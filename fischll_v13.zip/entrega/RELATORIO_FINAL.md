# Fishing Macro Mobile — relatório final

**Data:** 08/10/2026  
**Resultado:** identidade aplicada e APK Debug gerado. **Suíte de testes ainda reprovada por falhas preexistentes.**

## NOME

**Fishing Macro Mobile**

Aplicado ao launcher, `app_name`, título principal, notificações, nome do canal de notificações,
rótulo do serviço de acessibilidade e cabeçalhos dos diagnósticos mostrados/compartilhados.
O serviço de acessibilidade aparece como **Fishing Macro Mobile Input**, preservando o qualificativo funcional.

## ÍCONE

**Novo ícone anexado aplicado.** A imagem original foi usada diretamente, sem IA generativa,
sem redesenho e sem substituição. A decomposição de preto/transparência conserva as cores ao
recompor sobre fundo preto; redimensionamento uniforme com antialias, sem deformar Android ou peixe.

- Background preto `@color/ic_launcher_background`.
- Foreground derivado da imagem original, canvas **108 × 108 dp**, nas cinco densidades.
- Conteúdo visual significativo dentro da safe zone circular de **66 dp**; raios medidos de
  **31,26 a 31,66 dp**, menores que 33 dp. A figura não é cortada pelas máscaras usuais.
- Adaptive icons API 26+ em `mipmap-anydpi-v26`.
- API 33+ em `mipmap-anydpi-v33`, com camada **monochrome** derivada do mesmo foreground.
- Fallbacks `ic_launcher` e `ic_launcher_round`: **48, 72, 96, 144 e 192 px**.
- Manifest: `android:icon="@mipmap/ic_launcher"` e
  `android:roundIcon="@mipmap/ic_launcher_round"`.
- XMLs adaptativos, PNGs e referências confirmados também **dentro do APK compilado**, não apenas no código-fonte.
- Em ícones temáticos, o Android 13 aplica as cores do tema por escolha do usuário; no modo normal,
  a composição permanece branca/preta. Compatibilidade dos recursos verificada; aparência no launcher
  de aparelho físico **não foi testada**.

Documentação consultada: https://developer.android.com/develop/ui/compose/system/icon_design_adaptive

## ALTERAÇÕES — lista exata

Caminhos relativos a `firefox-v12/`.

### Arquivos existentes com conteúdo alterado (6)

- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/fischa/app/FischEngineService.kt`
- `app/src/main/java/com/fischa/app/MainActivity.kt`
- `app/src/main/java/com/fischa/app/ManualRodRoiOverlay.kt`
- `app/src/main/res/values/strings.xml`
- `core/src/main/kotlin/com/fischa/core/capture/CaptureProbe.kt`

**Detalhamento:**

1. `AndroidManifest.xml`: novos recursos de launcher/roundIcon e rótulo visível da acessibilidade.
2. `strings.xml`: nome oficial, nome do canal e recurso do rótulo da acessibilidade.
3. `MainActivity.kt`: somente título principal e cabeçalho de compartilhamento do diagnóstico.
4. `FischEngineService.kt`: somente textos das notificações e atualização do **nome** do canal
   existente. O ID do canal é o mesmo. A chamada oficial `createNotificationChannel` atualiza o nome;
   não há exclusão/recriação por outro ID nem alteração da lógica de captura/input/estados.
5. `CaptureProbe.kt`: somente literal do cabeçalho do relatório de diagnóstico. Nenhuma função
   de captura, medida, condição ou veredito foi alterada.
6. `ManualRodRoiOverlay.kt`: **exceção necessária para compilar o código recebido**:
   - `WindowManager?` capturado em variável local não nula após a mesma verificação de disponibilidade;
   - enum privado `TouchMode` movido da classe `inner RoiView` para a classe envolvente,
     pois Kotlin não permite essa declaração dentro de uma classe `inner`.
   - Valores do enum, cálculos de ROI, limites, gestos, persistência e callbacks preservados.

### Recursos adicionados (20)

- `app/src/main/res/drawable-hdpi/ic_launcher_foreground.png`
- `app/src/main/res/drawable-mdpi/ic_launcher_foreground.png`
- `app/src/main/res/drawable-xhdpi/ic_launcher_foreground.png`
- `app/src/main/res/drawable-xxhdpi/ic_launcher_foreground.png`
- `app/src/main/res/drawable-xxxhdpi/ic_launcher_foreground.png`
- `app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml`
- `app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml`
- `app/src/main/res/mipmap-anydpi-v33/ic_launcher.xml`
- `app/src/main/res/mipmap-anydpi-v33/ic_launcher_round.xml`
- `app/src/main/res/mipmap-hdpi/ic_launcher.png`
- `app/src/main/res/mipmap-hdpi/ic_launcher_round.png`
- `app/src/main/res/mipmap-mdpi/ic_launcher.png`
- `app/src/main/res/mipmap-mdpi/ic_launcher_round.png`
- `app/src/main/res/mipmap-xhdpi/ic_launcher.png`
- `app/src/main/res/mipmap-xhdpi/ic_launcher_round.png`
- `app/src/main/res/mipmap-xxhdpi/ic_launcher.png`
- `app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png`
- `app/src/main/res/mipmap-xxxhdpi/ic_launcher.png`
- `app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png`
- `app/src/main/res/values/icon_colors.xml`

### Arquivo removido

- `app/src/main/res/drawable/ic_fisch.xml` — ícone antigo, sem referências após a troca.

### Permissão de execução

- `gradlew` — marcado como executável para permitir `./gradlew`; conteúdo não alterado.

### Preservação e referências antigas

- **146 arquivos originais permanecem idênticos byte a byte** ao ZIP recebido.
- Todos os 32 arquivos Kotlin em `core/src/test` foram preservados. Nenhum teste foi excluído,
  ignorado ou alterado; nenhuma configuração `ignoreFailures` foi adicionada.
- `applicationId` e namespace: **com.fischa.app**. Versão e scripts Gradle preservados.
- `rootProject.name = "FischAutoBotV9"`, diretório `firefox-v12`, classes `FischEngineService`,
  pacotes, IDs, tags técnicas `FischAuto` e comentários históricos foram preservados.
- Documentação histórica recebida em README/docs/deliverables não foi reescrita nem apresentada
  como resultado desta execução. Este relatório é o resultado atual.
- Não restaram textos de marca antigos nos locais visuais identificados. A busca residual encontra
  somente identificadores técnicos, tags de log e comentários/histórico.
- START, START FISHING, STOP, máquinas de estados, VisionPipeline, MediaProjection,
  ScreenCaptureSource, detectores, InputSafetyGuard, permissões declaradas e configurações de
  automação não tiveram sua lógica alterada.

## TESTES

| Verificação | Resultado |
|---|---|
| `./gradlew clean` | **PASS**, executado novamente após corrigir os erros de compilação |
| `./gradlew test` | **FAIL** — 242 testes, **237 aprovados, 5 reprovados**, 0 ignorados |
| `./gradlew :core:selfTest` | **FAIL** — 138 verificações, **113 aprovadas, 25 reprovadas** |
| Comparação com cópia original do ZIP | **PASS** — mesmos 242 resultados individuais e mesmas 5 falhas; selfTest original também com 25 falhas |
| Verificação externa de identidade e safe zone | **PASS** — cinco densidades, Manifest, XMLs e preservação do escopo |
| `apksigner verify --verbose --print-certs` | **PASS** — assinatura Debug RSA, APK Signature Scheme v2 |
| `zipalign -c -v 4` | **PASS** |
| `aapt2 dump badging/xmltree/resources` | **PASS** — nome, pacote, versão, ícones e referências compilados confirmados |

`app:testDebugUnitTest` e `app:testReleaseUnitTest` retornam **NO-SOURCE**: o módulo Android não tem
fontes de teste unitário. Os 242 testes pertencem a `core`. Não há testes instrumentados no projeto
recebido; não foi alegada execução em emulador/aparelho. Lint não foi executado nesta etapa.

### Cinco testes reprovados — reproduzidos no original e no final

- `com.fischa.core.v9.V9PipelineIntegrationTest.pipelineForwardsDiagnosticFramesToTheSink`
  - java.lang.AssertionError: sem frames de 'nenhum candidato'
- `com.fischa.core.v9.V9RodButtonDetectionTest.stationaryButtonKeepsItsWindowStableAfterConfirmation`
  - java.lang.AssertionError: perdeu o alvo parado
- `com.fischa.core.v9.V9RodButtonDetectionTest.worksAtDifferentResolutions`
  - java.lang.AssertionError: 1280 x 720: não detectou (confirmação: confirmando 1/3 (conf 0.52))
- `com.fischa.core.v9.V9RodButtonDetectionTest.roiStartingFarFromTargetKeepsHonestAndRecoversWhenTheWindowGrows`
  - java.lang.AssertionError: centro a 301.85675px do botão recuperado
- `com.fischa.core.v9.V9RodButtonDetectionTest.worksAtDifferentAspectRatios`
  - java.lang.AssertionError: 720 x 720: não detectou (SEARCHING etapa 1/3 da escada (busca ampliada) | TARGET_NOT_FOUND)

**Análise:** as falhas são de diagnóstico/detecção V9, estabilidade do alvo, resoluções, proporções
ou recuperação de ROI. Os mesmos testes e a lógica testada são idênticos ao original. Corrigi-las
exigiria uma tarefa separada de manutenção/validação do detector, expressamente fora desta alteração
final de identidade. Não foi usada exclusão de testes nem mudança de expectativa para ocultá-las.

**SelfTest:** as 25 falhas estão nos checks legados de cast/input/safety. Os fixtures do harness
não ativam `SafetyContext.automationActive`, cujo padrão é `false`, enquanto o guard atual retorna
`AUTOMATION_NOT_ACTIVE` antes das condições que esses checks esperam testar. O harness e o guard
foram mantidos intactos. A lista completa de falhas está em `logs/16-selfTest-final.log`.

### Resultado por classe da suíte JUnit

| Classe | Testes | Aprovados | Falhas | Ignorados |
|---|---:|---:|---:|---:|
| `CaptureConsentPolicyTest` | 8 | 8 | 0 | 0 |
| `CaptureDiagnosticsTest` | 13 | 13 | 0 | 0 |
| `CaptureInputSeparationTest` | 6 | 6 | 0 | 0 |
| `CaptureSessionGateTest` | 1 | 1 | 0 | 0 |
| `CaptureStateMachineTest` | 11 | 11 | 0 | 0 |
| `FrameAgeTest` | 5 | 5 | 0 | 0 |
| `FrameBufferTest` | 2 | 2 | 0 | 0 |
| `ProcessingResolutionTest` | 2 | 2 | 0 | 0 |
| `CoordinateMapperTest` | 8 | 8 | 0 | 0 |
| `AppConfigTest` | 3 | 3 | 0 | 0 |
| `ControllersTest` | 10 | 10 | 0 | 0 |
| `GestureLeaseTest` | 3 | 3 | 0 | 0 |
| `StartFishingFlowTest` | 16 | 16 | 0 | 0 |
| `StartFishingLifecycleV12Test` | 2 | 2 | 0 | 0 |
| `StartSemanticsV5Test` | 10 | 10 | 0 | 0 |
| `EmergencyStopAndInputGateTest` | 6 | 6 | 0 | 0 |
| `InputSafetyGuardTest` | 6 | 6 | 0 | 0 |
| `RobloxForegroundDetectorTest` | 12 | 12 | 0 | 0 |
| `AutomationStateMachineTest` | 12 | 12 | 0 | 0 |
| `FishingStateMachineTest` | 5 | 5 | 0 | 0 |
| `RodConfirmTrackerTest` | 7 | 7 | 0 | 0 |
| `TrackersTest` | 6 | 6 | 0 | 0 |
| `V7RealInputLockTest` | 3 | 3 | 0 | 0 |
| `V7RodFinderTest` | 13 | 13 | 0 | 0 |
| `V8PipelineIntegrationTest` | 5 | 5 | 0 | 0 |
| `V8RodDetectionTest` | 30 | 30 | 0 | 0 |
| `V9DiagProbeTest` | 1 | 1 | 0 | 0 |
| `V9PipelineIntegrationTest` | 7 | 6 | 1 | 0 |
| `V9RodButtonDetectionTest` | 28 | 24 | 4 | 0 |
| `V9ScenesProbeTest` | 1 | 1 | 0 | 0 |

## BUILD

**`assembleDebug`: concluído com sucesso.** Log: `logs/15-assembleDebug-retry.log`.
Nenhuma etapa de teste foi desativada. A montagem do APK é uma tarefa independente da aprovação
da suíte JVM; portanto **APK compilado não significa suíte aprovada**.

Ambiente: JDK 17, Gradle Wrapper **8.9**, AGP **8.7.3**, Kotlin **2.0.21**,
Android SDK Platform **35**, Build Tools **35.0.0**. `minSdk=26`, `targetSdk=35`.

### Erros e recuperação — sem omissões

1. O ambiente tinha apenas Java 11 e nenhum SDK Android. JDK 17 e SDK oficial foram instalados
   fora do projeto; nenhuma dependência/build script foi substituída.
2. A compilação Android encontrou os dois erros originais em `ManualRodRoiOverlay.kt`.
   Foram corrigidos estritamente como descrito acima; depois houve novo `clean`, `test` e build.
3. Tentativas de teste excederam a RAM do sandbox de aproximadamente 2 GiB. O kernel confirmou
   OOM-kill de processos Java (`logs/13-memoria-ambiente.log`). Uma execução encadeada foi interrompida
   para recuperar o ambiente; o log parcial de assembleDebug não é declarado sucesso.
4. Foram ajustados **somente os parâmetros de memória do ambiente**, em
   `/home/user/.cache/gradle/gradle.properties`, sem mudar arquivos Gradle do projeto:
   `-Xmx384m -XX:MaxMetaspaceSize=320m -XX:ReservedCodeCacheSize=96m -XX:+UseSerialGC`.
5. Nova execução completa de `./gradlew test` terminou com as cinco falhas preexistentes;
   `./gradlew assembleDebug` terminou com **BUILD SUCCESSFUL**; `:core:selfTest` foi reexecutado
   e manteve as 25 falhas anteriores. Todos os logs, inclusive os iniciais, foram preservados.

## APK

- **Nome do aplicativo:** Fishing Macro Mobile.
- **Variante:** debug (debuggable, assinatura de desenvolvimento).
- **Versão:** `12.0-v12` — `versionCode=12`, sem alteração.
- **Package/applicationId:** `com.fischa.app`, sem alteração.
- **Caminho exato gerado pelo Gradle:**
  `/home/user/firefox-v12/app/build/outputs/apk/debug/app-debug.apk`
- **Cópia persistente para download:**
  `/home/user/entrega/Fishing-Macro-Mobile-12.0-v12-debug.apk`
- **SHA-256:** `bbcc617bd07e4cbc3f154cc00ea58845209d79d1d8ccac526fedc45d0ba48b0a`
- **Instalável:** APK Android completo, assinado e alinhado; não é AAB, stub ou arquivo renomeado.
  A instalação/abertura efetiva em aparelho não foi executada.
- Assinatura Debug gerada neste ambiente. Uma instalação anterior assinada por outra chave pode
  recusar atualização. Não desinstale uma versão existente sem antes preservar dados/calibrações.

## PROBLEMAS RESTANTES

1. **Cinco falhas JUnit V9**, reproduzidas no projeto original.
2. **25 falhas do harness SelfTest**, também reproduzidas no original.
3. **Validação física pendente**: instalação, launcher normal/temático Android 13, captura,
   permissões, calibração e START/START FISHING/STOP no dispositivo alvo.
4. Advertências preexistentes de APIs obsoletas (`recycle`) e de inlining aparecem nos logs;
   não impedem a compilação e não foram usadas como motivo para refatoração fora do escopo.

**Conclusão:** identidade correta e APK Debug gerado; não declarar o aplicativo integralmente
homologado enquanto as falhas de testes e a validação física não forem resolvidas.

## Materiais da entrega

- `Fishing-Macro-Mobile-12.0-v12-debug.apk`: APK independente para instalar.
- `Fishing-Macro-Mobile-projeto-e-relatorio.zip`: projeto limpo, relatório, logs, resultados JUnit
  original/final, CSVs/HTML, patch textual, scripts de geração/verificação e imagem original.
- `alteracoes.patch`: diff dos arquivos textuais; os PNGs estão no projeto completo do ZIP.
- `arquivos-alterados.json`: inventário exato.
- `comparacao-testes.json`: status de cada teste original/final.

### Procedência

ZIP de origem: https://github.com/Votetrols/Fish-macro-test-3/blob/24a7f5455f78794e2ac3025e818c14fd27937038/firefox_v12.zip

- SHA-256 do ZIP original: `6ee836c3d676d3f8d157c1ad58e8c05665a7183e05e4697caa84304366ab7242`
- SHA-256 da imagem original anexada: `a3f704a7d053759e445c47d32cb1fa6ef359c089d8d435aa04ad807f40d9aa0a`

### Reproduzir localmente

Instale JDK 17 e Android SDK Platform 35 + Build Tools 35.0.0, configure `JAVA_HOME` e
`ANDROID_HOME` (ou `sdk.dir` em seu `local.properties`) e, em `firefox-v12/`, execute:

```bash
chmod +x gradlew
./gradlew clean
./gradlew test
./gradlew assembleDebug
./gradlew :core:selfTest
```

Os comandos de teste continuam sujeitos às falhas explicitamente documentadas. Execute os comandos
separadamente para observar cada resultado. Não use `-x test`, `ignoreFailures` ou remoção de testes.
O ZIP não contém SDK/JDK, caches, chave privada de assinatura ou caminhos locais de SDK.
