"""Deriva os recursos da imagem fornecida, sem redesenhar. Requer Pillow e NumPy.
Uso: python gerar_icones.py IMAGEM DIRETORIO_RES
"""
from pathlib import Path
import sys
import numpy as np
from PIL import Image, ImageDraw

source = Path(sys.argv[1])
res = Path(sys.argv[2])
original = Image.open(source).convert('RGB')
a = np.asarray(original).astype(np.float32)
# Separação matemática do preto: recompor sobre preto recupera os pixels originais.
alpha = a.max(axis=2)
rgb = np.divide(a * 255, alpha[:, :, None], out=np.zeros_like(a), where=alpha[:, :, None] > 0)
rgba = np.dstack((np.rint(rgb), alpha)).astype('uint8')
foreground = Image.fromarray(rgba, 'RGBA')
y, x = np.where(alpha > 16)
cx, cy = (x.min() + x.max()) / 2, (y.min() + y.max()) / 2
radius = np.hypot(x - cx, y - cy).max()
# Margem dentro da safe zone circular de 66dp: raio do conteúdo = 31.5dp.
scale = 31.5 / radius

for density, factor in [('mdpi', 1), ('hdpi', 1.5), ('xhdpi', 2), ('xxhdpi', 3), ('xxxhdpi', 4)]:
    folder = res / ('drawable-' + density)
    folder.mkdir(parents=True, exist_ok=True)
    size = round(108 * factor)
    w, h = [round(n * scale * factor) for n in original.size]
    art = foreground.resize((w, h), Image.Resampling.LANCZOS)
    layer = Image.new('RGBA', (size, size))
    layer.alpha_composite(art, (round(size/2 - cx*w/original.width), round(size/2 - cy*h/original.height)))
    layer.save(folder / 'ic_launcher_foreground.png', optimize=True)
    # Fallbacks de 48dp: mesma composição, enquadramento central de 72dp.
    inset = round(18 * factor)
    viewport = layer.crop((inset, inset, size-inset, size-inset))
    legacy = Image.new('RGBA', viewport.size, 'black')
    legacy.alpha_composite(viewport)
    legacy = legacy.resize((round(48*factor), round(48*factor)), Image.Resampling.LANCZOS)
    folder = res / ('mipmap-' + density)
    folder.mkdir(parents=True, exist_ok=True)
    legacy.convert('RGB').save(folder / 'ic_launcher.png', optimize=True)
    # Antialias na máscara circular do fallback, sem recortar a figura.
    mask = Image.new('L', (legacy.width*4, legacy.height*4))
    ImageDraw.Draw(mask).ellipse((0, 0, mask.width-1, mask.height-1), fill=255)
    legacy.putalpha(mask.resize(legacy.size, Image.Resampling.LANCZOS))
    legacy.save(folder / 'ic_launcher_round.png', optimize=True)

for api in [26, 33]:
    folder = res / f'mipmap-anydpi-v{api}'
    folder.mkdir(parents=True, exist_ok=True)
    mono = '    <monochrome android:drawable="@drawable/ic_launcher_foreground" />\n' if api == 33 else ''
    xml = ('<?xml version="1.0" encoding="utf-8"?>\n'
           '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
           '    <background android:drawable="@color/ic_launcher_background" />\n'
           '    <foreground android:drawable="@drawable/ic_launcher_foreground" />\n'
           + mono + '</adaptive-icon>\n')
    for name in ['ic_launcher', 'ic_launcher_round']:
        (folder / (name + '.xml')).write_text(xml)
(res / 'values' / 'icon_colors.xml').write_text(
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
    '    <color name="ic_launcher_background">#000000</color>\n</resources>\n')
print(f'Imagem: {original.size}; escala uniforme: {scale:.9f} dp/px; raio visual: 31.5dp; canvas: 108dp.')
