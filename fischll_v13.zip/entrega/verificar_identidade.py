"""Verificação externa de identidade; não altera o código nem a suíte de testes.
Uso: python verificar_identidade.py PROJETO ZIP_ORIGINAL
"""
from pathlib import Path
import sys, zipfile, hashlib, json
import xml.etree.ElementTree as ET
from PIL import Image
import numpy as np

root = Path(sys.argv[1]); original = zipfile.ZipFile(sys.argv[2])
res = root/'app/src/main/res'
ns = '{http://schemas.android.com/apk/res/android}'
strings = {e.attrib['name']: e.text for e in ET.parse(res/'values/strings.xml').getroot()}
assert strings['app_name'] == 'Fishing Macro Mobile'
assert strings['notification_channel'] == 'Fishing Macro Mobile'
manifest = ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
app = manifest.find('application')
assert app.get(ns+'label') == '@string/app_name'
assert app.get(ns+'icon') == '@mipmap/ic_launcher'
assert app.get(ns+'roundIcon') == '@mipmap/ic_launcher_round'
old_manifest = ET.fromstring(original.read('firefox-v12/app/src/main/AndroidManifest.xml'))
assert [ET.tostring(e) for e in manifest.findall('uses-permission')] == [ET.tostring(e) for e in old_manifest.findall('uses-permission')]
for svc, old in zip(app.findall('service'), old_manifest.find('application').findall('service')):
    a, b = dict(svc.attrib), dict(old.attrib)
    a.pop(ns+'label', None); b.pop(ns+'label', None)
    assert a == b, 'Registro técnico de serviço mudou'
for api in (26, 33):
    for name in ('ic_launcher', 'ic_launcher_round'):
        icon = ET.parse(res/f'mipmap-anydpi-v{api}/{name}.xml').getroot()
        assert icon.tag == 'adaptive-icon'
        assert icon.find('background').get(ns+'drawable') == '@color/ic_launcher_background'
        assert icon.find('foreground').get(ns+'drawable') == '@drawable/ic_launcher_foreground'
        if api == 33:
            assert icon.find('monochrome').get(ns+'drawable') == '@drawable/ic_launcher_foreground'
assert ET.parse(res/'values/icon_colors.xml').find('color').text == '#000000'
for density, factor in [('mdpi',1), ('hdpi',1.5), ('xhdpi',2), ('xxhdpi',3), ('xxxhdpi',4)]:
    im = Image.open(res/f'drawable-{density}/ic_launcher_foreground.png')
    assert im.size == (round(108*factor),)*2
    a = np.array(im)[:,:,3]
    y,x = np.where(a > 16)
    radius = float(np.hypot((x+.5)/factor-54, (y+.5)/factor-54).max())
    assert radius <= 33, f'{density}: fora da safe zone circular: {radius}'
    print(f'PASS {density}: foreground {im.size}, raio visual {radius:.2f}dp < 33dp')
    for name in ['ic_launcher','ic_launcher_round']:
        assert Image.open(res/f'mipmap-{density}/{name}.png').size == (round(48*factor),)*2
# Apenas arquivos de identidade autorizados diferem do ZIP original.
allowed = {
 'app/src/main/AndroidManifest.xml',
 'app/src/main/res/values/strings.xml',
 'app/src/main/java/com/fischa/app/MainActivity.kt',
 'app/src/main/java/com/fischa/app/FischEngineService.kt',
 'core/src/main/kotlin/com/fischa/core/capture/CaptureProbe.kt',
 # Exceção estritamente necessária: smart-cast local e enum fora da classe inner.
 'app/src/main/java/com/fischa/app/ManualRodRoiOverlay.kt',
}
changed, removed, unchanged = [], [], []
for name in original.namelist():
    parts = Path(name).parts
    if not parts or parts[0] != 'firefox-v12' or name.endswith('/') or any(p in parts for p in ['build','.gradle','.git']): continue
    rel = '/'.join(parts[1:]); path = root/rel
    if not path.exists():
        assert rel == 'app/src/main/res/drawable/ic_fisch.xml'
        removed.append(rel)
    elif path.read_bytes() != original.read(name):
        assert rel in allowed, 'Alteração fora do escopo: '+rel
        changed.append(rel)
    else:
        unchanged.append(rel)
assert len(changed) == len(allowed)
assert all('src/test/' not in c for c in changed)
assert (root/'gradlew').stat().st_mode & 0o111
print(f'PASS: {len(unchanged)} arquivos originais com bytes idênticos; {len(changed)} alterados; {len(removed)} removido (ícone antigo).')
print('PASS: permissões, registros técnicos dos serviços, testes, build scripts, IDs e lógica protegida preservados.')
print('PASS: Manifest, app_name, cinco densidades, adaptive v26 e monochrome v33.')
