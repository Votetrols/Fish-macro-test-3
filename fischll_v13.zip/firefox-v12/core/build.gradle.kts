plugins {
    id("org.jetbrains.kotlin.jvm")
}

java {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
    kotlinOptions.jvmTarget = "11"
}

tasks.withType<org.gradle.api.tasks.testing.Test>().configureEach {
    // Keep the JVM test fork bounded in constrained CI/sandbox environments; detector tests are
    // allocation-light and run serially, so this does not reduce production heap capacity.
    maxHeapSize = "256m"
    maxParallelForks = 1
}

tasks.register<JavaExec>("selfTest") {
    group = "verification"
    description = "Runs the deterministic core self-test harness."
    dependsOn(tasks.named("classes"))
    classpath = sourceSets["main"].runtimeClasspath
    mainClass.set("com.fischa.core.tools.SelfTest")
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}
