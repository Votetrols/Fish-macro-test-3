package com.fischa.core.pipeline

import com.fischa.core.config.AppConfig
import com.fischa.core.config.RodDetectorKind
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.RecordingExecutor
import com.fischa.core.state.AutomationState
import com.fischa.core.vision.VisionFrame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** V12 structural lifecycle tests: START is infrastructure-only; START FISHING owns vision. */
class StartFishingLifecycleV12Test {
    private fun input(ts: Long, macro: Boolean = true) = PipelineInput(
        frameTimestampNs = ts,
        currentTimeNs = ts,
        captureHealthy = true,
        robloxDetected = true,
        inputAuthorized = true,
        macroEnabled = macro,
        realInputEnabled = false,
        foregroundPackage = "com.roblox.client",
        foregroundBlockReason = "NONE",
    )

    private fun frame(ts: Long): VisionFrame {
        val f = VisionFrame.allocate(64, 32)
        f.argb.fill(0xFF787878.toInt())
        // Keep gray all-zero as a cheap probe: inactive processing must not call ensureGray().
        f.resetFor(ts, ts)
        return f
    }

    @Test
    fun mainStartReadyDoesNotRunHeavyVision() {
        val pipeline = VisionPipeline(
            cfg = AppConfig().validate().copy(rodDetector = RodDetectorKind.V8),
            executor = RecordingExecutor(),
            log = ThrottledLog(NoopSink),
            emergency = EmergencyStop(),
        )
        assertTrue(pipeline.setInfrastructureReady(true, "capture RUNNING", 1L))
        assertEquals(AutomationState.APP_READY, pipeline.automationState)

        val f = frame(2L)
        pipeline.onFrame(f, input(2L))

        assertEquals(AutomationState.APP_READY, pipeline.automationState)
        assertEquals("INACTIVE", pipeline.output.rodDetector)
        assertFalse(pipeline.output.rodDetected)
        assertTrue("APP_READY must not allocate/fill grayscale pixels", f.gray.all { it.toInt() == 0 })
        pipeline.close()
    }

    @Test
    fun startFishingEnablesVisionAndStopClearsIt() {
        val pipeline = VisionPipeline(
            cfg = AppConfig().validate().copy(rodDetector = RodDetectorKind.V8),
            executor = RecordingExecutor(),
            log = ThrottledLog(NoopSink),
            emergency = EmergencyStop(),
        )
        pipeline.setInfrastructureReady(true, "capture RUNNING", 1L)
        assertTrue(pipeline.startFishing("test", 2L))
        assertEquals(AutomationState.FISHING_ACTIVE, pipeline.automationState)

        val f = frame(3L)
        pipeline.onFrame(f, input(3L))
        assertTrue("START FISHING must enter the active vision path", f.gray.any { it.toInt() != 0 })

        assertTrue(pipeline.stopFishing("test stop", 4L))
        assertEquals(AutomationState.APP_READY, pipeline.automationState)
        val stoppedFrame = frame(5L)
        pipeline.onFrame(stoppedFrame, input(5L))
        assertEquals("INACTIVE", pipeline.output.rodDetector)
        assertFalse(pipeline.output.rodDetected)
        assertTrue("STOP must return to the O(1) inactive path", stoppedFrame.gray.all { it.toInt() == 0 })
        pipeline.close()
    }
}
