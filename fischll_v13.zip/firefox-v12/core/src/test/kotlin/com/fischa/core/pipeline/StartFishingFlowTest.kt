package com.fischa.core.pipeline

import com.fischa.core.config.AppConfig
import com.fischa.core.config.RodDetectorKind
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.safety.DenyReason
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.RealInputPolicy
import com.fischa.core.safety.RecordingExecutor
import com.fischa.core.safety.RobloxForegroundStatus
import com.fischa.core.state.AutomationChange
import com.fischa.core.state.AutomationState
import com.fischa.core.state.AutomationUi
import com.fischa.core.state.FishingState
import com.fischa.core.vision.VisionFrame
import com.fischa.core.v7.RodSceneFixture
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * **V9.1 §1…§11/§16 — separação entre "START do aplicativo" e "START da pesca".**
 *
 * Roda o `VisionPipeline` **real** com frames sintéticos do `RodSceneFixture` (a mesma cena que os
 * testes V7/V8 já usam como evidência do botão da vara) e verifica ponta a ponta:
 *
 *   1. START principal → `APP_READY`, **zero** input, `FishingState.IDLE`;
 *   2. START FISHING → `FISHING_ACTIVE` e só então o ciclo executa (vara confirmada);
 *   3. STOP → nenhum input novo, gesto cancelado, `APP_READY` e **captura preservada**;
 *   4. START FISHING depois do STOP começa uma sessão limpa (nada de alvo/confirmação antigos);
 *   5. `targetFound=false`, confiança baixa e captura/foreground inválidos nunca geram input;
 *   6. dois STARTs não criam dois ciclos, dois STOPs não quebram nada.
 *
 * Observação de honestidade (spec §17): a detecção usada aqui é a **V8** (`rodDetector = V8`),
 * escolhida explicitamente porque é o detector preservado que completa a cadeia
 * visão→decisão→input **nesta cena sintética**. A V9 é medida no fim do arquivo apenas quanto ao
 * comportamento honesto (`targetFound=false`, sem coordenada inventada). Teste sintético **não** é
 * validação visual do botão real do Fisch (isso exige frames reais, via `RodFrameLab`).
 */
class StartFishingFlowTest {

    private companion object {
        const val W = 640
        const val H = 288
        const val ROD_X = 520
        const val ROD_Y = 199
    }

    // V7 §10: o build publica REAL_INPUT travado; esta suíte mede a cadeia com input autorizado,
    // então a trava é liberada durante os testes e restaurada depois (a trava tem suíte própria).
    @Before fun unlockRealInput() {
        RealInputPolicy.unlockForTesting("V9.1 START FISHING / STOP flow test (input chain)")
    }

    @After fun restoreRealInputLock() {
        RealInputPolicy.lock()
    }

    private inner class Rig(
        realInput: Boolean = true,
        cfg: AppConfig = AppConfig().copy(rodDetector = RodDetectorKind.V8).validate(),
    ) {
        var nowNs = 1_000_000_000L
        var serial = 0L
        val exec = RecordingExecutor()
        val requests = ArrayList<AutomationChange>()
        val listener: (AutomationChange) -> Unit = { requests.add(it) }
        val pipeline = VisionPipeline(
            cfg = cfg,
            executor = exec,
            log = ThrottledLog(NoopSink),
            emergency = EmergencyStop(),
            foregroundStatusProvider = {
                RobloxForegroundStatus(
                    foregroundPackage = "com.roblox.client",
                    robloxDetected = true,
                    inputAuthorized = true,
                    blockReason = "NONE",
                    timestampMs = nowNs / 1_000_000L,
                )
            },
            monotonicNowNs = { nowNs },
        ).also { it.automation.addListener(listener) }

        private val realInput = realInput

        /** transições da automação como "FROM->TO" (ordem de publicação). */
        fun transitions() = requests.map { "${it.from.name}->${it.to.name}" }

        /** START principal: só infraestrutura (é o que o serviço faz quando a captura fica RUNNING). */
        fun mainStart(): Boolean = pipeline.setInfrastructureReady(true, "captura RUNNING", nowNs)

        fun frame(withRod: Boolean = true, captureHealthy: Boolean = true, authorized: Boolean = true) {
            val f = VisionFrame.allocate(W, H)
            RodSceneFixture.draw(f, if (withRod) RodSceneFixture.Rod(ROD_X, ROD_Y) else null)
            f.resetFor(nowNs, ++serial)
            f.ensureGray()
            pipeline.onFrame(
                f,
                PipelineInput(
                    frameTimestampNs = nowNs,
                    currentTimeNs = nowNs,
                    captureHealthy = captureHealthy,
                    robloxDetected = authorized,
                    inputAuthorized = authorized,
                    macroEnabled = pipeline.armed,
                    realInputEnabled = realInput,
                    foregroundPackage = if (authorized) "com.roblox.client" else "com.android.launcher",
                    foregroundBlockReason = if (authorized) "NONE" else "FOREGROUND_PACKAGE_MISMATCH",
                ),
            )
            nowNs += 33_000_000L
        }

        fun steps(n: Int, withRod: Boolean = true, captureHealthy: Boolean = true, authorized: Boolean = true) {
            repeat(n) { frame(withRod = withRod, captureHealthy = captureHealthy, authorized = authorized) }
        }

        /** gestos reais (cancelAll/releaseAll são limpeza, não input). */
        fun gestures() = exec.calls.filter { it == "tap" || it == "holdStart" || it == "holdExtend" }

        fun castsStarted() = exec.calls.count { it == "holdStart" }

        fun close() {
            pipeline.automation.removeListener(listener)
            pipeline.close()
        }
    }

    // ================================================================ 1/2 — START principal

    @Test fun mainStartLeavesTheSystemReadyWithoutFishing() {
        val rig = Rig()
        assertTrue("START principal precisa publicar READY", rig.mainStart())
        assertEquals(AutomationState.APP_READY, rig.pipeline.automationState)
        assertEquals("AUTOMATION: READY", rig.pipeline.automation.debugLine)
        assertEquals("START FISHING", AutomationUi.buttonLabel(rig.pipeline.automationState))
        assertFalse("READY não é FISHING_ACTIVE", rig.pipeline.automation.pumping)

        // A cena tem o botão da vara — e MESMO ASSIM nada pode acontecer.
        rig.steps(60, withRod = true)

        assertEquals("START principal não pode pescar", emptyList<String>(), rig.gestures())
        assertFalse("cast nunca autorizado em READY", rig.pipeline.output.castAuthorized)
        assertFalse("nada foi enviado ao executor", rig.pipeline.output.inputIssued)
        assertEquals(
            "a porteira do cast precisa dizer por que não autoriza (automação não está ativa)",
            DenyReason.AUTOMATION_NOT_ACTIVE.name,
            rig.pipeline.output.castGateReason,
        )
        assertFalse("START principal não executa visão pesada", rig.pipeline.output.rodDetected)
        assertEquals("detector fica inativo no READY", "INACTIVE", rig.pipeline.output.rodState)
        assertTrue(
            "a FSM de pesca fica em IDLE durante toda a preparação",
            rig.pipeline.output.state == FishingState.IDLE,
        )
        assertEquals(
            "apenas o READY foi registrado",
            listOf("APP_IDLE->APP_READY"),
            rig.transitions(),
        )
        rig.close()
    }

    // ================================================================ 3/4 — START FISHING

    @Test fun startFishingActivatesTheAutomationAndOnlyThenTheCycleRuns() {
        val rig = Rig()
        rig.mainStart()
        rig.steps(20, withRod = true)
        assertEquals("nada de gesto antes do START FISHING", 0, rig.gestures().size)

        assertTrue("START FISHING precisa ativar a automação", rig.pipeline.startFishing("START FISHING", rig.nowNs))
        assertEquals(AutomationState.FISHING_ACTIVE, rig.pipeline.automationState)
        assertEquals("o botão flutuante passa a significar STOP", "STOP", AutomationUi.buttonLabel(rig.pipeline.automationState))

        rig.steps(40, withRod = true)

        assertTrue("a vara confirma e o cast executa", rig.pipeline.output.rodConfirmed)
        assertTrue("cast iniciado com HOLD_START", rig.castsStarted() >= 1)
        assertTrue(
            "o ciclo saiu de IDLE (estado=${rig.pipeline.output.state})",
            rig.pipeline.output.state != FishingState.IDLE,
        )
        assertEquals(
            listOf("APP_IDLE->APP_READY", "APP_READY->FISHING_ACTIVE"),
            rig.transitions(),
        )
        rig.close()
    }

    @Test fun startFishingTwiceKeepsASingleCycle() {
        val rig = Rig()
        rig.mainStart()
        assertTrue(rig.pipeline.startFishing("START FISHING", rig.nowNs))
        rig.steps(25, withRod = true)
        val stateBefore = rig.pipeline.output.state
        val transitionsBefore = rig.transitions()

        assertFalse("o segundo START FISHING é ignorado", rig.pipeline.startFishing("START FISHING", rig.nowNs))
        assertEquals("nenhum ciclo novo foi criado", stateBefore, rig.pipeline.output.state)
        assertEquals("nenhuma transição nova", transitionsBefore, rig.transitions())
        rig.steps(10, withRod = true)
        assertEquals("o ciclo continua o mesmo", FishingState.CASTING, rig.pipeline.output.state)
        rig.close()
    }

    // ================================================================ 5/6/7 — STOP

    @Test fun stopBlocksEveryNewInputCancelsGesturesAndReturnsToReady() {
        val rig = Rig()
        rig.mainStart()
        rig.pipeline.startFishing("START FISHING", rig.nowNs)
        rig.steps(30, withRod = true)
        assertTrue("pré-condição: o cast precisa ter começado", rig.castsStarted() >= 1)

        val gesturesAtStop = rig.gestures().size
        assertTrue(rig.pipeline.stopFishing("STOP", rig.nowNs))

        assertTrue("o gesto em curso é cancelado", rig.exec.calls.contains("cancelAll"))
        assertTrue("e liberado", rig.exec.calls.contains("releaseAll"))
        assertEquals(AutomationState.APP_READY, rig.pipeline.automationState)
        assertFalse("a automação está desligada", rig.pipeline.automation.pumping)
        assertEquals("o botão volta para START FISHING", "START FISHING", AutomationUi.buttonLabel(rig.pipeline.automationState))

        // frames com o botão da vara visível: nenhum gesto novo pode sair
        rig.steps(60, withRod = true)
        assertEquals("nenhum gesto novo depois do STOP", gesturesAtStop, rig.gestures().size)
        assertEquals(FishingState.IDLE, rig.pipeline.output.state)
        assertFalse("nada foi enviado ao executor depois do STOP", rig.pipeline.output.inputIssued)
        assertEquals(
            "a porteira do cast precisa dizer por que não autoriza (automação parada pelo STOP)",
            DenyReason.AUTOMATION_NOT_ACTIVE.name,
            rig.pipeline.output.castGateReason,
        )
        assertEquals(
            listOf(
                "APP_IDLE->APP_READY",
                "APP_READY->FISHING_ACTIVE",
                "FISHING_ACTIVE->FISHING_STOPPING",
                "FISHING_STOPPING->APP_READY",
            ),
            rig.transitions(),
        )
        rig.close()
    }

    @Test fun stopTwiceIsSafeAndDoesNotBreakAnything() {
        val rig = Rig()
        rig.mainStart()
        rig.pipeline.startFishing("START FISHING", rig.nowNs)
        rig.steps(25, withRod = true)

        assertTrue(rig.pipeline.stopFishing("STOP", rig.nowNs))
        assertFalse("o segundo STOP é no-op", rig.pipeline.stopFishing("STOP", rig.nowNs))
        assertFalse("STOP em READY continua sem efeito", rig.pipeline.stopFishing("STOP", rig.nowNs))
        assertEquals(AutomationState.APP_READY, rig.pipeline.automationState)
        rig.steps(10, withRod = true)
        assertEquals(FishingState.IDLE, rig.pipeline.output.state)
        rig.close()
    }

    @Test fun stopKeepsTheCaptureAliveAndTheDetectionObserving() {
        val rig = Rig()
        rig.mainStart()
        rig.pipeline.startFishing("START FISHING", rig.nowNs)
        rig.steps(25, withRod = true)
        rig.pipeline.stopFishing("STOP", rig.nowNs)

        // a captura continua válida, mas a visão pesada só volta após novo START FISHING (§4)
        rig.steps(20, withRod = true, captureHealthy = true)
        assertFalse("STOP desliga a visão pesada até novo START FISHING", rig.pipeline.output.rodDetected)
        assertEquals("mas nada de ciclo", FishingState.IDLE, rig.pipeline.output.state)
        assertEquals(
            "a automação continua em READY (não vira erro nem derruba a sessão)",
            AutomationState.APP_READY,
            rig.pipeline.automationState,
        )
        assertTrue("captura não foi destruída", rig.pipeline.output.state != FishingState.CAPTURE_ERROR)
        rig.close()
    }

    // ================================================================ 8/10 — nova sessão limpa

    @Test fun startAfterStopBeginsACleanSession() {
        val rig = Rig()
        rig.mainStart()

        // 1º ciclo: confirma a vara, chega ao cast
        rig.pipeline.startFishing("START FISHING", rig.nowNs)
        rig.steps(35, withRod = true)
        assertEquals(FishingState.CASTING, rig.pipeline.output.state)
        assertTrue("pré-condição: alvo confirmado", rig.pipeline.output.rodConfirmed)
        val castsFirstCycle = rig.castsStarted()

        // STOP limpa tudo
        rig.pipeline.stopFishing("STOP", rig.nowNs)
        rig.steps(2, withRod = true) // o STOP é publicado no frame seguinte
        assertFalse("nenhum alvo antigo sobrevive ao STOP", rig.pipeline.output.rodConfirmed)
        assertFalse("nenhuma confirmação antiga sobrevive", rig.pipeline.output.rodV8TargetFound)

        // 2º ciclo: começa limpo — nada herdado da sessão anterior
        assertTrue(rig.pipeline.startFishing("START FISHING", rig.nowNs))
        rig.steps(2, withRod = true) // ainda não dá para confirmar (o streak recomeçou)
        assertEquals("a sessão nova não pula direto para a ação", FishingState.WAITING_FOR_ROD, rig.pipeline.output.state)
        assertFalse("a sessão nova não herda confirmação", rig.pipeline.output.rodConfirmed)

        rig.steps(35, withRod = true)
        assertTrue("o novo ciclo executa de novo", rig.castsStarted() > castsFirstCycle)
        assertTrue(rig.exec.calls.contains("holdStart"))
        rig.close()
    }

    // ================================================================ 11/12/13/14 — sem input indevido

    @Test fun targetNotFoundNeverProducesInputOrInventedCoordinates() {
        val rig = Rig()
        rig.mainStart()
        rig.pipeline.startFishing("START FISHING", rig.nowNs)
        rig.steps(90, withRod = false) // cena de jogo (água/partículas), sem o botão da vara

        assertEquals("nenhum gesto sem alvo", emptyList<String>(), rig.gestures())
        assertFalse(rig.pipeline.output.rodConfirmed)
        assertFalse(rig.pipeline.output.castAuthorized)
        assertFalse("o pipeline não pode publicar alvo", rig.pipeline.output.rodV8TargetFound)
        assertTrue(
            "sem alvo, a posição publicada pela V9 tem de ser vazia (nada inventado)",
            rig.pipeline.rodV9Out.targetX.isNaN() && rig.pipeline.rodV9Out.targetY.isNaN(),
        )
        assertTrue(
            "nenhum estado de ciclo real foi iniciado (estado=${rig.pipeline.output.state})",
            rig.pipeline.output.state !in setOf(
                FishingState.CASTING, FishingState.PRESSING_SHAKE,
                FishingState.CONTROLLING_PLAYER_BAR, FishingState.TRACKING_FISH,
            ),
        )
        rig.close()
    }

    @Test fun lowConfidenceNeverProducesInput() {
        // confiança mínima inatingível: o candidato existe, o alvo nunca é confirmado
        val cfg = AppConfig().copy(
            rodDetector = RodDetectorKind.V8,
            rodV8 = AppConfig.RodV8(minimumConfidence = 0.999f),
        ).validate()
        val rig = Rig(cfg = cfg)
        rig.mainStart()
        rig.pipeline.startFishing("START FISHING", rig.nowNs)
        rig.steps(60, withRod = true)

        assertFalse("confiança abaixo do mínimo não confirma", rig.pipeline.output.rodConfirmed)
        assertEquals("nenhum gesto com confiança insuficiente", emptyList<String>(), rig.gestures())
        val out = rig.pipeline.output
        assertEquals("a FSM não pode sair de WAITING_FOR_ROD sem confirmação", FishingState.WAITING_FOR_ROD, out.state)
        assertFalse("nada pode ser enviado ao executor", out.inputIssued)
        // Nota medida nesta suíte: `castAuthorized` reflete só a porteira (macro/foreground/captura/
        // frame/confiança mínima de ação) e pode ser true com um candidato ainda **não confirmado**;
        // quem decide de verdade é o par `rodConfirmed && castAuthorized` na FSM — por isso o estado
        // aqui continua WAITING_FOR_ROD e nenhum gesto sai.
        val diag = "estado=${out.state} motivo=${out.stateReason} rodState=${out.rodState} " +
            "rodDetected=${out.rodDetected} conf=${"%.2f".format(out.rodConfidence)}"
        assertTrue(
            "nenhum estado de ciclo pode ser iniciado sem confirmação ($diag)",
            out.state !in setOf(
                FishingState.CASTING, FishingState.PRESSING_SHAKE, FishingState.SEARCHING_SHAKE,
                FishingState.CONTROLLING_PLAYER_BAR, FishingState.TRACKING_FISH,
            ),
        )
        assertFalse("nada é enviado ao executor", rig.pipeline.output.inputIssued)
        rig.close()
    }

    @Test fun captureFailureNeverProducesInputAndNeverTaps() {
        val rig = Rig()
        rig.mainStart()
        rig.pipeline.startFishing("START FISHING", rig.nowNs)
        rig.steps(25, withRod = true)
        val gesturesBefore = rig.gestures().size
        rig.steps(10, withRod = true, captureHealthy = false)
        assertEquals("captura morta não gera gesto novo", gesturesBefore, rig.gestures().size)
        assertFalse(rig.pipeline.output.castAuthorized)
        rig.close()
    }

    @Test fun robloxNotInForegroundNeverProducesInput() {
        val rig = Rig()
        rig.mainStart()
        rig.pipeline.startFishing("START FISHING", rig.nowNs)
        rig.steps(40, withRod = true, authorized = false)
        assertTrue("nenhum gesto com o Roblox fora da frente", rig.gestures().isEmpty())
        assertFalse(rig.pipeline.output.castAuthorized)
        assertFalse(rig.pipeline.output.inputAuthorized)
        rig.close()
    }

    // ================================================================ 15 — separação detector/input

    @Test fun detectorKeepsPublishingDataOnlyAndTheControllerDecides() {
        val rig = Rig()
        rig.mainStart()
        rig.steps(15, withRod = true)
        assertFalse("o detector não executa nada por si (READY)", rig.pipeline.output.inputIssued)
        assertEquals("no READY o detector fica explicitamente inativo", "INACTIVE", rig.pipeline.output.rodState)
        assertTrue("nenhum gesto chegou ao executor", rig.gestures().isEmpty())
        rig.close()
    }

    // ================================================================ 16/17/18 — ROI móvel e recovery

    @Test fun movingRoiKeepsFollowingTheTargetAndRecoveryStillWorks() {
        val rig = Rig()
        rig.mainStart()
        rig.pipeline.startFishing("START FISHING", rig.nowNs)
        rig.steps(40, withRod = true)
        assertEquals("pré-condição: rastreando", FishingState.CASTING, rig.pipeline.output.state)
        val roiWhileTracking = rig.pipeline.output.rodRoiNorm.copyOf()
        assertTrue("a ROI móvel foi publicada", roiWhileTracking[2] > roiWhileTracking[0])
        assertTrue("e cabe na tela", roiWhileTracking.all { it in 0f..1f })

        // o botão some da cena: a recuperação continua existindo e nada de posição inventada
        rig.steps(70, withRod = false)
        assertTrue(
            "a escada de recuperação/estado de perda continua funcionando (estado=${rig.pipeline.output.rodState}, " +
                "etapa=${rig.pipeline.output.rodV8RecoveryStage})",
            rig.pipeline.output.rodV8Recovering || rig.pipeline.output.rodV8RecoveryStage > 0 ||
                rig.pipeline.output.rodState == "TARGET_LOST" || rig.pipeline.output.rodState == "RECOVERING",
        )
        assertFalse("sem alvo não há coordenada", rig.pipeline.output.rodV8TargetFound)
        rig.close()
    }

    // ================================================================ 19/20 — um ciclo por vez, repetível

    @Test fun fullCycleCanBeRepeatedManyTimesWithoutLeakingState() {
        val rig = Rig()
        rig.mainStart()
        var casts = 0
        repeat(4) { cycle ->
            assertTrue("ciclo $cycle não ativou", rig.pipeline.startFishing("START FISHING", rig.nowNs))
            assertEquals(AutomationState.FISHING_ACTIVE, rig.pipeline.automationState)
            rig.steps(35, withRod = true)
            val now = rig.castsStarted()
            assertTrue("ciclo $cycle não executou gesto", now > casts)
            casts = now
            assertTrue("ciclo $cycle não parou", rig.pipeline.stopFishing("STOP", rig.nowNs))
            rig.steps(2, withRod = true)
            assertEquals(FishingState.IDLE, rig.pipeline.output.state)
            assertEquals(AutomationState.APP_READY, rig.pipeline.automationState)
        }
        assertEquals(
            "cada ciclo publica exatamente 3 transições (READY→ACTIVE→STOPPING→READY) e o " +
                "START principal publica 1",
            1 + 4 * 3,
            rig.transitions().size,
        )
        assertEquals(
            "uma ativação por ciclo, sem duplicatas",
            4,
            rig.transitions().count { it == "APP_READY->FISHING_ACTIVE" },
        )
        assertEquals(4, rig.transitions().count { it == "FISHING_ACTIVE->FISHING_STOPPING" })
        assertEquals(4, rig.transitions().count { it == "FISHING_STOPPING->APP_READY" })
        assertEquals(1, rig.transitions().count { it == "APP_IDLE->APP_READY" })
        rig.close()
    }

    // ================================================================ §7/§17 — honestidade da V9

    /**
     * **Mede, não presume.** Na MESMA cena em que a V8 confirma o botão, a V9 (detector visual
     * atual, `rodButtonV9`) hoje **não** encontra alvo. Este teste exige dela só o comportamento
     * honesto: sem alvo ⇒ sem coordenada, sem confirmação, sem gesto. A validação visual do botão
     * real do Fisch continua pendente (spec §7/§17 — frames reais via `RodFrameLab`).
     */
    @Test fun v9IsHonestOnTheSceneTheV8Confirms() {
        val cfg = AppConfig().copy(rodDetector = RodDetectorKind.V9).validate()
        val exec = RecordingExecutor()
        val pipeline = VisionPipeline(cfg = cfg, executor = exec, log = ThrottledLog(NoopSink))
        pipeline.setInfrastructureReady(true, "captura RUNNING", 0L)
        pipeline.startFishing("START FISHING", 0L)
        var now = 1_000_000_000L
        repeat(60) { i ->
            val f = VisionFrame.allocate(W, H)
            RodSceneFixture.draw(f, RodSceneFixture.Rod(ROD_X, ROD_Y))
            f.resetFor(now, i.toLong())
            f.ensureGray()
            pipeline.onFrame(
                f,
                PipelineInput(
                    frameTimestampNs = now,
                    currentTimeNs = now,
                    captureHealthy = true,
                    robloxDetected = true,
                    inputAuthorized = true,
                    macroEnabled = pipeline.armed,
                    realInputEnabled = true,
                ),
            )
            now += 33_000_000L
        }
        val v9 = pipeline.rodV9Out
        assertFalse("coordenada publicada sem alvo (targetX=${v9.targetX})", v9.targetX.isFinite())
        assertFalse("coordenada publicada sem alvo (targetY=${v9.targetY})", v9.targetY.isFinite())
        assertFalse("nenhuma confirmação sem evidência suficiente", pipeline.output.rodConfirmed)
        assertEquals(
            "nenhum gesto sai do caminho V9 sem alvo confirmado",
            emptyList<String>(),
            exec.calls.filter { it == "tap" || it == "holdStart" || it == "holdExtend" },
        )
        pipeline.close()
    }

    @Test fun v9DetectionDisabledIsHonestAndNeverCasts() {
        val cfg = AppConfig().copy(
            rodDetector = RodDetectorKind.V9,
            rodButtonV9 = AppConfig.RodButtonV9(rodButtonDetectionEnabled = false),
        ).validate()
        val exec = RecordingExecutor()
        val pipeline = VisionPipeline(cfg = cfg, executor = exec, log = ThrottledLog(NoopSink))
        pipeline.setInfrastructureReady(true, "captura RUNNING", 0L)
        pipeline.startFishing("START FISHING", 0L)
        var now = 1_000_000_000L
        repeat(40) { i ->
            val f = VisionFrame.allocate(W, H)
            RodSceneFixture.draw(f, RodSceneFixture.Rod(ROD_X, ROD_Y))
            f.resetFor(now, i.toLong())
            f.ensureGray()
            pipeline.onFrame(
                f,
                PipelineInput(
                    frameTimestampNs = now,
                    currentTimeNs = now,
                    captureHealthy = true,
                    robloxDetected = true,
                    inputAuthorized = true,
                    macroEnabled = pipeline.armed,
                    realInputEnabled = true,
                ),
            )
            now += 33_000_000L
        }
        assertFalse("detecção desligada não publica alvo", pipeline.output.rodV8TargetFound)
        assertFalse(pipeline.output.rodConfirmed)
        assertEquals(FishingState.WAITING_FOR_ROD, pipeline.output.state)
        assertTrue(
            "detecção desligada nunca gera input",
            exec.calls.none { it == "tap" || it == "holdStart" || it == "holdExtend" },
        )
        pipeline.close()
    }
}
