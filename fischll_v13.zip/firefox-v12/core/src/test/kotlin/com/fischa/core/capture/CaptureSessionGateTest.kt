package com.fischa.core.capture

import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CaptureSessionGateTest {
    @Test
    fun stopInvalidatesQueuedCallbacksAndNewSessionGetsNewIdentity() {
        val gate = CaptureSessionGate()
        val first = gate.openSession()
        assertTrue(gate.accepts(first))

        gate.invalidate()
        assertFalse("queued callback from the stopped session must be rejected", gate.accepts(first))

        val second = gate.openSession()
        assertNotEquals(first, second)
        assertFalse("old session cannot publish into a new session", gate.accepts(first))
        assertTrue(gate.accepts(second))
    }
}
