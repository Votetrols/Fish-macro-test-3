package com.fischa.core.capture

import com.fischa.core.config.AppConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProcessingResolutionTest {
    @Test
    fun reducedProfileIsInternalAndRestoresNormalProfile() {
        val controller = ProcessingResolutionController(maxProcessingWidth = 640)
        val normal = controller.configure(sourceWidth = 1600, sourceHeight = 720, densityDpi = 280)
        val reduced = controller.activateReduced()

        assertEquals(ProcessingResolutionMode.NORMAL, normal.mode)
        assertEquals(ProcessingResolutionMode.REDUCED, reduced.mode)
        assertEquals(640, reduced.width)
        assertEquals(288, reduced.height)
        assertEquals(1600, reduced.sourceWidth)
        assertEquals(720, reduced.sourceHeight)
        assertNotEquals("The temporary profile must not be confused with global display geometry", normal.width, reduced.width)

        val restored = controller.restoreNormal()
        assertEquals(ProcessingResolutionMode.NORMAL, restored.mode)
        assertEquals(1600, restored.width)
        assertEquals(720, restored.height)
        assertTrue("restore only changes the internal profile", restored.sourceWidth == 1600 && restored.sourceHeight == 720)
    }

    @Test
    fun manualRoiMustStayInsideNormalizedDisplay() {
        val valid = AppConfig().withOverrides(
            mapOf(
                "rodButtonV9.manualRoiEnabled" to "true",
                "rodButtonV9.initialRoiX" to "0.60",
                "rodButtonV9.initialRoiY" to "0.40",
                "rodButtonV9.roiWidth" to "0.30",
                "rodButtonV9.roiHeight" to "0.40",
            ),
        ).validate()
        assertTrue(valid.rodButtonV9.manualRoiEnabled)

        val invalid = AppConfig().withOverrides(
            mapOf(
                "rodButtonV9.manualRoiEnabled" to "true",
                "rodButtonV9.initialRoiX" to "0.80",
                "rodButtonV9.roiWidth" to "0.40",
            ),
        )
        val error = runCatching { invalid.validate() }.exceptionOrNull()
        assertTrue("x + width > 1 must fail closed", error is IllegalArgumentException)
    }
}
