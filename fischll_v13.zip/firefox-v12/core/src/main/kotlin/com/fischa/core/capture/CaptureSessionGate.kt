package com.fischa.core.capture

import java.util.concurrent.atomic.AtomicLong

/**
 * Session-generation gate for asynchronous capture callbacks.
 *
 * A callback may already be queued when STOP closes ImageReader/VirtualDisplay. The callback must
 * prove both that its token is the currently active generation and that the session is open before
 * it can acquire or publish anything. Opening a later session produces a different token, so an old
 * callback can never control the new buffer.
 */
class CaptureSessionGate {
    private val generation = AtomicLong(0L)
    @Volatile private var open = false

    fun openSession(): Long {
        val token = generation.incrementAndGet()
        open = true
        return token
    }

    fun invalidate() {
        open = false
        generation.incrementAndGet()
    }

    fun accepts(token: Long): Boolean = open && token != 0L && generation.get() == token

    fun currentGeneration(): Long = generation.get()
}
