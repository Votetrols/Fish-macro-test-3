package com.fischa.core.state

/**
 * **Estado do aplicativo/automação (V9.1)** — deliberadamente separado do [FishingState]
 * (que descreve *onde estamos no ciclo de pesca*).
 *
 * O usuário pediu duas decisões distintas e independentes:
 *
 *  1. **START principal do app** → liga infraestrutura (permissões → serviços → captura) e deixa o
 *     sistema **pronto**, sem pescar. Estado: [APP_READY].
 *  2. **START FISHING** (botão flutuante) → começa a automação. Estado: [FISHING_ACTIVE].
 *     **STOP** → [FISHING_STOPPING] → [APP_READY] (a infraestrutura permanece preparada).
 *
 * ```
 * APP_IDLE ──START principal(infra pronta)──▸ APP_READY ──START FISHING──▸ FISHING_ACTIVE
 *    ▴                                          ▴                              │
 *    │                                          │                            STOP
 *    └──────── infra perdida / emergência ──────┴──── STOP COMPLETO ──── FISHING_STOPPING
 * ```
 *
 * Nada aqui usa atrasos arbitrários: cada transição é causada por um evento real do host
 * (serviço iniciado, captura RUNNING, toque do operador, limpeza concluída).
 */
enum class AutomationState {
    /** Infraestrutura desligada (antes do START principal / depois do STOP geral). */
    APP_IDLE,

    /** Permissões + serviços + captura preparados. **Nenhuma automação executando.** */
    APP_READY,

    /** O operador mandou pescar: o ciclo de pesca pode executar (respeitando o SafetyGuard). */
    FISHING_ACTIVE,

    /** STOP em andamento: nenhum input novo é permitido enquanto a limpeza acontece. */
    FISHING_STOPPING,
    ;

    /** Rótulo curto usado nos diagnósticos: `AUTOMATION: OFF/READY/ACTIVE/STOPPING`. */
    val label: String
        get() = when (this) {
            APP_IDLE -> "OFF"
            APP_READY -> "READY"
            FISHING_ACTIVE -> "ACTIVE"
            FISHING_STOPPING -> "STOPPING"
        }

    /** Somente neste estado a camada de automação pode executar ações. */
    val isFishing: Boolean get() = this == FISHING_ACTIVE
}

/** Eventos que movem a máquina. Todos vêm de um ator real (UI, botão flutuante, serviço). */
enum class AutomationEvent {
    INFRASTRUCTURE_READY,
    INFRASTRUCTURE_LOST,
    START_FISHING_REQUESTED,
    STOP_REQUESTED,
    STOP_COMPLETED,
    EMERGENCY,
}

/** Registro de uma transição (para log/diagnóstico; imutável). */
class AutomationChange(
    val from: AutomationState,
    val to: AutomationState,
    val event: AutomationEvent,
    val reason: String,
    val timestampNs: Long,
)

/**
 * Máquina de estados da **automação** (não do ciclo de pesca).
 *
 * Regras de segurança implementadas aqui (spec §3/§4/§5/§14):
 *  - `START FISHING` só sai de [AutomationState.APP_READY] (ou de [AutomationState.APP_IDLE], caso
 *    o host não tenha publicado o READY — compatibilidade com os hosts/testes antigos); pedido
 *    repetido **não** cria um segundo ciclo (retorna `null`);
 *  - durante [AutomationState.FISHING_STOPPING] `START FISHING` é **recusado** (o STOP vence);
 *  - `STOP` só sai de [AutomationState.FISHING_ACTIVE] → [AutomationState.FISHING_STOPPING];
 *    repetido é inofensivo;
 *  - a volta para [AutomationState.APP_READY] só acontece quando a limpeza **termina de verdade**
 *    ([completeStop]), nunca por timer;
 *  - perder a infraestrutura (captura/serviço) derruba a automação para [AutomationState.APP_IDLE]
 *    em qualquer estado.
 *
 * A classe é thread-safe para leitura ([state]/[lastReason] são voláteis) e sincroniza as
 * transições, porque o botão flutuante toca na thread principal e o laço de visão roda em outra.
 */
class AutomationStateMachine(private val clockNs: () -> Long = { System.nanoTime() }) {

    @Volatile
    var state: AutomationState = AutomationState.APP_IDLE
        private set

    @Volatile
    var lastReason: String = "init"
        private set

    var enteredAtNs: Long = 0L
        private set

    /** Última transição registrada (para diagnóstico). */
    @Volatile
    var lastChange: AutomationChange? = null
        private set

    private val listeners = ArrayList<(AutomationChange) -> Unit>()

    fun addListener(l: (AutomationChange) -> Unit) { synchronized(listeners) { listeners.add(l) } }
    fun removeListener(l: (AutomationChange) -> Unit) { synchronized(listeners) { listeners.remove(l) } }

    /** Somente em [AutomationState.FISHING_ACTIVE] a automação (input) pode executar. */
    val pumping: Boolean get() = state.isFishing

    val ready: Boolean get() = state == AutomationState.APP_READY

    /** `AUTOMATION: READY` — linha pronta para o overlay/log (spec §13). */
    val debugLine: String get() = "AUTOMATION: ${state.label}"

    private fun move(
        to: AutomationState,
        event: AutomationEvent,
        reason: String,
        nowNs: Long,
    ): AutomationChange? {
        if (state == to) return null
        val from = state
        state = to
        lastReason = reason
        enteredAtNs = nowNs
        val change = AutomationChange(from, to, event, reason, nowNs)
        lastChange = change
        val copy = synchronized(listeners) { ArrayList(listeners) }
        copy.forEach { runCatching { it(change) } }
        return change
    }

    /**
     * Infraestrutura pronta (captura RUNNING, serviços no ar) → [AutomationState.APP_READY].
     * Nunca inicia pesca: só deixa o sistema preparado.
     */
    @Synchronized
    fun setInfrastructureReady(
        ready: Boolean,
        reason: String,
        nowNs: Long = clockNs(),
    ): AutomationChange? {
        if (!ready) {
            return move(AutomationState.APP_IDLE, AutomationEvent.INFRASTRUCTURE_LOST, reason, nowNs)
        }
        if (state != AutomationState.APP_IDLE) return null
        return move(AutomationState.APP_READY, AutomationEvent.INFRASTRUCTURE_READY, reason, nowNs)
    }

    /**
     * Comando explícito do operador (botão flutuante / UI): começar a pescar.
     *
     * @return a transição, ou `null` quando o pedido é ignorado (já pescando, parando, ou idêntico).
     */
    @Synchronized
    fun startFishing(reason: String = "START FISHING", nowNs: Long = clockNs()): AutomationChange? {
        when (state) {
            AutomationState.FISHING_ACTIVE -> return null // nada de dois ciclos paralelos
            AutomationState.FISHING_STOPPING -> return null // STOP em andamento vence
            AutomationState.APP_READY -> Unit
            AutomationState.APP_IDLE ->
                // Compatibilidade: um host que manda START FISHING sem ter publicado o READY
                // (testes antigos, replay) assume a infraestrutura como pronta. Registrado, nunca
                // silencioso — e continua sem ligar nada por conta própria.
                move(
                    AutomationState.APP_READY,
                    AutomationEvent.INFRASTRUCTURE_READY,
                    "$reason (READY assumido pelo host)",
                    nowNs,
                )
        }
        return move(AutomationState.FISHING_ACTIVE, AutomationEvent.START_FISHING_REQUESTED, reason, nowNs)
    }

    /**
     * STOP do operador: entra em [AutomationState.FISHING_STOPPING]. A partir daqui **nenhum**
     * input novo é autorizado (a camada de segurança lê [pumping]).
     */
    @Synchronized
    fun requestStop(reason: String = "STOP", nowNs: Long = clockNs()): AutomationChange? {
        if (state != AutomationState.FISHING_ACTIVE) return null // STOP repetido/fora de hora: no-op
        return move(AutomationState.FISHING_STOPPING, AutomationEvent.STOP_REQUESTED, reason, nowNs)
    }

    /**
     * Limpeza concluída (gestos cancelados, estados transitórios limpos): volta para
     * [AutomationState.APP_READY] — a captura e os serviços **não** são destruídos (spec §4).
     */
    @Synchronized
    fun completeStop(reason: String = "STOP concluído", nowNs: Long = clockNs()): AutomationChange? {
        if (state != AutomationState.FISHING_STOPPING) return null
        return move(AutomationState.APP_READY, AutomationEvent.STOP_COMPLETED, reason, nowNs)
    }

    /** Emergência / encerramento da sessão: tudo volta para [AutomationState.APP_IDLE]. */
    @Synchronized
    fun emergency(reason: String, nowNs: Long = clockNs()): AutomationChange? {
        if (state == AutomationState.APP_IDLE) return null
        return move(AutomationState.APP_IDLE, AutomationEvent.EMERGENCY, reason, nowNs)
    }
}

/**
 * Textos/visibilidade do controle manual (spec §2/§13/§14). Fica no `core` — e não no `app` — para
 * ser testável em JVM pura: o botão do Android só *desenha* o que está decidido aqui.
 */
object AutomationUi {
    const val BUTTON_START = "START FISHING"
    const val BUTTON_STOP = "STOP"
    const val BUTTON_STOPPING = "STOPPING"

    /** Texto do botão flutuante para cada estado (spec §2: `START FISHING` ⇄ `STOP`). */
    fun buttonLabel(state: AutomationState): String = when (state) {
        AutomationState.APP_IDLE -> ""
        AutomationState.APP_READY -> BUTTON_START
        AutomationState.FISHING_ACTIVE -> BUTTON_STOP
        AutomationState.FISHING_STOPPING -> BUTTON_STOPPING
    }

    /** O botão existe enquanto o modo de pesca estiver preparado. */
    fun buttonVisible(state: AutomationState): Boolean = state != AutomationState.APP_IDLE

    /** Durante o STOP já em andamento o botão não aceita um segundo comando. */
    fun buttonEnabled(state: AutomationState): Boolean = state != AutomationState.FISHING_STOPPING

    /** Linha de diagnóstico: `AUTOMATION: OFF|READY|ACTIVE|STOPPING` (spec §13). */
    fun debugLine(state: AutomationState): String = "AUTOMATION: ${state.label}"
}
