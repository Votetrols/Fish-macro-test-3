package com.fischa.core.capture

/**
 * Describes the pixels used by the internal MediaProjection processing stream.
 *
 * This is deliberately not Android's global DisplayMetrics and it never changes the device display,
 * density, DPI, or user settings. NORMAL is the measured physical display geometry; REDUCED is a
 * uniformly scaled VirtualDisplay/ImageReader output used only by the vision pipeline.
 */
enum class ProcessingResolutionMode {
    NORMAL,
    REDUCED,
}

data class ProcessingResolution(
    val mode: ProcessingResolutionMode,
    val width: Int,
    val height: Int,
    val densityDpi: Int,
    val sourceWidth: Int,
    val sourceHeight: Int,
) {
    init {
        require(width > 0 && height > 0) { "processing resolution must be positive" }
        require(sourceWidth > 0 && sourceHeight > 0) { "source display resolution must be positive" }
        require(densityDpi > 0) { "densityDpi must be positive" }
    }

    val scaleX: Float get() = width.toFloat() / sourceWidth
    val scaleY: Float get() = height.toFloat() / sourceHeight

    fun describe(): String =
        "${mode.name} ${width}x$height dpi=$densityDpi source=${sourceWidth}x$sourceHeight " +
            "scale=${"%.3f".format(scaleX)}/${"%.3f".format(scaleY)}"
}

/**
 * Small, deterministic policy object used by Android capture and by JVM tests.
 * Calling [activateReduced] selects only the capture output size. Calling [restoreNormal] discards
 * the reduced profile; it does not and cannot mutate the physical display.
 */
class ProcessingResolutionController(
    private val maxProcessingWidth: Int,
) {
    init { require(maxProcessingWidth > 0) { "maxProcessingWidth must be positive" } }

    var mode: ProcessingResolutionMode = ProcessingResolutionMode.NORMAL
        private set

    private var normal: ProcessingResolution? = null
    private var active: ProcessingResolution? = null

    fun configure(sourceWidth: Int, sourceHeight: Int, densityDpi: Int): ProcessingResolution {
        val profile = ProcessingResolution(
            mode = ProcessingResolutionMode.NORMAL,
            width = sourceWidth,
            height = sourceHeight,
            densityDpi = densityDpi.coerceAtLeast(1),
            sourceWidth = sourceWidth,
            sourceHeight = sourceHeight,
        )
        normal = profile
        active = profile
        mode = ProcessingResolutionMode.NORMAL
        return profile
    }

    fun activateReduced(): ProcessingResolution {
        val source = normal ?: error("configure() must be called before activateReduced()")
        val size = com.fischa.core.common.CoordinateMapper.captureSizeFor(
            source.width,
            source.height,
            maxProcessingWidth,
        )
        val profile = ProcessingResolution(
            mode = ProcessingResolutionMode.REDUCED,
            width = size[0],
            height = size[1],
            densityDpi = source.densityDpi,
            sourceWidth = source.width,
            sourceHeight = source.height,
        )
        active = profile
        mode = ProcessingResolutionMode.REDUCED
        return profile
    }

    fun current(): ProcessingResolution = active ?: error("configure() must be called first")

    fun normalProfile(): ProcessingResolution = normal ?: error("configure() must be called first")

    /** Discards the reduced processing profile and returns the measured normal display profile. */
    fun restoreNormal(): ProcessingResolution {
        val profile = normal ?: error("configure() must be called before restoreNormal()")
        active = profile
        mode = ProcessingResolutionMode.NORMAL
        return profile
    }

    /** Clears references at the end of a capture session; the phone display is untouched. */
    fun clear() {
        active = null
        normal = null
        mode = ProcessingResolutionMode.NORMAL
    }
}
