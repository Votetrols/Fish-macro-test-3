# Firefox V12 — relatório técnico da revisão

Data: 2026-10-08 (ambiente local de build)
Base: `Firefox_v11.1.zip` / cópia de trabalho `/home/user/firefox-v12`
Versão Android definida nesta revisão: `versionCode=12`, `versionName=12.0-v12`

## 1. Resultado executivo

A revisão estrutural foi implementada sem trocar package name, nome do projeto ou arquitetura de input.
O principal defeito encontrado no código foi corrigido: o START principal publicava `APP_READY`, mas o
loop continuava executando toda a visão pesada e podia disparar o caminho de diagnóstico Bitmap/PNG.
Agora o caminho `APP_READY`/`FISHING_STOPPING` é inativo e retorna antes de converter pixels para grayscale,
rodar detectores, trackers, FSM de pesca ou input. Em `FISHING_ACTIVE`, a vara continua como sinal de
presença/liveness, enquanto SHAKE, barra, captura e os trackers do minigame são agendados pelo estado
atual da FSM e têm seus resultados limpos ao serem ignorados.

O fluxo ficou:

```text
START principal
  permissões → FGS mediaProjection → MediaProjection → callback → ImageReader → VirtualDisplay → primeiro frame
  → APP_READY / botão START FISHING

START FISHING
  → FISHING_ACTIVE → visão, detectores, decisões e input passam a ser possíveis

STOP
  → FISHING_STOPPING → cancelamento/liberação → APP_READY
  → captura permanece disponível, mas a visão pesada fica desligada
```

## 2. Causa do crash: o que foi provado e o que não foi

### Causa estrutural identificada no código

Nos arquivos `app/src/main/java/com/fischa/app/FischEngineService.kt` e
`core/src/main/kotlin/com/fischa/core/pipeline/VisionPipeline.kt`, o START principal já mudava o
estado lógico para READY, porém o loop iniciado por `prepareFishingSession()` continuava chamando
`VisionPipeline.onFrame()` com o pipeline completo.

A sequência problemática era:

1. `prepareFishingSession()` iniciava `loop(src)` logo depois de a captura ficar RUNNING.
2. `onFrame()` chamava `runDetectors(frame)` independentemente de `AutomationState.APP_READY`.
3. V9/V8/V7, Shake, FishingBar, CatchConfirm, PlayerBar, Fish e Progress eram executados antes de
   qualquer START FISHING.
4. Com `rodButtonV9.saveDiagnosticFrames=true`, eventos do detector podiam chamar
   `RodFrameDumper`, que fazia recorte, criação/desenho de `Bitmap` e compressão PNG no caminho do
   loop.
5. Ao mesmo tempo, callbacks de `ImageReader` pertencentes à sessão antiga podiam estar enfileirados
   enquanto `STOP`/teardown fechava reader, VirtualDisplay e buffer.

Essa é a causa raiz **estrutural** da janela de crash: visão e I/O pesado eram iniciados no comando
errado, com teardown assíncrono sem uma identidade de sessão forte.

### Limite de evidência

Não existe logcat, stack trace de aparelho, emulador, Galaxy A22 ou Roblox disponível neste ambiente.
Portanto não é tecnicamente honesto afirmar uma exceção Java única, como `IllegalStateException` ou
`SecurityException`, como causa física definitiva. O código anterior não preservava uma exceção de
runtime do dispositivo no material recebido. O relatório distingue, portanto:

- **provado por auditoria de código:** trabalho pesado no START principal + proteção insuficiente de
  callbacks durante teardown;
- **não provado:** a classe/mensagem exata da exceção do aparelho original;
- **correção aplicada:** arquitetura que não executa esse trabalho em APP_READY e invalida callbacks
  antigos antes de fechar/recriar recursos.

## 3. Correções estruturais

### 3.1 Vision Pipeline

Arquivo: `core/src/main/kotlin/com/fischa/core/pipeline/VisionPipeline.kt`

- Adicionado caminho `publishAutomationInactive()` antes de `ensureGray()`.
- Em `APP_READY` e `FISHING_STOPPING`, o frame não é convertido nem analisado.
- Snapshots, ROI, confiança, candidatos, progresso, trackers e ação são limpos.
- O output publica `rodState=INACTIVE`, `FishingState.IDLE` e `AUTOMATION_NOT_ACTIVE`.
- STOP é reavaliado depois da etapa de detectores, antes da FSM, antes dos controladores e no limite
  de dispatch.
- Um `lifecycleLock` serializa `onFrame()` com START/STOP/disarm/reset; o gate de automação é
  desligado antes de aguardar um frame em andamento.
- O callback `authorizeSegment` revalida automação, foreground, confiança e emergência antes de
  cada segmento de gesto.
- `FishingStateMachine.disarm()` garante que CASTING/minigame não sobrevive para a próxima sessão.

### 3.2 Identidade e quiescência de callbacks

Arquivos:

- `core/src/main/kotlin/com/fischa/core/capture/CaptureSessionGate.kt`
- `app/src/main/java/com/fischa/app/ScreenCaptureSource.kt`

- Toda sessão de captura recebe token monotônico.
- `close()` e recriação do ImageReader invalidam o token antes da liberação.
- Callback enfileirado verifica token e identidade do ImageReader antes de adquirir a imagem.
- Há uma segunda verificação depois de adquirir a imagem, antes de tocar no FrameBuffer.
- Toda Image adquirida continua sendo fechada em `finally`.
- Callback de sessão antiga não consegue publicar na sessão nova.

### 3.3 Estado e comandos duplicados

Arquivo: `core/src/main/kotlin/com/fischa/core/state/AutomationState.kt`

As transições públicas de `AutomationStateMachine` ficaram sincronizadas. START duplicado,
START FISHING durante STOPPING e STOP repetido permanecem idempotentes e não criam loops ou sessões
paralelas.

## 4. Interface e estados

A UI existente foi preservada e atualizada para V12. O status exibe:

- captura, projeção e foreground service separadamente;
- estado da automação: `APP_IDLE`, `APP_READY`, `FISHING_ACTIVE`, `FISHING_STOPPING`;
- estado da FSM de pesca;
- foreground/package/activity e motivo de bloqueio;
- idade do frame, FPS, frames recebidos/processados/dropados/gated;
- resolução interna de processamento e geometria do display;
- rod detector, confiança, ROI e motivo de falha;
- segurança/input/emergency.

O botão flutuante continua pertencendo ao `AccessibilityService`, com uma única instância:

- READY: `START FISHING`;
- ACTIVE: `STOP`;
- STOPPING: `STOPPING` e sem novo START;
- IDLE: controle oculto.

## 5. VARAR: calibração manual

Arquivos:

- `app/src/main/java/com/fischa/app/ManualRodRoiOverlay.kt`
- `app/src/main/java/com/fischa/app/GameAccessibilityService.kt`
- `core/src/main/kotlin/com/fischa/core/config/AppConfig.kt`
- `core/src/main/kotlin/com/fischa/core/vision/RodDetectionV9.kt`

Implementado/verificado:

- ROI persistida em coordenadas normalizadas `x`, `y`, `width`, `height`.
- Editor permite mover o retângulo pelo centro.
- Editor agora permite redimensionar pela alça inferior direita.
- Tamanho mínimo e limites da tela são aplicados no editor.
- Persistência rejeita valores não finitos ou fora do quadrado normalizado.
- `AppConfig.validate()` rejeita `x + width > 1` ou `y + height > 1` quando o modo manual está ativo.
- No modo manual, o V9 usa a janela base salva e não executa movimento automático nem expansão da
  escada de recuperação.
- A calibração é bloqueada durante `FISHING_ACTIVE`/`FISHING_STOPPING`.

## 6. Pixels/resolução

Arquivo: `core/src/main/kotlin/com/fischa/core/capture/ProcessingResolution.kt`

O comportamento continua sem alterar resolução global, DPI ou densidade do Android:

- `NORMAL`: display físico medido;
- `REDUCED`: saída interna do VirtualDisplay, escalada uniformemente e limitada por
  `capture.processingWidth` (padrão 640 px).

Para uma tela 1600×720, o perfil reduzido é 640×288. Essa redução é somente da captura usada pelo
pipeline. Não há `wm size`, `wm density`, root, ADB ou escrita em configuração do aparelho.

`ScreenCaptureSource` registra o perfil no status/UI e restaura/descarta o perfil lógico quando a
captura é fechada em STOP total, falha recuperável, onStop do MediaProjection ou shutdown do serviço.

## 7. Testes adicionados/atualizados

Novos testes:

- `core/src/test/kotlin/com/fischa/core/pipeline/StartFishingLifecycleV12Test.kt`
  - START/APP_READY não preenche grayscale e não executa detector;
  - START FISHING habilita visão;
  - STOP volta ao caminho inativo e limpa output.
- `core/src/test/kotlin/com/fischa/core/capture/CaptureSessionGateTest.kt`
  - callback enfileirado da sessão antiga é rejeitado;
  - sessão nova recebe identidade diferente.
- `core/src/test/kotlin/com/fischa/core/capture/ProcessingResolutionTest.kt`
  - perfil reduzido uniforme;
  - restauração do perfil normal;
  - ROI manual inválida rejeitada.

`StartFishingFlowTest` foi atualizado para a decisão V12: STOP/READY preservam a captura, mas não
continuam a visão pesada; só START FISHING reativa detectores.

## 8. Validação executada

Ambiente usado:

- JDK: `/tmp/jdk17`;
- Gradle: wrapper do projeto;
- sem Android SDK disponível.

Resultados:

- `./gradlew :core:compileKotlin --no-daemon`: **PASS**.
- Testes direcionados V12 + START/STOP: **PASS**.
- Teste completo core após o gate de sessão: **242 testes coletados, 237 passados, 5 falhas**.
- As 5 falhas restantes estão em cenários V9 de detector/diagnóstico; a falha
  `stationaryButtonKeepsItsWindowStableAfterConfirmation` foi reproduzida no V11.1 intocado, portanto
  é baseline/preexistente, não regressão desta revisão.
- `:core:selfTest` executou, mas o harness legado apresentou 25 falhas em SafetyGuard/real-input;
  não foi declarado PASS.
- `:app`/APK/lint não puderam ser compilados porque o ambiente retorna `SDK location not found`.
- Nenhum teste físico foi feito: não há aparelho, emulador, logcat ou Roblox disponíveis.

## 9. Pendências reais

1. Instalar/configurar Android SDK e executar `assembleDebug`, lint e testes instrumentados.
2. Instalar em Galaxy A22 real, reproduzir o START original e coletar logcat completo.
3. Validar MediaProjection no Android 13/API 33 e em Android 14/15.
4. Corrigir ou reavaliar os cinco testes V9 preexistentes de estabilidade, resolução, aspect ratio,
   diagnóstico e recovery.
5. Validar ROI manual sobre o botão VARAR real e medir FPS/CPU/RAM com diagnóstico desligado e ligado.
6. Validar Roblox e input real somente com autorização explícita e usando o SafetyGuard; essa etapa
   não foi simulada como teste físico.

## 10. Conclusão

A correção de maior risco — retirar visão pesada do START principal e colocar uma barreira de sessão
no callback de captura — foi implementada e coberta por testes JVM. A conclusão sobre a causa exata da
exceção de um aparelho continua limitada pela ausência de logcat físico, e essa limitação permanece
explicitamente registrada em vez de ser mascarada por uma afirmação não verificável.
