# Firefox V12 — auditoria inicial e decisões técnicas

Data da auditoria: 2026-10-07/08 (ambiente de build). Base analisada: `Firefox_v11.1.zip`, commit `8e27f4b7c0308e6ebdd3ef060bb4c7dc4f2beab9`.

## Escopo analisado antes das alterações

- `FischEngineService`, `ScreenCaptureSource`, `MainActivity`, `GameAccessibilityService`, overlays e input;
- `VisionPipeline`, `FishingStateMachine`, `AutomationStateMachine`, `FrameBuffer`, `CoordinateMapper`;
- detectores V7/V8/V9, captura de diagnósticos, configuração e persistência;
- Manifest/Gradle, testes JVM, relatórios das versões V6–V9.1 e fluxo MediaProjection;
- documentação oficial do Android sobre MediaProjection, ImageReader, VirtualDisplay, WindowMetrics e foreground services.

## Achados principais

### A. Causa estrutural do crash após START sem START FISHING

O fluxo de START já separava o estado lógico, mas não separava o trabalho físico:

1. `FischEngineService.prepareFishingSession()` marcava a infraestrutura como pronta e, imediatamente, iniciava `loop(src)` (`FischEngineService.kt`, região das linhas 889–960 da base).
2. A cada frame, `VisionPipeline.onFrame()` chamava `runDetectors(frame)` sem considerar `AutomationState.APP_READY`.
3. `runDetectors()` executava o detector de vara V9, Shake, FishingBar e CatchConfirm; em seguida o pipeline ainda executava PlayerBar, Fish e Progress. Ou seja, START sem START FISHING fazia visão pesada continuamente.
4. A configuração base mantinha `rodButtonV9.saveDiagnosticFrames=true`; quando o detector emitia eventos, `RodFrameDumper` fazia cópia de ROI, criava Bitmaps, escalava, desenhava e comprimía PNG de forma síncrona na thread do loop.
5. Paralelamente, a captura produzia frames no `HandlerThread` e o encerramento podia fechar `ImageReader`/`FrameBuffer` enquanto callbacks ainda estavam em andamento. A base tinha proteção parcial, mas não tinha um token de sessão nem uma barreira de quiescência do callback.
6. O pipeline também era acessado pelo loop de frames e pelo comando STOP/MediaProjection callback sem uma serialização única de estado.

A hipótese operacional mais forte para as falhas contínuas é a combinação de visão pesada + I/O/Bitmap de diagnóstico antes da ativação da pesca, agravada pela concorrência entre callbacks de captura e teardown. O código da base não preservava um stack trace de um aparelho, portanto não é tecnicamente correto afirmar uma exceção Java única sem logcat do dispositivo. A V12 torna esse cenário impossível por arquitetura: APP_READY não executa detectores, o dump de diagnóstico é opt-in e callbacks antigos são invalidados/quiescidos.

### B. Lifecycle e concorrência

- `ImageReader.OnImageAvailableListener` rodava em `HandlerThread`, enquanto `close()` podia ocorrer na Main/engine thread.
- `shutdownCapture()` liberava a fonte antes de aguardar completamente a thread do capture handler.
- Um frame já adquirido podia chegar ao pipeline depois de STOP; não havia geração de sessão para rejeitá-lo.
- `VisionPipeline` podia ser mutado por `onFrame()` e por START/STOP em threads diferentes.
- STOP já cancelava gestos, mas a prioridade não era publicada antes da disputa pelo método do pipeline.

### C. Calibração VARAR

A base já persistia ROI normalizada e o detector V9 respeitava `manualRoiEnabled`, mas o overlay permitia apenas mover o retângulo; não havia alças de redimensionamento. Também faltava validação de que `left + width` e `top + height` permaneciam dentro de 1. A V12 adiciona alças, limites, tamanho mínimo e validação persistente.

### D. Resolução/pixels

A base já usava `CoordinateMapper.captureSizeFor()` e criava o `VirtualDisplay` diretamente em 640 px de largura. Isso reduz a resolução **da saída da MediaProjection**, não a resolução global do aparelho. Não havia alteração de `DisplayMetrics`, DPI do sistema, `wm size`, root ou ADB. A V12 formaliza essa escolha num controlador de perfil de processamento e deixa explícito que o modo NORMAL é o display físico; REDUCED é somente a saída interna da captura. Ao encerrar a captura, o perfil reduzido é descartado e nenhum estado global do telefone é alterado.

## Pesquisa oficial aplicada

1. **MediaProjectionManager / MediaProjection**: o foreground service com tipo `mediaProjection` deve estar ativo antes de `getMediaProjection()`, o callback deve ser registrado antes de `createVirtualDisplay()`, e `onStop()` precisa liberar VirtualDisplay/Surface. Cada sessão de captura usa consentimento e um único `createVirtualDisplay()`.
2. **ImageReader**: `acquireLatestImage()` é apropriado para processamento em tempo real, mas toda `Image` adquirida precisa ser fechada; `maxImages` deve ser o menor valor compatível para evitar backpressure/memória.
3. **VirtualDisplay/MediaProjection**: `width`/`height` definem a saída do display virtual. Eles podem ser menores que o display físico para processamento/casting; isso não altera a resolução do telefone. Mudanças de tamanho durante uma sessão exigem `VirtualDisplay.resize()` e atualização da Surface, portanto a V12 não faz reconfiguração mid-session desnecessária.
4. **WindowMetrics**: Android 11+ recomenda WindowMetrics e `Configuration.densityDpi`; APIs de display real antigas não devem ser usadas para posicionar UI. A leitura da geometria foi isolada e usa contexto de janela para a área máxima da captura.
5. **Foreground service**: Manifest, permissão `FOREGROUND_SERVICE_MEDIA_PROJECTION` e runtime type `FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION` permanecem alinhados ao Android 14+.

Referências consultadas:

- https://developer.android.com/reference/android/media/projection/MediaProjectionManager
- https://developer.android.com/reference/android/media/projection/MediaProjection
- https://developer.android.com/media/grow/media-projection
- https://developer.android.com/reference/android/media/ImageReader
- https://developer.android.com/reference/android/hardware/display/VirtualDisplay
- https://developer.android.com/about/versions/14/changes/fgs-types-required
- https://developer.android.com/about/versions/12/behavior-changes-all

## Plano de implementação

1. Bloquear visão pesada em APP_READY e serializar/invalidatear sessões.
2. Tornar captura e ImageReader quiescíveis, com `Image` sempre fechado.
3. Validar estado, geração, frames e input antes de ações.
4. Otimizar detectores por estado.
5. Completar calibração manual e persistência normalizada.
6. Formalizar o perfil de pixels reduzidos sem tocar na configuração global do Android.
7. Reorganizar UI e atualizar testes/documentação.
8. Executar testes JVM, self-test, lint/build e auditoria final; declarar limitações de teste físico.

## Implementação V12 concluída nesta etapa

### Separação START / START FISHING / STOP

- `VisionPipeline.onFrame()` atualiza os sinais de segurança e, quando a automação não está em `FISHING_ACTIVE`, retorna por um caminho O(1) antes de `ensureGray()`, `runDetectors()`, tracking, Bitmap/PNG diagnóstico e input.
- O caminho inativo limpa snapshots, ROI/alvos/confirmações e publica `rodState=INACTIVE`, `FishingState.IDLE` e `DenyReason.AUTOMATION_NOT_ACTIVE`.
- Em sessão ativa, a vara permanece contínua por ser o sinal de presença/liveness; SHAKE, barra, captura e os detectores/trackers de minigame são agendados conforme o estado da FSM e resetados quando ignorados, sem evidência velha.
- `START FISHING` reabre uma sessão limpa; `STOP` faz `FishingStateMachine.disarm()`, cancela/libera gestos e a próxima sessão não herda CASTING, confirmações ou trackers.
- Há novas rechecagens de `automation.pumping` após detectores, após a FSM e no limite final de dispatch. O callback de autorização de cada segmento também revalida STOP/foreground.
- Um `lifecycleLock` serializa `onFrame()` contra START/STOP/disarm/reset; o gate de automação é publicado antes de esperar um frame em andamento, evitando input novo enquanto a limpeza termina.
- Transições públicas da `AutomationStateMachine` agora são sincronizadas para START duplicado, STOP duplicado e START durante STOPPING.

### Capture callback/session gate

- `CaptureSessionGate` em `core/capture` fornece identidade monotônica de sessão; callback de `ImageReader` só pode adquirir/publicar se o token ainda for o ativo.
- `ScreenCaptureSource` invalida o token antes de fechar/recriar reader, verifica a identidade do reader antes e depois de adquirir a `Image`, fecha a `Image` em `finally` e invalida novamente no `close()`.
- O callback não pode publicar em buffer de uma sessão nova depois de STOP ou de uma substituição de `ImageReader`.

### VARAR manual

- `ManualRodRoiOverlay` agora permite mover e redimensionar pela alça inferior direita, com tamanho mínimo e persistência apenas quando o retângulo normalizado é finito e está dentro de `[0,1]`.
- `AppConfig.validate()` aplica a validação de limites de `left + width`/`top + height` quando `manualRoiEnabled=true`.
- O caminho V9 manual já mantinha a janela base fixa; V12 preserva essa regra: não move, não amplia e não cai na escada de recuperação automática em modo manual.

### Perfil de pixels

- `ProcessingResolutionController` formaliza NORMAL (display medido) e REDUCED (saída interna uniforme, limitada por `processingWidth`).
- `ScreenCaptureSource` registra o perfil efetivo e restaura/descarta o perfil no fechamento; não há escrita em resolução, DPI, `DisplayMetrics`, `wm`, root ou ADB do aparelho.
- O status/UI exibe o perfil interno e informa que o display global permanece inalterado.

## Validação executada após as alterações

- `:core:compileKotlin`: **PASS** com JDK 17.
- Testes direcionados V12 + fluxo START/STOP legado atualizado: **PASS** (`StartFishingFlowTest`, `StartFishingLifecycleV12Test`, `ProcessingResolutionTest`, `CaptureSessionGateTest`).
- Execução completa `:core:test` com heap/metaspace limitados: 242 testes coletados; **237 passaram e 5 falharam** em cenários V9 já falhos no baseline intocado (confirmado executando o mesmo teste no V11.1: `V9RodButtonDetectionTest.stationaryButtonKeepsItsWindowStableAfterConfirmation`). As falhas restantes são: diagnóstico `NO_CANDIDATE`, estabilidade do alvo parado, resolução 1280×720 e dois cenários de recuperação/aspect ratio.
- `:core:selfTest`: executa, mas o harness legado ainda reporta 25 falhas de SafetyGuard/real-input; não foi tratado como PASS. A suíte JUnit direcionada é a fonte de validação usada para as mudanças V12.
- Build/app Android, lint, APK, instalação e teste físico ainda não foram validados porque este ambiente não possui Android SDK (`SDK location not found`). Não há logcat, emulador, dispositivo Galaxy A22 ou Roblox disponíveis; portanto a exceção única do crash original continua **não provada por stack trace físico**.
