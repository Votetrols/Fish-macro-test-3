package com.fischa.app

import android.content.Context
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.SystemClock
import com.fischa.app.ui.DiagnosticsLog
import com.fischa.core.capture.CaptureAttempt
import com.fischa.core.capture.CaptureSessionGate
import com.fischa.core.capture.CaptureStage
import com.fischa.core.capture.FrameAge
import com.fischa.core.capture.FrameBuffer
import com.fischa.core.capture.FrameCounters
import com.fischa.core.capture.FrameStatsTracker
import com.fischa.core.capture.ProbeStep
import com.fischa.core.capture.ProcessingResolution
import com.fischa.core.capture.ProcessingResolutionController
import com.fischa.core.common.CoordinateMapper
import com.fischa.core.config.AppConfig
import com.fischa.core.vision.VisionFrame
import java.nio.ByteOrder

/**
 * MediaProjection capture tuned for the Galaxy A22 (V5 spec §4) with V6 per-stage diagnostics
 * (V6 spec §1/§7).
 *
 * V5 behaviour preserved on purpose:
 *  - The VirtualDisplay is created directly at the *processing* size (e.g. 640×288 for the A22's
 *    1600×720 landscape), so SurfaceFlinger does the downscale in hardware.
 *  - RGBA_8888 rows are bulk-copied through an IntBuffer into reusable [VisionFrame] slots.
 *  - `acquireLatestImage()` + the bounded FrameBuffer (latest-only) discard obsolete frames, and a
 *    time gate drops images that arrive faster than `capture.targetFps`.
 *  - Every Image is closed in `finally`; failure paths cancel the slot instead of leaking it.
 *
 * V6 additions:
 *  - `createImageReader()` / `createVirtualDisplay()` are separate, individually diagnosable steps
 *    (V6 spec §7 + §18 probe). Each records its exact outcome and the original exception in the
 *    [CaptureAttempt], so a failure can never again be reported as a generic
 *    "MediaProjection indisponível".
 *  - The Surface handed to the VirtualDisplay is verified to belong to *this* ImageReader.
 *  - ImageReader dimensions/format and VirtualDisplay size/density/flags are recorded verbatim.
 *  - First-frame latency and received/processed/dropped counters are exposed (spec §14).
 */
class ScreenCaptureSource(
    private val context: Context,
    private val projection: MediaProjection,
    private val captureHandler: Handler,
    private val cfg: AppConfig.Capture,
    private val onCaptureFailure: (String) -> Unit = {},
    /** V6 §1: called with the unmasked failure so the service can log class/message/stack. */
    private val onCaptureFailureDetailed: (CaptureStage, Throwable, String) -> Unit = { _, _, _ -> },
) : AutoCloseable {

    @Volatile var captureHealthy: Boolean = false
        private set
    @Volatile var lastFrameTimestampNs: Long = 0L
        private set
    @Volatile var droppedFrames: Long = 0L
        private set
    /** Images skipped by the FPS gate (never copied); diagnostic only. */
    @Volatile var gatedFrames: Long = 0L
        private set
    @Volatile var producedFrames: Long = 0L
        private set
    /** Images handed over by the ImageReader (including the ones discarded by the gates). */
    @Volatile var receivedFrames: Long = 0L
        private set
    @Volatile var firstFrameReceived: Boolean = false
        private set
    @Volatile var firstFrameLatencyMs: Long = -1L
        private set

    @Volatile var readerWidth: Int = 0
        private set
    @Volatile var readerHeight: Int = 0
        private set
    @Volatile var readerFormat: Int = 0
        private set
    @Volatile var readerMaxImages: Int = 0
        private set

    val hasReader: Boolean get() = reader != null
    val hasDisplay: Boolean get() = display != null

    private val frameStats = FrameStatsTracker()
    /** Internal capture/output profile; it never mutates Android's global display metrics. */
    private val processingResolutionController = ProcessingResolutionController(cfg.processingWidth)

    lateinit var geometry: ScreenGeometry
        private set
    lateinit var processingResolution: ProcessingResolution
        private set
    lateinit var mapper: CoordinateMapper
        private set

    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var frameBuffer: FrameBuffer? = null
    private var rowInts = IntArray(0)
    private var captureWidth = 0
    private var captureHeight = 0
    private var serial = 0L
    private var lastPublishedUptimeNs = 0L
    private var startedUptimeMs = 0L
    /** Callback/session gate: queued ImageReader callbacks cannot publish after close or replacement. */
    private val sessionGate = CaptureSessionGate()
    @Volatile private var minIntervalNs = 0L
    @Volatile var effectiveFps: Int = 0
        private set
    @Volatile private var strideWarned = false
    /** V5 §13: transient ImageReader hiccups are counted; only a persistent failure is terminal. */
    private var consecutiveCopyFailures = 0
    private var copyFailureReported = false

    val frameWidth: Int get() = captureWidth
    val frameHeight: Int get() = captureHeight

    fun frameCounters(): FrameCounters =
        FrameCounters(receivedFrames, producedFrames, droppedFrames, gatedFrames)

    fun frameAgeMs(nowNs: Long = System.nanoTime()): Long = frameStats.frameAgeMs(nowNs)

    /** True once at least one frame has been published to the frame buffer. */
    val geometryReady: Boolean get() = ::geometry.isInitialized

    /** Marks the session healthy after the caller verified reader+display (service start path). */
    fun markHealthy() {
        captureHealthy = true
    }

    /**
     * Full start sequence: geometry → ImageReader → VirtualDisplay. Returns false and fills
     * [attempt] with the exact stage + exception on failure (V6 spec §3/§7).
     */
    fun begin(attempt: CaptureAttempt? = null): Boolean {
        readGeometry()
        if (!createImageReader(attempt)) return false
        if (!createVirtualDisplay(attempt)) return false
        captureHealthy = true
        return true
    }

    /** Reads display geometry, computes the processing size and publishes the coordinate mapper. */
    private fun readGeometry() {
        geometry = ScreenGeometry.read(context)
        processingResolutionController.configure(
            geometry.width,
            geometry.height,
            geometry.densityDpi,
        )
        // Capture uses a reduced internal VirtualDisplay output, not a global display change.
        processingResolution = processingResolutionController.activateReduced()
        captureWidth = processingResolution.width
        captureHeight = processingResolution.height
        mapper = CoordinateMapper(captureWidth, captureHeight, geometry.width, geometry.height)
        setRateLimit(cfg.targetFps)
        DiagnosticsLog.event(TAG, "[CAPTURE] processing profile ${processingResolution.describe()} (global display unchanged)")
    }

    /**
     * V6 spec §7 — ImageReader creation and validation, isolated so the diagnostic probe can run it
     * on its own and so a failure records `imageReaderCreated=false` plus the real exception.
     */
    fun createImageReader(attempt: CaptureAttempt? = null): Boolean {
        attempt?.markStage(CaptureStage.IMAGE_READER)
        if (!::geometry.isInitialized) readGeometry()
        if (captureWidth <= 0 || captureHeight <= 0) {
            val e = IllegalStateException("invalid capture size ${captureWidth}x$captureHeight")
            attempt?.imageReaderCreated = false
            attempt?.capture(e, "capture size computed from display geometry")
            DiagnosticsLog.failure(TAG, "invalid capture size ${captureWidth}x$captureHeight", e)
            return false
        }
        // Invalidate first: a callback already queued on the old Handler must become a no-op.
        sessionGate.invalidate()
        frameBuffer?.close()
        frameBuffer = FrameBuffer(captureWidth, captureHeight, cfg.bufferSlots.coerceIn(2, 8))
        rowInts = IntArray(captureWidth)
        runCatching { reader?.setOnImageAvailableListener(null, null) }
        runCatching { reader?.close() }
        reader = null

        val imageReader = try {
            ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, MAX_IMAGES)
        } catch (t: Throwable) {
            attempt?.imageReaderCreated = false
            attempt?.capture(t, "ImageReader.newInstance(${captureWidth}x$captureHeight, RGBA_8888, $MAX_IMAGES)")
            DiagnosticsLog.failure(
                TAG,
                "[IMAGE_READER] newInstance failed ${captureWidth}x$captureHeight RGBA_8888 maxImages=$MAX_IMAGES",
                t,
            )
            return false
        }
        reader = imageReader
        readerWidth = imageReader.width
        readerHeight = imageReader.height
        readerFormat = imageReader.imageFormat
        readerMaxImages = MAX_IMAGES
        startedUptimeMs = SystemClock.elapsedRealtime()
        val generation = sessionGate.openSession()
        imageReader.setOnImageAvailableListener({ source -> copyLatestImage(source, generation) }, captureHandler)
        attempt?.imageReaderCreated = true
        attempt?.imageReaderWidth = imageReader.width
        attempt?.imageReaderHeight = imageReader.height
        attempt?.imageReaderFormat = imageReader.imageFormat
        attempt?.imageReaderMaxImages = MAX_IMAGES
        DiagnosticsLog.event(
            TAG,
            "[IMAGE_READER] created ${imageReader.width}x${imageReader.height} format=${imageReader.imageFormat} " +
                "maxImages=$MAX_IMAGES surfacePresent=${imageReader.surface != null}",
        )
        return true
    }

    /**
     * V6 spec §7 — VirtualDisplay creation bound to *this* ImageReader surface, validating surface
     * ownership and geometry before the session can be declared healthy.
     */
    fun createVirtualDisplay(attempt: CaptureAttempt? = null): Boolean {
        attempt?.markStage(CaptureStage.VIRTUAL_DISPLAY)
        val imageReader = reader
        if (imageReader == null) {
            val e = IllegalStateException("VirtualDisplay requested with no ImageReader")
            attempt?.virtualDisplayCreated = false
            attempt?.capture(e, "ImageReader must exist before the VirtualDisplay")
            DiagnosticsLog.failure(TAG, "[VIRTUAL_DISPLAY] no ImageReader", e)
            return false
        }
        val surface = imageReader.surface
        if (surface == null || !surface.isValid) {
            val e = IllegalStateException("ImageReader surface invalid")
            attempt?.virtualDisplayCreated = false
            attempt?.capture(e, "surface must belong to the ImageReader")
            DiagnosticsLog.failure(TAG, "[VIRTUAL_DISPLAY] ImageReader surface invalid", e)
            return false
        }
        runCatching { display?.release() }
        display = null
        val created = try {
            projection.createVirtualDisplay(
                VIRTUAL_DISPLAY_NAME,
                captureWidth,
                captureHeight,
                if (::geometry.isInitialized) geometry.densityDpi else 0,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                surface,
                null,
                captureHandler,
            )
        } catch (t: Throwable) {
            attempt?.virtualDisplayCreated = false
            attempt?.capture(
                t,
                "createVirtualDisplay(${captureWidth}x$captureHeight, " +
                    "dpi=${if (::geometry.isInitialized) geometry.densityDpi else 0}, flags=AUTO_MIRROR, " +
                    "surface=ImageReader#${System.identityHashCode(imageReader)})",
            )
            DiagnosticsLog.failure(
                TAG,
                "[VIRTUAL_DISPLAY] createVirtualDisplay failed ${captureWidth}x$captureHeight " +
                    "dpi=${if (::geometry.isInitialized) geometry.densityDpi else 0}",
                t,
            )
            return false
        }
        if (created == null) {
            val e = IllegalStateException("createVirtualDisplay returned null")
            attempt?.virtualDisplayCreated = false
            attempt?.capture(e, "MediaProjection.createVirtualDisplay returned null")
            DiagnosticsLog.failure(TAG, "[VIRTUAL_DISPLAY] null", e)
            return false
        }
        display = created
        // spec §7: the surface used by the VirtualDisplay must be the ImageReader's own surface.
        val sameSurface = runCatching { created.surface == surface }.getOrDefault(false)
        // API 35 removed VirtualDisplay.getWidth()/getHeight()/getDensityDpi(): the requested values
        // are the record of truth for the diagnostic (the display was created with exactly these).
        val requestedDensity = if (::geometry.isInitialized) geometry.densityDpi else 0
        attempt?.virtualDisplayCreated = true
        attempt?.virtualDisplayWidth = captureWidth
        attempt?.virtualDisplayHeight = captureHeight
        attempt?.virtualDisplayDensity = requestedDensity
        attempt?.virtualDisplayFlags = DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR
        DiagnosticsLog.event(
            TAG,
            "[VIRTUAL_DISPLAY] created ${captureWidth}x$captureHeight dpi=$requestedDensity " +
                "flags=AUTO_MIRROR surfaceOwnedByReader=$sameSurface",
        )
        if (!sameSurface) {
            val e = IllegalStateException("VirtualDisplay surface mismatch")
            attempt?.capture(e, "VirtualDisplay surface is not the ImageReader surface")
            DiagnosticsLog.failure(TAG, "[VIRTUAL_DISPLAY] surface mismatch", e)
            return false
        }
        return true
    }

    /**
     * Waits until the first frame reaches the frame buffer (V6 spec §20 acceptance criterion).
     * Blocking lives here so the diagnostic probe and the session start use the same code.
     */
    fun awaitFirstFrame(timeoutMs: Long): ProbeStep {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        while (SystemClock.elapsedRealtime() < deadline) {
            if (firstFrameReceived) {
                return ProbeStep(
                    CaptureStage.FIRST_FRAME, true,
                    "primeiro frame em ${firstFrameLatencyMs}ms (received=$receivedFrames processed=$producedFrames)",
                )
            }
            if (!captureHealthy && hasReader && hasDisplay) captureHealthy = true
            if (reader == null || display == null) {
                return ProbeStep(CaptureStage.FIRST_FRAME, false, "capture desmontada antes do primeiro frame")
            }
            runCatching { Thread.sleep(10) }
        }
        return ProbeStep(
            CaptureStage.FIRST_FRAME, false,
            "nenhum frame em ${timeoutMs}ms (received=$receivedFrames healthy=$captureHealthy " +
                "display=$hasDisplay reader=$hasReader)",
        )
    }

    private fun copyLatestImage(source: ImageReader, callbackGeneration: Long) {
        // The listener can already be queued when close() runs. Do not acquire from a stale reader;
        // this prevents old sessions from touching the new buffer and avoids post-STOP work.
        if (!sessionGate.accepts(callbackGeneration) || source !== reader) return
        val image = try { source.acquireLatestImage() } catch (e: Exception) {
            // V5 §13: count transient failures; only a persistent failure terminates the session.
            consecutiveCopyFailures++
            if (consecutiveCopyFailures >= MAX_COPY_FAILURES) {
                onCaptureFailureDetailed(CaptureStage.FRAME_COPY, e, "acquireLatestImage failed $consecutiveCopyFailures times")
                onCaptureFailure("acquireLatestImage failed $consecutiveCopyFailures times: ${e.message}")
            }
            null
        } ?: return
        try {
            if (!sessionGate.accepts(callbackGeneration) || source !== reader) return
            receivedFrames++
            frameStats.onReceived(System.nanoTime())
            val nowNs = SystemClock.elapsedRealtimeNanos()
            if (minIntervalNs > 0L && lastPublishedUptimeNs != 0L && nowNs - lastPublishedUptimeNs < minIntervalNs) {
                gatedFrames++
                frameStats.onGated()
                return
            }
            val buffer = frameBuffer ?: return
            val frame = buffer.acquireWritable()
            if (frame == null) {
                droppedFrames = buffer.droppedFrames()
                frameStats.onDropped()
                return
            }
            try {
                copyPixels(image, frame)
                val ts = System.nanoTime()
                frame.resetFor(ts, ++serial)
                frame.fps = cfg.targetFps.toFloat()
                if (!buffer.publish(frame)) {
                    buffer.cancelWrite(frame)
                    return
                }
                consecutiveCopyFailures = 0
                copyFailureReported = false
                lastPublishedUptimeNs = nowNs
                lastFrameTimestampNs = ts
                producedFrames++
                frameStats.onProcessed(ts)
                droppedFrames = buffer.droppedFrames()
                if (!firstFrameReceived) {
                    firstFrameReceived = true
                    firstFrameLatencyMs = (nowNs / 1_000_000L) - startedUptimeMs
                    DiagnosticsLog.event(
                        TAG,
                        "[FRAME] primeiro frame ${captureWidth}x$captureHeight latency=${firstFrameLatencyMs}ms " +
                            "age=${FrameAge.format(frameAgeMs())}",
                    )
                }
            } catch (e: Exception) {
                buffer.cancelWrite(frame)
                consecutiveCopyFailures++
                if (consecutiveCopyFailures >= MAX_COPY_FAILURES) {
                    if (!copyFailureReported) {
                        copyFailureReported = true
                        onCaptureFailureDetailed(CaptureStage.FRAME_COPY, e, "frame copy failed $consecutiveCopyFailures times")
                    }
                    onCaptureFailure("frame copy failed $consecutiveCopyFailures times: ${e.message}")
                }
            }
        } finally {
            // every Image is closed exactly once, on every path (spec §15)
            image.close()
        }
    }

    private fun copyPixels(image: Image, frame: VisionFrame) {
        val plane = image.planes.firstOrNull() ?: error("ImageReader returned no planes")
        require(image.width == captureWidth && image.height == captureHeight) {
            "capture dimensions changed ${image.width}x${image.height} != ${captureWidth}x${captureHeight}"
        }
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        require(pixelStride == 4) { "RGBA plane pixelStride=$pixelStride (expected 4)" }
        if (rowStride % 4 != 0 && !strideWarned) {
            strideWarned = true
            onCaptureFailure("unexpected rowStride=$rowStride (not a multiple of 4)")
        }
        val bytes = plane.buffer
        bytes.rewind()
        val ints = bytes.order(ByteOrder.nativeOrder()).asIntBuffer()
        val rowStrideInts = rowStride / 4
        val w = captureWidth
        val dst = frame.argb
        val row = rowInts
        val littleEndian = ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN
        var dstOff = 0
        for (y in 0 until captureHeight) {
            ints.position(y * rowStrideInts)
            ints.get(row, 0, w)
            if (littleEndian) {
                // memory R,G,B,A → int 0xAABBGGRR; want 0xFFRRGGBB
                for (x in 0 until w) {
                    val p = row[x]
                    dst[dstOff + x] = (0xFF shl 24) or ((p and 0xFF) shl 16) or (p and 0xFF00) or ((p ushr 16) and 0xFF)
                }
            } else {
                // memory R,G,B,A → int 0xRRGGBBAA
                for (x in 0 until w) {
                    val p = row[x]
                    dst[dstOff + x] = (0xFF shl 24) or (p ushr 8)
                }
            }
            dstOff += w
        }
    }

    /**
     * Adaptive rate gate (spec §4/§12): the engine lowers this when vision processing cannot keep
     * up, so the capture thread stops copying frames that would only be discarded anyway.
     */
    fun setRateLimit(fps: Int) {
        val clamped = fps.coerceIn(5, 60)
        effectiveFps = clamped
        // Allow ~15% jitter so a 30 Hz gate on a 60/90 Hz source does not alias down to 20/22 Hz.
        minIntervalNs = ((1_000_000_000L / clamped) * 0.85f).toLong()
    }

    /** Worker takes only the latest frame; older pending frames have already been returned to the pool. */
    fun takeLatest(): VisionFrame? = frameBuffer?.takeLatest()

    fun release(frame: VisionFrame) {
        frameBuffer?.release(frame)
    }

    fun hasPendingFrame(): Boolean = (frameBuffer?.pendingCount() ?: 0) > 0

    /** True while the physical display still has the size/rotation the session was calibrated for. */
    fun displayConfigurationUnchanged(): Boolean {
        val now = runCatching { ScreenGeometry.read(context) }.getOrNull() ?: return false
        return now.sameAs(geometry)
    }

    override fun close() {
        // Invalidate callbacks before releasing ImageReader/VirtualDisplay. Handler messages already
        // queued for this source may still run, but they can no longer acquire/publish a frame.
        sessionGate.invalidate()
        captureHealthy = false
        runCatching { reader?.setOnImageAvailableListener(null, null) }
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { frameBuffer?.close() }
        val restored = runCatching { processingResolutionController.restoreNormal() }.getOrNull()
        if (restored != null) processingResolution = restored
        DiagnosticsLog.event(
            TAG,
            "[CAPTURE] recursos liberados (display/reader/surface) received=$receivedFrames " +
                "produced=$producedFrames dropped=$droppedFrames " +
                "processingRestored=${restored?.describe() ?: "none"}",
        )
        display = null
        reader = null
        frameBuffer = null
        rowInts = IntArray(0)
        firstFrameReceived = false
    }

    companion object {
        const val MAX_IMAGES = 3
        const val MAX_COPY_FAILURES = 10
        const val VIRTUAL_DISPLAY_NAME = "fisch-v6-capture"
        private const val TAG = "CAPTURE"
    }
}
