package com.fischa.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings as AndroidSettings
import android.text.method.ScrollingMovementMethod
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.fischa.app.ui.DiagnosticsLog
import com.fischa.core.capture.CaptureAttempt
import com.fischa.core.capture.CaptureConsentPolicy
import com.fischa.core.capture.CaptureErrorText
import com.fischa.core.capture.CaptureState
import com.fischa.core.capture.FrameAge
import com.fischa.core.config.AppConfig
import com.fischa.core.log.Tags

/**
 * Operator UI.
 *
 * V6 changes (spec §5/§9/§17/§18/§20/§21):
 *  - The screen-capture consent uses the modern
 *    `registerForActivityResult(ActivityResultContracts.StartActivityForResult())` API.
 *  - The Activity no longer creates the MediaProjection: it hands the consent (resultCode + Intent)
 *    to the foreground service, which starts the FGS *first* and only then calls
 *    `getMediaProjection()` — the ordering the platform requires (and the V5 bug).
 *  - A dedicated "DIAGNÓSTICO DE CAPTURA" action tests only the capture infrastructure and writes a
 *    report; it never fishes, never taps Roblox and never enables real input.
 *  - The capture lifecycle is displayed as its own state machine (Capture / Projection / Service),
 *    with the frame counters, "frame age = N/A" when no frame exists, and the last capture error
 *    **including the original exception class and message**.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var statusView: TextView
    private lateinit var captureView: TextView
    private lateinit var reportView: TextView
    private lateinit var logView: TextView
    private lateinit var realInputSwitch: Switch
    private lateinit var verboseSwitch: CheckBox
    private lateinit var debugSwitch: CheckBox
    private val fields = linkedMapOf<String, EditText>()
    private val handler = Handler(Looper.getMainLooper())
    private var pendingRealInput = false
    private var pendingDiagnostic = false

    /**
     * V6 §5 — modern Activity Result API for the screen-capture consent.
     */
    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        onConsentResult(result.resultCode, result.data)
    }

    private val refresh = object : Runnable {
        override fun run() {
            val s = FischEngineService.status
            val live = GameAccessibilityService.latestForegroundStatus()
            statusView.text = buildString {
                val acc = if (GameAccessibilityService.instance != null) "ON" else "OFF"
                append("Acessibilidade: $acc | Roblox: ${if (s.running) s.robloxDetected else live.robloxDetected} | package: ${if (s.running) s.foregroundPackage else live.foregroundPackage}\n")
                append("Fonte: ${if (s.running) s.evidenceSource else live.evidenceSource} | Input autorizado: ${if (s.inputAuthorized) "YES" else "NO"} | realInput: ${if (s.realInputEnabled) "ON" else "OFF"}\n")
                append("Janela/activity: ${if (s.running) s.foregroundActivityWindow else live.foregroundActivityWindow}\n")
                append("Janela/atividade do bloqueio: ${if (s.running) s.foregroundBlockReason else live.blockReason}\n")
                append("Janela/idade do status: ${if (s.foregroundAgeMs == Long.MAX_VALUE) "-" else s.foregroundAgeMs.toString()} ms\n")
                append("FSM pesca: ${s.state} | FPS: ${"%.1f".format(s.fps)} | proc: ${"%.1f".format(s.procMs)} ms\n")
                append("AUTOMAÇÃO: ${s.automationState} (${s.automationLine})${if (s.automationReason.isNotEmpty()) " — ${s.automationReason}" else ""}\n")
                append("Vara: detected=${s.rodDetected} conf=${"%.2f".format(s.rodConfidence)} confirmed=${s.rodConfirmed} | castAutorizado=${s.castAuthorized}${if (s.castGateReason.isNotEmpty() && s.state == "WAITING_FOR_ROD") " (${s.castGateReason})" else ""}\n")
                append("V7 detecção: ${s.rodState} | score=${"%.2f".format(s.rodScore)} | candidatos=${s.rodCandidates} | tracking=${s.rodTracking} | calibração=${if (s.rodCalibrationDone) "OK" else "coletando"}\n")
                if (s.rodRoi.isNotEmpty()) append("ROI dinâmica (px): ${s.rodRoi}\n")
                if (s.rodReason.isNotEmpty()) append("motivo: ${s.rodReason}\n")
                if (s.rodCalibration.isNotEmpty()) append("calibração: ${s.rodCalibration}\n")
                append("Barra: locked=${s.barLocked} | confiança global: ${"%.2f".format(s.globalConf)}\n")
                if (s.emergency) append("EMERGENCY STOP LATCHED — limpe explicitamente antes de iniciar\n")
                if (s.denyReason.isNotEmpty()) append("Safety/Input: ${s.denyReason}\n")
                if (s.geometry.isNotEmpty()) append("Geometria: ${s.geometry}\n")
                if (s.processingResolution.isNotEmpty()) append("Pixels internos: ${s.processingResolution} (display global inalterado)\n")
                append(s.message)
            }
            val attempt = CaptureAttemptRegistry.last
            captureView.text = buildString {
                append("=== CAPTURA (V6) ===\n")
                append("Capture state:   ${s.captureState} (${s.captureReason})\n")
                append("Projection:      ${s.projectionState}\n")
                append("Service:         ${s.serviceState}\n")
                append("frame age:       ${FrameAge.format(s.frameAgeMs)} (\"N/A\" quando não há frame)\n")
                append("FPS:             ${"%.1f".format(s.fps)}\n")
                append("frames received: ${s.framesReceived}\n")
                append("frames processed:${s.framesProcessed}\n")
                append("frames dropped:  ${s.framesDropped} (gated: ${s.gatedFrames})\n")
                append("primeiro frame:  ${if (s.firstFrameLatencyMs >= 0) "${s.firstFrameLatencyMs} ms" else "não recebido"}\n")
                append("última falha:    ${s.lastCaptureError.ifEmpty { "nenhuma" }}\n")
                if (s.lastCaptureErrorTechnical.isNotEmpty()) append("causa técnica:   ${s.lastCaptureErrorTechnical}\n")
                if (s.deviceDescription.isNotEmpty()) append("device:          ${s.deviceDescription}\n")
                attempt?.let { append("última tentativa: stage=${it.stage.name} resultCode=${it.resultCode} dataPresent=${it.dataPresent} " +
                    "managerPresent=${it.managerPresent} fgs=${it.foregroundStarted} projection=${it.projectionCreated} " +
                    "reader=${it.imageReaderCreated} display=${it.virtualDisplayCreated} firstFrame=${it.firstFrameReceived}\n") }
                append("modo diagnóstico: ${if (s.diagnosticMode) "SIM" else "não"}\n")
                if (s.reportFile.isNotEmpty()) append("relatório: ${s.reportFile}\n")
                append("log: ${AppLog.logFilePath()}")
            }
            logView.text = AppLog.tail().ifEmpty { "Aguardando diagnóstico [SAFETY]." }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLog.init(this)
        AppLog.setVerbose(getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).getBoolean("verbose", false))
        val padding = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        setContentView(ScrollView(this).apply { addView(root) })
        root.setOnApplyWindowInsetsListener { view, insets ->
            @Suppress("DEPRECATION")
            view.setPadding(
                padding + insets.systemWindowInsetLeft,
                padding + insets.systemWindowInsetTop,
                padding + insets.systemWindowInsetRight,
                padding + insets.systemWindowInsetBottom,
            )
            insets
        }
        fun text(value: String, size: Float = 16f) = TextView(this).apply {
            text = value
            textSize = size
            root.addView(this)
        }
        fun button(value: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = value; setOnClickListener { action() } })
        }

        text(getString(R.string.app_name), 26f)
        val device = FischEngineService.readDeviceProfile(this)
        text("Alvo: Galaxy A22 (SM-A225M) / Android 13. Device: ${device.describe()}")
        text(
            "Novo fluxo (V9.1): o START principal apenas prepara o sistema (permissões → serviços → captura) e " +
                "deixa o estado READY — ele NÃO começa a pescar. Quando estiver READY aparece um botão flutuante " +
                "\"START FISHING\" sobre o jogo: é ele que inicia a automação (o texto vira \"STOP\"). STOP para a " +
                "automação na hora e volta para READY sem derrubar a captura. Input real continua OFF até você " +
                "ativar explicitamente, e o SafetyGuard continua bloqueando fora do Roblox, com frame antigo ou " +
                "confiança baixa. Use apenas onde automação seja permitida.",
        )
        statusView = text("Aguardando início")
        text("Diagnóstico de captura (MediaProjection)", 20f)
        captureView = text("capture=STOPPED", 13f)

        button("START (só prepara: permissões → serviços → captura → READY)") { begin(diagnostic = false) }
        button("CALIBRAR QUADRADO DO BOTÃO VARAR") {
            val service = GameAccessibilityService.instance
            if (service == null) {
                Toast.makeText(this, "Ative a Acessibilidade primeiro.", Toast.LENGTH_LONG).show()
            } else {
                service.showManualRodRoiCalibration()
            }
        }
        text("A calibração manual cria uma área fixa: coloque o quadrado sobre o botão VARAR e salve. O detector V9 passa a procurar somente nessa área.", 13f)
        button("START FISHING (iniciar a automação agora — equivale ao botão flutuante)") {
            startService(
                Intent(this, FischEngineService::class.java).setAction(FischEngineService.ACTION_START_FISHING),
            )
        }
        button("STOP DA AUTOMAÇÃO (mantém a captura em READY)") {
            startService(
                Intent(this, FischEngineService::class.java).setAction(FischEngineService.ACTION_STOP_FISHING),
            )
        }
        button("DIAGNÓSTICO DE CAPTURA (só infraestrutura; não pesca, não clica, não ativa input)") {
            begin(diagnostic = true)
        }
        button("Mostrar relatório do diagnóstico de captura") { showReport() }
        button("Compartilhar log + diagnóstico") { shareDiagnostics() }
        button("STOP TOTAL (encerra a sessão: automação + captura)") {
            startService(Intent(this, FischEngineService::class.java).setAction(FischEngineService.ACTION_STOP))
        }
        button("EMERGENCY STOP — cancelar e liberar") {
            startService(Intent(this, FischEngineService::class.java).setAction(FischEngineService.ACTION_EMERGENCY))
        }
        button("Limpar latch de emergência (ação manual; não inicia o macro)") {
            startService(Intent(this, FischEngineService::class.java).setAction(FischEngineService.ACTION_CLEAR_EMERGENCY))
        }
        button("Habilitar / revisar serviço de acessibilidade") {
            startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("Configurações") { startActivity(Intent(this, SettingsActivity::class.java)) }

        text("Relatório", 20f)
        reportView = TextView(this).apply {
            textSize = 10f
            typeface = android.graphics.Typeface.MONOSPACE
            movementMethod = ScrollingMovementMethod()
            text = "Nenhum diagnóstico executado ainda."
        }
        root.addView(reportView, LinearLayout.LayoutParams(-1, (220 * resources.displayMetrics.density).toInt()))

        realInputSwitch = Switch(this).apply {
            // V7 §10: REAL_INPUT is hard-locked while the detection is being validated. The switch
            // is disabled on purpose — there is no UI path to unlock it, and no code path that
            // unlocks it automatically after a successful detection.
            val locked = com.fischa.core.safety.RealInputPolicy.locked
            text = if (locked) {
                "REAL_INPUT bloqueado na V7 (validação visual da detecção)"
            } else {
                "Autorizar gestos reais nesta sessão (OFF por padrão)"
            }
            isChecked = false
            isEnabled = !locked
        }
        root.addView(realInputSwitch)
        debugSwitch = CheckBox(this).apply {
            text = "Overlay de debug (não-touchable)"
            isChecked = getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).getBoolean("overlay", false)
            setOnCheckedChangeListener { _, enabled ->
                getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).edit().putBoolean("overlay", enabled).apply()
                startService(
                    Intent(this@MainActivity, FischEngineService::class.java)
                        .setAction(FischEngineService.ACTION_DEBUG_OVERLAY)
                        .putExtra(FischEngineService.EXTRA_DEBUG_ENABLED, enabled),
                )
            }
        }
        root.addView(debugSwitch)
        verboseSwitch = CheckBox(this).apply {
            text = "Log verboso (DEBUG por frame; só para diagnóstico)"
            isChecked = getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).getBoolean("verbose", false)
            setOnCheckedChangeListener { _, enabled ->
                getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).edit().putBoolean("verbose", enabled).apply()
                AppLog.setVerbose(enabled)
            }
        }
        root.addView(verboseSwitch)

        text("Parâmetros core (aplicados no próximo Start)", 20f)
        val config = FischEngineService.loadConfig(this)
        fun field(label: String, key: String, value: String) {
            text(label)
            val edit = EditText(this).apply {
                setText(value)
                inputType = android.text.InputType.TYPE_CLASS_TEXT
            }
            fields[key] = edit
            root.addView(edit)
        }
        field("Largura de processamento (A22: 640)", "capture.processingWidth", config.capture.processingWidth.toString())
        field("FPS alvo de captura (A22: 24–30)", "capture.targetFps", config.capture.targetFps.toString())
        field("Timeout do primeiro frame (ms)", "capture.firstFrameTimeoutMs", config.capture.firstFrameTimeoutMs.toString())
        field("Kp", "control.kP", config.control.kP.toString())
        field("Kff", "control.kFF", config.control.kFF.toString())
        field("Deadband", "control.deadband", config.control.deadband.toString())
        field("CAST_HOLD_DURATION_MS (carga do cast)", "cast.holdMs", config.cast.holdMs.toString())
        field("Vara: frames p/ confirmar (padrão 3)", "rod.confirmFrames", config.rod.confirmFrames.toString())
        field("Vara: confiança mínima (ROD_CONFIDENCE_THRESHOLD)", "rod.confidenceThreshold", config.rod.confidenceThreshold.toString())
        field("Vara: tolerância de posição", "rod.stableToleranceF", config.rod.stableToleranceF.toString())
        field("Vara: janela de confirmação (ms)", "rod.confirmWindowMs", config.rod.confirmWindowMs.toString())
        field("WAITING_FOR_WATER timeout (ms)", "state.waitingForWaterMs", config.state.waitingForWaterMs.toString())
        field("Hold quantum (30–100 ms)", "safety.holdQuantumMs", config.safety.holdQuantumMs.toString())
        field("Frame age máximo (ms)", "safety.maxFrameAgeMs", config.safety.maxFrameAgeMs.toString())
        button("Salvar parâmetros") { saveConfig() }

        text("Último log do motor", 20f)
        logView = TextView(this).apply {
            textSize = 11f
            movementMethod = ScrollingMovementMethod()
            setPadding(0, padding, 0, 0)
        }
        root.addView(logView)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
        AppLog.event(Tags.SYSTEM, "[SYSTEM] UI V6 aberta; device ${FischEngineService.readDeviceProfile(this).describe()}")
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun saveConfig(): Boolean = try {
        val base = AppConfig().toMap().toMutableMap()
        fields.forEach { (key, edit) -> base[key] = edit.text.toString().trim() }
        val parsed = AppConfig().withOverrides(base).validate()
        val valid = parsed.toMap()
        fields.forEach { (key, edit) ->
            val entered = edit.text.toString().trim().toDoubleOrNull()
                ?: throw IllegalArgumentException("$key precisa ser numérico")
            val applied = valid[key]?.toDoubleOrNull()
                ?: throw IllegalArgumentException("$key não foi reconhecido")
            require(kotlin.math.abs(entered - applied) < 1e-6 || entered == applied) {
                "Valor inválido para $key: ${edit.text}"
            }
        }
        getSharedPreferences("fisch-config", Context.MODE_PRIVATE).edit().apply {
            valid.forEach { (key, value) -> putString(key, value) }
        }.apply()
        Toast.makeText(this, "Configurações salvas; reinicie o motor", Toast.LENGTH_SHORT).show()
        true
    } catch (e: Exception) {
        Toast.makeText(this, "Valor inválido: ${e.message}", Toast.LENGTH_LONG).show()
        false
    }

    /** START and DIAGNÓSTICO share the consent flow; only the service action differs (spec §9/§18). */
    private fun begin(diagnostic: Boolean) {
        if (FischEngineService.status.running) {
            Toast.makeText(this, "Pare a sessão antes de iniciar outra", Toast.LENGTH_SHORT).show()
            return
        }
        if (!diagnostic && GameAccessibilityService.instance == null) {
            Toast.makeText(this, "Ative o serviço de acessibilidade primeiro (necessário apenas para INPUT; o diagnóstico de captura não precisa)", Toast.LENGTH_LONG).show()
            startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if (!saveConfig()) return
        pendingDiagnostic = diagnostic
        pendingRealInput = if (diagnostic) false else realInputSwitch.isChecked
        if (pendingRealInput) {
            android.app.AlertDialog.Builder(this)
                .setTitle("Confirmar input real")
                .setMessage(
                    "Build Galaxy A22 V6 — não testada por nós no Roblox real. Você autoriza gestos " +
                        "reais apenas nesta sessão? O SafetyGuard continua bloqueando fora do Roblox, " +
                        "em frames antigos e com confiança baixa. EMERGÊNCIA fica na notificação.",
                )
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Autorizar sessão") { _, _ -> requestProjection() }
                .show()
        } else {
            requestProjection()
        }
    }

    /** V6 §5: system consent dialog, then the result goes to the foreground service. */
    private fun requestProjection() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        if (manager == null) {
            DiagnosticsLog.event(Tags.MEDIA_PROJECTION, "[MEDIA_PROJECTION] MediaProjectionManager indisponível (getSystemService = null)")
            Toast.makeText(this, "MediaProjectionManager indisponível neste aparelho", Toast.LENGTH_LONG).show()
            return
        }
        DiagnosticsLog.event(
            Tags.MEDIA_PROJECTION,
            "[MEDIA_PROJECTION] solicitando consentimento (createScreenCaptureIntent, sdk=${Build.VERSION.SDK_INT}, " +
                "modo=${if (pendingDiagnostic) "DIAGNOSTIC" else "START"})",
        )
        val intent = if (Build.VERSION.SDK_INT >= 34) {
            manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            manager.createScreenCaptureIntent()
        }
        projectionLauncher.launch(intent)
    }

    /**
     * V6 spec §5 — the Activity Result is evaluated explicitly and logged as
     * `CAPTURE_PERMISSION_RESULT`; only a full success starts the service.
     */
    private fun onConsentResult(resultCode: Int, data: Intent?) {
        val managerPresent = getSystemService(MediaProjectionManager::class.java) != null
        val evaluation = CaptureConsentPolicy.evaluate(resultCode, data != null, managerPresent)
        DiagnosticsLog.event(Tags.MEDIA_PROJECTION, "[MEDIA_PROJECTION] ${evaluation.logLine}")
        if (!CaptureConsentPolicy.mayStartCapture(evaluation)) {
            DiagnosticsLog.event(
                Tags.CAPTURE,
                "[CAPTURE] captura NÃO iniciada: ${evaluation.reason} (resultCode=$resultCode dataPresent=${data != null})",
            )
            CaptureConsentHolder.clear()
            Toast.makeText(this, evaluation.friendlyMessage(), Toast.LENGTH_LONG).show()
            return
        }
        // primary handoff = intent extras; holder = fallback for ROMs that strip nested binder extras
        CaptureConsentHolder.set(resultCode, data)
        val attempt = CaptureAttempt(
            device = FischEngineService.readDeviceProfile(this),
            mode = if (pendingDiagnostic) "DIAGNOSTIC" else "START",
        )
        attempt.resultCode = resultCode
        attempt.dataPresent = true
        attempt.managerPresent = managerPresent
        attempt.startedFromActivity = "activity-extras"
        CaptureAttemptRegistry.publish(attempt)

        val action = if (pendingDiagnostic) {
            FischEngineService.ACTION_DIAGNOSE_CAPTURE
        } else {
            FischEngineService.ACTION_START
        }
        val startIntent = Intent(this, FischEngineService::class.java)
            .setAction(action)
            .putExtra(FischEngineService.EXTRA_RESULT_CODE, resultCode)
            .putExtra(FischEngineService.EXTRA_RESULT_DATA, data)
            .putExtra(FischEngineService.EXTRA_REAL_INPUT, pendingRealInput)
            .putExtra(FischEngineService.EXTRA_CONSENT_SOURCE, "activity-extras")
        val started = try {
            ContextCompat.startForegroundService(this, startIntent)
            true
        } catch (t: Throwable) {
            // e.g. ForegroundServiceStartNotAllowedException: the app is in the foreground right now
            // (we just returned from the consent dialog), so a plain start still lets the service
            // call startForeground() immediately.
            DiagnosticsLog.failure(
                Tags.FOREGROUND_SERVICE,
                "[FOREGROUND_SERVICE] startForegroundService recusado; tentando startService",
                t,
            )
            try {
                startService(startIntent)
                true
            } catch (t2: Throwable) {
                DiagnosticsLog.failure(Tags.FOREGROUND_SERVICE, "[FOREGROUND_SERVICE] startService também recusado", t2)
                false
            }
        }
        if (!started) {
            CaptureConsentHolder.clear()
            Toast.makeText(this, "Não foi possível iniciar o serviço de captura (ver log)", Toast.LENGTH_LONG).show()
        }
        realInputSwitch.isChecked = false
    }

    private fun showReport() {
        val report = CaptureAttemptRegistry.lastReport?.format()
            ?: FischEngineService.status.diagnosticReport.ifEmpty { null }
            ?: runCatching {
                java.io.File(filesDir, FischEngineService.REPORT_FILE).takeIf { it.exists() }?.readText()
            }.getOrNull()
        val attempt = CaptureAttemptRegistry.last
        reportView.text = buildString {
            if (report != null) {
                append(report)
            } else {
                append("Nenhum relatório ainda. Use \"DIAGNÓSTICO DE CAPTURA\".\n")
            }
            if (attempt != null) {
                append("\n\n--- última tentativa ---\n")
                append(attempt.formatBlock())
            }
            append("\n\n--- log (final) ---\n")
            append(AppLog.lines().takeLast(4000))
        }
    }

    private fun shareDiagnostics() {
        val text = buildString {
            append("${getString(R.string.app_name)} — diagnóstico\n")
            append("device: ${FischEngineService.readDeviceProfile(this@MainActivity).describe()}\n\n")
            append(CaptureAttemptRegistry.last?.formatBlock().orEmpty())
            append("\n\n")
            append(CaptureAttemptRegistry.lastReport?.format().orEmpty())
            append("\n\n=== LOG ===\n")
            append(AppLog.lines())
        }.take(60_000)
        val share = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        startActivity(Intent.createChooser(share, "Compartilhar diagnóstico"))
    }

    companion object {
        /** Purely informational helpers for the UI text (kept out of the hot path). */
        const val BUILD_LABEL = "0.9.1-v91"
    }
}
