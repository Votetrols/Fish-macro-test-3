package com.fischa.core.vision

import com.fischa.core.common.NormRegion
import com.fischa.core.common.PointF
import com.fischa.core.common.RectF
import com.fischa.core.config.AppConfig
import com.fischa.core.log.Tags
import com.fischa.core.log.ThrottledLog
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * V9 §1 — a máquina de estados da **janela móvel**, preservada integralmente da V8:
 *
 * ```
 * INITIAL → SEARCHING → TRACKING → TARGET_LOST → RECOVERING → TRACKING
 *                            ↑                        │
 *                            └──── TARGET_NOT_FOUND ───┘  (orçamento de recuperação esgotado)
 * ```
 *
 * A única diferença em relação à V8 é **quem** responde "existe um botão aqui dentro?": em vez do
 * mecanismo antigo (blob escuro + anel), quem responde é o [RodButtonDetectorV9].
 */
enum class RodV9State {
    /** a janela está na posição inicial configurada (primeiro frame de uma sessão) */
    INITIAL,

    /** a janela está sendo varrida em busca do botão */
    SEARCHING,

    /** o botão foi encontrado, confirmado, e a janela o acompanha */
    TRACKING,

    /** o botão não apareceu no frame atual (carência curta; a janela fica perto do lastKnown) */
    TARGET_LOST,

    /** a busca foi ampliada em torno da última posição conhecida (e depois da área inicial) */
    RECOVERING,
    ;

    val isTracking: Boolean get() = this == TRACKING
    val isRecovery: Boolean get() = this == TARGET_LOST || this == RECOVERING

    val rodDiag: RodDiagEvent?
        get() = when (this) {
            TARGET_LOST -> RodDiagEvent.NO_CANDIDATE
            RECOVERING -> RodDiagEvent.RECOVERING
            else -> null
        }
}

/**
 * V9 §10/§17 — tudo o que o detector reporta, e *nada além disso*: `targetFound`, `targetX`,
 * `targetY`, `confidence`, `state`, `roi` e `candidateData`. O detector **nunca** executa input.
 *
 * `targetX`/`targetY` só têm significado quando [targetFound] é true; fora disso ficam `NaN`
 * (o detector nunca inventa uma posição — spec §14). [targetNotFound] é a resposta explícita
 * `TARGET_NOT_FOUND`: o orçamento de recuperação terminou sem candidato válido.
 */
class RodV9Result {
    var state: RodV9State = RodV9State.INITIAL

    /** true apenas quando um candidato validado passou a confirmação temporal */
    var targetFound = false

    /** orçamento de recuperação esgotado: a resposta honesta é `TARGET_NOT_FOUND` */
    var targetNotFound = false

    /** posição normalizada do alvo (0..1 do frame) — `NaN` a menos que [targetFound] */
    var targetX = Float.NaN
    var targetY = Float.NaN

    /** confiança temporal da detecção (0..1) */
    var confidence = 0f

    /** score de um único frame do vencedor (0..1) */
    var score = 0f

    /** candidatos que sobreviveram à busca dentro da janela neste frame */
    var candidates = 0

    /** hipóteses descartadas com motivo neste frame (auditoria §6/§9) */
    var rejections = 0

    /** motivos legíveis dos descartes deste frame (§6/§9 — o que o detector viu e recusou) */
    val rejectionNotes = ArrayList<String>(8)

    /** streak de confirmação (frames) e quantos são exigidos no FPS medido */
    var confirmation = 0
    var requiredFrames = 0

    /** um candidato foi visto (e validado) neste frame — mesmo sem confirmação ainda */
    var candidateFound = false

    /** estado **visual** do detector de botão (`SEARCHING`/`CANDIDATE`/`CONFIRMING`/…) */
    var detectorState: RodButtonV9State = RodButtonV9State.SEARCHING

    /** candidatos medidos neste frame (cópia — vira `candidateData` no resultado) */
    val candidateData = ArrayList<RodButtonCandidateV9>(8)

    /** centro/raio do candidato em pixels do frame processado (debug §8) */
    val candidatePx = PointF()
    var candidateRadiusPx = 0f

    /** centro/raio do alvo em pixels processados (só válido quando [targetFound]) */
    val centerPx = PointF()
    var radiusPx = 0f

    /** caixa do candidato em pixels processados (debug), vazia quando não há candidato */
    val box = RectF()

    /** última posição conhecida do alvo (memória usada pela recuperação — §7) */
    var lastKnownX = Float.NaN
    var lastKnownY = Float.NaN

    /** posição do alvo no frame confirmado anterior (debug) */
    var previousX = Float.NaN
    var previousY = Float.NaN

    /** true enquanto a escada de recuperação está ativa */
    var recovering = false

    /** 0 = janela normal; 1..3 = estágios de recuperação (janelas ampliadas / área inicial) */
    var recoveryStage = 0

    /** true quando a janela buscada é maior que a configurada */
    var windowExpanded = false

    /** ms desde a última vez que o alvo foi visto (0 enquanto rastreia) */
    var lostMs = 0L

    /** true quando a janela se moveu neste frame (debug/log) */
    var moved = false

    /** ms desde a última confirmação (`Long.MAX_VALUE` quando nunca confirmou) — debug §8 */
    var msSinceConfirmed = Long.MAX_VALUE

    /** por que o detector está neste estado (vai para o log/overlay literalmente) */
    var reason = ""

    var frameW = 1
    var frameH = 1

    /** timestamp do frame que produziu este resultado (mesmo relógio monotônico do pipeline) */
    var frameTimestampNs = 0L

    /** resumo em uma linha da configuração da janela em vigor (debug §8) */
    var configSummary = ""

    internal var roiRegion: NormRegion = NormRegion.UNIT

    /** a janela que foi buscada neste frame (normalizada) — debug §8 */
    val roi: NormRegion get() = roiRegion

    fun copyFrom(o: RodV9Result) {
        state = o.state
        targetFound = o.targetFound; targetNotFound = o.targetNotFound
        targetX = o.targetX; targetY = o.targetY
        confidence = o.confidence; score = o.score; candidates = o.candidates
        confirmation = o.confirmation; requiredFrames = o.requiredFrames
        candidateFound = o.candidateFound
        detectorState = o.detectorState
        rejections = o.rejections
        rejectionNotes.clear()
        rejectionNotes.addAll(o.rejectionNotes)
        // os candidatos do frame já são cópias imutáveis produzidas pelo detector: reaproveita
        candidateData.clear()
        candidateData.addAll(o.candidateData)
        candidatePx.x = o.candidatePx.x; candidatePx.y = o.candidatePx.y
        candidateRadiusPx = o.candidateRadiusPx
        centerPx.x = o.centerPx.x; centerPx.y = o.centerPx.y
        radiusPx = o.radiusPx
        box.set(o.box)
        lastKnownX = o.lastKnownX; lastKnownY = o.lastKnownY
        previousX = o.previousX; previousY = o.previousY
        recovering = o.recovering; recoveryStage = o.recoveryStage
        windowExpanded = o.windowExpanded; lostMs = o.lostMs; moved = o.moved
        msSinceConfirmed = o.msSinceConfirmed
        reason = o.reason
        frameW = o.frameW; frameH = o.frameH
        frameTimestampNs = o.frameTimestampNs
        configSummary = o.configSummary
        roiRegion = o.roiRegion
    }

    fun centerString(): String =
        if (targetFound) "(${(centerPx.x).toInt()},${(centerPx.y).toInt()})" else "(-)"

    fun roiString(): String =
        "(${(roi.left * frameW).toInt()},${(roi.top * frameH).toInt()}," +
            "${(roi.width * frameW).toInt()},${(roi.height * frameH).toInt()})"
}

/**
 * # Rod Detection V9 — janela móvel (arquitetura da V8) + identificação visual V9
 *
 * A arquitetura permanece exatamente a da V8 — só muda o elo da *identificação visual*:
 *
 * ```
 * Screen Capture → ROI móvel (esta classe) → RodButtonDetectorV9 → validação de confiança
 *   → coordenadas do alvo → camada de input (fora daqui)
 * ```
 *
 * Preservado da V8 (§1/§13): [AppConfig.RodButtonV9.initialRoiX]…, `roiWidth`, `roiHeight`,
 * `maxMovePerFrame`, `deadZone`, `smoothing`, `minimumConfidence`, `confirmationFrames`,
 * `recoveryExpansion`, `targetLostTimeout`, `lastKnownTargetX/Y` e os estados
 * INITIAL/SEARCHING/TRACKING/TARGET_LOST/RECOVERING. A janela continua quadrada, móvel, nunca sai
 * da tela, e o alvo só é publicado depois da confirmação temporal.
 *
 * O que **não** mudou: input. Esta classe não chama `dispatchGesture`, não toca na tela, não
 * clica — a execução continua exclusivamente na camada de input já existente
 * (`InputSafetyGuard` → `AndroidInputExecutor`, ambos fora do detector).
 */
class RodDetectionV9(
    private val cfg: AppConfig,
    private val log: ThrottledLog,
) {
    private val v9 = cfg.rodButtonV9

    /** o detector visual (único ponto que mudou em relação à V8) */
    val detector = RodButtonDetectorV9(v9, log)

    /** §9 — captura para diagnóstico (passivo; `NONE` por padrão) */
    var diagnostics: RodFrameDiagnostics = RodFrameDiagnostics.NONE

    // ---- janela: canto superior esquerdo (normalizado) + o tamanho base configurado -------
    private var roiX = v9.initialRoiX
    private var roiY = v9.initialRoiY
    private val baseW = v9.roiWidth
    private val baseH = v9.roiHeight

    // ---- estado ----------------------------------------------------------------------------
    private var state = RodV9State.INITIAL
    private var started = false
    private var streak = 0
    private var streakStartNs = 0L
    private var anchorX = 0f
    private var anchorY = 0f
    private var confidence = 0f
    private var lastKnownX = Float.NaN
    private var lastKnownY = Float.NaN
    private var previousX = Float.NaN
    private var previousY = Float.NaN
    private var freshRequired = false
    private var lostSinceNs = NO_TIME
    private var recoverySinceNs = NO_TIME
    private var recoveryStage = 0
    private var exhausted = false
    private var lastNs = 0L
    private var fps = 30f
    private var lastLogState: RodV9State? = null
    private var lastDiagNs = 0L

    private val snapshot = RodV9Result()

    /** visões somente-leitura (o pipeline copia o que precisa; o snapshot é a fonte da verdade) */
    val currentState: RodV9State get() = state
    val out: RodV9Result get() = snapshot
    val tracking: Boolean get() = state == RodV9State.TRACKING
    val window: NormRegion get() = snapshot.roi

    /**
     * Um novo ciclo de pesca só pode começar a partir de uma confirmação **nova**: a janela e a
     * memória sobrevivem, mas `TRACKING`/`targetFound` precisam ser reconquistados com um novo
     * streak.
     */
    fun requireFreshConfirmation(reason: String) {
        freshRequired = true
        streak = 0
        snapshot.targetFound = false
        log.i(Tags.ROD_V9, "fresh", "[ROD_V9] reconfirmação exigida ($reason)")
    }

    /** Reset completo (nova sessão de captura): a janela volta para a posição configurada. */
    fun reset(nowNs: Long, reason: String) {
        state = RodV9State.INITIAL
        started = false
        streak = 0; streakStartNs = 0L
        confidence = 0f
        lastKnownX = Float.NaN; lastKnownY = Float.NaN
        previousX = Float.NaN; previousY = Float.NaN
        freshRequired = false
        lostSinceNs = NO_TIME; recoverySinceNs = NO_TIME; recoveryStage = 0; exhausted = false
        roiX = v9.initialRoiX; roiY = v9.initialRoiY
        detector.reset()
        snapshot.targetFound = false; snapshot.targetNotFound = false
        snapshot.targetX = Float.NaN; snapshot.targetY = Float.NaN
        snapshot.candidateFound = false; snapshot.confirmation = 0
        snapshot.candidateData.clear()
        log.i(Tags.ROD_V9, "reset", "[ROD_V9] reset ($reason)")
    }

    /**
     * Um frame → um resultado. Nunca aloca o frame, nunca toca em input.
     *
     * @param fpsMeasured FPS medido pelo host (nunca presumido); só torna a confirmação robusta a
     *        FPS — sem medição, assume ~30.
     * @param nowNs timestamp do frame no relógio monotônico do pipeline.
     */
    fun update(frame: VisionFrame, fpsMeasured: Float, nowNs: Long): RodV9Result {
        if (fpsMeasured.isFinite() && fpsMeasured > 0.5f) fps = fpsMeasured
        val w = frame.width
        val h = frame.height
        val dtSec = if (lastNs == 0L) 1f / fps else ((nowNs - lastNs) / 1e9f).coerceIn(0.001f, 0.5f)
        lastNs = nowNs
        if (!started) started = true else if (state == RodV9State.INITIAL) state = RodV9State.SEARCHING

        val window = currentWindow()
        val detecting = v9.rodButtonDetectionEnabled

        // ---- detecção DENTRO da janela (fonte única: o detector visual V9) -------------------
        val det = if (detecting) {
            detector.update(
                frame = frame,
                roi = window,
                nowNs = nowNs,
                fps = fps,
                tracking = state.isTracking,
                recovering = state.isRecovery,
            )
        } else {
            null
        }

        // ---- publica o básico do frame ------------------------------------------------------
        snapshot.frameW = w
        snapshot.frameH = h
        snapshot.frameTimestampNs = nowNs
        snapshot.configSummary = configSummary()
        snapshot.roiRegion = window
        snapshot.requiredFrames = det?.requiredFrames ?: requiredFrames()
        snapshot.lostMs = if (lostSinceNs == NO_TIME) 0L else (nowNs - lostSinceNs) / 1_000_000L
        snapshot.msSinceConfirmed = detectorIfEnabled()?.msSinceConfirmed ?: Long.MAX_VALUE
        snapshot.rejections = det?.rejections ?: 0
        snapshot.rejectionNotes.clear()
        detectorIfEnabled()?.let { d -> snapshot.rejectionNotes.addAll(d.lastRejections) }
        snapshot.moved = false
        snapshot.candidateFound = false
        // cada frame re-avalia: um alvo só existe se ESTE frame o confirmou (nunca herda
        // posição do frame anterior — publicar coordenada velha seria inventar posição)
        snapshot.targetFound = false
        snapshot.targetX = Float.NaN
        snapshot.targetY = Float.NaN
        snapshot.candidateData.clear()
        snapshot.detectorState = det?.state ?: RodButtonV9State.DISABLED

        var hadCandidate = false
        var lowConfidence = false

        if (det != null && det.candidateFound) {
            hadCandidate = true
            val best = det.candidateData.firstOrNull()
            val required = det.requiredFrames.coerceAtLeast(1)
            snapshot.candidates = det.candidates
            snapshot.candidateData.addAll(det.candidateData)
            snapshot.candidatePx.x = det.bestCxPx
            snapshot.candidatePx.y = det.bestCyPx
            snapshot.candidateRadiusPx = det.bestRadiusPx
            snapshot.box.set(det.box)
            snapshot.score = det.score

            if (best == null) {
                onMiss(nowNs, dtSec, false)
            } else {
                val rejection = validationFailure(best, w, h, jumpTolerance(window))
                if (rejection != null) {
                    lowConfidence = true
                    log.i(
                        Tags.ROD_V9, "reject",
                        "[ROD_V9] candidato rejeitado na validação: $rejection " +
                            "(score=${"%.2f".format(best.score)} r=${"%.1f".format(best.r)} " +
                            "c=(${(best.cx).toInt()},${(best.cy).toInt()}))",
                    )
                    onMiss(nowNs, dtSec, true)
                } else if (det.targetFound) {
                    // o detector visual já fez a confirmação temporal (spec §5): a janela só segue
                    onConfirmedTarget(best, det, required, w, h, nowNs)
                } else {
                    lowConfidence = det.confidence < v9.minimumConfidence
                    onCandidate(best, det, required, w, h, nowNs)
                }
            }
        } else {
            snapshot.candidates = det?.candidates ?: 0
            onMiss(nowNs, dtSec, false)
        }

        snapshot.state = state
        snapshot.recovering = state.isRecovery
        snapshot.recoveryStage = if (state.isRecovery) recoveryStage else 0
        snapshot.windowExpanded = window.width > baseW * 1.001f || window.height > baseH * 1.001f
        snapshot.targetNotFound = exhausted
        if (state != lastLogState) {
            lastLogState = state
            log.i(Tags.ROD_V9, "state", "[STATE] ROD_V9=${state.name}")
        }

        // ---- §9: captura de diagnóstico (passiva) -------------------------------------------
        maybeDiagnose(frame, window, nowNs, hadCandidate, lowConfidence)
        return snapshot
    }

    /** o detector visual responde só quando ligado; sem ele o detector "nunca confirmou" */
    private fun detectorIfEnabled(): RodButtonDetectorV9? =
        if (v9.rodButtonDetectionEnabled) detector else null

    // ---------------------------------------------------------------------------------------
    //  estado
    // ---------------------------------------------------------------------------------------

    /** candidato validado mas ainda não confirmado: a janela pode se aproximar, sem publicar alvo */
    private fun onCandidate(
        c: RodButtonCandidateV9,
        det: RodButtonV9Result,
        required: Int,
        w: Int,
        h: Int,
        nowNs: Long,
    ) {
        val nx = c.cx / w
        val ny = c.cy / h
        streak = det.confirmation
        anchorX = nx
        anchorY = ny
        streakStartNs = nowNs
        confidence = det.confidence
        snapshot.candidateFound = true
        snapshot.confidence = confidence
        snapshot.confirmation = streak
        snapshot.score = c.score
        if (!state.isRecovery) {
            state = RodV9State.SEARCHING
            // aquisição: a janela se aproxima do candidato validado (movimento limitado pela
            // dead zone/suavização/maxMovePerFrame — §1); nunca em recuperação, que tem âncora
            // própria (última posição conhecida / área inicial).
            moveWindowTowards(nx, ny)
        }
        val why = if (freshRequired) "reconfirmação" else "confirmação"
        snapshot.reason = "$why: ${det.reason}"
        log.d(
            Tags.ROD_V9, "confirming",
            "[ROD_V9] $why candidato streak=$streak/$required score=${"%.2f".format(c.score)} " +
                "conf=${"%.2f".format(det.confidence)} c=(${(c.cx).toInt()},${(c.cy).toInt()})",
        )
    }

    /** alvo confirmado pelo detector visual: a janela segue, o alvo é publicado (§3) */
    private fun onConfirmedTarget(
        c: RodButtonCandidateV9,
        det: RodButtonV9Result,
        required: Int,
        w: Int,
        h: Int,
        nowNs: Long,
    ) {
        val nx = c.cx / w
        val ny = c.cy / h
        previousX = lastKnownX
        previousY = lastKnownY
        lastKnownX = nx
        lastKnownY = ny
        streak = det.confirmation
        anchorX = nx
        anchorY = ny
        streakStartNs = nowNs
        confidence = det.confidence
        lostSinceNs = NO_TIME
        recoverySinceNs = NO_TIME
        recoveryStage = 0
        exhausted = false
        freshRequired = false
        state = RodV9State.TRACKING
        moveWindowTowards(nx, ny)
        snapshot.candidateFound = true
        snapshot.targetFound = true
        snapshot.targetNotFound = false
        snapshot.targetX = nx
        snapshot.targetY = ny
        snapshot.confidence = confidence
        snapshot.confirmation = streak
        snapshot.score = c.score
        snapshot.lastKnownX = lastKnownX
        snapshot.lastKnownY = lastKnownY
        snapshot.previousX = previousX
        snapshot.previousY = previousY
        snapshot.centerPx.x = c.cx
        snapshot.centerPx.y = c.cy
        snapshot.radiusPx = c.r
        snapshot.reason = "TARGET_FOUND (tracking) ${det.confirmation}/${required}"
        log.i(
            Tags.ROD_V9, "found",
            "[ROD_V9] TARGET_FOUND center=(${(c.cx).toInt()},${(c.cy).toInt()}) " +
                "r=${"%.1f".format(c.r)} score=${"%.2f".format(c.score)} " +
                "conf=${"%.2f".format(confidence)} streak=$streak/$required roi=${snapshot.roiString()}",
        )
    }

    private fun onMiss(nowNs: Long, dtSec: Float, hadCandidate: Boolean) {
        streak = 0
        // decaimento por TEMPO: comportamento idêntico a 15 ou 60 FPS
        confidence = (confidence * exp(-dtSec / v9.confidenceDecaySec)).coerceIn(0f, 1f)
        snapshot.candidateFound = false
        snapshot.targetFound = false
        snapshot.targetX = Float.NaN
        snapshot.targetY = Float.NaN
        snapshot.score = 0f
        snapshot.confidence = confidence
        snapshot.confirmation = 0
        if (lostSinceNs == NO_TIME) lostSinceNs = nowNs
        val lostMs = (nowNs - lostSinceNs) / 1_000_000L
        snapshot.lostMs = lostMs

        if (state == RodV9State.TRACKING) {
            // §7: um frame ausente não significa que o alvo morreu — mas o detector também nunca
            // publica uma posição que não vê.
            state = RodV9State.TARGET_LOST
            snapshot.reason = "TARGET_LOST (alvo ausente na janela, ${lostMs}ms)"
            log.w(Tags.ROD_V9, "lost", "[ROD_V9] TARGET_LOST (${lostMs}ms sem detecção) → recuperação")
            return
        }
        if (lostSinceNs != NO_TIME && lostMs <= v9.lostGraceMs) {
            state = when {
                state == RodV9State.INITIAL -> RodV9State.INITIAL
                lastKnownX.isFinite() -> RodV9State.TARGET_LOST
                else -> RodV9State.SEARCHING
            }
            snapshot.reason = if (lastKnownX.isFinite()) {
                "TARGET_LOST ${lostMs}ms/${v9.lostGraceMs}ms (aguardando)"
            } else {
                "SEARCHING ${lostMs}ms/${v9.lostGraceMs}ms (sem candidato na janela)"
            }
            return
        }
        enterRecovery(nowNs, hadCandidate)
    }

    /**
     * §7 — recuperação em etapas. Estágios 1/2 ampliam a busca em torno da **última posição
     * conhecida**; o estágio 3 volta à **área inicial configurada**; esgotado o orçamento, o
     * detector responde `TARGET_NOT_FOUND` (e recomeça a escada — um alvo que volta é detectado
     * de novo, nunca uma posição inventada).
     */
    private fun enterRecovery(nowNs: Long, hadCandidate: Boolean) {
        if (recoverySinceNs == NO_TIME) {
            recoverySinceNs = nowNs
            recoveryStage = 1
            exhausted = false
        }
        val elapsed = (nowNs - recoverySinceNs) / 1_000_000L
        if (elapsed > v9.targetLostTimeout) {
            if (!exhausted) {
                exhausted = true
                log.w(
                    Tags.ROD_V9, "notfound",
                    "[ROD_V9] TARGET_NOT_FOUND (${elapsed}ms de recuperação, estágios 1..3 esgotados) " +
                        "lastKnown=(${if (lastKnownX.isFinite()) (lastKnownX * snapshot.frameW).toInt() else -1}," +
                        "${if (lastKnownY.isFinite()) (lastKnownY * snapshot.frameH).toInt() else -1})",
                )
            }
            recoverySinceNs = nowNs
            recoveryStage = 1
        } else {
            recoveryStage = stageFor(elapsed)
        }
        // sem alvo confirmado antes, não há o que "recuperar": a busca continua SEARCHING (a
        // escada apenas amplia a janela) — dizer RECOVERING ali seria mentir para o usuário.
        state = if (lastKnownX.isFinite()) RodV9State.RECOVERING else RodV9State.SEARCHING
        snapshot.targetNotFound = exhausted
        snapshot.reason = if (state == RodV9State.RECOVERING) {
            "RECOVERING etapa $recoveryStage/$RECOVERY_STAGES " +
                "(busca ampliada, alvo não encontrado${if (hadCandidate) ": candidato rejeitado" else ""})"
        } else {
            "SEARCHING etapa $recoveryStage/$RECOVERY_STAGES da escada " +
                "(busca ampliada${if (hadCandidate) ", candidato rejeitado" else ""})" +
                (if (exhausted) " | TARGET_NOT_FOUND" else "")
        }
        log.i(
            Tags.ROD_V9, "recovery",
            "[ROD_V9] ${state.name} etapa=$recoveryStage rota=${recoveryWindow().describe()} " +
                "lastKnown=(${if (lastKnownX.isFinite()) (lastKnownX * snapshot.frameW).toInt() else -1}," +
                "${if (lastKnownY.isFinite()) (lastKnownY * snapshot.frameH).toInt() else -1})",
        )
    }

    private fun stageFor(elapsedMs: Long): Int = when {
        elapsedMs <= v9.targetLostTimeout / 3 -> 1
        elapsedMs <= (v9.targetLostTimeout * 2) / 3 -> 2
        else -> 3
    }

    // ---------------------------------------------------------------------------------------
    //  geometria da janela (§1/§4/§9/§10/§11/§12)
    // ---------------------------------------------------------------------------------------

    private fun currentWindow(): NormRegion = when (state) {
        RodV9State.RECOVERING -> recoveryWindow()
        // a escada também amplia a busca antes de existir um alvo: o estado continua SEARCHING,
        // mas a janela usada é a ampliada (é a mesma escada §7, sem inventar um "alvo perdido")
        RodV9State.SEARCHING -> if (recoveryStage == 0) baseWindow() else ladderWindow()
        // TARGET_LOST mantém a janela onde ela estava (carência) — nada de teleporte
        else -> baseWindow()
    }

    private fun baseWindow(): NormRegion =
        fitInside(NormRegion(roiX, roiY, roiX + baseW, roiY + baseH))

    private fun initialWindow(): NormRegion =
        fitInside(
            NormRegion(
                v9.initialRoiX, v9.initialRoiY,
                v9.initialRoiX + baseW, v9.initialRoiY + baseH,
            ),
        )

    private fun recoveryWindow(): NormRegion {
        val ax = if (lastKnownX.isFinite()) lastKnownX else roiX + baseW * 0.5f
        val ay = if (lastKnownY.isFinite()) lastKnownY else roiY + baseH * 0.5f
        return when (recoveryStage) {
            1 -> fitInside(centered(ax, ay, baseW * v9.recoveryExpansion, baseH * v9.recoveryExpansion))
            2 -> fitInside(
                centered(
                    ax, ay,
                    min(baseW * v9.recoveryExpansion * v9.recoveryExpansion, LADDER_MAX_FRACTION),
                    min(baseH * v9.recoveryExpansion * v9.recoveryExpansion, LADDER_MAX_FRACTION),
                ),
            )
            // §7 etapa 3: a área inicial configurada é o último recurso
            else -> initialWindow()
        }
    }

    /**
     * A mesma escada, usada **antes de existir um alvo**: âncora é a janela inicial (não há
     * `lastKnownTarget` para honrar). É o caso "a ROI começou longe do botão" da spec §12.
     */
    private fun ladderWindow(): NormRegion {
        val ax = roiX + baseW * 0.5f
        val ay = roiY + baseH * 0.5f
        return when (recoveryStage) {
            1 -> fitInside(centered(ax, ay, baseW * v9.recoveryExpansion, baseH * v9.recoveryExpansion))
            2 -> fitInside(
                centered(
                    ax, ay,
                    min(baseW * v9.recoveryExpansion * v9.recoveryExpansion, LADDER_MAX_FRACTION),
                    min(baseH * v9.recoveryExpansion * v9.recoveryExpansion, LADDER_MAX_FRACTION),
                ),
            )
            else -> initialWindow()
        }
    }

    private fun centered(cx: Float, cy: Float, w: Float, h: Float): NormRegion =
        NormRegion(cx - w * 0.5f, cy - h * 0.5f, cx + w * 0.5f, cy + h * 0.5f)

    /**
     * §11 — a janela nunca sai da tela: o tamanho é mantido e o retângulo é *deslocado* para
     * dentro (só encolhe se for fisicamente maior que a tela inteira).
     */
    private fun fitInside(region: NormRegion): NormRegion {
        val w = min(region.width, 1f)
        val h = min(region.height, 1f)
        val cx = region.centerX.coerceIn(w * 0.5f, 1f - w * 0.5f)
        val cy = region.centerY.coerceIn(h * 0.5f, 1f - h * 0.5f)
        return NormRegion(cx - w * 0.5f, cy - h * 0.5f, cx + w * 0.5f, cy + h * 0.5f)
    }

    /**
     * §1/§4/§9/§10 — move a janela na direção do alvo (já validado): nada dentro da dead zone,
     * com suavização, e nunca mais que [AppConfig.RodButtonV9.maxMovePerFrame] por frame — um
     * candidato suspeito não pode fazer a ROI saltar a tela.
     */
    private fun moveWindowTowards(nx: Float, ny: Float) {
        val cx = roiX + baseW * 0.5f
        val cy = roiY + baseH * 0.5f
        val dxT = nx - cx
        val dyT = ny - cy
        if (abs(dxT) <= v9.deadZone && abs(dyT) <= v9.deadZone) return
        val sx = cx * v9.smoothing + nx * (1f - v9.smoothing)
        val sy = cy * v9.smoothing + ny * (1f - v9.smoothing)
        val dx = (sx - cx).coerceIn(-v9.maxMovePerFrame, v9.maxMovePerFrame)
        val dy = (sy - cy).coerceIn(-v9.maxMovePerFrame, v9.maxMovePerFrame)
        val moved = fitInside(centered(cx + dx, cy + dy, baseW, baseH))
        snapshot.moved = true
        roiX = moved.left
        roiY = moved.top
    }

    // ---------------------------------------------------------------------------------------
    //  validação (§5) e exigências de confirmação
    // ---------------------------------------------------------------------------------------

    /**
     * §5 — um candidato só conta depois de: score de piso, tamanho plausível (faixa calibrada),
     * inteiramente dentro do frame e espacialmente consistente com a última posição conhecida
     * enquanto existe um lock.
     *
     * @return `null` quando o candidato é válido; caso contrário, o motivo legível da recusa.
     */
    private fun validationFailure(c: RodButtonCandidateV9, w: Int, h: Int, tolerance: Float): String? {
        if (!c.score.isFinite()) return "score não finito"
        if (c.score < CANDIDATE_FLOOR) {
            return "score ${"%.2f".format(c.score)} < piso ${"%.2f".format(CANDIDATE_FLOOR)}"
        }
        if (c.cx < c.r * 0.5f || c.cy < c.r * 0.5f ||
            c.cx > w - c.r * 0.5f || c.cy > h - c.r * 0.5f
        ) {
            return "borda do frame (c=(${c.cx.toInt()},${c.cy.toInt()}) r=${"%.1f".format(c.r)})"
        }
        val rNorm = c.r / w
        if (rNorm < v9.minSizeNormalized * SIZE_BAND_SLACK_LO) {
            return "tamanho ${"%.4f".format(rNorm)}W < mínimo " +
                "${"%.4f".format(v9.minSizeNormalized * SIZE_BAND_SLACK_LO)}W"
        }
        if (rNorm > v9.maxSizeNormalized * SIZE_BAND_SLACK_HI) {
            return "tamanho ${"%.4f".format(rNorm)}W > máximo " +
                "${"%.4f".format(v9.maxSizeNormalized * SIZE_BAND_SLACK_HI)}W"
        }
        if (lastKnownX.isFinite() && state != RodV9State.INITIAL) {
            val d = hypot(c.cx / w - lastKnownX, c.cy / h - lastKnownY)
            if (d > tolerance) {
                return "inconsistência espacial d=${"%.3f".format(d)} > tol=${"%.3f".format(tolerance)}"
            }
        }
        return null
    }

    /**
     * Tolerância de consistência espacial: em tracking é [AppConfig.RodButtonV9.maxTargetJump];
     * em recuperação cresce com a janela (deliberadamente ampliada), porque procurar mais longe é
     * exatamente o propósito daqueles estágios.
     */
    private fun jumpTolerance(window: NormRegion): Float =
        if (state.isRecovery) max(v9.maxTargetJump, 0.5f * min(window.width, window.height))
        else v9.maxTargetJump

    /** §5/§11 — frames exigidos no FPS medido, nunca abaixo do mínimo configurado */
    private fun requiredFrames(): Int {
        val fromTime = (v9.targetConfirmMs / 1000f * fps).roundToInt()
        return max(v9.confirmationFrames, fromTime.coerceIn(1, MAX_CONFIRM_FRAMES))
    }

    /** §9 — dispara a captura de diagnóstico nos quatro casos exigidos pela spec */
    private fun maybeDiagnose(
        frame: VisionFrame,
        window: NormRegion,
        nowNs: Long,
        hadCandidate: Boolean,
        lowConfidence: Boolean,
    ) {
        if (diagnostics === RodFrameDiagnostics.NONE) return
        val event = when {
            exhausted -> RodDiagEvent.TARGET_NOT_FOUND
            snapshot.targetFound -> RodDiagEvent.CONFIRMED
            lowConfidence && hadCandidate -> RodDiagEvent.LOW_CONFIDENCE
            snapshot.candidateFound -> RodDiagEvent.CANDIDATE_FOUND
            state.isRecovery -> RodDiagEvent.RECOVERING
            else -> RodDiagEvent.NO_CANDIDATE
        }
        // o sink (Android) aplica o intervalo mínimo; aqui só evitamos inundar em rajadas de
        // frames idênticos dentro do mesmo instante de tempo.
        if (nowNs == lastDiagNs && event == RodDiagEvent.NO_CANDIDATE) return
        lastDiagNs = nowNs
        val note = buildString {
            append("estado=").append(state.name)
            append(" detector=").append(snapshot.detectorState.name)
            append(" candidatos=").append(snapshot.candidates)
            append(" score=").append("%.2f".format(snapshot.score))
            append(" conf=").append("%.2f".format(snapshot.confidence))
            append(" roi=").append(window.describe())
            append(" lastKnown=(")
            append(if (lastKnownX.isFinite()) (lastKnownX * frame.width).toInt() else -1).append(',')
            append(if (lastKnownY.isFinite()) (lastKnownY * frame.height).toInt() else -1).append(')')
            if (exhausted) append(" TARGET_NOT_FOUND")
        }
        runCatching { diagnostics.onRodFrame(event, frame, window, snapshot, note) }
    }

    /** descrição em uma linha da janela em vigor (log + overlay §8) */
    fun configSummary(): String =
        "janela=${"%.2f".format(baseW)}x${"%.2f".format(baseH)} inicial=(" +
            "${"%.2f".format(v9.initialRoiX)},${"%.2f".format(v9.initialRoiY)}) " +
            "maxMove=${"%.3f".format(v9.maxMovePerFrame)} deadZone=${"%.3f".format(v9.deadZone)} " +
            "smooth=${"%.2f".format(v9.smoothing)} confMin=${"%.2f".format(v9.minimumConfidence)} " +
            "frames=${v9.confirmationFrames} expansao=${"%.2f".format(v9.recoveryExpansion)} " +
            "recovery=${v9.targetLostTimeout}ms | " + detector.configSummary()

    companion object {
        /** sentinela de "ainda não aconteceu" (o instante 0 do relógio monotônico é válido) */
        private const val NO_TIME = -1L

        /**
         * Teto da janela de recuperação, em fração do frame. A etapa 2 expande a janela por
         * `recoveryExpansion²` (3,24× no padrão) e, num frame largo, isso virava a **tela inteira**:
         * buscando o frame todo o V9 encontrou uma estrutura grande e bem fechada na pedra/margem
         * (fechamento 0,92, raio 43px) e publicou um alvo numa cena **sem botão** — medido no teste
         * da cena sem botão. O teto mantém a busca ampliada como "área maior em volta da âncora"
         * (spec §11) sem transformar a recuperação numa varredura de tela cheia.
         */
        private const val LADDER_MAX_FRACTION = 0.72f

        /** abaixo disso o frame não tem evidência utilizável alguma */
        private const val CANDIDATE_FLOOR = 0.30f

        /** a faixa de tamanho tolera a diferença entre hipóteses (círculo × caixa) com folga */
        private const val SIZE_BAND_SLACK_LO = 0.6f
        private const val SIZE_BAND_SLACK_HI = 1.4f

        private const val MAX_CONFIRM_FRAMES = 12

        /** estágios da recuperação (ampliada → mais ampliada → área inicial) */
        const val RECOVERY_STAGES = 3

        /** resposta explícita quando o orçamento de recuperação se esgota (spec §7) */
        const val TARGET_NOT_FOUND = "TARGET_NOT_FOUND"

        /** resposta explícita quando existe alvo validado e confirmado */
        const val TARGET_FOUND = "TARGET_FOUND"
    }
}
