package com.fischa.core.tracking

import com.fischa.core.config.AppConfig
import org.junit.Assert.*
import org.junit.Test

class TrackersTest {
    private val cfg = AppConfig().validate().tracking
    private val ms = 1_000_000L

    @Test fun fishTrackerEstimatesVelocityAndPredicts() {
        val t = FishTracker(cfg)
        var now = 0L
        var x = 0.20f
        repeat(20) {
            t.update(now, x, 0.9f, 300f)
            x += 0.01f      // +0.30 bar-widths/s at 30 fps
            now += 33 * ms
        }
        assertTrue(t.out.valid)
        assertFalse(t.out.lost)
        assertEquals(0.30f, t.out.v, 0.08f)
        assertEquals(t.out.x + t.out.v * 0.1f, t.predictX(0.1f), 1e-5f)
        assertTrue(t.out.x in 0f..1f)
    }

    @Test fun fishTrackerCoastsThroughShortOcclusionThenFlagsLost() {
        val t = FishTracker(cfg)
        var now = 0L
        var x = 0.30f
        repeat(15) { t.update(now, x, 0.9f, 300f); x += 0.01f; now += 33 * ms }
        val xBefore = t.out.x
        // short occlusion (< fishMaxLostMs): still valid, position extrapolated, confidence decays
        now += 100 * ms
        t.update(now, null, 0f, 300f)
        assertTrue(t.out.valid)
        assertFalse(t.out.lost)
        assertTrue(t.out.x > xBefore)
        assertTrue(t.out.confidence < 0.9f)
        // long loss: lost → controller/safety must stop using it
        now += (cfg.fishMaxLostMs + 50) * ms
        t.update(now, null, 0f, 300f)
        assertTrue(t.out.lost)
        assertFalse(t.out.valid)
    }

    @Test fun fishTrackerClampsOutOfRangeMeasurements() {
        val t = FishTracker(cfg)
        t.update(0L, 1.7f, 0.9f, 300f)
        assertTrue(t.out.x <= 1f)
        t.update(33 * ms, -0.4f, 0.9f, 300f)
        assertTrue(t.out.x >= 0f)
    }

    @Test fun playerTrackerReportsEdgesAndLoss() {
        val t = PlayerBarTracker(cfg)
        var now = 0L
        repeat(10) {
            t.update(now, 0.97f, 0.2f, 0.9f, false, 100f, 400f, 370f, 400f)
            now += 33 * ms
        }
        assertTrue(t.out.valid)
        assertTrue(t.out.atRightEdge)
        now += (cfg.blockMaxLostMs + 50) * ms
        t.update(now, null, 0f, 0f, false, 100f, 400f, 0f, 0f)
        assertTrue(t.out.lost)
    }

    @Test fun barTrackerLocksAndUnlocksWithHysteresis() {
        val t = BarTracker(cfg)
        val rect = FloatArray(4)
        assertTrue(t.update(100f, 200f, 400f, 215f, 0.9f, rect))
        assertEquals(100f, rect[0], 1e-3f)
        // moderately low confidence keeps the lock (hysteresis) ...
        assertTrue(t.update(100f, 200f, 400f, 215f, (cfg.barLockMinConf + cfg.barUnlockConf) / 2f, rect))
        // ... very low confidence unlocks
        assertFalse(t.update(100f, 200f, 400f, 215f, cfg.barUnlockConf - 0.05f, rect))
    }

    @Test fun confidenceTrackerAggregatesAndFlagsControlReadiness() {
        val c = ConfidenceTracker(cfg)
        repeat(20) { c.update(0.9f, 0.8f, 0.8f, it * 33 * ms) }
        assertTrue(c.controlReady)
        assertTrue(c.global > 0.7f)
        repeat(20) { c.update(0f, 0f, 0f, (20 + it) * 33 * ms) }
        assertFalse(c.controlReady)
        assertTrue(c.global < 0.1f)
    }
}
