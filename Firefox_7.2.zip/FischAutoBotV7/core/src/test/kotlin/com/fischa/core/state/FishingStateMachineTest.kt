package com.fischa.core.state

import com.fischa.core.config.AppConfig
import org.junit.Assert.*
import org.junit.Test

class FishingStateMachineTest {
    private fun evidence(now: Long, block: Evidence.() -> Unit = {}) = Evidence().apply {
        robloxForeground = true
        captureHealthy = true
        globalConf = .9f
        nowNs = now
        block()
    }

    /** V5 rod-button gate evidence: visually confirmed rod + safety authorization. */
    private fun rodGate(e: Evidence) {
        e.fishingButton = true
        e.fishingButtonConf = .9f
        e.rodConfirmed = true
        e.castAuthorized = true
    }

    @Test fun fullCycleRequiresVisualCatchConfirmationAndRecovery() {
        val machine = FishingStateMachine(AppConfig.StateTiming())
        machine.armed = true
        var time = 0L
        fun step(block: Evidence.() -> Unit = {}) {
            machine.update(evidence(time, block))
            time += 33_000_000L
        }
        step { rodGate(this) }
        assertEquals(FishingState.WAITING_FOR_ROD, machine.state)
        step { rodGate(this) }
        assertEquals(FishingState.CASTING, machine.state)
        // cast released → WAITING_FOR_WATER (V5 §7: no immediate shake, wait for evidence)
        step { rodGate(this); castComplete = true }
        assertEquals(FishingState.WAITING_FOR_WATER, machine.state)
        step { shake = true; shakeConf = .9f }
        assertEquals(FishingState.SEARCHING_SHAKE, machine.state)
        step { shake = true; shakeConf = .9f }
        assertEquals(FishingState.PRESSING_SHAKE, machine.state)
        repeat(3) { step { bar = true; barConf = .9f } }
        assertEquals(FishingState.FISHING_MINIGAME_DETECTED, machine.state)
        step { bar = true; barConf = .9f; fishOk = true; playerOk = true }
        assertEquals(FishingState.TRACKING_FISH, machine.state)
        step { bar = true; barConf = .9f; fishOk = true; playerOk = true }
        assertEquals(FishingState.CONTROLLING_PLAYER_BAR, machine.state)
        repeat(7) { step { bar = true; barConf = .9f; progress = .9f; fishOk = true; playerOk = true } }
        repeat(6) { step { progress = .9f } }
        assertEquals(FishingState.CATCH_CONFIRMATION, machine.state)
        step { catchConfirm = true; catchConfirmConf = .9f }
        assertEquals(FishingState.RESET, machine.state)
        repeat(40) {
            if (machine.state != FishingState.WAITING_FOR_ROD) step { fishingButton = true }
        }
        assertEquals(FishingState.WAITING_FOR_ROD, machine.state)
    }

    @Test fun confirmationTimeoutDoesNotAssumeCatchOrImmediatelyRecast() {
        val timing = AppConfig.StateTiming(confirmWindowMs = 200, catchMinProgress = .3f)
        val machine = FishingStateMachine(timing)
        machine.armed = true
        var time = 0L
        fun step(block: Evidence.() -> Unit = {}) {
            machine.update(evidence(time, block))
            time += 33_000_000L
        }
        step { rodGate(this) }; step { rodGate(this) }
        step { castComplete = true }
        step { shake = true; shakeConf = .9f }; step { shake = true; shakeConf = .9f }
        repeat(3) { step { bar = true; barConf = .9f } }
        step { bar = true; barConf = .9f; fishOk = true; playerOk = true }
        step { bar = true; barConf = .9f; fishOk = true; playerOk = true }
        repeat(7) { step { bar = true; barConf = .9f; progress = .8f; fishOk = true; playerOk = true } }
        repeat(6) { step { progress = .8f } }
        assertEquals(FishingState.CATCH_CONFIRMATION, machine.state)
        repeat(8) { step() }
        assertEquals(FishingState.VISION_LOST, machine.state)
    }

    // ---- V5 §4/§22: the rod-button gate ------------------------------------------------

    @Test fun waitingForRodOnlyExitsViaConfirmedRodAndAuthorization() {
        val machine = FishingStateMachine(AppConfig.StateTiming())
        machine.armed = true
        var time = 0L
        fun step(block: Evidence.() -> Unit = {}) {
            machine.update(evidence(time, block))
            time += 33_000_000L
        }
        step()
        assertEquals(FishingState.WAITING_FOR_ROD, machine.state)
        // rod visible but NOT confirmed (single frame / not stable yet) → stay waiting
        step { fishingButton = true; fishingButtonConf = .9f }
        assertEquals(FishingState.WAITING_FOR_ROD, machine.state)
        // confirmed but not authorized (e.g. realInput OFF / Roblox not foreground) → stay
        step { fishingButton = true; fishingButtonConf = .9f; rodConfirmed = true; castAuthorized = false }
        assertEquals(FishingState.WAITING_FOR_ROD, machine.state)
        // low confidence confirmation attempt → stay
        step { fishingButton = true; fishingButtonConf = .2f; rodConfirmed = false; castAuthorized = true }
        assertEquals(FishingState.WAITING_FOR_ROD, machine.state)
        // shake or bar alone must NOT start anything while waiting for the rod (spec §4)
        step { shake = true; shakeConf = .9f }
        assertEquals(FishingState.WAITING_FOR_ROD, machine.state)
        step { bar = true; barConf = .9f }
        assertEquals(FishingState.WAITING_FOR_ROD, machine.state)
        // only the full gate opens CASTING
        step { rodGate(this) }
        assertEquals(FishingState.CASTING, machine.state)
    }

    @Test fun newCycleRequiresFreshRodConfirmationAfterCatch() {
        val machine = FishingStateMachine(AppConfig.StateTiming())
        machine.armed = true
        var time = 0L
        fun step(block: Evidence.() -> Unit = {}) {
            machine.update(evidence(time, block))
            time += 33_000_000L
        }
        step { rodGate(this) }; step { rodGate(this) }
        assertEquals(FishingState.CASTING, machine.state)
        step { rodGate(this); castComplete = true }
        assertEquals(FishingState.WAITING_FOR_WATER, machine.state)
        step { shake = true; shakeConf = .9f }; step { shake = true; shakeConf = .9f }
        repeat(3) { step { bar = true; barConf = .9f } }
        step { bar = true; barConf = .9f; fishOk = true; playerOk = true }
        step { bar = true; barConf = .9f; fishOk = true; playerOk = true }
        repeat(7) { step { bar = true; barConf = .9f; progress = .9f; fishOk = true; playerOk = true } }
        repeat(6) { step { progress = .9f } }
        assertEquals(FishingState.CATCH_CONFIRMATION, machine.state)
        step { catchConfirm = true; catchConfirmConf = .9f }
        assertEquals(FishingState.RESET, machine.state)
        repeat(40) {
            if (machine.state != FishingState.WAITING_FOR_ROD) step { fishingButton = true }
        }
        assertEquals(FishingState.WAITING_FOR_ROD, machine.state)
        // rod visible again but not yet re-confirmed → no new cast
        repeat(2) { step { fishingButton = true; fishingButtonConf = .9f } }
        assertEquals(FishingState.WAITING_FOR_ROD, machine.state)
        // only after a fresh confirmation (+ authorization) does the new cycle begin
        step { rodGate(this) }
        assertEquals(FishingState.CASTING, machine.state)
    }

    @Test fun waitingForWaterReturnsToRodWatchOnTimeoutWithoutCasting() {
        val timing = AppConfig.StateTiming(waitingForWaterMs = 300)
        val machine = FishingStateMachine(timing)
        machine.armed = true
        var time = 0L
        fun step(block: Evidence.() -> Unit = {}) {
            machine.update(evidence(time, block))
            time += 33_000_000L
        }
        step { rodGate(this) }; step { rodGate(this) }
        step { rodGate(this); castComplete = true }
        assertEquals(FishingState.WAITING_FOR_WATER, machine.state)
        // no shake, no bar → safety timeout returns to the rod watch (never a timer-initiated cast)
        repeat(10) { step { rodGate(this) } }
        assertEquals(FishingState.WAITING_FOR_ROD, machine.state)
        // and from there the cycle only restarts through a fresh rod confirmation (next test)
    }
}
