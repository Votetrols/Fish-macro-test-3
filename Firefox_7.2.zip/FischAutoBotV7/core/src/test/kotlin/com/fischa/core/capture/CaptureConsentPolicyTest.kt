package com.fischa.core.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * V6 spec §19 — Activity Result cases.
 *
 *   1. Activity Result RESULT_OK      → [resultOkProceeds]
 *   2. Activity Result cancelado      → [userCancellationIsNotAnError]
 *   3. data null                      → [nullDataBlocksCapture]
 *   4. MediaProjection manager null   → [missingManagerBlocksCapture]
 *   5. exceção de getMediaProjection  → see CaptureDiagnosticsTest (failure keeps the class/message)
 */
class CaptureConsentPolicyTest {

    private val resultOk = -1 // Activity.RESULT_OK

    @Test fun resultOkProceeds() {
        val e = CaptureConsentPolicy.evaluate(resultOk, dataPresent = true, managerPresent = true)
        assertEquals(ConsentDecision.PROCEED, e.decision)
        assertTrue(CaptureConsentPolicy.mayStartCapture(e))
        assertTrue(e.logLine.startsWith("CAPTURE_PERMISSION_RESULT"))
        assertTrue(e.logLine.contains("resultCode=-1"))
        assertTrue(e.logLine.contains("dataPresent=true"))
        assertTrue(e.logLine.contains("failureReason=none"))
    }

    @Test fun userCancellationIsNotAnError() {
        val e = CaptureConsentPolicy.evaluate(0, dataPresent = false, managerPresent = true)
        assertEquals(ConsentDecision.RESULT_NOT_OK, e.decision)
        assertTrue(CaptureConsentPolicy.isUserCancellation(e))
        assertTrue(e.logLine.contains("failureReason=RESULT_NOT_OK(0)"))
        assertFalse(CaptureConsentPolicy.mayStartCapture(e))
        assertTrue(e.friendlyMessage().contains("negada"))
    }

    @Test fun otherNonOkResultIsReported() {
        val e = CaptureConsentPolicy.evaluate(2, dataPresent = true, managerPresent = true)
        assertEquals(ConsentDecision.RESULT_NOT_OK, e.decision)
        assertTrue(e.reason.contains("RESULT_NOT_OK(2)"))
        assertFalse(CaptureConsentPolicy.isUserCancellation(e))
    }

    @Test fun nullDataBlocksCapture() {
        val e = CaptureConsentPolicy.evaluate(resultOk, dataPresent = false, managerPresent = true)
        assertEquals(ConsentDecision.DATA_MISSING, e.decision)
        assertTrue(e.logLine.contains("failureReason=DATA_NULL"))
        assertFalse(CaptureConsentPolicy.mayStartCapture(e))
    }

    @Test fun dataWithoutTokenBlocksCapture() {
        val e = CaptureConsentPolicy.evaluate(resultOk, dataPresent = true, managerPresent = true, dataHasToken = false)
        assertEquals(ConsentDecision.DATA_MISSING, e.decision)
        assertTrue(e.logLine.contains("failureReason=DATA_WITHOUT_TOKEN"))
    }

    @Test fun missingManagerBlocksCapture() {
        val e = CaptureConsentPolicy.evaluate(resultOk, dataPresent = true, managerPresent = false)
        assertEquals(ConsentDecision.MANAGER_UNAVAILABLE, e.decision)
        assertTrue(e.logLine.contains("failureReason=MANAGER_UNAVAILABLE"))
        assertFalse(CaptureConsentPolicy.mayStartCapture(e))
    }

    @Test fun missingResultCodeBlocksCapture() {
        val e = CaptureConsentPolicy.evaluate(null, dataPresent = false, managerPresent = true)
        assertEquals(ConsentDecision.RESULT_NOT_OK, e.decision)
        assertTrue(e.logLine.contains("resultCode=-1"))
    }

    @Test fun consentNeverStartsCaptureByItself() {
        // Even a PROCEED decision only authorizes starting the foreground service; the capture
        // machine still has to walk AUTHORIZED → STARTING → RUNNING.
        val e = CaptureConsentPolicy.evaluate(resultOk, true, true)
        val m = CaptureSessionState()
        m.requestPermission()
        m.authorized()
        assertFalse(m.state.producesFrames)
        assertTrue(m.state == CaptureState.AUTHORIZED)
        assertTrue(CaptureConsentPolicy.mayStartCapture(e))
    }
}
