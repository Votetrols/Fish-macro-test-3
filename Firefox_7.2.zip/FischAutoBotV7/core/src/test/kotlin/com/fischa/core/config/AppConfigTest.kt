package com.fischa.core.config

import org.junit.Assert.*
import org.junit.Test

class AppConfigTest {
    @Test fun defaultsValidateAndFlatOverridesRoundTrip() {
        val defaults = AppConfig().validate()
        val roundTrip = AppConfig().withOverrides(defaults.toMap()).validate()
        assertEquals(defaults.toMap(), roundTrip.toMap())
    }

    @Test fun allSerializedControllerAndShakeDurationsAreApplied() {
        val edited = AppConfig().withOverrides(mapOf(
            "control.tapHoldPeriodMs" to "360",
            "control.tapHoldDurMs" to "300",
            "shake.tapDurMs" to "80",
        )).validate()
        assertEquals(360, edited.control.tapHoldPeriodMs)
        assertEquals(300, edited.control.tapHoldDurMs)
        assertEquals(80, edited.shake.tapDurMs)
    }

    @Test fun invalidSafetyBoundsAreRejected() {
        assertThrows(IllegalArgumentException::class.java) {
            AppConfig(safety = AppConfig.Safety(maxHoldLeaseMs = 900)).validate()
        }
        assertThrows(IllegalArgumentException::class.java) {
            AppConfig(control = AppConfig.Control(tapBand = .01f, deadband = .02f)).validate()
        }
        assertThrows(IllegalArgumentException::class.java) {
            AppConfig(safety = AppConfig.Safety(maxTapMs = 50), shake = AppConfig.Shake(tapDurMs = 60)).validate()
        }
    }
}
