package com.fischa.core.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * V6 spec §19 items 13/14 — missing frame and stale frame.
 *
 * V5 showed `frame age: 9223372036854775807 ms` (= Long.MAX_VALUE) when no frame had ever arrived.
 * V6 must show `N/A` and must keep every consumer fail-closed while there is no frame.
 */
class FrameAgeTest {

    @Test fun noFrameIsNA() {
        val tracker = FrameStatsTracker()
        assertFalse(tracker.hasFrame)
        assertEquals(FrameAge.NONE, tracker.frameAgeMs(1_000_000_000L))
        assertEquals("N/A", FrameAge.format(tracker.frameAgeMs(1_000_000_000L)))
        // Long.MAX_VALUE must never be produced by the V6 helper
        assertTrue(tracker.frameAgeMs(1_000_000_000L) != Long.MAX_VALUE)
    }

    @Test fun frameAgeIsComputedFromTheFrameStamp() {
        val tracker = FrameStatsTracker()
        tracker.onReceived(5_000_000_000L)
        tracker.onProcessed(5_000_000_000L)
        assertEquals(37L, tracker.frameAgeMs(5_037_000_000L))
        assertEquals("37 ms", FrameAge.format(tracker.frameAgeMs(5_037_000_000L)))
    }

    @Test fun staleFrameIsDetectedAndMissingFrameIsStale() {
        assertTrue(FrameAge.isStale(400L, maxAgeMs = 350L))
        assertFalse(FrameAge.isStale(120L, maxAgeMs = 350L))
        // fail-closed: no frame counts as stale
        assertTrue(FrameAge.isStale(FrameAge.NONE, maxAgeMs = 350L))
        assertTrue(FrameAge.isStale(Long.MAX_VALUE, maxAgeMs = 350L))
    }

    @Test fun countersTrackReceivedProcessedDropped() {
        val tracker = FrameStatsTracker()
        repeat(10) { tracker.onReceived(1_000_000_000L + it * 33_000_000L) }
        repeat(7) { tracker.onProcessed(1_000_000_000L + it * 33_000_000L) }
        tracker.onDropped(3)
        tracker.onGated(5)
        val counters = tracker.counters()
        assertEquals(10L, counters.received)
        assertEquals(7L, counters.processed)
        assertEquals(3L, counters.dropped)
        assertEquals(5L, counters.gated)
        assertTrue(counters.describe().contains("dropped=3"))
    }

    @Test fun resetClearsTheFrame() {
        val tracker = FrameStatsTracker()
        tracker.onReceived(42L)
        assertTrue(tracker.hasFrame)
        tracker.reset()
        assertFalse(tracker.hasFrame)
        assertEquals("N/A", FrameAge.format(tracker.frameAgeMs(1_000L)))
    }
}
