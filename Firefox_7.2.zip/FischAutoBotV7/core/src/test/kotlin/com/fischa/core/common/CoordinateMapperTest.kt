package com.fischa.core.common

import org.junit.Assert.*
import org.junit.Test

/**
 * Spec §3: CAPTURE → NORMALIZED → DEVICE must be one consistent transformation. Geometry used
 * here is the Galaxy A22 (SM-A225, 720×1600 HD+) in landscape, plus the A22 5G (1080×2400).
 */
class CoordinateMapperTest {

    @Test fun a22LandscapeCaptureSizeKeepsAspectAndIsEven() {
        val size = CoordinateMapper.captureSizeFor(1600, 720, 640)
        assertEquals(640, size[0])
        assertEquals(288, size[1])
        val m = CoordinateMapper(size[0], size[1], 1600, 720)
        assertTrue(m.isConsistent(1f))
        assertEquals(0f, m.aspectMismatch, 1e-4f)
    }

    @Test fun a22PortraitAndA225gAlsoConsistent() {
        val p = CoordinateMapper.captureSizeFor(720, 1600, 640)
        assertEquals(640, p[0]); assertEquals(1422, p[1])
        assertTrue(CoordinateMapper(p[0], p[1], 720, 1600).isConsistent(2f))
        val g = CoordinateMapper.captureSizeFor(2400, 1080, 640)
        assertEquals(640, g[0]); assertEquals(288, g[1])
        assertTrue(CoordinateMapper(g[0], g[1], 2400, 1080).isConsistent(2f))
    }

    @Test fun captureToDeviceIsUniformScaleOnA22() {
        val m = CoordinateMapper(640, 288, 1600, 720)
        // bar center seen at capture px (320, 200) must land at device px (800, 500)
        val p = m.captureToDevice(320f, 200f)
        assertEquals(800f, p.x, 0.01f)
        assertEquals(500f, p.y, 0.01f)
        // normalized intermediate
        assertEquals(0.5f, m.normX(320f), 1e-6f)
        assertEquals(200f / 288f, m.normY(200f), 1e-6f)
        // device → capture inverse round trip
        val back = m.deviceToCapture(p.x, p.y)
        assertEquals(320f, back.x, 0.01f)
        assertEquals(200f, back.y, 0.01f)
    }

    @Test fun cornersStayInsideDeviceBounds() {
        val m = CoordinateMapper(640, 288, 1600, 720)
        val tl = m.normalizedToDevice(0f, 0f)!!
        val br = m.normalizedToDevice(1f, 1f)!!
        assertEquals(0f, tl.x, 0f); assertEquals(0f, tl.y, 0f)
        assertEquals(1599f, br.x, 0f); assertEquals(719f, br.y, 0f)
    }

    @Test fun invalidNormalizedPointsAreRejectedNotClamped() {
        val m = CoordinateMapper(640, 288, 1600, 720)
        assertNull(m.normalizedToDevice(1.01f, 0.5f))
        assertNull(m.normalizedToDevice(-0.001f, 0.5f))
        assertNull(m.normalizedToDevice(Float.NaN, 0.5f))
        assertNull(m.normalizedToDevice(0.5f, Float.POSITIVE_INFINITY))
        assertFalse(CoordinateMapper.isValidNormalized(2f, 0f))
    }

    @Test fun aspectMismatchIsDetected() {
        // capture taken from a 16:9 source but touches sent to a 20:9 display: must be flagged
        val wrong = CoordinateMapper(640, 360, 1600, 720)
        assertFalse(wrong.isConsistent(2f))
        assertTrue(wrong.aspectMismatch > 0.1f)
        // the even-rounding done by captureSizeFor stays far inside the engine's 2 px tolerance
        val a22 = CoordinateMapper.captureSizeFor(720, 1600, 640)
        assertTrue(CoordinateMapper(a22[0], a22[1], 720, 1600).isConsistent(2f))
        // a whole-pixel aspect error (640x289 for a 20:9 panel) is ~5 px at the far corner: tolerated
        // only with an explicit looser tolerance, flagged with the engine default
        val almost = CoordinateMapper(640, 289, 1600, 720)
        assertFalse(almost.isConsistent(2f))
        assertTrue(almost.isConsistent(8f))
    }

    @Test fun rectNormalizationMatchesPointNormalization() {
        val m = CoordinateMapper(640, 288, 1600, 720)
        val out = FloatArray(4)
        m.captureRectToNormalized(64f, 144f, 576f, 160f, out)
        assertEquals(0.1f, out[0], 1e-6f)
        assertEquals(0.5f, out[1], 1e-6f)
        assertEquals(0.9f, out[2], 1e-6f)
        assertEquals(160f / 288f, out[3], 1e-6f)
    }

    @Test fun rejectsDegenerateSizes() {
        assertThrows(IllegalArgumentException::class.java) { CoordinateMapper(0, 288, 1600, 720) }
        assertThrows(IllegalArgumentException::class.java) { CoordinateMapper(640, 288, 1600, 0) }
    }
}
