package com.fischa.core.capture

import org.junit.Assert.*
import org.junit.Test

class FrameBufferTest {
    @Test fun newestPendingFrameReplacesOldAndBufferStaysBounded() {
        val buffer = FrameBuffer(8, 4, 3)
        val first = buffer.acquireWritable()!!
        first.resetFor(10, 1)
        assertTrue(buffer.publish(first))
        val second = buffer.acquireWritable()!!
        second.resetFor(20, 2)
        assertTrue(buffer.publish(second))
        assertEquals(1, buffer.pendingCount())
        assertEquals(1L, buffer.droppedFrames())
        val latest = buffer.takeLatest()!!
        assertEquals(2L, latest.serial)
        assertNull(buffer.takeLatest())
        buffer.release(latest)
        val reused = buffer.acquireWritable()
        assertNotNull(reused)
        buffer.cancelWrite(reused!!)
        buffer.close()
        assertTrue(buffer.isClosed())
        assertNull(buffer.takeLatest())
    }

    @Test fun producerDoesNotWaitWhenAllSlotsAreLeased() {
        val buffer = FrameBuffer(8, 4, 2)
        val a = buffer.acquireWritable()!!
        val b = buffer.acquireWritable()!!
        assertNull(buffer.acquireWritable())
        assertEquals(1L, buffer.droppedFrames())
        buffer.cancelWrite(a)
        buffer.cancelWrite(b)
        buffer.close()
    }
}
