package com.fischa.core.tracking

import com.fischa.core.config.AppConfig
import org.junit.Assert.*
import org.junit.Test

/** V5 §5 — temporal rod-button confirmation: consecutive frames, confidence, stability, window. */
class RodConfirmTrackerTest {

    private class Rig(cfg: AppConfig.Rod = AppConfig.Rod()) {
        val tracker = RodConfirmTracker(cfg)
        var t = 0L
        fun tick(detected: Boolean, conf: Float, x: Float = 0.8f, y: Float = 0.7f): Boolean {
            val r = tracker.update(detected, conf, x, y, t)
            t += 33_000_000L
            return r
        }
    }

    @Test fun confirmsOnlyAfterConfiguredConsecutiveFrames() {
        val rig = Rig()
        assertFalse(rig.tick(true, 0.9f))
        assertFalse(rig.tick(true, 0.9f))
        assertTrue("3rd consecutive stable frame confirms", rig.tick(true, 0.9f))
        assertTrue(rig.tick(true, 0.9f))
        assertEquals(4, rig.tracker.streakFrames)
    }

    @Test fun singleFrameIsNeverEnough() {
        val rig = Rig(AppConfig.Rod(confirmFrames = 1))
        assertTrue("with confirmFrames=1 a single frame confirms (configurable)", rig.tick(true, 0.9f))
        val rig2 = Rig()
        repeat(10) { rig2.tick(true, 0.9f) }
        // a flickering detection (miss every other frame) never accumulates
        val rig3 = Rig()
        var confirmed = false
        repeat(12) { confirmed = rig3.tick(it % 2 == 0, 0.9f) }
        assertFalse(confirmed)
    }

    @Test fun lowConfidenceNeverConfirms() {
        val rig = Rig()
        var confirmed = false
        repeat(10) { confirmed = rig.tick(true, 0.4f) } // below 0.55 threshold
        assertFalse(confirmed)
        assertEquals(0, rig.tracker.streakFrames)
    }

    @Test fun unstablePositionRestartsTheStreak() {
        val rig = Rig()
        assertFalse(rig.tick(true, 0.9f, 0.80f, 0.70f))
        assertFalse(rig.tick(true, 0.9f, 0.80f, 0.70f))
        // jump beyond tolerance → streak restarts at the new anchor
        assertFalse(rig.tick(true, 0.9f, 0.83f, 0.71f))
        assertFalse(rig.tick(true, 0.9f, 0.83f, 0.71f))
        assertTrue(rig.tick(true, 0.9f, 0.83f, 0.71f))
    }

    @Test fun streakBeyondWindowNeverConfirms() {
        val rig = Rig()
        var confirmed = false
        repeat(5) {
            confirmed = rig.tick(true, 0.9f)
            rig.t += 800_000_000L // slow frames: streak spans > confirmWindowMs
        }
        assertFalse(confirmed)
    }

    @Test fun disappearanceAndResetClearConfirmation() {
        val rig = Rig()
        repeat(3) { rig.tick(true, 0.9f) }
        assertTrue(rig.tracker.confirmed)
        assertFalse(rig.tick(false, 0f))
        assertFalse(rig.tracker.confirmed)
        rig.tracker.reset()
        assertEquals(0, rig.tracker.streakFrames)
        assertFalse(rig.tracker.confirmed)
    }

    @Test fun invalidCoordinatesNeverConfirm() {
        val rig = Rig()
        var confirmed = false
        repeat(5) { confirmed = rig.tick(true, 0.9f, Float.NaN, 0.7f) }
        assertFalse(confirmed)
        repeat(5) { confirmed = rig.tick(true, 0.9f, 1.5f, 0.7f) }
        assertFalse(confirmed)
    }
}
