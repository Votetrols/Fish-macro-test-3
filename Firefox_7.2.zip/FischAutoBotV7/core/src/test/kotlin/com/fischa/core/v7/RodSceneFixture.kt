package com.fischa.core.v7

import com.fischa.core.vision.VisionFrame

/**
 * Synthetic scenes for the V7 detection tests. The rod button is drawn with exactly the visual
 * signature the finder looks for — dark semi-transparent disc + brighter ring + small mid-gray
 * hook glyph — and can be placed **anywhere** on the frame, at any size, so the tests can prove
 * the detector is not tied to a coordinate.
 */
object RodSceneFixture {

    data class Rod(
        val cx: Int,
        val cy: Int,
        val interiorR: Int = 30,
        val ringR: Int = 40,
        val glyph: Boolean = true,
        val glyphGray: Int = 0xA0,
        val interiorGray: Int = 0x28,
        val ringGray: Int = 0x6E,
    )

    const val BG = 0x78

    fun draw(
        frame: VisionFrame,
        rod: Rod?,
        bg: Int = BG,
        noise: Int = 0,
        seed: Long = 7L,
        whiteText: Boolean = false,
        whiteTextCenter: Pair<Int, Int>? = null,
    ) {
        frame.argb.fill(grayToArgb(bg))
        var rnd = seed
        if (noise > 0) {
            val variance = noise * noise
            for (i in frame.argb.indices) {
                rnd = rnd * 6364136223846793005L + 1442695040888963407L
                val d = (((rnd ushr 33) % (2L * variance + 1)) - variance).toInt()
                val g = (bg + d).coerceIn(0, 255)
                frame.argb[i] = grayToArgb(g)
            }
        }
        if (rod != null) {
            for (y in 0 until frame.height) {
                for (x in 0 until frame.width) {
                    val dx = x - rod.cx
                    val dy = y - rod.cy
                    val d2 = dx * dx + dy * dy
                    when {
                        d2 <= rod.interiorR * rod.interiorR -> frame.argb[y * frame.width + x] = grayToArgb(rod.interiorGray)
                        d2 <= rod.ringR * rod.ringR -> frame.argb[y * frame.width + x] = grayToArgb(rod.ringGray)
                        else -> Unit
                    }
                }
            }
            if (rod.glyph) {
                val gx = rod.cx - 6
                val gy = rod.cy + 4
                val gr = (rod.interiorR / 3).coerceAtLeast(4)
                for (y in gy - gr..gy + gr) {
                    for (x in gx - gr..gx + gr) {
                        if ((x - gx) * (x - gx) + (y - gy) * (y - gy) <= gr * gr &&
                            x in 0 until frame.width && y in 0 until frame.height
                        ) {
                            frame.argb[y * frame.width + x] = grayToArgb(rod.glyphGray)
                        }
                    }
                }
            }
        }
        if (whiteText) {
            val (tx, ty) = whiteTextCenter ?: (220 to 60)
            // a "SHAKE"-like prompt: bright glyphs inside a dark disc (the V6 false-positive shape)
            val discR = 34
            for (y in ty - discR..ty + discR) {
                for (x in tx - discR..tx + discR) {
                    if (x !in 0 until frame.width || y !in 0 until frame.height) continue
                    val d2 = (x - tx) * (x - tx) + (y - ty) * (y - ty)
                    if (d2 <= discR * discR) frame.argb[y * frame.width + x] = grayToArgb(0x26)
                }
            }
            // thick bright bars (≈12 % of the disc, like real "SHAKE" text) — thick enough that a
            // detector has to *see* the text, not just a couple of stray bright pixels
            for (row in 0 until 3) {
                for (dy in 0 until 4) {
                    val y = ty - 10 + row * 10 + dy
                    for (x in tx - 18..tx + 18) {
                        if (x in 0 until frame.width && y in 0 until frame.height) {
                            frame.argb[y * frame.width + x] = grayToArgb(0xFF)
                        }
                    }
                }
            }
        }
    }

    fun grayToArgb(g: Int): Int = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
}
