package com.fischa.core.pipeline

import com.fischa.core.config.AppConfig
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.RecordingExecutor
import com.fischa.core.safety.RobloxForegroundStatus
import com.fischa.core.state.FishingState
import com.fischa.core.vision.VisionFrame
import org.junit.Assert.*
import com.fischa.core.safety.RealInputPolicy
import org.junit.After
import org.junit.Before
import org.junit.Test

/**
 * V5 §22 — START semantics and the rod-button gate, tested end-to-end through the real
 * VisionPipeline with synthetic frames (a drawn rod button on a 640×288 A22-landscape frame).
 *
 * Covered:
 *   1. START não executa input.                7. realInput OFF → input bloqueado.
 *   2. Estado inicial após captura = WAITING_FOR_ROD.
 *   3. Rod não detectado → nenhum input.       8. Emergency Stop → input bloqueado.
 *   4. Rod confidence baixa → nenhum input.    9. Captura inválida → input bloqueado.
 *   5. Rod confirmado → CAST permitido.       10. Frame stale → input bloqueado.
 *   6. Roblox ausente → input bloqueado.      11/12. (FishingStateMachineTest: catch →
 *                                                WAITING_FOR_ROD; novo ciclo só após nova
 *                                                confirmação da vara.)
 */
class StartSemanticsV5Test {

    // V7 §10: the shipped app hard-locks REAL_INPUT while the detection is validated.
    // This legacy suite verifies the *unlocked* input chain (V5/V6 behaviour), so the lock
    // is explicitly released for its duration and restored afterwards. The lock itself is
    // covered by the V7 suite (`V7RealInputLockTest`).
    @Before fun unlockRealInputForLegacyInputTests() {
        RealInputPolicy.unlockForTesting("legacy input-chain test (unlocked path)")
    }

    @After fun restoreRealInputLock() {
        RealInputPolicy.lock()
    }


    companion object {
        const val W = 640
        const val H = 288
        // on the FishingButtonDetector search grid, at the calibrated prior (0.818, 0.692)
        const val ROD_CX = 520
        const val ROD_CY = 199
        const val ROD_R = 36
    }

    /** Draws the synthetic scene: uniform background + optional rod button (dark disc, bright
     *  ring, mid-gray hook glyph — exactly the features FishingButtonDetector scores). */
    private fun drawFrame(frame: VisionFrame, withRod: Boolean) {
        val bg = 0xFF787878.toInt()       // gray 120
        val interior = 0xFF282828.toInt() // gray 40
        val ring = 0xFF6E6E6E.toInt()     // gray 110
        val glyph = 0xFFA0A0A0.toInt()    // gray 160 (mid-gray hook glyph)
        frame.argb.fill(bg)
        if (withRod) {
            for (y in 0 until H) {
                for (x in 0 until W) {
                    val dx = x - ROD_CX
                    val dy = y - ROD_CY
                    val d2 = dx * dx + dy * dy
                    frame.argb[y * W + x] = when {
                        d2 < 30 * 30 -> interior
                        d2 <= 40 * 40 -> ring
                        else -> bg
                    }
                }
            }
            // hook glyph: small mid-gray disc inside the button (not white → not a Shake prompt)
            val gx = ROD_CX - 6
            val gy = ROD_CY + 4
            for (y in gy - 10..gy + 10) {
                for (x in gx - 10..gx + 10) {
                    if ((x - gx) * (x - gx) + (y - gy) * (y - gy) <= 100 && x in 0 until W && y in 0 until H) {
                        frame.argb[y * W + x] = glyph
                    }
                }
            }
        }
    }

    private fun newFrame(tsNs: Long, serial: Long, withRod: Boolean): VisionFrame {
        val f = VisionFrame.allocate(W, H)
        drawFrame(f, withRod)
        f.resetFor(tsNs, serial)
        return f
    }

    /** Test rig: fake monotonic clock + authorized foreground provider + recording executor. */
    private inner class Rig(
        cfg: AppConfig = AppConfig().validate(),
        val exec: RecordingExecutor = RecordingExecutor(),
        val emergency: EmergencyStop = EmergencyStop(),
    ) {
        var nowNs = 1_000_000_000L
        val pipeline = VisionPipeline(
            cfg = cfg,
            executor = exec,
            log = ThrottledLog(NoopSink),
            emergency = emergency,
            foregroundStatusProvider = {
                RobloxForegroundStatus(
                    foregroundPackage = "com.roblox.client",
                    robloxDetected = true,
                    inputAuthorized = true,
                    blockReason = "NONE",
                    timestampMs = nowNs / 1_000_000L,
                )
            },
            monotonicNowNs = { nowNs },
        )
        var serial = 0L

        fun step(
            withRod: Boolean,
            realInput: Boolean = true,
            authorized: Boolean = true,
            captureHealthy: Boolean = true,
            frameAgeMs: Long = 0,
        ) {
            val frame = newFrame(nowNs, ++serial, withRod)
            pipeline.onFrame(frame, PipelineInput(
                frameTimestampNs = nowNs,
                currentTimeNs = nowNs + frameAgeMs * 1_000_000L,
                captureHealthy = captureHealthy,
                robloxDetected = authorized,
                inputAuthorized = authorized,
                macroEnabled = true,
                realInputEnabled = realInput,
                foregroundPackage = if (authorized) "com.roblox.client" else "com.android.launcher",
                foregroundBlockReason = if (authorized) "NONE" else "FOREGROUND_PACKAGE_MISMATCH",
            ))
            nowNs += 33_000_000L
        }

        fun gameInputCalls() = exec.calls.filter {
            it == "tap" || it == "holdStart" || it == "holdExtend"
        }
    }

    // ---- 1/2/3: START only starts the infrastructure; initial state; no rod → no input ----

    @Test fun startDoesNotExecuteInputAndInitialStateIsWaitingForRod() {
        val rig = Rig()
        rig.pipeline.armed = true // what FischEngineService does on START
        repeat(12) { rig.step(withRod = false) }
        assertEquals("estado inicial após START/captura deve ser WAITING_FOR_ROD",
            FishingState.WAITING_FOR_ROD, rig.pipeline.output.state)
        assertTrue("START não pode executar nenhum gesto", rig.gameInputCalls().isEmpty())
        assertTrue("nada foi emitido ao executor", rig.exec.calls.none { it.startsWith("tap") || it.startsWith("hold") })
        assertFalse(rig.pipeline.output.rodDetected)
        rig.pipeline.close()
    }

    @Test fun rodNotDetectedMeansZeroInput() {
        val rig = Rig()
        rig.pipeline.armed = true
        repeat(12) { rig.step(withRod = false) }
        assertEquals(FishingState.WAITING_FOR_ROD, rig.pipeline.output.state)
        assertFalse(rig.pipeline.output.rodDetected)
        assertTrue(rig.gameInputCalls().isEmpty())
        rig.pipeline.close()
    }

    // ---- 4: low rod confidence → zero input ----------------------------------------

    @Test fun lowRodConfidenceMeansZeroInput() {
        // V7: the finder reaches a high natural confidence on a clean synthetic button, so the
        // "too low" threshold used to probe the gate must sit above it (the gate itself — no
        // confirmation above the configured threshold → no input — is unchanged from V6).
        val cfg = AppConfig().withOverrides(mapOf("rod.confidenceThreshold" to "0.995")).validate()
        val rig = Rig(cfg = cfg)
        rig.pipeline.armed = true
        repeat(12) { rig.step(withRod = true) }
        // vision sees the rod, but it never passes ROD_CONFIDENCE_THRESHOLD → never confirmed
        assertTrue(rig.pipeline.output.rodDetected)
        assertFalse(rig.pipeline.output.rodConfirmed)
        assertEquals(FishingState.WAITING_FOR_ROD, rig.pipeline.output.state)
        assertTrue(rig.gameInputCalls().isEmpty())
        rig.pipeline.close()
    }

    // ---- 5: rod confirmed → CAST allowed -------------------------------------------

    @Test fun confirmedRodAuthorizesCast() {
        val rig = Rig()
        rig.pipeline.armed = true
        var sawConfirmed = false
        var sawAuthorizedWhileWatching = false
        repeat(12) {
            rig.step(withRod = true)
            if (rig.pipeline.output.rodDetected) sawConfirmed = rig.pipeline.output.rodConfirmed
            if (rig.pipeline.output.state == FishingState.WAITING_FOR_ROD && rig.pipeline.output.castAuthorized) {
                sawAuthorizedWhileWatching = true
            }
        }
        assertTrue("vara detectada e confirmada (3 frames estáveis + confiança)", sawConfirmed)
        assertTrue("gate de cast autorizado enquanto em WAITING_FOR_ROD", sawAuthorizedWhileWatching)
        assertEquals(FishingState.CASTING, rig.pipeline.output.state)
        assertTrue("cast inicia com HOLD_START", rig.exec.calls.contains("holdStart"))
        rig.pipeline.close()
    }

    // ---- 6: Roblox absent → input blocked -------------------------------------------

    @Test fun robloxAbsentBlocksInput() {
        val rig = Rig()
        rig.pipeline.armed = true
        repeat(10) { rig.step(withRod = true, authorized = false) }
        assertEquals(FishingState.WAITING_FOR_ROD, rig.pipeline.output.state)
        assertFalse(rig.pipeline.output.inputAuthorized)
        assertFalse(rig.pipeline.output.castAuthorized)
        assertEquals("ROBLOX_NOT_DETECTED", rig.pipeline.output.castGateReason)
        assertTrue(rig.gameInputCalls().isEmpty())
        rig.pipeline.close()
    }

    // ---- 7: realInput OFF (default) → input blocked, WOULD_CAST logged --------------

    @Test fun realInputOffBlocksInputButStillReportsRodDetected() {
        val rig = Rig()
        rig.pipeline.armed = true
        repeat(12) { rig.step(withRod = true, realInput = false) }
        assertFalse("START não ativa realInput", rig.pipeline.output.realInputEnabled)
        assertTrue("vara detectada", rig.pipeline.output.rodDetected)
        assertTrue("vara confirmada", rig.pipeline.output.rodConfirmed)
        assertFalse("cast NÃO autorizado com realInput OFF", rig.pipeline.output.castAuthorized)
        assertEquals("REAL_INPUT_DISABLED", rig.pipeline.output.castGateReason)
        assertEquals("permanece observando: WAITING_FOR_ROD", FishingState.WAITING_FOR_ROD, rig.pipeline.output.state)
        assertTrue("nenhum gesto real", rig.gameInputCalls().isEmpty())
        assertTrue("executor nunca chamado", rig.exec.calls.none { it.startsWith("tap") || it.startsWith("hold") })
        rig.pipeline.close()
    }

    // ---- 8: Emergency Stop → input blocked -------------------------------------------

    @Test fun emergencyStopBlocksInput() {
        val rig = Rig()
        rig.pipeline.armed = true
        rig.emergency.activate("test")
        repeat(12) { rig.step(withRod = true) }
        assertTrue(rig.pipeline.output.emergencyLatched)
        assertFalse(rig.pipeline.output.castAuthorized)
        assertEquals("EMERGENCY_STOP", rig.pipeline.output.castGateReason)
        assertTrue(rig.gameInputCalls().isEmpty())
        assertTrue("emergência cancela/libera gestos", rig.exec.calls.contains("cancelAll"))
        rig.emergency.clear()
        rig.pipeline.close()
    }

    // ---- 9: invalid capture → input blocked ------------------------------------------

    @Test fun invalidCaptureBlocksInput() {
        val rig = Rig()
        rig.pipeline.armed = true
        repeat(6) { rig.step(withRod = true, captureHealthy = false) }
        assertFalse(rig.pipeline.output.castAuthorized)
        assertEquals("CAPTURE_STOPPED", rig.pipeline.output.castGateReason)
        assertEquals(FishingState.CAPTURE_ERROR, rig.pipeline.output.state)
        assertTrue(rig.gameInputCalls().isEmpty())
        rig.pipeline.close()
    }

    // ---- 10: stale frame → input blocked ----------------------------------------------

    @Test fun staleFrameBlocksInput() {
        val rig = Rig()
        rig.pipeline.armed = true
        repeat(12) { rig.step(withRod = true, frameAgeMs = 500) } // > safety.maxFrameAgeMs (180)
        assertTrue(rig.pipeline.output.rodDetected)
        assertFalse("frame stale → cast não autorizado", rig.pipeline.output.castAuthorized)
        assertEquals("FRAME_STALE", rig.pipeline.output.castGateReason)
        assertEquals(FishingState.WAITING_FOR_ROD, rig.pipeline.output.state)
        assertTrue(rig.gameInputCalls().isEmpty())
        rig.pipeline.close()
    }

    // ---- extra: WAITING_FOR_WATER waits for visual evidence after the cast ------------

    @Test fun afterCastReleasePipelineWaitsForWaterEvidence() {
        val cfg = AppConfig().withOverrides(mapOf("cast.holdMs" to "500")).validate()
        val rig = Rig(cfg = cfg)
        rig.pipeline.armed = true
        // run until the cast hold completes (release issued) and the FSM moves on
        var sawCasting = false
        var sawWaitingForWater = false
        repeat(40) {
            rig.step(withRod = true)
            if (rig.pipeline.output.state == FishingState.CASTING) sawCasting = true
            if (rig.pipeline.output.state == FishingState.WAITING_FOR_WATER) sawWaitingForWater = true
        }
        assertTrue("o ciclo chegou ao CAST", sawCasting)
        assertTrue("após o release do cast o sistema entra em WAITING_FOR_WATER (não pesca de novo por timer)",
            sawWaitingForWater)
        assertTrue(rig.exec.calls.contains("holdStart"))
        assertTrue("o hold do cast é liberado", rig.exec.calls.contains("holdRelease"))
        rig.pipeline.close()
    }
}
