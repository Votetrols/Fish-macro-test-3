package com.fischa.core.safety

import org.junit.Assert.*
import org.junit.Test

class RobloxForegroundDetectorTest {
    private val detector = RobloxForegroundDetector()
    private val roblox = RobloxForegroundDetector.ROBLOX_PACKAGE

    @Test fun robloxForegroundIsRecognizedFromWindowAndEventEvidence() {
        val status = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = roblox,
            rootInActiveWindowPackage = roblox,
            lastWindowEventPackage = roblox,
            foregroundActivity = "com.roblox.client.GameActivity",
            activeWindow = "type=application active=true",
            timestampMs = 10,
        ))
        assertTrue(status.robloxDetected)
        assertTrue(status.inputAuthorized)
        assertEquals(roblox, status.foregroundPackage)
        assertEquals("ACTIVE_WINDOW", status.evidenceSource)
        assertEquals("NONE", status.blockReason)
    }

    @Test fun immersiveSurfaceMayUseFreshWindowEventWhenRootIsNull() {
        val status = detector.evaluate(ForegroundObservation(
            lastWindowEventPackage = roblox,
            foregroundActivity = "com.roblox.client.GameActivity",
            timestampMs = 20,
        ))
        assertTrue(status.inputAuthorized)
        assertEquals("EVENT", status.evidenceSource)
    }

    // ---- the Galaxy A22 real-test failure: fullscreen Roblox, no accessibility root, no new events

    @Test fun fullscreenRobloxWithoutRootStaysDetectedViaVerifiedActivityLongAfterTheEvent() {
        val status = detector.evaluate(ForegroundObservation(
            // no live sources at all
            activeAppWindowPackage = null,
            rootInActiveWindowPackage = null,
            activeAppWindowRootMissing = true,
            // legacy event is old (would have aged out → FOREGROUND_UNKNOWN in the old rule)
            lastWindowEventPackage = roblox,
            lastWindowEventTimestampMs = 1_000,
            // verified activity transition 5 minutes ago
            lastActivityPackage = roblox,
            lastActivityClass = "com.roblox.client.ActivityNativeMain",
            lastActivityTimestampMs = 1_000,
            timestampMs = 301_000,
        ))
        assertTrue(status.robloxDetected)
        assertTrue(status.inputAuthorized)
        assertEquals("ACTIVITY", status.evidenceSource)
        assertEquals(roblox, status.foregroundPackage)
        assertTrue(status.foregroundActivityWindow.contains("ActivityNativeMain"))
    }

    @Test fun laterVerifiedActivityOfAnotherAppReplacesRoblox() {
        val status = detector.evaluate(ForegroundObservation(
            lastActivityPackage = "com.sec.android.app.launcher",
            lastActivityClass = "com.sec.android.app.launcher.activities.LauncherActivity",
            lastActivityTimestampMs = 5_000,
            lastWindowEventPackage = roblox,
            lastWindowEventTimestampMs = 4_900, // fresh but lower-trust than the verified activity
            timestampMs = 5_100,
        ))
        assertFalse(status.robloxDetected)
        assertFalse(status.inputAuthorized)
        assertEquals("FOREGROUND_PACKAGE_MISMATCH", status.blockReason)
        assertEquals("com.sec.android.app.launcher", status.foregroundPackage)
    }

    @Test fun liveWindowOfAnotherAppOverridesRobloxActivityEvidence() {
        val status = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = "com.samsung.android.game.gametools",
            lastActivityPackage = roblox,
            lastActivityClass = "com.roblox.client.ActivityNativeMain",
            lastActivityTimestampMs = 10,
            timestampMs = 20,
        ))
        assertFalse(status.robloxDetected)
        assertEquals("FOREGROUND_PACKAGE_MISMATCH", status.blockReason)
        assertEquals("com.samsung.android.game.gametools", status.foregroundPackage)
    }

    @Test fun liveRobloxRootWinsEvenIfActivityEvidenceIsMissing() {
        val status = detector.evaluate(ForegroundObservation(
            rootInActiveWindowPackage = roblox,
            timestampMs = 20,
        ))
        assertTrue(status.inputAuthorized)
        assertEquals("ROOT", status.evidenceSource)
    }

    @Test fun activityEvidenceCanBeAgedOutWhenConfigured() {
        val strict = RobloxForegroundDetector(maxActivityAgeMs = 60_000)
        val fresh = strict.evaluate(ForegroundObservation(
            lastActivityPackage = roblox, lastActivityClass = "A", lastActivityTimestampMs = 1_000, timestampMs = 30_000,
        ))
        assertTrue(fresh.inputAuthorized)
        val old = strict.evaluate(ForegroundObservation(
            lastActivityPackage = roblox, lastActivityClass = "A", lastActivityTimestampMs = 1_000, timestampMs = 90_000,
        ))
        assertFalse(old.inputAuthorized)
        assertEquals("FOREGROUND_UNKNOWN", old.blockReason)
    }

    // ---- legacy fail-closed rules keep holding

    @Test fun otherAndUnknownPackagesFailClosed() {
        val other = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = "com.android.launcher",
            lastWindowEventPackage = "com.android.launcher",
            timestampMs = 30,
        ))
        assertFalse(other.robloxDetected)
        assertFalse(other.inputAuthorized)
        assertEquals("FOREGROUND_PACKAGE_MISMATCH", other.blockReason)

        val unknown = detector.evaluate(ForegroundObservation(timestampMs = 31))
        assertFalse(unknown.robloxDetected)
        assertFalse(unknown.inputAuthorized)
        assertEquals(RobloxForegroundStatus.UNKNOWN, unknown.foregroundPackage)
        assertEquals("FOREGROUND_UNKNOWN", unknown.blockReason)
    }

    @Test fun staleCachedEventCannotAuthorizeUnknownFullscreenForeground() {
        val status = detector.evaluate(ForegroundObservation(
            lastWindowEventPackage = roblox,
            timestampMs = 5_000,
            lastWindowEventTimestampMs = 1_000,
        ))
        assertFalse(status.robloxDetected)
        assertFalse(status.inputAuthorized)
        assertEquals(RobloxForegroundStatus.UNKNOWN, status.foregroundPackage)
    }

    @Test fun overlayAndConflictingWindowBlockInput() {
        val overlay = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = roblox,
            lastWindowEventPackage = roblox,
            incompatibleOverlay = true,
            timestampMs = 40,
        ))
        assertTrue(overlay.robloxDetected)
        assertFalse(overlay.inputAuthorized)
        assertEquals("INCOMPATIBLE_OVERLAY", overlay.blockReason)
        assertTrue(overlay.overlayActive)

        val conflict = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = roblox,
            rootInActiveWindowPackage = "com.android.systemui",
            lastWindowEventPackage = roblox,
            timestampMs = 41,
        ))
        assertFalse(conflict.inputAuthorized)
        assertFalse(conflict.robloxDetected)
    }

    @Test fun accessibilityUnavailableOrScreenOffCannotAuthorizeCachedRoblox() {
        val status = detector.evaluate(ForegroundObservation(
            lastWindowEventPackage = roblox,
            accessibilityAvailable = false,
            timestampMs = 50,
        ))
        assertTrue(status.robloxDetected)
        assertFalse(status.inputAuthorized)
        assertEquals("ACCESSIBILITY_UNAVAILABLE", status.blockReason)

        val off = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = roblox,
            screenInteractive = false,
            timestampMs = 51,
        ))
        assertFalse(off.inputAuthorized)
        assertEquals("SCREEN_NOT_INTERACTIVE", off.blockReason)
    }

    @Test fun whitespaceAndUnknownTokensAreNormalized() {
        val status = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = "  $roblox  ",
            rootInActiveWindowPackage = RobloxForegroundStatus.UNKNOWN,
            timestampMs = 60,
        ))
        assertTrue(status.inputAuthorized)
    }
}
