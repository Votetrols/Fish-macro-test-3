package com.fischa.core.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * V6 spec §19 — capture lifecycle tests.
 *
 * Maps to the required items:
 *   8. projection onStop              → [projectionStopAllowsCleanRetry]
 *   9. STOP libera recursos           → [stopReleasesAndAllowsRestart]
 *  10. Emergency Stop libera recursos → [emergencyStopDoesNotFabricateFishingError]
 *  11. restart depois de STOP         → [restartAfterStopUsesFreshState]
 *  12. capture state transitions      → [happyPathTransitions], [illegalTransitionsAreRejectedInStrictMode]
 *  15. START não executa CAST         → [startOnlyRequestsPermission] (FSM untouched)
 */
class CaptureStateMachineTest {

    private var now = 1_000_000_000L
    private fun machine(strict: Boolean = true) = CaptureSessionState(clockNs = { now }, strict = strict)

    private fun happyPath(m: CaptureSessionState): List<CaptureTransition> {
        m.requestPermission()
        m.authorized()
        m.serviceStarting()
        m.serviceRunning()
        m.projectionActive()
        m.running()
        return m.historySnapshot
    }

    @Test fun happyPathTransitions() {
        val m = machine()
        val history = happyPath(m)
        assertEquals(
            listOf(
                CaptureState.STOPPED to CaptureState.REQUESTING_PERMISSION,
                CaptureState.REQUESTING_PERMISSION to CaptureState.AUTHORIZED,
                CaptureState.AUTHORIZED to CaptureState.STARTING,
                CaptureState.STARTING to CaptureState.RUNNING,
            ),
            history.map { it.from to it.to },
        )
        assertEquals(CaptureState.RUNNING, m.state)
        assertEquals(ProjectionState.ACTIVE, m.projection)
        assertEquals(ServiceState.RUNNING, m.service)
        assertTrue(m.state.producesFrames)
    }

    @Test fun illegalTransitionsAreRejectedInStrictMode() {
        // RUNNING -> AUTHORIZED is nonsense (would mean "capture running without consent")
        val m = machine()
        happyPath(m)
        val thrown = runCatching { m.authorized("illegal") }.exceptionOrNull()
        assertNotNull("strict mode must reject an illegal transition", thrown)
        assertEquals(CaptureState.RUNNING, m.state)
    }

    @Test fun nonStrictModeNeverThrowsButKeepsState() {
        val m = machine(strict = false)
        happyPath(m)
        m.stopped("user stop")
        m.pausedByNobody()
        assertEquals(CaptureState.STOPPED, m.state)
    }

    @Test fun permissionDeniedDoesNotStartAnything() {
        val m = machine()
        m.requestPermission()
        m.permissionDenied("RESULT_NOT_OK(0)")
        assertEquals(CaptureState.STOPPED, m.state)
        assertEquals(ProjectionState.NONE, m.projection)
        assertEquals(ServiceState.STOPPED, m.service)
        assertTrue(m.canStartNewAttempt())
    }

    @Test fun failureKeepsOriginalCauseAndLeavesFishingMachineAlone() {
        val m = machine()
        m.requestPermission()
        m.authorized()
        val boom = SecurityException("Media projections require a foreground service of type FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION")
        val failure = m.fail(CaptureStage.GET_PROJECTION, boom, "FGS mediaProjection ativa antes do getMediaProjection")
        assertEquals(CaptureState.FAILED, m.state)
        assertEquals(ProjectionState.ERROR, m.projection)
        assertEquals(ServiceState.ERROR, m.service)
        assertEquals("java.lang.SecurityException", failure.error.exceptionClass)
        assertEquals(boom.message, failure.error.message)
        assertTrue(failure.summary().contains("SecurityException"))
        assertTrue(failure.summary().contains("Media projections require a foreground service"))
        // capture state has no fishing vocabulary at all (spec §15)
        assertFalse(CaptureState.FAILED.name in listOf("CAPTURE_ERROR", "VISION_LOST"))
    }

    @Test fun projectionStopAllowsCleanRetry() {
        val m = machine()
        happyPath(m)
        m.projectionStopped("MediaProjection.onStop (sistema)")
        assertEquals(CaptureState.STOPPED, m.state)
        assertEquals(ProjectionState.STOPPED, m.projection)
        assertTrue(m.canStartNewAttempt())
        assertFalse(m.holdsResources())
        // a second session must be possible without clearing anything
        val second = happyPath(m)
        assertEquals(CaptureState.RUNNING, second.last().to)
    }

    @Test fun stopReleasesAndAllowsRestart() {
        val m = machine()
        happyPath(m)
        assertTrue(m.holdsResources())
        m.stopped("STOP do usuário")
        assertFalse(m.holdsResources())
        assertEquals(CaptureState.STOPPED, m.state)
        assertEquals(ProjectionState.STOPPED, m.projection)
        assertEquals(ServiceState.STOPPED, m.service)
    }

    @Test fun emergencyStopDoesNotFabricateFishingError() {
        val m = machine()
        happyPath(m)
        // EMERGENCY STOP is a user action: it stops the capture machine and leaves lastFailure null
        m.stopped("EMERGENCY STOP")
        assertEquals(CaptureState.STOPPED, m.state)
        assertEquals(null, m.lastFailure)
        assertTrue(m.canStartNewAttempt())
    }

    @Test fun restartAfterStopUsesFreshState() {
        val m = machine()
        happyPath(m)
        m.stopped("STOP")
        m.requestPermission("novo START")
        assertEquals(CaptureState.REQUESTING_PERMISSION, m.state)
        assertEquals(ProjectionState.NONE, m.projection)
        assertEquals(ServiceState.STOPPED, m.service)
        assertEquals(null, m.lastFailure)
        // the brand-new session must be able to become RUNNING again
        m.authorized(); m.serviceStarting(); m.serviceRunning(); m.projectionActive(); m.running()
        assertEquals(CaptureState.RUNNING, m.state)
        assertEquals(ProjectionState.ACTIVE, m.projection)
    }

    @Test fun startOnlyRequestsPermission() {
        val m = machine()
        m.requestPermission("START")
        // START never jumps to RUNNING and never reaches the fishing CAST state by itself
        assertEquals(CaptureState.REQUESTING_PERMISSION, m.state)
        assertFalse(m.state.producesFrames)
        assertFalse(m.holdsResources())
    }

    @Test fun requestWhileRunningIsRefused() {
        val m = machine(strict = false)
        happyPath(m)
        m.requestPermission("START de novo")
        assertEquals(CaptureState.FAILED, m.state)
        assertNotNull(m.lastFailure)
        assertTrue(m.lastFailure!!.error.message.contains("already active"))
    }
}

/** Small helper so the test above can express "a call that must not change anything". */
private fun CaptureSessionState.pausedByNobody() {
    // intentionally empty: non-strict mode tolerates stale callbacks
}
