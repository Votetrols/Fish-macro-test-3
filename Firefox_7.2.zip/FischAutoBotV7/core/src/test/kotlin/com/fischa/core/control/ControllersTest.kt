package com.fischa.core.control

import com.fischa.core.config.AppConfig
import com.fischa.core.tracking.FishTracker
import com.fischa.core.tracking.PlayerBarTracker
import org.junit.Assert.*
import org.junit.Test

/**
 * Controller decisions depend on the *visual* error fish−player (spec §11), never on a fixed
 * cadence. Tracks are produced through the real trackers so the test exercises the same path
 * the pipeline uses.
 */
class ControllersTest {
    private val cfg = AppConfig().validate()
    private val ms = 1_000_000L

    private class Tracks(cfg: AppConfig) {
        val fish = FishTracker(cfg.tracking)
        val player = PlayerBarTracker(cfg.tracking)
        fun feed(nowNs: Long, fishX: Float, playerX: Float, conf: Float = 0.9f) {
            fish.update(nowNs, fishX, conf, 300f)
            player.update(nowNs, playerX, 0.25f, conf, false, 100f, 400f, 100f + playerX * 300f - 37f, 100f + playerX * 300f + 37f)
        }
    }

    @Test fun alignedInsideDeadbandNeverPresses() {
        val c = FishingController(cfg.control)
        val t = Tracks(cfg)
        var now = 1_000 * ms
        repeat(12) {
            t.feed(now, 0.50f, 0.50f)
            val d = c.update(now, 1f / 30f, t.fish.out, t.player.out, 0f)
            assertTrue(d.safe)
            assertEquals(ControlAction.NONE, d.action)
            assertEquals(0f, d.error, 1e-3f)
            now += 33 * ms
        }
    }

    @Test fun fishFarRightStartsHoldThenExtendsAndReleasesWhenAligned() {
        val c = FishingController(cfg.control)
        val t = Tracks(cfg)
        var now = 1_000 * ms
        // settle trackers
        repeat(5) { t.feed(now, 0.80f, 0.40f); now += 33 * ms }
        t.feed(now, 0.80f, 0.40f)
        var d = c.update(now, 1f / 30f, t.fish.out, t.player.out, 0f)
        assertEquals(ControlAction.HOLD_START, d.action)
        assertTrue("error must be positive (player left of fish)", d.error > cfg.control.holdBand)
        // keep holding while error is still large
        now += 33 * ms
        t.feed(now, 0.80f, 0.45f)
        d = c.update(now, 1f / 30f, t.fish.out, t.player.out, 0f)
        assertEquals(ControlAction.HOLD_EXTEND, d.action)
        // player reaches the fish → release (after minHold)
        now += (cfg.control.minHoldMs + 50) * ms
        repeat(6) { t.feed(now, 0.80f, 0.80f); now += 33 * ms }
        d = c.update(now, 1f / 30f, t.fish.out, t.player.out, 0f)
        assertEquals(ControlAction.HOLD_RELEASE, d.action)
        assertFalse(d.holdActive)
    }

    @Test fun fishLeftOfPlayerUsesDriftOnlyNoInput() {
        val c = FishingController(cfg.control)
        val t = Tracks(cfg)
        var now = 1_000 * ms
        repeat(8) { t.feed(now, 0.20f, 0.60f); now += 33 * ms }
        val d = c.update(now, 1f / 30f, t.fish.out, t.player.out, 0f)
        assertEquals(ControlAction.NONE, d.action)
        assertTrue(d.error < 0f)
        assertTrue(d.reason.contains("drift"))
    }

    @Test fun smallPositiveErrorProducesShortTapNotHold() {
        val c = FishingController(cfg.control)
        val t = Tracks(cfg)
        var now = 1_000 * ms
        val err = (cfg.control.deadband + cfg.control.tapBand) / 2f
        repeat(8) { t.feed(now, 0.50f + err, 0.50f); now += 33 * ms }
        val d = c.update(now, 1f / 30f, t.fish.out, t.player.out, 0f)
        assertEquals(ControlAction.TAP, d.action)
        assertTrue(d.tapDurMs in 60..cfg.control.tapDurMs * 2)
    }

    @Test fun maximumContinuousHoldIsFinite() {
        val c = FishingController(cfg.control)
        val t = Tracks(cfg)
        var now = 1_000 * ms
        repeat(5) { t.feed(now, 0.95f, 0.10f); now += 33 * ms }
        var d = c.update(now, 1f / 30f, t.fish.out, t.player.out, 0f)
        assertEquals(ControlAction.HOLD_START, d.action)
        var released = false
        repeat(200) {
            now += 33 * ms
            t.feed(now, 0.95f, 0.10f)
            d = c.update(now, 1f / 30f, t.fish.out, t.player.out, 0f)
            if (d.action == ControlAction.HOLD_RELEASE) { released = true; return@repeat }
        }
        assertTrue("hold must be released at maxHoldMs even if the error persists", released)
    }

    @Test fun lowConfidenceReleasesActiveHoldAndSuppressesNewInput() {
        val c = FishingController(cfg.control)
        val t = Tracks(cfg)
        var now = 1_000 * ms
        repeat(5) { t.feed(now, 0.90f, 0.30f); now += 33 * ms }
        assertEquals(ControlAction.HOLD_START, c.update(now, 1f / 30f, t.fish.out, t.player.out, 0f).action)
        // detector loses the fish: tracker coasts then flags lost → controller must release
        var d = c.decision
        var releasedAfterMs = -1L
        for (i in 0 until 60) {
            now += 33 * ms
            t.fish.update(now, null, 0f, 300f)
            t.player.update(now, 0.30f, 0.25f, 0.9f, false, 100f, 400f, 150f, 220f)
            d = c.update(now, 1f / 30f, t.fish.out, t.player.out, 0f)
            if (d.action == ControlAction.HOLD_RELEASE) { releasedAfterMs = (i + 1) * 33L; break }
        }
        assertEquals(ControlAction.HOLD_RELEASE, d.action)
        assertFalse(d.safe)
        // released once the tracker declared the fish lost (bounded by fishMaxLostMs + one frame)
        assertTrue("released after ${releasedAfterMs}ms", releasedAfterMs in 1..(cfg.tracking.fishMaxLostMs + 100))
        // and stays silent afterwards
        now += 33 * ms
        t.fish.update(now, null, 0f, 300f)
        d = c.update(now, 1f / 30f, t.fish.out, t.player.out, 0f)
        assertEquals(ControlAction.NONE, d.action)
        assertFalse(d.safe)
    }

    // ---- cast ------------------------------------------------------------------------------

    @Test fun castHoldStartsExtendsAndReleasesAtConfiguredDurationUsingDetectedCenter() {
        val cast = CastController(cfg.cast)
        cast.start()
        var now = 5_000 * ms
        val start = cast.tick(true, 0.9f, 0.81f, 0.69f, now)!!
        assertEquals(CastGestureAction.START, start.action)
        assertEquals(0.81f, start.nx, 1e-6f)
        assertEquals(0.69f, start.ny, 1e-6f)
        now += 33 * ms
        assertEquals(CastGestureAction.EXTEND, cast.tick(true, 0.9f, 0.81f, 0.69f, now)!!.action)
        now += cfg.cast.holdMs * ms
        val release = cast.tick(true, 0.9f, 0.81f, 0.69f, now)!!
        assertEquals(CastGestureAction.RELEASE, release.action)
        assertNull(cast.tick(true, 0.9f, 0.81f, 0.69f, now + 33 * ms))
    }

    @Test fun castReleasesImmediatelyWhenButtonVanishes() {
        val cast = CastController(cfg.cast)
        cast.start()
        val now = 5_000 * ms
        assertEquals(CastGestureAction.START, cast.tick(true, 0.9f, 0.5f, 0.5f, now)!!.action)
        val r = cast.tick(false, 0f, 0f, 0f, now + 100 * ms)!!
        assertEquals(CastGestureAction.RELEASE, r.action)
        assertEquals(CastController.Phase.WAIT_PRESS, cast.phase)
    }

    // ---- shake -----------------------------------------------------------------------------

    @Test fun shakeTapsDetectedCenterAndFollowsItWhenItMoves() {
        val s = ShakeController(cfg.shake)
        var now = 1_000 * ms
        var tap: TapRequest? = null
        repeat(cfg.shake.confirmFrames) { tap = s.tick(true, 0.9f, 0.30f, 0.40f, now); now += 33 * ms }
        assertNotNull(tap)
        assertEquals(0.30f, tap!!.nx, 1e-6f)
        assertEquals(0.40f, tap!!.ny, 1e-6f)
        // same spot right away: guarded (no spam)
        assertNull(s.tick(true, 0.9f, 0.30f, 0.40f, now))
        // prompt re-appears elsewhere after cooldown: tap at the NEW center
        now += (cfg.shake.tapCooldownMs + 5) * ms
        var moved: TapRequest? = null
        repeat(cfg.shake.confirmFrames) {
            val r = s.tick(true, 0.9f, 0.70f, 0.25f, now)
            if (r != null && moved == null) moved = TapRequest().also { o -> r.copyTo(o) }
            now += 33 * ms
        }
        assertNotNull(moved)
        assertEquals(0.70f, moved!!.nx, 1e-6f)
        assertEquals(0.25f, moved!!.ny, 1e-6f)
        assertEquals(2, s.tapsThisSession)
    }

    @Test fun shakeNeverTapsWithoutDetectionOrWithLowConfidence() {
        val s = ShakeController(cfg.shake)
        var now = 1_000 * ms
        repeat(10) { assertNull(s.tick(false, 0f, 0.5f, 0.5f, now)); now += 33 * ms }
        repeat(10) { assertNull(s.tick(true, cfg.shake.minConfidence - 0.05f, 0.5f, 0.5f, now)); now += 33 * ms }
        assertEquals(0, s.tapsThisSession)
    }
}
