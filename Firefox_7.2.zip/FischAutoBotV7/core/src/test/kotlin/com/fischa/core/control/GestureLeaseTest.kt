package com.fischa.core.control

import org.junit.Assert.*
import org.junit.Test

class GestureLeaseTest {
    private val point = GestureTarget(.42f, .61f)

    @Test fun tapHoldStartExtendReleaseAndCancel() {
        val g = GestureLease(maxLeaseMs = 250, maxContinuousMs = 1000, watchdogMs = 100)
        assertTrue(g.tap(point, 60, 1000))
        assertEquals(GestureSessionState.TAP, g.state)
        g.completeTap()
        assertEquals(0, g.activeCount)

        assertTrue(g.holdStart(point, 100, 1100))
        assertTrue(g.holdExtend(point, 100, 1150))
        assertTrue(g.shouldContinue(1200))
        assertFalse(g.holdExtend(GestureTarget(.8f, .8f), 100, 1210))
        g.holdRelease()
        assertEquals(GestureSessionState.IDLE, g.state)
        assertFalse(g.holdExtend(point, 100, 1220))

        assertTrue(g.holdStart(point, 100, 1300))
        val before = g.generation
        g.cancelAll()
        assertEquals(before + 1, g.generation)
        assertEquals(0, g.activeCount)
    }

    @Test fun leaseAndWatchdogExpireWithoutFreshExtensions() {
        val g = GestureLease(maxLeaseMs = 250, maxContinuousMs = 1000, watchdogMs = 100)
        assertTrue(g.holdStart(point, 80, 1000))
        assertFalse(g.shouldContinue(1081))
        assertEquals(GestureSessionState.IDLE, g.state)
    }

    @Test fun invalidPointsDurationsAndInfiniteHoldAreRejected() {
        val g = GestureLease(maxLeaseMs = 100, maxContinuousMs = 150, watchdogMs = 200)
        assertFalse(g.tap(GestureTarget(Float.NaN, .5f), 20, 1))
        assertFalse(g.tap(point, 600, 1))
        assertTrue(g.holdStart(point, 100, 1000))
        assertFalse(g.holdExtend(point, 100, 1151))
        assertFalse(g.shouldContinue(1151))
        assertEquals(GestureSessionState.IDLE, g.state)
    }
}
