package com.fischa.core.v7

import com.fischa.core.calib.CalibrationConfig
import com.fischa.core.config.AppConfig
import com.fischa.core.log.LogSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.vision.RodDetectionState
import com.fischa.core.vision.RodFinder
import com.fischa.core.vision.RodSnapshot
import com.fischa.core.vision.VisionFrame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.hypot

/**
 * V7 §2/§3/§4/§6/§8/§9 — the rod finder, tested on synthetic scenes drawn by [RodSceneFixture].
 *
 * The point of every test here is the same: the button is **found**, never assumed. The scene is
 * drawn at an arbitrary position, an arbitrary size and an arbitrary frame resolution, and the
 * assertions are always relative to the *truth* of the drawing (centre, radius), never to a
 * coordinate baked into the code.
 */
class V7RodFinderTest {

    private class RecordingSink : LogSink {
        val lines = ArrayList<String>()
        override fun log(level: LogSink.Level, tag: String, msg: String, timestampNs: Long) {
            lines.add("$tag|$msg")
        }
        fun any(sub: String) = lines.any { it.contains(sub) }
    }

    /** Drives the finder frame by frame with a fake clock; keeps the state trail. */
    private class Driver(
        val w: Int = 640,
        val h: Int = 288,
        val fps: Float = 30f,
        cfg: AppConfig = AppConfig().validate(),
    ) {
        val sink = RecordingSink()
        val log = ThrottledLog(sink)
        val finder = RodFinder(cfg, log)
        val periodNs: Long = (1_000_000_000.0 / fps).toLong()
        var nowNs = 1_000_000_000L
        var serial = 0L
        val states = ArrayList<RodDetectionState>()
        var last: RodSnapshot = finder.out

        fun frame(
            rod: RodSceneFixture.Rod?,
            noise: Int = 0,
            whiteText: Boolean = false,
            whiteTextCenter: Pair<Int, Int>? = null,
        ): RodSnapshot {
            val f = VisionFrame.allocate(w, h)
            RodSceneFixture.draw(f, rod, noise = noise, whiteText = whiteText, whiteTextCenter = whiteTextCenter)
            f.resetFor(nowNs, ++serial)
            f.ensureGray()
            log.setNow(nowNs)
            val snap = finder.update(f, fps, nowNs)
            nowNs += periodNs
            states.add(snap.state)
            last = snap
            return snap
        }

        fun run(
            frames: Int,
            rod: RodSceneFixture.Rod?,
            noise: Int = 0,
            whiteText: Boolean = false,
            stopWhen: (RodSnapshot) -> Boolean = { false },
        ): RodSnapshot {
            var snap = last
            repeat(frames) {
                snap = frame(rod, noise = noise, whiteText = whiteText)
                if (stopWhen(snap)) return snap
            }
            return snap
        }

        /** Runs until the rod is confirmed (or [max] frames). */
        fun confirm(rod: RodSceneFixture.Rod, max: Int = 40): RodSnapshot =
            run(max, rod) { it.state.isConfirmedFamily }

        fun indexOfFirst(state: RodDetectionState): Int = states.indexOfFirst { it == state }
    }

    // ---------------------------------------------------------------- §2.A: search anywhere

    @Test
    fun findsTheButtonAtAnyPositionAndSizeOnTheFrame() {
        // (cx, cy, interiorR, ringR) — top-left, centre, top-right, bottom, big, small
        val placements = listOf(
            intArrayOf(120, 80, 30, 40),
            intArrayOf(520, 199, 30, 40),
            intArrayOf(598, 74, 26, 35),
            intArrayOf(330, 230, 34, 46),
            intArrayOf(200, 140, 38, 50),
            intArrayOf(450, 120, 22, 30),
        )
        for (p in placements) {
            val (cx, cy, ir, rr) = p
            val d = Driver()
            // NOTE: no assert about *where* the finder looked — the button is drawn at an
            // arbitrary spot and must be found there, side of the screen included (the wide search
            // starts from the calibration estimate and widens itself when that estimate fails).
            val snap = d.confirm(RodSceneFixture.Rod(cx, cy, interiorR = ir, ringR = rr), max = 60)
            val tag = "colocado em ($cx,$cy) interior=$ir ring=$rr"
            assertTrue("não confirmou o botão $tag (estado=${snap.state} reason=${snap.reason})",
                snap.state.isConfirmedFamily)
            val dx = snap.center.x - cx
            val dy = snap.center.y - cy
            assertTrue("centro errado para o botão $tag: (${snap.center.x},${snap.center.y}) d=${hypot(dx, dy)}",
                hypot(dx, dy) <= 6f)
            assertTrue("raio fora da faixa para o botão $tag: r=${snap.radius} (esperado ~$rr)",
                snap.radius in rr * 0.75f..rr * 1.30f)
            // the snapshot must publish the same point in normalized coordinates (debug overlay)
            assertEquals(snap.center.x / 640f, snap.centerNorm.x, 1e-4f)
            assertEquals(snap.center.y / 288f, snap.centerNorm.y, 1e-4f)
        }
    }

    @Test
    fun findsTheButtonOnOtherFrameResolutionsAndScales() {
        // processing frame ≠ 640×288: a tablet-ish 960×540 and a small 480×216 (both "relative")
        val cases = listOf(
            Triple(960, 540, intArrayOf(700, 380, 46, 60)),
            Triple(480, 216, intArrayOf(390, 150, 22, 30)),
        )
        for ((w, h, p) in cases) {
            val d = Driver(w = w, h = h)
            val (cx, cy, ir, rr) = p
            val snap = d.confirm(RodSceneFixture.Rod(cx, cy, interiorR = ir, ringR = rr))
            assertTrue("frame ${w}x${h}: não confirmou (state=${snap.state} reason=${snap.reason})",
                snap.state.isConfirmedFamily)
            assertTrue("frame ${w}x${h}: centro (${snap.center.x},${snap.center.y}) != ($cx,$cy)",
                hypot(snap.center.x - cx, snap.center.y - cy) <= 7f)
            assertTrue("frame ${w}x${h}: raio ${snap.radius} != ~$rr",
                snap.radius in rr * 0.70f..rr * 1.35f)
            assertEquals(cx / w.toFloat(), snap.centerNorm.x, 0.02f)
        }
    }

    // ------------------------------------------------- §6: state sequence and confirmation gate

    @Test
    fun walksTheSpecifiedStateSequenceAndNeverConfirmsOnASingleFrame() {
        val d = Driver()
        val rod = RodSceneFixture.Rod(520, 199)
        var firstCandidateIdx = -1
        var confirmedIdx = -1
        var confirmedWithoutRequirement = false
        repeat(40) { i ->
            val snap = d.frame(rod)
            if (snap.state == RodDetectionState.CANDIDATE_FOUND && firstCandidateIdx < 0) {
                firstCandidateIdx = i
                assertFalse("um único frame não pode confirmar", snap.confirmed)
                assertTrue("streak deve começar em 1 (obtido ${snap.streak})", snap.streak == 1)
                assertTrue("requiredFrames deve ser >= 3 (adaptativo ao FPS), obtido ${snap.requiredFrames}",
                    snap.requiredFrames >= 3)
            }
            if (snap.confirmed && snap.state == RodDetectionState.ROD_CONFIRMED && confirmedIdx < 0) {
                confirmedIdx = i
                if (snap.streak < 2) confirmedWithoutRequirement = true
            }
        }
        assertTrue("nunca chegou a CANDIDATE_FOUND", firstCandidateIdx >= 0)
        assertTrue("nunca chegou a ROD_CONFIRMED", confirmedIdx >= 0)
        assertFalse("confirmou sem exigir múltiplos frames", confirmedWithoutRequirement)

        // order of the state machine (spec §6)
        assertTrue("primeiro estado deve ser AUTO_CALIBRATION (${d.states.first()})",
            d.indexOfFirst(RodDetectionState.AUTO_CALIBRATION) == 0)
        assertTrue("SEARCHING_ROD antes de CANDIDATE_FOUND",
            d.indexOfFirst(RodDetectionState.SEARCHING_ROD) < firstCandidateIdx)
        val confirming = d.indexOfFirst(RodDetectionState.CONFIRMING_ROD)
        assertTrue("CONFIRMING_ROD depois de CANDIDATE_FOUND", confirming > firstCandidateIdx)
        assertTrue("ROD_CONFIRMED depois de CONFIRMING_ROD", confirmedIdx > confirming)
        assertTrue("TRACKING_ROD depois de ROD_CONFIRMED",
            d.indexOfFirst(RodDetectionState.TRACKING_ROD) > confirmedIdx)
        // at least one frame in CONFIRMING_ROD between the candidate and the confirmation
        assertTrue("CONFIRMING_ROD precisa de >= 2 frames (candidato → confirmado)",
            confirmedIdx - firstCandidateIdx >= 2)
    }

    @Test
    fun confidenceRampsUpAcrossConfirmationAndStaysAboveTheThreshold() {
        val d = Driver()
        val confidences = ArrayList<Float>()
        val snap = d.run(40, RodSceneFixture.Rod(520, 199)) { s ->
            if (s.state == RodDetectionState.CANDIDATE_FOUND ||
                s.state == RodDetectionState.CONFIRMING_ROD ||
                s.state.isConfirmedFamily
            ) confidences.add(s.confidence)
            s.state.isConfirmedFamily
        }
        assertTrue("não confirmou (state=${snap.state})", snap.state.isConfirmedFamily)
        assertTrue("poucas amostras de confiança (${confidences.size})", confidences.size >= 3)
        for (i in 1 until confidences.size) {
            assertTrue(
                "confiança deve crescer com a confirmação temporal: ${confidences[i - 1]} → ${confidences[i]}",
                confidences[i] >= confidences[i - 1] - 1e-3f,
            )
        }
        assertTrue("confiança final baixa: ${snap.confidence}", snap.confidence >= 0.6f)
        assertTrue("streak final (${snap.streak}) deve atingir requiredFrames (${snap.requiredFrames})",
            snap.streak >= snap.requiredFrames)
        // distinct scores: the *candidate* score and the *temporal* confidence are not the same thing
        assertTrue("score=${snap.score}", snap.score > 0.3f)
        assertNotNull("calibração ausente", snap.calibration)
        assertTrue("calibração inválida", snap.calibration!!.rodSearchRegion.isValid)
        assertTrue("calibração não marcada como concluída", snap.calibrationDone)
    }

    @Test
    fun confirmationFrameCountAdaptsToFpsAndLowFpsStillConfirms() {
        val needs = HashMap<Float, Int>()
        for (fps in listOf(8f, 30f, 60f)) {
            val d = Driver(fps = fps)
            val snap = d.run(40, RodSceneFixture.Rod(520, 199)) { it.state == RodDetectionState.CANDIDATE_FOUND }
            assertTrue("fps=$fps: nunca achou candidato", snap.state == RodDetectionState.CANDIDATE_FOUND)
            needs[fps] = snap.requiredFrames
        }
        val at8 = needs[8f]!!
        val at30 = needs[30f]!!
        val at60 = needs[60f]!!
        assertTrue("contagem de confirmação não depende do FPS: 8fps=$at8 30fps=$at30 60fps=$at60",
            at8 < at30 && at30 < at60)
        // and it must still be *time* based: ≈targetConfirmMs of frames, bounded 3..12
        for (fps in listOf(8f, 30f, 60f)) {
            val expected = CalibrationConfig.framesForConfirm(fps, 120f)
            assertEquals("fps=$fps: frames de confirmação", expected, needs[fps]!!)
            assertTrue("fps=$fps: fora dos limites 3..12", needs[fps]!! in 3..12)
        }
        // low FPS is never a failure: it confirms anyway, just with fewer frames
        val slow = Driver(fps = 8f)
        val slowSnap = slow.confirm(RodSceneFixture.Rod(520, 199), max = 40)
        assertTrue("8 fps não pode ser falha automática (state=${slowSnap.state} reason=${slowSnap.reason})",
            slowSnap.state.isConfirmedFamily)
    }

    // ------------------------------------------------ §3/§4: dynamic ROI + local tracking

    @Test
    fun roiIsBuiltAroundTheDetectedButtonAndIsMuchSmallerThanTheSearch() {
        val d = Driver()
        val snapped = d.confirm(RodSceneFixture.Rod(520, 199))
        assertTrue(snapped.state.isConfirmedFamily)
        val roi = snapped.roi
        val search = snapped.searchRegion
        assertTrue("ROI inválida", roi.isValid)
        assertTrue("ROI deve conter o centro detectado", roi.contains(snapped.centerNorm.x, snapped.centerNorm.y))
        assertTrue("ROI (${roi.width}) deve ser bem menor que a busca ampla (${search.width})",
            roi.width < search.width * 0.5f)
        // padding proportional to the *detected* size: ROI ≈ 1.5×…×3.5× the button diameter
        val diameterNorm = 2f * snapped.radius / 640f
        val ratio = roi.width / diameterNorm
        assertTrue("ROI/botão = $ratio (esperado ~1.5–3.5, sem dimensão absoluta)", ratio in 1.4f..3.5f)
        // the ROI is *not* the V6 fixed region: it must sit on the button, not on a constant
        assertTrue("centro da ROI deve coincidir com o botão",
            abs(roi.centerX - snapped.centerNorm.x) <= 0.05f)
    }

    @Test
    fun roiFollowsSmallMovementsAndButtonsOfDifferentSizesGetDifferentRois() {
        val d = Driver()
        d.confirm(RodSceneFixture.Rod(520, 199))
        val before = d.last.roi
        // small movement: the local tracker must follow and update the ROI (spec §4 BUTTON_MOVED)
        val moved = d.run(10, RodSceneFixture.Rod(556, 214)) { s ->
            s.state.isConfirmedFamily && abs(s.center.x - 556f) <= 5f
        }
        assertTrue("não seguiu o movimento do botão (state=${moved.state} reason=${moved.reason})",
            moved.state.isConfirmedFamily)
        assertTrue("centro não seguiu: (${moved.center.x},${moved.center.y})",
            hypot(moved.center.x - 556f, moved.center.y - 214f) <= 6f)
        assertTrue("ROI não acompanhou o movimento (${before.centerX} → ${moved.roi.centerX})",
            moved.roi.centerX > before.centerX + 0.02f)
        // it keeps tracking locally instead of re-running the wide search every frame
        assertTrue("deveria estar em TRACKING_ROD", moved.state == RodDetectionState.TRACKING_ROD)
        assertTrue("tracking flag", moved.tracking)

        // a physically bigger button at the same frame resolution → bigger ROI (padding ∝ size)
        val big = Driver()
        val bigSnap = big.confirm(RodSceneFixture.Rod(320, 150, interiorR = 38, ringR = 50))
        assertTrue(bigSnap.state.isConfirmedFamily)
        val bigDiameter = 2f * bigSnap.radius / 640f
        assertTrue("ROI do botão grande deve ser maior que a do pequeno",
            bigSnap.roi.width / bigDiameter > 1.4f)
    }

    // ------------------------------------------------------ §4/§6: loss and auto-recovery

    @Test
    fun lossReturnsToSearchingAndReacquiresTheButtonAtItsNewPosition() {
        val d = Driver()
        val first = d.confirm(RodSceneFixture.Rod(520, 199))
        assertTrue(first.state.isConfirmedFamily)
        // the button disappears
        val lost = d.run(60, rod = null) { it.state == RodDetectionState.SEARCHING_ROD }
        assertTrue("perda não voltou para SEARCHING_ROD (state=${lost.state} reason=${lost.reason})",
            lost.state == RodDetectionState.SEARCHING_ROD)
        assertFalse("não pode continuar confirmado sem o botão", lost.confirmed)
        assertTrue("ROD_LOST precisa aparecer no caminho de recuperação",
            d.states.contains(RodDetectionState.ROD_LOST))

        // …and comes back somewhere else: the finder must *find* it again (no fixed coordinate)
        // (the new position is on the other side of the frame: the search must widen and find it)
        val again = d.run(60, RodSceneFixture.Rod(180, 120)) { it.state.isConfirmedFamily }
        assertTrue("não recuperou o botão em nova posição (state=${again.state} reason=${again.reason})",
            again.state.isConfirmedFamily)
        assertTrue("centro antigo reaproveitado: (${again.center.x},${again.center.y})",
            hypot(again.center.x - 180f, again.center.y - 120f) <= 7f)
    }

    @Test
    fun theEstimateIsNotAnAssumptionBecauseTheSearchWidensItself() {
        // a button far outside the calibrated estimate (left edge, outside the right/lower prior)
        val d = Driver()
        var firstWidth = -1f
        var widestSearch = -1f
        val found = d.run(60, RodSceneFixture.Rod(70, 200)) { s ->
            if (!s.state.isConfirmedFamily) {
                if (firstWidth < 0f) firstWidth = s.searchRegion.width
                widestSearch = maxOf(widestSearch, s.searchRegion.width)
            }
            s.state.isConfirmedFamily
        }
        assertTrue(
            "botão fora da estimativa inicial não foi encontrado (state=${found.state} " +
                "reason=${found.reason})",
            found.state.isConfirmedFamily,
        )
        assertTrue("centro errado: (${found.center.x},${found.center.y})",
            hypot(found.center.x - 70f, found.center.y - 200f) <= 7f)
        assertTrue("a região de busca deveria ter se ampliado (era $firstWidth, " +
            "chegou a $widestSearch)", widestSearch > firstWidth + 0.1f)
        assertTrue("a ampliação precisa ser registrada no log",
            d.sink.any("ampliada") || d.sink.any("expand"))
    }

    // ---------------------------------------------------------------- §9: no false positives

    @Test
    fun emptyNoisyAndTextScenesAreNeverConfirmed() {
        val scenes = listOf(
            Triple("fundo vazio", 0, false),
            Triple("ruído", 14, false),
            Triple("texto branco (falso positivo típico)", 6, true),
        )
        for ((name, noise, text) in scenes) {
            val d = Driver()
            var everDetected = false
            repeat(30) {
                val snap = d.frame(null, noise = noise, whiteText = text)
                assertFalse("cena '$name' não pode confirmar", snap.confirmed)
                assertFalse("cena '$name' não pode entrar na família confirmada (${snap.state})",
                    snap.state.isConfirmedFamily)
                if (snap.detected) everDetected = true
            }
            assertTrue("cena '$name': deveria explicar o motivo ao não confirmar (reason='${d.last.reason}')",
                d.last.reason.isNotEmpty())
            if (everDetected) {
                assertTrue("cena '$name': candidato fraco não pode ser tratado como confirmado",
                    d.last.state != RodDetectionState.ROD_CONFIRMED)
            }
        }
    }

    // ------------------------------------------------------------------- §9: logs with reason

    @Test
    fun logsStateTheReasonForEveryDecision() {
        val d = Driver()
        d.run(12, rod = null)                          // fails to detect → must say why
        val snap = d.run(40, RodSceneFixture.Rod(520, 199)) { it.state.isConfirmedFamily }
        assertTrue(snap.state.isConfirmedFamily)
        val lines = d.sink.lines
        assertTrue("faltou o log de calibração (screen=): $lines", d.sink.any("[CALIBRATION] screen="))
        assertTrue("faltou o log da região de busca", d.sink.any("[CALIBRATION] rodSearchRegion="))
        assertTrue("faltou candidates= no log de busca", d.sink.any("[ROD_SEARCH] candidates="))
        assertTrue("faltou bestScore no log de busca", d.sink.any("bestScore="))
        assertTrue("a ausência do botão precisa de motivo explícito",
            d.sink.any("no valid candidate") || d.sink.any("candidates=0"))
        assertTrue("faltou o progresso da confirmação (frame=n/m)",
            d.sink.any("[ROD_CONFIRM] frame="))
        assertTrue("faltou [ROD] CONFIRMED", d.sink.any("[ROD] CONFIRMED"))
        assertTrue("faltou o centro detectado no log", d.sink.any("[ROD] center="))
        assertTrue("faltou a ROI no log", d.sink.any("[ROD] roi="))
        assertTrue("faltou [TRACKING] ACTIVE", d.sink.any("[TRACKING] ACTIVE"))
        assertTrue("a busca deve reportar o estado", d.sink.any("[STATE] SEARCHING_ROD"))

        // moving → "BUTTON_MOVED" and losing → "LOCAL_RETRY"/"LOST" must be explained too
        d.run(12, RodSceneFixture.Rod(560, 210))
        assertTrue("movimento do botão precisa ser reportado", d.sink.any("BUTTON_MOVED"))
        val lost = d.run(70, rod = null) { it.state == RodDetectionState.SEARCHING_ROD }
        assertTrue(lost.state == RodDetectionState.SEARCHING_ROD)
        assertTrue("a perda precisa de motivo ([TRACKING] LOST / LOCAL_RETRY / WIDE SEARCH)",
            d.sink.any("[TRACKING] LOST") || d.sink.any("local retry failed") ||
                d.sink.any("[ROD_SEARCH] candidates=0"))
    }

    // -------------------------------------------------- §7: adaptive model never goes backwards

    @Test
    fun repeatedFailuresRaiseTheRequirementInsteadOfCrashingOrConfirming() {
        val cfg = AppConfig().validate()
        val d = Driver(cfg = cfg)
        // three short appearances that disappear before confirmation: false-positive pattern
        repeat(3) {
            d.run(3, RodSceneFixture.Rod(520, 199))
            d.run(20, rod = null)
        }
        val baseline = d.last.requiredFrames
        // a stable button appears again and must still end up confirmed (recovery, not a dead end)
        val snap = d.run(60, RodSceneFixture.Rod(520, 199)) { it.state.isConfirmedFamily }
        assertTrue("após padrões instáveis o detector precisa continuar confirmando (state=${snap.state} " +
            "reason=${snap.reason})", snap.state.isConfirmedFamily)
        assertTrue("requiredFrames absurdo: $baseline → ${snap.requiredFrames}",
            snap.requiredFrames in 3..12)
    }

    @Test
    fun trackingDoesNotRescanTheWholeFrameEveryFrame() {
        val d = Driver()
        val confirmed = d.confirm(RodSceneFixture.Rod(520, 199))
        assertTrue(confirmed.state.isConfirmedFamily)
        // after confirmation the wide search is off and the ROI is the search area (spec §4/§11)
        val tracked = d.run(5, RodSceneFixture.Rod(520, 199))
        assertTrue("deve estar rastreando localmente", tracked.tracking)
        assertFalse("busca ampla não deve estar ativa em TRACKING_ROD", tracked.searchActive)
        assertTrue("ROI deve estar ativa", tracked.roi.isValid)
        assertTrue("ROI pequena (${tracked.roi.width})", tracked.roi.width < 0.5f)
    }
}
