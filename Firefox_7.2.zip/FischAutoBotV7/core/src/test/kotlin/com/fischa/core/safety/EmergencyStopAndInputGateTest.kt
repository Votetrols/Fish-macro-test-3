package com.fischa.core.safety

import com.fischa.core.config.AppConfig
import com.fischa.core.control.InputExecutor
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.pipeline.PipelineInput
import com.fischa.core.pipeline.VisionPipeline
import com.fischa.core.state.FishingState
import com.fischa.core.vision.VisionFrame
import org.junit.Assert.*
import org.junit.Test

/** Records every call the core makes to the platform input layer. */
class RecordingExecutor : InputExecutor {
    val calls = ArrayList<String>()
    var acceptGestures = true
    override fun tap(nx: Float, ny: Float, durationMs: Int) { calls.add("legacyTap") }
    override fun tap(nx: Float, ny: Float, durationMs: Int, authorize: () -> Boolean): Boolean {
        if (!authorize()) { calls.add("tap:denied"); return false }
        calls.add("tap"); return acceptGestures
    }
    override fun holdStart(nx: Float, ny: Float, leaseMs: Int, authorize: () -> Boolean): Boolean {
        if (!authorize()) { calls.add("holdStart:denied"); return false }
        calls.add("holdStart"); return acceptGestures
    }
    override fun holdExtend(nx: Float, ny: Float, leaseMs: Int, authorize: () -> Boolean): Boolean {
        if (!authorize()) { calls.add("holdExtend:denied"); return false }
        calls.add("holdExtend"); return acceptGestures
    }
    override fun holdRelease() { calls.add("holdRelease") }
    override fun cancelAll() { calls.add("cancelAll") }
    override fun releaseAll() { calls.add("releaseAll") }
}

class EmergencyStopAndInputGateTest {

    @Test fun emergencyLatchesOnceNotifiesListenersAndOnlyExplicitClearReleasesIt() {
        val stop = EmergencyStop()
        var notified = 0
        stop.addListener { notified++ }
        assertFalse(stop.latched)
        stop.activate("test 1")
        stop.activate("test 2") // idempotent
        assertTrue(stop.latched)
        assertEquals(1, notified)
        stop.clear()
        assertFalse(stop.latched)
        stop.activate("again")
        assertEquals(2, notified)
    }

    @Test fun emergencyListenerExceptionsDoNotPreventOtherListeners() {
        val stop = EmergencyStop()
        var second = false
        stop.addListener { error("boom") }
        stop.addListener { second = true }
        stop.activate("x")
        assertTrue(stop.latched)
        assertTrue(second)
    }

    @Test fun pipelineReleasesAndCancelsEveryGestureWhenEmergencyFires() {
        val exec = RecordingExecutor()
        val stop = EmergencyStop()
        val pipeline = VisionPipeline(AppConfig().validate(), exec, ThrottledLog(NoopSink), emergency = stop)
        pipeline.armed = true
        stop.activate("notification button")
        assertTrue("cancelAll must be called", exec.calls.contains("cancelAll"))
        assertTrue("releaseAll must be called", exec.calls.contains("releaseAll"))
        // after the latch: no new real input can pass the guard
        val guard = InputSafetyGuard(AppConfig().safety)
        val ctx = SafetyContext().apply {
            macroEnabled = true; realInputEnabled = true; captureHealthy = true
            robloxDetected = true; platformAuthorized = true; state = FishingState.PRESSING_SHAKE
            trackingOk = true; controllerSafe = true; frameTimestampNs = 1_000_000_000L
        }
        val verdict = guard.evaluate(ctx, InputRequest(GestureAction.TAP, .5f, .5f, 60, .9f), 1_000_000_000L, stop)
        assertEquals(DenyReason.EMERGENCY_STOP, verdict.reason)
        // cleanup is never blocked
        assertTrue(guard.evaluate(ctx, InputRequest(GestureAction.CANCEL_ALL), 1_000_000_000L, stop).allowed)
        pipeline.close()
    }

    @Test fun disarmReleasesGesturesAndBlocksInput() {
        val exec = RecordingExecutor()
        val pipeline = VisionPipeline(AppConfig().validate(), exec, ThrottledLog(NoopSink))
        pipeline.armed = true
        assertTrue(pipeline.safety.macroEnabled)
        pipeline.disarm(1L)
        assertFalse(pipeline.armed)
        assertFalse(pipeline.safety.macroEnabled)
        assertTrue(exec.calls.contains("cancelAll"))
        assertTrue(exec.calls.contains("releaseAll"))
    }

    @Test fun pipelineWithRealInputOffNeverCallsTheExecutorForGameInput() {
        val exec = RecordingExecutor()
        val pipeline = VisionPipeline(AppConfig().validate(), exec, ThrottledLog(NoopSink))
        pipeline.armed = true
        val frame = VisionFrame.allocate(640, 288)
        var now = 1_000_000_000L
        repeat(30) {
            frame.resetFor(now, it.toLong())
            pipeline.onFrame(frame, PipelineInput(
                frameTimestampNs = now, currentTimeNs = now + 5_000_000L,
                captureHealthy = true, robloxDetected = true, inputAuthorized = true,
                macroEnabled = true, realInputEnabled = false,
            ))
            now += 33_000_000L
        }
        assertFalse(pipeline.output.realInputEnabled)
        assertFalse(pipeline.output.inputAuthorized)
        assertTrue(exec.calls.none { it.startsWith("tap") || it.startsWith("hold") })
        pipeline.close()
    }

    @Test fun pipelineReportsRobloxBlockReasonAndFrameAge() {
        val exec = RecordingExecutor()
        val pipeline = VisionPipeline(AppConfig().validate(), exec, ThrottledLog(NoopSink))
        pipeline.armed = true
        val frame = VisionFrame.allocate(640, 288)
        val now = 2_000_000_000L
        frame.resetFor(now, 1)
        pipeline.onFrame(frame, PipelineInput(
            frameTimestampNs = now, currentTimeNs = now + 400_000_000L, // 400 ms old frame
            captureHealthy = true, robloxDetected = false, inputAuthorized = false,
            macroEnabled = true, realInputEnabled = true,
            foregroundPackage = "com.sec.android.app.launcher",
            foregroundBlockReason = "FOREGROUND_PACKAGE_MISMATCH",
        ))
        assertEquals(400L, pipeline.output.frameAgeMs)
        assertFalse(pipeline.output.robloxDetected)
        assertFalse(pipeline.output.inputAuthorized)
        assertEquals("FOREGROUND_PACKAGE_MISMATCH", pipeline.output.foregroundBlockReason)
        assertEquals("com.sec.android.app.launcher", pipeline.render?.foregroundPackage)
        assertTrue(exec.calls.none { it.startsWith("tap") || it.startsWith("hold") })
        pipeline.close()
    }
}
