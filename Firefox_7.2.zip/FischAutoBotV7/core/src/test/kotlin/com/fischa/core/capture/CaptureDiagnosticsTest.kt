package com.fischa.core.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * V6 spec §19 — MediaProjection infrastructure diagnostics.
 *
 *   5. exceção de getMediaProjection      → [getMediaProjectionExceptionIsPreserved]
 *   6. exceção de createVirtualDisplay    → [createVirtualDisplayExceptionIsPreserved]
 *   7. ImageReader inválido               → [invalidImageReaderFailsTheStep]
 *   8. projection onStop                  → [projectionStoppedStepMarksFailure]
 *   9. STOP libera recursos               → [teardownAlwaysRuns]
 *  10. Emergency Stop libera recursos      → [teardownAlwaysRuns]
 *  11. restart depois de STOP             → [diagSessionCanRunTwiceOnFreshObjects]
 *  §1  não mascarar                       → [failureKeepsClassMessageAndStack]
 *  §20 critério de sucesso                → [successReportRequiresRunningCaptureWithFrames]
 */
class CaptureDiagnosticsTest {

    /** Scriptable fake of the Android layer (the real one is [ServiceCaptureProbe] in :app). */
    private class FakeProbe : CaptureProbe {
        var managerOk = true
        var consentOk = true
        var foregroundOk = true
        var projectionOk = true
        var readerOk = true
        var displayOk = true
        var firstFrameOk = true
        var projectionThrowable: Throwable? = null
        var displayThrowable: Throwable? = null
        var teardownCalls = 0
        var resourceHeld = true

        override fun probeManager(): ProbeStep =
            ProbeStep(CaptureStage.MANAGER, managerOk, "manager")

        override fun probeConsent(): ProbeStep =
            ProbeStep(CaptureStage.CONSENT, consentOk, "consent")

        override fun probeForegroundService(): ProbeStep =
            ProbeStep(CaptureStage.FOREGROUND, foregroundOk, "startForeground")

        override fun probeProjection(): ProbeStep {
            projectionThrowable?.let {
                return ProbeStep(CaptureStage.GET_PROJECTION, false, "getMediaProjection", CapturedException.from(it))
            }
            return ProbeStep(CaptureStage.GET_PROJECTION, projectionOk, "projection")
        }

        override fun probeImageReader(): ProbeStep =
            ProbeStep(CaptureStage.IMAGE_READER, readerOk, "ImageReader 640x288 RGBA_8888")

        override fun probeVirtualDisplay(): ProbeStep {
            displayThrowable?.let {
                return ProbeStep(CaptureStage.VIRTUAL_DISPLAY, false, "createVirtualDisplay", CapturedException.from(it))
            }
            return ProbeStep(CaptureStage.VIRTUAL_DISPLAY, displayOk, "VirtualDisplay 640x288")
        }

        override fun awaitFirstFrame(timeoutMs: Long): ProbeStep =
            ProbeStep(CaptureStage.FIRST_FRAME, firstFrameOk, "first frame in 220ms")

        override fun teardownProbe() {
            teardownCalls++
            resourceHeld = false
        }
    }

    private val a22 = DeviceProfile(
        sdkInt = 33,
        manufacturer = "samsung",
        model = "SM-A225M",
        device = "a22",
        product = "a22x",
        screenWidth = 720,
        screenHeight = 1600,
        densityDpi = 280,
        rotation = 1,
        locale = "pt_BR",
        appVersionName = "0.4.0-a22",
        appVersionCode = 4,
        targetSdk = 35,
    )

    private fun run(probe: FakeProbe, fps: Float = 29.5f, frameAgeMs: Long = 33L, frames: Long = 12L) =
        CaptureDiagnostics.run(
            probe = probe,
            device = a22,
            startedNs = 0L,
            nowNs = { 250_000_000L },
            timeoutMs = 2_000L,
            fps = { fps },
            frameAgeMs = { frameAgeMs },
            framesReceived = { frames },
            framesProcessed = { frames },
        )

    @Test fun successReportRequiresRunningCaptureWithFrames() {
        val report = run(FakeProbe())
        assertTrue(report.success())
        assertEquals(7, report.steps.size)
        assertTrue(report.steps.all { it.ok })
        assertTrue(report.format().contains("CAPTURA = RUNNING, FPS > 0, frame age válido, frames recebidos > 0"))
        assertTrue(report.format().contains("tocouInput=false"))
    }

    @Test fun successNeedsPositiveFpsAndValidFrameAge() {
        assertFalse(run(FakeProbe(), fps = 0f).success())
        assertFalse(run(FakeProbe(), frameAgeMs = FrameAge.NONE).success())
        assertFalse(run(FakeProbe(), frames = 0L).success())
    }

    @Test fun getMediaProjectionExceptionIsPreserved() {
        val probe = FakeProbe().apply {
            projectionThrowable = SecurityException(
                "Media projections require a foreground service of type ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION",
            )
        }
        val report = run(probe)
        assertFalse(report.success())
        assertEquals(CaptureStage.GET_PROJECTION, report.failedStep!!.stage)
        val text = report.format()
        assertTrue(text.contains("java.lang.SecurityException"))
        assertTrue(text.contains("Media projections require a foreground service"))
        // the pipeline stops at the failing step: nothing after it is reported as OK
        assertTrue(report.steps.none { it.stage == CaptureStage.VIRTUAL_DISPLAY })
    }

    @Test fun createVirtualDisplayExceptionIsPreserved() {
        val probe = FakeProbe().apply {
            displayThrowable = IllegalStateException("Must register a callback before starting capture")
        }
        val report = run(probe)
        assertFalse(report.success())
        assertEquals(CaptureStage.VIRTUAL_DISPLAY, report.failedStep!!.stage)
        assertTrue(report.format().contains("Must register a callback before starting capture"))
    }

    @Test fun invalidImageReaderFailsTheStep() {
        val probe = FakeProbe().apply { readerOk = false }
        val report = run(probe)
        assertFalse(report.success())
        assertEquals(CaptureStage.IMAGE_READER, report.failedStep!!.stage)
        assertTrue(report.format().contains("[FAIL] ImageReader.newInstance"))
    }

    @Test fun noFirstFrameIsReportedAsSuch() {
        val probe = FakeProbe().apply { firstFrameOk = false }
        val report = run(probe)
        assertFalse(report.success())
        assertEquals(CaptureStage.FIRST_FRAME, report.failedStep!!.stage)
        assertTrue(report.format().contains("VirtualDisplay" /* earlier steps stayed visible */))
    }

    @Test fun projectionStoppedStepMarksFailure() {
        val probe = FakeProbe().apply { foregroundOk = false }
        val report = run(probe)
        assertEquals(CaptureStage.FOREGROUND, report.failedStep!!.stage)
        assertFalse(report.success())
    }

    @Test fun teardownAlwaysRuns() {
        val okProbe = FakeProbe()
        run(okProbe)
        assertEquals(1, okProbe.teardownCalls)
        assertFalse(okProbe.resourceHeld)

        val brokenProbe = FakeProbe().apply { managerOk = false }
        run(brokenProbe)
        assertEquals("teardown must run even when the very first step fails", 1, brokenProbe.teardownCalls)
        assertFalse(brokenProbe.resourceHeld)
    }

    @Test fun diagSessionCanRunTwiceOnFreshObjects() {
        val first = FakeProbe()
        val second = FakeProbe()
        assertTrue(run(first).success())
        assertTrue(run(second).success())
        assertEquals(1, first.teardownCalls)
        assertEquals(1, second.teardownCalls)
    }

    @Test fun failureKeepsClassMessageAndStack() {
        val throwable = SecurityException("boom from the platform")
        val e = CapturedException.from(throwable)
        assertEquals("java.lang.SecurityException", e.exceptionClass)
        assertEquals("boom from the platform", e.message)
        assertTrue(e.oneLine().startsWith("java.lang.SecurityException: boom from the platform"))
        val failure = CaptureFailure(CaptureStage.GET_PROJECTION, e, "hint", resultCode = -1, dataPresent = true)
        assertTrue(CaptureErrorText.technicalLine(failure).contains("SecurityException: boom from the platform"))
        assertTrue(CaptureErrorText.userMessage(failure).contains("boom from the platform"))
    }

    @Test fun mediaProjectionBlockContainsEveryRequestedField() {
        val attempt = CaptureAttempt(device = a22, mode = "START")
        attempt.resultCode = -1
        attempt.dataPresent = true
        attempt.managerPresent = true
        attempt.serviceStarted = true
        attempt.foregroundStarted = true
        attempt.foregroundType = "mediaProjection"
        attempt.projectionCreated = false
        attempt.capture(
            SecurityException("Media projections require a foreground service"),
            "getMediaProjection(resultCode, data)",
        )
        val block = attempt.formatBlock()
        listOf(
            "[MEDIA_PROJECTION]",
            "sdk=33",
            "manufacturer=samsung",
            "model=SM-A225M",
            "resultCode=-1",
            "dataPresent=true",
            "managerPresent=true",
            "serviceStarted=true",
            "foregroundStarted=true",
            "projectionCreated=false",
            "imageReaderCreated=?",
            "virtualDisplayCreated=?",
            "exceptionClass=java.lang.SecurityException",
            "exceptionMessage=Media projections require a foreground service",
            "stackTrace=",
        ).forEach { expected ->
            assertTrue("bloco deveria conter '$expected':\n$block", block.contains(expected))
        }
        assertTrue(attempt.formatLine().contains("exceptionClass=java.lang.SecurityException"))
        assertFalse(attempt.capturedSuccessfully())
    }

    @Test fun galaxyA22ProfileIsRecognised() {
        assertTrue(a22.isLikelyGalaxyA22())
        assertTrue(a22.describe().contains("samsung SM-A225M"))
        assertTrue(a22.keyValueLines().contains("sdk=33"))
        assertFalse(a22.copy(model = "SM-G991B", device = "o1s").isLikelyGalaxyA22())
    }

    @Test fun diagnosticModeNeverReportsInputOrFishing() {
        val report = run(FakeProbe())
        val text = report.format()
        assertTrue(text.contains("mode=DIAGNOSTIC"))
        assertTrue(text.contains("pescou=false"))
        assertTrue(text.contains("realInput=OFF"))
        assertNotNull(report.device)
    }
}
