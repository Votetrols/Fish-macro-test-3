package com.fischa.core.safety

import com.fischa.core.config.AppConfig
import com.fischa.core.state.FishingState
import org.junit.Assert.*
import org.junit.Test

class InputSafetyGuardTest {
    private val now = 9_000_000_000L
    private val guard = InputSafetyGuard(AppConfig().validate().safety)
    private val tap = InputRequest(GestureAction.TAP, .5f, .5f, 60, .95f, "unit")

    private fun context(state: FishingState = FishingState.PRESSING_SHAKE) = SafetyContext().apply {
        macroEnabled = true
        realInputEnabled = true
        captureHealthy = true
        robloxDetected = true
        platformAuthorized = true
        overlaySuspected = false
        this.state = state
        targetConfidence = .95f
        trackingOk = true
        controllerSafe = true
        frameTimestampNs = now
    }

    private fun deny(c: SafetyContext, request: InputRequest = tap, emergency: EmergencyStop = EmergencyStop()) =
        guard.evaluate(c, request, now, emergency)

    @Test fun validRequestPassesAndCastDoesNotNeedFishTracking() {
        assertTrue(deny(context()).allowed)
        val cast = context(FishingState.CASTING).apply { trackingOk = false }
        assertTrue(deny(cast, tap.copy(action = GestureAction.HOLD_START)).allowed)
    }

    @Test fun requiredSafetyConditionsBlock() {
        assertEquals(DenyReason.MACRO_DISABLED, deny(context().apply { macroEnabled = false }).reason)
        assertEquals(DenyReason.REAL_INPUT_DISABLED, deny(context().apply { realInputEnabled = false }).reason)
        assertEquals(DenyReason.CAPTURE_STOPPED, deny(context().apply { captureHealthy = false }).reason)
        assertEquals(DenyReason.ROBLOX_NOT_DETECTED, deny(context().apply { robloxDetected = false }).reason)
        assertEquals(DenyReason.FOREGROUND_UNAUTHORIZED, deny(context().apply { platformAuthorized = false }).reason)
        assertEquals(DenyReason.OVERLAY_ACTIVE, deny(context().apply { overlaySuspected = true }).reason)
        assertEquals(DenyReason.STATE_NOT_ACTIONABLE, deny(context(FishingState.IDLE)).reason)
        assertEquals(DenyReason.TRACKING_LOST, deny(context(FishingState.CONTROLLING_PLAYER_BAR).apply { trackingOk = false }, tap.copy(action = GestureAction.HOLD_START)).reason)
        assertEquals(DenyReason.CONTROLLER_UNSAFE, deny(context().apply { controllerSafe = false }).reason)
    }

    @Test fun staleFramesLowConfidenceAndInvalidCommandsBlock() {
        val stale = context().apply { frameTimestampNs = now - (AppConfig().safety.maxFrameAgeMs + 5) * 1_000_000L }
        assertEquals(DenyReason.FRAME_STALE, deny(stale).reason)
        val low = tap.copy(confidence = AppConfig().safety.minActionConfidence - .01f)
        assertEquals(DenyReason.TARGET_CONFIDENCE_LOW, deny(context(), low).reason)
        assertEquals(DenyReason.COORDINATES_OUT_OF_BOUNDS, deny(context(), tap.copy(nx = Float.NaN)).reason)
        assertEquals(DenyReason.INVALID_DURATION, deny(context(), tap.copy(durationMs = 900)).reason)
    }

    @Test fun emergencyBlocksNewGestureButNeverBlocksRelease() {
        val emergency = EmergencyStop().apply { activate("test") }
        assertEquals(DenyReason.EMERGENCY_STOP, deny(context(), tap, emergency).reason)
        assertTrue(deny(context().apply { realInputEnabled = false }, InputRequest(GestureAction.HOLD_RELEASE), emergency).allowed)
        assertTrue(deny(context(), InputRequest(GestureAction.CANCEL_ALL), emergency).allowed)
    }

    @Test fun rateLimitAppliesToNewTap() {
        val limited = context().apply { lastInputNs = now - 5_000_000L }
        assertEquals(DenyReason.RATE_LIMITED, deny(limited).reason)
    }
}
