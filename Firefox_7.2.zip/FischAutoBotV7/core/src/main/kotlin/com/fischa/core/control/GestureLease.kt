package com.fischa.core.control

import kotlin.math.abs

/** Normalized gesture target, kept in core so lease policy is testable without Android. */
data class GestureTarget(val x: Float, val y: Float)

enum class GestureSessionState { IDLE, TAP, HOLD }

/**
 * Platform-neutral lease/watchdog state for GestureService. A hold is never infinite: every
 * continuation needs a fresh lease, must keep the same target, and is capped by a total hold
 * duration. Android is responsible for dispatching/releasing each segment.
 */
class GestureLease(
    private val maxLeaseMs: Long = 250,
    private val maxContinuousMs: Long = 5_000,
    private val watchdogMs: Long = 350,
    private val targetTolerance: Float = 0.015f,
) {
    var state: GestureSessionState = GestureSessionState.IDLE
        private set
    var target: GestureTarget? = null
        private set
    var generation: Long = 0L
        private set
    var leaseDeadlineMs: Long = 0L
        private set
    var startedAtMs: Long = 0L
        private set
    var lastRenewalMs: Long = 0L
        private set

    val activeCount: Int get() = if (state == GestureSessionState.IDLE) 0 else 1

    fun tap(point: GestureTarget, durationMs: Long, nowMs: Long): Boolean {
        if (state != GestureSessionState.IDLE || !validPoint(point) || durationMs !in 1..500) return false
        state = GestureSessionState.TAP
        target = point
        startedAtMs = nowMs
        lastRenewalMs = nowMs
        leaseDeadlineMs = nowMs + durationMs
        return true
    }

    fun completeTap() {
        if (state == GestureSessionState.TAP) clear()
    }

    fun holdStart(point: GestureTarget, leaseMs: Long, nowMs: Long): Boolean {
        if (state != GestureSessionState.IDLE || !validPoint(point) || !validLease(leaseMs)) return false
        state = GestureSessionState.HOLD
        target = point
        startedAtMs = nowMs
        lastRenewalMs = nowMs
        leaseDeadlineMs = nowMs + leaseMs
        return true
    }

    fun holdExtend(point: GestureTarget, leaseMs: Long, nowMs: Long): Boolean {
        if (state != GestureSessionState.HOLD || !validPoint(point) || !validLease(leaseMs)) return false
        if (nowMs < lastRenewalMs || nowMs - startedAtMs >= maxContinuousMs) return false
        val current = target ?: return false
        if (abs(current.x - point.x) > targetTolerance || abs(current.y - point.y) > targetTolerance) return false
        lastRenewalMs = nowMs
        leaseDeadlineMs = minOf(nowMs + leaseMs, startedAtMs + maxContinuousMs)
        return leaseDeadlineMs > nowMs
    }

    /** True only while the lease, watchdog, and total-hold cap are all still valid. */
    fun shouldContinue(nowMs: Long): Boolean {
        if (state != GestureSessionState.HOLD) return false
        val valid = nowMs >= lastRenewalMs &&
            nowMs >= startedAtMs &&
            nowMs <= leaseDeadlineMs &&
            nowMs - lastRenewalMs <= watchdogMs &&
            nowMs - startedAtMs < maxContinuousMs
        if (!valid) holdRelease()
        return valid
    }

    fun holdRelease() {
        if (state == GestureSessionState.HOLD) clear()
    }

    /** Increments generation so any queued callback from an earlier gesture is stale. */
    fun cancelAll() {
        generation++
        clear()
    }

    private fun clear() {
        state = GestureSessionState.IDLE
        target = null
        leaseDeadlineMs = 0L
        startedAtMs = 0L
        lastRenewalMs = 0L
    }

    private fun validLease(ms: Long) = ms in 1..maxLeaseMs
    private fun validPoint(p: GestureTarget) = p.x.isFinite() && p.y.isFinite() && p.x in 0f..1f && p.y in 0f..1f
}
