package com.fischa.core.tracking

import com.fischa.core.config.AppConfig
import kotlin.math.abs

/**
 * Temporal confirmation gate for the fishing-rod button (spec V5 §3/§4/§5).
 *
 * The rod button is the ONLY trigger allowed to start a fishing cycle, and a single frame is
 * never enough. This tracker requires, per streak:
 *  - [AppConfig.Rod.confirmFrames] consecutive frames with the button detected;
 *  - every frame's confidence >= [AppConfig.Rod.confidenceThreshold] (ROD_CONFIDENCE_THRESHOLD);
 *  - the button center stable within [AppConfig.Rod.stableToleranceF] (normalized units) of the
 *    streak anchor — a jumping false positive restarts the streak;
 *  - the whole streak completes within [AppConfig.Rod.confirmWindowMs] — a slow, drifting
 *    accumulation across seconds never confirms (no fixed long wait, no latency added).
 *
 * Conceptually: frame 1 → detected, frame 2 → detected, frame 3 → detected ⇒ ROD_CONFIRMED.
 * All parameters are configurable. The tracker never touches input; it only reports whether
 * the visual rod-button confirmation holds on the current frame.
 */
class RodConfirmTracker(private val cfg: AppConfig.Rod) {

    private var streak = 0
    private var anchorX = 0f
    private var anchorY = 0f
    private var startedNs = 0L

    /** True while the rod button is confirmed on the current frame. */
    var confirmed = false
        private set

    /** Consecutive confirmed-quality frames in the current streak (diagnostics/tests). */
    val streakFrames: Int get() = streak

    /**
     * @param detected rod button reported by the detector this frame
     * @param conf detector confidence this frame (0..1)
     * @param nx normalized button center x (0..1)
     * @param ny normalized button center y (0..1)
     * @param nowNs frame timestamp (monotonic, same clock as the pipeline)
     * @return true when the rod button is ROD_CONFIRMED on this frame
     */
    fun update(detected: Boolean, conf: Float, nx: Float, ny: Float, nowNs: Long): Boolean {
        if (detected && conf >= cfg.confidenceThreshold &&
            nx.isFinite() && ny.isFinite() && nx in 0f..1f && ny in 0f..1f
        ) {
            if (streak == 0) {
                anchorX = nx; anchorY = ny; startedNs = nowNs; streak = 1
            } else {
                val drift = abs(nx - anchorX) + abs(ny - anchorY)
                if (drift <= cfg.stableToleranceF) {
                    streak++
                } else {
                    // position jumped: restart the streak anchored at the new position
                    anchorX = nx; anchorY = ny; startedNs = nowNs; streak = 1
                }
            }
            val withinWindow = nowNs - startedNs <= cfg.confirmWindowMs * 1_000_000L
            confirmed = streak >= cfg.confirmFrames && withinWindow
        } else {
            streak = 0
            confirmed = false
        }
        return confirmed
    }

    /** A new fishing cycle (or a new WAITING_FOR_ROD entry) requires a fresh confirmation. */
    fun reset() {
        streak = 0
        confirmed = false
        startedNs = 0L
        anchorX = 0f
        anchorY = 0f
    }
}
