package com.fischa.core.vision

import com.fischa.core.common.RectF
import com.fischa.core.config.AppConfig
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Finds the fish indicator: a gray fish sprite riding on a thin vertical "needle" that crosses
 * the bar. Two observation modes (measured in the reference video):
 *  - needle *above* the bar top against the world background (mid-gray, low chroma);
 *  - needle *inside* the white block (dark against white).
 * When both fire and agree, the score is boosted.
 *
 * Requires the bar prior. Output: box = needle bounds (x = fish center along the bar);
 * v0 = normalized fish x in [0..1] along the bar; v1 = mode (0=above,1=inside,2=merged);
 * v2 = raw cluster score.
 */
class FishDetector(private val cfg: AppConfig.Vision) :
    TemporalDetector("Fish", minOnFrames = 2, minOffFrames = 4) {

    val lastBar = RectF()
    private var barValid = false
    /** prior x (normalized) supplied by the pipeline from FishTracker, for disambiguation */
    var priorXNorm = -1f
    /** white block span supplied by the pipeline (PlayerBarDetector) — mode 2 lives inside it */
    var blockL = -1; var blockR = -1

    fun setBarPrior(l: Float, t: Float, r: Float, b: Float) {
        barValid = r - l > 10f
        if (barValid) lastBar.set(l, t, r, b)
    }

    fun clearBarPrior() { barValid = false; blockL = -1; blockR = -1 }

    override fun detectRaw(frame: VisionFrame, hit: DetSnapshot): Float {
        if (!barValid) return 0f
        val bl = lastBar.left.toInt(); val br = lastBar.right.toInt() - 1
        val bt = lastBar.top.toInt(); val bb = lastBar.bottom.toInt() - 1
        val barW = br - bl + 1
        if (barW <= 16) return 0f
        val win = cfg.fishNeedleAbovePx

        // ---- mode 1: vertical mid-gray run ending just above the bar top, scanning up ----
        if (profAbove.size < barW + 2) profAbove = IntArray(barW + 2)
        if (profInside.size < barW + 2) profInside = IntArray(barW + 2)
        val aProf = profAbove
        for (x in 0 until barW) {
            var run = 0
            var y = bt - 1
            val yLow = max(1, bt - 1 - win)
            while (y >= yLow) {
                val g = frame.grayAt(bl + x, y)
                val p = frame.pixel(bl + x, y)
                if (g in cfg.fishNeedleMinGray..cfg.fishNeedleMaxGray && chroma(p) < 80) run++ else break
                y--
            }
            aProf[x] = run
        }
        val aC = cluster(aProf, barW, minRun = 4, maxSpan = 16)
        // narrowness: the needle must be a THIN peak — broad gray bands are background
        val aNarrow = aC.maxRun > 0 &&
            (aC.peak <= 3 || aProf[aC.peak - 3] <= 1) &&
            (aC.peak >= barW - 4 || aProf[aC.peak + 3] <= 1)
        val aX = if (aNarrow) bl + aC.peak.toFloat() else -1f
        val aScore = if (aNarrow) min(1f, aC.maxRun / 14f) else 0f

        // ---- mode 2: dark needle inside the bar rows (against white block) ----
        var iScore = 0f
        var iX = -1f
        if (aScore < 0.45f && blockL >= 0 && blockR > blockL) {
            val iProf = profInside
            val hMid = (bt + bb) / 2
            val hLo = min(bt + 2, hMid); val hHi = max(hMid + 1, bb - 1)
            val bl0 = max(0, blockL.toInt() - bl)
            val br0 = min(barW - 1, blockR.toInt() - bl)
            for (x in 0 until barW) iProf[x] = 0
            var x = bl0
            while (x <= br0) {
                var run = 0
                var y = hHi
                while (y >= hLo) {
                    val g = frame.grayAt(bl + x, y)
                    if (g in cfg.fishDarkMinGray..cfg.fishDarkMaxGray) run++ else break
                    y--
                }
                iProf[x] = run
                x++
            }
            val iC = cluster(iProf, barW, minRun = 3, maxSpan = 14)
            // inside-block needle must also be thin AND flanked by white-ish block pixels
            val iNarrow = iC.maxRun > 0 &&
                (iC.peak <= 3 || iProf[iC.peak - 3] <= 1) &&
                (iC.peak >= barW - 4 || iProf[iC.peak + 3] <= 1)
            iX = if (iNarrow) bl + iC.peak.toFloat() else -1f
            if (iNarrow) iScore = min(1f, iC.maxRun / 10f)
        }

        var cx = -1f; var mode = 0; var score = 0f
        if (aScore >= iScore && aX >= 0f && aScore > 0.25f) { cx = aX; mode = 0; score = aScore }
        else if (iScore > 0.25f && iX >= 0f) { cx = iX; mode = 1; score = iScore }
        if (aX >= 0f && iX >= 0f && aScore > 0.25f && iScore > 0.25f) {
            if (abs(aX - iX) <= max(6f, barW * 0.06f)) { mode = 2; score = min(1f, max(aScore, iScore) + 0.25f) }
        }
        if (cx < 0) return 0f

        // disambiguation: when the *above* mode fired far from the tracker prior while the
        // *inside* mode agrees with it, prefer the prior-consistent candidate
        if (priorXNorm >= 0f && mode == 0 && iX >= 0f && aScore < iScore + 0.4f) {
            val priorPx = bl + priorXNorm * barW
            val aErr = abs(aX - priorPx) / barW
            val iErr = if (iX >= 0f) abs(iX - priorPx) / barW else 1f
            if (iErr < aErr) { cx = iX; mode = 1; score = iScore + 0.1f }
        }

        val raw = score.coerceIn(0f, 1f)
        if (raw > 0.5f) {
            hit.detected = true
            hit.box.set(cx - 5f, (bt - win).toFloat(), cx + 5f, bb.toFloat())
            hit.rawScore = raw
            hit.v0 = (cx - bl) / barW.toFloat()
            hit.v1 = mode.toFloat()
            hit.v2 = score
        }
        return raw
    }

    private class ClusterResult(var lo: Int = -1, var hi: Int = -1, var maxRun: Int = 0, var peak: Int = -1)

    private var profAbove = IntArray(0)
    private var profInside = IntArray(0)

    /**
     * Finds the widest window (≤ maxSpan columns) whose peak run ≥ minRun, returning the peak
     * position. Cluster = consecutive columns with v ≥ minRun, merged across gaps of 1.
     */
    private fun cluster(prof: IntArray, len: Int, minRun: Int, maxSpan: Int): ClusterResult {
        val res = ClusterResult()
        var bestPeak = 0
        var i = 0
        while (i < len) {
            if (prof[i] >= minRun) {
                // gather run of columns
                var j = i
                var peak = 0; var peakIdx = i
                while (j < len && prof[j] >= minRun) {
                    if (prof[j] > peak) { peak = prof[j]; peakIdx = j }
                    j++
                    if (j - i >= maxSpan) break
                }
                if (peak > bestPeak) {
                    bestPeak = peak
                    res.lo = i; res.hi = j - 1; res.maxRun = peak; res.peak = peakIdx
                }
                i = j + 1
                continue
            }
            i++
        }
        return res
    }
}
