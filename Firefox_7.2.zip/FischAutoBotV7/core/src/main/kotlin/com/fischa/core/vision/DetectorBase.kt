package com.fischa.core.vision

import com.fischa.core.common.RectF
import com.fischa.core.common.clamp01

/**
 * Snapshot published by a detector after temporal validation. Immutable-by-convention:
 * the pipeline reads it and copies what it needs for the debug overlay.
 */
class DetSnapshot {
    var detected = false
    /** temporal (validated) confidence 0..1 */
    var confidence = 0f
    /** raw single-frame score of the current frame, for logs/debug */
    var rawScore = 0f
    val box = RectF()
    var timestampNs = 0L
    /** detector-specific scalars, documented per detector */
    var v0 = 0f; var v1 = 0f; var v2 = 0f; var v3 = 0f
    /** how many consecutive frames the element has been stably seen (0 when not seen) */
    var streak = 0
    /** frames since last seen (large when absent) */
    var lostFrames = 0

    fun copyFrom(o: DetSnapshot) {
        detected = o.detected; confidence = o.confidence; rawScore = o.rawScore
        box.set(o.box); timestampNs = o.timestampNs
        v0 = o.v0; v1 = o.v1; v2 = o.v2; v3 = o.v3
        streak = o.streak; lostFrames = o.lostFrames
    }
}

/**
 * Temporal validation used by every detector: an element must appear in
 * `minOnFrames` consecutive raw hits before it is reported, and disappear for
 * `minOffFrames` before it is cleared. Confidence is an EMA that keeps a short grace
 * value while the element is briefly occluded (frame-to-frame flicker tolerance).
 */
abstract class TemporalDetector(
    val name: String,
    val minOnFrames: Int,
    val minOffFrames: Int,
) {
    protected var onStreak = 0
    protected var offStreak = 0
    protected var reported = false
    protected var ema = 0f
    protected var lastSeenNs = 0L

    val out = DetSnapshot()

    /** run one frame; returns [out] (shared instance — read before the next call or copy). */
    fun process(frame: VisionFrame): DetSnapshot {
        val hit = out.apply { clear() }
        val raw = detectRaw(frame, hit) // fills hit.box/hit.v* + rawScore; >0.5 => candidate
        val rawHit = hit.rawScore > 0.5f
        if (rawHit) {
            onStreak++; offStreak = 0
            ema = ema * 0.55f + raw.coerceIn(0f, 1f) * 0.45f
            lastSeenNs = frame.timestampNs
        } else {
            offStreak++
            ema *= 0.75f
        }
        if (!reported) {
            if (rawHit && onStreak >= minOnFrames) reported = true
        } else {
            if (offStreak >= minOffFrames) reported = false
        }
        out.detected = reported && (rawHit || offStreak < minOffFrames)
        out.confidence = if (out.detected) clamp01(ema) else 0f
        out.rawScore = raw.coerceIn(0f, 1f)
        out.streak = if (rawHit) onStreak else 0
        out.lostFrames = if (rawHit) 0 else offStreak
        out.timestampNs = frame.timestampNs
        return out
    }

    private fun DetSnapshot.clear() {
        detected = false; confidence = 0f; rawScore = 0f; streak = 0; lostFrames = 0
        v0 = 0f; v1 = 0f; v2 = 0f; v3 = 0f
    }

    /**
     * @return raw confidence 0..1 of the single-frame detection; must set hit.detected=true and
     * hit.box when a candidate was found, regardless of temporal gating.
     */
    protected abstract fun detectRaw(frame: VisionFrame, hit: DetSnapshot): Float

    /** hard reset (state machine re-entry after long absence) */
    fun reset() { onStreak = 0; offStreak = 0; reported = false; ema = 0f; lastSeenNs = 0L }
}
