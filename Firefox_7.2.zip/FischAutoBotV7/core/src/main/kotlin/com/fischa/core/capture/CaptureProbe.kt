package com.fischa.core.capture

/** Result of one infrastructure step of the capture diagnostic (spec §18). */
class ProbeStep(
    val stage: CaptureStage,
    val ok: Boolean,
    val detail: String = "",
    val exception: CapturedException? = null,
) {
    fun line(): String = buildString {
        append(if (ok) "  [ OK ] " else "  [FAIL] ")
        append(stage.label)
        if (detail.isNotBlank()) append(" — ").append(detail)
        exception?.let { append(" — ").append(it.oneLine()) }
    }
}

/**
 * Platform hooks used by [CaptureDiagnostics]. Implemented by the Android layer
 * (`FischEngineService` + `ScreenCaptureSource`) and by fakes in the unit tests.
 *
 * The V6 spec §18 requires the diagnostic to touch *only* the capture infrastructure: it must not
 * fish, must not tap Roblox, must not enable real input and must not look for the rod button.
 */
interface CaptureProbe {
    /** MediaProjectionManager obtainable? */
    fun probeManager(): ProbeStep

    /** Screen-capture consent present/valid? (In diagnostic mode the Activity just asked for it.) */
    fun probeConsent(): ProbeStep

    /** startForegroundService() + startForeground(type=mediaProjection) + notification. */
    fun probeForegroundService(): ProbeStep

    /** MediaProjectionManager.getMediaProjection(resultCode, data) + callback registration. */
    fun probeProjection(): ProbeStep

    /** ImageReader.newInstance(w, h, RGBA_8888, 3) with valid dimensions. */
    fun probeImageReader(): ProbeStep

    /** MediaProjection.createVirtualDisplay(...) bound to the ImageReader surface. */
    fun probeVirtualDisplay(): ProbeStep

    /** Waits for the first real frame; [timeoutMs] is a hard bound. */
    fun awaitFirstFrame(timeoutMs: Long): ProbeStep

    /** Always called: STOP/EMERGENCY semantics — release VirtualDisplay, ImageReader, projection. */
    fun teardownProbe()
}

/**
 * Ordered outcome of the diagnostic run plus the frame measurements of the probe session.
 */
class CaptureDiagnosticReport(
    val device: DeviceProfile?,
    val mode: String,
    val steps: List<ProbeStep>,
    val startedNs: Long,
    val finishedNs: Long,
    val fps: Float,
    val frameAgeMs: Long,
    val framesReceived: Long,
    val framesProcessed: Long,
    val firstFrameLatencyMs: Long,
    val attemptBlock: String,
) {
    val failedStep: ProbeStep? get() = steps.firstOrNull { !it.ok }

    /** spec §20: capture RUNNING and FPS > 0 and a valid frame age and frames received > 0. */
    fun success(): Boolean {
        val allOk = steps.isNotEmpty() && steps.all { it.ok }
        return allOk && fps > 0f && FrameAge.isValid(frameAgeMs) && framesReceived > 0L
    }

    fun durationMs(): Long = (finishedNs - startedNs) / 1_000_000L

    fun format(): String = buildString {
        appendLine("===== DIAGNÓSTICO DE CAPTURA (Fisch AutoBot V6) =====")
        appendLine("mode=$mode  tocouInput=false  pescou=false  realInput=OFF")
        device?.let { appendLine("device: ${it.describe()}") }
        appendLine("steps:")
        steps.forEach { appendLine(it.line()) }
        appendLine("--- medidas ---")
        appendLine("fps=${"%.1f".format(fps)} frameAge=${FrameAge.format(frameAgeMs)} " +
            "framesReceived=$framesReceived framesProcessed=$framesProcessed firstFrameLatencyMs=$firstFrameLatencyMs")
        appendLine("--- veredito (spec §20) ---")
        appendLine(
            if (success()) "CAPTURA = RUNNING, FPS > 0, frame age válido, frames recebidos > 0 → MediaProjection OK"
            else "FALHOU: ${failedStep?.let { it.stage.label + " — " + (it.exception?.oneLine() ?: it.detail) } ?: "critérios de sucesso não atingidos"}",
        )
        appendLine("duração=${durationMs()}ms")
        appendLine()
        append(attemptBlock)
    }
}

/**
 * Runs the capture-only diagnostic in the canonical order of the V6 flow (spec §3/§18/§20) and
 * stops at the first failure so the report always points at the exact broken stage.
 */
object CaptureDiagnostics {

    const val MODE_DIAGNOSTIC = "DIAGNOSTIC"

    /**
     * @param timeoutMs bound for the first frame (spec §20); the A22 needs ~1–2 s after the
     *                  virtual display is created.
     */
    fun run(
        probe: CaptureProbe,
        device: DeviceProfile?,
        startedNs: Long,
        nowNs: () -> Long = { startedNs },
        timeoutMs: Long = 2_000L,
        fps: () -> Float = { 0f },
        frameAgeMs: () -> Long = { FrameAge.NONE },
        framesReceived: () -> Long = { 0L },
        framesProcessed: () -> Long = { 0L },
        attemptBlock: () -> String = { "" },
    ): CaptureDiagnosticReport {
        val steps = ArrayList<ProbeStep>(7)
        var firstFrameLatency = -1L

        fun step(block: () -> ProbeStep): Boolean {
            val s = runCatching { block() }.getOrElse { t ->
                ProbeStep(CaptureStage.NONE, false, "probe step threw", CapturedException.from(t))
            }
            steps.add(s)
            return s.ok
        }

        try {
            if (step { probe.probeManager() } &&
                step { probe.probeConsent() } &&
                step { probe.probeForegroundService() } &&
                step { probe.probeProjection() } &&
                step { probe.probeImageReader() } &&
                step { probe.probeVirtualDisplay() }
            ) {
                val before = nowNs()
                val frame = runCatching { probe.awaitFirstFrame(timeoutMs) }
                    .getOrElse { ProbeStep(CaptureStage.FIRST_FRAME, false, "await threw", CapturedException.from(it)) }
                steps.add(frame)
                if (frame.ok) firstFrameLatency = (nowNs() - before) / 1_000_000L
            }
        } finally {
            // Diagnostic sessions must never leave a capture running (spec §6/§8).
            runCatching { probe.teardownProbe() }
        }

        val finished = nowNs()
        return CaptureDiagnosticReport(
            device = device,
            mode = MODE_DIAGNOSTIC,
            steps = steps,
            startedNs = startedNs,
            finishedNs = finished,
            fps = fps(),
            frameAgeMs = frameAgeMs(),
            framesReceived = framesReceived(),
            framesProcessed = framesProcessed(),
            firstFrameLatencyMs = firstFrameLatency,
            attemptBlock = attemptBlock(),
        )
    }
}
