package com.fischa.core.vision

import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Cheap multi-scale disc detector shared by the rod-button and Shake detectors.
 *
 * Both UI elements are "dark semi-transparent disc + brighter thin ring". We score candidate
 * (cx, cy, r) centers with:
 *   ringDelta  : mean luminance on the ring minus mean just inside/outside (ring must pop)
 *   interior   : mean luminance inside the disc (both elements are dark; scene varies)
 *   roundness  : stability of the ring across sampled angles
 * Everything is sampled on a fixed unit-circle table (precomputed), O(N) per candidate with a
 * small constant; candidate grids are stepped so cost is bounded by frame area / step^2.
 */
class DiscMatcher(
    private val angleCount: Int = 32,
) {
    private val cosT = FloatArray(angleCount)
    private val sinT = FloatArray(angleCount)

    init {
        for (i in 0 until angleCount) {
            val a = (2.0 * Math.PI * i / angleCount).toFloat()
            cosT[i] = cos(a.toDouble()).toFloat()
            sinT[i] = sin(a.toDouble()).toFloat()
        }
    }

    class Score {
        var cx = 0; var cy = 0; var r = 0
        var ringDelta = 0f
        var interiorGray = 0f
        var roundness = 0f
        var total = 0f
    }

    /**
     * @param maxR minR candidate radius range in px
     * @param interiorMaxGray reject centers whose disc interior is brighter than this
     * @param minRingDelta reject centers whose ring contrast is below this
     * @param whiteScore optional: fraction of "special pixels" inside the disc (e.g. white text)
     *                   computed by [interiorWhiteFrac]; the caller combines it.
     */
    fun bestDisc(
        frame: VisionFrame,
        x0: Int, y0: Int, x1: Int, y1: Int,
        minR: Int, maxR: Int,
        step: Int,
        interiorMaxGray: Int,
        minRingDelta: Int,
        out: Score,
    ): Score {
        var best = -1e9f
        out.total = -1e9f
        val w = frame.width
        val margin = maxR + 3
        var cy = max(y0, margin)
        while (cy < min(y1, frame.height - margin)) {
            var cx = max(x0, margin)
            while (cx < min(x1, w - margin)) {
                var r = minR
                while (r <= maxR) {
                    val s = score(frame, cx, cy, r)
                    if (s.ringDelta >= minRingDelta && s.total > best) {
                        best = s.total
                        out.cx = cx; out.cy = cy; out.r = r
                        out.ringDelta = s.ringDelta; out.interiorGray = s.interiorGray
                        out.roundness = s.roundness; out.total = s.total
                    }
                    r += max(4, r / 6)
                }
                cx += step
            }
            cy += step
        }
        if (out.total < -1e8f) { out.total = 0f; out.r = 0 }
        return out
    }

    private val tmp = Score()

    private fun score(f: VisionFrame, cx: Int, cy: Int, r: Int): Score {
        var ringSum = 0; var inSum = 0; var outSum = 0
        var n = 0
        var ringMin = 255; var ringMax = 0
        val ri = r - 2f
        val ro = r + 2f
        for (i in 0 until angleCount) {
            val gx = cx + (cosT[i] * r).roundToInt()
            val gy = cy + (sinT[i] * r).roundToInt()
            val gxi = cx + (cosT[i] * ri).roundToInt()
            val gyi = cy + (sinT[i] * ri).roundToInt()
            val gxo = cx + (cosT[i] * ro).roundToInt()
            val gyo = cy + (sinT[i] * ro).roundToInt()
            if (gx < 1 || gy < 1 || gx >= f.width - 1 || gy >= f.height - 1) { tmp.total = -1e9f; return tmp }
            val gv = f.grayAt(gx, gy)
            ringSum += gv
            inSum += f.grayAt(gxi, gyi)
            outSum += f.grayAt(gxo, gyo)
            if (gv < ringMin) ringMin = gv
            if (gv > ringMax) ringMax = gv
            n++
        }
        val ring = ringSum.toFloat() / n
        // interior mean over a sparse cross pattern (cheap)
        var isum = 0; var icnt = 0
        var d = -r + 3
        while (d < r - 2) {
            isum += f.grayAt(cx + d, cy); icnt++
            isum += f.grayAt(cx, cy + d); icnt++
            d += 3
        }
        val interior = isum.toFloat() / max(icnt, 1)
        val outside = outSum.toFloat() / n
        val inner = inSum.toFloat() / n
        val ringDelta = ring - (0.55f * interior + 0.45f * outside)
        val roundness = 1f - (ringMax - ringMin) / 160f
        tmp.ringDelta = ringDelta
        tmp.interiorGray = interior
        tmp.roundness = roundness.coerceIn(0f, 1f)
        tmp.total = ringDelta * 2.2f + roundness * 30f - max(0f, interior - 120f) * 0.6f
        return tmp
    }

    /** fraction of pixels inside the disc matching [lo,hi] gray (white text glyphs etc.) */
    fun interiorFrac(f: VisionFrame, cx: Int, cy: Int, r: Int, lo: Int, hi: Int): Float {
        if (r <= 0) return 0f
        var hit = 0; var n = 0
        var dy = -r; 
        while (dy <= r) {
            var dx = -r
            while (dx <= r) {
                if (dx * dx + dy * dy <= r * r) {
                    val x = cx + dx; val y = cy + dy
                    if (x in 1 until f.width - 1 && y in 1 until f.height - 1) {
                        val g = f.grayAt(x, y)
                        if (g >= lo && g <= hi) hit++
                        n++
                    }
                }
                dx++
            }
            dy++
        }
        return if (n == 0) 0f else hit.toFloat() / n
    }
}
