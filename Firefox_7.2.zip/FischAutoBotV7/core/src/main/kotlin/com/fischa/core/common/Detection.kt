package com.fischa.core.common

/**
 * Structured result returned by every detector.
 *
 * `box` and `center` are expressed in **processing pixel space** (i.e. the coordinate space of
 * the [com.fischa.core.vision.VisionFrame] that produced them). Converting back to screen space
 * is a single linear scale owned by the capture layer, so detectors never deal with device
 * resolution, orientation or density at all.
 *
 * The type parameter carries whatever extra geometry a detector can legitimately provide
 * (normalized spans, tint state, …) without forcing every detector into a tuple.
 */
data class DetectionResult<T>(
    val detected: Boolean,
    val confidence: Float,
    val box: RectF?,
    val center: PointF?,
    val timestampNs: Long,
    /** detection-frame fps; 0 when unknown. Used for temporal validation on the consumer side. */
    val frameFps: Float,
    val extra: T? = null,
) {
    val area: Float get() = if (box == null) 0f else box.width * box.height

    companion object {
        const val NOT_DETECTED_CONF = 0f

        fun <T> missed(ts: Long, fps: Float): DetectionResult<T> =
            DetectionResult(false, NOT_DETECTED_CONF, null, null, ts, fps, null)
    }
}
