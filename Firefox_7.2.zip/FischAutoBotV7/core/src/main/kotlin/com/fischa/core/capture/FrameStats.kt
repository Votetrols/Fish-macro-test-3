package com.fischa.core.capture

/**
 * V6 spec §14 — frame age must never be shown as `9223372036854775807 ms` (Long.MAX_VALUE) as it
 * was in the V5 diagnostics screen when no frame had ever arrived. "No frame" is a state, not a
 * number: it is reported as `N/A`, and every consumer has to treat it as "cannot act".
 */
object FrameAge {
    /** Sentinel for "no frame yet". Deliberately negative so it can never be confused with a real age. */
    const val NONE: Long = -1L

    fun isValid(ageMs: Long): Boolean = ageMs >= 0L

    /** `N/A` when nothing arrived yet, `37 ms` otherwise (V6 spec §14). */
    fun format(ageMs: Long): String = if (isValid(ageMs)) "$ageMs ms" else "N/A"

    /** Age of a frame given now and the frame stamp (both on the same monotonic clock). */
    fun of(nowNs: Long, frameTimestampNs: Long): Long {
        if (frameTimestampNs <= 0L) return NONE
        return ((nowNs - frameTimestampNs).coerceAtLeast(0L)) / 1_000_000L
    }

    /**
     * A missing frame is always "stale" (fail-closed): the controller may not act on it.
     */
    fun isStale(ageMs: Long, maxAgeMs: Long): Boolean = !isValid(ageMs) || ageMs > maxAgeMs
}

/** Counters required by spec §14/§17. */
data class FrameCounters(
    val received: Long = 0L,
    val processed: Long = 0L,
    val dropped: Long = 0L,
    val gated: Long = 0L,
) {
    fun describe(): String =
        "received=$received processed=$processed dropped=$dropped gated=$gated"
}

/**
 * Latest-frame-only bookkeeping (spec §14): the buffer never accumulates old frames, so we make
 * the discard explicit and measurable instead of hiding it.
 */
class FrameStatsTracker {
    private var received = 0L
    private var processed = 0L
    private var dropped = 0L
    private var gated = 0L
    private var lastFrameTimestampNs = 0L
    private var firstFrameTimestampNs = 0L

    val hasFrame: Boolean get() = lastFrameTimestampNs > 0L

    fun onReceived(timestampNs: Long) {
        received++
        lastFrameTimestampNs = timestampNs
        if (firstFrameTimestampNs == 0L) firstFrameTimestampNs = timestampNs
    }

    fun onProcessed(timestampNs: Long) {
        processed++
        if (lastFrameTimestampNs == 0L) lastFrameTimestampNs = timestampNs
    }

    fun onDropped(count: Long = 1L) {
        dropped += count
    }

    fun onGated(count: Long = 1L) {
        gated += count
    }

    /** `N/A` (i.e. [FrameAge.NONE]) when no frame exists — never Long.MAX_VALUE (spec §14). */
    fun frameAgeMs(nowNs: Long): Long = FrameAge.of(nowNs, lastFrameTimestampNs)

    fun counters(): FrameCounters = FrameCounters(received, processed, dropped, gated)

    fun describe(nowNs: Long): String =
        "${counters().describe()} frameAge=${FrameAge.format(frameAgeMs(nowNs))}"

    fun reset() {
        received = 0L
        processed = 0L
        dropped = 0L
        gated = 0L
        lastFrameTimestampNs = 0L
        firstFrameTimestampNs = 0L
    }
}
