package com.fischa.core.state

/**
 * Explicit, evidence-driven states (spec §11; V5 flow §2). No implicit timers anywhere.
 *
 * V5 cycle:  WAITING_FOR_ROD → CASTING → WAITING_FOR_WATER → SEARCHING_SHAKE ⇄ PRESSING_SHAKE
 *            → FISHING_MINIGAME_DETECTED → TRACKING_FISH → CONTROLLING_PLAYER_BAR
 *            → CATCH_CONFIRMATION → RESET → WAITING_FOR_ROD → …
 *
 *  - IDLE: infrastructure off (before START / after STOP).
 *  - WAITING_FOR_ROD: observing only. The visually confirmed rod button is the ONLY way out.
 */
enum class FishingState {
    IDLE,
    WAITING_FOR_ROD,
    CASTING,
    WAITING_FOR_WATER,
    SEARCHING_SHAKE,
    PRESSING_SHAKE,
    FISHING_MINIGAME_DETECTED,
    TRACKING_FISH,
    CONTROLLING_PLAYER_BAR,
    CATCH_CONFIRMATION,
    RESET,

    // error / safety states
    VISION_LOST,
    CAPTURE_ERROR,
    ROBLOX_NOT_DETECTED,
    INVALID_STATE,
    EMERGENCY_STOP,
    ;

    val isError: Boolean
        get() = this == VISION_LOST || this == CAPTURE_ERROR || this == ROBLOX_NOT_DETECTED ||
                this == INVALID_STATE || this == EMERGENCY_STOP

    /** States where the macro may issue game input at all. */
    val actionable: Boolean
        get() = this == CASTING || this == PRESSING_SHAKE || this == FISHING_MINIGAME_DETECTED ||
            this == TRACKING_FISH || this == CONTROLLING_PLAYER_BAR

    /** States where the controller (minigame loop) runs. */
    val controlling: Boolean
        get() = this == FISHING_MINIGAME_DETECTED || this == TRACKING_FISH || this == CONTROLLING_PLAYER_BAR
}

/** Events that may drive transitions; every field is measured, never assumed. */
data class StateEvidence(
    val fishingButton: Boolean,
    val fishingButtonConf: Float,
    val shake: Boolean,
    val shakeConf: Float,
    /** shake box center moved by > threshold since our last tap attempt */
    val shakeMoved: Boolean,
    /** minigame bar detected in this frame */
    val bar: Boolean,
    val barConf: Float,
    /** progress bar present and increasing */
    val progressPresent: Boolean,
    val progressValue: Float,
    /** catch confirmation (fish name text) visible */
    val catchConfirm: Boolean,
    val catchConfirmConf: Float,
    /** Roblox foreground (activity) reported by the platform */
    val robloxForeground: Boolean,
    /** capture pipeline is producing frames */
    val captureHealthy: Boolean,
    /** aggregate vision trust */
    val globalConfidence: Float,
    /** tracking of fish/player usable */
    val trackingOk: Boolean,
    val frameDeltaMs: Float,
    // ---- V5 rod-button gate (spec §3/§4/§5) ----
    /** rod button passed the temporal+confidence+stability confirmation this frame */
    val rodConfirmed: Boolean = false,
    /** InputSafetyGuard authorizes the WAITING_FOR_ROD → CASTING transition this frame */
    val castAuthorized: Boolean = false,
    /** CastController finished the hold (release issued) this frame */
    val castComplete: Boolean = false,
    /** CastController aborted the hold (target lost) this frame */
    val castAborted: Boolean = false,
)

class StateChange(val from: FishingState, val to: FishingState, val reason: String, val timestampNs: Long)
