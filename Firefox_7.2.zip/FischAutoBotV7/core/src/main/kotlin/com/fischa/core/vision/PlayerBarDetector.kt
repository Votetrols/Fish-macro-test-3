package com.fischa.core.vision

import com.fischa.core.common.RectF
import com.fischa.core.common.clamp
import com.fischa.core.common.ramp
import com.fischa.core.config.AppConfig
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Finds the white controllable block inside the minigame bar, *including* the red-tinted
 * "mismatch" rendering it gets while the fish is outside it (observed at ~val 64 red hue in
 * the reference video). The block's width is learned visually and never resized by rod.
 *
 * Requires a bar prior ([lastBar]) — without the bar geometry this detector cannot answer
 * "inside the bar", which is a hard requirement of the spec (block ⊂ bar).
 *
 * Output: box = block bounds; normalized block left/right/center stored in [geom];
 * v0 = 1 when tinted red (mismatch), 0 when white; v1 = block width / bar width;
 * v2 = left-arrow glyph presence (debug hint); v3 = right-arrow glyph presence.
 */
class PlayerBarDetector(private val cfg: AppConfig.Vision) :
    TemporalDetector("PlayerBar", minOnFrames = 2, minOffFrames = 4) {

    class BlockGeometry {
        var valid = false
        var left = 0f; var right = 0f; var top = 0f; var bottom = 0f
        val centerX: Float get() = (left + right) * 0.5f
        val width: Float get() = right - left
        fun clear() { valid = false }
    }

    val geom = BlockGeometry()
    /** set by the pipeline before processing each frame */
    val lastBar = RectF()
    private var barValid = false

    fun setBarPrior(l: Float, t: Float, r: Float, b: Float) {
        barValid = r - l > 10f && b - t > 4f
        if (barValid) lastBar.set(l, t, r, b) else { geom.clear(); barValid = false }
    }

    fun clearBarPrior() { barValid = false; geom.clear() }

    override fun detectRaw(frame: VisionFrame, hit: DetSnapshot): Float {
        if (!barValid) return 0f
        val w = frame.width
        val bl = lastBar.left.toInt(); val br = lastBar.right.toInt() - 1
        val bt = lastBar.top.toInt(); val bb = lastBar.bottom.toInt() - 1
        val barW = (br - bl + 1)
        if (barW <= 8) return 0f

        val rowTop = min(bb, bt + 2); val rowBot = max(rowTop, bb - 1)
        val midRow = (rowTop + rowBot) / 2

        // Scan each row in the band; score columns that are block-white or block-red-tint.
        // Pick the best (longest) qualifying run across rows.
        var bestLen = 0; var bestRow = -1; var bestL = 0; var bestR = 0; var bestRedCount = 0
        var row = rowTop
        while (row <= rowBot) {
            var cur = 0; var start = 0; var gap = 0; var reds = 0; var redsCur = 0
            var x = bl
            while (x <= br) {
                val p = frame.pixel(x, row)
                val g = frame.grayAt(x, row)
                val white = g >= cfg.blockWhiteMinGray && chroma(p) < 80
                val red = redTint(p) && g in cfg.mismatchValMin..cfg.mismatchValMax
                if (white || red) {
                    if (gap > 12) { cur = 0; start = x; redsCur = 0 }
                    cur++; if (red) redsCur++
                    gap = 0
                    if (cur > bestLen) {
                        bestLen = cur; bestRow = row; bestL = start; bestR = x; bestRedCount = redsCur
                    }
                } else gap++
                x++
            }
            row++
        }
        val minLen = max(4, (cfg.blockMinWidthF * w).toInt())
        val maxLen = (cfg.blockMaxWidthF * w).toInt()
        if (bestRow < 0 || bestLen < minLen || bestLen > maxLen) return 0f

        // vertical extent: rows within bar where the run columns are mostly block-like
        var t = bestRow; var b = bestRow
        while (t > rowTop && rowBlockFrac(frame, bestL, bestR, t - 1) > 0.5f) t--
        while (b < rowBot && rowBlockFrac(frame, bestL, bestR, b + 1) > 0.5f) b++

        val blockW = bestR - bestL + 1
        val redFrac = if (blockW == 0) 0f else bestRedCount.toFloat() / blockW
        val tintMismatch = redFrac > 0.55f

        // containment in the bar (allow 3 px sensor slop)
        val contained = bestL >= bl - 3 && bestR <= br + 3
        if (!contained) return 0f

        val coverage = rowBlockFrac(frame, bestL, bestR, midRow)
        val widthFit = 1f - min(1f, abs(blockW / barW.toFloat() - 0.30f) / 0.30f)
        val tintValidity = if (tintMismatch || redFrac < 0.30f) 1f else 0.3f
        val raw = (0.50f * coverage + 0.30f * widthFit + 0.20f * tintValidity).coerceIn(0f, 1f)

        // arrow glyphs (dark gray marks near the block edges) — debug hint only
        val arrowL = glyphFrac(frame, bestL + 2, bestL + (blockW * 3) / 10, t, b)
        val arrowR = glyphFrac(frame, bestR - (blockW * 3) / 10, bestR - 2, t, b)

        if (raw > 0.5f) {
            hit.detected = true
            hit.box.set(bestL.toFloat(), t.toFloat(), (bestR + 1).toFloat(), (b + 1).toFloat())
            hit.rawScore = raw
            geom.valid = true; geom.left = bestL.toFloat(); geom.right = (bestR + 1).toFloat()
            geom.top = t.toFloat(); geom.bottom = (b + 1).toFloat()
            hit.v0 = if (tintMismatch) 1f else 0f
            hit.v1 = blockW / barW.toFloat()
            hit.v2 = arrowL
            hit.v3 = arrowR
        }
        return raw
    }

    private fun rowBlockFrac(f: VisionFrame, x0: Int, x1: Int, row: Int): Float {
        var hit = 0; var n = 0
        var x = x0
        while (x <= x1) {
            val p = f.pixel(x, row)
            val g = f.grayAt(x, row)
            if ((g >= cfg.blockWhiteMinGray && chroma(p) < 80) ||
                (redTint(p) && g in cfg.mismatchValMin..cfg.mismatchValMax)) hit++
            n++; x += 2
        }
        return if (n == 0) 0f else hit.toFloat() / n
    }

    /** fraction of mid-gray glyph pixels (arrows) inside a vertical strip */
    private fun glyphFrac(f: VisionFrame, x0: Int, x1: Int, t: Int, b: Int): Float {
        if (x1 <= x0) return 0f
        var hit = 0; var n = 0
        var y = t
        while (y <= b) {
            var x = x0
            while (x <= x1) {
                val g = f.grayAt(x, y)
                val p = f.pixel(x, y)
                if (g in 95..175 && chroma(p) < 60) hit++
                n++; x++
            }
            y++
        }
        return if (n == 0) 0f else hit.toFloat() / n
    }
}
