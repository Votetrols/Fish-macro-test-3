package com.fischa.core.pipeline

import com.fischa.core.control.ControlAction
import com.fischa.core.safety.RobloxForegroundStatus
import com.fischa.core.state.FishingState
import com.fischa.core.vision.DetSnapshot

/**
 * Platform signals for one captured frame. [currentTimeNs] must use the same monotonic clock
 * as [frameTimestampNs]; replay defaults to the frame timestamp, Android supplies now() so
 * stale frames are rejected before an input command.
 */
class PipelineInput(
    var frameTimestampNs: Long = 0L,
    var currentTimeNs: Long = frameTimestampNs,
    var captureHealthy: Boolean = false,
    var robloxDetected: Boolean = false,
    var inputAuthorized: Boolean = false,
    var overlaySuspected: Boolean = false,
    var macroEnabled: Boolean = false,
    /** Explicit, session-scoped user opt-in. False in all defaults and replay runs. */
    var realInputEnabled: Boolean = false,
    var foregroundPackage: String = RobloxForegroundStatus.UNKNOWN,
    var foregroundActivityWindow: String = RobloxForegroundStatus.UNKNOWN,
    var foregroundBlockReason: String = "FOREGROUND_UNKNOWN",
    var foregroundTimestampMs: Long = 0L,
    // ---- V7 §1: platform screen facts for AUTO_CALIBRATION (0/unknown in replay & tests) ----
    var screenWidthPx: Int = 0,
    var screenHeightPx: Int = 0,
    var densityDpi: Int = 0,
    var rotationDeg: Int = 0,
    var appWindowWidthPx: Int = 0,
    var appWindowHeightPx: Int = 0,
    var statusBarPx: Int = 0,
    var navBarPx: Int = 0,
)

class PipelineOutput {
    // detection snapshots (owned instances — read before next call or copy)
    val fishingButton = DetSnapshot()
    val shake = DetSnapshot()
    val bar = DetSnapshot()
    val player = DetSnapshot()
    val fish = DetSnapshot()
    val progress = DetSnapshot()
    val catchConfirm = DetSnapshot()

    var state: FishingState = FishingState.IDLE
    var stateReason: String = ""

    var fishXNorm = 0f
    var playerXNorm = 0f
    var errorNorm = 0f
    var fishVel = 0f
    var playerVel = 0f
    var desiredVel = 0f
    var progressValue = 0f
    var progressRate = 0f
    var globalConfidence = 0f
    var frameAgeMs = Long.MAX_VALUE

    /** the control action the controller *intends*; executed only if safety allows */
    var intendedAction: ControlAction = ControlAction.NONE
    var tapDurationMs = 0
    var holdActive = false
    var decisionReason = ""

    var inputIssued = false
    var inputDeniedReason = ""
    var inputAuthorized = false
    var realInputEnabled = false
    var robloxDetected = false
    var foregroundPackage: String = RobloxForegroundStatus.UNKNOWN
    var foregroundActivityWindow: String = RobloxForegroundStatus.UNKNOWN
    var foregroundBlockReason: String = "FOREGROUND_UNKNOWN"
    var emergencyLatched = false
    var armed = false
    var shakeSessionTaps = 0
    var shakeSession = 0
    var castPhase = ""

    // V5 rod-button gate (spec §3/§4/§20 test mode)
    var rodDetected = false
    var rodConfidence = 0f
    var rodConfirmed = false
    var castAuthorized = false
    var castGateReason = ""

    // pixel-space helpers for the harness/tests (processing coordinates)
    val barRectPx = FloatArray(4)
    var barLocked = false
    var blockCenterPx = -1f
    var fishCenterPx = -1f

    // ---- V7 §2…§6, §9: auto-calibrated rod detection (all normalized; no fixed coordinates) --
    /** detection state machine: INIT/AUTO_CALIBRATION/SEARCHING_ROD/…/TRACKING_ROD */
    var rodState = "INIT"
    /** single-frame candidateScore of the winning candidate */
    var rodScore = 0f
    /** candidates that survived the wide search this frame */
    var rodCandidates = 0
    /** temporal confirmation streak and the (FPS-adaptive) requirement */
    var rodStreak = 0
    var rodRequiredFrames = 0
    /** true while the cheap local search inside the dynamic ROI is running */
    var rodTracking = false
    /** ms without a detection (0 while tracking) */
    var rodLostMs = 0L
    /** why the rod is not confirmed right now (goes to the log/overlay verbatim) */
    var rodReason = ""
    /** dynamic ROI around the detected button (normalized l,t,r,b) */
    val rodRoiNorm = FloatArray(4)
    /** current wide-search region (normalized) */
    val rodSearchNorm = FloatArray(4)
    /** detected button centre (normalized) */
    val rodCenterNorm = FloatArray(2)
    var rodCalibrationDone = false
    /** one-line human summary of the calibration in force */
    var rodCalibration = ""
    var rodCandidateDetail = ""

    // ---- V7 §10: layer separation (VISION/DETECTION/DECISION may run; INPUT stays blocked) --
    var layerVision = "ACTIVE"
    var layerDetection = "ACTIVE"
    var layerDecision = "ACTIVE"
    var layerInput = "DISABLED"
    val realInputLocked: Boolean get() = layerInput == "DISABLED"
}
