package com.fischa.core.safety

/**
 * Platform-neutral evidence collected by the single Android AccessibilityService monitor.
 * A missing package is unknown, never a positive result.
 *
 * Sources (all optional; the detector combines them fail-closed):
 *  - [activeAppWindowPackage]: package of the root of the *active/focused* TYPE_APPLICATION window
 *    (null when the game exposes no accessibility root — common for Unity/Roblox fullscreen).
 *  - [rootInActiveWindowPackage]: package of `rootInActiveWindow` (may also be null for games).
 *  - [lastActivityPackage]/[lastActivityClass]: the most recent TYPE_WINDOW_STATE_CHANGED event
 *    whose class name was *verified by PackageManager to be a real Activity* of that package.
 *    This is the authoritative "current app" signal for fullscreen games with no root; it is not
 *    aged out by itself because a game does not emit new events while it is simply running, but
 *    it is overridden by any newer verified activity (launcher, recents, in-call UI, our own UI…).
 *  - [lastWindowEventPackage]: legacy unverified window event (kept for compatibility/tests); it is
 *    only trusted for [maxWindowEventAgeMs] and never over a conflicting live source.
 *  - [appWindowPackages]: root packages of *all* TYPE_APPLICATION windows (for conflict detection).
 *  - [incompatibleOverlay]: an active system / IME / foreign accessibility window covers the game.
 */
data class ForegroundObservation(
    val activeAppWindowPackage: String? = null,
    val rootInActiveWindowPackage: String? = null,
    val lastWindowEventPackage: String? = null,
    val foregroundActivity: String? = null,
    val activeWindow: String? = null,
    val incompatibleOverlay: Boolean = false,
    val accessibilityAvailable: Boolean = true,
    val screenInteractive: Boolean = true,
    val timestampMs: Long,
    /** Timestamp of the cached event source; old events cannot authorize a fullscreen window. */
    val lastWindowEventTimestampMs: Long? = timestampMs,
    // ---- V3 / Galaxy A22 additions -------------------------------------------------------
    val lastActivityPackage: String? = null,
    val lastActivityClass: String? = null,
    val lastActivityTimestampMs: Long? = null,
    /** Root packages of every TYPE_APPLICATION window currently on screen (may be empty). */
    val appWindowPackages: List<String> = emptyList(),
    /** True when a TYPE_APPLICATION window is active/focused but its root package is unknown. */
    val activeAppWindowRootMissing: Boolean = false,
)

data class RobloxForegroundStatus(
    val foregroundPackage: String = UNKNOWN,
    val foregroundActivityWindow: String = UNKNOWN,
    val robloxDetected: Boolean = false,
    val inputAuthorized: Boolean = false,
    val blockReason: String = "FOREGROUND_UNKNOWN",
    val timestampMs: Long = 0L,
    val overlayActive: Boolean = false,
    /** Which evidence produced [robloxDetected] (for logs): ACTIVE_WINDOW / ROOT / ACTIVITY / EVENT / NONE. */
    val evidenceSource: String = "NONE",
) {
    companion object {
        const val UNKNOWN = "<unknown>"
        fun unknown(timestampMs: Long, reason: String = "FOREGROUND_UNKNOWN") =
            RobloxForegroundStatus(timestampMs = timestampMs, blockReason = reason)
    }
}

/**
 * The one package/window decision rule used by UI diagnostics, engine and gesture watchdog.
 *
 * Decision (fail-closed):
 *  1. Any *live* source (active app window root, rootInActiveWindow) that names a package other
 *     than Roblox → NOT detected (FOREGROUND_PACKAGE_MISMATCH).
 *  2. Else if a live source names Roblox → detected (ACTIVE_WINDOW / ROOT).
 *  3. Else if the last verified Activity transition belongs to Roblox and no other app window is
 *     active → detected (ACTIVITY). This is the Roblox-fullscreen-without-root case that broke the
 *     previous real test (the old rule aged the event out after 3 s and ended in FOREGROUND_UNKNOWN).
 *  4. Else if a *fresh* unverified window event names Roblox (≤ maxWindowEventAgeMs) → detected (EVENT).
 *  5. Else → not detected. Unknown is never allowed.
 *
 * Authorization additionally requires: accessibility connected, screen interactive, no
 * incompatible overlay.
 */
class RobloxForegroundDetector(
    private val expectedPackage: String = ROBLOX_PACKAGE,
    private val maxWindowEventAgeMs: Long = 3_000L,
    /** Verified activity evidence older than this is treated as unknown (0 = never expires). */
    private val maxActivityAgeMs: Long = 0L,
) {
    init {
        require(maxWindowEventAgeMs >= 0L)
        require(maxActivityAgeMs >= 0L)
    }

    fun evaluate(observation: ForegroundObservation): RobloxForegroundStatus {
        val active = normalize(observation.activeAppWindowPackage)
        val root = normalize(observation.rootInActiveWindowPackage)

        val eventTimestamp = observation.lastWindowEventTimestampMs
        val eventAgeMs = eventTimestamp?.let { observation.timestampMs - it } ?: Long.MAX_VALUE
        val eventFresh = eventAgeMs >= 0L && eventAgeMs <= maxWindowEventAgeMs
        val event = if (eventFresh) normalize(observation.lastWindowEventPackage) else null

        val activityTs = observation.lastActivityTimestampMs
        val activityAgeMs = activityTs?.let { observation.timestampMs - it } ?: Long.MAX_VALUE
        val activityFresh = observation.lastActivityPackage != null &&
            (maxActivityAgeMs == 0L || (activityAgeMs >= 0L && activityAgeMs <= maxActivityAgeMs))
        val activity = if (activityFresh) normalize(observation.lastActivityPackage) else null

        // Live sources are authoritative in both directions.
        val liveSources = listOfNotNull(active, root)
        val liveConflict = liveSources.any { it != expectedPackage }
        val liveMatch = liveSources.any { it == expectedPackage }

        val detected: Boolean
        val source: String
        val mismatchDetail: String?
        when {
            liveConflict -> {
                detected = false
                source = "NONE"
                mismatchDetail = liveSources.first { it != expectedPackage }
            }
            liveMatch -> {
                detected = true
                source = if (active == expectedPackage) "ACTIVE_WINDOW" else "ROOT"
                mismatchDetail = null
            }
            activity != null -> {
                detected = activity == expectedPackage
                source = if (detected) "ACTIVITY" else "NONE"
                mismatchDetail = if (detected) null else activity
            }
            event != null -> {
                detected = event == expectedPackage
                source = if (detected) "EVENT" else "NONE"
                mismatchDetail = if (detected) null else event
            }
            else -> {
                detected = false
                source = "NONE"
                mismatchDetail = null
            }
        }

        val resolved = when {
            liveConflict -> mismatchDetail ?: RobloxForegroundStatus.UNKNOWN
            active != null -> active
            root != null -> root
            activity != null -> activity
            event != null -> event
            else -> RobloxForegroundStatus.UNKNOWN
        }
        val anyEvidence = liveSources.isNotEmpty() || activity != null || event != null

        val reason = when {
            !observation.accessibilityAvailable -> "ACCESSIBILITY_UNAVAILABLE"
            !observation.screenInteractive -> "SCREEN_NOT_INTERACTIVE"
            observation.incompatibleOverlay -> "INCOMPATIBLE_OVERLAY"
            !anyEvidence -> "FOREGROUND_UNKNOWN"
            mismatchDetail != null -> "FOREGROUND_PACKAGE_MISMATCH"
            !detected -> "ROBLOX_NOT_CONFIRMED"
            else -> "NONE"
        }
        val authorized = detected && observation.accessibilityAvailable &&
            observation.screenInteractive && !observation.incompatibleOverlay

        val activityLabel = observation.lastActivityClass?.takeIf { it.isNotBlank() }
            ?: observation.foregroundActivity?.takeIf { it.isNotBlank() }
        val window = listOfNotNull(
            activityLabel,
            observation.activeWindow?.takeIf { it.isNotBlank() },
        ).joinToString(" | ").ifBlank { RobloxForegroundStatus.UNKNOWN }

        return RobloxForegroundStatus(
            foregroundPackage = resolved,
            foregroundActivityWindow = window,
            robloxDetected = detected,
            inputAuthorized = authorized,
            blockReason = if (authorized) "NONE" else reason,
            timestampMs = observation.timestampMs,
            overlayActive = observation.incompatibleOverlay,
            evidenceSource = source,
        )
    }

    private fun normalize(packageName: String?): String? = packageName
        ?.trim()
        ?.takeIf { it.isNotEmpty() && it != RobloxForegroundStatus.UNKNOWN }

    companion object {
        const val ROBLOX_PACKAGE = "com.roblox.client"
    }
}
