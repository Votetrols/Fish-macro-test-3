package com.fischa.core.state

import com.fischa.core.config.AppConfig
import kotlin.math.max
import kotlin.math.min

/** What the detector/tracker layer reports per frame (booleans + confidences). */
class Evidence {
    var fishingButton = false; var fishingButtonConf = 0f
    var shake = false; var shakeConf = 0f
    var bar = false; var barConf = 0f
    var fishOk = false; var playerOk = false
    var progress = -1f
    var catchConfirm = false; var catchConfirmConf = 0f
    var robloxForeground = false
    var captureHealthy = false
    var globalConf = 0f
    var overlaySuspected = false   // system UI covers the screen (darkened + foreign ui)
    var nowNs = 0L
    var dtSec = 1f / 30f
    /** shake session hint from ShakeController (prompt vanished → may reappear elsewhere) */
    var shakeGone = false
    // ---- V5 rod-button gate (spec §3/§4/§5) ----
    /** rod button passed temporal + confidence + stability confirmation this frame */
    var rodConfirmed = false
    /** InputSafetyGuard authorizes WAITING_FOR_ROD → CASTING right now */
    var castAuthorized = false
    /** CastController completed the hold (release issued after CAST_HOLD_DURATION_MS) */
    var castComplete = false
    /** CastController aborted the hold (rod target lost mid-press) */
    var castAborted = false
}

/**
 * Explicit fishing-cycle state machine (spec §11; V5 flow §2). Transitions require *visual +
 * temporal* evidence; dwells are measured in frames/monotonic time, never in assumed game
 * durations. No timer ever *starts* a cycle — timers only act as safety timeouts that return
 * the machine to WAITING_FOR_ROD, where a fresh visual rod-button confirmation is required.
 *
 *   IDLE → WAITING_FOR_ROD → CASTING → WAITING_FOR_WATER → SEARCHING_SHAKE ⇄ PRESSING_SHAKE →
 *   FISHING_MINIGAME_DETECTED → TRACKING_FISH → CONTROLLING_PLAYER_BAR →
 *   CATCH_CONFIRMATION → RESET → WAITING_FOR_ROD ...
 *
 * V5 rod-button gate (spec §4): while WAITING_FOR_ROD the machine may ONLY leave via
 *   rodConfirmed && castAuthorized → CASTING.
 * If the rod button is not detected (or its confidence is below threshold, or Roblox is not
 * confirmed in the foreground, or the InputSafetyGuard does not authorize), the machine
 * stays in WAITING_FOR_ROD and no cast/shake/minigame action is ever started.
 *
 * Error states (VISION_LOST / CAPTURE_ERROR / ROBLOX_NOT_DETECTED / INVALID_STATE /
 * EMERGENCY_STOP) are entered whenever their guard fails; recovery always returns through
 * RESET, never straight back into the cycle (fail-safe first).
 *
 * The machine never issues input; it only tracks "where are we in the cycle".
 */
class FishingStateMachine(private val cfg: AppConfig.StateTiming) {

    var state = FishingState.IDLE; private set
    var enteredAtNs = 0L; private set
    var lastReason = "init"; private set

    /** set by the host (UI "Start" pressed) */
    var armed = false

    var shakeSession = 0; private set

    /** minimum aggregate confidence before the "vision lost" timer runs */
    var globalConfFloor = 0.28f

    private val listeners = ArrayList<(StateChange) -> Unit>()
    fun addListener(l: (StateChange) -> Unit) { synchronized(listeners) { listeners.add(l) } }
    fun removeListener(l: (StateChange) -> Unit) { synchronized(listeners) { listeners.remove(l) } }

    private fun enter(s: FishingState, nowNs: Long, why: String) {
        if (state == s) return
        val from = state
        if (s == FishingState.CATCH_CONFIRMATION) {
            catchConfirmed = false
            catchClearFrames = 0
            rodRecoveryFrames = 0
        } else if (s == FishingState.RESET && from != FishingState.CATCH_CONFIRMATION) {
            catchConfirmed = false
            catchClearFrames = 0
            rodRecoveryFrames = 0
        }
        state = s; enteredAtNs = nowNs; lastReason = why
        val copy = synchronized(listeners) { ArrayList(listeners) }
        copy.forEach { runCatching { it(StateChange(from, s, why, nowNs)) } }
    }

    fun resetAll(nowNs: Long) = enter(FishingState.RESET, nowNs, "manual reset")
    fun emergencyStop(nowNs: Long) = enter(FishingState.EMERGENCY_STOP, nowNs, "emergency stop")

    /** the host should run the shake-tap loop while this is true */
    fun shakePhaseActive(): Boolean =
        state == FishingState.SEARCHING_SHAKE || state == FishingState.PRESSING_SHAKE

    private var barStreak = 0
    private var barLostStreak = 0
    private var noEvidenceSince = -1L
    private var nonRobloxSince = -1L
    private var catchConfirmed = false
    private var catchClearFrames = 0
    private var rodRecoveryFrames = 0

    /** One evaluation per frame; [Evidence] is caller-owned (reused object). */
    fun update(e: Evidence) {
        val now = e.nowNs

        // ---- hard guards (every state except EMERGENCY_STOP) -------------------------------
        if (state != FishingState.EMERGENCY_STOP) {
            if (!e.captureHealthy && state != FishingState.IDLE && state != FishingState.CAPTURE_ERROR) {
                enter(FishingState.CAPTURE_ERROR, now, "capture stream dead")
            }
            if ((!e.robloxForeground || e.overlaySuspected) && state != FishingState.IDLE &&
                state != FishingState.ROBLOX_NOT_DETECTED
            ) {
                if (nonRobloxSince < 0L) nonRobloxSince = now
                if (now - nonRobloxSince > 1_000_000_000L) {
                    enter(FishingState.ROBLOX_NOT_DETECTED, now, "roblox window gone / overlay suspected")
                    nonRobloxSince = -1L
                }
            } else nonRobloxSince = -1L

            if (state != FishingState.VISION_LOST && state != FishingState.IDLE && state != FishingState.ROBLOX_NOT_DETECTED) {
                val visionMissing = e.globalConf < globalConfFloor && !e.bar && !e.fishingButton && !e.shake
                if (visionMissing) {
                    if (noEvidenceSince < 0L) noEvidenceSince = now
                    if (now - noEvidenceSince > cfg.visionLostAfterMs * 1_000_000L) {
                        enter(FishingState.VISION_LOST, now, "no game evidence for ${cfg.visionLostAfterMs}ms")
                        noEvidenceSince = -1L
                    }
                } else noEvidenceSince = -1L
            }
        }

        // ---- error recovery: healthy + any game evidence → RESET (never direct resume) -----
        if (state.isError && state != FishingState.EMERGENCY_STOP) {
            val healthy = e.captureHealthy && e.robloxForeground && !e.overlaySuspected
            if (healthy && (e.bar || e.fishingButton || e.shake)) {
                enter(FishingState.RESET, now, "recovered from ${state.name.lowercase()}")
            }
            return
        }
        if (state == FishingState.EMERGENCY_STOP) return

        // ---- normal cycle -------------------------------------------------------------------
        when (state) {
            FishingState.IDLE -> {
                if (armed) enter(FishingState.WAITING_FOR_ROD, now, "armed; observing the screen")
            }

            FishingState.WAITING_FOR_ROD -> {
                // V5 §4: the visually confirmed rod button + safety authorization is the ONLY
                // exit. No bar/shake shortcut, no timer, no fixed coordinate: if the rod button
                // is not confirmed, we keep waiting (and never touch, hold or click).
                if (e.rodConfirmed && e.castAuthorized) {
                    enter(
                        FishingState.CASTING, now,
                        "rod button confirmed (conf=%.2f) + input authorized".format(e.fishingButtonConf),
                    )
                }
            }

            FishingState.CASTING -> {
                // CastController owns the press; the machine watches for phase evidence.
                if (e.castComplete) {
                    enter(FishingState.WAITING_FOR_WATER, now, "cast hold released; waiting for water evidence")
                    return
                }
                if (e.castAborted) {
                    enter(FishingState.WAITING_FOR_ROD, now, "cast target lost mid-press; back to rod watch")
                    return
                }
                if (e.shake) { enter(FishingState.WAITING_FOR_WATER, now, "shake during cast"); return }
                if (e.bar) {
                    barStreak++
                    if (barStreak >= cfg.minigameEnterFrames) {
                        barStreak = 0
                        enter(FishingState.WAITING_FOR_WATER, now, "minigame during cast")
                    }
                    return
                } else barStreak = 0
                if (now - enteredAtNs > 12_000_000_000L)
                    enter(FishingState.WAITING_FOR_ROD, now, "cast produced no evidence")
            }

            FishingState.WAITING_FOR_WATER -> {
                // V5 §7: after the cast, do NOT start Shake immediately and do not rely on a
                // fixed sleep — wait for the visual evidence (shake prompt or minigame bar).
                if (e.shake) { enter(FishingState.SEARCHING_SHAKE, now, "shake after cast"); return }
                if (e.bar) {
                    barStreak++
                    if (barStreak >= cfg.minigameEnterFrames) {
                        barStreak = 0
                        enter(FishingState.FISHING_MINIGAME_DETECTED, now, "minigame after cast")
                    }
                    return
                } else barStreak = 0
                // safety timeout only: it never starts a cycle, it just returns to the rod watch
                if (now - enteredAtNs > cfg.waitingForWaterMs * 1_000_000L)
                    enter(FishingState.WAITING_FOR_ROD, now, "no water evidence after cast; back to rod watch")
            }

            FishingState.SEARCHING_SHAKE -> {
                if (e.shake) {
                    enter(FishingState.PRESSING_SHAKE, now, "shake detected conf=%.2f".format(e.shakeConf))
                    return
                }
                if (e.bar) {
                    barStreak++
                    if (barStreak >= cfg.minigameEnterFrames) {
                        barStreak = 0
                        enter(FishingState.FISHING_MINIGAME_DETECTED, now, "no shake, straight to minigame")
                    }
                    return
                } else barStreak = 0
            }

            FishingState.PRESSING_SHAKE -> {
                if (e.shake) return                       // keep hammering while present
                barLostStreak++
                if (e.bar) {
                    barStreak++
                    if (barStreak >= cfg.minigameEnterFrames) {
                        barStreak = 0; barLostStreak = 0
                        enter(FishingState.FISHING_MINIGAME_DETECTED, now, "shake ended, minigame starts")
                    }
                    return
                }
                // shake gone & no bar yet → back to searching (it may reappear elsewhere)
                if (e.shakeGone || barLostStreak >= 4) {
                    barLostStreak = 0
                    shakeSession++
                    enter(FishingState.SEARCHING_SHAKE, now, "shake cleared (session $shakeSession)")
                }
            }

            FishingState.FISHING_MINIGAME_DETECTED -> {
                if (e.fishOk && e.playerOk) enter(FishingState.TRACKING_FISH, now, "trackers ready")
                else if (now - enteredAtNs > 700_000_000L) enter(FishingState.TRACKING_FISH, now, "force-track after dwell")
                if (!e.bar) {
                    barLostStreak++
                    if (barLostStreak >= cfg.minigameExitFrames) {
                        barLostStreak = 0
                        toCatchOrReset(e, now)
                    }
                } else barLostStreak = 0
            }

            FishingState.TRACKING_FISH ->
                enter(FishingState.CONTROLLING_PLAYER_BAR, now, "tracking→control")

            FishingState.CONTROLLING_PLAYER_BAR -> {
                if (!e.bar) {
                    barLostStreak++
                    if (barLostStreak >= cfg.minigameExitFrames) {
                        barLostStreak = 0
                        toCatchOrReset(e, now)
                    }
                    return
                }
                barLostStreak = 0
                // dwell protection: a minigame cannot exceed sane bounds forever
                if (now - enteredAtNs > 180_000_000_000L)
                    enter(FishingState.INVALID_STATE, now, "minigame dwell > 180s")
            }

            FishingState.CATCH_CONFIRMATION -> {
                val dwell = now - enteredAtNs
                if (e.catchConfirm && e.catchConfirmConf >= 0.50f) {
                    catchConfirmed = true
                    catchClearFrames = 0
                    rodRecoveryFrames = 0
                    enter(FishingState.RESET, now, "visual catch confirmation detected")
                } else if (dwell > cfg.confirmWindowMs * 1_000_000L) {
                    // A timer is only a safety timeout: it never declares a catch or recasts.
                    enter(FishingState.VISION_LOST, now, "catch confirmation not observed; automatic recast inhibited")
                }
            }

            FishingState.RESET -> {
                val dwellComplete = now - enteredAtNs >= cfg.resetDwellMs * 1_000_000L
                if (!catchConfirmed && dwellComplete) {
                    enter(FishingState.WAITING_FOR_ROD, now, "recovery after non-catch exit")
                } else if (catchConfirmed) {
                    catchClearFrames = if (e.catchConfirm) 0 else catchClearFrames + 1
                    rodRecoveryFrames = if (e.fishingButton) rodRecoveryFrames + 1 else 0
                    if (dwellComplete && catchClearFrames >= 2 && rodRecoveryFrames >= 2) {
                        catchConfirmed = false
                        enter(FishingState.WAITING_FOR_ROD, now, "confirmed notice cleared; rod button restored")
                    }
                }
            }

            else -> enter(FishingState.INVALID_STATE, now, "unhandled state")
        }

        // stale watchdog while armed
        if (state != FishingState.IDLE && e.globalConf < globalConfFloor &&
            now - enteredAtNs > 20_000_000_000L
        ) enter(FishingState.VISION_LOST, now, "long stale period")
    }

    private fun toCatchOrReset(e: Evidence, now: Long) {
        val winning = e.progress >= cfg.catchMinProgress || e.catchConfirm
        if (winning) enter(FishingState.CATCH_CONFIRMATION, now, "bar gone with progress=%.2f".format(max(0f, e.progress)))
        else enter(FishingState.RESET, now, "bar gone without progress (escape/fail)")
    }

    companion object {
        fun clampDt(prev: Long, now: Long): Float =
            if (prev <= 0L) 1f / 30f else min(0.25f, max(0.0005f, (now - prev) / 1e9f))
    }
}
