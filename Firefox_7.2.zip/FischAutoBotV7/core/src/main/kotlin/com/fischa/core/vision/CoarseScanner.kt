package com.fischa.core.vision

import kotlin.math.max
import kotlin.math.min

/**
 * V7 §2 FASE A / §11 — cheap "where could a dark disc with a brighter ring be?" pass.
 *
 * The wide search in the V6 code scored every (cx, cy, r) at full resolution over a large region
 * every frame. V7 keeps the same idea but runs it on a **coarse map** (mean luminance per
 * [step]×[step] cell) with a **summed-area table**, so the ring/interior/outside means of a
 * candidate cost 12 array lookups instead of ~70 pixel reads. That is what makes it affordable to
 * search a wide, screen-proportional region on every frame of a Galaxy A22.
 *
 * The result is only a *candidate list*: one score per likely dark-disc center. The expensive,
 * discriminative feature work (roundness, glyph, white-text rejection, temporal persistence) runs
 * afterwards at full resolution on the few survivors — see [RodFinder].
 *
 * Everything here is relative: the caller passes the region in processing pixels and the radius
 * band in *coarse* cells, both derived from [com.fischa.core.calib.CalibrationConfig].
 */
class CoarseScanner {

    /** One raw hit, expressed in coarse-cell units of the map prepared by [prepare]. */
    class Hit {
        var cx = 0f; var cy = 0f; var r = 0f
        var contrast = 0f
        var interior = 0f
        var outside = 0f
        var darkness = 0f
        var score = 0f
        fun set(o: Hit) { cx = o.cx; cy = o.cy; r = o.r; contrast = o.contrast; interior = o.interior; outside = o.outside; darkness = o.darkness; score = o.score }
    }

    private var mapW = 0
    private var mapH = 0
    private var step = 4
    private var originX = 0
    private var originY = 0
    private var map = FloatArray(0)
    private var sat = FloatArray(0)

    var lastCentersScored = 0
        private set
    var lastCellsBuilt = 0
        private set

    /** mean luminance of the coarse cell (x, y); used by callers that need the local background */
    fun cell(cx: Int, cy: Int): Float =
        if (cx in 0 until mapW && cy in 0 until mapH) map[cy * mapW + cx] else -1f

    /**
     * Builds the coarse map for [frame]. [step] is chosen by the calibration (≈4 px wide search)
     * so that the map stays around 160×72 cells — the cost is proportional to the searched area,
     * never to the display resolution.
     *
     * [regionPx] (optional `[x0, y0, x1, y1]`) restricts the map to the region that is about to
     * be scanned: that is what makes local tracking inside the dynamic ROI almost free — a
     * 100×100 px window costs ~600 cells instead of the whole frame (V7 §11).
     */
    fun prepare(frame: VisionFrame, step: Int, regionPx: IntArray? = null) {
        val s = step.coerceIn(2, 12)
        val rx0 = (regionPx?.get(0) ?: 0).coerceIn(0, frame.width - 1)
        val ry0 = (regionPx?.get(1) ?: 0).coerceIn(0, frame.height - 1)
        val rx1 = (regionPx?.get(2) ?: frame.width).coerceIn(rx0 + 2, frame.width)
        val ry1 = (regionPx?.get(3) ?: frame.height).coerceIn(ry0 + 2, frame.height)
        val cw = max(2, (rx1 - rx0) / s)
        val ch = max(2, (ry1 - ry0) / s)
        if (cw != mapW || ch != mapH || this.step != s || originX != rx0 || originY != ry0) {
            mapW = cw; mapH = ch; this.step = s
            originX = rx0; originY = ry0
            map = FloatArray(cw * ch)
            sat = FloatArray((cw + 1) * (ch + 1))
        }
        // 4 samples per cell: enough for a stable mean, 4× cheaper than reading every pixel.
        val gray = frame.gray
        val w = frame.width
        val half = s / 2
        var idx = 0
        for (cy in 0 until ch) {
            val y0 = (originY + cy * s + half).coerceIn(0, frame.height - 1)
            for (cx in 0 until cw) {
                val x0 = (originX + cx * s + half).coerceIn(0, w - 1)
                var sum = 0; var n = 0
                // 4 taps around the cell centre
                for (dy in -half..half step max(1, s - 1)) {
                    val y = (y0 + dy).coerceIn(0, frame.height - 1)
                    for (dx in -half..half step max(1, s - 1)) {
                        val x = (x0 + dx).coerceIn(0, w - 1)
                        sum += gray[y * w + x].toInt() and 0xFF
                        n++
                    }
                }
                map[idx++] = if (n > 0) sum.toFloat() / n else 0f
            }
        }
        lastCellsBuilt = cw * ch
        buildSat()
    }

    private fun buildSat() {
        val sw = mapW + 1
        var i = 0
        // row 0 and column 0 stay zero
        for (x in 0..mapW) sat[x] = 0f
        for (y in 1..mapH) {
            var rowSum = 0f
            sat[y * sw] = 0f
            for (x in 1..mapW) {
                rowSum += map[(y - 1) * mapW + (x - 1)]
                sat[y * sw + x] = sat[(y - 1) * sw + x] + rowSum
            }
        }
        i = 0 // kept for clarity; the prefix loop above is the whole SAT
    }

    /** mean of the axis-aligned box around (cx, cy) with half-size [r] cells (clamped to the map) */
    private fun boxMean(cx: Float, cy: Float, r: Float): Float {
        if (r <= 0f) return 0f
        val x0 = (cx - r).toInt().coerceIn(0, mapW - 1)
        val x1 = (cx + r).toInt().coerceIn(0, mapW - 1)
        val y0 = (cy - r).toInt().coerceIn(0, mapH - 1)
        val y1 = (cy + r).toInt().coerceIn(0, mapH - 1)
        if (x1 < x0 || y1 < y0) return 0f
        val sw = mapW + 1
        val a = sat[y0 * sw + x0]
        val b = sat[y0 * sw + (x1 + 1)]
        val c = sat[(y1 + 1) * sw + x0]
        val d = sat[(y1 + 1) * sw + (x1 + 1)]
        val area = (x1 - x0 + 1) * (y1 - y0 + 1)
        return (d - b - c + a) / area
    }

    private fun boxMeanX(cx: Float, cy: Float, rx: Float, ry: Float): Float {
        val sw = mapW + 1
        val x0 = (cx - rx).toInt().coerceIn(0, mapW - 1)
        val x1 = (cx + rx).toInt().coerceIn(0, mapW - 1)
        val y0 = (cy - ry).toInt().coerceIn(0, mapH - 1)
        val y1 = (cy + ry).toInt().coerceIn(0, mapH - 1)
        if (x1 < x0 || y1 < y0) return 0f
        val a = sat[y0 * sw + x0]
        val b = sat[y0 * sw + (x1 + 1)]
        val c = sat[(y1 + 1) * sw + x0]
        val d = sat[(y1 + 1) * sw + (x1 + 1)]
        val area = (x1 - x0 + 1) * (y1 - y0 + 1)
        return (d - b - c + a) / area
    }

    /**
     * Scans [regionPx] = [x0, y0, x1, y1] (processing pixels) for dark discs whose ring band is
     * brighter than both the interior and the surroundings.
     *
     * @param minRc/maxRc radius band in coarse cells (from the calibration size band ÷ step)
     * @param centerStride step between scanned centers in coarse cells (2 keeps the wide pass
     *        cheap; the full-resolution refinement recovers the sub-cell position)
     * @param limit maximum number of hits kept (best score first)
     */
    fun scan(
        regionPx: IntArray,
        minRc: Float,
        maxRc: Float,
        limit: Int,
        centerStride: Int,
        interiorMaxGray: Float,
        out: ArrayList<Hit>,
    ) {
        out.clear()
        if (mapW < 4 || mapH < 4) return
        val x0c = ((regionPx[0] - originX) / step).coerceIn(0, mapW - 1)
        val y0c = ((regionPx[1] - originY) / step).coerceIn(0, mapH - 1)
        val x1c = ((regionPx[2] - originX) / step).coerceIn(0, mapW - 1)
        val y1c = ((regionPx[3] - originY) / step).coerceIn(0, mapH - 1)
        if (x1c <= x0c || y1c <= y0c) return

        val rLo = max(2f, minRc)
        val rHi = max(rLo + 1f, maxRc)
        val rSteps = if (rHi - rLo <= 4f) 4 else 6
        val rInc = max(1f, (rHi - rLo) / rSteps)
        val stride = centerStride.coerceAtLeast(1)

        // The prepared map already covers the requested region *plus* the ring margin (see
        // prepare()), so the loop walks the requested region exactly — no extra inset that would
        // silently shrink the search area.
        var cyi = y0c
        var scored = 0
        while (cyi <= y1c) {
            var cxi = x0c
            while (cxi <= x1c) {
                val cx = cxi.toFloat()
                val cy = cyi.toFloat()
                var r = rLo
                while (r <= rHi) {
                    scored++
                    val innerR = r * 0.62f
                    val ringOut = r * 1.12f
                    val ringIn = r * 0.78f
                    val outerOut = r * 1.75f
                    val outerIn = r * 1.28f
                    val inner = boxMean(cx, cy, innerR)
                    val ringArea = boxMean(cx, cy, ringOut) * (ringOut * 2 + 1) * (ringOut * 2 + 1) -
                        boxMean(cx, cy, ringIn) * (ringIn * 2 + 1) * (ringIn * 2 + 1)
                    val ringAreaPx = ((ringOut * 2 + 1) * (ringOut * 2 + 1)) - ((ringIn * 2 + 1) * (ringIn * 2 + 1))
                    val ring = if (ringAreaPx > 0f) ringArea / ringAreaPx else 0f
                    val outerArea = boxMean(cx, cy, outerOut) * (outerOut * 2 + 1) * (outerOut * 2 + 1) -
                        boxMean(cx, cy, outerIn) * (outerIn * 2 + 1) * (outerIn * 2 + 1)
                    val outerAreaPx = ((outerOut * 2 + 1) * (outerOut * 2 + 1)) - ((outerIn * 2 + 1) * (outerIn * 2 + 1))
                    val outer = if (outerAreaPx > 0f) outerArea / outerAreaPx else 0f
                    val contrast = ring - (0.55f * inner + 0.45f * outer)
                    val interiorOk = inner <= interiorMaxGray
                    if (interiorOk && contrast > 4f) {
                        val darkness = (1f - (inner / interiorMaxGray)).coerceIn(0f, 1f)
                        val score = 0.62f * (contrast / 60f).coerceAtMost(1.4f) + 0.38f * darkness
                        if (score > 0.42f) {
                            val hit = Hit()
                            hit.cx = originX / step.toFloat() + cx
                            hit.cy = originY / step.toFloat() + cy
                            hit.r = r
                            hit.contrast = contrast; hit.interior = inner; hit.outside = outer
                            hit.darkness = darkness; hit.score = score
                            insertSorted(out, hit, limit)
                        }
                    }
                    r += rInc
                }
                cxi += stride
            }
            cyi += stride
        }
        lastCentersScored = scored
    }

    /** keeps [out] sorted by score (descending), at most [limit] entries, suppressing near-dupes */
    private fun insertSorted(out: ArrayList<Hit>, hit: Hit, limit: Int) {
        val minDist = hit.r * 0.9f
        for (i in out.indices) {
            val o = out[i]
            val dx = o.cx - hit.cx; val dy = o.cy - hit.cy
            if (dx * dx + dy * dy < minDist * minDist) {
                if (hit.score > o.score) o.set(hit)
                return
            }
        }
        var pos = out.size
        for (i in out.indices) {
            if (hit.score > out[i].score) { pos = i; break }
        }
        if (pos >= limit) return
        out.add(pos, hit)
        if (out.size > limit) out.removeAt(out.size - 1)
    }

    /** Diagnostic: the mean/std of the coarse map, used by the calibration noise floor. */
    fun statistics(): Pair<Float, Float> {
        if (map.isEmpty()) return 0f to 0f
        var sum = 0.0; var sum2 = 0.0
        for (v in map) { sum += v; sum2 += v.toDouble() * v }
        val n = map.size
        val mean = (sum / n).toFloat()
        val variance = max(0.0, sum2 / n - mean.toDouble() * mean).toFloat()
        return mean to kotlin.math.sqrt(variance)
    }
}
