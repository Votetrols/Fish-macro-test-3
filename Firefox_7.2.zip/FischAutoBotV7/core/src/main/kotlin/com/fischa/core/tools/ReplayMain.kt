package com.fischa.core.tools

import com.fischa.core.control.InputExecutor
import com.fischa.core.debug.RenderModel
import com.fischa.core.config.AppConfig
import com.fischa.core.log.LogSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.pipeline.PipelineInput
import com.fischa.core.pipeline.VisionPipeline
import com.fischa.core.vision.VisionFrame
import java.awt.Color
import java.awt.Font
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO

/**
 * Replay harness (spec §26 "prepared for joint testing"): feeds real video frames through the
 * exact production pipeline and validates detection against offline ground truth. Runnable on
 * plain JVM:
 *
 *   java com.fischa.core.tools.ReplayMainKt <framesDir> [outDir] [csvOut]
 *
 * framesDir contains `f_NNNN.jpg|png` frames (1066×480 from the reference video or any
 * recording) and optionally `gt.csv` with rows:
 *   frame,blockLeft,blockTop,blockRight,blockBottom          (video pixel coords)
 * and `meta.txt`:  minigameStart=NNNN / minigameEnd=NNNN.
 *
 * Produces a per-frame CSV, annotated debug frames, and a PASS/FAIL summary.
 */
object ReplayMain {

    private class DryExecutor : InputExecutor {
        var taps = 0
        override fun tap(nx: Float, ny: Float, durationMs: Int) { taps++ }
        override fun cancelAll() {}
    }

    private const val PROC_W = 640

    @JvmStatic
    fun main(args: Array<String>) {
        val framesDir = File(args.getOrNull(0) ?: error("usage: ReplayMain <framesDir> [outDir] [csv]"))
        val outDir = File(args.getOrNull(1) ?: "replay_out").apply { mkdirs() }
        val csvOut = File(args.getOrNull(2) ?: File(outDir, "replay.csv").path)

        val files = framesDir.listFiles { f -> f.name.matches(Regex("f_\\d+\\.(jpg|jpeg|png)")) }
            ?.sortedBy { it.name } ?: emptyList()
        require(files.isNotEmpty()) { "no f_NNNN.jpg frames in $framesDir" }

        val gt = readGt(File(framesDir, "gt.csv"))
        val (mgStart, mgEnd) = readMeta(File(framesDir, "meta.txt"))
        println("frames=${files.size} minigame window=$mgStart..$mgEnd gt rows=${gt.size}")

        val executor = DryExecutor()                       // FASE 3: decisions only, no input
        val logLines = ArrayList<String>()
        val sink = LogSink { level, tag, msg, _ -> logLines.add("[$tag] $msg") }
        val cfg = AppConfig()
        val pipeline = VisionPipeline(cfg, executor, ThrottledLog(sink))
        pipeline.armed = true

        var failCount = 0
        var blockHits = 0; var blockTotal = 0; var blockErrMax = 0f
        var barIn = 0; var barOut = 0; var fishFrames = 0; var progressFrames = 0
        var firstMinigame = -1; var lastMinigame = -1
        var shakeFrames = 0; var rodFrames = 0
        val statesSeen = LinkedHashMap<String, Int>()

        val csv = csvOut.bufferedWriter()
        val t0 = System.currentTimeMillis()

        for ((idx, f) in files.withIndex()) {
            val n = f.name.substringAfter('_').substringBefore('.').toInt()
            val img = ImageIO.read(f) ?: continue
            val sf = PROC_W.toFloat() / img.width
            val ph = (img.height * sf).toInt().coerceAtLeast(16)
            val frame = VisionFrame(PROC_W, ph, IntArray(PROC_W * ph), ByteArray(PROC_W * ph))
            downscale(img, frame)
            frame.resetFor(n * 1_000_000_000L / 15, n.toLong())
            frame.fps = 15f
            pipeline.setFpsMeasured(15f)

            val input = PipelineInput(
                frameTimestampNs = n * 1_000_000_000L / 15,
                captureHealthy = true,
                robloxDetected = true,
                inputAuthorized = true,
                macroEnabled = true,
                realInputEnabled = false,
                foregroundPackage = "com.roblox.client",
                foregroundActivityWindow = "replay-window",
                foregroundBlockReason = "NONE",
            )
            pipeline.onFrame(frame, input)
            val o = pipeline.output

            val inMg = mgStart in 0..n && n <= mgEnd
            if (inMg) { if (o.barLocked) barIn++ } else if (!o.barLocked) barOut++
            if (o.barLocked) {
                if (firstMinigame < 0) firstMinigame = n
                lastMinigame = n
            }
            if (o.player.detected) fishFrames++
            if (o.fish.detected) { /* counted separately below */ }
            if (o.shake.detected) shakeFrames++
            if (o.fishingButton.detected) rodFrames++
            if (o.progress.detected) progressFrames++

            if (o.player.detected) {
                val g = gt[n]
                if (g != null) {
                    blockTotal++
                    val predCxPx = o.blockCenterPx
                    val gtCxPx = (g[0] + g[2]) / 2f * sf
                    val err = Math.abs(predCxPx - gtCxPx)
                    blockHits++
                    if (err > blockErrMax) blockErrMax = err
                    if (err > 12f / sf) {
                        failCount++
                        if (failCount < 40) println("BLOCK-ERR f_$n pred=${predCxPx.toInt()} gt=${gtCxPx.toInt()} err=${err.toInt()}")
                    }
                }
            }
            statesSeen[o.state.name] = (statesSeen[o.state.name] ?: 0) + 1

            csv.write("$n,${o.state.name},${"%.4f".format(o.fishXNorm)},${"%.4f".format(o.playerXNorm)},${"%.4f".format(o.errorNorm)},${o.intendedAction},${"%.3f".format(o.globalConfidence)},${"%.3f".format(o.progressValue)},${o.inputIssued},${o.inputDeniedReason}\n")

            if (idx % 15 == 0) {
                val anno = annotate(img, pipeline.render)
                ImageIO.write(anno, "jpg", File(outDir, "anno_%04d.jpg".format(n)))
            }
        }
        csv.close()
        val dt = System.currentTimeMillis() - t0

        println("---- replay summary ----")
        println("frames=${files.size} time=${dt}ms (${(dt.toFloat() / files.size).toInt()}ms/frame)")
        println("bar: in-minigame locked=$barIn/${maxOf(1, mgEnd - mgStart + 1)}  out clean=$barOut")
        println("block: gt-matched=$blockHits/$blockTotal maxErr=${blockErrMax.toInt()}px@proc fails=$failCount")
        println("fish-block frames=$fishFrames  progress frames=$progressFrames  shake frames=$shakeFrames  rod frames=$rodFrames")
        println("first/last minigame-locked: $firstMinigame/$lastMinigame (gt $mgStart/$mgEnd)")
        println("states: $statesSeen")
        println("log tail:")
        logLines.takeLast(10).forEach { println("  $it") }

        val barRate = barIn.toFloat() / maxOf(1, mgEnd - mgStart + 1)
        val ok = failCount == 0 && barRate > 0.85f &&
            firstMinigame in (mgStart - 25)..(mgStart + 25) && lastMinigame >= mgEnd - 40
        println(if (ok) "REPLAY PASS" else "REPLAY FAIL (barRate=$barRate fails=$failCount)")
        if (!ok) kotlin.system.exitProcess(1)
    }

    // ---------------- helpers ----------------

    private fun readGt(file: File): Map<Int, FloatArray> {
        if (!file.exists()) return emptyMap()
        val m = HashMap<Int, FloatArray>()
        file.forEachLine { line ->
            val p = line.trim().split(',')
            if (p.size >= 5 && p[0].toIntOrNull() != null) {
                m[p[0].toInt()] = floatArrayOf(p[1].toFloat(), p[2].toFloat(), p[3].toFloat(), p[4].toFloat())
            }
        }
        return m
    }

    private fun readMeta(file: File): Pair<Int, Int> {
        if (!file.exists()) return 286 to 455
        var a = 286; var b = 455
        file.forEachLine {
            if (it.startsWith("minigameStart=")) a = it.substringAfter('=').trim().toIntOrNull() ?: a
            if (it.startsWith("minigameEnd=")) b = it.substringAfter('=').trim().toIntOrNull() ?: b
        }
        return a to b
    }

    private fun downscale(img: BufferedImage, frame: VisionFrame) {
        val sf = frame.width.toFloat() / img.width
        for (y in 0 until frame.height) {
            val sy = (y / sf).toInt().coerceAtMost(img.height - 1)
            var i = y * frame.width
            for (x in 0 until frame.width) {
                val sx = (x / sf).toInt().coerceAtMost(img.width - 1)
                frame.argb[i++] = img.getRGB(sx, sy)
            }
        }
    }

    private fun annotate(img: BufferedImage, r0: RenderModel?): BufferedImage {
        val out = BufferedImage(img.width, img.height, BufferedImage.TYPE_INT_RGB)
        val g = out.createGraphics()
        g.drawImage(img, 0, 0, null)
        g.font = Font("Monospaced", Font.BOLD, 15)
        if (r0 != null) {
            r0.barBox?.let { boxNorm(g, it, Color(0x00FF00), "BAR") }
            r0.blockBox?.let { boxNorm(g, it, Color(0xFFFFFF), "BLOCK") }
            r0.fishBox?.let { boxNorm(g, it, Color(0xFF8800), "FISH") }
            r0.shakeBox?.let { boxNorm(g, it, Color(0xFF00FF), "SHAKE") }
            r0.rodBox?.let { boxNorm(g, it, Color(0x00FFFF), "ROD") }
            r0.progressBox?.let { boxNorm(g, it, Color(0x00FF88), "PROG") }
            val txt = "ST=%s F=%.3f P=%.3f E=%+.3f V=%+.2f ACT=%s CONF=%.2f PRG=%.2f%s".format(
                r0.state, r0.fishCx, r0.playerCx, r0.error, r0.fishVel, r0.action, r0.confGlobal, r0.progress,
                if (r0.holdActive) " HOLD" else ""
            )
            g.color = Color(0xFFFF00)
            g.fillRect(4, 4, txt.length * 8 + 10, 22)
            g.color = Color(0)
            g.drawString(txt, 9, 20)
        }
        g.dispose()
        return out
    }

    private fun boxNorm(g: java.awt.Graphics2D, r: FloatArray, col: Color, label: String) {
        g.color = col
        val x = (r[0] * 1066f).toInt(); val y = (r[1] * 480f).toInt()
        val w = ((r[2] - r[0]) * 1066f).toInt().coerceAtLeast(4)
        val h = ((r[3] - r[1]) * 480f).toInt().coerceAtLeast(4)
        g.drawRect(x, y, w, h)
        g.drawString(label, x, maxOf(12, y - 4))
    }
}
