package com.fischa.core.vision

import com.fischa.core.calib.CalibrationConfig
import com.fischa.core.config.AppConfig
import com.fischa.core.common.RectF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * V7 §6 — the detection state machine, kept separate from the fishing [com.fischa.core.state.
 * FishingState] machine: the fishing machine asks "where are we in the cycle?", this one asks
 * "how sure are we that we can see the rod button?".
 *
 *   INIT → AUTO_CALIBRATION → SEARCHING_ROD → CANDIDATE_FOUND → CONFIRMING_ROD → ROD_CONFIRMED
 *          → TRACKING_ROD → (ROD_LOST → LOCAL_RETRY → TRACKING_ROD | SEARCHING_ROD)
 *
 * A detection is never confirmed from a single frame, and never with a confidence below the
 * calibrated threshold.
 */
enum class RodDetectionState {
    INIT,
    AUTO_CALIBRATION,
    SEARCHING_ROD,
    CANDIDATE_FOUND,
    CONFIRMING_ROD,
    ROD_CONFIRMED,
    TRACKING_ROD,
    ROD_LOST,
    LOCAL_RETRY,
    ;

    val isConfirmedFamily: Boolean get() = this == ROD_CONFIRMED || this == TRACKING_ROD
    val isSearching: Boolean get() = this == SEARCHING_ROD || this == LOCAL_RETRY || this == ROD_LOST
}

/**
 * V7 §2 FASE B/C — one candidate for the rod button, with **all** the visual evidence that was
 * used to score it. Nothing here depends on a single feature: a candidate must look like a disc
 * (shape), be the right size (relative to what this screen actually shows), stand out from its
 * background (contrast), be where the element plausibly is (position, soft), and persist over
 * time (temporal). [RodScorer] combines the sub-scores with configurable weights to produce
 * `candidateScore`.
 */
class RodCandidate {
    var cx = 0f; var cy = 0f; var r = 0f
    var radiusNorm = 0f

    // ---- raw measurements ------------------------------------------------------------------
    var ringDelta = 0f          // ring mean − (0.55·interior + 0.45·outside), gray units
    var interiorGray = 0f
    var outsideGray = 0f
    var roundness = 0f          // 0..1, angular ring closure from DiscMatcher
    var fill = 0f               // fraction of the disc interior that is dark
    var glyphFrac = 0f          // mid-gray "hook" glyph fraction (rod button indicator)
    var whiteFrac = 0f          // white text fraction (SHAKE prompt indicator → rejected)
    var persistence = 0f        // 0..1, how often this position was a candidate recently
    var distanceNorm = 0f       // distance to the expected position (normalized)

    // ---- sub-scores (each 0..1) ------------------------------------------------------------
    var shapeScore = 0f
    var sizeScore = 0f
    var contrastScore = 0f
    var positionScore = 0f
    var temporalScore = 0f
    var identityScore = 0f
    var score = 0f              // weighted sum = candidateScore

    val box = RectF()

    fun bounds() {
        box.set(cx - r, cy - r, cx + r, cy + r)
    }

    fun copyFrom(o: RodCandidate) {
        cx = o.cx; cy = o.cy; r = o.r; radiusNorm = o.radiusNorm
        ringDelta = o.ringDelta; interiorGray = o.interiorGray; outsideGray = o.outsideGray
        roundness = o.roundness; fill = o.fill; glyphFrac = o.glyphFrac; whiteFrac = o.whiteFrac
        persistence = o.persistence; distanceNorm = o.distanceNorm
        shapeScore = o.shapeScore; sizeScore = o.sizeScore; contrastScore = o.contrastScore
        positionScore = o.positionScore; temporalScore = o.temporalScore; identityScore = o.identityScore
        score = o.score
        box.set(o.box)
    }

    fun describe(): String =
        "score=${"%.3f".format(score)} c=(${cx.toInt()},${cy.toInt()}) r=${"%.1f".format(r)} " +
            "shape=${"%.2f".format(shapeScore)} size=${"%.2f".format(sizeScore)} " +
            "contrast=${"%.2f".format(contrastScore)} pos=${"%.2f".format(positionScore)} " +
            "time=${"%.2f".format(temporalScore)} id=${"%.2f".format(identityScore)}"
}

/**
 * V7 §2 FASE C — the weighted combination of the candidate features.
 *
 * `candidateScore = shapeScore + sizeScore + contrastScore + positionScore + temporalScore`
 * (plus a small identity term that separates the rod's mid-gray hook glyph from the SHAKE prompt's
 * white text). The weights are configuration, and [tune] lets the runtime nudge them (gradually,
 * bounded) as detections are confirmed or rejected — see [com.fischa.core.calib.RodAdaptiveModel].
 */
class RodScorer(private val w: AppConfig.RodV7.Weights) {

    var weightShape = w.shape
        private set
    var weightSize = w.size
        private set
    var weightContrast = w.contrast
        private set
    var weightPosition = w.position
        private set
    var weightTemporal = w.temporal
        private set
    var weightIdentity = w.identity
        private set

    var tuningHistory: Int = 0
        private set

    fun score(c: RodCandidate, calib: CalibrationConfig, frameWidth: Int, frameHeight: Int) {
        // size: the calibration measures a *band* (min..max radius as a fraction of the frame
        // width), so anything inside it gets full credit and only what falls outside decays —
        // there is no "expected radius" the button has to hit.
        val loR = (calib.minCandidateSize * frameWidth).coerceAtLeast(3f)
        val hiR = (calib.maxCandidateSize * frameWidth).coerceAtLeast(loR + 2f)

        // shape: disc-likeness (ring closure + how much of the interior is a filled dark region)
        c.shapeScore = (0.68f * c.roundness + 0.32f * c.fill).coerceIn(0f, 1f)

        c.sizeScore = when {
            c.r < loR -> (1f - (loR - c.r) / max(4f, loR * 0.6f)).coerceIn(0f, 1f)
            c.r > hiR -> (1f - (c.r - hiR) / max(4f, hiR * 0.6f)).coerceIn(0f, 1f)
            else -> 1f
        }

        // contrast: ring must pop above the calibrated tolerance; saturates at 2× the tolerance
        val tol = max(4f, calib.minRingDelta)
        c.contrastScore = ((c.ringDelta - tol) / tol).coerceIn(0f, 1f)

        // position: soft prior (never a filter!) — the whole point of V7 is that the button moves
        val nx = c.cx / frameWidth
        val ny = c.cy / frameHeight
        val d = sqrt((nx - calib.rodSearchRegion.centerX) * (nx - calib.rodSearchRegion.centerX) +
            (ny - calib.rodSearchRegion.centerY) * (ny - calib.rodSearchRegion.centerY))
        c.distanceNorm = d
        c.positionScore = (1f - (d / 0.75f)).coerceIn(0f, 1f)

        // temporal: persistence of a candidate near this position over the last frames
        c.temporalScore = c.persistence.coerceIn(0f, 1f)

        // identity: rod button carries a small mid-gray glyph; the SHAKE disc is full of white text
        val glyphBand = if (c.glyphFrac in 0.015f..0.40f) min(1f, 0.25f + c.glyphFrac * 4f) else 0f
        val whitePenalty = min(1f, max(0f, c.whiteFrac - 0.02f) * 8f)
        c.identityScore = (glyphBand * (1f - whitePenalty)).coerceIn(0f, 1f)
        // V6 parity ("strong white text => shake, not rod"), but as a gradual *veto*: bright text on
        // the dark face is evidence against "rod button", so it damps the whole score instead of
        // only the identity term. Gradual → a small white highlight is harmless, a text-covered
        // disc (≈12 % of its area) collapses below the viability floor.
        val textGate = (1f - 0.75f * whitePenalty).coerceIn(0.15f, 1f)

        c.score = (textGate * (weightShape * c.shapeScore + weightSize * c.sizeScore +
            weightContrast * c.contrastScore + weightPosition * c.positionScore +
            weightTemporal * c.temporalScore + weightIdentity * c.identityScore)).coerceIn(0f, 1f)
    }

    /**
     * V7 §7 — gradual self-tuning. [confirmed] true when the frame's winner was accepted, false
     * when it was rejected (false-positive risk). Changes are small and bounded, and the weights
     * are re-normalised so the score keeps its 0..1 range and its meaning.
     */
    fun tune(confirmed: Boolean, step: Float = 0.02f) {
        tuningHistory++
        val s = step.coerceIn(0.001f, 0.05f)
        if (confirmed) {
            // trust the discriminative features a bit more (shape/contrast/temporal)
            weightShape += s
            weightContrast += s * 0.5f
            weightPosition -= s * 0.5f
        } else {
            // suspicious pattern: lean on persistence and identity, lean off position/size
            weightTemporal += s
            weightIdentity += s * 0.5f
            weightPosition -= s
        }
        normalize()
    }

    /** auto-calibration hook: the weights are re-derived from the scene's measured statistics. */
    fun setFromCalibration(w: AppConfig.RodV7.Weights) {
        weightShape = w.shape
        weightSize = w.size
        weightContrast = w.contrast
        weightPosition = w.position
        weightTemporal = w.temporal
        weightIdentity = w.identity
        normalize()
    }

    private fun normalize() {
        weightShape = weightShape.coerceIn(0.02f, 0.6f)
        weightSize = weightSize.coerceIn(0.02f, 0.5f)
        weightContrast = weightContrast.coerceIn(0.02f, 0.6f)
        weightPosition = weightPosition.coerceIn(0f, 0.3f)
        weightTemporal = weightTemporal.coerceIn(0.02f, 0.5f)
        weightIdentity = weightIdentity.coerceIn(0f, 0.3f)
        val sum = weightShape + weightSize + weightContrast + weightPosition + weightTemporal + weightIdentity
        if (sum > 0f) {
            val k = 1f / sum
            weightShape *= k; weightSize *= k; weightContrast *= k
            weightPosition *= k; weightTemporal *= k; weightIdentity *= k
        }
    }

    fun describe(): String =
        "w[shape=${"%.2f".format(weightShape)} size=${"%.2f".format(weightSize)} " +
            "contrast=${"%.2f".format(weightContrast)} pos=${"%.2f".format(weightPosition)} " +
            "time=${"%.2f".format(weightTemporal)} id=${"%.2f".format(weightIdentity)}]"
}
