package com.fischa.core.common

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Mutable float rectangle used inside the hot loop (reused, never per-frame allocated). */
class RectF(var left: Float = 0f, var top: Float = 0f, var right: Float = 0f, var bottom: Float = 0f) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val centerX: Float get() = (left + right) * 0.5f
    val centerY: Float get() = (top + bottom) * 0.5f

    fun set(other: RectF) { left = other.left; top = other.top; right = other.right; bottom = other.bottom }
    fun set(l: Float, t: Float, r: Float, b: Float) { left = l; top = t; right = r; bottom = b }
    fun contains(x: Float, y: Float) = x in left..right && y in top..bottom
    fun inflate(dx: Float, dy: Float) { left -= dx; top -= dy; right += dx; bottom += dy }
    fun iou(o: RectF): Float {
        val ix = min(right, o.right) - max(left, o.left)
        val iy = min(bottom, o.bottom) - max(top, o.top)
        if (ix <= 0f || iy <= 0f) return 0f
        val inter = ix * iy
        return inter / max(width * height + o.width * o.height - inter, 1e-6f)
    }
    fun copy() = RectF(left, top, right, bottom)
    override fun toString() = "RectF($left,$top,$right,$bottom)"
}

class PointF(var x: Float = 0f, var y: Float = 0f) { fun set(a: Float, b: Float) { x = a; y = b } }

fun clamp(v: Float, lo: Float, hi: Float) = if (v < lo) lo else if (v > hi) hi else v
fun clamp01(v: Float) = clamp(v, 0f, 1f)
fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

/** Smooth, saturation-free ramp used to turn raw scores into confidences. */
fun ramp(v: Float, lo: Float, hi: Float): Float =
    if (hi <= lo) (if (v >= hi) 1f else 0f) else clamp01((v - lo) / (hi - lo))

fun approach(current: Float, target: Float, rate: Float): Float {
    val d = target - current
    return if (abs(d) <= rate) target else current + if (d > 0) rate else -rate
}
