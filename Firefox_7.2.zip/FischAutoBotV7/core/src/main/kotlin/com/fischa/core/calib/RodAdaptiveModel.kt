package com.fischa.core.calib

import com.fischa.core.config.AppConfig
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

/**
 * V7 §7 — the "learn from its own detections" layer.
 *
 * While the confirmed candidate stays stable the model slowly converges on the real button
 * (expected position, expected size, expected ROI) and, when a detection turns out to have been
 * wrong, it raises the bar instead: more temporal confirmation frames, a higher confidence
 * threshold, more weight on persistence — always **gradually** (time-based EMA, bounded steps,
 * cooldowns), never a violent reconfiguration.
 *
 * The model only *refines* the calibration; it can never confirm a detection by itself and it
 * never touches input.
 */
class RodAdaptiveModel(private val v7: AppConfig.RodV7) {

    /** learned expected button radius (normalized by frame width); <0 → not learned yet */
    var expectedRadiusNorm = -1f
        private set
    var expectedCx = -1f
        private set
    var expectedCy = -1f
        private set

    var stableFrames = 0
        private set
    var confirmedEvents = 0
        private set
    var falsePositiveEvents = 0
        private set

    private var extraConfirmFrames = 0
    private var thresholdBump = 0f
    private var lastUpdateNs = 0L
    private var lastPenaltyNs = 0L
    private var lastStableLogNs = 0L

    /** observed spread of the button radius (normalized): drives the learned size tolerance */
    var radiusSpread = 0.004f
        private set

    /**
     * A stable, confirmed detection: converge the expectations toward what is actually on screen.
     * The learning rate is time-based (α = 1 − e^(−Δt/τ)), so the behaviour is identical at
     * 15 FPS or 60 FPS instead of depending on the frame count.
     */
    fun onStable(radiusNorm: Float, nx: Float, ny: Float, nowNs: Long) {
        if (!radiusNorm.isFinite() || radiusNorm <= 0f || !nx.isFinite() || !ny.isFinite()) return
        val dt = if (lastUpdateNs == 0L) 0f else max(0f, (nowNs - lastUpdateNs) / 1e9f)
        lastUpdateNs = nowNs
        val alpha = if (dt <= 0f) 0.05f else (1f - exp(-dt / max(0.5f, v7.adaptTauSec))).coerceIn(0.01f, 0.35f)
        if (expectedRadiusNorm <= 0f) {
            expectedRadiusNorm = radiusNorm
            expectedCx = nx; expectedCy = ny
            stableFrames = 1
            return
        }
        val dR = radiusNorm - expectedRadiusNorm
        expectedRadiusNorm += alpha * dR
        expectedCx += alpha * (nx - expectedCx)
        expectedCy += alpha * (ny - expectedCy)
        radiusSpread = radiusSpread * (1f - alpha * 0.5f) + (dR * dR).let { kotlin.math.sqrt(it) } * alpha * 0.5f
        stableFrames++
    }

    /** First confirmation of a fresh cycle: seed (or nudge) the expectations and the model. */
    fun onConfirmed(radiusNorm: Float, nx: Float, ny: Float, nowNs: Long) {
        confirmedEvents++
        if (expectedRadiusNorm <= 0f) {
            expectedRadiusNorm = radiusNorm
            expectedCx = nx; expectedCy = ny
        } else {
            // a new confirmation is strong evidence: converge a little faster, still gradual
            val alpha = 0.12f
            expectedRadiusNorm += alpha * (radiusNorm - expectedRadiusNorm)
            expectedCx += alpha * (nx - expectedCx)
            expectedCy += alpha * (ny - expectedCy)
        }
        lastUpdateNs = nowNs
    }

    /**
     * A pattern that produced a wrong detection: ask for more temporal evidence and a slightly
     * higher confidence. Both penalties are bounded and applied at most once per cooldown.
     */
    fun onFalsePositive(nowNs: Long) {
        if (nowNs - lastPenaltyNs < v7.adaptCooldownMs * 1_000_000L) return
        lastPenaltyNs = nowNs
        falsePositiveEvents++
        extraConfirmFrames = min(4, extraConfirmFrames + 1)
        thresholdBump = min(0.12f, thresholdBump + 0.02f)
    }

    /** Confirmation frames actually required now (calibrated base + adaptive penalty). */
    fun effectiveConfirmFrames(base: Int): Int =
        (base + extraConfirmFrames).coerceIn(CalibrationConfig.MIN_CONFIRM_FRAMES, CalibrationConfig.MAX_CONFIRM_FRAMES + 4)

    /** Extra confidence required by the adaptive model (added to the calibrated threshold). */
    fun thresholdBump(): Float = thresholdBump

    fun sizeBandHint(): Float = radiusSpread.coerceIn(0.002f, 0.05f)

    fun describe(): String =
        "expectedR=${if (expectedRadiusNorm < 0f) "?" else "%.4f".format(expectedRadiusNorm)} " +
            "expectedC=(${if (expectedCx < 0f) "?" else "%.3f".format(expectedCx)},${if (expectedCy < 0f) "?" else "%.3f".format(expectedCy)}) " +
            "stable=$stableFrames confirmed=$confirmedEvents fp=$falsePositiveEvents " +
            "extraFrames=$extraConfirmFrames thrBump=${"%.2f".format(thresholdBump)} spread=${"%.4f".format(radiusSpread)}"

    fun reset() {
        expectedRadiusNorm = -1f; expectedCx = -1f; expectedCy = -1f
        stableFrames = 0; confirmedEvents = 0; falsePositiveEvents = 0
        extraConfirmFrames = 0; thresholdBump = 0f; radiusSpread = 0.004f
        lastUpdateNs = 0L; lastPenaltyNs = 0L
    }
}
