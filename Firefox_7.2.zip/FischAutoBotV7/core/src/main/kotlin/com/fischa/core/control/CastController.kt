package com.fischa.core.control

import com.fischa.core.config.AppConfig

/** Bounded gesture directives for the dynamically detected fishing-rod button. */
enum class CastGestureAction { START, EXTEND, RELEASE }

data class PressRequest(
    val action: CastGestureAction,
    val nx: Float,
    val ny: Float,
    val confidence: Float,
    val reason: String,
)

/**
 * Cast phase driver. The rod center is supplied by FishingButtonDetector on each frame; the
 * Android layer receives only short hold leases, so it can re-check the safety gate while the
 * configurable ~3 s cast is in progress.
 */
class CastController(private val cfg: AppConfig.Cast) {
    enum class Phase { IDLE, WAIT_PRESS, PRESSING, PRESS_SENT, COOLDOWN }

    var phase = Phase.IDLE
        private set
    private var pressStartedNs = 0L
    private var targetX = 0f
    private var targetY = 0f

    /**
     * V5: set when a RELEASE directive was issued on the last [tick]. The pipeline consumes it
     * (and clears it) to feed the FSM's CASTING → WAITING_FOR_WATER transition. Combined with
     * [releaseWasComplete] the FSM can tell a finished cast (→ WAITING_FOR_WATER) from an
     * aborted one, e.g. rod target lost mid-press (→ WAITING_FOR_ROD).
     */
    var releaseIssued = false
        private set
    /** True when the last release completed the configured hold duration (vs target lost). */
    var releaseWasComplete = false
        private set

    fun start() {
        phase = Phase.WAIT_PRESS
        releaseIssued = false
        releaseWasComplete = false
    }

    fun onShakeOrBarSeen(nowNs: Long) {
        if (phase != Phase.IDLE) {
            phase = Phase.COOLDOWN
            pressStartedNs = nowNs
        }
    }

    /** Called every frame while CASTING; null means no input command this frame. */
    fun tick(
        rodConfirmed: Boolean,
        confidence: Float,
        cxNorm: Float,
        cyNorm: Float,
        nowNs: Long,
    ): PressRequest? {
        when (phase) {
            Phase.WAIT_PRESS -> {
                if (rodConfirmed && confidence >= cfg.minConfidence && validPoint(cxNorm, cyNorm)) {
                    phase = Phase.PRESSING
                    pressStartedNs = nowNs
                    targetX = cxNorm
                    targetY = cyNorm
                    return PressRequest(CastGestureAction.START, targetX, targetY, confidence, "cast hold start")
                }
            }
            Phase.PRESSING -> {
                val elapsedMs = ((nowNs - pressStartedNs).coerceAtLeast(0L)) / 1_000_000L
                if (elapsedMs >= cfg.holdMs) {
                    phase = Phase.PRESS_SENT
                    releaseIssued = true
                    releaseWasComplete = true
                    return PressRequest(CastGestureAction.RELEASE, targetX, targetY, confidence, "cast duration complete")
                }
                // Renew only while the visual target remains sufficiently supported. A missing
                // button releases the lease instead of continuing a blind press.
                if (!rodConfirmed || confidence < cfg.minConfidence) {
                    phase = Phase.WAIT_PRESS
                    releaseIssued = true
                    releaseWasComplete = false
                    return PressRequest(CastGestureAction.RELEASE, targetX, targetY, confidence, "cast target lost")
                }
                return PressRequest(CastGestureAction.EXTEND, targetX, targetY, confidence, "cast hold renew")
            }
            Phase.PRESS_SENT, Phase.COOLDOWN, Phase.IDLE -> Unit
        }
        return null
    }

    fun reset() {
        phase = Phase.IDLE
        pressStartedNs = 0L
        targetX = 0f
        targetY = 0f
        releaseIssued = false
        releaseWasComplete = false
    }

    private fun validPoint(x: Float, y: Float) = x.isFinite() && y.isFinite() && x in 0f..1f && y in 0f..1f
}
