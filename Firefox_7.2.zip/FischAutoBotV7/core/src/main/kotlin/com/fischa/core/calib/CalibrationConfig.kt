package com.fischa.core.calib

import com.fischa.core.common.NormRegion

/**
 * V7 §1 — everything the detection stack needs to know about *this* screen, discovered by
 * [AutoCalibrator] at start-up instead of being typed in by the user.
 *
 * Every geometric field is **relative** (fractions of the processing frame or of the display),
 * so changing phone, resolution, density, orientation or capture scale never requires editing a
 * number: the calibration simply produces a new instance.
 *
 * Field semantics (the spec's `CalibrationConfig`):
 *  - [screenWidth]/[screenHeight]  real display pixels (MediaProjection mirrors this).
 *  - [scale]                       processing pixels per display pixel (frameW / screenW). 1.00
 *                                  means the vision frame *is* the screen resolution.
 *  - [gameRegion]                  useful application area (display minus system insets), the
 *                                  only place detection is ever allowed to look.
 *  - [estimatedFps]                measured, never assumed.
 *  - [rodSearchRegion]             proportional, wide candidate region for the rod button. It is
 *                                  an *estimate* that the search refines at runtime — never a
 *                                  fixed coordinate where the button is assumed to be.
 *  - [minCandidateSize]/[maxCandidateSize]  radius band as a fraction of the frame **width**
 *                                  (measured from the blobs actually seen on screen).
 *  - [confidenceThreshold]         adaptive score floor (noise floor + margin).
 *  - [temporalConfirmationFrames]  consecutive frames required to confirm, derived from the
 *                                  measured FPS and [targetConfirmMs] (adaptative, not "3").
 *  - [roiPadding]                  padding as a fraction of the detected button size, giving
 *                                  finalRodROI ≈ button × (1 + 2·roiPadding) ≈ ×1.5 by default.
 *
 * The remaining fields are provenance/diagnostics: they make the calibration auditable in the log
 * and in the debug overlay, and they let the runtime re-calibration (low frequency) update the
 * tolerances without touching the geometry.
 */
data class CalibrationConfig(
    val screenWidth: Int,
    val screenHeight: Int,
    val scale: Float,
    val gameRegion: NormRegion,
    val estimatedFps: Float,
    val rodSearchRegion: NormRegion,
    val minCandidateSize: Float,
    val maxCandidateSize: Float,
    val confidenceThreshold: Float,
    val temporalConfirmationFrames: Int,
    val roiPadding: Float,
    // ---- provenance / diagnostics ----------------------------------------------------------
    val rotationDeg: Int = 0,
    val densityDpi: Int = 0,
    val processingWidth: Int = 0,
    val processingHeight: Int = 0,
    /** measured scene noise (gray std-dev of the coarse map): drives the contrast tolerance */
    val sceneNoise: Float = 0f,
    /** ring-contrast tolerance derived from [sceneNoise] */
    val minRingDelta: Float = 12f,
    /** how many frames were observed while calibrating */
    val samples: Int = 0,
    val calibratedAtNs: Long = 0L,
    /** coarse scan step (processing px) chosen from the frame size for the wide search */
    val searchStepCoarse: Int = 4,
    /** wall-clock budget used to derive [temporalConfirmationFrames] */
    val targetConfirmMs: Float = 120f,
    val lostTimeoutMs: Long = 320L,
    val retryTimeoutMs: Long = 700L,
) {
    val isLandscape: Boolean get() = screenWidth >= screenHeight

    /** search region in processing pixels [x0, y0, x1, y1] for a frame of the given size */
    fun searchRectPx(frameWidth: Int, frameHeight: Int): IntArray =
        rodSearchRegion.clamp().toPx(frameWidth, frameHeight)

    /**
     * Region the **auto-calibration** samples: the estimate plus the proportional fallback band.
     * Calibration must be able to *see* a button placed anywhere in the usable area — otherwise
     * the estimate would be measuring itself instead of the scene.
     */
    fun calibrationScanRectPx(frameWidth: Int, frameHeight: Int): IntArray =
        rodSearchRegion.union(WIDE_FALLBACK).clamp().toPx(frameWidth, frameHeight)

    fun minRadiusPx(frameWidth: Int): Int = (minCandidateSize * frameWidth).toInt().coerceAtLeast(3)

    fun maxRadiusPx(frameWidth: Int): Int =
        (maxCandidateSize * frameWidth).toInt().coerceAtLeast(minRadiusPx(frameWidth) + 4)

    /**
     * ROI padding in pixels for a detected button of [buttonWidth]×[buttonHeight] px:
     * padding is a fraction of the button size (never an absolute number), giving
     * `ROI = button × (1 + 2·roiPadding)`.
     */
    fun paddingPx(buttonWidth: Float, buttonHeight: Float): Pair<Float, Float> =
        buttonWidth * roiPadding to buttonHeight * roiPadding

    /** Re-derives the FPS-dependent fields without invalidating the geometric ones. */
    fun withFps(fps: Float): CalibrationConfig =
        if (fps.isFinite() && fps > 0.5f) copy(
            estimatedFps = fps,
            temporalConfirmationFrames = framesForConfirm(fps, targetConfirmMs),
        ) else this

    fun describe(): String =
        "screen=${screenWidth}x$screenHeight scale=${"%.3f".format(scale)} rot=${rotationDeg} " +
            "dpi=$densityDpi fps=${"%.1f".format(estimatedFps)} gameRegion=${gameRegion.describe()} " +
            "search=${rodSearchRegion.describe()} size=[${"%.3f".format(minCandidateSize)}.." +
            "${"%.3f".format(maxCandidateSize)}] thr=${"%.3f".format(confidenceThreshold)} " +
            "confirmFrames=$temporalConfirmationFrames roiPad=${"%.2f".format(roiPadding)} " +
            "noise=${"%.1f".format(sceneNoise)} ringDelta=${"%.1f".format(minRingDelta)} samples=$samples"

    fun toMap(): Map<String, String> = mapOf(
        "calib.screenWidth" to screenWidth.toString(),
        "calib.screenHeight" to screenHeight.toString(),
        "calib.scale" to scale.toString(),
        "calib.gameRegion" to gameRegion.describe(),
        "calib.estimatedFps" to estimatedFps.toString(),
        "calib.rodSearchRegion" to rodSearchRegion.describe(),
        "calib.minCandidateSize" to minCandidateSize.toString(),
        "calib.maxCandidateSize" to maxCandidateSize.toString(),
        "calib.confidenceThreshold" to confidenceThreshold.toString(),
        "calib.temporalConfirmationFrames" to temporalConfirmationFrames.toString(),
        "calib.roiPadding" to roiPadding.toString(),
    )

    companion object {
        /** Bounds of the adaptive confirmation window (never a fixed "3 frames" for everyone). */
        /**
         * Proportional band used **only** when the estimate did not produce a candidate: it is
         * where a rod button could still plausibly be (most of the usable area, without the very
         * top band where HUD/prompt elements live). It exists so the search can never be trapped
         * by a bad estimate — it is a fallback, never the assumed position.
         */
        val WIDE_FALLBACK = NormRegion(0.03f, 0.18f, 0.97f, 0.95f)

        const val MIN_CONFIRM_FRAMES = 3
        const val MAX_CONFIRM_FRAMES = 12

        /** frames needed so that the confirmation spans ≈ [targetMs] at [fps] (bounded). */
        fun framesForConfirm(fps: Float, targetMs: Float): Int {
            val f = if (fps.isFinite() && fps > 0.5f) fps else 30f
            return Math.round(targetMs / 1000f * f).coerceIn(MIN_CONFIRM_FRAMES, MAX_CONFIRM_FRAMES)
        }

        /**
         * Calibration used before [AutoCalibrator] finishes (and by unit tests that drive the
         * pipeline without a display). All values are relative and deliberately generous: the
         * search region covers the right/lower half of the useful area — the *estimate* the spec
         * allows — and the size band brackets the rod button measured in the reference video
         * (radius ≈ 0.05×W), widened on both sides.
         */
        fun provisional(
            processingWidth: Int,
            processingHeight: Int,
            screenWidth: Int = processingWidth,
            screenHeight: Int = processingHeight,
            densityDpi: Int = 0,
            rotationDeg: Int = 0,
            fps: Float = 30f,
        ): CalibrationConfig = CalibrationConfig(
            screenWidth = if (screenWidth > 0) screenWidth else processingWidth,
            screenHeight = if (screenHeight > 0) screenHeight else processingHeight,
            scale = processingWidth.toFloat() / (if (screenWidth > 0) screenWidth else processingWidth),
            gameRegion = NormRegion(0f, 0.02f, 1f, 0.98f),
            estimatedFps = fps,
            // estimate: right/lower half of the useful area — refined by the search itself
            rodSearchRegion = NormRegion(0.50f, 0.30f, 1.00f, 0.98f),
            minCandidateSize = 0.030f,
            maxCandidateSize = 0.110f,
            confidenceThreshold = 0.50f,
            temporalConfirmationFrames = framesForConfirm(fps, 120f),
            roiPadding = 0.25f,
            rotationDeg = rotationDeg,
            densityDpi = densityDpi,
            processingWidth = processingWidth,
            processingHeight = processingHeight,
            searchStepCoarse = 4,
        )
    }
}
