package com.fischa.core.vision

import com.fischa.core.config.AppConfig
import kotlin.math.max
import kotlin.math.min

/**
 * Catches the post-catch confirmation state (spec §2 TÉRMINO). In the reference video the
 * confirmation is NOT a modal: the game prints two bright text lines in the world-center
 * notification band ("You just caught a ...", "Bestiary: New Highest Weight!") together with a
 * large gold number popup for a few seconds while the standard HUD is restored.
 *
 * We therefore detect the *fingerprint*, not text:
 *   F1: high bright-text activity in the center notification band vs. a rolling baseline;
 *   F2: gold pixels in the upper-center popup region (the XP number);
 *   F3: the minigame bar just vanished (fed by the state machine through [noteBarGone]).
 *
 * Output: box = union of evidence band; v0 = text-activity ratio; v1 = gold fraction;
 * v2 = bar-just-gone bonus; v3 = reserved.
 */
class CatchConfirmDetector(private val cfg: AppConfig.Vision) :
    TemporalDetector("CatchConfirm", minOnFrames = 2, minOffFrames = 8) {

    private val baseline = FloatArray(32)
    private var bIdx = 0
    private var barGoneUntilNs = 0L

    /** how long the confirmation stays "fresh" after the bar disappears */
    var confirmWindowNs: Long = 6_000_000_000L

    fun noteBarGone(nowNs: Long) { barGoneUntilNs = nowNs + confirmWindowNs }
    fun resetBaseline() { baseline.fill(0f) }

    override fun detectRaw(frame: VisionFrame, hit: DetSnapshot): Float {
        val w = frame.width; val h = frame.height
        // F1: bright low-chroma glyph pixels in center band (exclude HUD strips)
        val x0 = (0.30f * w).toInt(); val x1 = (0.70f * w).toInt()
        val y0 = (0.52f * h).toInt(); val y1 = (0.78f * h).toInt()
        var bright = 0; var n = 0
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val p = frame.pixel(x, y)
                val g = frame.grayAt(x, y)
                if (g >= 200 && chroma(p) < 60) bright++
                n++
                x += 2
            }
            y += 2
        }
        val activity = if (n == 0) 0f else bright.toFloat() / n

        // rolling baseline of scene text activity (median-ish via min-of-recent-8)
        baseline[bIdx % baseline.size] = activity
        bIdx++
        var base = 1f
        for (k in 0 until 8) {
            val v = baseline[(bIdx - 1 - k + baseline.size * 2) % baseline.size]
            if (v < base) base = v
        }
        val spike = ((activity - base) / max(base, 0.004f)).coerceIn(0f, 6f) / 6f

        // F2: gold number (r>200,g>140,b<90) in upper center
        var gold = 0; var gn = 0
        var yy = (0.18f * h).toInt()
        while (yy < (0.42f * h).toInt()) {
            var xx = (0.40f * w).toInt()
            while (xx < (0.60f * w).toInt()) {
                val p = frame.pixel(xx, yy)
                val r = (p shr 16) and 0xFF; val gg = (p shr 8) and 0xFF; val b = p and 0xFF
                if (r > 190 && gg in 120..200 && b < 110) gold++
                gn++
                xx += 2
            }
            yy += 2
        }
        val goldFrac = if (gn == 0) 0f else gold.toFloat() / gn

        val barGone = if (frame.timestampNs < barGoneUntilNs) 1f else 0f

        val raw = (0.55f * spike + 0.20f * min(1f, goldFrac * 14f) + 0.25f * barGone).coerceIn(0f, 1f)
        // a catch needs at least one positive cue besides bar-gone
        val cue = spike > 0.25f || goldFrac > 0.008f
        if (raw > 0.5f && (cue || (barGone > 0f && raw > 0.62f))) {
            hit.detected = true
            hit.box.set(x0.toFloat(), (0.18f * h), x1.toFloat(), y1.toFloat())
            hit.rawScore = raw
            hit.v0 = spike; hit.v1 = goldFrac; hit.v2 = barGone
        }
        return raw
    }
}
