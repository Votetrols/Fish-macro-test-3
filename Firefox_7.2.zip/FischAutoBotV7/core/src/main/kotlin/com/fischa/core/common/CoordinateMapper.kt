package com.fischa.core.common

/**
 * The ONE transformation layer between the three coordinate systems used by the macro:
 *
 *   CAPTURE/PROCESSING px  --toNormalized-->  NORMALIZED (0..1 of the full display)  --toDevice-->  DEVICE/TOUCH px
 *
 * Invariants (Galaxy A22 stage, spec §3):
 *  - The capture frame is a uniformly scaled image of the *entire physical display* (real size,
 *    including status/navigation bar area). Therefore normalized = captureX / captureWidth.
 *  - Touch coordinates handed to AccessibilityService.dispatchGesture are *display* pixels of the
 *    same entire physical display, so deviceX = normalizedX * deviceWidth.
 *  - Both sides are measured from the same display size source at session start; a mismatch in
 *    aspect ratio is reported by [aspectMismatch] and the engine refuses to start when it is large.
 *
 * Pure Kotlin so the mapping is unit-testable without Android.
 */
class CoordinateMapper(
    val captureWidth: Int,
    val captureHeight: Int,
    val deviceWidth: Int,
    val deviceHeight: Int,
) {
    init {
        require(captureWidth > 0 && captureHeight > 0) { "capture size must be positive" }
        require(deviceWidth > 0 && deviceHeight > 0) { "device size must be positive" }
    }

    /** Uniform scale from capture px to device px (should be identical on both axes). */
    val scaleX: Float get() = deviceWidth.toFloat() / captureWidth
    val scaleY: Float get() = deviceHeight.toFloat() / captureHeight

    /** Relative aspect-ratio error between the two spaces (0 = identical aspect). */
    val aspectMismatch: Float
        get() {
            val a = captureWidth.toFloat() / captureHeight
            val b = deviceWidth.toFloat() / deviceHeight
            return kotlin.math.abs(a - b) / b
        }

    /** True when a point mapped through capture→normalized→device lands within [tolerancePx]. */
    fun isConsistent(tolerancePx: Float = 2f): Boolean {
        // Worst case is the far corner: compare the uniform scale on both axes.
        val dx = kotlin.math.abs(scaleX - scaleY) * captureWidth
        val dy = kotlin.math.abs(scaleX - scaleY) * captureHeight
        return dx <= tolerancePx && dy <= tolerancePx
    }

    // ---- capture → normalized ---------------------------------------------------------------

    fun normX(captureX: Float): Float = clamp01(captureX / captureWidth)
    fun normY(captureY: Float): Float = clamp01(captureY / captureHeight)

    fun captureToNormalized(captureX: Float, captureY: Float, out: PointF = PointF()): PointF {
        out.x = normX(captureX)
        out.y = normY(captureY)
        return out
    }

    /** Normalizes a capture-space rectangle in place into [out] = [l, t, r, b] fractions. */
    fun captureRectToNormalized(l: Float, t: Float, r: Float, b: Float, out: FloatArray): FloatArray {
        out[0] = normX(l); out[1] = normY(t); out[2] = normX(r); out[3] = normY(b)
        return out
    }

    // ---- normalized → device ----------------------------------------------------------------

    fun deviceX(nx: Float): Float = (clamp01(nx) * deviceWidth).coerceIn(0f, deviceWidth - 1f)
    fun deviceY(ny: Float): Float = (clamp01(ny) * deviceHeight).coerceIn(0f, deviceHeight - 1f)

    /** Returns null when the normalized point is not finite or outside 0..1 (never clamps silently). */
    fun normalizedToDevice(nx: Float, ny: Float, out: PointF = PointF()): PointF? {
        if (!isValidNormalized(nx, ny)) return null
        out.x = deviceX(nx)
        out.y = deviceY(ny)
        return out
    }

    // ---- capture → device (composition, used by tests/diagnostics) -----------------------------

    fun captureToDevice(captureX: Float, captureY: Float, out: PointF = PointF()): PointF {
        out.x = deviceX(normX(captureX))
        out.y = deviceY(normY(captureY))
        return out
    }

    /** Inverse mapping used by diagnostics (device touch → capture pixel). */
    fun deviceToCapture(deviceX: Float, deviceY: Float, out: PointF = PointF()): PointF {
        out.x = (deviceX / deviceWidth) * captureWidth
        out.y = (deviceY / deviceHeight) * captureHeight
        return out
    }

    fun describe(): String =
        "capture=${captureWidth}x${captureHeight} device=${deviceWidth}x${deviceHeight} " +
            "scale=${"%.3f".format(scaleX)}/${"%.3f".format(scaleY)} aspectMismatch=${"%.4f".format(aspectMismatch)}"

    companion object {
        fun isValidNormalized(nx: Float, ny: Float): Boolean =
            nx.isFinite() && ny.isFinite() && nx in 0f..1f && ny in 0f..1f

        /**
         * Chooses the capture size for a display: scales the *real* display size uniformly so the
         * longer side becomes at most [maxProcessingWidth] (landscape games → width), keeps the
         * aspect ratio, and rounds both sides to even numbers (hardware scaler friendly).
         */
        fun captureSizeFor(displayWidth: Int, displayHeight: Int, maxProcessingWidth: Int): IntArray {
            require(displayWidth > 0 && displayHeight > 0 && maxProcessingWidth > 0)
            val scale = minOf(1f, maxProcessingWidth.toFloat() / displayWidth)
            var w = Math.round(displayWidth * scale)
            var h = Math.round(displayHeight * scale)
            w -= w % 2; h -= h % 2
            return intArrayOf(w.coerceAtLeast(2), h.coerceAtLeast(2))
        }
    }
}
