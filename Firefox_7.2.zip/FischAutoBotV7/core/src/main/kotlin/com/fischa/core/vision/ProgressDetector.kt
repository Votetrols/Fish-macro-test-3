package com.fischa.core.vision

import com.fischa.core.common.RectF
import com.fischa.core.config.AppConfig
import kotlin.math.max
import kotlin.math.min

/**
 * Finds the thin progress bar rendered just below the minigame bar and measures the white fill
 * fraction from its left end (progress 0..1). Geometry: outline (mid-gray, ~2 px) with a
 * white fill run starting at the inner-left; dark remainder. Requires the bar prior to know
 * where to look and to normalize its extent (it is centered under the bar but narrower).
 *
 * Output: box = progress outline; v0 = fill fraction 0..1; v1 = fill speed (per second,
 * computed over a ~0.5 s window by the pipeline); v2/v3 unused.
 */
class ProgressDetector(private val cfg: AppConfig.Vision) :
    TemporalDetector("Progress", minOnFrames = 2, minOffFrames = 6) {

    val lastBar = RectF()
    private var barValid = false
    /** last accepted geometry cached so short occlusions (fish icon crossing) don't reset us */
    var cachedFill = -1f
        private set

    fun setBarPrior(l: Float, t: Float, r: Float, b: Float) {
        barValid = r - l > 10f
        if (barValid) lastBar.set(l, t, r, b)
    }

    fun clearBarPrior() { barValid = false; cachedFill = -1f }

    override fun detectRaw(frame: VisionFrame, hit: DetSnapshot): Float {
        if (!barValid) return 0f
        val bl = lastBar.left.toInt(); val br = lastBar.right.toInt() - 1
        val bb = lastBar.bottom.toInt()
        val barW = br - bl + 1
        if (barW <= 16) return 0f
        val w = frame.width
        val y0 = bb + 2
        val y1 = min(frame.height - 2, bb + max(6, (barW * cfg.progressSearchBelowF).toInt()) + 10)

        var bestLen = 0; var bestRow = -1; var bestL = 0; var bestR = 0
        var row = y0
        while (row <= y1) {
            var cur = 0; var start = 0; var gap = 0
            var x = max(0, bl - (barW * 0.30f).toInt())
            val xe = min(w - 1, br + (barW * 0.30f).toInt())
            while (x <= xe) {
                val g = frame.grayAt(x, row)
                if (g >= cfg.progressOutlineMinGray) {
                    if (gap > 4) { cur = 0; start = x }
                    cur++; gap = 0
                    if (cur > bestLen) { bestLen = cur; bestRow = row; bestL = start; bestR = x }
                } else gap++
                x++
            }
            row++
        }
        val minLen = (barW * cfg.progressMinWidthFracOfBar).toInt()
        val maxLen = (barW * cfg.progressMaxWidthFracOfBar).toInt()
        if (bestRow < 0 || bestLen < minLen || bestLen > maxLen) {
            if (cachedFill >= 0f) {
                // keep publishing the cached value at reduced raw score for 2-3 frames of grace
                hit.detected = true
                hit.rawScore = 0.52f
                hit.v0 = cachedFill
            }
            return if (cachedFill >= 0f) 0.52f else 0f
        }
        // fill = white run from inner-left of the outline
        val fillMin = cfg.progressFillMinGray
        var fx = bestL + 2
        var fill = 0
        var fgap = 0
        while (fx < bestR - 1) {
            if (frame.grayAt(fx, bestRow) >= fillMin) { fill++; fgap = 0 } else {
                fgap++; if (fgap > 2) break
            }
            fx++
        }
        val span = (bestR - bestL - 3).coerceAtLeast(1)
        val frac = (fill.toFloat() / span).coerceIn(0f, 1f)
        cachedFill = frac

        val raw = 0.8f
        hit.detected = true
        hit.box.set(bestL.toFloat(), (bestRow - 1).toFloat(), (bestR + 1).toFloat(), (bestRow + 2).toFloat())
        hit.rawScore = raw
        hit.v0 = frac
        return raw
    }
}
