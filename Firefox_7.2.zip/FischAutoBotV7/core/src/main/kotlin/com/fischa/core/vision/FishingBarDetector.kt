package com.fischa.core.vision

import com.fischa.core.config.AppConfig
import kotlin.math.max
import kotlin.math.min

/**
 * Finds the main horizontal minigame bar. The bar width varies with the rod (spec §6/§23), so
 * the geometry is always measured — never assumed.
 *
 * The bar is a semi-transparent near-black band with the white (or red-tinted) player block
 * *inside* it, so the block is used as the seed: find a white/red block candidate row, then
 * extend the dark band left and right from its center and measure the vertical extent.
 * Red end-cap triangles flanking the run corroborate the edges (they were measured bracketing
 * the bar in the reference video).
 *
 * Output: box = bar bounds (raw frame pixels); v0 = width/frameW; v1 = dark fraction;
 * v2 = end-cap 0..1; v3 = white-block fraction.
 */
class FishingBarDetector(private val cfg: AppConfig.Vision) :

    TemporalDetector("FishingBar", minOnFrames = 3, minOffFrames = 5) {

    class BarGeometry {
        var valid = false
        var left = 0f; var top = 0f; var right = 0f; var bottom = 0f
        val width: Float get() = right - left
        val height: Float get() = bottom - top
        val centerX: Float get() = (left + right) * 0.5f
        fun normX(px: Float): Float = if (width <= 0f) 0f else (px - left) / width
        fun set(l: Float, t: Float, r: Float, b: Float) { valid = true; left = l; top = t; right = r; bottom = b }
        fun clear() { valid = false }
    }

    /** last detection geometry (pipeline reads it right after [process]) */
    val geometry = BarGeometry()

    override fun detectRaw(frame: VisionFrame, hit: DetSnapshot): Float {
        geometry.clear()
        val w = frame.width; val h = frame.height
        val y0 = (cfg.barSearchY0 * h).toInt()
        val y1 = (cfg.barSearchY1 * h).toInt()
        val minBarLen = (cfg.barMinWidthF * w).toInt()
        val maxBarLen = (cfg.barMaxWidthF * w).toInt()
        val minBlockLen = (cfg.blockMinWidthF * w).toInt()
        if (y1 - y0 < 8 || maxBarLen < minBarLen) return 0f

        var bestRaw = 0f
        var bestRow = -1
        var bestL = 0; var bestR = 0
        var bestT = 0; var bestB = 0
        var bestWhite = 0f
        var bestDark = 0f
        var bestCaps = intArrayOf(-1, -1)
        var row = y0 + 2
        while (row < y1 - 2) {
            val blk = findBlockSpan(frame, row, minBlockLen)
            if (blk == null) { row++; continue }
            val grown = growDark(frame, row, blk.first, blk.second, w)
            val sL = grown.first; val sR = grown.second
            val len = sR - sL + 1
            if (len < minBarLen || len > maxBarLen) { row++; continue }
            val darkR = darkRatio(frame, sL, sR, row)
            if (darkR < cfg.barDarkColFrac) { row++; continue }

            // The bar's vertical extent is unreliable in darkness (its shadow under the bar is
            // as dark as the bar itself), so derive the band from the white BLOCK rows ± padding.
            val bx0 = blk.first + 4; val bx1 = max(blk.first + 5, blk.second - 4)
            var t = row
            while (t > y0 - 4 && t > row - 12 && blockFrac(frame, bx0, bx1, t - 1) >= 0.5f) t--
            var b = row
            while (b < y1 + 4 && b < h - 3 && b < row + 12 && blockFrac(frame, bx0, bx1, b + 1) >= 0.5f) b++
            t = max(y0 - 4, t - 1); b = min(minOf(y1 + 4, h - 3), b + 1)
            val barH = b - t + 1
            val maxBarH = (cfg.barMaxHeightF * h).toInt()
            if (barH < 6 || barH > maxBarH + 6) { row++; continue }

            // dark material measured on the bar arms beside the block (the block itself is white)
            val midRow = (t + b) / 2
            val darkFrac = (darkRatio(frame, sL, max(sL, blk.first - 2), midRow) +
                darkRatio(frame, min(sR, blk.second + 2), sR, midRow)) * 0.5f
            if (darkFrac < 0.45f) {row++; continue }
            // the bar floats on bright sand; check OUTSIDE the progress bar's horizontal span
            val belowY = min(h - 2, b + 7)
            if (darkRatioOuter(frame, sL, sR, belowY) > 0.32f) {row++; continue }
            // and above the bar the world is brighter than the band
            val aboveY = max(1, t - 5)
            if (darkRatio(frame, sL, sR, aboveY) > 0.55f) {row++; continue }
            val caps = IntArray(2)
            val endCap = endCaps(frame, sL, sR, t, b, caps)
            val white = whiteRatio(frame, blk.first, blk.second, (t + b) / 2)

            val widthScore = min(1f, len.toFloat() / maxBarLen)
            var raw = 0.42f * darkFrac + 0.22f * widthScore + 0.18f * endCap +
                0.12f * min(1f, white * 2.5f) + 0.06f * min(1f, barH.toFloat() / maxBarH)
            if (endCap > 0.4f) raw = min(1f, raw + 0.12f)
            raw = raw.coerceIn(0f, 1f)
            if (raw > bestRaw) {
                bestRaw = raw; bestRow = row; bestL = sL; bestR = sR
                bestT = t; bestB = b; bestWhite = white; bestDark = darkFrac; bestCaps = caps
            }
            row++
        }
        if (bestRow < 0 || bestRaw < 0.5f) return 0f
        // snap to end caps when both were found just outside the run (precise edges)
        var leftEdge = bestL; var rightEdge = bestR + 1
        if (bestCaps[0] in 0 until leftEdge + 14 && bestCaps[1] in rightEdge - 14 until w) {
            leftEdge = bestCaps[0] + 4
            rightEdge = bestCaps[1] - 1
        }
        val barH = bestB - bestT + 1
        val t = bestT; val b = bestB
        hit.detected = true
        hit.box.set(leftEdge.toFloat(), t.toFloat(), rightEdge.toFloat(), (b + 1).toFloat())
        hit.rawScore = bestRaw
        hit.v0 = (rightEdge - leftEdge).toFloat() / w
        hit.v1 = bestDark
        hit.v2 = if (bestCaps[0] >= 0 && bestCaps[1] >= 0) 1f else 0.5f
        hit.v3 = bestWhite
        geometry.set(leftEdge.toFloat(), t.toFloat(), rightEdge.toFloat(), (b + 1).toFloat())
        return bestRaw
    }

    /** longest white-or-red-tint span on a row; tolerates internal marker gaps (≤12 cols) */
    private fun findBlockSpan(f: VisionFrame, row: Int, minLen: Int): Pair<Int, Int>? {
        val w = f.width
        var bestLen = 0; var bestStart = -1; var bestBright = 0
        var cur = 0; var start = 0; var gap = 0; var bright = 0
        var x = 1
        while (x < w - 1) {
            val p = f.pixel(x, row); val g = f.grayAt(x, row)
            val isBlock = (g >= cfg.blockWhiteMinGray && chroma(p) < 80) ||
                (redTint(p) && g in cfg.mismatchValMin..cfg.mismatchValMax)
            if (isBlock) {
                if (gap > 12 || start == 0 && cur == 0) { cur = 0; bright = 0; start = x }
                cur = x - start + 1; bright++; gap = 0
                if (bright > bestBright && cur >= minLen && bright >= cur * 0.55f) {
                    bestBright = bright; bestLen = cur; bestStart = start
                }
            } else {
                gap++
            }
            x++
        }
        if (bestLen < minLen || bestStart < 0) return null
        return bestStart to (bestStart + bestLen - 1)
    }

    /** extend from the block outward while pixels are dark band material (allow small holes) */
    private fun growDark(f: VisionFrame, row: Int, fromL: Int, fromR: Int, w: Int): Pair<Int, Int> {
        val maxSpan = (cfg.barMaxWidthF * w).toInt() / 2 + 8
        var l = fromL
        var holes = 0
        while (l > 1 && isDarkish(f, l - 1, row)) l--
        while (l > 1 && maxSpan > 0) {
            // tolerate a few non-dark columns (fish icon crossing the bar, block border)
            var probe = l - 1
            var skipped = 0
            while (probe > 1 && !isDarkish(f, probe, row) && skipped < cfg.barGrowMaxHoles) { probe--; skipped++ }
            if (skipped == 0) { l--; holes = 0 }
            else if (isDarkish(f, probe, row)) l = probe
            else break
            if (fromR - l > maxSpan) break
        }
        var r = fromR
        while (r < w - 2 && isDarkish(f, r + 1, row)) r++
        while (r < w - 2 && maxSpan > 0) {
            var probe = r + 1
            var skipped = 0
            while (probe < w - 2 && !isDarkish(f, probe, row) && skipped < cfg.barGrowMaxHoles) { probe++; skipped++ }
            if (skipped == 0) r++
            else if (isDarkish(f, probe, row)) r = probe
            else break
            if (r - fromL > maxSpan) break
        }
        return l to r
    }

    /**
     * dark-ish bar material. Brightness alone is not enough (night water is dark too), so we
     * additionally require the pixel to be *darker than the same column well below the bar*
     * where the background is; and low chroma (the bar is neutral gray/black).
     */
    private fun isDarkish(f: VisionFrame, x: Int, row: Int): Boolean {
        if (x < 1 || row < 1) return false
        val g = f.grayAt(x, row)
        if (g !in cfg.barDarkMin..cfg.barDarkMax) return false
        val p = f.pixel(x, row)
        if (chroma(p) > cfg.barDarkMaxChroma) return false
        val h = f.height
        val below = f.grayAt(x, min(h - 2, row + cfg.barBgBelowOffset))
        return below - g >= cfg.barBgBelowDelta
    }

    /** dark fraction over the outer 22% of the span on both sides (skips the progress bar) */
    private fun darkRatioOuter(f: VisionFrame, x0: Int, x1: Int, row: Int): Float {
        var hit = 0; var n = 0
        val side = ((x1 - x0) * 0.22f).toInt().coerceAtLeast(4)
        for (part in 0..1) {
            var x = if (part == 0) x0 else x1 - side
            val ex = if (part == 0) x0 + side else x1
            while (x <= ex) { if (isDarkish(f, x, row)) hit++; n++; x += 2 }
        }
        return if (n == 0) 1f else hit.toFloat() / n
    }

    private fun darkRatio(f: VisionFrame, x0: Int, x1: Int, row: Int): Float {
        var hit = 0; var n = 0
        var x = x0
        while (x <= x1) { if (isDarkish(f, x, row)) hit++; n++; x += 2 }
        return if (n == 0) 0f else hit.toFloat() / n
    }

    private fun darkRatio2(f: VisionFrame, x0: Int, x1: Int, t: Int, b: Int): Float {
        var hit = 0; var n = 0
        var y = t
        while (y <= b) {
            var x = x0
            while (x <= x1) { if (isDarkish(f, x, y)) hit++; n++; x += 3 }
            y += 2
        }
        return if (n == 0) 0f else hit.toFloat() / n
    }

    private fun blockFrac(f: VisionFrame, x0: Int, x1: Int, row: Int): Float {
        var hit = 0; var n = 0
        var x = x0
        while (x <= x1) {
            val g = f.grayAt(x, row); val p = f.pixel(x, row)
            if ((g >= cfg.blockWhiteMinGray && chroma(p) < 80) ||
                (redTint(p) && g in cfg.mismatchValMin..cfg.mismatchValMax)) hit++
            n++; x += 2
        }
        return if (n == 0) 0f else hit.toFloat() / n
    }

    private fun whiteRatio(f: VisionFrame, x0: Int, x1: Int, row: Int): Float {
        var hit = 0; var n = 0
        var x = x0
        while (x <= x1) {
            val g = f.grayAt(x, row); val p = f.pixel(x, row)
            if (g >= cfg.blockWhiteMinGray ||
                (redTint(p) && g in cfg.mismatchValMin..cfg.mismatchValMax)) hit++
            n++; x++
        }
        return if (n == 0) 0f else hit.toFloat() / n
    }

    /** red triangles flanking the bar ends (measured in the reference video at the bar edges) */
    private fun endCaps(f: VisionFrame, x0: Int, x1: Int, top: Int, bot: Int, out: IntArray): Float {
        var hits = 0
        val win = 18
        for (side in 0..1) {
            val sx = if (side == 0) max(0, x0 - win) else x1 + 1
            val ex = if (side == 0) x0 else min(f.width - 1, x1 + win)
            var found = false
            var y = top
            while (y <= bot && !found) {
                var x = sx
                while (x <= ex) {
                    if (redTint(f.pixel(x, y))) { found = true; out[side] = x; break }
                    x += 2
                }
                y++
            }
            if (found) hits++
        }
        return hits / 2f
    }
}
