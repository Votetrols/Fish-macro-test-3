package com.fischa.core.safety

import java.util.concurrent.atomic.AtomicReference

/**
 * V7 §10 — session-level hard lock on real input.
 *
 * The V7 cycle is a **visual validation** cycle: the detection stack must prove it finds the rod
 * button before any gesture may ever be considered. This policy is the second, independent wall
 * on top of [InputSafetyGuard] (the first one): while it is locked the pipeline reports
 * `REAL_INPUT=DISABLED` and behaves as if `realInputEnabled` had never been requested, no matter
 * what the platform, the UI switch or a caller passes in.
 *
 * There is deliberately **no automatic unlock**: nothing in the detection, tracking, calibration
 * or state-machine code can clear the lock. Only an explicit, audited call — a user decision in a
 * later release — can do it, and every call is recorded with a reason so it shows up in the log.
 *
 * The unlock entry point exists only so the deterministic test-suite can exercise the *unlocked*
 * legacy paths (V5/V6 tests of the input chain); the shipped app never calls it.
 */
object RealInputPolicy {

    private val lockReasonRef = AtomicReference(DEFAULT_REASON)

    /** `true` = real input is refused (V7 default). */
    @Volatile
    var locked: Boolean = true
        private set

    /** Auditable trail of the lock/unlock decisions (bounded). */
    private val trail = ArrayList<String>(8)

    val reason: String get() = lockReasonRef.get()

    fun allows(): Boolean = !locked

    /** Re-locks (default state). Safe to call at any time, from any thread. */
    fun lock(reason: String = DEFAULT_REASON) {
        locked = true
        lockReasonRef.set(reason)
        record("LOCK($reason)")
    }

    /**
     * Explicit, deliberate unlock. Used by the legacy input-chain tests; the V7 app never calls
     * it while the detection is being validated.
     */
    fun unlockForTesting(reason: String) {
        locked = false
        lockReasonRef.set(reason)
        record("UNLOCK($reason)")
    }

    fun history(): List<String> = synchronized(trail) { ArrayList(trail) }

    private fun record(entry: String) {
        synchronized(trail) {
            trail.add(entry)
            if (trail.size > 8) trail.removeAt(0)
        }
    }

    const val DEFAULT_REASON = "V7: REAL_INPUT bloqueado durante a validação da detecção (sem auto-unlock)"
}
