package com.fischa.core.vision

import com.fischa.core.common.PointF
import com.fischa.core.common.RectF

/**
 * A processed frame in the *processing* coordinate space (fixed small width, e.g. 640).
 *
 * Allocation policy: the backing arrays are owned by the capture layer's FrameBuffer and
 * recycled. Detectors must treat them as read-only and must not retain them across frames —
 * they may only copy *derived* values (numbers, or reuse their own scratch objects).
 */
class VisionFrame(
    val width: Int,
    val height: Int,
    val argb: IntArray,
    /** luminance, filled lazily by [ensureGray]; same length as argb. */
    val gray: ByteArray,
) {
    var timestampNs: Long = 0L
    var serial: Long = 0L
    var fps: Float = 0f

    private var grayFilled = false

    fun ensureGray() {
        if (grayFilled) return
        var i = 0
        val n = width * height
        while (i < n) {
            val p = argb[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            // integer luma matching cv2's BT.601 (77/150/29 >> 8) used in the offline analysis
            gray[i] = ((r * 77 + g * 150 + b * 29) shr 8).toByte()
            i++
        }
        grayFilled = true
    }

    /** reset before the buffer slot is re-used for a new frame (no reallocation). */
    fun resetFor(tsNs: Long, newSerial: Long) { grayFilled = false; timestampNs = tsNs; serial = newSerial }

    inline fun grayAt(x: Int, y: Int): Int = gray[y * width + x].toInt() and 0xFF
    inline fun pixel(x: Int, y: Int): Int = argb[y * width + x]

    inline fun r(p: Int) = (p shr 16) and 0xFF
    inline fun g(p: Int) = (p shr 8) and 0xFF
    inline fun b(p: Int) = p and 0xFF

    companion object {
        fun allocate(width: Int, height: Int): VisionFrame =
            VisionFrame(width, height, IntArray(width * height), ByteArray(width * height))
    }
}

/**
 * Soft red-dominance for the *muted* reds the game actually renders (end-cap triangles measured
 * R60 G46 B43; tinted block R78 G60 B50 at video level). `redDominant` below is the strong
 * variant for the bite marker; `redTint` is tuned for the UI elements we must hit.
 */
inline fun redTint(p: Int): Boolean {
    val r = (p shr 16) and 0xFF
    val g = (p shr 8) and 0xFF
    val b = p and 0xFF
    return r >= 45 && r - b >= 12 && r - g >= 8 && g <= 150
}

/** Strong red-dominance test (bite markers / alerts). */
inline fun redDominant(p: Int): Boolean {
    val r = (p shr 16) and 0xFF
    val g = (p shr 8) and 0xFF
    val b = p and 0xFF
    return r > 80 && r - g > 40 && r - b > 30
}

inline fun chroma(p: Int): Int {
    val r = (p shr 16) and 0xFF
    val g = (p shr 8) and 0xFF
    val b = p and 0xFF
    return maxOf(r, g, b) - minOf(r, g, b)
}

/** Minimal mutable output bundle so detectors never allocate per call. */
class DetectionSink {
    val box = RectF()
    val center = PointF()
    var confidence = 0f
    var extra0 = 0f
    var extra1 = 0f
    var extra2 = 0f
    var extra3 = 0f
    var detected = false

    fun clear() { detected = false; confidence = 0f; extra0 = 0f; extra1 = 0f; extra2 = 0f; extra3 = 0f }
}
