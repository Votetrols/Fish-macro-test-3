package com.fischa.core.capture

/**
 * V6 spec §1/§18 — maps an unmasked [CaptureFailure] to (a) a friendly line for the UI and
 * (b) the technical line that must always be shown/logged next to it. The friendly text never
 * replaces the original cause; it is purely additive.
 */
object CaptureErrorText {

    /** Friendly, actionable text (pt-BR) shown in the toast/status area. */
    fun userMessage(failure: CaptureFailure): String {
        val base = when (failure.stage) {
            CaptureStage.MANAGER -> "MediaProjectionManager indisponível neste aparelho"
            CaptureStage.CONSENT -> "O consentimento de captura não foi concedido"
            CaptureStage.SERVICE_START -> "O sistema não permitiu iniciar o serviço de captura"
            CaptureStage.FOREGROUND -> "O serviço em primeiro plano foi rejeitado pelo sistema"
            CaptureStage.GET_PROJECTION -> "O sistema recusou criar a sessão de captura de tela"
            CaptureStage.CALLBACK -> "A sessão de captura foi criada mas o callback foi recusado"
            CaptureStage.IMAGE_READER -> "Falha ao criar o ImageReader da captura"
            CaptureStage.VIRTUAL_DISPLAY -> "Falha ao criar o VirtualDisplay da captura"
            CaptureStage.FIRST_FRAME -> "A captura iniciou mas nenhum quadro chegou"
            CaptureStage.FRAME_COPY -> "Falha ao copiar quadros da captura"
            CaptureStage.NONE -> "Falha na captura de tela"
        }
        return "$base — causa: ${failure.error.oneLine()}"
    }

    /**
     * One-line technical detail for logs and the UI ("last capture error"): stage + exact
     * exception class + exact message. This is what V5 was missing.
     */
    fun technicalLine(failure: CaptureFailure): String =
        "${failure.stage.name}/${failure.stage.label}: ${failure.error.oneLine()}"

    /**
     * Whether pressing START again has a realistic chance of succeeding without changing
     * permissions/settings. Used only for text hints, never to suppress the real error.
     */
    fun isRetryable(failure: CaptureFailure): Boolean = when (failure.stage) {
        CaptureStage.FIRST_FRAME, CaptureStage.FRAME_COPY -> true
        CaptureStage.GET_PROJECTION, CaptureStage.FOREGROUND, CaptureStage.VIRTUAL_DISPLAY -> {
            // A SecurityException about the foreground service is retryable once the consent is
            // fresh and the service is started first; a hard platform rejection usually is not.
            val msg = failure.error.message.lowercase()
            "foreground service" in msg || "stale" in msg || "timed out" in msg
        }
        CaptureStage.MANAGER, CaptureStage.SERVICE_START, CaptureStage.CONSENT -> false
        CaptureStage.IMAGE_READER -> true
        CaptureStage.CALLBACK -> true
        CaptureStage.NONE -> true
    }

    /** Compact hint appended to the diagnostic block. */
    fun retryHint(failure: CaptureFailure): String =
        if (isRetryable(failure)) "retry=possible (press START again)" else "retry=check permissions/settings first"
}
