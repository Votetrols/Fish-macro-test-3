package com.fischa.core.capture

/**
 * V6 spec §1/§2/§20 — every field the user asked us to record when the MediaProjection flow
 * fails, plus the device identity of the target phone (Samsung Galaxy A22 / SM-A225M / API 33).
 *
 * Nothing here is Android-specific, so the whole diagnostic block can be asserted in unit tests.
 */
data class DeviceProfile(
    val sdkInt: Int,
    val manufacturer: String,
    val model: String,
    val device: String = "",
    val product: String = "",
    val screenWidth: Int = 0,
    val screenHeight: Int = 0,
    val densityDpi: Int = 0,
    val rotation: Int = 0,
    val locale: String = "",
    val appVersionName: String = "",
    val appVersionCode: Long = 0L,
    val targetSdk: Int = 0,
) {
    /** `Samsung SM-A225M (a22) sdk=33 screen=720x1600 dpi=300 rot=1` */
    fun describe(): String = buildString {
        append(manufacturer).append(' ').append(model)
        if (device.isNotBlank() && !device.equals(model, ignoreCase = true)) {
            append(" (").append(device).append(')')
        }
        append(" sdk=").append(sdkInt)
        append(" screen=").append(screenWidth).append('x').append(screenHeight)
        append(" dpi=").append(densityDpi)
        append(" rot=").append(rotation)
    }

    fun keyValueLines(): List<String> = listOf(
        "sdk=$sdkInt",
        "manufacturer=$manufacturer",
        "model=$model",
        "device=$device",
        "product=$product",
        "screenWidth=$screenWidth",
        "screenHeight=$screenHeight",
        "densityDpi=$densityDpi",
        "rotation=$rotation",
        "locale=$locale",
        "appVersionName=$appVersionName",
        "appVersionCode=$appVersionCode",
        "targetSdk=$targetSdk",
    )

    /** True when this is (probably) the target device of this iteration. */
    fun isLikelyGalaxyA22(): Boolean =
        manufacturer.contains("samsung", ignoreCase = true) &&
            (model.contains("A225", ignoreCase = true) || device.contains("a22", ignoreCase = true))
}

/**
 * Accumulates the state of every stage of the capture flow. The Android layer fills what it
 * knows; `null` means "not reached / unknown", which is itself diagnostic information.
 */
class CaptureAttempt(
    var device: DeviceProfile? = null,
    /** where the capture was started from: START (fishing session) or DIAGNOSTIC (infra only) */
    var mode: String = "START",
) {
    // ---- consent / activity result ------------------------------------------------------
    var resultCode: Int? = null
    var dataPresent: Boolean? = null
    var managerPresent: Boolean? = null
    var startedFromActivity: String = "-"

    // ---- service / foreground -----------------------------------------------------------
    var serviceStarted: Boolean? = null
    var serviceState: String = "-"
    var foregroundStarted: Boolean? = null
    var foregroundType: String = "-"
    var notificationPosted: Boolean? = null
    var startForegroundException: CapturedException? = null

    // ---- projection ---------------------------------------------------------------------
    var projectionCreated: Boolean? = null
    var projectionCallbackRegistered: Boolean? = null
    var projectionStoppedBySystem: Boolean = false

    // ---- virtual display / image reader --------------------------------------------------
    var imageReaderCreated: Boolean? = null
    var imageReaderWidth: Int = 0
    var imageReaderHeight: Int = 0
    var imageReaderFormat: Int = 0
    var imageReaderMaxImages: Int = 0
    var virtualDisplayCreated: Boolean? = null
    var virtualDisplayWidth: Int = 0
    var virtualDisplayHeight: Int = 0
    var virtualDisplayDensity: Int = 0
    var virtualDisplayFlags: Int = 0

    // ---- frames --------------------------------------------------------------------------
    var firstFrameReceived: Boolean? = null
    var framesReceived: Long = 0L
    var framesProcessed: Long = 0L
    var framesDropped: Long = 0L
    var frameAgeMs: Long = FrameAge.NONE
    var fps: Float = 0f
    var firstFrameLatencyMs: Long = -1L

    // ---- failure -------------------------------------------------------------------------
    var stage: CaptureStage = CaptureStage.NONE
    var exceptionClass: String = ""
    var exceptionMessage: String = ""
    var exceptionStack: List<String> = emptyList()
    var hint: String = ""
    var elapsedMs: Long = 0L

    fun markStage(stage: CaptureStage) {
        this.stage = stage
    }

    fun capture(throwable: Throwable, hint: String = "") {
        val captured = CapturedException.from(throwable)
        exceptionClass = captured.exceptionClass
        exceptionMessage = captured.message
        exceptionStack = captured.stackTrace
        if (hint.isNotBlank()) this.hint = hint
    }

    fun hasFailure(): Boolean = exceptionClass.isNotEmpty()

    /**
     * The exact `[MEDIA_PROJECTION]` block requested in the V6 spec §1. Written to logcat, to the
     * in-app log and to the diagnostic report; it is the first thing to look at on the A22.
     */
    fun formatBlock(): String {
        val d = device
        return buildString {
            appendLine("[MEDIA_PROJECTION]")
            appendLine("sdk=${d?.sdkInt ?: -1}")
            appendLine("manufacturer=${d?.manufacturer ?: "?"}")
            appendLine("model=${d?.model ?: "?"}")
            appendLine("device=${d?.device ?: "?"}")
            appendLine("screen=${d?.screenWidth ?: 0}x${d?.screenHeight ?: 0} dpi=${d?.densityDpi ?: 0} rot=${d?.rotation ?: 0}")
            appendLine("mode=$mode")
            appendLine("resultCode=${resultCode?.toString() ?: "?"}")
            appendLine("dataPresent=${dataPresent?.toString() ?: "?"}")
            appendLine("managerPresent=${managerPresent?.toString() ?: "?"}")
            appendLine("serviceStarted=${serviceStarted?.toString() ?: "?"} serviceState=$serviceState")
            appendLine("foregroundStarted=${foregroundStarted?.toString() ?: "?"} foregroundType=$foregroundType notificationPosted=${notificationPosted?.toString() ?: "?"}")
            appendLine("projectionCreated=${projectionCreated?.toString() ?: "?"} callbackRegistered=${projectionCallbackRegistered?.toString() ?: "?"} projectionStoppedBySystem=$projectionStoppedBySystem")
            appendLine("imageReaderCreated=${imageReaderCreated?.toString() ?: "?"} ${imageReaderWidth}x$imageReaderHeight format=$imageReaderFormat maxImages=$imageReaderMaxImages")
            appendLine("virtualDisplayCreated=${virtualDisplayCreated?.toString() ?: "?"} ${virtualDisplayWidth}x$virtualDisplayHeight density=$virtualDisplayDensity flags=$virtualDisplayFlags")
            appendLine("firstFrameReceived=${firstFrameReceived?.toString() ?: "?"} firstFrameLatencyMs=$firstFrameLatencyMs")
            appendLine("framesReceived=$framesReceived framesProcessed=$framesProcessed framesDropped=$framesDropped")
            appendLine("fps=${"%.1f".format(fps)} frameAge=${FrameAge.format(frameAgeMs)}")
            appendLine("stage=${stage.name}(${stage.label})")
            appendLine("exceptionClass=${exceptionClass.ifEmpty { "none" }}")
            appendLine("exceptionMessage=${exceptionMessage.ifEmpty { "none" }}")
            appendLine("hint=${hint.ifEmpty { "none" }}")
            if (exceptionStack.isNotEmpty()) {
                appendLine("stackTrace=")
                exceptionStack.forEach { appendLine(it) }
            }
            append("elapsedMs=$elapsedMs")
        }
    }

    /**
     * One-line version for logcat / throttle-safe logging. Keeps class + message verbatim.
     */
    fun formatLine(): String = "[MEDIA_PROJECTION] sdk=${device?.sdkInt ?: -1} manufacturer=${device?.manufacturer ?: "?"} " +
        "model=${device?.model ?: "?"} resultCode=${resultCode ?: -1} dataPresent=${dataPresent ?: false} " +
        "managerPresent=${managerPresent ?: false} serviceStarted=${serviceStarted ?: false} " +
        "foregroundStarted=${foregroundStarted ?: false} projectionCreated=${projectionCreated ?: false} " +
        "imageReaderCreated=${imageReaderCreated ?: false} virtualDisplayCreated=${virtualDisplayCreated ?: false} " +
        "firstFrameReceived=${firstFrameReceived ?: false} stage=${stage.name} " +
        "exceptionClass=${exceptionClass.ifEmpty { "none" }} exceptionMessage=${exceptionMessage.ifEmpty { "none" }}"

    /** True only when the session is genuinely capturing (spec §20 acceptance criteria). */
    fun capturedSuccessfully(): Boolean =
        virtualDisplayCreated == true && imageReaderCreated == true && projectionCreated == true &&
            firstFrameReceived == true && fps > 0f && FrameAge.isValid(frameAgeMs) && framesReceived > 0
}
