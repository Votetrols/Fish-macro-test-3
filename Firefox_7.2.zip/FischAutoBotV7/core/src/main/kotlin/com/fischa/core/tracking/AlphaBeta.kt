package com.fischa.core.tracking

import kotlin.math.abs

/**
 * Minimal 1-D alpha-beta filter — deliberately *not* a heavy Kalman: the fish can stop and
 * reverse within a couple of frames (measured in the video), so the filter must react fast.
 * Innovation gating with hard re-sync handles those jumps without lag.
 *
 * Units are whatever the caller feeds (normalized bar units [0..1] throughout this project).
 */
class AlphaBeta(
    var alpha: Float = 0.55f,
    var beta: Float = 0.30f,
    /** innovation beyond which we snap position and re-estimate velocity from the jump */
    var jumpThreshold: Float = 0.22f,
) {
    var pos = 0f; private set
    var vel = 0f; private set
    var acc = 0f; private set
    var lastMeas = 0f; private set
    var initialized = false; private set
    /** last dt used; trackers keep per-cadence state consistent */
    var lastDt = 0f; private set

    fun reset() { initialized = false; pos = 0f; vel = 0f; acc = 0f }

    fun seed(p: Float) { pos = p; vel = 0f; acc = 0f; lastMeas = p; initialized = true }

    /** update with a measurement; returns innovation (meas - predicted) */
    fun update(p: Float, dt: Float): Float {
        if (dt <= 0.0001f) return 0f
        lastDt = dt
        if (!initialized) { seed(p); return 0f }
        val pred = pos + vel * dt
        var innov = p - pred
        if (abs(innov) > jumpThreshold) {
            // abrupt fish behavior: snap to the new observation, damp velocity, keep moving
            acc = (p - pos) / (dt * dt) * 0.02f
            pos = p
            vel = 0.5f * (vel + (p - lastMeas) / dt)
            lastMeas = p
            return innov
        }
        val xNew = pred + alpha * innov
        // velocity uses innovation for smoother response during direction changes
        vel += beta * innov / dt
        // mild velocity damping so a stopped fish stops being "predicted" forever
        vel *= 0.94f
        acc = 0.85f * acc + 0.15f * ((xNew - pos) / dt - vel) / dt
        pos = xNew
        lastMeas = p
        return innov
    }

    fun predict(dt: Float): Float = pos + vel * dt

    fun coast(dt: Float) {
        if (!initialized) return
        pos += vel * dt
        vel *= (1f - 2.5f * dt).coerceIn(0.7f, 1f)
    }
}
