package com.fischa.core.debug

import com.fischa.core.state.FishingState

/**
 * Immutable snapshot the pipeline publishes for the debug overlay (spec §14). Coordinates are
 * normalized (0..1) so the overlay can render them on any display size/orientation. The
 * pipeline builds one small instance per processed frame (cheap; no pixel data).
 */
class RenderModel(
    val state: FishingState,
    val fps: Float,
    val procMs: Float,
    /** normalized boxes (left, top, right, bottom) */
    val barBox: FloatArray?,
    val blockBox: FloatArray?,
    val fishBox: FloatArray?,
    val shakeBox: FloatArray?,
    val rodBox: FloatArray?,
    val progressBox: FloatArray?,
    val fishCx: Float,
    val playerCx: Float,
    val error: Float,
    val fishVel: Float,
    val playerVel: Float,
    val desiredVel: Float,
    val action: String,
    val actionReason: String,
    val progress: Float,
    val progressRate: Float,
    val confGlobal: Float,
    val confBar: Float,
    val confFish: Float,
    val confPlayer: Float,
    val confShake: Float,
    val confRod: Float,
    /** V5: rod button passed the temporal confirmation on this frame */
    val rodConfirmed: Boolean = false,
    /** V5: InputSafetyGuard authorizes the WAITING_FOR_ROD → CASTING transition */
    val castAuthorized: Boolean = false,
    val holdActive: Boolean,
    val tapsThisSession: Int,
    val shakeSession: Int,
    val denyReason: String,
    val emergency: Boolean,
    val armed: Boolean,
    val robloxDetected: Boolean = false,
    val foregroundPackage: String = "<unknown>",
    val foregroundWindow: String = "<unknown>",
    val inputAuthorized: Boolean = false,
    val realInputEnabled: Boolean = false,
    val frameAgeMs: Long = Long.MAX_VALUE,
    val safetyBlockedReason: String = "",
    // ---- V7 §5: rod detection (auto-calibrated, dynamic ROI) ----------------------------
    /** detection state machine name (INIT/AUTO_CALIBRATION/SEARCHING_ROD/…/TRACKING_ROD) */
    val rodState: String = "INIT",
    val rodScore: Float = 0f,
    val rodCandidates: Int = 0,
    val rodStreak: Int = 0,
    val rodRequiredFrames: Int = 0,
    val rodTracking: Boolean = false,
    val rodLostMs: Long = 0L,
    val rodReason: String = "",
    /** dynamic ROI around the detected button (normalized l,t,r,b) */
    val rodRoiBox: FloatArray? = null,
    /** current wide-search region (normalized l,t,r,b) */
    val rodSearchBox: FloatArray? = null,
    /** detected button centre (normalized) */
    val rodCenterNorm: FloatArray? = null,
    val rodCalibrationDone: Boolean = false,
    /** one-line summary of the calibration currently in force */
    val rodCalibration: String = "",
    val rodCandidateDetail: String = "",
    // ---- V7 §10: layer separation -------------------------------------------------------
    val layerVision: String = "ACTIVE",
    val layerDetection: String = "ACTIVE",
    val layerDecision: String = "ACTIVE",
    val layerInput: String = "DISABLED",
)
