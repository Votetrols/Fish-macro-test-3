package com.fischa.core.tracking

import com.fischa.core.common.clamp01
import com.fischa.core.config.AppConfig
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Time + confidence bookkeeping shared by the trackers. All trackers operate in **normalized
 * units of the minigame bar** ([0..1] along the bar), which makes them resolution- and
 * rod-width-independent by construction.
 */

class FishTrack {
    /** normalized position along the bar, 0..1 (never NaN; clamped by the tracker) */
    var x = 0.5f; internal set
    /** estimated velocity in bar-widths per second (sign = direction) */
    var v = 0f; internal set
    /** rough acceleration */
    var a = 0f; internal set
    var confidence = 0f; internal set
    var valid = false; internal set
    /** ms since last *measurement* (not prediction) */
    var ageMs = 0L; internal set
    var lost = false; internal set

    fun snapshotTo(o: FishTrack) {
        o.x = x; o.v = v; o.a = a; o.confidence = confidence; o.valid = valid; o.ageMs = ageMs; o.lost = lost
    }
}

class FishTracker(private val cfg: AppConfig.Tracking) {
    private val ab = AlphaBeta(alpha = cfg.fishAlpha, beta = cfg.fishBeta, jumpThreshold = cfg.fishJumpResyncNorm)
    private var lastTsNs = 0L
    private var lastMeasTsNs = 0L
    val out = FishTrack()

    fun reset() { ab.reset(); lastTsNs = 0L; lastMeasTsNs = 0L; out.valid = false; out.lost = true; out.confidence = 0f; out.ageMs = Long.MAX_VALUE / 4 }

    /**
     * @param normX measured fish x (bar-normalized) or null when the detector missed
     * @param conf raw confidence of that detection 0..1
     */
    fun update(nowNs: Long, normX: Float?, conf: Float, barWidthPx: Float) {
        val dt = if (lastTsNs == 0L) 1f / 30f else max(0.001f, min(0.25f, (nowNs - lastTsNs) / 1e9f))
        lastTsNs = nowNs
        if (normX != null && conf > 0.25f) {
            val clamped = clamp01(normX)
            ab.update(clamped, dt)
            lastMeasTsNs = nowNs
            out.confidence = conf
            out.valid = true
            out.lost = false
        } else {
            ab.coast(dt)
            val age = nowNs - lastMeasTsNs
            out.ageMs = age / 1_000_000L
            val decay = cfg.confDecayPerSec
            out.confidence = max(0f, out.confidence - decay * dt)
            if (age > cfg.fishMaxLostMs * 1_000_000L) {
                out.lost = true
                out.valid = false
            }
        }
        if (normX != null && conf > 0.25f) out.ageMs = 0L
        out.x = ab.pos
        out.v = ab.vel
        out.a = ab.acc
    }

    fun predictX(horizonSec: Float): Float = ab.pos + ab.vel * horizonSec
}

class PlayerTrack {
    var x = 0.5f; internal set
    var v = 0f; internal set
    var widthNorm = 0.3f; internal set
    var mismatchTint = false; internal set
    var atLeftEdge = false; internal set
    var atRightEdge = false; internal set
    var confidence = 0f; internal set
    var valid = false; internal set
    var lost = false; internal set
    var ageMs = 0L; internal set

    fun snapshotTo(o: PlayerTrack) {
        o.x = x; o.v = v; o.widthNorm = widthNorm; o.mismatchTint = mismatchTint
        o.atLeftEdge = atLeftEdge; o.atRightEdge = atRightEdge
        o.confidence = confidence; o.valid = valid; o.lost = lost; o.ageMs = ageMs
    }
}

/**
 * Tracks the white controllable block. The learned width (spec: never resize it by hand) is a
 * slow EMA; edge detection is derived from center ± half-width against the bar span.
 */
class PlayerBarTracker(private val cfg: AppConfig.Tracking) {
    private val ab = AlphaBeta(alpha = cfg.blockAlpha, beta = 0.12f, jumpThreshold = 0.35f)
    private var lastTsNs = 0L
    private var lastMeasTsNs = 0L
    var widthNormEma = -1f; private set
    val out = PlayerTrack()

    fun reset() {
        ab.reset(); lastTsNs = 0L; lastMeasTsNs = 0L
        out.valid = false; out.lost = true; out.confidence = 0f; out.ageMs = Long.MAX_VALUE / 4
    }

    fun update(nowNs: Long, centerXNorm: Float?, widthNorm: Float, conf: Float, tinted: Boolean,
               barLeftPx: Float, barRightPx: Float, blockLeftPx: Float, blockRightPx: Float) {
        val dt = if (lastTsNs == 0L) 1f / 30f else max(0.001f, min(0.25f, (nowNs - lastTsNs) / 1e9f))
        lastTsNs = nowNs
        if (centerXNorm != null && conf > 0.25f) {
            ab.update(clamp01(centerXNorm), dt)
            lastMeasTsNs = nowNs
            out.confidence = conf
            out.valid = true; out.lost = false
            if (widthNorm > 0.05f) {
                widthNormEma = if (widthNormEma < 0f) widthNorm else widthNormEma * 0.9f + widthNorm * 0.1f
            }
        } else {
            ab.coast(dt)
            out.ageMs = (nowNs - lastMeasTsNs) / 1_000_000L
            out.confidence = max(0f, out.confidence - cfg.confDecayPerSec * dt)
            if (out.ageMs > cfg.blockMaxLostMs) { out.lost = true; out.valid = false }
        }
        if (centerXNorm != null && conf > 0.25f) out.ageMs = 0L
        out.x = ab.pos
        out.v = ab.vel
        out.mismatchTint = tinted
        if (widthNormEma > 0f) out.widthNorm = widthNormEma
        // edge clamp detection uses raw pixels when available (independent of the EMA)
        val barW = (barRightPx - barLeftPx).coerceAtLeast(1f)
        if (blockRightPx > blockLeftPx) {
            out.atLeftEdge = (blockLeftPx - barLeftPx) < barW * 0.03f
            out.atRightEdge = (barRightPx - blockRightPx) < barW * 0.03f
        }
    }

    fun predictX(horizonSec: Float): Float = ab.pos + ab.vel * horizonSec
}

/**
 * Smooths the bar rectangle itself (it can wobble a few px as the camera moves). While
 * `locked`, the pipeline searches detectors only inside an inflated band — the main
 * performance lever (spec §16: process only needed regions).
 */
class BarTracker(private val cfg: AppConfig.Tracking) {
    private val s = floatArrayOf(0f, 0f, 0f, 0f) // left top right bottom
    var locked = false; private set
    var confidence = 0f; private set
    var lastSeenNs = 0L; private set

    fun reset() { locked = false; confidence = 0f }

    /** @return the smoothed rect as (left, top, right, bottom) in [outRect] */
    fun update(l: Float, t: Float, r: Float, b: Float, conf: Float, outRect: FloatArray): Boolean {
        if (conf > cfg.barLockMinConf) {
            if (!locked) {
                s[0] = l; s[1] = t; s[2] = r; s[3] = b; locked = true
            } else {
                val a = cfg.barAlpha
                s[0] += a * (l - s[0]); s[1] += a * (t - s[1])
                s[2] += a * (r - s[2]); s[3] += a * (b - s[3])
            }
            confidence = max(confidence * 0.6f, conf)
        } else {
            confidence *= 0.5f
            if (locked && confidence < cfg.barUnlockConf) locked = false
        }
        outRect[0] = s[0]; outRect[1] = s[1]; outRect[2] = s[2]; outRect[3] = s[3]
        return locked
    }

    fun touch(nowNs: Long) { lastSeenNs = nowNs }
}

/**
 * Progress trend + rate. Kept as EMA + slope over a 0.5 s window; the state machine uses
 * `rate` to tell "winning" from "losing" and the controller widens its bands when losing.
 */
class ProgressTracker {
    var value = -1f; private set
    var rate = 0f; private set   // units/s (fraction of bar progress per second)
    private var samples = FloatArray(64)
    private var stamps = LongArray(64)
    private var n = 0
    private var lastConf = 0f

    fun reset() { value = -1f; rate = 0f; n = 0 }

    fun update(nowNs: Long, v: Float?, conf: Float) {
        if (v == null || conf < 0.4f) return
        lastConf = conf
        value = if (value < 0f) v else value * 0.7f + v * 0.3f
        val i = n % samples.size
        samples[i] = value
        stamps[i] = nowNs
        n++
        if (n >= 8) {
            val end = n % samples.size
            val startIdx = (n - 8) % samples.size
            val dt = (stamps[(end - 1 + samples.size) % samples.size] - stamps[startIdx]) / 1e9f
            val dv = samples[(end - 1 + samples.size) % samples.size] - samples[startIdx]
            if (dt > 0.05f) rate = dv / dt
        }
    }

    fun confidence() = lastConf
}

/**
 * Aggregates per-detector confidences into the single number the SafetyGuard reads
 * (spec §15: "insufficient confidence" must block input).
 */
class ConfidenceTracker(private val cfg: AppConfig.Tracking) {
    var bar = 0f; private set
    var fish = 0f; private set
    var player = 0f; private set
    var global = 0f; private set
    /** true while a *complete enough* picture exists for control */
    var controlReady = false; private set

    fun reset() { bar = 0f; fish = 0f; player = 0f; global = 0f; controlReady = false }

    fun update(barC: Float, fishC: Float, playerC: Float, tsNs: Long) {
        val a = cfg.confEmaAlpha
        bar = bar * (1 - a) + barC * a
        fish = fish * (1 - a) + fishC * a
        player = player * (1 - a) + playerC * a
        global = 0.45f * bar + 0.30f * fish + 0.25f * player
        controlReady = bar > 0.5f && fish > 0.35f && player > 0.35f
    }
}
