package com.fischa.core.control

import com.fischa.core.config.AppConfig
import kotlin.math.abs

/** A tap request in normalized screen coordinates (0..1). */
class TapRequest {
    var nx = 0f; var ny = 0f
    var durMs = 60
    var reason = ""
    fun copyTo(o: TapRequest) { o.nx = nx; o.ny = ny; o.durMs = durMs; o.reason = reason }
}

/**
 * Drives the shake phase (spec §10): detect → bbox → center → tap → wait → re-detect.
 * No fixed count, no fixed position, no fixed interval, no artificial search timeout.
 *
 * Anti-stale rule: if the prompt sits at exactly the same place for longer than
 * `sameSpotGuardMs` we re-tap it (the game may need repeated presses), but never faster than
 * the guard interval. All coordinates arrive already normalized by the pipeline.
 *
 * This class never emits input — the caller routes [tick] results through the safety layer.
 */
class ShakeController(private val cfg: AppConfig.Shake) {

    enum class Phase { SEARCHING, CONFIRMING, TAPPED_WAITING_GONE }

    var phase = Phase.SEARCHING; private set
    var tapsThisSession = 0; private set
    private var confirmStreak = 0
    private var lostStreak = 0
    private var lastTapNs = 0L
    private var lastTapNx = -1f; private var lastTapNy = -1f
    private val out = TapRequest()

    fun resetSession() {
        phase = Phase.SEARCHING; confirmStreak = 0; lostStreak = 0
        tapsThisSession = 0; lastTapNs = 0L; lastTapNx = -1f; lastTapNy = -1f
    }

    fun tick(detected: Boolean, conf: Float, cxNorm: Float, cyNorm: Float, nowNs: Long): TapRequest? {
        if (detected && conf >= cfg.minConfidence) {
            lostStreak = 0
            confirmStreak++
            val movedOrFresh = lastTapNx < 0f ||
                abs(cxNorm - lastTapNx) + abs(cyNorm - lastTapNy) > cfg.sameSpotEpsF ||
                nowNs - lastTapNs > cfg.sameSpotGuardMs * 1_000_000L
            val cooldownOk = nowNs - lastTapNs >= cfg.tapCooldownMs * 1_000_000L
            if (confirmStreak >= cfg.confirmFrames && cooldownOk && movedOrFresh) {
                lastTapNs = nowNs; lastTapNx = cxNorm; lastTapNy = cyNorm
                tapsThisSession++
                phase = Phase.TAPPED_WAITING_GONE
                out.nx = cxNorm; out.ny = cyNorm
                out.durMs = cfg.tapDurMs
                out.reason = "shake tap #$tapsThisSession conf=%.2f".format(conf)
                return out
            }
            if (phase == Phase.SEARCHING) phase = Phase.CONFIRMING
            return null
        } else {
            confirmStreak = 0
            lostStreak++
            if (phase == Phase.TAPPED_WAITING_GONE && lostStreak >= cfg.lostFrames) phase = Phase.SEARCHING
            return null
        }
    }
}
