package com.fischa.core.vision

import com.fischa.core.config.AppConfig
import kotlin.math.max
import kotlin.math.min

/**
 * Finds the SHAKE prompt anywhere on screen: dark disc + light ring + **white glyphs**
 * ("SHAKE"). The prompt moves and repeats; nothing about position/count is assumed.
 *
 * The Roblox top bar (Shop/Menu/Aquariums) also contains white text on dark strips, so the
 * disc/ring geometry is mandatory — text alone never triggers. The search strip excludes the
 * top system bar and is additionally gated by *transience*: the prompt appears and disappears
 * within ~1–3 s while static HUD text does not; temporal gating in [TemporalDetector]
 * enforces that only for entering/leaving, so we also discount centers whose immediate
 * surroundings changed nothing for a long time while the disc itself appeared (see [staticPenalty]).
 *
 * Output: box = disc bounds (tap target = center); v0 = radius; v1 = white glyph fraction;
 * v2 = static-surround penalty; v3 = interior darkness.
 */
class ShakeDetector(private val cfg: AppConfig.Vision) :
    TemporalDetector("Shake", minOnFrames = 2, minOffFrames = 3) {

    private val disc = DiscMatcher(28)
    private val scoreBuf = DiscMatcher.Score()

    override fun detectRaw(frame: VisionFrame, hit: DetSnapshot): Float {
        val w = frame.width; val h = frame.height
        val x0 = (cfg.shakeSearchX0 * w).toInt(); val x1 = (cfg.shakeSearchX1 * w).toInt()
        val y0 = (cfg.shakeSearchY0 * h).toInt(); val y1 = (cfg.shakeSearchY1 * h).toInt()
        val minR = max(7, (cfg.shakeRadiusMinF * w).toInt())
        val maxR = max(minR + 10, (cfg.shakeRadiusMaxF * w).toInt())

        val s = disc.bestDisc(frame, x0, y0, x1, y1, minR, maxR, step = 5,
            interiorMaxGray = 120, minRingDelta = cfg.shakeRingMinDelta, out = scoreBuf)
        if (s.r <= 0) return 0f
        if (s.interiorGray > cfg.shakeInteriorMaxGray) return 0f

        // white text glyphs inside the disc are the key discriminator vs. the rod button
        val whiteFrac = disc.interiorFrac(frame, s.cx, s.cy, s.r, cfg.shakeGlyphMinGray, 255)
        val textScore = min(1f, (whiteFrac - 0.02f) * 14f).coerceIn(0f, 1f)
        if (textScore <= 0.05f) return 0f

        val contrastScore = min(1f, s.ringDelta / 50f)
        val interiorDark = 1f - min(s.interiorGray.toFloat(), 140f) / 140f
        val raw = (0.40f * textScore + 0.32f * contrastScore + 0.16f * interiorDark + 0.12f * s.roundness)
            .coerceIn(0f, 1f)

        if (raw > 0.5f) {
            hit.detected = true
            hit.box.set((s.cx - s.r).toFloat(), (s.cy - s.r).toFloat(), (s.cx + s.r).toFloat(), (s.cy + s.r).toFloat())
            hit.rawScore = raw
            hit.v0 = s.r.toFloat(); hit.v1 = whiteFrac; hit.v2 = 0f; hit.v3 = interiorDark
        }
        return raw
    }
}
