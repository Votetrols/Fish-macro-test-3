package com.fischa.core.capture

import com.fischa.core.vision.VisionFrame
import java.util.Collections
import java.util.IdentityHashMap

/**
 * Bounded, latest-only frame exchange between Android capture and vision. Slots are reused;
 * an unprocessed pending frame is returned to the pool when a newer one arrives, so latency
 * cannot grow into an old-frame queue.
 */
class FrameBuffer(
    width: Int,
    height: Int,
    capacity: Int = 3,
) : AutoCloseable {
    private val free = ArrayDeque<VisionFrame>()
    private val writing = Collections.newSetFromMap(IdentityHashMap<VisionFrame, Boolean>())
    private val inUse = Collections.newSetFromMap(IdentityHashMap<VisionFrame, Boolean>())
    private val all = Collections.newSetFromMap(IdentityHashMap<VisionFrame, Boolean>())
    private var pending: VisionFrame? = null
    private var closed = false
    private var dropped = 0L

    init {
        require(width > 0 && height > 0)
        require(capacity in 2..8) { "FrameBuffer capacity must be 2..8" }
        repeat(capacity) {
            val frame = VisionFrame.allocate(width, height)
            all.add(frame)
            free.addLast(frame)
        }
    }

    @Synchronized
    fun acquireWritable(): VisionFrame? {
        if (closed) return null
        val frame = free.removeFirstOrNull()
        if (frame == null) {
            dropped++
            return null
        }
        writing.add(frame)
        return frame
    }

    /** Publishes a slot filled by the producer; any older not-yet-consumed slot is dropped. */
    @Synchronized
    fun publish(frame: VisionFrame): Boolean {
        if (closed || !writing.remove(frame) || !all.contains(frame)) {
            if (writing.remove(frame) && !closed) free.addLast(frame)
            return false
        }
        pending?.let {
            pending = null
            free.addLast(it)
            dropped++
        }
        pending = frame
        return true
    }

    /** Takes only the newest pending frame; returns immediately when none is ready. */
    @Synchronized
    fun takeLatest(): VisionFrame? {
        if (closed) return null
        val frame = pending ?: return null
        pending = null
        inUse.add(frame)
        return frame
    }

    /** Returns a consumed slot to the producer pool. */
    @Synchronized
    fun release(frame: VisionFrame) {
        if (inUse.remove(frame) && !closed && all.contains(frame)) free.addLast(frame)
    }

    /** Returns a failed/abandoned producer slot to the pool. */
    @Synchronized
    fun cancelWrite(frame: VisionFrame) {
        if (writing.remove(frame) && !closed && all.contains(frame)) free.addLast(frame)
    }

    @Synchronized fun pendingCount(): Int = if (pending == null) 0 else 1
    @Synchronized fun droppedFrames(): Long = dropped
    @Synchronized fun isClosed(): Boolean = closed

    @Synchronized
    override fun close() {
        closed = true
        pending = null
        free.clear()
        writing.clear()
        inUse.clear()
        all.clear()
    }
}
