package com.fischa.core.capture

/**
 * V6 spec §8/§15 — the screen-capture lifecycle is a first-class state machine, completely
 * separate from the fishing FSM ([com.fischa.core.state.FishingState]).
 *
 * V5 collapsed every situation into `Captura: false`, which made the Galaxy A22 failure
 * impossible to diagnose: "capture denied by the user", "foreground service rejected",
 * "getMediaProjection threw SecurityException" and "capture running fine" all looked identical.
 *
 * V6 keeps the two machines apart on purpose:
 *  - a MediaProjection failure moves *this* machine to [FAILED] and never touches the fishing FSM;
 *  - the fishing FSM only reports what it can actually see (IDLE while no capture exists).
 */
enum class CaptureState {
    /** No capture infrastructure. Before START, after STOP, after a clean teardown. */
    STOPPED,

    /** The consent dialog is on screen (or was requested) — `createScreenCaptureIntent()` issued. */
    REQUESTING_PERMISSION,

    /** Consent granted (resultCode = RESULT_OK, data present). Nothing started yet. */
    AUTHORIZED,

    /** Foreground service + MediaProjection + VirtualDisplay/ImageReader are being built. */
    STARTING,

    /** VirtualDisplay is producing frames that reach the frame buffer. */
    RUNNING,

    /** Something failed; [CaptureSessionState.lastFailure] holds the original, unmasked cause. */
    FAILED,
    ;

    /** True while the machine owns (or is about to own) platform capture resources. */
    val active: Boolean get() = this == REQUESTING_PERMISSION || this == AUTHORIZED ||
        this == STARTING || this == RUNNING

    /** Only a RUNNING capture may feed vision or authorize anything. */
    val producesFrames: Boolean get() = this == RUNNING
}

/**
 * MediaProjection object lifecycle (V6 spec §6/§17). Distinct from [CaptureState] because the
 * projection token survives (AUTHORIZED) while the service is being started, and can be stopped
 * by the system (STOPPED) independently of our own teardown.
 */
enum class ProjectionState {
    NONE,
    AUTHORIZED,
    ACTIVE,
    STOPPED,
    ERROR,
}

/** Foreground-service lifecycle (V6 spec §4/§17). */
enum class ServiceState {
    STOPPED,
    STARTING,
    RUNNING,
    ERROR,
}

/**
 * Where in the deterministic V5→V6 flow a failure happened (spec §3):
 * Activity → MediaProjectionManager → createScreenCaptureIntent → Activity Result →
 * Foreground Service → MediaProjection → VirtualDisplay → ImageReader → ScreenCapture →
 * FrameBuffer → Vision.
 */
enum class CaptureStage(val label: String) {
    MANAGER("MediaProjectionManager"),
    CONSENT("consentimento (Activity Result)"),
    SERVICE_START("startForegroundService"),
    FOREGROUND("startForeground"),
    GET_PROJECTION("getMediaProjection"),
    CALLBACK("registerCallback"),
    IMAGE_READER("ImageReader.newInstance"),
    VIRTUAL_DISPLAY("createVirtualDisplay"),
    FIRST_FRAME("first frame"),
    FRAME_COPY("frame copy"),
    NONE("none"),
}

/** The original exception, preserved verbatim (V6 spec §1: never replace the real cause). */
class CapturedException(
    val exceptionClass: String,
    val message: String,
    val stackTrace: List<String>,
    val cause: String? = null,
) {
    /** `java.lang.SecurityException: Media projections require a foreground service ...` */
    fun oneLine(): String {
        val head = "$exceptionClass: ${message.ifBlank { "<no message>" }}"
        return if (cause.isNullOrBlank()) head else "$head (caused by $cause)"
    }

    fun firstFrame(): String = stackTrace.firstOrNull().orEmpty()

    fun describe(multiline: Boolean = true): String =
        if (multiline) (listOf(oneLine()) + stackTrace).joinToString("\n") else oneLine()

    override fun toString(): String = oneLine()

    companion object {
        /** Deepest exception class of the chain (usually the informative one). */
        fun rootClass(t: Throwable): String {
            var cur: Throwable = t
            var guard = 0
            while (cur.cause != null && cur.cause !== cur && guard++ < 16) cur = cur.cause!!
            return cur.javaClass.name
        }

        fun from(t: Throwable, maxFrames: Int = 12): CapturedException = CapturedException(
            exceptionClass = t.javaClass.name,
            message = t.message.orEmpty(),
            stackTrace = t.stackTrace
                .take(maxFrames)
                .map { "    at ${it.className}.${it.methodName}(${it.fileName}:${it.lineNumber})" },
            cause = t.cause?.let { rootClass(it) },
        )
    }
}

/** One unrecovered capture failure, with everything needed to fix it in the next iteration. */
data class CaptureFailure(
    val stage: CaptureStage,
    val error: CapturedException,
    val hint: String = "",
    val resultCode: Int? = null,
    val dataPresent: Boolean? = null,
    val timestampMs: Long = 0L,
) {
    /** Single line for the UI — always carries the original class + message, never a generic text. */
    fun summary(): String = buildString {
        append(stage.label).append(": ").append(error.oneLine())
        if (hint.isNotBlank()) append(" [").append(hint).append(']')
    }

    fun short(): String = "${stage.name}: ${error.exceptionClass}: ${error.message}"
}

/** One entry of the transition history (bounded, for the diagnostics screen). */
class CaptureTransition(
    val from: CaptureState,
    val to: CaptureState,
    val reason: String,
    val timestampNs: Long,
)

/**
 * Deterministic capture lifecycle machine (V6 spec §3/§6/§8/§15).
 *
 * Every platform interaction of the Android layer is expressed as an event here, so the whole
 * MediaProjection flow can be unit-tested on the JVM without a device (V6 spec §19).
 *
 * [strict] is used by the tests to make an illegal transition loud; in the app it stays false so
 * that a late callback can never crash the service after an error path already ran.
 */
class CaptureSessionState(
    private val clockNs: () -> Long = { 0L },
    private val strict: Boolean = false,
    private val historyLimit: Int = 32,
) {
    var state: CaptureState = CaptureState.STOPPED
        private set
    var projection: ProjectionState = ProjectionState.NONE
        private set
    var service: ServiceState = ServiceState.STOPPED
        private set
    var lastFailure: CaptureFailure? = null
        private set
    var lastReason: String = "init"
        private set

    /** >=0 while a capture attempt is in flight; used for the "elapsed" line of the diagnostic. */
    var attemptStartedNs: Long = 0L
        private set

    private val history = ArrayDeque<CaptureTransition>()
    private val listeners = ArrayList<(CaptureState, CaptureState, String) -> Unit>(4)
    private var errorNotified = false

    val historySnapshot: List<CaptureTransition> get() = history.toList()

    fun addListener(listener: (from: CaptureState, to: CaptureState, reason: String) -> Unit) {
        listeners.add(listener)
    }

    private fun transition(to: CaptureState, reason: String) {
        val from = state
        if (from == to) {
            lastReason = reason
            return
        }
        checkLegality(from, to)
        state = to
        lastReason = reason
        history.addLast(CaptureTransition(from, to, reason, clockNs()))
        while (history.size > historyLimit) history.removeFirst()
        // snapshot: listeners may mutate the machine (e.g. stop resources)
        for (listener in ArrayList(listeners)) runCatching { listener(from, to, reason) }
    }

    private fun checkLegality(from: CaptureState, to: CaptureState) {
        val ok = to in ALLOWED[from].orEmpty()
        if (ok) return
        val msg = "illegal capture transition $from -> $to"
        if (strict) throw IllegalStateException(msg)
    }

    // ---------------------------------------------------------------- events

    /** START pressed → consent dialog requested (spec §5). */
    fun requestPermission(reason: String = "createScreenCaptureIntent") {
        if (state == CaptureState.RUNNING || state == CaptureState.STARTING) {
            fail(CaptureStage.NONE, IllegalStateException("capture already active"), "requestPermission ignored")
            return
        }
        attemptStartedNs = clockNs()
        errorNotified = false
        transition(CaptureState.REQUESTING_PERMISSION, reason)
        projection = ProjectionState.NONE
        service = ServiceState.STOPPED
    }

    /** resultCode != RESULT_OK or data == null — capture never starts (spec §5). */
    fun permissionDenied(reason: String) {
        transition(CaptureState.STOPPED, reason)
        lastFailure = null
        projection = ProjectionState.NONE
    }

    /** resultCode == RESULT_OK && data != null (spec §5 CAPTURE_PERMISSION_RESULT). */
    fun authorized(reason: String = "RESULT_OK") {
        transition(CaptureState.AUTHORIZED, reason)
        projection = ProjectionState.AUTHORIZED
    }

    fun serviceStarting(reason: String = "startForegroundService") {
        service = ServiceState.STARTING
        if (state == CaptureState.AUTHORIZED) transition(CaptureState.STARTING, reason)
    }

    fun serviceRunning(reason: String = "startForeground") {
        service = ServiceState.RUNNING
        lastReason = reason
    }

    fun projectionActive(reason: String = "getMediaProjection") {
        projection = ProjectionState.ACTIVE
        lastReason = reason
    }

    /** First frame arrived → the session is real (spec §20 success criterion). */
    fun running(reason: String = "firstFrame") {
        transition(CaptureState.RUNNING, reason)
        service = ServiceState.RUNNING
        projection = ProjectionState.ACTIVE
    }

    /**
     * Records the *original* failure. The UI may show a friendly line, but this structure keeps
     * class + message + stack of what the platform actually threw (spec §1).
     */
    fun fail(
        stage: CaptureStage,
        throwable: Throwable,
        hint: String = "",
        resultCode: Int? = null,
        dataPresent: Boolean? = null,
    ): CaptureFailure {
        val failure = CaptureFailure(
            stage = stage,
            error = CapturedException.from(throwable),
            hint = hint,
            resultCode = resultCode,
            dataPresent = dataPresent,
            timestampMs = clockNs() / 1_000_000L,
        )
        return fail(stage, failure)
    }

    fun fail(stage: CaptureStage, failure: CaptureFailure): CaptureFailure {
        transition(CaptureState.FAILED, "fail:${stage.name}")
        lastFailure = failure
        errorNotified = true
        if (stage == CaptureStage.GET_PROJECTION || stage == CaptureStage.FOREGROUND ||
            stage == CaptureStage.MANAGER || stage == CaptureStage.SERVICE_START ||
            stage == CaptureStage.CONSENT
        ) {
            projection = if (projection == ProjectionState.NONE) ProjectionState.NONE else ProjectionState.ERROR
            service = ServiceState.ERROR
        }
        return failure
    }

    /** The system ended the projection (onStop) or we did (spec §6). */
    fun projectionStopped(reason: String = "projection onStop") {
        transition(CaptureState.STOPPED, reason)
        if (projection == ProjectionState.ACTIVE || projection == ProjectionState.AUTHORIZED) {
            projection = ProjectionState.STOPPED
        }
    }

    /** STOP / EMERGENCY STOP / clean shutdown: everything released (spec §6). */
    fun stopped(reason: String = "stop") {
        transition(CaptureState.STOPPED, reason)
        if (projection == ProjectionState.ACTIVE || projection == ProjectionState.AUTHORIZED) {
            projection = ProjectionState.STOPPED
        }
        service = ServiceState.STOPPED
    }

    /** After a clean stop, is a brand-new attempt allowed? (spec §6: never reuse old objects). */
    fun canStartNewAttempt(): Boolean = state == CaptureState.STOPPED || state == CaptureState.FAILED

    /** True when the machine is in a state that must never be reused for a new session. */
    fun holdsResources(): Boolean = state == CaptureState.STARTING || state == CaptureState.RUNNING

    fun clearFailure() {
        lastFailure = null
        errorNotified = false
    }

    fun snapshot(): CaptureStateSnapshot = CaptureStateSnapshot(
        state = state,
        projection = projection,
        service = service,
        reason = lastReason,
        failure = lastFailure,
        transitions = history.size,
    )

    companion object {
        /** Allowed edges of the capture lifecycle. Everything else is a programming error. */
        private val ALLOWED: Map<CaptureState, Set<CaptureState>> = mapOf(
            CaptureState.STOPPED to setOf(
                CaptureState.REQUESTING_PERMISSION, CaptureState.STOPPED,
            ),
            CaptureState.REQUESTING_PERMISSION to setOf(
                CaptureState.AUTHORIZED, CaptureState.STOPPED, CaptureState.FAILED,
            ),
            CaptureState.AUTHORIZED to setOf(
                CaptureState.STARTING, CaptureState.STOPPED, CaptureState.FAILED,
            ),
            CaptureState.STARTING to setOf(
                CaptureState.RUNNING, CaptureState.FAILED, CaptureState.STOPPED,
            ),
            CaptureState.RUNNING to setOf(
                CaptureState.STOPPED, CaptureState.FAILED,
            ),
            CaptureState.FAILED to setOf(
                CaptureState.STOPPED, CaptureState.REQUESTING_PERMISSION, CaptureState.FAILED,
            ),
        )

        fun isTransitionAllowed(from: CaptureState, to: CaptureState): Boolean =
            to in ALLOWED[from].orEmpty()
    }
}

/** Immutable capture-lifecycle snapshot published to the UI / diagnostics screen. */
data class CaptureStateSnapshot(
    val state: CaptureState = CaptureState.STOPPED,
    val projection: ProjectionState = ProjectionState.NONE,
    val service: ServiceState = ServiceState.STOPPED,
    val reason: String = "init",
    val failure: CaptureFailure? = null,
    val transitions: Int = 0,
) {
    fun describe(): String =
        "capture=${state.name} projection=${projection.name} service=${service.name}"
}
