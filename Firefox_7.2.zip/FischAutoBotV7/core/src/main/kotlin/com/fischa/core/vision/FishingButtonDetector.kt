package com.fischa.core.vision

import com.fischa.core.config.AppConfig
import kotlin.math.max
import kotlin.math.min

/**
 * Finds the rod/cast button — a dark semi-transparent disc with a light ring and a gray hook
 * glyph, on the right half of the screen near the jump area. Detection is entirely visual;
 * the calibrated prior position (config) only *weights* the score, it is never assumed.
 *
 * Output (in [DetSnapshot]): box = disc bounds; v0 = radius px; v1 = mid-gray glyph fraction;
 * v2 = distance from prior (normalized); v3 = interior darkness (0..1, higher=darker).
 */
class FishingButtonDetector(private val cfg: AppConfig.Vision) :
    TemporalDetector("FishingButton", minOnFrames = 2, minOffFrames = 3) {

    private val disc = DiscMatcher(24)
    private val scoreBuf = DiscMatcher.Score()

    override fun detectRaw(frame: VisionFrame, hit: DetSnapshot): Float {
        val w = frame.width; val h = frame.height
        val x0 = (cfg.rodSearchX0 * w).toInt(); val x1 = (cfg.rodSearchX1 * w).toInt()
        val y0 = (cfg.rodSearchY0 * h).toInt(); val y1 = (cfg.rodSearchY1 * h).toInt()
        val minR = max(6, (cfg.rodRadiusMinF * w).toInt())
        val maxR = max(minR + 8, (cfg.rodRadiusMaxF * w).toInt())

        val s = disc.bestDisc(frame, x0, y0, x1, y1, minR, maxR, step = 6,
            interiorMaxGray = 140, minRingDelta = cfg.rodRingMinDelta, out = scoreBuf)
        if (s.r <= 0) return 0f

        val interiorDark = 1f - min(s.interiorGray.toFloat(), 160f) / 160f
        if (s.interiorGray > cfg.rodInteriorMaxGray) return 0f

        // mid-gray glyph (the hook icon), not pure white: Shake uses white text instead
        val glyphFrac = disc.interiorFrac(frame, s.cx, s.cy, s.r, 115, 215)
        val whiteFrac = disc.interiorFrac(frame, s.cx, s.cy, s.r, 205, 255)
        val glyphScore = if (glyphFrac in 0.02f..0.35f) min(1f, glyphFrac * 10f) else 0f

        // prior distance weighting only — element remains fully position-agnostic
        val nx = s.cx.toFloat() / w; val ny = s.cy.toFloat() / h
        val pd = kotlin.math.sqrt(
            (nx - cfg.rodPriorCx) * (nx - cfg.rodPriorCx) + (ny - cfg.rodPriorCy) * (ny - cfg.rodPriorCy)
        )
        val priorBonus = cfg.rodPriorWeight * (1f - min(pd * 3f, 1f))

        // ring contrast dominates; require at least a hint of a glyph, allow bright overlay scenes
        val contrastScore = min(1f, s.ringDelta / 60f)
        var raw = 0.42f * contrastScore + 0.25f * glyphScore + 0.18f * interiorDark +
                0.15f * s.roundness + priorBonus - 0.20f * min(whiteFrac * 4f, 1f) // strong white text => shake, not rod
        raw = raw.coerceIn(0f, 1f)

        if (raw > 0.45f) {
            hit.detected = true
            hit.box.set((s.cx - s.r).toFloat(), (s.cy - s.r).toFloat(), (s.cx + s.r).toFloat(), (s.cy + s.r).toFloat())
            hit.rawScore = raw
            hit.v0 = s.r.toFloat(); hit.v1 = glyphFrac; hit.v2 = pd; hit.v3 = interiorDark
        }
        return raw
    }
}
