package com.fischa.core.common

/**
 * V7 §1 — an axis-aligned region expressed in **relative** coordinates (0..1) of the processed
 * frame. Every search region, ROI and padding in the V7 detection stack is expressed this way so
 * that no absolute pixel coordinate is ever baked into the behaviour: the same configuration
 * works on a 640×288 processing frame of a Galaxy A22 (1600×720 display), a tablet or a replay.
 *
 * Pixel conversion happens exactly once, at the point of use, via [toPx]/[pxLeft]… so a region can
 * never be confused with a pixel rectangle (all pixel-space math stays in the vision layer).
 */
data class NormRegion(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
) {
    val width: Float get() = (right - left).coerceAtLeast(0f)
    val height: Float get() = (bottom - top).coerceAtLeast(0f)
    val centerX: Float get() = (left + right) * 0.5f
    val centerY: Float get() = (top + bottom) * 0.5f

    val isValid: Boolean
        get() = left.isFinite() && top.isFinite() && right.isFinite() && bottom.isFinite() &&
            right > left && bottom > top

    fun contains(x: Float, y: Float): Boolean = x in left..right && y in top..bottom

    /** Grows the region by [fx]·width on the left/right and [fy]·height on the top/bottom. */
    fun inflateRelative(fx: Float, fy: Float = fx): NormRegion = NormRegion(
        left - width * fx,
        top - height * fy,
        right + width * fx,
        bottom + height * fy,
    )

    /** Same as [inflateRelative] but with absolute (normalized) deltas. */
    fun inflate(dx: Float, dy: Float = dx): NormRegion =
        NormRegion(left - dx, top - dy, right + dx, bottom + dy)

    fun clamp(): NormRegion = NormRegion(
        left.coerceIn(0f, 1f), top.coerceIn(0f, 1f),
        right.coerceIn(0f, 1f), bottom.coerceIn(0f, 1f),
    ).let { if (it.right <= it.left || it.bottom <= it.top) this.clampDegenerate() else it }

    private fun clampDegenerate(): NormRegion {
        val l = left.coerceIn(0f, 0.99f)
        val t = top.coerceIn(0f, 0.99f)
        return NormRegion(l, t, (l + 0.01f).coerceAtMost(1f), (t + 0.01f).coerceAtMost(1f))
    }

    fun intersect(other: NormRegion): NormRegion? {
        val l = maxOf(left, other.left); val t = maxOf(top, other.top)
        val r = minOf(right, other.right); val b = minOf(bottom, other.bottom)
        return if (r <= l || b <= t) null else NormRegion(l, t, r, b)
    }

    fun union(other: NormRegion): NormRegion =
        NormRegion(minOf(left, other.left), minOf(top, other.top), maxOf(right, other.right), maxOf(bottom, other.bottom))

    /** Region of [w]×[h] fraction around a normalized point, clamped to the unit square. */
    fun toPx(frameWidth: Int, frameHeight: Int): IntArray = intArrayOf(
        (left * frameWidth).toInt(), (top * frameHeight).toInt(),
        (right * frameWidth).toInt(), (bottom * frameHeight).toInt(),
    )

    /** Same geometry as a *pixel* rectangle (used only for the debug renderer/tests). */
    fun toPixelRegion(frameWidth: Int, frameHeight: Int): NormRegion = this

    fun describe(fmt: String = "(%.3f,%.3f,%.3f,%.3f)"): String =
        fmt.format(left, top, right, bottom)

    companion object {
        val UNIT = NormRegion(0f, 0f, 1f, 1f)

        fun around(cx: Float, cy: Float, w: Float, h: Float): NormRegion =
            NormRegion(cx - w * 0.5f, cy - h * 0.5f, cx + w * 0.5f, cy + h * 0.5f)

        /** Region built from a pixel rectangle of a [frameWidth]×[frameHeight] frame. */
        fun fromPx(l: Float, t: Float, r: Float, b: Float, frameWidth: Int, frameHeight: Int): NormRegion =
            NormRegion(l / frameWidth, t / frameHeight, r / frameWidth, b / frameHeight)
    }
}
