package com.fischa.core.capture

/**
 * V6 spec §5 — the Activity Result of `createScreenCaptureIntent()` is evaluated explicitly:
 * `resultCode == RESULT_OK`, `data != null`, manager available. If any condition fails the capture
 * must not start, and the reason must be recorded as `CAPTURE_PERMISSION_RESULT`.
 *
 * V5 only checked `resultCode != RESULT_OK || data == null` and produced a single boolean, which
 * is why a platform-level rejection later in the flow became the generic
 * "MediaProjection indisponível — tente novamente" toast.
 */
enum class ConsentDecision {
    /** Consent given; the foreground service may now be started. */
    PROCEED,

    /** The user pressed "Cancel"/"Don't allow" in the system dialog. */
    DENIED_BY_USER,

    /** Any other non-OK result code returned by the system dialog. */
    RESULT_NOT_OK,

    /** RESULT_OK but the returned Intent (or its projection token) is missing. */
    DATA_MISSING,

    /** `getSystemService(MediaProjectionManager)` returned null — platform/ROM problem. */
    MANAGER_UNAVAILABLE,
    ;

    val permitted: Boolean get() = this == PROCEED
}

data class ConsentEvaluation(
    val decision: ConsentDecision,
    val reason: String,
    /** `CAPTURE_PERMISSION_RESULT resultCode=0 dataPresent=true failureReason=...` */
    val logLine: String,
) {
    /** RESULT_CANCELED (0): the user pressed "Cancelar"/"Não permitir" in the system dialog. */
    fun isCancellation(): Boolean =
        decision == ConsentDecision.RESULT_NOT_OK && reason.contains("RESULT_NOT_OK(0)")

    fun friendlyMessage(): String = when {
        decision == ConsentDecision.PROCEED ->
            "Autorização de captura concedida; iniciando serviço de captura…"
        isCancellation() ->
            "Captura negada/cancelada por você na tela do sistema."
        decision == ConsentDecision.DENIED_BY_USER ->
            "Captura negada por você na tela do sistema."
        decision == ConsentDecision.RESULT_NOT_OK ->
            "O sistema não autorizou a captura (resultCode=$reason)."
        decision == ConsentDecision.DATA_MISSING ->
            "O sistema autorizou, mas não devolveu o token de captura (data=null)."
        else ->
            "MediaProjectionManager indisponível neste dispositivo."
    }
}

object CaptureConsentPolicy {

    const val RESULT_OK = -1

    /**
     * @param resultCode     Activity.RESULT_OK (-1) on success
     * @param dataPresent    whether the returned Intent is non-null (and carries the token)
     * @param managerPresent whether MediaProjectionManager could be obtained
     */
    fun evaluate(
        resultCode: Int?,
        dataPresent: Boolean,
        managerPresent: Boolean,
        dataHasToken: Boolean = dataPresent,
    ): ConsentEvaluation {
        val failureReason: String
        val decision = when {
            !managerPresent -> {
                failureReason = "MANAGER_UNAVAILABLE"
                ConsentDecision.MANAGER_UNAVAILABLE
            }

            resultCode == null -> {
                failureReason = "RESULT_CODE_MISSING"
                ConsentDecision.RESULT_NOT_OK
            }

            resultCode != RESULT_OK -> {
                failureReason = "RESULT_NOT_OK($resultCode)"
                ConsentDecision.RESULT_NOT_OK
            }

            !dataPresent -> {
                failureReason = "DATA_NULL"
                ConsentDecision.DATA_MISSING
            }

            !dataHasToken -> {
                failureReason = "DATA_WITHOUT_TOKEN"
                ConsentDecision.DATA_MISSING
            }

            else -> {
                failureReason = ""
                ConsentDecision.PROCEED
            }
        }
        val logLine = "CAPTURE_PERMISSION_RESULT resultCode=${resultCode ?: -1} " +
            "dataPresent=$dataPresent managerPresent=$managerPresent " +
            "failureReason=${failureReason.ifEmpty { "none" }}"
        return ConsentEvaluation(decision, failureReason, logLine)
    }

    /** A user-cancelled dialog is not an error, it is a decision (spec §5). */
    fun isUserCancellation(evaluation: ConsentEvaluation): Boolean = evaluation.isCancellation()

    /** True when the flow may continue with a foreground service + getMediaProjection. */
    fun mayStartCapture(evaluation: ConsentEvaluation): Boolean = evaluation.decision == ConsentDecision.PROCEED
}
