package com.fischa.core.control

import com.fischa.core.common.clamp
import com.fischa.core.config.AppConfig
import com.fischa.core.tracking.FishTrack
import com.fischa.core.tracking.PlayerTrack
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Actions the controller wants the input layer to realize. */
enum class ControlAction { NONE, TAP, HOLD_START, HOLD_EXTEND, HOLD_RELEASE }

/** Full decision record (debug overlay + logs). */
class ControlDecision {
    var action = ControlAction.NONE
    var tapDurMs = 0
    var holdUntilNextFrame = false
    /** signed error fish-player in normalized bar units (pos = player must go right) */
    var error = 0f
    var predictedError = 0f
    var fishVel = 0f
    var playerVel = 0f
    /** desired block velocity used internally (for logs/overlay) */
    var desiredVel = 0f
    var reason = "init"
    var holdActive = false
    var holdMs = 0L
    var tappable = true
    /** Set only when the current visual tracks and all control values are finite/in range. */
    var safe = false
}

/**
 * Real-time alignment controller for the minigame (spec §9/§24).
 *
 * Physics it models (measured in the reference video, units = bar-widths/second):
 *   - the block drifts LEFT at ~ −0.30/s whenever no finger is down;
 *   - holding moves it RIGHT at ~ +0.55…0.70/s (net +0.25…+0.40/s while holding);
 *   - actuation is therefore one-sided: we can only *push right* or *let drift pull left*.
 *
 * Control law: a PD-with-feedforward computes a *desired block velocity*; a bounded actuator
 * layer converts it into hold/tap/release with hysteresis + minimum durations, so the output
 * is stable (no chatter), low-latency (decided every frame) and never presses when aligned.
 * The controller never touches input itself — it only emits [ControlDecision] which the
 * InputController executes through the safety gate (spec §3: decision vs. input separated).
 */
class FishingController(private val cfg: AppConfig.Control) {

    private var holdActive = false
    private var holdStartNs = 0L
    private var lastTapNs = 0L
    private var lastReleaseNs = 0L
    private var lastTsNs = 0L
    /** hysteresis state to avoid chatter at band boundaries */
    private var pressing = false
    private var catchUp = false

    fun reset() {
        holdActive = false; pressing = false; catchUp = false
        holdStartNs = 0L; lastTapNs = 0L; lastReleaseNs = 0L; lastTsNs = 0L
    }

    val decision = ControlDecision()

    /**
     * @param nowNs frame timestamp
     * @param dtSec seconds since last frame (clamped by caller)
     * @param progressRate d(progress)/dt in units/s, used for the "losing" widening rule
     */
    fun update(
        nowNs: Long,
        dtSec: Float,
        fish: FishTrack,
        player: PlayerTrack,
        progressRate: Float,
    ): ControlDecision {
        val d = decision
        d.action = ControlAction.NONE
        d.holdActive = holdActive
        d.tappable = true
        d.safe = false

        // --- evidence gating -------------------------------------------------------------
        val confOk = fish.valid && fish.confidence >= cfg.minConfidence &&
                player.valid && player.confidence >= cfg.minConfidence
        if (!confOk) {
            if (holdActive) { holdActive = false; d.action = ControlAction.HOLD_RELEASE; d.reason = "low-confidence release" }
            else d.reason = "hold-off (low confidence)"
            d.error = 0f; d.predictedError = 0f
            lastTsNs = nowNs
            return d
        }
        val visualValues = floatArrayOf(fish.x, fish.v, player.x, player.v, progressRate)
        val tracksFiniteAndNormalized = visualValues.all { it.isFinite() } &&
            fish.x in 0f..1f && player.x in 0f..1f &&
            fish.confidence in 0f..1f && player.confidence in 0f..1f
        if (!tracksFiniteAndNormalized) {
            if (holdActive) {
                holdActive = false
                pressing = false
                d.action = ControlAction.HOLD_RELEASE
                d.reason = "invalid tracking values; release"
            } else {
                d.reason = "invalid tracking values; input suppressed"
            }
            d.error = 0f
            d.predictedError = 0f
            lastTsNs = nowNs
            return d
        }
        d.safe = true

        // --- error + prediction ------------------------------------------------------------
        val err = fish.x - player.x                       // >0: player left of fish → press
        val look = clamp(fish.v, -cfg.lookaheadVelClamp, cfg.lookaheadVelClamp) * cfg.lookaheadSec
        val predErr = err + look - player.v * 0.02f        // small lead of our own motion too
        d.error = err
        d.predictedError = predErr
        d.fishVel = fish.v
        d.playerVel = player.v

        // losing progress for a while → widen bands a bit (catch-up policy, spec §9.4)
        val losing = progressRate < -0.02f
        if (losing && !catchUp) { catchUpStartNs = nowNs; catchUp = true }
        if (!losing && catchUp && progressRate > 0.01f) catchUp = false
        val inCatchUp = catchUp && nowNs - catchUpStartNs > cfg.catchUpAfterMs * 1_000_000L
        val bonus = if (inCatchUp) cfg.catchUpBandBonus else 0f
        val db = cfg.deadband
        val tapB = cfg.tapBand + bonus
        val holdB = max(tapB, cfg.holdBand - bonus)

        // --- near-edge awareness ------------------------------------------------------------
        // Right edge: pressing cannot help (block clamped at bar right). Releasing lets the
        // drift bring it back left, which is what we want when the fish moves left.
        val nearRight = player.atRightEdge || player.x > 1f - cfg.edgeMargin
        val nearLeft = player.atLeftEdge || player.x < cfg.edgeMargin

        val absErr = abs(predErr)
        var wantPress = pressing
        if (absErr > holdB || (predErr > tapB && abs(fish.v) > 0.18f)) wantPress = true
        if (absErr < db) wantPress = false
        if (predErr < -db) wantPress = false                    // fish LEFT: only drift can fix
        if (cfg.rightEdgeNoHold && nearRight && predErr > 0) wantPress = false

        // desired block velocity (normalized/s): PD + fish-velocity feedforward. While pressed we
        // also add the drift constant so the term explains *why* short taps suffice when aligned.
        d.desiredVel = clamp(cfg.kP * predErr + cfg.kFF * fish.v + (if (wantPress) cfg.kDrift else 0f), -0.8f, 0.9f)

        // --- actuator layer (tap/hold/release with timing floors) ---------------------------
        when {
            wantPress && !holdActive && nowNs - lastReleaseNs >= cfg.minReleaseMs * 1_000_000L -> {
                holdActive = true; pressing = true; holdStartNs = nowNs
                d.action = ControlAction.HOLD_START
                d.reason = "error +%.3f → hold".format(predErr)
            }
            wantPress && holdActive -> {
                d.holdMs = (nowNs - holdStartNs) / 1_000_000L
                if (d.holdMs >= cfg.maxHoldMs) {
                    // A hold is always finite. Release at the configured cap; if the next fresh
                    // frame still needs rightward correction, a new HOLD_START can be authorized.
                    holdActive = false
                    pressing = false
                    lastReleaseNs = nowNs
                    d.action = ControlAction.HOLD_RELEASE
                    d.reason = "maximum continuous hold reached; release and re-evaluate"
                } else {
                    d.action = ControlAction.HOLD_EXTEND
                    d.holdUntilNextFrame = true
                    d.reason = "hold continues"
                }
            }
            !wantPress && holdActive && (nowNs - holdStartNs >= cfg.minHoldMs * 1_000_000L) -> {
                holdActive = false; pressing = false; lastReleaseNs = nowNs
                d.action = ControlAction.HOLD_RELEASE
                d.reason = if (nearLeft) "release (aligned / left edge)" else "release (aligned)"
            }
            !wantPress && holdActive -> {
                // inside minimum-hold window: keep extending (never release early — that would
                // waste a press and add oscillation)
                d.action = ControlAction.HOLD_EXTEND; d.holdUntilNextFrame = true
                d.reason = "minHold protection"
            }
            !holdActive && absErr in (db..tapB) && predErr > 0 &&
                nowNs - lastTapNs >= cfg.minTapGapMs * 1_000_000L -> {
                // micro-correction tap: short press, no state-hold
                lastTapNs = nowNs
                d.action = ControlAction.TAP
                d.tapDurMs = if (cfg.tapDurScaleByErr)
                    (cfg.tapDurMs * (0.6f + 1.2f * ((absErr - db) / (tapB - db + 1e-3f)))).toInt().coerceIn(60, cfg.tapDurMs * 2)
                else cfg.tapDurMs
                d.reason = "tap (+%.3f, band)".format(predErr)
            }
            else -> d.reason = when {
                holdActive -> "hold (min-hold pending release)"
                absErr <= db -> "aligned (deadband)"
                predErr < -db -> "fish left of block → drift only"
                nearLeft -> "at left edge"
                else -> "idle"
            }
        }
        d.holdActive = holdActive
        lastTsNs = nowNs
        return d
    }

    private var catchUpStartNs = 0L
}
