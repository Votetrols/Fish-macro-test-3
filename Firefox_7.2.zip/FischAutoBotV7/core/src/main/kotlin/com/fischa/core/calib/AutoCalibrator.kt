package com.fischa.core.calib

import com.fischa.core.common.NormRegion
import com.fischa.core.config.AppConfig
import com.fischa.core.vision.CoarseScanner
import com.fischa.core.vision.VisionFrame
import kotlin.math.max
import kotlin.math.min

/**
 * V7 §1 — AUTO_CALIBRATION.
 *
 * Runs for the first frames of a session (and cheaply, later, on demand) and measures **everything
 * the detector would otherwise have to be told by a human**:
 *
 *  - screen width/height, density/scale, orientation and the useful application area (from the
 *    platform facts the Android layer publishes);
 *  - the pipeline FPS actually achieved on this device;
 *  - the scene's noise floor (gray std-dev of the coarse map) → contrast tolerance;
 *  - the size of the elements that are actually being seen → candidate size band;
 *  - a *proportional* estimate of where the rod button can be (right/lower part of the useful
 *    area), refined by the blobs observed while calibrating — an estimate, never a fixed spot;
 *  - the confidence threshold (noise floor + margin) and the temporal confirmation frame count
 *    (derived from the measured FPS, bounded).
 *
 * Everything it produces is relative: no absolute pixel coordinate leaves this class.
 */
class AutoCalibrator(private val v7: AppConfig.RodV7) {

    var samples = 0
        private set
    var done = false
        private set
    var needsScreenInfo = true
        private set

    // platform facts
    private var screenWidth = 0
    private var screenHeight = 0
    private var densityDpi = 0
    private var rotationDeg = 0
    private var appWindowWidth = 0
    private var appWindowHeight = 0
    private var statusBarPx = 0
    private var navBarPx = 0

    // measurements
    private var firstNs = 0L
    private var lastFrameNs = 0L
    private val frameIntervals = ArrayList<Float>(32)
    private var noiseSum = 0.0
    private var noiseCount = 0
    private val radiusSamples = ArrayList<Float>(64)
    private val centerXs = ArrayList<Float>(64)
    private val centerYs = ArrayList<Float>(64)
    private var bestScoreSeen = 0f
    private var fpsSampleSum = 0.0
    private var fpsSampleCount = 0

    fun setScreenInfo(
        screenWidthPx: Int,
        screenHeightPx: Int,
        densityDpi: Int,
        rotationDeg: Int,
        appWindowWidthPx: Int,
        appWindowHeightPx: Int,
        statusBarPx: Int,
        navBarPx: Int,
    ) {
        if (screenWidthPx > 0 && screenHeightPx > 0) {
            screenWidth = screenWidthPx
            screenHeight = screenHeightPx
            needsScreenInfo = false
        }
        this.densityDpi = densityDpi
        this.rotationDeg = rotationDeg
        appWindowWidth = if (appWindowWidthPx > 0) appWindowWidthPx else screenWidth
        appWindowHeight = if (appWindowHeightPx > 0) appWindowHeightPx else screenHeight
        this.statusBarPx = max(0, statusBarPx)
        this.navBarPx = max(0, navBarPx)
    }

    fun reset() {
        samples = 0; done = false
        firstNs = 0L; lastFrameNs = 0L
        frameIntervals.clear(); radiusSamples.clear(); centerXs.clear(); centerYs.clear()
        noiseSum = 0.0; noiseCount = 0; bestScoreSeen = 0f
        fpsSampleSum = 0.0; fpsSampleCount = 0
    }

    /**
     * One observation. Returns the finished [CalibrationConfig] exactly once, when the sampling
     * budget (frames **and** a minimum wall-clock span) is exhausted.
     */
    fun observe(
        frame: VisionFrame,
        scanner: CoarseScanner,
        hits: List<CoarseScanner.Hit>,
        stepPx: Int,
        fps: Float,
        nowNs: Long,
    ): CalibrationConfig? {
        if (done) return null
        if (firstNs == 0L) firstNs = nowNs
        if (lastFrameNs > 0L && nowNs > lastFrameNs) {
            val dt = (nowNs - lastFrameNs) / 1e9f
            if (dt in 1e-4f..0.5f) frameIntervals.add(dt)
        }
        lastFrameNs = nowNs
        samples++

        if (fps.isFinite() && fps > 0.5f) { fpsSampleSum += fps; fpsSampleCount++ }

        val (_, std) = scanner.statistics()
        if (std.isFinite() && std >= 0f) { noiseSum += std; noiseCount++ }

        for (hit in hits) {
            val rPx = hit.r * stepPx
            if (rPx < 2f) continue
            radiusSamples.add(rPx)
            centerXs.add(hit.cx * stepPx / max(1, frame.width))
            centerYs.add(hit.cy * stepPx / max(1, frame.height))
            if (hit.score > bestScoreSeen) bestScoreSeen = hit.score
        }

        // Finishes as soon as the sampling budget is filled (frames), with a wall-clock ceiling so
        // a stalled or very slow stream cannot keep the detector in calibration forever.
        val enoughFrames = samples >= v7.calibrationFrames
        val timeout = nowNs - firstNs >= v7.calibrationMaxMs * 1_000_000L
        if (enoughFrames || (timeout && samples >= 2)) {
            done = true
            return finalize(frame)
        }
        return null
    }

    private fun finalize(frame: VisionFrame): CalibrationConfig {
        val w = frame.width
        val h = frame.height
        val fps = measuredFps()
        val noise = if (noiseCount > 0) (noiseSum / noiseCount).toFloat() else 0f
        val sizeBand = sizeBand(w)
        val search = searchRegion()
        val game = gameRegion()
        val threshold = confidenceThreshold(noise)
        val frames = CalibrationConfig.framesForConfirm(fps, v7.targetConfirmMs)
        val minRing = (0.6f * noise + 4f).coerceIn(4f, 26f)
        return CalibrationConfig(
            screenWidth = if (screenWidth > 0) screenWidth else w,
            screenHeight = if (screenHeight > 0) screenHeight else h,
            scale = w.toFloat() / (if (screenWidth > 0) screenWidth else w),
            gameRegion = game,
            estimatedFps = fps,
            rodSearchRegion = search,
            minCandidateSize = sizeBand.first,
            maxCandidateSize = sizeBand.second,
            confidenceThreshold = threshold,
            temporalConfirmationFrames = frames,
            roiPadding = ((v7.roiScale - 1f) * 0.5f).coerceIn(0.05f, 1.5f),
            rotationDeg = rotationDeg,
            densityDpi = densityDpi,
            processingWidth = w,
            processingHeight = h,
            sceneNoise = noise,
            minRingDelta = minRing,
            samples = samples,
            calibratedAtNs = lastFrameNs,
            searchStepCoarse = v7.wideSearchStepPx,
            targetConfirmMs = v7.targetConfirmMs,
            lostTimeoutMs = v7.lostTimeoutMs,
            retryTimeoutMs = v7.retryTimeoutMs,
        )
    }

    /** median frame interval → FPS (robust against a single hick-up); falls back to the EMA. */
    private fun measuredFps(): Float {
        if (frameIntervals.size >= 3) {
            val sorted = frameIntervals.sorted()
            val median = sorted[sorted.size / 2]
            if (median > 1e-4f) return (1f / median).coerceIn(1f, 144f)
        }
        if (fpsSampleCount > 0) return (fpsSampleSum / fpsSampleCount).toFloat().coerceIn(1f, 144f)
        return 30f
    }

    /** Size band, in radius fractions of the frame width, from the blobs actually observed. */
    private fun sizeBand(frameWidth: Int): Pair<Float, Float> {
        if (radiusSamples.size < 4) return DEFAULT_MIN_SIZE to DEFAULT_MAX_SIZE
        val sorted = radiusSamples.sorted()
        val p20 = sorted[(sorted.size * 0.20f).toInt().coerceIn(0, sorted.size - 1)]
        val p85 = sorted[(sorted.size * 0.85f).toInt().coerceIn(0, sorted.size - 1)]
        var lo = (p20 * 0.72f) / frameWidth
        var hi = (p85 * 1.35f) / frameWidth
        lo = lo.coerceIn(0.018f, 0.12f)
        hi = hi.coerceIn(lo + 0.01f, 0.20f)
        // never shrink the band below the provisional one (the button may simply not be visible yet)
        lo = min(lo, DEFAULT_MIN_SIZE)
        hi = max(hi, DEFAULT_MAX_SIZE)
        return lo to hi
    }

    /**
     * Proportional estimate of the rod-button search region, **refined** (not replaced) by the
     * blobs seen while calibrating. Guaranteed to stay wide: it is an estimate for the search to
     * start from, and the search itself refines it frame by frame.
     */
    private fun searchRegion(): NormRegion {
        val game = gameRegion()
        var region = PROVISIONAL_SEARCH
        val cluster = bestClusterRegion()
        if (cluster != null) {
            val inflated = cluster.inflateRelative(0.35f, 0.35f)
            if (inflated.width * inflated.height >= MIN_SEARCH_AREA) region = inflated
        }
        // always keep the useful area of the estimate and never leave the game region
        val estimate = PROVISIONAL_SEARCH.intersect(game) ?: PROVISIONAL_SEARCH
        region = region.union(estimate).clamp()
        val clamped = region.intersect(game) ?: region
        return if (clamped.width * clamped.height >= MIN_SEARCH_AREA) clamped else estimate
    }

    /** bounding box (normalized) of the strongest blob cluster seen during calibration */
    private fun bestClusterRegion(): NormRegion? {
        if (centerXs.size < 3) return null
        // take the top third of the observed blobs by position agreement with the best radius sample
        var minX = 1f; var minY = 1f; var maxX = 0f; var maxY = 0f
        var used = 0
        for (i in centerXs.indices) {
            val x = centerXs[i]; val y = centerYs[i]
            // V7: the calibration scan covers the whole usable area, so a cluster seen on the left
            // side is a legitimate observation (it is the *scene* telling where the button is).
            if (x < 0f || x > 1f || y < 0f || y > 1f) continue
            minX = min(minX, x); maxX = max(maxX, x)
            minY = min(minY, y); maxY = max(maxY, y)
            used++
        }
        if (used < 3 || maxX <= minX || maxY <= minY) return null
        return NormRegion(minX, minY, maxX, maxY).clamp()
    }

    /** Useful application area (display minus system insets), normalized. */
    private fun gameRegion(): NormRegion {
        val h = if (screenHeight > 0) screenHeight.toFloat() else 1f
        val top = (statusBarPx / h).coerceIn(0f, 0.08f)
        val bottom = (navBarPx / h).coerceIn(0f, 0.08f)
        // when the system reports nothing, keep a small symmetric guard band instead of assuming 0
        val t = if (statusBarPx > 0) top else 0.02f
        val b = if (navBarPx > 0) bottom else 0.02f
        return NormRegion(0f, t, 1f, (1f - b).coerceAtLeast(0.6f))
    }

    /**
     * Adaptive confidence floor. The scene's own noise sets the floor (a noisy night scene needs a
     * stricter threshold than a flat UI), and a very strong calibration sample can relax it a
     * little — bounded on both sides so it never becomes a rubber stamp.
     */
    private fun confidenceThreshold(noise: Float): Float {
        var thr = 0.46f + (noise * 0.0022f)
        if (bestScoreSeen > 0.75f) thr = min(thr, bestScoreSeen * 0.78f)
        return thr.coerceIn(0.42f, 0.70f)
    }

    companion object {
        /** generous proportional estimate: right/lower half of the useful area (spec §1 example) */
        val PROVISIONAL_SEARCH = NormRegion(0.50f, 0.30f, 1.00f, 0.98f)

        const val DEFAULT_MIN_SIZE = 0.030f
        const val DEFAULT_MAX_SIZE = 0.110f

        /** a refined region below this area cannot be trusted → keep the wide estimate */
        const val MIN_SEARCH_AREA = 0.06f
    }
}
