plugins {
    id("org.jetbrains.kotlin.jvm")
}

java {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
    kotlinOptions.jvmTarget = "11"
}

tasks.withType<org.gradle.api.tasks.testing.Test>().configureEach {
    maxHeapSize = "128m"
    maxParallelForks = 1
}

tasks.register<JavaExec>("selfTest") {
    group = "verification"
    description = "Runs the deterministic core self-test harness."
    dependsOn(tasks.named("classes"))
    classpath = sourceSets["main"].runtimeClasspath
    mainClass.set("com.fischa.core.tools.SelfTest")
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}
