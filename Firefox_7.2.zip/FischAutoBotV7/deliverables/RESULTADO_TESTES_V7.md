# RESULTADO DOS TESTES — V7

Data: 07/10/2026 · Ambiente: JDK 17 (Adoptium), Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, Android SDK 35

## 1. Testes unitários do núcleo (`:core:test`)

**136 testes, 0 falhas** (19 classes) — 120 testes da V6 preservados + 16 novos da V7.

### Novos testes da V7 — detecção/tracking (`V7RodFinderTest`, 13)

| Teste | O que prova |
|---|---|
| `findsTheButtonAtAnyPositionAndSizeOnTheFrame` | O botão é **encontrado** em 6 posições/tamanhos diferentes (inclusive fora da estimativa inicial, no lado esquerdo): centro a ≤ 6 px do real e raio dentro de 0.75–1.30× do real. |
| `findsTheButtonOnOtherFrameResolutionsAndScales` | Funciona em 640×288, 960×540 e 480×216, com botões de tamanhos diferentes — nada é absoluto. |
| `walksTheSpecifiedStateSequenceAndNeverConfirmsOnASingleFrame` | Sequência `AUTO_CALIBRATION → SEARCHING_ROD → CANDIDATE_FOUND → CONFIRMING_ROD → ROD_CONFIRMED → TRACKING_ROD`; um único frame **nunca** confirma; há ≥ 2 frames entre candidato e confirmado. |
| `confidenceRampsUpAcrossConfirmationAndStaysAboveTheThreshold` | A confiança cresce monotonicamente durante a confirmação e termina ≥ 0.6; `streak ≥ requiredFrames`; calibração marcada como concluída com região válida. |
| `confirmationFrameCountAdaptsToFpsAndLowFpsStillConfirms` | O nº de frames de confirmação é **função do FPS** (8 fps → 3, 30 fps → 4, 60 fps → 7, igual a `framesForConfirm`), limitado a 3..12; a 8 fps a confirmação **ocorre** (FPS baixo não é falha automática). |
| `roiIsBuiltAroundTheDetectedButtonAndIsMuchSmallerThanTheSearch` | A ROI nasce **em torno do botão detectado**, contém o centro, é < 50 % da região de busca e mede 1.4–3.5× o diâmetro do botão (padding proporcional). |
| `roiFollowsSmallMovementsAndButtonsOfDifferentSizesGetDifferentRois` | Movimento de ~36 px é seguido (centro a ≤ 6 px) e a ROI se desloca; o estado é `TRACKING_ROD`; botão maior ⇒ ROI maior. |
| `trackingDoesNotRescanTheWholeFrameEveryFrame` | Em `TRACKING_ROD` a busca ampla está desligada (`tracking = true`, `searchActive = false`) — só a ROI é varrida. |
| `lossReturnsToSearchingAndReacquiresTheButtonAtItsNewPosition` | Sumindo o botão: `ROD_LOST` → `SEARCHING_ROD` e, com o botão reaparecendo **em outro lugar**, o sistema o **re-encontra** (prova de que a posição é medida, não memorizada). |
| `theEstimateIsNotAnAssumptionBecauseTheSearchWidensItself` | Botão no canto esquerdo (fora da estimativa): a região de busca **se amplia sozinha** (> +0.1 em largura), o log registra a ampliação e o botão é encontrado. |
| `emptyNoisyAndTextScenesAreNeverConfirmed` | Fundo vazio, cena com ruído e prompt de texto branco (falso positivo típico da V6) **nunca** confirmam; o motivo é sempre registrado. |
| `logsStateTheReasonForEveryDecision` | Os logs trazem `[CALIBRATION] screen=…`, `rodSearchRegion=…`, `[ROD_SEARCH] candidates=… bestScore=…`, `no valid candidate`, `[ROD_CONFIRM] frame=n/m`, `[ROD] CONFIRMED`, `[ROD] center=`, `[ROD] roi=`, `[TRACKING] ACTIVE`, `BUTTON_MOVED`, `[ROD_LOST]`/`WIDE SEARCH`. |
| `repeatedFailuresRaiseTheRequirementInsteadOfCrashingOrConfirming` | Padrões instáveis (aparece/some antes de confirmar) **não** confirmam; depois disso o detector volta a confirmar um botão estável, com exigência dentro de 3..12 frames (sem "endurecer até travar"). |

### Novos testes da V7 — trava de input (`V7RealInputLockTest`, 3)

| Teste | O que prova |
|---|---|
| `detectionWorksEndToEndWhileRealInputStaysDisabled` | Pela `VisionPipeline` real: com o botão visível, macro armado e `realInputEnabled = true`, a detecção chega a `ROD_CONFIRMED`/`TRACKING_ROD` e, ainda assim, `layerInput = DISABLED`, `realInputLocked = true`, `VISION/DETECTION/DECISION = ACTIVE`, **zero** chamadas ao executor e **nenhum `UNLOCK` novo** no histórico. |
| `rodsDisappearingAndReappearingNeverUnlocksInput` | Ciclo detectar → perder → reencontrar: continua bloqueado, sem gestos, sem unlock. |
| `debugModelExposesTheDetectionVisualDataNormalized` | O `RenderModel` (fonte do overlay) publica estado/score/streak/ROI/busca/centro **normalizados (0..1)**; a caixa do candidato cai sobre o botão desenhado (≤ 8 px) e `layerInput = DISABLED`. |

### Testes da V6 preservados

As 19 classes originais continuam rodando (captura, consentimento, separação captura/input, estados, FSM, tracker, config, controlador, segurança, `StartSemanticsV5Test`...). Duas mudanças **apenas de teste** foram necessárias:

* `CaptureInputSeparationTest` e `StartSemanticsV5Test` exercitam o caminho **desbloqueado** da cadeia de input (V5/V6): agora fazem `RealInputPolicy.unlockForTesting()` no `@Before` e `lock()` no `@After`. A trava em si é coberta pelos testes V7 acima — a política **não** foi enfraquecida.
* No `StartSemanticsV5Test.lowRodConfidenceMeansZeroInput`, o limiar artificial passou de `0.95` para `0.995`: o detector V7 atinge confiança natural alta (0.97) numa cena limpa, então o limiar precisa ficar acima dela para testar o **gate** (que é o mesmo de antes).

## 2. SelfTest do núcleo (`:core:selfTest`)

```
== SelfTest: 138 checks, 0 failures ==
```

Mesmo número da V6 (138/0) — nenhuma regressão de comportamento.

## 3. Build do APK

```
> Task :app:assembleDebug
BUILD SUCCESSFUL in 1m 32s
39 actionable tasks: 39 executed
```

APK: `deliverables/FischAutoBotV7-debug.apk` (3.6 MB). Log completo: `build_v7.log`.

## 4. Cobertura de cenários (cena sintética `RodSceneFixture`)

| Eixo | Cenários testados |
|---|---|
| Posição | (120,80), (200,140), (330,230), (450,120), (520,199), (598,74), (70,200), (180,120) |
| Tamanho do botão | raio interno 22 / 26 / 30 / 34 / 38 / 46 px (anel 30…60 px) |
| Resolução | 640×288, 960×540, 480×216 |
| FPS | 8, 30, 60 |
| Cenas ruins | fundo uniforme, ruído σ=14, prompt com texto branco |
| Movimento | +36 px, +60 px e reaparecimento em outra região |
