# RELATÓRIO DE BUILD — V7

## Ambiente

| Item | Versão / caminho |
|---|---|
| JDK | Adoptium 17 (`/var/tmp/tools/jdk17`) — exigido pelo AGP 8.7.3 |
| Gradle | wrapper 8.9 (`./gradlew`) |
| Android Gradle Plugin | 8.7.3 · Kotlin 2.0.21 |
| Android SDK | platforms;android-35, build-tools;35.0.0 |
| Módulos | `:core` (Kotlin/JVM) e `:app` (Android) |

## Comando

```bash
export JAVA_HOME=/var/tmp/tools/jdk17
export ANDROID_HOME=/var/tmp/tools/android-sdk
./gradlew --no-daemon --console=plain clean :core:test :core:selfTest :app:assembleDebug
```

## Resultado

```
> Task :core:test
> Task :core:selfTest
== SelfTest: 138 checks, 0 failures ==
> Task :app:assembleDebug
BUILD SUCCESSFUL in 1m 32s
39 actionable tasks: 39 executed
```

* Testes do núcleo: **136 testes, 0 falhas** (120 da V6 + 16 da V7).
* SelfTest: **138 checagens, 0 falhas** (igual à V6).
* APK gerado: `app/build/outputs/apk/debug/app-debug.apk` → copiado para `deliverables/FischAutoBotV7-debug.apk` (3,6 MB).
* Log completo desta execução: `build_v7.log`.

## Avisos do compilador (não bloqueantes)

* `VisionFrame.kt`: avisos de `inline` (herdados da V6).
* `GameAccessibilityService.kt`: `Bitmap.recycle()` deprecado (herdado da V6).

Nenhum erro de compilação; nenhum aviso novo introduzido pela V7 nos módulos de detecção.
