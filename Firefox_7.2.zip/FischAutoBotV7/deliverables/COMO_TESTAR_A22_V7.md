# COMO TESTAR A V7 (Galaxy A22)

> **Regra da V7:** o objetivo deste teste é **ver** o sistema encontrando o botão da vara.
> `REAL_INPUT` permanece **DISABLED** — nenhum toque real acontece, e não existe auto-desbloqueio.

## 0. Antes de começar

* Use o APK `FischAutoBotV7-debug.apk`.
* Mantenha o app da V6 instalado ou desinstale antes (mesmo `applicationId`): `adb install -r FischAutoBotV7-debug.apk`.
* O procedimento de captura (a) **serviço de acessibilidade** e (b) **MediaProjection** é o mesmo da V6 — veja `docs/COMO_TESTAR_A22_V6.md` e `docs/DIAGNOSTICO_MEDIAPROJECTION_V6.md` se a captura não iniciar.

## 1. Teste obrigatório (visual) — checklist

Abra o Roblox/Fisch com o **botão da vara visível**, toque em **START** e marque cada passo:

| # | O que fazer | O que deve aparecer |
|---|---|---|
| 1 | START | `STATE=AUTO_CALIBRATION` por poucos frames; log `[CALIBRATION] screen=… scale=… fps=… rodSearchRegion=(…)` |
| 2 | esperar | `STATE=SEARCHING_ROD SEARCH=ACTIVE`, caixa **amarela** = região de busca (proporcional à tela, não um ponto) |
| 3 | botão visível | `CANDIDATE=FOUND` com a caixa **laranja** **em cima do botão da vara** (confira com o olho!) |
| 4 | esperar ~0,5 s | `ROD_CONFIDENCE` subindo (0.6 → 0.8 → 0.95) e `CONFIRM=n/m` crescendo |
| 5 | confirmar | `STATE=ROD_CONFIRMED` (caixa **verde**) e a **ROI ciano** desenhada em volta do botão |
| 6 | esperar 1 s | `STATE=TRACKING_ROD` (caixa **ciano**) — `TRACKING=ACTIVE` |
| 7 | mover levemente a câmera/personagem | a caixa (e a ROI) **acompanham** o botão; log `[TRACKING] BUTTON_MOVED … → ROI atualizada` |
| 8 | tapar o botão com a mão / trocar de tela | `STATE=ROD_LOST` → `LOCAL_RETRY` (caixa **vermelha**) → `STATE=SEARCHING_ROD` |
| 9 | destapar o botão | volta sozinho para `CANDIDATE_FOUND → ROD_CONFIRMED → TRACKING_ROD` em **outra** posição se ele estiver em outro lugar |
| 10 | olhar a linha de camadas | `VISION=ACTIVE DETECTION=ACTIVE DECISION=ACTIVE REAL_INPUT=DISABLED` em **todos** os passos |
| 11 | conferir o executor | nenhum toque/gesto real é executado em momento algum |

Se em qualquer passo a caixa ficar parada em um ponto que **não** é o botão, esse é exatamente o problema que a V7 corrige — anote o estado mostrado (`STATE=…`) e a linha `CAND: (x,y,r)=score`.

## 2. O que observar no log

```
[CALIBRATION] screen=1600x720 scale=0.400 rot=0 dpi=280
[CALIBRATION] fps=30.1
[CALIBRATION] rodSearchRegion=(0.500,0.300,1.000,0.980) (estimativa inicial, não coordenada fixa)
[CALIBRATION] minCandidateSize=0.030W maxCandidateSize=0.110W confidenceThreshold=0.62
[CALIBRATION] temporalConfirmationFrames=4 (≈120ms @ 30.1fps)
[ROD_SEARCH] candidates=3 bestScore=0.81
[ROD_CONFIRM] frame=2/4 confidence=0.71 thr=0.62 (2/4)
[ROD] CONFIRMED
[ROD] center=(872,332) r=52.0 score=0.87
[ROD] roi=(712,272,264,264) (norm=(0.712,0.455,0.877,0.820))
[TRACKING] ACTIVE (local search, ROI dinâmica)
```

Em falha, o motivo aparece explícito:

```
[ROD_SEARCH] candidates=0 no valid candidate
[ROD_CONFIRM] confidence too low confidence=0.44 threshold=0.62 (2/4)
[TRACKING] LOST (335ms sem detecção) → LOCAL_RETRY
[ROD_SEARCH] local retry failed after 705ms → WIDE SEARCH (search=(…))
[STATE] SEARCHING_ROD
```

## 3. FPS baixo

Em FPS baixo (Roblox fora de foco, aparelho quente) o sistema **não falha**: ele reduz o número de frames de confirmação (até o mínimo de 3) e mantém os mesmos critérios de tempo. Se o overlay mostrar 4–10 FPS, a confirmação apenas demora um pouco mais.

## 4. Se o botão não for encontrado

1. Verifique se o botão está **visível** na tela durante a busca (a busca não lê o que não existe).
2. Confira `[CALIBRATION] rodSearchRegion=…` e, depois de ~0.6 s de busca, se aparece `[ROD_SEARCH] estimativa sem candidato por …ms → região ampliada …` (a busca se amplia sozinha para quase toda a área útil).
3. Se `candidates=0` com o botão visível, o contraste pode estar fora da faixa: anote `minRingDelta` da calibração e o brilho do botão (a calibração mede o ruído da cena e ajusta o limiar; o `AppConfig` permite ajuste fino em `rodV7` se necessário).
4. Se aparecer candidato mas `confidence too low`, olhe `CAND: (x,y,r)=score` — o score decomposto ajuda a identificar qual atributo está baixo (forma/tamanho/contraste/posição/temporal/identidade).
