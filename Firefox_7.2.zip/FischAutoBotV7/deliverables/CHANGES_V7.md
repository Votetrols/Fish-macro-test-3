# CHANGES V7 — detecção automática + localização robusta do botão da vara

Base: V6 (`firefox_v6.zip`, commit 3c3a3da). Compatibilidade: HUD, logs, estados, FSM, captura,
config, FPS e o sistema de segurança da V6 foram **preservados**; só o que a V7 exige mudou.

## O que mudou de comportamento

1. **O botão da vara não é mais procurado em coordenada fixa.** A antiga ROI/quadrado vermelho fixo
   saiu do fluxo do pipeline (`FishingButtonDetector` continua no repositório, coberto pelo selfTest,
   mas não é mais usado pela detecção do botão).
2. **Auto-calibração** (`AUTO_CALIBRATION`) mede tela/escala/orientação/área útil, FPS real, ruído da
   cena, tamanho dos elementos vistos e a região provável do botão. Todos os valores são **relativos**
   (`NormRegion` 0..1); a estimativa é só um ponto de partida.
3. **Detecção em 4 fases**: busca ampla proporcional (só quando necessário) → geração de candidatos
   (forma, tamanho, contraste, bordas, região ocupada, posição, persistência, identidade) →
   `candidateScore` ponderado e calibrável → confirmação temporal com nº de frames **derivado do FPS**.
4. **ROI dinâmica** em torno do botão detectado (`detectedBounds × 1.5` + padding proporcional).
5. **Tracking local** (varredura fina dentro da ROI, sem reprocessar a tela inteira) com atualização da
   ROI quando o botão se move e caminho de recuperação `ROD_LOST → LOCAL_RETRY → SEARCHING_ROD`.
6. **Auto-ajuste gradual** dos pesos/limiar/tolerâncias (modelo adaptativo) — nunca agressivo, sempre
   limitado por cooldown.
7. **Debug visual** substitui o quadrado vermelho: caixa do candidato colorida por estado (SEARCH /
   CANDIDATE / CONFIRMED / TRACKING / LOST), região de busca, ROI, cruz no centro do botão e linha
   `STATE=… FPS=… SEARCH=… CANDIDATE=… ROD_CONFIDENCE=… ROI=(x,y,w,h) TRACKING=…` +
   `VISION=… DETECTION=… DECISION=… REAL_INPUT=DISABLED`.
8. **Logs com motivo**: `[ROD_SEARCH] candidates=… bestScore=…`, `no valid candidate`,
   `[ROD_CONFIRM] frame=n/m confidence=… thr=…`, `[ROD] CONFIRMED/center/roi`, `[TRACKING] ACTIVE`,
   `BUTTON_MOVED`, `LOST`, `local retry failed → WIDE SEARCH`, `[STATE] SEARCHING_ROD`.
9. **`REAL_INPUT` bloqueado** por política de sessão (`RealInputPolicy`): aplicado no pipeline antes de
   qualquer decisão, sem auto-unlock, interruptor da UI desabilitado e coberto por testes.

## Arquivos

Novos: `common/NormRegion.kt`, `calib/{CalibrationConfig,AutoCalibrator,RodAdaptiveModel}.kt`,
`vision/{CoarseScanner,RodCandidate,RodFinder}.kt`, `safety/RealInputPolicy.kt`,
`core/src/test/.../v7/{RodSceneFixture,V7RodFinderTest,V7RealInputLockTest}.kt`.

Modificados: `pipeline/VisionPipeline.kt`, `pipeline/PipelineEvent.kt`, `config/AppConfig.kt`
(`rodV7`), `debug/RenderModel.kt`, `log/GameLog.kt` (tags), `app/DebugOverlay.kt`,
`app/FischEngineService.kt`, `app/MainActivity.kt`, `core/src/test/.../capture/CaptureInputSeparationTest.kt`
e `core/src/test/.../pipeline/StartSemanticsV5Test.kt` (apenas a política de teste da trava).

Detalhamento completo: `ENTREGA_V7.md` (seção 1).

## Configuração

Bloco `rodV7` no `AppConfig` (todos com default): `weights`, `maxRefinedCandidates`,
`wideSearchStepPx`, `localSearchStepPx`, `wideCenterStride`, `localCenterStride`, `interiorMaxGray`,
`driftToleranceFactor/Min`, `confirmWindowMs`, `roiScale`, `localSearchMarginFactor`,
`lostTimeoutMs`, `retryTimeoutMs`, `calibrationFrames/MaxMs`, `recalibrationIntervalMs`,
`targetConfirmMs`, `adaptTauSec`, `adaptiveTuning`, `adaptCooldownMs`, `wideExpandAfterMs`.

Nenhum campo antigo foi removido/reordenado; config V6 continua válida.
