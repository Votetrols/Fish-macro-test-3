# ENTREGA V7 — Detecção automática e localização robusta do botão da vara

**Projeto:** FischAutoBot (base V6 → V7)
**Data:** 07/10/2026
**Artefatos:** `FischAutoBotV7-debug.apk`, `FischAutoBotV7-clean.zip` (fonte completa), documentação em `deliverables/` e `docs/`.

> **Resumo:** a V7 resolve os dois problemas da V6 —
> **(1)** os parâmetros de detecção/calibração passaram a ser **medidos automaticamente** em tempo de execução;
> **(2)** o botão da vara deixou de ser procurado em uma **coordenada fixa**: ele é **encontrado** pelo sistema
> (busca ampla → candidatos → score ponderado → confirmação temporal) e a **ROI é criada dinamicamente em torno
> do botão detectado**, com o rastreamento local acompanhando o movimento.
> **`REAL_INPUT` permanece `DISABLED` durante todo o ciclo V7 — não existe auto-desbloqueio.**

---

## 1) Arquivos modificados

### Novos (núcleo da V7)

| Arquivo | Papel |
|---|---|
| `core/src/main/kotlin/com/fischa/core/common/NormRegion.kt` | Todas as regiões (busca, ROI, padding) em **coordenadas relativas 0..1**; conversão para pixels acontece só no ponto de uso. |
| `core/src/main/kotlin/com/fischa/core/calib/CalibrationConfig.kt` | Contrato do que a calibração mede (tela, escala, área útil, FPS, região estimada, faixa de tamanho, limiar, frames de confirmação, padding) + `framesForConfirm()` (FPS → frames). |
| `core/src/main/kotlin/com/fischa/core/calib/AutoCalibrator.kt` | Estágio `AUTO_CALIBRATION`: mede resolução/densidade/orientação/área útil, FPS real, ruído da cena, tamanho dos elementos vistos e a **região provável** do botão (estimativa refinada pelo que a câmera realmente vê). |
| `core/src/main/kotlin/com/fischa/core/calib/RodAdaptiveModel.kt` | Auto-ajuste **gradual** (limiar, frames de confirmação, tolerâncias) durante o rastreamento e em caso de falso positivo. |
| `core/src/main/kotlin/com/fischa/core/vision/CoarseScanner.kt` | Varredura grossa **somente da sub-região pedida** (origem + passo), com mapa de média 2×2 — base do baixo custo da busca ampla. |
| `core/src/main/kotlin/com/fischa/core/vision/RodCandidate.kt` | Candidato + `RodScorer` (score ponderado: forma, tamanho, contraste, posição, temporal, identidade) + `RodDetectionState`. |
| `core/src/main/kotlin/com/fischa/core/vision/RodFinder.kt` | Máquina de estados completa: busca ampla proporcional → candidatos → score → confirmação temporal adaptativa → ROI dinâmica → rastreamento local → perda/recuperação. |
| `core/src/main/kotlin/com/fischa/core/safety/RealInputPolicy.kt` | Trava de sessão do `REAL_INPUT` (padrão travada, **sem auto-unlock**, com histórico auditável). |
| `core/src/test/kotlin/com/fischa/core/v7/RodSceneFixture.kt` | Cena sintética de teste: desenha o botão em **qualquer posição, tamanho e resolução**, com opções de ruído e de texto branco (falso positivo típico). |
| `core/src/test/kotlin/com/fischa/core/v7/V7RodFinderTest.kt` | 13 testes da detecção/tracking/ROI/confirmação/logs. |
| `core/src/test/kotlin/com/fischa/core/v7/V7RealInputLockTest.kt` | 3 testes ponta-a-ponta provando que `REAL_INPUT` continua bloqueado mesmo com a detecção funcionando. |

### Modificados (o mínimo necessário)

| Arquivo | O que mudou |
|---|---|
| `core/.../pipeline/VisionPipeline.kt` | Passou a usar o `RodFinder` (a ROI fixa da V6 foi removida do fluxo), publica `rodState/rodScore/rodCandidates/rodStreak/rodRequiredFrames/rodTracking/rodRoiNorm/rodSearchNorm/rodCenterNorm/rodCalibration...` e as camadas `VISION/DETECTION/DECISION/INPUT`; aplica a trava do `REAL_INPUT` **antes** de qualquer decisão. |
| `core/.../pipeline/PipelineEvent.kt` | Campos V7 **acrescentados no fim** (com default) de `PipelineInput` (geometria da tela) e `PipelineOutput` (estado/ROI/score/camadas) — nada reordenado, compatibilidade binária com a V6 preservada. |
| `core/.../config/AppConfig.kt` | Novo bloco `rodV7`: pesos do score, passos de busca, tolerâncias, timeouts por **tempo** (não por frames), `calibrationFrames`, `targetConfirmMs`, `wideExpandAfterMs`, ajuste adaptativo. Todos com default — config V6 continua válida. |
| `core/.../debug/RenderModel.kt` | Campos para o overlay: estado, score, streak exigido, ROI, região de busca, centro normalizado, candidatos, calibração, camadas. |
| `core/.../log/GameLog.kt` | Tags `CALIBRATION`, `ROD_SEARCH`, `ROD_CONFIRM`, `ROD`, `ROD_FINDER`, `TRACKING`. |
| `app/.../DebugOverlay.kt` | **A caixa vermelha fixa foi substituída** pelas caixas do candidato/ROI/busca, coloridas por estado, com a linha `STATE=… FPS=… SEARCH=… CANDIDATE=… ROD_CONFIDENCE=… ROI=(x,y,w,h) TRACKING=…` e `VISION=… DETECTION=… DECISION=… REAL_INPUT=DISABLED`. |
| `app/.../FischEngineService.kt` | Envia a geometria real da tela para a calibração, espelha os dados V7 no overlay e nos logs (`REAL_INPUT` continua bloqueado no caminho de input real). |
| `app/.../MainActivity.kt` | Interruptor de `REAL_INPUT` desabilitado/rotulado como bloqueado na validação V7. |
| `core/src/test/.../capture/CaptureInputSeparationTest.kt`, `core/src/test/.../pipeline/StartSemanticsV5Test.kt` | Testes legados da cadeia de input (V5/V6) que verificam o caminho **desbloqueado**: fazem `unlockForTesting()/@After lock()`. No `StartSemanticsV5Test`, o limiar artificial do teste de gate subiu de `0.95` para `0.995` (o detector V7 atinge confiança natural mais alta; o *gate* testado é o mesmo). |

**Preservados sem alteração:** HUD/logs/estados da V6, `ShakeDetector`, `DetectorBase`, `InputSafetyGuard`, `EmergencyStop`, detecção de FPS, `FishingStateMachine`, `FishingButtonDetector`/`RodConfirmTracker` (legado, ainda no repositório e coberto pelo selfTest), config existente e integração com o app.

---

## 2) Parâmetros que se tornaram automáticos

| Parâmetro | V6 | V7 |
|---|---|---|
| Resolução, densidade, orientação, área útil | assumidos | **medidos** (MediaProjection + geometria do app + insets) |
| Região onde procurar o botão | ROI/coordenada fixa | **estimativa proporcional medida** na calibração (posição dos blobs vistos) ∪ faixa de fallback |
| Tamanho do botão (raio mín./máx.) | fixo | **medido** dos blobs vistos (p20…p85 do raio, em fração da **largura** da imagem) |
| Limiar de confiança | fixo | ruído da cena + margem, **reajustado** pelo modelo adaptativo |
| Nº de frames para confirmar | 3 fixo | **derivado do FPS medido** (`targetConfirmMs = 120 ms`, limitado a 3..12 frames) |
| ROI depois de confirmar | fixa | **botão detectado × 1.5** + padding proporcional (sem dimensão absoluta) |
| Tolerância de deriva do centro | fixa | proporcional ao raio (`max(0.020, 0.8·raio)`) |
| Timeout de perda / retry | fixo | **em tempo real (ms)** — 320 ms de perda, 700 ms de retry — independente do FPS |
| Pesos do `candidateScore` | fixos | calibráveis (`AppConfig.RodV7.weights`) e **auto-ajustados gradualmente** |
| FPS | assumido | **medido** (intervalo mediano + EMA) e usado na confirmação, no tracking e nos timeouts |

O `AppConfig` continua com valores-padrão sensatos: eles são **estimativa inicial**, não a posição assumida do botão.

---

## 3) Como o detector encontra o botão (não há coordenada fixa)

**FASE A — busca ampla proporcional.** A calibração devolve uma região *estimada* (`rodSearchRegion`). A cada frame em `SEARCHING_ROD` a varredura usa `CoarseScanner` com passo grosso (`wideSearchStepPx = 4`, salto de centros), construindo o mapa de médias **apenas da sub-região** pedida. Se a estimativa não produz candidato por `wideExpandAfterMs = 600 ms`, a busca **se amplia sozinha** para a faixa proporcional de fallback (quase toda a área útil) — uma estimativa ruim nunca prende a busca: `[ROD_SEARCH] estimativa sem candidato por 623ms → região ampliada …`.

**FASE B — candidatos (nunca um único atributo).** Para cada ponto grosso aceito:
1. `measureBlob()` mede o **disco escuro** com limiar adaptativo (amostras internas em anel + fundo pelos cantos da janela), valida forma de disco (bbox, preenchimento ≥ 0.45, simetria) e devolve o **centro e o raio reais** do blob — o candidato passa a ser ancorado no blob, não na célula grossa;
2. o `DiscMatcher` verifica o **anel** em resolução cheia ao redor do blob e mede o raio externo do botão;
3. mede os demais atributos: roundness/fill (forma), `ringDelta` (contraste), `glyphFrac` (glifo cinza do hook), `whiteFrac` (texto branco = prompt "SHAKE"), persistência temporal, distância da estimativa.

Candidatos que caem no mesmo botão são **agrupados** (centroide ponderado pelo score) — evita o "pulo" da caixa entre duas detecções quase idênticas.

**FASE C — score ponderado.** `candidateScore = w_shape·shape + w_size·size + w_contrast·contraste + w_position·posição + w_temporal·persistência + w_identity·identidade`, com `w_*` calibráveis e auto-ajustados. `size` dá crédito **total** dentro da faixa medida e só decai fora dela; texto branco no interior do disco aplica um **veto gradual** (o prompt "SHAKE" não é o botão da vara). Vence o maior score; o vencedor precisa passar do **piso de viabilidade** e depois do **limiar de confiança**.

**FASE D — confirmação temporal** (seção 5).

**Resultado medido** (cena sintética 640×288, botão em (520,199), anel r=40): a partir do frame 4 →
`CANDIDATE_FOUND (521,199,r40)=0.79 conf=0.63` → `CONFIRMING_ROD 0.71…0.98` → `ROD_CONFIRMED (521,197,r39.5) conf=0.975`,
`ROI=(0.722,0.480,0.907,0.891)` — ou seja, centro a ~2 px do real e raio ~1 px do real, com score `sh=0.94 sz=1.00 ct=1.00 po=0.90 tm=1.00 id=1.00`.

---

## 4) Como o tracking funciona

```
INIT → AUTO_CALIBRATION → SEARCHING_ROD → CANDIDATE_FOUND → CONFIRMING_ROD → ROD_CONFIRMED → TRACKING_ROD
                                                     ↑                                              │
                                          SEARCHING_ROD ← LOCAL_RETRY ← ROD_LOST ←──────────────────┘
```

* **Depois de confirmado**, a busca ampla é **desligada**: cada frame varre só a **ROI dinâmica** (`detectedButtonBounds × 1.5` + margem proporcional, passo fino `localSearchStepPx = 2`) — sem processar a tela inteira (§11).
* Se o botão **se move**, o centro é atualizado, a ROI é reconstruída e o log registra `[TRACKING] BUTTON_MOVED d=(+0.056,+0.023) → ROI atualizada`.
* Se o botão **desaparece**: contagem por **tempo** (não por frames) → `TRACKING_ROD → ROD_LOST` (320 ms) → `LOCAL_RETRY` (700 ms, olhando um pouco além da ROI) → `SEARCHING_ROD` (busca ampla) → reencontra e reconfirma **sozinho**. Todo o caminho é registrado com motivo (`[TRACKING] miss 132ms/320ms …`, `[TRACKING] LOST (335ms sem detecção) → LOCAL_RETRY`, `[ROD_SEARCH] local retry failed after 705ms → WIDE SEARCH`).
* Um candidato **fraco nunca é tratado como confirmado**: `confirmed` só liga quando o streak temporal e o limiar de confiança passam; ao perder, o streak zera e o estado volta para `SEARCHING_ROD`.
* Cada novo ciclo de pesca (voltar para `WAITING_FOR_ROD`) exige **reconfirmação fresca** — a trava continua, mas a confiança é reconquistada (`[ROD_CONFIRM] re-confirmação concluída (4/4) → ROD_CONFIRMED`).

---

## 5) Como a confirmação temporal funciona

1. O primeiro frame com candidato aceito inicia um **streak ancorado** na posição medida; o número de frames exigidos vem do **FPS medido**:
   `frames = round(targetConfirmMs/1000 · fps)`, limitado a 3..12 (ex.: 8 fps → 3; 30 fps → 4; 60 fps → 7). Não existe "3 frames" fixo.
2. A cada frame seguinte a verificação roda **só na vizinhança da âncora** (não na tela toda) e o streak cresce se o centro se mantém dentro de `max(0.020, 0.8·raio)`; um salto de posição **reinicia** o streak (`[ROD_CONFIRM] center unstable drift=0.041 > tol=0.031 → streak reiniciado`).
3. A **confiança** combina a evidência do frame com a evidência temporal: `conf = score · (0.72 + 0.28·streak/exigido)`; abaixo do limiar efetivo o estado permanece `CONFIRMING_ROD` com motivo explícito (`[ROD_CONFIRM] confidence too low confidence=0.44 threshold=0.55 (2/4)`).
4. O streak inteiro deve caber em `confirmWindowMs = 1500 ms` — em FPS baixo ele é mais curto em frames, mas continua sendo confirmação **temporal**; FPS baixo **não** é falha automática (o processamento se adapta: menos frames, mesmos critérios).
5. Só com `streak ≥ exigido` **e** `conf ≥ limiar` o estado vira `ROD_CONFIRMED` → `TRACKING_ROD`.

---

## 6) Como testar a V7 (validação visual, antes de qualquer outra coisa)

1. Instale `FischAutoBotV7-debug.apk` no A22 (`adb install -r FischAutoBotV7-debug.apk`).
2. Habilite o **serviço de acessibilidade** do app e conceda a captura de tela (MediaProjection) — igual à V6 (`docs/COMO_TESTAR_A22_V6.md`).
3. Abra o Roblox/Fisch com o **botão da vara visível** e toque em **START** no app.
4. Observe o overlay (a linha colorida + as caixas). Sequência esperada:
   1. `STATE=AUTO_CALIBRATION` (poucos frames) e no log `[CALIBRATION] screen=… scale=… fps=… rodSearchRegion=(…)`;
   2. `STATE=SEARCHING_ROD SEARCH=ACTIVE` com a caixa **amarela** = região de busca (proporcional, não um ponto);
   3. ao achar: `CANDIDATE=FOUND` com caixa **laranja** exatamente **sobre o botão da vara** (confira com o olho: ela deve acompanhar o botão, não ficar num canto fixo);
   4. `ROD_CONFIDENCE` subindo (0.6 → 0.8 → 0.95) com `CONFIRM=n/m`;
   5. `STATE=ROD_CONFIRMED` (caixa **verde**) e a **ROI ciano** aparecendo em volta do botão;
   6. `STATE=TRACKING_ROD` (caixa **ciano**) seguindo o botão quando ele se move (gire/mova a câmera levemente);
   7. **tampe o botão ou troque de tela**: deve aparecer `ROD_LOST`/`LOCAL_RETRY` (caixa **vermelha**) e voltar para `SEARCHING_ROD`, reencontrando sozinho;
   8. em **nenhum** momento a linha `VISION=ACTIVE DETECTION=ACTIVE DECISION=ACTIVE REAL_INPUT=DISABLED` pode mudar — e **nenhum toque real** deve acontecer.
5. Logs de referência (esperados): `[ROD_SEARCH] candidates=4 bestScore=0.81`, `[ROD_CONFIRM] frame=2/4 …`, `[ROD] CONFIRMED`, `[ROD] center=… r=…`, `[ROD] roi=…`, `[TRACKING] ACTIVE`; em falha: `[ROD_SEARCH] candidates=0 no valid candidate`, `[ROD_CONFIRM] confidence too low …`, `[STATE] SEARCHING_ROD` — **sempre com o motivo**, nunca só `confirmed=false`.
6. Só depois da validação visual o `REAL_INPUT` poderá ser considerado em uma etapa futura — **nesta entrega ele continua bloqueado por decisão de projeto**.

---

## 7) Confirmação: `REAL_INPUT` continua bloqueado

* `RealInputPolicy` nasce **travada** e o pipeline aplica a trava **antes** de qualquer decisão: `safety.realInputEnabled = input.realInputEnabled && RealInputPolicy.allows()`.
* **Não existe auto-unlock**: nenhum caminho de detecção/confirmação/tracking/calibração chama `unlockForTesting()`; a única chamada existe para os testes legados da cadeia de input (V5/V6) e é auditada.
* O overlay e os logs sempre imprimem `REAL_INPUT=DISABLED` (camadas `VISION/DETECTION/DECISION` seguem `ACTIVE`).
* O interruptor de `REAL_INPUT` na UI está desabilitado.
* **Provas em teste:** `V7RealInputLockTest` (3 testes) alimenta o pipeline com o botão visível, macro armado, `realInputEnabled = true` e verifica: detecção chega a `ROD_CONFIRMED`/`TRACKING_ROD`, **zero** chamadas ao executor, `layerInput = DISABLED`, e **nenhum `UNLOCK` novo** no histórico da política — inclusive no ciclo detecta → perde → reencontra. O `StartSemanticsV5Test` continua cobrindo a cadeia de input (com a trava liberada apenas dentro do teste).

---

## Testes e build (resumo)

| Verificação | Resultado |
|---|---|
| `:core:test` (unitários, JVM) | **136 testes, 0 falhas** (120 da V6 preservados + 16 novos da V7) |
| `:core:selfTest` (checagens internas) | **138 checagens, 0 falhas** |
| `:app:assembleDebug` (APK) | **SUCCESS** → `FischAutoBotV7-debug.apk` (3,6 MB) |
| Log completo | `build_v7.log` / `docs/RELATORIO_BUILD_V7.md` |

Detalhamento: `docs/RESULTADO_TESTES_V7.md`.

## O que a V7 **não** faz (limites conhecidos)

* Não executa toques reais: toda a validação é visual, por decisão explícita do projeto.
* A validação em dispositivo real (A22 + Fisch) **ainda depende do seu teste visual** — os testes cobrem cenas sintéticas em 4 posições/tamanhos, 3 resoluções (640×288, 960×540, 480×216) e 3 FPS (8/30/60).
* O prompt "SHAKE" com texto branco é rejeitado por veto gradual de `whiteFrac`; se o ícone do seu botão tiver partes brancas grandes, o limiar pode precisar de ajuste fino (o modelo adaptativo reage a falsos positivos).
