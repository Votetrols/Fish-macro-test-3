package com.fischa.app

import android.content.Context
import android.content.Intent
import android.os.SystemClock

/**
 * V6 spec §3/§5 — handoff of the screen-capture **consent** (resultCode + the Intent returned by
 * `createScreenCaptureIntent()`), not of a MediaProjection object.
 *
 * Why this replaces the V5 `ProjectionHolder`:
 *  - V5 created the MediaProjection inside the Activity and handed the *object* to the service.
 *    Since Android 10 (documented for API 34+), `MediaProjectionManager.getMediaProjection()` may
 *    only be called while a foreground service with type `mediaProjection` is already running, so
 *    the Activity call threw `SecurityException` — which V5 swallowed into the generic
 *    "MediaProjection indisponível — tente novamente".
 *  - V6 starts the foreground service first and calls `getMediaProjection()` there, from the single
 *    component that owns the capture lifecycle (deterministic, one projection instance).
 *
 * The consent Intent is passed through the service-start Intent extras (primary path). This holder
 * exists as a fallback for ROMs that strip nested binder extras, and it is always cleared on
 * teardown so a stale token can never be reused for a later session.
 */
object CaptureConsentHolder {
    /** Consent tokens are only valid for a very short window; older than this is refused. */
    const val MAX_AGE_MS = 20_000L

    private class Entry(val resultCode: Int, val data: Intent, val uptimeMs: Long)

    @Volatile private var entry: Entry? = null

    fun set(resultCode: Int, data: Intent?) {
        entry = if (data == null) null else Entry(resultCode, data, SystemClock.elapsedRealtime())
    }

    fun hasPending(): Boolean {
        val e = entry ?: return false
        return SystemClock.elapsedRealtime() - e.uptimeMs <= MAX_AGE_MS
    }

    /** Returns and clears the parked consent (single use). */
    fun take(): Pair<Int, Intent>? {
        val e = entry ?: return null
        entry = null
        if (SystemClock.elapsedRealtime() - e.uptimeMs > MAX_AGE_MS) return null
        return e.resultCode to e.data
    }

    fun clear() {
        entry = null
    }

    fun describe(): String {
        val e = entry ?: return "consent=none"
        return "consent=resultCode=${e.resultCode} ageMs=${SystemClock.elapsedRealtime() - e.uptimeMs}"
    }
}

/**
 * V6 spec §8/§17 — process-wide publication of the last [com.fischa.core.capture.CaptureAttempt].
 * The Activity reads it to show the diagnostics screen even when the service died before it could
 * bind its own log sink (exactly the V5 failure mode: no service → no logs → no clue).
 */
object CaptureAttemptRegistry {
    @Volatile var last: com.fischa.core.capture.CaptureAttempt? = null
        private set
    @Volatile var lastReport: com.fischa.core.capture.CaptureDiagnosticReport? = null
        private set
    @Volatile var lastLine: String = ""

    fun publish(attempt: com.fischa.core.capture.CaptureAttempt) {
        last = attempt
        lastLine = attempt.formatLine()
    }

    fun publishReport(report: com.fischa.core.capture.CaptureDiagnosticReport) {
        lastReport = report
    }

    fun clear() {
        last = null
        lastReport = null
        lastLine = ""
    }
}
