package com.fischa.app.input

import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.fischa.app.GameAccessibilityService
import com.fischa.app.InputGeometry
import com.fischa.app.ui.DiagnosticsLog
import com.fischa.core.common.CoordinateMapper
import com.fischa.core.config.AppConfig
import com.fischa.core.control.GestureLease
import com.fischa.core.control.GestureSessionState
import com.fischa.core.control.GestureTarget

/**
 * Main-thread Android gesture executor. Long holds are a chain of short continued strokes;
 * each segment has a watchdog and a fresh authorization callback. Android's public API cannot
 * forcibly remove a stroke already dispatched, so every segment is finite and bounded.
 */
class GestureService(
    private val owner: GameAccessibilityService,
    cfg: AppConfig,
) {
    private val main = Handler(Looper.getMainLooper())
    private val quantumMs = cfg.safety.holdQuantumMs.coerceIn(30, 100)
    private val maxContinuousMs = cfg.safety.maxManualHoldMs.coerceIn(500, 10_000)
    private val lease = GestureLease(
        maxLeaseMs = cfg.safety.maxHoldLeaseMs.coerceIn(100, 500),
        maxContinuousMs = maxContinuousMs,
        watchdogMs = cfg.safety.watchdogMs.coerceIn(100, 1000),
    )

    private var stroke: GestureDescription.StrokeDescription? = null
    private var pixelX = 0f
    private var pixelY = 0f
    private var inFlight = false
    private var finishRequested = false
    private var tapInFlight = false
    private var authorize: (() -> Boolean)? = null
    private var dispatchSerial = 0L

    val activeGestureCount: Int
        get() = if (inFlight || lease.activeCount > 0) 1 else 0

    fun tap(nx: Float, ny: Float, durationMs: Int, permit: () -> Boolean): Boolean {
        assertMainThread()
        if (!permitNow(permit) || inFlight || lease.state != GestureSessionState.IDLE) return false
        val p = toPixels(nx, ny) ?: return false
        if (!lease.tap(GestureTarget(nx, ny), durationMs.toLong(), SystemClock.elapsedRealtime())) return false
        pixelX = p.first
        pixelY = p.second
        authorize = permit
        tapInFlight = true
        DiagnosticsLog.event("INPUT", "TAP n=(${"%.3f".format(nx)},${"%.3f".format(ny)}) px=(${pixelX.toInt()},${pixelY.toInt()}) dur=${durationMs}ms")
        val path = Path().apply { moveTo(pixelX, pixelY) }
        val serial = ++dispatchSerial
        val strokeDescription = GestureDescription.StrokeDescription(path, 0L, durationMs.toLong())
        inFlight = true
        val accepted = dispatch(
            GestureDescription.Builder().addStroke(strokeDescription).build(),
            durationMs,
            serial,
            onCompleted = {
                lease.completeTap()
                tapInFlight = false
                inFlight = false
                authorize = null
            },
        )
        if (!accepted) clearGesture("tap rejected")
        return accepted
    }

    fun holdStart(nx: Float, ny: Float, leaseMs: Int, permit: () -> Boolean): Boolean {
        assertMainThread()
        if (!permitNow(permit) || inFlight || lease.state != GestureSessionState.IDLE) return false
        val p = toPixels(nx, ny) ?: return false
        if (!lease.holdStart(GestureTarget(nx, ny), leaseMs.toLong(), SystemClock.elapsedRealtime())) return false
        pixelX = p.first
        pixelY = p.second
        authorize = permit
        finishRequested = false
        tapInFlight = false
        DiagnosticsLog.event("INPUT", "HOLD_START n=(${"%.3f".format(nx)},${"%.3f".format(ny)}) px=(${pixelX.toInt()},${pixelY.toInt()}) lease=${leaseMs}ms")
        sendHoldSegment()
        return lease.state == GestureSessionState.HOLD || inFlight
    }

    fun holdExtend(nx: Float, ny: Float, leaseMs: Int, permit: () -> Boolean): Boolean {
        assertMainThread()
        if (!permitNow(permit)) {
            requestFinish("authorization expired before extend")
            return false
        }
        if (!lease.holdExtend(GestureTarget(nx, ny), leaseMs.toLong(), SystemClock.elapsedRealtime())) {
            requestFinish("invalid/expired hold renewal")
            return false
        }
        authorize = permit
        finishRequested = false
        if (!inFlight) sendHoldSegment()
        return true
    }

    fun holdRelease() {
        assertMainThread()
        if (lease.state == GestureSessionState.HOLD) lease.holdRelease()
        requestFinish("hold released")
    }

    fun cancelAll() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post { cancelAll() }
            return
        }
        lease.cancelAll()
        requestFinish("cancelAll")
    }

    fun releaseAll() = holdRelease()

    private fun sendHoldSegment() {
        assertMainThread()
        if (inFlight || tapInFlight || lease.state != GestureSessionState.HOLD) return
        val now = SystemClock.elapsedRealtime()
        val currentPermit = authorize
        if (finishRequested || !lease.shouldContinue(now) || currentPermit?.let { permitNow(it) } != true) {
            requestFinish("watchdog/authorization blocked")
            return
        }
        val remaining = (lease.leaseDeadlineMs - now).coerceAtLeast(1L)
        val duration = minOf(quantumMs, remaining).coerceAtLeast(1L)
        val keep = remaining > duration && now - lease.startedAtMs + duration < maxContinuousMs
        val path = Path().apply { moveTo(pixelX, pixelY) }
        val next = try {
            stroke?.continueStroke(path, 0L, duration, keep)
                ?: GestureDescription.StrokeDescription(path, 0L, duration, keep)
        } catch (e: Exception) {
            clearGesture("continueStroke failed: ${e.message}")
            return
        }
        val serial = ++dispatchSerial
        inFlight = true
        val accepted = dispatch(
            GestureDescription.Builder().addStroke(next).build(),
            duration.toInt(),
            serial,
            onCompleted = {
                inFlight = false
                stroke = if (keep) next else null
                if (!keep) {
                    clearGesture("hold lease ended")
                } else if (finishRequested || !lease.shouldContinue(SystemClock.elapsedRealtime()) ||
                    authorize?.let { permitNow(it) } != true
                ) {
                    requestFinish("hold no longer authorized")
                } else {
                    sendHoldSegment()
                }
            },
        )
        if (!accepted) {
            clearGesture("dispatchGesture rejected")
            return
        }
        // Watchdog only frees a segment after its bounded duration; it never assumes a long
        // hold succeeded if Android omitted a callback.
    }

    private fun requestFinish(reason: String) {
        finishRequested = true
        if (inFlight) return
        val activeStroke = stroke
        if (activeStroke == null) {
            clearGesture(reason)
            return
        }
        val path = Path().apply { moveTo(pixelX, pixelY) }
        val close = try {
            activeStroke.continueStroke(path, 0L, 1L, false)
        } catch (e: Exception) {
            clearGesture("release continuation failed: ${e.message}")
            return
        }
        val serial = ++dispatchSerial
        inFlight = true
        val accepted = dispatch(
            GestureDescription.Builder().addStroke(close).build(),
            1,
            serial,
            onCompleted = { clearGesture(reason) },
        )
        if (!accepted) clearGesture("release dispatch rejected")
    }

    private fun dispatch(
        gesture: GestureDescription,
        durationMs: Int,
        serial: Long,
        onCompleted: () -> Unit,
    ): Boolean {
        val accepted = try {
            owner.dispatchGesture(
                gesture,
                object : android.accessibilityservice.AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (serial != dispatchSerial) return
                        onCompleted()
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (serial != dispatchSerial) return
                        clearGesture("Android cancelled gesture")
                    }
                },
                main,
            )
        } catch (e: Exception) {
            DiagnosticsLog.event("INPUT", "dispatchGesture exception: ${e.message}")
            false
        }
        if (!accepted) return false
        val expected = serial
        main.postDelayed({
            if (inFlight && dispatchSerial == expected) {
                DiagnosticsLog.event("INPUT", "gesture watchdog expired after ${durationMs}ms")
                inFlight = false
                if (tapInFlight) {
                    lease.completeTap()
                    clearGesture("tap watchdog")
                } else if (stroke != null || lease.state == GestureSessionState.HOLD) {
                    requestFinish("hold watchdog")
                } else {
                    clearGesture("gesture watchdog")
                }
            }
        }, durationMs.coerceAtLeast(1) + 250L)
        return true
    }

    /**
     * NORMALIZED → DEVICE/TOUCH pixels through the one [CoordinateMapper] published by the active
     * capture session (spec §3). Without a published mapper there is no capture session, hence no
     * authorized vision decision — we refuse rather than guess with `displayMetrics`.
     */
    private fun toPixels(nx: Float, ny: Float): Pair<Float, Float>? {
        if (!CoordinateMapper.isValidNormalized(nx, ny)) return null
        val mapper = InputGeometry.mapper
        if (mapper == null) {
            DiagnosticsLog.event("INPUT", "gesture refused: no capture geometry published (session not running)")
            return null
        }
        val p = mapper.normalizedToDevice(nx, ny) ?: return null
        return p.x to p.y
    }

    private fun clearGesture(reason: String) {
        if (tapInFlight) lease.completeTap() else lease.holdRelease()
        stroke = null
        authorize = null
        finishRequested = false
        inFlight = false
        tapInFlight = false
        if (reason.isNotBlank()) DiagnosticsLog.event("INPUT", reason)
    }

    private fun permitNow(permit: () -> Boolean): Boolean = try {
        owner.refreshForegroundStatus().inputAuthorized && permit()
    } catch (_: Exception) {
        false
    }

    private fun assertMainThread() {
        check(Looper.myLooper() == Looper.getMainLooper()) { "GestureService must be mutated on main looper" }
    }
}
