package com.fischa.app

import com.fischa.app.ui.DiagnosticsLog
import com.fischa.core.capture.CaptureProbe
import com.fischa.core.capture.CaptureStage
import com.fischa.core.capture.ProbeStep

/**
 * V6 spec §18 — Android implementation of [CaptureProbe].
 *
 * The probe performs the *real* steps in the canonical order (manager → consent → foreground
 * service → MediaProjection → ImageReader → VirtualDisplay → first frame) and reports the outcome
 * of each one. It never fishes, never taps Roblox, never enables real input and never looks for the
 * rod button: it only exercises the capture infrastructure.
 */
class ServiceCaptureProbe(
    private val managerStep: () -> ProbeStep,
    private val consentStep: () -> ProbeStep,
    private val foregroundStep: () -> ProbeStep,
    private val projectionStep: () -> ProbeStep,
    private val imageReaderStep: () -> ProbeStep,
    private val virtualDisplayStep: () -> ProbeStep,
    private val firstFrameStep: (Long) -> ProbeStep,
    private val teardown: () -> Unit,
) : CaptureProbe {
    override fun probeManager(): ProbeStep = safe(managerStep, CaptureStage.MANAGER)
    override fun probeConsent(): ProbeStep = safe(consentStep, CaptureStage.GET_PROJECTION)
    override fun probeForegroundService(): ProbeStep = safe(foregroundStep, CaptureStage.FOREGROUND)
    override fun probeProjection(): ProbeStep = safe(projectionStep, CaptureStage.GET_PROJECTION)
    override fun probeImageReader(): ProbeStep = safe(imageReaderStep, CaptureStage.IMAGE_READER)
    override fun probeVirtualDisplay(): ProbeStep = safe(virtualDisplayStep, CaptureStage.VIRTUAL_DISPLAY)
    override fun awaitFirstFrame(timeoutMs: Long): ProbeStep = safe({ firstFrameStep(timeoutMs) }, CaptureStage.FIRST_FRAME)

    override fun teardownProbe() {
        runCatching { teardown() }
    }

    private inline fun safe(block: () -> ProbeStep, stage: CaptureStage): ProbeStep =
        try {
            block()
        } catch (t: Throwable) {
            // Never let a probe step throw away the diagnostic: report the original exception.
            DiagnosticsLog.failure("PROBE", "[${stage.name}] probe step threw", t)
            ProbeStep(stage, false, "exceção durante a etapa", com.fischa.core.capture.CapturedException.from(t))
        }
}
