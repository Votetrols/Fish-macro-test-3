package com.fischa.app

import android.content.Context
import com.fischa.app.ui.DiagnosticsLog
import com.fischa.core.log.LogSink
import java.io.File

/**
 * V6 spec §21 — process-wide log sink.
 *
 * V5 only created the log sink inside `FischEngineService.onCreate()`. When the capture never
 * started (the A22 failure), the service did not exist, so `DiagnosticsLog` had no sink and the
 * real exception only went to logcat — the user saw the generic toast and nothing else.
 *
 * V6 initialises the ring buffer + file sink as soon as *any* component (Activity, Accessibility
 * service or engine service) touches [init], and keeps it alive across service restarts:
 *  - bounded in-memory ring (`LogRingBuffer`, 600 lines) for the in-app viewer;
 *  - append-only file `files/fisch-log.txt` (rotated) so the evidence survives a crash;
 *  - every category is prefixed, so `[MEDIA_PROJECTION]` / `[FOREGROUND_SERVICE]` / `[FRAME]`
 *    lines are greppable exactly as the spec requires.
 */
object AppLog {
    private val buffer = LogRingBuffer()
    @Volatile private var initialized = false
    @Volatile private var verbose = false

    /** Idempotent: the first caller wins the file binding, later callers just refresh settings. */
    fun init(context: Context) {
        synchronized(this) {
            if (!initialized) {
                initialized = true
                runCatching {
                    buffer.file = File(context.filesDir, "fisch-log.txt")
                }
                buffer.verbose = context
                    .getSharedPreferences("fisch-ui", Context.MODE_PRIVATE)
                    .getBoolean("verbose", false)
            }
            verbose = buffer.verbose
            DiagnosticsLog.bind { category, message -> buffer.log(LogSink.Level.INFO, category, "[$category] $message", 0L) }
        }
    }

    fun setVerbose(enabled: Boolean) {
        buffer.verbose = enabled
        verbose = enabled
    }

    val isVerbose: Boolean get() = verbose

    fun sink(): LogSink = buffer

    fun event(category: String, message: String) {
        DiagnosticsLog.event(category, message)
    }

    fun failure(category: String, message: String, throwable: Throwable) {
        DiagnosticsLog.failure(category, message, throwable)
    }

    /** Writes a multi-line diagnostic block (e.g. the `[MEDIA_PROJECTION]` report) line by line. */
    fun block(category: String, block: String) {
        DiagnosticsLog.block(category, block)
    }

    /** Whole in-memory ring (diagnostics screen). */
    fun lines(): String = buffer.snapshot()

    /** Last line only (status line per frame). */
    fun tail(): String = buffer.lastLine()

    fun flushAndClose() = buffer.flushAndClose()

    fun rotateIfLarge() = buffer.rotateIfLarge()

    fun logFilePath(): String = buffer.file?.absolutePath ?: "<não inicializado>"

    /** Writes an arbitrary report next to the log (used by DIAGNÓSTICO DE CAPTURA). */
    fun writeReport(context: Context, name: String, content: String): File? = runCatching {
        File(context.filesDir, name).apply { writeText(content) }
    }.getOrNull()
}
