package com.fischa.app.ui

import android.util.Log

/**
 * Small bridge from Android callbacks into logcat and the engine's bounded log sink.
 *
 * V6 spec §1/§21: [failure] exists so that no code path can reduce a platform exception to a
 * generic string. Every capture/Accessibility/input callback that catches something calls it, and
 * the log gets the exact class, the exact message and the stack.
 */
object DiagnosticsLog {
    @Volatile private var sink: ((String, String) -> Unit)? = null

    fun bind(writer: ((String, String) -> Unit)?) { sink = writer }

    /** True when an in-app sink is attached (the UI uses this to explain missing logs). */
    fun isBound(): Boolean = sink != null

    fun event(category: String, message: String) {
        Log.i(TAG, "[$category] $message")
        runCatching { sink?.invoke(category, message) }
    }

    /**
     * Logs a failure **without masking it**: the caller keeps the original exception, and this
     * writes class + message + first stack frames to logcat and to the in-app log.
     */
    fun failure(category: String, message: String, throwable: Throwable) {
        val cls = throwable.javaClass.name
        val msg = throwable.message.orEmpty()
        Log.e(TAG, "[$category] $message | $cls: $msg", throwable)
        runCatching { sink?.invoke(category, "$message | exceptionClass=$cls exceptionMessage=$msg") }
        val stack = throwable.stackTrace.take(6).joinToString(" <- ") { "${it.className}.${it.methodName}(${it.fileName}:${it.lineNumber})" }
        runCatching { sink?.invoke(category, "stack=$stack") }
    }

    /** Convenience for a diagnostic block produced by the core (`formatBlock()`-style strings). */
    fun block(category: String, block: String) {
        Log.i(TAG, "[$category]\n$block")
        block.lineSequence().forEach { line ->
            runCatching { sink?.invoke(category, line) }
        }
    }

    private const val TAG = "FischAuto"
}
