package com.fischa.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.fischa.core.debug.RenderModel

/** Optional non-touchable, read-only overlay with detector boxes and safety diagnostics. */
class DebugOverlay(private val context: Context) {
    private val windowManager = context.getSystemService(WindowManager::class.java)
        ?: context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var model: RenderModel? = null

    private val view = object : View(context) {
        override fun onDraw(canvas: Canvas) {
            // Draw in the SAME coordinate space as capture/touch: the real display size published
            // by the capture session (spec §3). The overlay window is anchored at (0,0) and laid
            // out without inset limits, so using the real size keeps boxes aligned with the game
            // even if the window itself is clipped by system bars.
            val geometry = InputGeometry.geometry
            val w = geometry?.width?.toFloat() ?: width.toFloat()
            val h = geometry?.height?.toFloat() ?: height.toFloat()
            model?.let { drawModel(canvas, it, w, h) }
        }
    }
    private val boxPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = false }
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 24f
        isAntiAlias = false
        setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }
    private val smallTextPaint = Paint(textPaint).apply { textSize = 19f; color = Color.LTGRAY }
    private val fillPaint = Paint().apply { style = Paint.Style.FILL }
    private val centerPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = false }
    private var params: WindowManager.LayoutParams? = null

    fun enable() {
        if (params != null) return
        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0; y = 0
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = if (android.os.Build.VERSION.SDK_INT >= 30)
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            if (android.os.Build.VERSION.SDK_INT >= 30) fitInsetsTypes = 0
        }
        windowManager.addView(view, layoutParams)
        params = layoutParams
    }

    fun disable() {
        params?.let { runCatching { windowManager.removeViewImmediate(view) } }
        params = null
    }

    fun setModel(snapshot: RenderModel?) { model = snapshot }
    fun invalidate() { if (params != null) view.invalidate() }

    private fun drawModel(canvas: Canvas, m: RenderModel, width: Float, height: Float) {
        var y = 32f
        val lineHeight = 25f
        fun line(text: String, paint: Paint = smallTextPaint) {
            canvas.drawText(text, 12f, y, paint)
            y += lineHeight
        }
        val robloxPaint = Paint(textPaint).apply { color = if (m.robloxDetected) Color.GREEN else Color.RED }
        line("Roblox: ${if (m.robloxDetected) "YES" else "NO"} | package=${m.foregroundPackage}", robloxPaint)
        line("Window=${m.foregroundWindow}")
        line("State=${m.state} | FPS=${"%.1f".format(m.fps)} | frame=${m.frameAgeMs}ms", textPaint)
        line("Rod: confirmed=${m.rodConfirmed} conf=${"%.2f".format(m.confRod)} castAuthorized=${m.castAuthorized} (V6 compat)")
        // ---- V7 §5: detection stack, in the exact vocabulary of the spec -----------------
        val stateColor = when (m.rodState) {
            "SEARCHING_ROD" -> SEARCH_COLOR
            "CANDIDATE_FOUND", "CONFIRMING_ROD" -> CANDIDATE_COLOR
            "ROD_CONFIRMED" -> CONFIRMED_COLOR
            "TRACKING_ROD" -> TRACKING_COLOR
            "ROD_LOST" -> LOST_COLOR
            "LOCAL_RETRY" -> CANDIDATE_COLOR
            "AUTO_CALIBRATION" -> SEARCH_COLOR
            else -> Color.LTGRAY
        }
        val searchText = if (m.rodTracking) "LOCAL" else if (m.rodState == "AUTO_CALIBRATION") "CALIB" else "ACTIVE"
        val candidateText = when {
            m.rodState == "ROD_CONFIRMED" || m.rodState == "TRACKING_ROD" -> "CONFIRMED"
            m.rodCandidates > 0 -> "FOUND"
            else -> "NONE"
        }
        val roiText = m.rodRoiBox?.let {
            "(${(it[0] * width).toInt()},${(it[1] * height).toInt()}," +
                "${((it[2] - it[0]) * width).toInt()},${((it[3] - it[1]) * height).toInt()})"
        } ?: "(-)"
        val fmt = "STATE=%s FPS=%.0f SEARCH=%s CANDIDATE=%s ROD_SCORE=%.2f ROD_CONFIDENCE=%.2f ROI=%s TRACKING=%s CONFIRM=%d/%d CANDIDATES=%d"
        line(
            fmt.format(
                m.rodState, m.fps, searchText, candidateText, m.rodScore, m.confRod, roiText,
                if (m.rodTracking) "ACTIVE" else "IDLE", m.rodStreak, m.rodRequiredFrames, m.rodCandidates,
            ),
            Paint(textPaint).apply { color = stateColor },
        )
        val layers = "VISION=${m.layerVision} DETECTION=${m.layerDetection} DECISION=${m.layerDecision} REAL_INPUT=${m.layerInput}"
        line(layers, Paint(textPaint).apply { color = if (m.layerInput == "DISABLED") Color.RED else Color.GREEN })
        if (m.rodState == "ROD_LOST" || m.rodState == "LOCAL_RETRY" || m.rodTracking) {
            line("ROD: lost=${"%.0f".format(m.rodLostMs)}ms reason=${m.rodReason}", smallTextPaint)
        } else {
            line("ROD: reason=${m.rodReason}", smallTextPaint)
        }
        if (m.rodCalibration.isNotEmpty()) line("CALIB: ${m.rodCalibration}", smallTextPaint)
        if (m.rodCandidateDetail.isNotEmpty()) line("CAND: ${m.rodCandidateDetail}", smallTextPaint)
        line("Fish=${"%.3f".format(m.fishCx)} Player=${"%.3f".format(m.playerCx)} Error=${"%+.3f".format(m.error)}")
        line("Confidence: global=${"%.2f".format(m.confGlobal)} bar=${"%.2f".format(m.confBar)} fish=${"%.2f".format(m.confFish)} player=${"%.2f".format(m.confPlayer)}")
        line("Progress=${"%.2f".format(m.progress)} rate=${"%+.2f".format(m.progressRate)} | action=${m.action}")
        val safetyText = if (m.inputAuthorized) "Safety: PASS" else "Safety: BLOCKED ${m.safetyBlockedReason}"
        val safetyPaint = Paint(textPaint).apply { color = if (m.inputAuthorized) Color.GREEN else Color.RED }
        line("Input=${if (m.realInputEnabled) "ENABLED" else "DISABLED"} | $safetyText", safetyPaint)
        if (m.emergency) line("EMERGENCY STOP LATCHED", Paint(textPaint).apply { color = Color.RED })

        m.barBox?.let { drawBox(canvas, it, width, height, Color.CYAN) }
        m.blockBox?.let { drawBox(canvas, it, width, height, Color.WHITE) }
        m.fishBox?.let { drawBox(canvas, it, width, height, Color.YELLOW) }
        m.progressBox?.let { drawBox(canvas, it, width, height, Color.GREEN) }
        m.shakeBox?.let { drawBox(canvas, it, width, height, Color.MAGENTA) }
        // ---- V7: the boxes that accompany the *candidate*, not a fixed coordinate --------
        val activeColor = when (m.rodState) {
            "SEARCHING_ROD" -> SEARCH_COLOR
            "CANDIDATE_FOUND", "CONFIRMING_ROD" -> CANDIDATE_COLOR
            "ROD_CONFIRMED" -> CONFIRMED_COLOR
            "TRACKING_ROD" -> TRACKING_COLOR
            "ROD_LOST", "LOCAL_RETRY" -> LOST_COLOR
            else -> Color.LTGRAY
        }
        // wide search region (thin)
        m.rodSearchBox?.let { drawBox(canvas, it, width, height, SEARCH_COLOR, strokeWidth = 2f) }
        // dynamic ROI around the detected button
        m.rodRoiBox?.let { drawBox(canvas, it, width, height, TRACKING_COLOR, strokeWidth = 2f) }
        // the detected candidate (thicker, coloured by state) — replaces the old fixed red square
        m.rodBox?.let { drawBox(canvas, it, width, height, activeColor, strokeWidth = 4f) }
        // button centre cross
        m.rodCenterNorm?.let { c ->
            val cx = c[0] * width
            val cy = c[1] * height
            centerPaint.color = activeColor
            canvas.drawLine(cx - 12f, cy, cx + 12f, cy, centerPaint)
            canvas.drawLine(cx, cy - 12f, cx, cy + 12f, centerPaint)
        }
        m.barBox?.let { bar ->
            val left = bar[0] * width
            val right = bar[2] * width
            fillPaint.color = Color.argb(160, 0, 220, 120)
            canvas.drawRect(left, 4f, left + (right - left) * m.progress.coerceIn(0f, 1f), 12f, fillPaint)
        }
    }

    private fun drawBox(
        canvas: Canvas,
        norm: FloatArray,
        width: Float,
        height: Float,
        color: Int,
        strokeWidth: Float = 3f,
    ) {
        if (norm.size < 4) return
        boxPaint.color = color
        boxPaint.strokeWidth = strokeWidth
        canvas.drawRect(norm[0] * width, norm[1] * height, norm[2] * width, norm[3] * height, boxPaint)
        boxPaint.strokeWidth = 3f
    }

    private companion object {
        /** V7 §5: colours only differentiate the detection states. */
        const val SEARCH_COLOR = 0xFFFFD400.toInt()    // amarelo  — SEARCH
        const val CANDIDATE_COLOR = 0xFFFF9800.toInt() // laranja  — CANDIDATE
        const val CONFIRMED_COLOR = 0xFF00E676.toInt() // verde    — CONFIRMED
        const val TRACKING_COLOR = 0xFF00E5FF.toInt()  // ciano    — TRACKING
        const val LOST_COLOR = 0xFFFF1744.toInt()      // vermelho — LOST
    }
}
