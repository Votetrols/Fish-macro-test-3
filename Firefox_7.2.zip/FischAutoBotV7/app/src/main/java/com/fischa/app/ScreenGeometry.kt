package com.fischa.app

import android.content.Context
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.os.Build
import android.view.Display
import android.view.WindowManager
import com.fischa.core.common.CoordinateMapper

/**
 * Single source of truth for the physical display size used by BOTH the MediaProjection capture
 * and the AccessibilityService gesture path (spec §3: one coordinate system).
 *
 * Why not `resources.displayMetrics`? On Android 11+ a Service context's metrics may describe an
 * *application window* (excluding status/navigation bars) while MediaProjection mirrors the whole
 * display and dispatchGesture uses whole-display pixels. Mixing them shifts taps by the bar height
 * (tens of pixels on the Galaxy A22). We therefore always use the real/maximum display bounds.
 */
data class ScreenGeometry(
    val width: Int,
    val height: Int,
    val rotation: Int,
    val densityDpi: Int,
    /** Area the current application window may use (diagnostic only; not used for mapping). */
    val appWindowWidth: Int,
    val appWindowHeight: Int,
    val statusBarPx: Int,
    val navBarPx: Int,
) {
    val isLandscape: Boolean get() = width >= height

    fun describe(): String =
        "real=${width}x${height} rot=$rotation dpi=$densityDpi appWindow=${appWindowWidth}x${appWindowHeight} " +
            "statusBar=${statusBarPx}px navBar=${navBarPx}px"

    fun sameAs(other: ScreenGeometry): Boolean =
        width == other.width && height == other.height && rotation == other.rotation

    companion object {
        @Suppress("DEPRECATION")
        fun read(context: Context): ScreenGeometry {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val display: Display? = dm.getDisplay(Display.DEFAULT_DISPLAY)
            val rotation = display?.rotation ?: 0
            val densityDpi = context.resources.displayMetrics.densityDpi

            var realW: Int
            var realH: Int
            var appW: Int
            var appH: Int
            var statusBar = 0
            var navBar = 0
            if (Build.VERSION.SDK_INT >= 30) {
                val max = wm.maximumWindowMetrics.bounds
                realW = max.width(); realH = max.height()
                val cur = wm.currentWindowMetrics
                appW = cur.bounds.width(); appH = cur.bounds.height()
                runCatching {
                    val insets = cur.windowInsets.getInsetsIgnoringVisibility(
                        android.view.WindowInsets.Type.statusBars(),
                    )
                    statusBar = maxOf(insets.top, insets.left, insets.right, insets.bottom)
                    val nav = cur.windowInsets.getInsetsIgnoringVisibility(
                        android.view.WindowInsets.Type.navigationBars(),
                    )
                    navBar = maxOf(nav.top, nav.left, nav.right, nav.bottom)
                }
            } else {
                val p = Point()
                val d = display ?: wm.defaultDisplay
                d.getRealSize(p)
                realW = p.x; realH = p.y
                val a = Point()
                d.getSize(a)
                appW = a.x; appH = a.y
            }
            // Fallback guard: if real metrics are unusable, use whatever the display reports.
            if (realW <= 0 || realH <= 0) {
                val p = Point()
                (display ?: wm.defaultDisplay).getRealSize(p)
                realW = p.x.coerceAtLeast(1); realH = p.y.coerceAtLeast(1)
            }
            if (appW <= 0 || appH <= 0) { appW = realW; appH = realH }
            return ScreenGeometry(realW, realH, rotation, densityDpi, appW, appH, statusBar, navBar)
        }
    }
}

/**
 * Process-wide holder of the active capture→device mapper. Set by the engine when a capture
 * session starts (from the exact VirtualDisplay size it created) and cleared on stop. The
 * gesture layer refuses to convert coordinates while no mapper is published, so a tap can never
 * be computed against a different geometry than the one the vision frame came from.
 */
object InputGeometry {
    @Volatile var mapper: CoordinateMapper? = null
        private set
    @Volatile var geometry: ScreenGeometry? = null
        private set

    fun publish(mapper: CoordinateMapper, geometry: ScreenGeometry) {
        this.mapper = mapper
        this.geometry = geometry
    }

    fun clear() {
        mapper = null
        geometry = null
    }
}
