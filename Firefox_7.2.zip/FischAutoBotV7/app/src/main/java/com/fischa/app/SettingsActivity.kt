package com.fischa.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.fischa.core.config.AppConfig

/**
 * The settings screen is deliberately raw-but-honest (spec §7 "config centralizada"): every
 * tunable of the core is one `key=value` line, produced from [AppConfig.toMap] — the exact
 * same flat format the replay harness and tests use, so a line copied from a bug report can
 * be pasted into a test. Parsing is strict; on error nothing is saved.
 */
class SettingsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (12 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val editor = EditText(this).apply {
            inputType = EditorInfo.TYPE_CLASS_TEXT or EditorInfo.TYPE_TEXT_FLAG_MULTI_LINE
            gravity = Gravity.TOP or Gravity.START
            textSize = 11f
            typeface = android.graphics.Typeface.MONOSPACE
            setText(currentText())
            setHorizontallyScrolling(true)
        }
        root.addView(TextView(this).apply {
            text = "Um parâmetro por linha: chave=valor (ex.: control.kP=4.2)"
        })
        root.addView(ScrollView(this).apply {
            addView(editor, LinearLayout.LayoutParams(-1, -2))
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(Button(context).apply {
                text = "Salvar"
                setOnClickListener { save(editor.text.toString()) }
            })
            addView(Button(context).apply {
                text = "Restaurar padrões"
                setOnClickListener {
                    getSharedPreferences("fisch-config", MODE_PRIVATE).edit().clear().apply()
                    editor.setText(AppConfig().toMap().entries.sortedBy { it.key }
                        .joinToString("\n") { "${it.key}=${it.value}" })
                    Toast.makeText(context, "Padrões recarregados (aplique reiniciando o motor)",
                        Toast.LENGTH_SHORT).show()
                }
            })
        })
        setContentView(root)
    }

    private fun currentText(): String =
        FischEngineService.loadConfig(this).toMap().entries.sortedBy { it.key }
            .joinToString("\n") { "${it.key}=${it.value}" }

    private fun save(text: String) {
        val base = AppConfig().toMap()
        val parsed = HashMap<String, String>()
        for (line in text.lineSequence()) {
            val t = line.trim()
            if (t.isEmpty() || t.startsWith("#")) continue
            val eq = t.indexOf('=')
            if (eq <= 0) {
                Toast.makeText(this, "Linha inválida: $t", Toast.LENGTH_LONG).show()
                return
            }
            val k = t.substring(0, eq).trim()
            val v = t.substring(eq + 1).trim()
            if (!base.containsKey(k)) {
                Toast.makeText(this, "Chave desconhecida: $k", Toast.LENGTH_LONG).show()
                return
            }
            parsed[k] = v
        }
        // withOverrides drops unparseable values silently → round-trip verify every key
        val applied = AppConfig().withOverrides(parsed).validate().toMap()
        for ((k, v) in parsed) {
            val want = v.toDoubleOrNull()
            val got = applied[k]?.toDoubleOrNull()
            val ok = if (want != null && got != null) {
                kotlin.math.abs(want - got) < 1e-6 || want == got
            } else applied[k] == v
            if (!ok) {
                Toast.makeText(this, "Valor inválido para $k: '$v'", Toast.LENGTH_LONG).show()
                return
            }
        }
        getSharedPreferences("fisch-config", MODE_PRIVATE).edit()
            .clear()
            .apply { parsed.forEach { (k, v) -> putString(k, v) } }
            .apply()
        Toast.makeText(this, "Salvo. Reinicie o motor para aplicar.", Toast.LENGTH_SHORT).show()
        finish()
    }
}
