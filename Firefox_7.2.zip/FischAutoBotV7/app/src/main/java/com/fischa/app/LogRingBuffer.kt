package com.fischa.app

import android.util.Log
import com.fischa.core.log.LogSink
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter

/**
 * LogSink for Android: logcat + bounded in-memory ring (for the in-app viewer) + append-only
 * file (shareable). Written from the engine thread only; UI reads a copy.
 *
 * Log levels (spec §14): DEBUG lines are dropped unless [verbose] is enabled in the UI, so the
 * per-frame diagnostics never reach logcat/file in normal operation on the Galaxy A22. The file is
 * rotated when it grows beyond [MAX_FILE_BYTES] (one backup kept).
 */
class LogRingBuffer : LogSink {

    companion object {
        private const val TAG = "FischAuto"
        const val MAX_LINES = 600
        const val MAX_FILE_BYTES = 2L * 1024 * 1024
    }

    private val ring = ArrayDeque<String>(MAX_LINES)
    private var writer: BufferedWriter? = null
    private var linesSinceFlush = 0

    @Volatile var verbose: Boolean = false

    /** set after construction (or to null to stop file logging) */
    var file: File? = null
        set(v) {
            field = v
            runCatching { writer?.flush(); writer?.close() }
            writer = v?.let { BufferedWriter(FileWriter(it, true)) }
        }

    override fun log(level: LogSink.Level, tag: String, msg: String, timestampNs: Long) {
        if (level == LogSink.Level.DEBUG && !verbose) return
        val line = "[${level.name[0]}][$tag] $msg"
        synchronized(ring) {
            ring.addLast(line)
            while (ring.size > MAX_LINES) ring.removeFirst()
        }
        when (level) {
            LogSink.Level.DEBUG -> Log.d(TAG, line)
            LogSink.Level.INFO -> Log.i(TAG, line)
            LogSink.Level.WARN -> Log.w(TAG, line)
            LogSink.Level.ERROR -> Log.e(TAG, line)
        }
        synchronized(this) {
            runCatching {
                writer?.write(line); writer?.newLine()
                if (++linesSinceFlush >= 20 || level == LogSink.Level.ERROR) {
                    writer?.flush(); linesSinceFlush = 0
                }
            }
        }
    }

    fun snapshot(): String = synchronized(ring) { ring.joinToString("\n") }

    /** O(1) accessor used by the per-frame status snapshot (never join the ring per frame). */
    fun lastLine(): String = synchronized(ring) { ring.lastOrNull().orEmpty() }

    /** Keeps the on-device log bounded; called at session start. */
    fun rotateIfLarge() {
        val f = file ?: return
        synchronized(this) {
            if (f.length() <= MAX_FILE_BYTES) return
            runCatching { writer?.flush(); writer?.close() }
            val backup = File(f.parentFile, f.name + ".1")
            runCatching { backup.delete(); f.renameTo(backup) }
            writer = runCatching { BufferedWriter(FileWriter(f, true)) }.getOrNull()
        }
    }

    fun flushAndClose() {
        synchronized(this) { runCatching { writer?.flush(); writer?.close(); writer = null } }
    }
}
