package com.fischa.app

import android.os.Handler
import android.os.Looper
import com.fischa.core.control.InputExecutor

/** Normalized-coordinate adapter; conversion to display pixels occurs only in GestureService. */
class AndroidInputExecutor : InputExecutor {
    private val main = Handler(Looper.getMainLooper())
    /** Uptime of the last posted holdStart; covers the main-thread hop before the lease exists. */
    @Volatile private var holdPostedAtMs = 0L
    private val postGraceMs = 200L

    override fun tap(nx: Float, ny: Float, durationMs: Int) {
        // Deliberately no unauthenticated legacy path. Core must use the authorize-carrying overload.
    }

    override fun tap(nx: Float, ny: Float, durationMs: Int, authorize: () -> Boolean): Boolean =
        dispatch { it.gestures.tap(nx, ny, durationMs, authorize) }

    override fun holdStart(nx: Float, ny: Float, leaseMs: Int, authorize: () -> Boolean): Boolean {
        holdPostedAtMs = android.os.SystemClock.uptimeMillis()
        return dispatch { it.gestures.holdStart(nx, ny, leaseMs, authorize) }
    }

    override fun holdExtend(nx: Float, ny: Float, leaseMs: Int, authorize: () -> Boolean): Boolean =
        dispatch { it.gestures.holdExtend(nx, ny, leaseMs, authorize) }

    override fun holdRelease() {
        dispatch { it.gestures.holdRelease(); true }
    }

    override fun cancelAll() {
        dispatch { it.gestures.cancelAll(); true }
    }

    override fun releaseAll() = holdRelease()

    override fun activeGestureCount(): Int = GameAccessibilityService.instance?.gestures?.activeGestureCount ?: 0

    override fun holdStillActive(): Boolean? {
        val service = GameAccessibilityService.instance ?: return false
        if (service.gestures.activeGestureCount > 0) return true
        // A holdStart posted a moment ago may not have reached the main looper yet.
        return android.os.SystemClock.uptimeMillis() - holdPostedAtMs < postGraceMs
    }

    private fun dispatch(block: (GameAccessibilityService) -> Boolean): Boolean {
        val service = GameAccessibilityService.instance ?: return false
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return runCatching { block(service) }.getOrDefault(false)
        }
        val posted = main.post {
            runCatching { block(service) }
        }
        return posted
    }
}
