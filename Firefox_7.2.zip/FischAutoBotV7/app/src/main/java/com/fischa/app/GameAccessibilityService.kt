package com.fischa.app

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import com.fischa.app.input.GestureService
import com.fischa.app.ui.DiagnosticsLog
import com.fischa.core.debug.RenderModel
import com.fischa.core.safety.ForegroundObservation
import com.fischa.core.safety.RobloxForegroundDetector
import com.fischa.core.safety.RobloxForegroundStatus

/**
 * The sole Android foreground/window observer and the only AccessibilityService used for input.
 *
 * Galaxy A22 / V3 hardening (spec §5). The previous real test ended in FOREGROUND_UNKNOWN because
 * Roblox's fullscreen (Unity-style) surface exposes no accessibility root: the active-window and
 * rootInActiveWindow sources were null, and the only remaining source — the last window event —
 * was aged out after 3 s. Fixes:
 *
 *  1. **Verified activity tracking.** Every TYPE_WINDOW_STATE_CHANGED event whose class name is a
 *     real Activity of the event's package (checked with PackageManager) updates the "current
 *     app". Dialogs, toasts, IME, system panels never pass that check, so they cannot clobber it;
 *     a later Activity of any other app (launcher, recents, our own UI, in-call…) replaces it.
 *  2. **Periodic re-evaluation** (every [REFRESH_PERIOD_MS]) of the window list, so the cached
 *     status consumed by the engine and the gesture watchdog is never older than ~0.5 s even when
 *     no accessibility event arrives. The status carries its own timestamp; consumers must treat a
 *     stale status as *not authorized* (see FischEngineService).
 *  3. **Rate-limited** window scans (`refreshForegroundStatus` reuses a result younger than
 *     [MIN_REFRESH_INTERVAL_MS]), because the gesture path calls it before every hold segment.
 *  4. Live sources (active window root / rootInActiveWindow) still win in both directions: another
 *     app's window in front → blocked immediately.
 *
 * A missing service/root/package always resolves to BLOCKED, never to a permissive default.
 */
class GameAccessibilityService : AccessibilityService() {
    companion object {
        const val ROBLOX_PACKAGE = RobloxForegroundDetector.ROBLOX_PACKAGE
        private const val OWN_OVERLAY_CLASS_MARKER = "DebugOverlay"
        private const val REFRESH_PERIOD_MS = 500L
        private const val MIN_REFRESH_INTERVAL_MS = 80L

        @Volatile var instance: GameAccessibilityService? = null
            private set

        @Volatile private var lastSnapshot: RobloxForegroundStatus =
            RobloxForegroundStatus.unknown(SystemClock.elapsedRealtime(), "ACCESSIBILITY_UNAVAILABLE")

        fun latestForegroundStatus(): RobloxForegroundStatus =
            instance?.cachedForegroundStatus() ?: RobloxForegroundStatus.unknown(
                SystemClock.elapsedRealtime(),
                "ACCESSIBILITY_UNAVAILABLE",
            )
    }

    private val foregroundDetector = RobloxForegroundDetector()
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private var debugOverlay: DebugOverlay? = null
    @Volatile private var pendingDebugModel: RenderModel? = null
    private val renderDebugOverlay = Runnable {
        debugOverlay?.let { overlay ->
            overlay.setModel(pendingDebugModel)
            overlay.invalidate()
        }
    }
    private val periodicRefresh = object : Runnable {
        override fun run() {
            if (instance !== this@GameAccessibilityService) return
            refreshForegroundStatus(force = true)
            main.postDelayed(this, REFRESH_PERIOD_MS)
        }
    }

    // Legacy unverified event source (kept for compatibility; low trust, 3 s freshness in core).
    @Volatile private var lastWindowEventPackage: String? = null
    @Volatile private var lastWindowEventTimestampMs: Long? = null
    @Volatile private var lastEventActivity: String? = null
    // Verified Activity transitions (authoritative "current app" for root-less fullscreen games).
    @Volatile private var lastActivityPackage: String? = null
    @Volatile private var lastActivityClass: String? = null
    @Volatile private var lastActivityTimestampMs: Long? = null

    @Volatile private var foregroundStatus: RobloxForegroundStatus = lastSnapshot
    @Volatile private var lastRefreshUptimeMs: Long = 0L
    @Volatile private var lastDiagnosticKey: String = ""
    private val activityCache = HashMap<String, Boolean>()

    lateinit var gestures: GestureService
        private set

    override fun onServiceConnected() {
        super.onServiceConnected()
        gestures = GestureService(this, FischEngineService.loadConfig(this))
        instance = this
        refreshForegroundStatus(force = true)
        main.removeCallbacks(periodicRefresh)
        main.postDelayed(periodicRefresh, REFRESH_PERIOD_MS)
        if (getSharedPreferences("fisch-ui", MODE_PRIVATE).getBoolean("overlay", false)) setDebugOverlay(true)
        DiagnosticsLog.event("SAFETY", "Accessibility service connected; ${formatStatus(foregroundStatus)}")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event != null) {
            val type = event.eventType
            if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                val pkg = event.packageName?.toString()?.trim().orEmpty()
                val cls = event.className?.toString()?.trim().orEmpty()
                val now = SystemClock.elapsedRealtime()
                val ownOverlayEvent = pkg == packageName && cls.contains(OWN_OVERLAY_CLASS_MARKER)
                if (pkg.isNotEmpty() && !ownOverlayEvent) {
                    if (cls.isNotEmpty() && isActivityOf(pkg, cls)) {
                        if (pkg != lastActivityPackage || cls != lastActivityClass) {
                            DiagnosticsLog.event("SAFETY", "activity changed: $pkg/$cls")
                        }
                        lastActivityPackage = pkg
                        lastActivityClass = cls
                        lastActivityTimestampMs = now
                        lastWindowEventPackage = pkg
                        lastWindowEventTimestampMs = now
                        lastEventActivity = cls
                    } else if (pkg == ROBLOX_PACKAGE || pkg == lastActivityPackage) {
                        // Same app, non-activity window (dialog/popup): refresh the low-trust source only.
                        lastWindowEventPackage = pkg
                        lastWindowEventTimestampMs = now
                        lastEventActivity = cls.ifBlank { lastEventActivity }
                    }
                    // Unverified events from other packages (system UI panels, toasts, IME, game
                    // tools bubbles) do not change the current-app evidence. If they actually
                    // cover the game, the window scan below reports them as INCOMPATIBLE_OVERLAY.
                }
            }
            if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
                val status = refreshForegroundStatus(force = true)
                if (!status.inputAuthorized && ::gestures.isInitialized) gestures.cancelAll()
            }
        }
    }

    override fun onInterrupt() {
        DiagnosticsLog.event("SAFETY", "Accessibility interrupted; input blocked")
        if (::gestures.isInitialized) gestures.cancelAll()
        FischEngineService.triggerEmergencyFromAccessibility("accessibility interrupted")
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        teardown("accessibility unbound")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown("accessibility service destroyed")
        super.onDestroy()
    }

    private fun teardown(reason: String) {
        main.removeCallbacks(periodicRefresh)
        if (::gestures.isInitialized) gestures.cancelAll()
        setDebugOverlay(false)
        FischEngineService.triggerEmergencyFromAccessibility(reason)
        if (instance === this) instance = null
        lastSnapshot = RobloxForegroundStatus.unknown(SystemClock.elapsedRealtime(), "ACCESSIBILITY_UNAVAILABLE")
        foregroundStatus = lastSnapshot
    }

    /** PackageManager-verified "is this class an Activity of this package?" with a small cache. */
    private fun isActivityOf(pkg: String, cls: String): Boolean {
        val key = "$pkg/$cls"
        activityCache[key]?.let { return it }
        val verified = try {
            packageManager.getActivityInfo(ComponentName(pkg, cls), 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        } catch (_: Exception) {
            false
        }
        if (activityCache.size > 256) activityCache.clear()
        activityCache[key] = verified
        return verified
    }

    /** Called on the main looper immediately before every hold segment / dispatch, and periodically. */
    fun refreshForegroundStatus(force: Boolean = false): RobloxForegroundStatus {
        if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
            return foregroundStatus
        }
        val nowMs = SystemClock.elapsedRealtime()
        if (!force && lastRefreshUptimeMs != 0L && nowMs - lastRefreshUptimeMs < MIN_REFRESH_INTERVAL_MS) {
            return foregroundStatus
        }
        lastRefreshUptimeMs = nowMs

        var activeAppPackage: String? = null
        var activeAppRootMissing = false
        var rootPackage: String? = null
        var activity = lastEventActivity
        var activeWindow = "<unknown>"
        var overlayActive = false
        val appPackages = ArrayList<String>(4)

        try {
            val allWindows = windows
            for (window in allWindows) {
                val windowType = window.type
                val isActive = window.isActive || window.isFocused
                val root = try { window.root } catch (_: Exception) { null }
                val rootPkg = root?.packageName?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                val rootClass = root?.className?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                val title = if (android.os.Build.VERSION.SDK_INT >= 24) window.title?.toString() else null
                val description = "type=$windowType active=$isActive layer=${window.layer} id=${window.id}" +
                    (rootPkg?.let { " pkg=$it" } ?: "") +
                    (rootClass?.let { " class=$it" } ?: "") +
                    (title?.takeIf { it.isNotBlank() }?.let { " title=$it" } ?: "")
                if (isActive) activeWindow = description

                if (windowType == AccessibilityWindowInfo.TYPE_APPLICATION) {
                    if (rootPkg != null) appPackages.add(rootPkg)
                    if (isActive) {
                        if (rootPkg != null) {
                            activeAppPackage = rootPkg
                            if (rootClass != null) activity = rootClass
                        } else {
                            activeAppRootMissing = true
                        }
                    }
                } else if (isActive && isBlockingWindow(window, rootPkg)) {
                    overlayActive = true
                }
                try { root?.recycle() } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            DiagnosticsLog.event("SAFETY", "Accessibility windows query unavailable: ${e.javaClass.simpleName}")
        }

        try {
            val root = rootInActiveWindow
            if (root != null) {
                val pkg = root.packageName?.toString()?.trim().orEmpty()
                val cls = root.className?.toString()?.trim().orEmpty()
                val ownOverlayRoot = pkg == packageName && cls.contains(OWN_OVERLAY_CLASS_MARKER)
                if (pkg.isNotEmpty() && !ownOverlayRoot) rootPackage = pkg
                if (cls.isNotEmpty() && !ownOverlayRoot && activity == null) activity = cls
                try { root.recycle() } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            // Root access is optional; the verified activity source remains valid.
        }

        val interactive = try {
            (getSystemService(POWER_SERVICE) as? PowerManager)?.isInteractive ?: false
        } catch (_: Exception) { false }

        val observation = ForegroundObservation(
            activeAppWindowPackage = activeAppPackage,
            rootInActiveWindowPackage = rootPackage,
            lastWindowEventPackage = lastWindowEventPackage,
            foregroundActivity = activity,
            activeWindow = activeWindow,
            incompatibleOverlay = overlayActive,
            accessibilityAvailable = instance === this,
            screenInteractive = interactive,
            timestampMs = nowMs,
            lastWindowEventTimestampMs = lastWindowEventTimestampMs,
            lastActivityPackage = lastActivityPackage,
            lastActivityClass = lastActivityClass,
            lastActivityTimestampMs = lastActivityTimestampMs,
            appWindowPackages = appPackages,
            activeAppWindowRootMissing = activeAppRootMissing,
        )
        val next = foregroundDetector.evaluate(observation)
        foregroundStatus = next
        lastSnapshot = next
        val diagnosticKey = listOf(
            next.foregroundPackage,
            next.robloxDetected,
            next.inputAuthorized,
            next.blockReason,
            next.overlayActive,
            next.evidenceSource,
        ).joinToString("|")
        if (diagnosticKey != lastDiagnosticKey) {
            lastDiagnosticKey = diagnosticKey
            DiagnosticsLog.event("SAFETY", formatStatus(next))
        }
        return next
    }

    fun cachedForegroundStatus(): RobloxForegroundStatus = foregroundStatus

    fun setDebugOverlay(enabled: Boolean) {
        if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
            main.post { setDebugOverlay(enabled) }
            return
        }
        if (enabled) {
            if (debugOverlay == null) {
                runCatching { DebugOverlay(this).also { it.enable(); debugOverlay = it } }
                    .onFailure { DiagnosticsLog.event("DEBUG", "Overlay unavailable: ${it.javaClass.simpleName}") }
            }
        } else {
            debugOverlay?.disable()
            debugOverlay = null
        }
    }

    fun updateDebugOverlay(model: RenderModel?) {
        if (debugOverlay == null) return
        pendingDebugModel = model
        main.removeCallbacks(renderDebugOverlay)
        main.post(renderDebugOverlay)
    }

    fun overlaySuspected(): Boolean = foregroundStatus.overlayActive

    private fun isBlockingWindow(window: AccessibilityWindowInfo, rootPackage: String?): Boolean {
        return when (window.type) {
            AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY ->
                rootPackage != null && rootPackage != packageName
            AccessibilityWindowInfo.TYPE_SYSTEM,
            AccessibilityWindowInfo.TYPE_INPUT_METHOD -> true
            AccessibilityWindowInfo.TYPE_SPLIT_SCREEN_DIVIDER -> true
            else -> false
        }
    }

    private fun formatStatus(status: RobloxForegroundStatus): String =
        "foregroundPackage=${status.foregroundPackage} activity/window=${status.foregroundActivityWindow} " +
            "robloxDetected=${status.robloxDetected} inputAuthorized=${status.inputAuthorized} " +
            "blockReason=${status.blockReason} source=${status.evidenceSource} timestamp=${status.timestampMs}"
}
