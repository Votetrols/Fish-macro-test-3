package com.fischa.app

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import com.fischa.app.ui.DiagnosticsLog
import com.fischa.core.capture.CaptureAttempt
import com.fischa.core.capture.CaptureConsentPolicy
import com.fischa.core.capture.CaptureDiagnosticReport
import com.fischa.core.capture.CaptureDiagnostics
import com.fischa.core.capture.CaptureErrorText
import com.fischa.core.capture.CaptureSessionState
import com.fischa.core.capture.CaptureState
import com.fischa.core.capture.CaptureStateSnapshot
import com.fischa.core.capture.CaptureStage
import com.fischa.core.capture.DeviceProfile
import com.fischa.core.capture.FrameAge
import com.fischa.core.capture.ProbeStep
import com.fischa.core.capture.ProjectionState
import com.fischa.core.capture.ServiceState
import com.fischa.core.config.AppConfig
import com.fischa.core.log.LogSink
import com.fischa.core.log.Tags
import com.fischa.core.log.ThrottledLog
import com.fischa.core.pipeline.PipelineInput
import com.fischa.core.pipeline.VisionPipeline
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.RealInputPolicy
import com.fischa.core.safety.RobloxForegroundStatus
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Owns the whole capture lifecycle (V6 spec §3/§4/§6) plus the Firefox core loop, centralized
 * safety signals and the Android input lifecycle. Real input is session-scoped and false unless the
 * user explicitly enabled it in the UI.
 *
 * V5 → V6 MediaProjection fix (Galaxy A22 / Android 13):
 *  - V5 created the MediaProjection **in the Activity** and only then started the foreground
 *    service. Since Android 10 (required ordering documented for API 34+) `getMediaProjection()`
 *    may only be called while a foreground service **with type `mediaProjection` is already
 *    running**. The Activity call therefore threw `SecurityException` (or returned null), and V5
 *    collapsed that into the generic toast "MediaProjection indisponível — tente novamente".
 *  - V6 order is deterministic and matches the platform requirement:
 *      consent (Activity Result) → startForegroundService → startForeground(type=mediaProjection)
 *      → getMediaProjection(resultCode, data) → registerCallback → ImageReader → VirtualDisplay
 *      → first frame → RUNNING.
 *  - Every step records its outcome and the **original exception** in a [CaptureAttempt]; the UI can
 *    show a friendly sentence, but class + message + stack are always preserved and logged.
 */
class FischEngineService : Service() {
    companion object {
        const val ACTION_START = "com.fischa.app.START"
        /** V6 alias of [ACTION_START] with explicit semantics (start capture + WAITING_FOR_ROD). */
        const val ACTION_START_CAPTURE = "com.fischa.app.START_CAPTURE"
        /** V6 §18 — infrastructure-only diagnostic; never fishes and never enables input. */
        const val ACTION_DIAGNOSE_CAPTURE = "com.fischa.app.DIAGNOSE_CAPTURE"
        const val ACTION_STOP = "com.fischa.app.STOP"
        const val ACTION_EMERGENCY = "com.fischa.app.EMERGENCY"
        const val ACTION_CLEAR_EMERGENCY = "com.fischa.app.CLEAR_EMERGENCY"
        const val ACTION_DEBUG_OVERLAY = "com.fischa.app.DEBUG_OVERLAY"
        const val EXTRA_DEBUG_ENABLED = "debugEnabled"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        const val EXTRA_REAL_INPUT = "realInput"
        const val EXTRA_CONSENT_SOURCE = "consentSource"
        const val CHANNEL_ID = "fisch-engine"
        const val NOTIFICATION_ID = 42
        const val REPORT_FILE = "diagnostico_captura_v6.txt"
        const val LOG_FILE = "fisch-log.txt"
        private const val IDLE_SLEEP_MS = 250L

        @Volatile var status: StatusSnapshot = StatusSnapshot()
        @Volatile private var accessibilityEmergency: ((String) -> Unit)? = null

        fun prefs(c: Context): SharedPreferences =
            c.getSharedPreferences("fisch-config", Context.MODE_PRIVATE)

        fun uiPrefs(c: Context): SharedPreferences =
            c.getSharedPreferences("fisch-ui", Context.MODE_PRIVATE)

        fun loadConfig(c: Context): AppConfig {
            val map = HashMap<String, String>()
            val all = prefs(c).all
            for (key in all.keys) map[key] = all[key].toString()
            return AppConfig().withOverrides(map)
        }

        fun triggerEmergencyFromAccessibility(reason: String) {
            runCatching { accessibilityEmergency?.invoke(reason) }
        }

        /**
         * V6 spec §2/§20 — device identity recorded with every capture attempt. The build targets the
         * Samsung Galaxy A22 (SM-A225M, Android 13/API 33), so these values are logged verbatim
         * instead of being guessed.
         */
        fun readDeviceProfile(context: Context): DeviceProfile {
            val geometry = runCatching { ScreenGeometry.read(context) }.getOrNull()
            val pm = context.packageManager
            var versionName = ""
            var versionCode = 0L
            var targetSdk = 0
            runCatching {
                val info = pm.getPackageInfo(context.packageName, 0)
                versionName = info.versionName.orEmpty()
                versionCode = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else @Suppress("DEPRECATION") info.versionCode.toLong()
                targetSdk = info.applicationInfo?.targetSdkVersion ?: 0
            }
            return DeviceProfile(
                sdkInt = Build.VERSION.SDK_INT,
                manufacturer = Build.MANUFACTURER.orEmpty(),
                model = Build.MODEL.orEmpty(),
                device = Build.DEVICE.orEmpty(),
                product = Build.PRODUCT.orEmpty(),
                screenWidth = geometry?.width ?: 0,
                screenHeight = geometry?.height ?: 0,
                densityDpi = geometry?.densityDpi ?: 0,
                rotation = geometry?.rotation ?: 0,
                locale = context.resources.configuration.locales[0]?.toString().orEmpty(),
                appVersionName = versionName,
                appVersionCode = versionCode,
                targetSdk = targetSdk,
            )
        }
    }

    data class StatusSnapshot(
        val running: Boolean = false,
        val state: String = "IDLE",
        val fps: Float = 0f,
        val procMs: Float = 0f,
        val barLocked: Boolean = false,
        val globalConf: Float = 0f,
        val denyReason: String = "",
        val emergency: Boolean = false,
        val lastLogLine: String = "",
        val foregroundPackage: String = RobloxForegroundStatus.UNKNOWN,
        val foregroundActivityWindow: String = RobloxForegroundStatus.UNKNOWN,
        val robloxDetected: Boolean = false,
        val inputAuthorized: Boolean = false,
        val foregroundBlockReason: String = "FOREGROUND_UNKNOWN",
        val foregroundTimestampMs: Long = 0L,
        /** V6 §14: [FrameAge.NONE] (-1) when no frame exists; never Long.MAX_VALUE. */
        val frameAgeMs: Long = FrameAge.NONE,
        val message: String = "Parado",
        val realInputEnabled: Boolean = false,
        val droppedFrames: Long = 0L,
        val gatedFrames: Long = 0L,
        val geometry: String = "",
        val evidenceSource: String = "NONE",
        val foregroundAgeMs: Long = Long.MAX_VALUE,
        // V5 rod-button gate (spec §3/§4/§20)
        val rodDetected: Boolean = false,
        val rodConfidence: Float = 0f,
        val rodConfirmed: Boolean = false,
        val castAuthorized: Boolean = false,
        val castGateReason: String = "",
        // ---- V7 §2…§6: auto-calibrated rod detection ----
        val rodState: String = "INIT",
        val rodScore: Float = 0f,
        val rodCandidates: Int = 0,
        val rodTracking: Boolean = false,
        val rodCalibrationDone: Boolean = false,
        val rodCalibration: String = "",
        val rodRoi: String = "",
        val rodReason: String = "",
        // ---- V6 capture diagnostics (spec §8/§17) ----
        val captureState: String = CaptureState.STOPPED.name,
        val captureReason: String = "init",
        val projectionState: String = ProjectionState.NONE.name,
        val serviceState: String = ServiceState.STOPPED.name,
        val lastCaptureError: String = "",
        val lastCaptureErrorTechnical: String = "",
        val framesReceived: Long = 0L,
        val framesProcessed: Long = 0L,
        val framesDropped: Long = 0L,
        val firstFrameLatencyMs: Long = -1L,
        val deviceDescription: String = "",
        val diagnosticMode: Boolean = false,
        val diagnosticReport: String = "",
        val reportFile: String = "",
    ) {
        /** V6 §14: never expose Long.MAX_VALUE as "frame age". */
        val frameAgeText: String get() = FrameAge.format(frameAgeMs)
    }

    /** Foreground status older than this is treated as unknown → input blocked (fail-closed). */
    private val maxForegroundAgeMs = 2_000L

    /**
     * Reads the AccessibilityService's cached status and applies the staleness rule: a cached
     * "Roblox detected" from seconds ago must never authorize a gesture now.
     */
    private fun freshForegroundStatus(): Pair<RobloxForegroundStatus, Long> {
        val raw = GameAccessibilityService.latestForegroundStatus()
        val age = (SystemClock.elapsedRealtime() - raw.timestampMs).coerceAtLeast(0L)
        if (age > maxForegroundAgeMs && (raw.robloxDetected || raw.inputAuthorized)) {
            return raw.copy(
                robloxDetected = false,
                inputAuthorized = false,
                blockReason = "FOREGROUND_STALE(${age}ms)",
            ) to age
        }
        return raw to age
    }

    inner class LocalBinder : Binder() {
        val service: FischEngineService get() = this@FischEngineService
    }

    private val binder = LocalBinder()
    private val main = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)

    private var projectionManager: MediaProjectionManager? = null
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var capture: ScreenCaptureSource? = null
    private var captureThread: HandlerThread? = null
    private var loopThread: Thread? = null
    private lateinit var log: ThrottledLog
    private lateinit var cfg: AppConfig
    private lateinit var executor: AndroidInputExecutor
    private lateinit var emergency: EmergencyStop
    private lateinit var pipeline: VisionPipeline
    private var realInputForSession = false

    /** V6 capture lifecycle (spec §8/§15) — completely independent from the fishing FSM. */
    val captureState = CaptureSessionState(clockNs = { System.nanoTime() })
    private var attempt: CaptureAttempt? = null
    private var diagnosticMode = false

    override fun onCreate() {
        super.onCreate()
        // V6 §21: the log sink exists before the engine does, so a failed capture still leaves traces
        // for the Activity to show.
        AppLog.init(this)
        cfg = loadConfig(this)
        log = ThrottledLog(AppLog.sink())
        AppLog.setVerbose(uiPrefs(this).getBoolean("verbose", false))
        executor = AndroidInputExecutor()
        emergency = EmergencyStop(prefs(this).getBoolean("emergency_latched", false))
        emergency.addListener {
            prefs(this).edit().putBoolean("emergency_latched", true).apply()
            runCatching { executor.cancelAll() }
            runCatching { executor.releaseAll() }
        }
        pipeline = buildPipeline(cfg, emergency)
        accessibilityEmergency = { reason ->
            emergency.activate(reason)
            pipeline.disarm(System.nanoTime())
            main.post { stopEngine(emergencyStop = true) }
        }
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager?
        captureState.addListener { from, to, reason ->
            AppLog.event(Tags.CAPTURE, "[CAPTURE] estado $from -> $to ($reason)")
            publishCaptureStatus()
        }
        createChannel()
        val device = readDeviceProfile(this)
        AppLog.event(Tags.SYSTEM, "[SYSTEM] V6 alvo Galaxy A22 — device ${device.describe()} " +
            "galaxyA22=${device.isLikelyGalaxyA22()} app=${device.appVersionName}(${device.appVersionCode})")
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START, ACTION_START_CAPTURE -> {
                // V7 §10: the build hard-locks real input while the detection is being validated.
                // The intent extra is honoured *only* if the policy allows it, so a stale UI state
                // or a re-delivered intent can never sneak a gesture through.
                realInputForSession = intent.getBooleanExtra(EXTRA_REAL_INPUT, false) &&
                    RealInputPolicy.allows()
                return startCaptureSession(intent, diagnosticOnly = false)
            }
            ACTION_DIAGNOSE_CAPTURE -> {
                // V6 §18: infrastructure only — input stays OFF and the fishing FSM stays IDLE.
                realInputForSession = false
                return startCaptureSession(intent, diagnosticOnly = true)
            }
            ACTION_EMERGENCY -> {
                emergency.activate("notification action")
                pipeline.disarm(System.nanoTime())
                stopEngine(emergencyStop = true, reason = "EMERGENCY STOP")
            }
            ACTION_STOP -> stopEngine(emergencyStop = false, reason = "STOP do usuário")
            ACTION_CLEAR_EMERGENCY -> clearEmergency()
            ACTION_DEBUG_OVERLAY -> setDebugOverlay(intent.getBooleanExtra(EXTRA_DEBUG_ENABLED, false))
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        stopEngine(emergencyStop = false, reason = "onDestroy")
        runCatching { pipeline.close() }
        accessibilityEmergency = null
        DiagnosticsLog.bind(null)
        AppLog.flushAndClose()
        super.onDestroy()
    }

    private fun buildPipeline(config: AppConfig, stop: EmergencyStop) = VisionPipeline(
        cfg = config,
        executor = executor,
        log = log,
        emergency = stop,
        foregroundStatusProvider = { GameAccessibilityService.latestForegroundStatus() },
    )

    // =====================================================================================
    // V6 capture session
    // =====================================================================================

    /**
     * Deterministic capture start (V6 spec §3/§4/§5). Runs for both [ACTION_START] (fishing
     * session) and [ACTION_DIAGNOSE_CAPTURE] (infrastructure only). Returns the start flags for the
     * service; the heavy lifting is expressed as [com.fischa.core.capture.CaptureProbe] steps so the
     * same sequence is unit-tested in core.
     */
    private fun startCaptureSession(intent: Intent, diagnosticOnly: Boolean): Int {
        if (captureState.holdsResources()) {
            AppLog.event(Tags.CAPTURE, "[CAPTURE] START ignorado: captura já ativa (${captureState.state})")
            return START_NOT_STICKY
        }
        diagnosticMode = diagnosticOnly
        val device = readDeviceProfile(this)
        val newAttempt = CaptureAttempt(device = device, mode = if (diagnosticOnly) "DIAGNOSTIC" else "START")
        attempt = newAttempt
        CaptureAttemptRegistry.publish(newAttempt)
        captureState.requestPermission(if (diagnosticOnly) "diagnóstico de captura" else "START")

        val manager = projectionManager
        newAttempt.managerPresent = manager != null

        // ---- consent: extras first, parked consent as ROM-safe fallback -------------------
        var consentSource = "extras"
        var resultCode = if (intent.hasExtra(EXTRA_RESULT_CODE)) intent.getIntExtra(EXTRA_RESULT_CODE, Int.MIN_VALUE) else null
        var data: Intent? = IntentCompat.getParcelableExtra(intent, EXTRA_RESULT_DATA, Intent::class.java)
        if (data == null || resultCode == null) {
            val parked = CaptureConsentHolder.take()
            if (parked != null) {
                resultCode = parked.first
                data = parked.second
                consentSource = "holder"
            }
        }
        if (consentSource == "extras" && data != null) {
            // Primary handoff worked: drop the parked fallback so no stale token can be reused.
            CaptureConsentHolder.clear()
        }
        newAttempt.startedFromActivity = consentSource
        newAttempt.resultCode = resultCode
        newAttempt.dataPresent = data != null

        // Android 15 (API 35) additionally requires getMediaProjection() to run while an Activity is
        // visible; the A22 target is API 33, so this only matters if the APK is installed on a newer
        // phone. It is logged (never hidden) so the next iteration has the exact evidence.
        if (Build.VERSION.SDK_INT >= 35) {
            AppLog.event(
                Tags.MEDIA_PROJECTION,
                "[MEDIA_PROJECTION] aviso: sdk=${Build.VERSION.SDK_INT} >= 35 — se getMediaProjection falhar, " +
                    "o Android 15 exige Activity visível durante a chamada (limitação conhecida; ver docs/LIMITATIONS)",
            )
        }
        val evaluation = CaptureConsentPolicy.evaluate(
            resultCode = resultCode,
            dataPresent = data != null,
            managerPresent = manager != null,
        )
        AppLog.event(Tags.MEDIA_PROJECTION, "[MEDIA_PROJECTION] ${evaluation.logLine} source=$consentSource")
        if (!CaptureConsentPolicy.mayStartCapture(evaluation)) {
            captureState.permissionDenied(evaluation.reason)
            newAttempt.markStage(CaptureStage.CONSENT)
            newAttempt.hint = evaluation.reason
            newAttempt.elapsedMs = 0L
            AppLog.block(Tags.MEDIA_PROJECTION, newAttempt.formatBlock())
            publishAttempt(newAttempt, evaluation.friendlyMessage())
            // Never declare a capture that did not happen (spec §5/§8).
            stopSelf()
            return START_NOT_STICKY
        }
        captureState.authorized()

        // ---- everything else happens through the probe so both modes share one code path ----
        var keepAlive = !diagnosticOnly
        val runStartedNs = System.nanoTime()
        val captureWorkerHolder = arrayOfNulls<HandlerThread>(1)
        val sourceHolder = arrayOfNulls<ScreenCaptureSource>(1)

        fun track(step: ProbeStep): ProbeStep {
            if (!step.ok) keepAlive = false
            return step
        }

        val probe = ServiceCaptureProbe(
            managerStep = {
                val present = manager != null
                track(
                    ProbeStep(
                        CaptureStage.MANAGER, present,
                        if (present) "MediaProjectionManager disponível" else "getSystemService(MEDIA_PROJECTION_SERVICE) = null",
                        if (present) null else com.fischa.core.capture.CapturedException.from(
                            NullPointerException("MediaProjectionManager ausente neste aparelho"),
                        ),
                    ),
                )
            },
            consentStep = {
                track(ProbeStep(CaptureStage.CONSENT, true, evaluation.logLine))
            },
            foregroundStep = {
                captureState.serviceStarting()
                try {
                    startForegroundWithNotification()
                    newAttempt.serviceStarted = true
                    newAttempt.foregroundStarted = true
                    newAttempt.notificationPosted = true
                    newAttempt.foregroundType = "mediaProjection"
                    captureState.serviceRunning()
                    AppLog.event(
                        Tags.FOREGROUND_SERVICE,
                        "[FOREGROUND_SERVICE] startForeground(id=$NOTIFICATION_ID, type=mediaProjection) OK sdk=${Build.VERSION.SDK_INT}",
                    )
                    track(ProbeStep(CaptureStage.FOREGROUND, true, "startForeground type=mediaProjection OK"))
                } catch (t: Throwable) {
                    newAttempt.serviceStarted = false
                    newAttempt.foregroundStarted = false
                    newAttempt.startForegroundException = com.fischa.core.capture.CapturedException.from(t)
                    newAttempt.capture(t, "startForeground(id=$NOTIFICATION_ID, FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)")
                    AppLog.failure(
                        Tags.FOREGROUND_SERVICE,
                        "[FOREGROUND_SERVICE] startForeground rejeitado (sdk=${Build.VERSION.SDK_INT} " +
                            "manifest type=mediaProjection)",
                        t,
                    )
                    track(
                        ProbeStep(
                            CaptureStage.FOREGROUND, false, "startForeground rejeitado",
                            com.fischa.core.capture.CapturedException.from(t),
                        ),
                    )
                }
            },
            projectionStep = {
                val m = manager
                if (m == null) {
                    track(
                        ProbeStep(
                            CaptureStage.GET_PROJECTION, false, "sem MediaProjectionManager",
                            com.fischa.core.capture.CapturedException.from(
                                NullPointerException("MediaProjectionManager ausente"),
                            ),
                        ),
                    )
                } else {
                    try {
                        // Android 10+ / documented for U+: the foreground service with type
                        // mediaProjection MUST already be running here, which is exactly the V5 bug.
                        val proj = m.getMediaProjection(resultCode!!, data!!)
                        if (proj == null) {
                            val e = IllegalStateException(
                                "getMediaProjection retornou null (resultCode=$resultCode dataPresent=true " +
                                    "foregroundService=true)",
                            )
                            newAttempt.projectionCreated = false
                            newAttempt.capture(e, "getMediaProjection(null)")
                            AppLog.failure(Tags.MEDIA_PROJECTION, "[MEDIA_PROJECTION] getMediaProjection devolveu null", e)
                            track(ProbeStep(CaptureStage.GET_PROJECTION, false, "getMediaProjection = null", com.fischa.core.capture.CapturedException.from(e)))
                        } else {
                            val callback = object : MediaProjection.Callback() {
                                override fun onStop() {
                                    onProjectionStoppedBySystem()
                                }
                            }
                            proj.registerCallback(callback, main)
                            projectionCallback = callback
                            projection = proj
                            newAttempt.projectionCreated = true
                            newAttempt.projectionCallbackRegistered = true
                            captureState.projectionActive()
                            AppLog.event(
                                Tags.MEDIA_PROJECTION,
                                "[MEDIA_PROJECTION] sessão criada; callback registrado antes do VirtualDisplay (requisito API 34+)",
                            )
                            // HandlerThread + capture source are created only after the projection
                            // exists, so no invalid object is ever reused (spec §6).
                            val worker = HandlerThread("FischCapture").apply { start() }
                            captureWorkerHolder[0] = worker
                            captureThread = worker
                            val src = ScreenCaptureSource(
                                context = this@FischEngineService,
                                projection = proj,
                                captureHandler = Handler(worker.looper),
                                cfg = cfg.capture,
                                onCaptureFailure = { message -> handleCaptureError(CaptureStage.NONE, null, message) },
                                onCaptureFailureDetailed = { stage, t, hint -> handleCaptureFailure(stage, t, hint) },
                            )
                            sourceHolder[0] = src
                            capture = src
                            track(ProbeStep(CaptureStage.GET_PROJECTION, true, "MediaProjection ativa + callback + capture source"))
                        }
                    } catch (t: Throwable) {
                        newAttempt.projectionCreated = false
                        newAttempt.capture(t, "getMediaProjection(resultCode, data) com FGS mediaProjection ativa")
                        AppLog.failure(
                            Tags.MEDIA_PROJECTION,
                            "[MEDIA_PROJECTION] getMediaProjection lançou exceção " +
                                "(resultCode=$resultCode dataPresent=${data != null} fgs=true)",
                            t,
                        )
                        track(ProbeStep(CaptureStage.GET_PROJECTION, false, "getMediaProjection lançou exceção", com.fischa.core.capture.CapturedException.from(t)))
                    }
                }
            },
            imageReaderStep = {
                val src = sourceHolder[0]
                if (src == null) {
                    track(ProbeStep(CaptureStage.IMAGE_READER, false, "capture source inexistente (projeção falhou antes)"))
                } else {
                    val ok = src.createImageReader(newAttempt)
                    track(
                        ProbeStep(
                            CaptureStage.IMAGE_READER, ok,
                            if (ok) "ImageReader ${src.readerWidth}x${src.readerHeight} RGBA_8888 maxImages=${src.readerMaxImages}"
                            else "ImageReader falhou: ${newAttempt.exceptionClass}: ${newAttempt.exceptionMessage}",
                            if (ok) null else com.fischa.core.capture.CapturedException(
                                newAttempt.exceptionClass.ifEmpty { "java.lang.IllegalStateException" },
                                newAttempt.exceptionMessage,
                                newAttempt.exceptionStack,
                            ),
                        ),
                    )
                }
            },
            virtualDisplayStep = {
                val src = sourceHolder[0]
                if (src == null) {
                    track(ProbeStep(CaptureStage.VIRTUAL_DISPLAY, false, "capture source inexistente"))
                } else {
                    val ok = src.createVirtualDisplay(newAttempt)
                    if (ok) src.markHealthy()
                    track(
                        ProbeStep(
                            CaptureStage.VIRTUAL_DISPLAY, ok,
                            if (ok) "VirtualDisplay ${src.frameWidth}x${src.frameHeight} dpi=${if (src.geometryReady) src.geometry.densityDpi else 0}" +
                                " surface=ImageReader"
                            else "VirtualDisplay falhou: ${newAttempt.exceptionClass}: ${newAttempt.exceptionMessage}",
                            if (ok) null else com.fischa.core.capture.CapturedException(
                                newAttempt.exceptionClass.ifEmpty { "java.lang.IllegalStateException" },
                                newAttempt.exceptionMessage,
                                newAttempt.exceptionStack,
                            ),
                        ),
                    )
                }
            },
            firstFrameStep = { timeoutMs ->
                val src = sourceHolder[0]
                if (src == null) {
                    track(ProbeStep(CaptureStage.FIRST_FRAME, false, "capture source inexistente"))
                } else {
                    val step = src.awaitFirstFrame(timeoutMs)
                    newAttempt.firstFrameReceived = step.ok
                    newAttempt.firstFrameLatencyMs = src.firstFrameLatencyMs
                    track(step)
                }
            },
            teardown = {
                if (!keepAlive) {
                    AppLog.event(Tags.CAPTURE, "[CAPTURE] teardown do diagnóstico/sessão falha (keepAlive=false)")
                    shutdownCapture()
                } else {
                    AppLog.event(Tags.CAPTURE, "[CAPTURE] sessão mantida viva após o start (captura RUNNING)")
                }
            },
        )

        val report = CaptureDiagnostics.run(
            probe = probe,
            device = device,
            startedNs = runStartedNs,
            nowNs = { System.nanoTime() },
            timeoutMs = cfg.capture.firstFrameTimeoutMs,
            fps = { capture?.effectiveFps?.toFloat() ?: 0f },
            frameAgeMs = { capture?.frameAgeMs() ?: FrameAge.NONE },
            framesReceived = { capture?.receivedFrames ?: 0L },
            framesProcessed = { capture?.producedFrames ?: 0L },
            attemptBlock = { newAttempt.formatBlock() },
        )

        newAttempt.framesReceived = capture?.receivedFrames ?: 0L
        newAttempt.framesProcessed = capture?.producedFrames ?: 0L
        newAttempt.framesDropped = capture?.droppedFrames ?: 0L
        newAttempt.fps = capture?.effectiveFps?.toFloat() ?: 0f
        newAttempt.frameAgeMs = capture?.frameAgeMs() ?: FrameAge.NONE
        newAttempt.elapsedMs = (System.nanoTime() - runStartedNs) / 1_000_000L
        AppLog.block(Tags.MEDIA_PROJECTION, newAttempt.formatBlock())

        if (!report.success()) {
            // V6 §1: keep the original exception; the UI shows a friendly line plus the technical one.
            val failure = captureState.lastFailure
            val technical = failure?.let { CaptureErrorText.technicalLine(it) } ?: report.failedStep?.let {
                "${it.stage.name}: ${it.exception?.oneLine() ?: it.detail}"
            } ?: "critérios de sucesso §20 não atingidos"
            captureState.fail(
                report.failedStep?.stage ?: CaptureStage.NONE,
                IllegalStateException("capture not running: $technical"),
                CaptureErrorText.retryHint(failure ?: com.fischa.core.capture.CaptureFailure(
                    report.failedStep?.stage ?: CaptureStage.NONE,
                    com.fischa.core.capture.CapturedException(IllegalStateException::class.java.name, technical, emptyList()),
                )),
            )
            AppLog.event(Tags.CAPTURE, "[CAPTURE] FALHOU — $technical")
            AppLog.block(Tags.CAPTURE, report.format())
            publishAttempt(newAttempt, "Captura NÃO iniciou — $technical")
            writeReport(report.format())
            releaseAllCaptureResources()
            stopSelf()
            return START_NOT_STICKY
        }

        if (diagnosticOnly) {
            // §18/§20: report, then release everything (no fishing, no input, no FSM).
            AppLog.event(Tags.CAPTURE, "[CAPTURE] DIAGNÓSTICO OK — captura RUNNING, primeiro frame recebido")
            AppLog.block(Tags.CAPTURE, report.format())
            CaptureAttemptRegistry.publishReport(report)
            writeReport(report.format())
            val frames = capture?.producedFrames ?: 0L
            publishAttempt(newAttempt, "DIAGNÓSTICO OK: captura RUNNING, $frames frames, primeiro frame em ${newAttempt.firstFrameLatencyMs}ms")
            captureState.stopped("diagnóstico concluído")
            releaseAllCaptureResources()
            stopSelf()
            return START_NOT_STICKY
        }

        // ---- fishing session: capture is RUNNING → arm the pipeline in WAITING_FOR_ROD --------
        val src = sourceHolder[0] ?: run {
            publishAttempt(newAttempt, "capture source ausente")
            stopSelf()
            return START_NOT_STICKY
        }
        captureState.running("primeiro frame recebido")
        AppLog.event(
            Tags.CAPTURE,
            "[CAPTURE] RUNNING — ${src.frameWidth}x${src.frameHeight} primeiro frame em ${src.firstFrameLatencyMs}ms " +
                "fps=${src.effectiveFps} frameAge=${FrameAge.format(src.frameAgeMs())}",
        )
        return armFishingSession(src, newAttempt)
    }

    /** Publishes the capture status even when the fishing loop is not running yet. */
    private fun publishCaptureStatus() {
        val snapshot: CaptureStateSnapshot = captureState.snapshot()
        status = status.copy(
            captureState = snapshot.state.name,
            captureReason = snapshot.reason,
            projectionState = snapshot.projection.name,
            serviceState = snapshot.service.name,
            lastCaptureError = snapshot.failure?.summary().orEmpty(),
            lastCaptureErrorTechnical = snapshot.failure?.let { CaptureErrorText.technicalLine(it) } ?: "",
            diagnosticMode = diagnosticMode,
        )
    }

    private fun publishAttempt(newAttempt: CaptureAttempt, message: String) {
        CaptureAttemptRegistry.publish(newAttempt)
        publishCaptureStatus()
        status = status.copy(
            message = message,
            framesReceived = newAttempt.framesReceived,
            framesProcessed = newAttempt.framesProcessed,
            framesDropped = newAttempt.framesDropped,
            frameAgeMs = newAttempt.frameAgeMs,
            firstFrameLatencyMs = newAttempt.firstFrameLatencyMs,
            deviceDescription = newAttempt.device?.describe().orEmpty(),
            lastCaptureError = captureState.lastFailure?.summary() ?: status.lastCaptureError,
            lastCaptureErrorTechnical = captureState.lastFailure?.let { CaptureErrorText.technicalLine(it) }.orEmpty(),
            diagnosticReport = CaptureAttemptRegistry.lastReport?.format().orEmpty(),
            reportFile = reportFile().absolutePath,
        )
        AppLog.event(Tags.CAPTURE, "[CAPTURE] $message")
    }

    private fun reportFile(): File = File(filesDir, REPORT_FILE)

    private fun writeReport(content: String) {
        runCatching { reportFile().writeText(content) }
            .onFailure { AppLog.failure(Tags.CAPTURE, "[CAPTURE] não foi possível gravar ${REPORT_FILE}", it) }
    }

    private fun armFishingSession(src: ScreenCaptureSource, newAttempt: CaptureAttempt): Int {
        if (emergency.latched) {
            status = status.copy(
                running = false,
                emergency = true,
                message = "Parada de emergência travada; desarme explicitamente antes de iniciar",
            )
            releaseAllCaptureResources()
            stopSelf()
            return START_NOT_STICKY
        }
        if (running.getAndSet(true)) {
            releaseAllCaptureResources()
            return START_NOT_STICKY
        }
        cfg = loadConfig(this)
        AppLog.setVerbose(uiPrefs(this).getBoolean("verbose", false))
        AppLog.rotateIfLarge()
        runCatching { pipeline.close() }
        pipeline = buildPipeline(cfg, emergency)

        InputGeometry.publish(src.mapper, src.geometry)
        AppLog.event(Tags.CAPTURE, "[CAPTURE] display ${src.geometry.describe()}")
        AppLog.event(Tags.CAPTURE, "[CAPTURE] mapper ${src.mapper.describe()} targetFps=${cfg.capture.targetFps}")
        if (!src.mapper.isConsistent(2f)) {
            handleCaptureError(CaptureStage.NONE, null, "capture/device aspect mismatch ${src.mapper.describe()}; refusing session")
            return START_NOT_STICKY
        }
        // START never fishes (spec §9): the pipeline is armed but the FSM only leaves
        // WAITING_FOR_ROD when the rod button is visually confirmed.
        pipeline.armed = true
        setDebugOverlay(uiPrefs(this).getBoolean("overlay", false))
        status = StatusSnapshot(
            running = true,
            emergency = emergency.latched,
            realInputEnabled = realInputForSession,
            foregroundPackage = RobloxForegroundStatus.UNKNOWN,
            foregroundActivityWindow = RobloxForegroundStatus.UNKNOWN,
            foregroundBlockReason = "WAITING_FOR_ROBLOX_WINDOW",
            geometry = src.geometry.describe() + " | " + src.mapper.describe(),
            captureState = captureState.state.name,
            captureReason = captureState.lastReason,
            projectionState = captureState.projection.name,
            serviceState = captureState.service.name,
            deviceDescription = newAttempt.device?.describe().orEmpty(),
            framesReceived = src.receivedFrames,
            framesProcessed = src.producedFrames,
            framesDropped = src.droppedFrames,
            firstFrameLatencyMs = src.firstFrameLatencyMs,
            frameAgeMs = src.frameAgeMs(),
            message = "Captura RUNNING (${src.frameWidth}x${src.frameHeight}); aguardando o botão da vara",
            reportFile = reportFile().absolutePath,
        )

        val thread = Thread { loop(src) }.apply {
            name = "fisch-engine"
            priority = Thread.NORM_PRIORITY + 2
        }
        loopThread = thread
        thread.start()
        return START_NOT_STICKY
    }

    private fun loop(src: ScreenCaptureSource) {
        var prevFrameNs = 0L
        var fpsEma = 0f
        var lastDisplayCheckNs = 0L
        var lastSafetyLogNs = 0L
        var lastNoFrameLogNs = 0L
        var procEmaMs = 0f
        var lastRateAdjustNs = 0L
        var calibrationLogged = false
        while (running.get()) {
            val nowNs = System.nanoTime()
            if (nowNs - lastDisplayCheckNs >= 250_000_000L) {
                lastDisplayCheckNs = nowNs
                if (!src.displayConfigurationUnchanged()) {
                    AppLog.event(Tags.CAPTURE, "[CAPTURE] orientação/tamanho mudou; encerrando sessão")
                    pipeline.disarm(nowNs)
                    running.set(false)
                    break
                }
            }

            val frame = try { src.takeLatest() } catch (e: Exception) {
                AppLog.failure(Tags.CAPTURE, "[CAPTURE] takeLatest falhou", e)
                null
            }
            if (frame == null) {
                if (lastNoFrameLogNs == 0L || nowNs - lastNoFrameLogNs >= 1_000_000_000L) {
                    lastNoFrameLogNs = nowNs
                    log.d(Tags.CAPTURE, "waiting", "[FRAME] aguardando frame; dropped=${src.droppedFrames} age=${FrameAge.format(src.frameAgeMs(nowNs))}")
                }
                val last = src.lastFrameTimestampNs
                if (last > 0L && nowNs - last > cfg.capture.streamTimeoutMs * 1_000_000L) {
                    // V5 §13: a dead capture stream stops the session gracefully (no crash) so the
                    // user can simply press START again. V6 keeps the original cause instead of a
                    // generic message.
                    handleCaptureError(
                        CaptureStage.FIRST_FRAME,
                        IllegalStateException(
                            "frame stream timed out after ${cfg.capture.streamTimeoutMs} ms " +
                                "(received=${src.receivedFrames} produced=${src.producedFrames})",
                        ),
                        "frame stream timed out (${cfg.capture.streamTimeoutMs} ms)",
                    )
                    break
                }
                try { Thread.sleep(5) } catch (_: InterruptedException) { break }
                continue
            }

            try {
                val timestampNs = frame.timestampNs
                val ageAtStartMs = ((System.nanoTime() - timestampNs).coerceAtLeast(0L)) / 1_000_000L
                if (prevFrameNs > 0L) {
                    val delta = (timestampNs - prevFrameNs).coerceAtLeast(1L)
                    val inst = 1_000_000_000f / delta
                    fpsEma = if (fpsEma == 0f) inst else fpsEma * 0.90f + inst * 0.10f
                }
                prevFrameNs = timestampNs
                frame.fps = fpsEma
                pipeline.setFpsMeasured(fpsEma)
                log.setNow(timestampNs)

                val (foreground, foregroundAge) = freshForegroundStatus()
                val input = PipelineInput(
                    frameTimestampNs = timestampNs,
                    currentTimeNs = System.nanoTime(),
                    captureHealthy = src.captureHealthy,
                    robloxDetected = foreground.robloxDetected,
                    inputAuthorized = foreground.inputAuthorized,
                    overlaySuspected = foreground.overlayActive,
                    macroEnabled = pipeline.armed,
                    realInputEnabled = realInputForSession,
                    foregroundPackage = foreground.foregroundPackage,
                    foregroundActivityWindow = foreground.foregroundActivityWindow,
                    foregroundBlockReason = foreground.blockReason,
                    foregroundTimestampMs = foreground.timestampMs,
                    // V7 §1: the platform facts AUTO_CALIBRATION cannot measure from a frame alone
                    screenWidthPx = src.geometry.width,
                    screenHeightPx = src.geometry.height,
                    densityDpi = src.geometry.densityDpi,
                    rotationDeg = src.geometry.rotation,
                    appWindowWidthPx = src.geometry.appWindowWidth,
                    appWindowHeightPx = src.geometry.appWindowHeight,
                    statusBarPx = src.geometry.statusBarPx,
                    navBarPx = src.geometry.navBarPx,
                )
                try {
                    pipeline.onFrame(frame, input)
                } catch (e: Exception) {
                    AppLog.failure(Tags.ERROR, "[ERROR] pipeline step lançou exceção", e)
                    emergency.activate("pipeline exception")
                    running.set(false)
                }

                val out = pipeline.output
                status = StatusSnapshot(
                    running = running.get(),
                    state = out.state.name,
                    fps = fpsEma,
                    procMs = pipeline.render?.procMs ?: 0f,
                    barLocked = out.barLocked,
                    globalConf = out.globalConfidence,
                    denyReason = out.inputDeniedReason.ifEmpty {
                        pipeline.render?.safetyBlockedReason.orEmpty()
                    },
                    emergency = emergency.latched,
                    lastLogLine = AppLog.tail(),
                    foregroundPackage = out.foregroundPackage,
                    foregroundActivityWindow = out.foregroundActivityWindow,
                    robloxDetected = out.robloxDetected,
                    inputAuthorized = out.inputAuthorized,
                    foregroundBlockReason = out.foregroundBlockReason,
                    foregroundTimestampMs = input.foregroundTimestampMs,
                    frameAgeMs = ageAtStartMs,
                    realInputEnabled = out.realInputEnabled,
                    droppedFrames = src.droppedFrames,
                    gatedFrames = src.gatedFrames,
                    geometry = status.geometry,
                    evidenceSource = foreground.evidenceSource,
                    foregroundAgeMs = foregroundAge,
                    rodDetected = out.rodDetected,
                    rodConfidence = out.rodConfidence,
                    rodConfirmed = out.rodConfirmed,
                    castAuthorized = out.castAuthorized,
                    castGateReason = out.castGateReason,
                    rodState = out.rodState,
                    rodScore = out.rodScore,
                    rodCandidates = out.rodCandidates,
                    rodTracking = out.rodTracking,
                    rodCalibrationDone = out.rodCalibrationDone,
                    rodCalibration = out.rodCalibration,
                    rodReason = out.rodReason,
                    rodRoi = if (out.rodTracking || out.rodState == "ROD_CONFIRMED") {
                        "(${(out.rodRoiNorm[0] * src.geometry.width).toInt()},${(out.rodRoiNorm[1] * src.geometry.height).toInt()}," +
                            "${((out.rodRoiNorm[2] - out.rodRoiNorm[0]) * src.geometry.width).toInt()}," +
                            "${((out.rodRoiNorm[3] - out.rodRoiNorm[1]) * src.geometry.height).toInt()})"
                    } else "",

                    captureState = captureState.state.name,
                    captureReason = captureState.lastReason,
                    projectionState = captureState.projection.name,
                    serviceState = captureState.service.name,
                    lastCaptureError = captureState.lastFailure?.summary().orEmpty(),
                    lastCaptureErrorTechnical = captureState.lastFailure?.let { CaptureErrorText.technicalLine(it) }.orEmpty(),
                    framesReceived = src.receivedFrames,
                    framesProcessed = src.producedFrames,
                    firstFrameLatencyMs = src.firstFrameLatencyMs,
                    deviceDescription = status.deviceDescription,
                    diagnosticMode = diagnosticMode,
                    reportFile = reportFile().absolutePath,
                )
                if (timestampNs - lastSafetyLogNs >= 1_000_000_000L || lastSafetyLogNs == 0L) {
                    lastSafetyLogNs = timestampNs
                    log.i(
                        Tags.SAFETY,
                        "status",
                        "[SAFETY] state=${out.state.name} frameAge=${FrameAge.format(ageAtStartMs)} " +
                            "fps=${"%.1f".format(fpsEma)} robDlg=${out.robloxDetected} inputAuthorized=${out.inputAuthorized} " +
                            "rodDetected=${out.rodDetected} rodConfirmed=${out.rodConfirmed} " +
                            "frames rx=${src.receivedFrames} proc=${src.producedFrames} drop=${src.droppedFrames} gated=${src.gatedFrames} " +
                            "capture=${captureState.state.name} projection=${captureState.projection.name} " +
                            "package=${out.foregroundPackage} timestamp=${foreground.timestampMs}",
                    )
                    log.i(
                        Tags.ROD_FINDER,
                        "v7",
                        "[ROD_FINDER] STATE=${out.rodState} score=${"%.2f".format(out.rodScore)} " +
                            "candidates=${out.rodCandidates} conf=${"%.2f".format(out.rodConfidence)} " +
                            "tracking=${out.rodTracking} confirm=${out.rodStreak}/${out.rodRequiredFrames} " +
                            "lost=${out.rodLostMs}ms roi=${out.rodRoiNorm.map { "%.3f".format(it) }} " +
                            "layers[V=${out.layerVision} D=${out.layerDetection} DEC=${out.layerDecision} IN=${out.layerInput}] " +
                            "reason=${out.rodReason}",
                    )
                    if (out.rodCalibrationDone && out.rodCalibration.isNotEmpty() && !calibrationLogged) {
                        calibrationLogged = true
                        AppLog.event(Tags.CALIBRATION, "[CALIBRATION] ${out.rodCalibration}")
                    }
                    log.i(
                        Tags.CAPTURE,
                        "stats",
                        "[CAPTURE] fps=${"%.1f".format(fpsEma)} proc=${"%.1f".format(pipeline.render?.procMs ?: 0f)}ms " +
                            "frameAge=${FrameAge.format(ageAtStartMs)} produced=${src.producedFrames} dropped=${src.droppedFrames} gated=${src.gatedFrames}",
                    )
                }
                GameAccessibilityService.instance?.updateDebugOverlay(pipeline.render)
                // Adaptive capture rate (V5 §12) — bounded to [12, targetFps].
                val procMsNow = pipeline.render?.procMs ?: 0f
                procEmaMs = if (procEmaMs == 0f) procMsNow else procEmaMs * 0.9f + procMsNow * 0.1f
                if (timestampNs - lastRateAdjustNs >= 1_000_000_000L) {
                    lastRateAdjustNs = timestampNs
                    val sustainable = if (procEmaMs > 1f) (800f / procEmaMs).toInt() else cfg.capture.targetFps
                    val wanted = sustainable.coerceIn(12, cfg.capture.targetFps)
                    if (wanted != src.effectiveFps) {
                        src.setRateLimit(wanted)
                        log.i(Tags.CAPTURE, "rate", "[CAPTURE] adaptive rate -> $wanted fps (proc=${"%.1f".format(procEmaMs)}ms)")
                    }
                }
                // Duty cycle (spec §12): while Roblox is not the authorized foreground app there is
                // nothing to control — idle at ~4 FPS instead of burning the A22's CPU. Note that
                // this throttles *processing* only: capture keeps running so the diagnostics screen
                // always has a valid frame (V6 §13).
                if (!foreground.inputAuthorized) {
                    Thread.sleep(IDLE_SLEEP_MS)
                } else {
                    val targetMs = if (fpsEma > 5f) (1000f / fpsEma).toLong() else 33L
                    val spentMs = ((System.nanoTime() - timestampNs) / 1_000_000L).coerceAtLeast(0L)
                    val sleepMs = targetMs - spentMs
                    if (sleepMs in 1..30) Thread.sleep(sleepMs)
                }
            } catch (e: Exception) {
                AppLog.failure(Tags.ERROR, "[ERROR] frame loop falhou", e)
                emergency.activate("engine loop exception")
                running.set(false)
            } finally {
                src.release(frame)
            }
        }
        shutdownCapture()
        status = status.copy(
            running = false,
            inputAuthorized = false,
            emergency = emergency.latched,
            captureState = captureState.state.name,
            projectionState = captureState.projection.name,
            serviceState = captureState.service.name,
        )
        main.post {
            runCatching { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE) }
            if (emergency.latched) stopSelf()
        }
    }

    /** Projection ended by the system (spec §6): release, mark capture false, allow a clean retry. */
    private fun onProjectionStoppedBySystem() {
        attempt?.projectionStoppedBySystem = true
        AppLog.event(Tags.MEDIA_PROJECTION, "[MEDIA_PROJECTION] onStop do sistema: projetando encerrada")
        captureState.projectionStopped("MediaProjection.onStop (sistema)")
        // V6 intentional change vs V5 (which latched the emergency stop here): the user must be able
        // to press START again without clearing a latch (spec §6 "permitir nova tentativa limpa").
        stopEngine(
            emergencyStop = false,
            captureError = null,
            reason = "MediaProjection encerrada pelo sistema",
            message = "Captura encerrada pelo sistema (MediaProjection onStop). Pode iniciar novamente.",
        )
    }

    /**
     * V6 §13: capture failures never mask the cause and never latch the emergency stop — they log
     * everything (exception, stack, stage, state), release the resources and leave the app open so
     * the user can press START again. The fishing FSM is deliberately *not* switched to an error
     * state: a MediaProjection failure is not a fishing failure (spec §15).
     */
    private fun handleCaptureError(stage: CaptureStage, cause: Throwable?, message: String) {
        val ts = SystemClock.elapsedRealtime()
        val effectiveStage = if (stage == CaptureStage.NONE) CaptureStage.FRAME_COPY else stage
        val throwable = cause ?: IllegalStateException(message)
        AppLog.event(Tags.CAPTURE, "[CAPTURE] CAPTURE ERROR: $message")
        AppLog.failure(Tags.CAPTURE, "[CAPTURE] falha na captura (stage=${effectiveStage.name})", throwable)
        AppLog.event(
            Tags.CAPTURE,
            "[CAPTURE] timestamp=${ts}ms fishingState=${pipeline.output.state.name} " +
                "captureState=${captureState.state.name} projection=${captureState.projection.name} " +
                "service=${captureState.service.name} projectionObject=${projection != null} " +
                "captureHealthy=${capture?.captureHealthy ?: false}",
        )
        captureState.fail(effectiveStage, throwable, message)
        val technical = CaptureErrorText.technicalLine(captureState.lastFailure!!)
        if (Looper.myLooper() == Looper.getMainLooper()) {
            stopEngine(emergencyStop = false, captureError = message, reason = technical, message = "CAPTURE ERROR: $technical")
        } else {
            main.post {
                stopEngine(emergencyStop = false, captureError = message, reason = technical, message = "CAPTURE ERROR: $technical")
            }
        }
    }

    /** Callback variant used by the capture thread: keeps the original exception (V6 §1). */
    private fun handleCaptureFailure(stage: CaptureStage, cause: Throwable, hint: String) {
        AppLog.failure(Tags.CAPTURE, "[CAPTURE] falha detalhada (stage=${stage.name}, hint=$hint)", cause)
        attempt?.capture(cause, hint)
        handleCaptureError(stage, cause, hint)
    }

    private fun shutdownCapture() {
        InputGeometry.clear()
        runCatching { capture?.close() }
        capture = null
        runCatching { captureThread?.quitSafely() }
        captureThread = null
        val proj = projection
        val cb = projectionCallback
        projection = null
        projectionCallback = null
        if (proj != null) {
            // Unregister first so our own stop() does not fire onStop → spurious state change.
            runCatching { cb?.let { proj.unregisterCallback(it) } }
            runCatching { proj.stop() }
            AppLog.event(Tags.MEDIA_PROJECTION, "[MEDIA_PROJECTION] sessão liberada (callback removido + stop())")
        }
    }

    /** STOP / EMERGENCY STOP path: release every capture resource (spec §6). */
    private fun releaseAllCaptureResources() {
        shutdownCapture()
    }

    private fun stopEngine(
        emergencyStop: Boolean,
        captureError: String? = null,
        reason: String = "stop",
        message: String? = null,
    ) {
        val wasRunning = running.getAndSet(false)
        runCatching { pipeline.disarm(System.nanoTime()) }
        runCatching { executor.cancelAll() }
        runCatching { executor.releaseAll() }
        val thread = loopThread
        loopThread = null
        if (thread != null && thread !== Thread.currentThread()) runCatching { thread.join(1000) }
        releaseAllCaptureResources()
        captureState.stopped(reason)
        GameAccessibilityService.instance?.setDebugOverlay(false)
        status = status.copy(
            running = false,
            inputAuthorized = false,
            realInputEnabled = false,
            emergency = emergency.latched || emergencyStop,
            state = when {
                emergencyStop -> "EMERGENCY_STOP"
                captureError != null -> status.state
                else -> status.state
            },
            captureState = captureState.state.name,
            captureReason = captureState.lastReason,
            projectionState = captureState.projection.name,
            serviceState = captureState.service.name,
            lastCaptureError = captureState.lastFailure?.summary() ?: status.lastCaptureError,
            lastCaptureErrorTechnical = captureState.lastFailure?.let { CaptureErrorText.technicalLine(it) }
                ?: status.lastCaptureErrorTechnical,
            message = message ?: when {
                captureError != null -> "CAPTURE ERROR: $captureError"
                emergencyStop -> status.message.ifEmpty { "Parado (emergência)" }
                else -> "Parado"
            },
        )
        if (emergencyStop && !emergency.latched) emergency.activate("stop")
        if (wasRunning || !status.running) runCatching { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE) }
        if (wasRunning || emergencyStop) stopSelf()
    }

    fun setDebugOverlay(enabled: Boolean) {
        // TYPE_ACCESSIBILITY_OVERLAY must be attached by the owning AccessibilityService.
        GameAccessibilityService.instance?.setDebugOverlay(enabled)
    }

    /** Explicit operator action only; clearing the latch does not re-arm the macro. */
    fun clearEmergency() {
        emergency.clear()
        prefs(this).edit().putBoolean("emergency_latched", false).apply()
        pipeline.disarm(System.nanoTime())
        status = status.copy(emergency = false, running = false, inputAuthorized = false, realInputEnabled = false)
    }

    fun applyConfig(newCfg: AppConfig) {
        cfg = newCfg
        if (running.get()) main.post { stopEngine(emergencyStop = false, reason = "config alterada") }
    }

    /**
     * V6 spec §4 — foreground service with the mediaProjection type. Called **before**
     * `getMediaProjection()`, which is the order the platform requires since Android 10 (and the
     * documented requirement for apps targeting API 34+).
     */
    private fun startForegroundWithNotification() {
        createChannel()
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, FischEngineService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stopNow = PendingIntent.getService(
            this, 2, Intent(this, FischEngineService::class.java).setAction(ACTION_EMERGENCY),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Fisch AutoBot V6 ativo")
            .setContentText("Captura local; estado WAITING_FOR_ROD; input real somente após opt-in explícito")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Parar", stopIntent)
            .addAction(android.R.drawable.ic_delete, "EMERGÊNCIA", stopNow)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 29) {
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.notification_channel), NotificationManager.IMPORTANCE_LOW),
            )
        }
    }
}
