# Firefox V3 → build Galaxy A22 — relatório de alterações

Aparelho-alvo desta etapa: **Samsung Galaxy A22** (SM-A225, 720×1600 HD+, Helio G80; o A22 5G
1080×2400 também é coberto pela mesma lógica porque toda a geometria é lida do aparelho em
runtime). Nenhuma coordenada fixa do A22 foi introduzida — só revisão da *cadeia* de
coordenadas e do custo de CPU.

## 1. Auditoria (estado encontrado)

| Área | Situação encontrada | Ação |
|---|---|---|
| Build | `app` nunca tinha sido compilado com AGP. Erro real: `MainActivity` usava `Switch(...)` com campo `SwitchCompat` (import inexistente). Core compilava. | Corrigido; build completo com AGP 8.7.3 / Kotlin 2.0.21 / JDK 17 / SDK 35. |
| Coordenadas | Captura usava `getRealSize` (tela inteira) mas o toque usava `resources.displayMetrics` do Service — em Android 11+ pode excluir barras do sistema → deslocamento de dezenas de px. Normalização era `x / frame.width` dentro do pipeline, toque era `nx * widthPixels` em outro arquivo. | Criada **uma camada única** `core/common/CoordinateMapper` (CAPTURE → NORMALIZED → DEVICE), com `ScreenGeometry` (app) como fonte única do tamanho real da tela. O engine recusa iniciar se captura e tela tiverem aspecto incompatível. |
| Captura | VirtualDisplay em resolução cheia + cópia **pixel a pixel com `ByteBuffer.get()`** (≈3,5 MB/frame em Kotlin) + Bitmap cheio + Canvas de redução. Inviável no A22. | VirtualDisplay criado **já no tamanho de processamento** (640×288 no A22 em paisagem; escala em hardware), cópia por linha via `IntBuffer`, sem Bitmap/Canvas, frames "gated" por FPS alvo, descarte latest-only preservado (`FrameBuffer`). |
| Roblox detector | Causa provável da falha no teste real: Roblox fullscreen sem *accessibility root* → fontes "vivas" nulas; a única fonte restante (último evento de janela) expirava em 3 s → `FOREGROUND_UNKNOWN` → input bloqueado. | Ver §3 abaixo. |
| Input/hold | Lógica de `continueStroke` com lease/watchdog boa. Falta de realimentação: se o Android encerrasse o hold, o pipeline continuava mandando `HOLD_EXTEND` sem dedo na tela. | `InputExecutor.holdStillActive()` + re-emissão de `HOLD_START` pelo gate de segurança. |
| Desempenho | `logSink.snapshot()` (join de 600 linhas) **por frame** no engine; `setOf(...)` alocado por chamada no guard/pipeline; overlay re-postado por frame mesmo desligado. | Corrigidos. Duty-cycle ~4 FPS quando Roblox não está autorizado em primeiro plano; taxa de captura adaptativa (12..targetFps) conforme tempo de processamento medido. |
| Logs | Sem nível; DEBUG ia para logcat sempre. | `LogRingBuffer` filtra DEBUG salvo "Log verboso" na UI; rotação do arquivo em 2 MB; novas linhas `[CAPTURE] geometry/mapper/stats`, `[SAFETY] … source= statusAge=`, `[INPUT] TAP/HOLD_START n=(…) px=(…)`. |

Arquitetura preservada: `CAPTURE → VISION → TRACKING → STATE MACHINE → CONTROLLER → SAFETY →
INPUT`. Nenhum detector, tracker, controlador, FSM, guard, overlay ou harness foi removido.

## 2. Coordenadas (spec §3)

```
ScreenGeometry.read(ctx)   → tamanho REAL do display (maximumWindowMetrics / getRealSize)
CoordinateMapper.captureSizeFor(real, processingWidth) → 640×288 (A22 4G paisagem)
VirtualDisplay(640×288)    → VisionFrame 640×288 (CAPTURE px)
pipeline: nx = x / frame.width                    (NORMALIZED)
GestureService.toPixels: mapper.normalizedToDevice(nx, ny) → px da tela real (DEVICE)
```

* `InputGeometry` publica o `CoordinateMapper` da sessão; o `GestureService` **recusa** converter
  coordenadas quando não há sessão de captura (nunca usa `displayMetrics`).
* `DebugOverlay` desenha no mesmo espaço (tamanho real, `FLAG_LAYOUT_NO_LIMITS`, cutout ALWAYS).
* Testado em `CoordinateMapperTest` (A22 paisagem/retrato, A22 5G, cantos, rejeição de valores
  inválidos, detecção de aspecto incompatível).
* Barras do sistema/edge-to-edge: a captura e o `dispatchGesture` operam ambos na tela física
  inteira; onde o Roblox desenha dentro dela é irrelevante porque a detecção é dinâmica.
* Rotação/tamanho mudando durante a sessão → sessão encerrada em estado seguro (já existia).

## 3. RobloxForegroundDetector (spec §5)

Evidências agora combinadas (fail-closed, em `core/safety/RobloxForegroundDetector.kt`):

1. **Fontes vivas** (`activeAppWindowPackage`, `rootInActiveWindowPackage`): se apontarem outro
   pacote → `FOREGROUND_PACKAGE_MISMATCH` imediato; se apontarem Roblox → detectado (`ACTIVE_WINDOW`/`ROOT`).
2. **Atividade verificada** (`lastActivityPackage/Class`): só eventos `TYPE_WINDOW_STATE_CHANGED`
   cuja classe é uma **Activity real do pacote** (confirmado via `PackageManager.getActivityInfo`)
   atualizam o "app atual". Painéis do SystemUI, toasts, IME, bolha do Game Booster **não**
   passam nessa verificação e não derrubam a evidência; qualquer Activity posterior de outro app
   (launcher, recents, chamada, nossa própria UI) a substitui. Não expira sozinha (o Roblox não
   emite eventos enquanto apenas roda) — fonte `ACTIVITY`.
3. **Evento legado** não verificado: só com ≤ 3 s de idade e sem fonte melhor (`EVENT`).
4. Sem evidência → `FOREGROUND_UNKNOWN` → bloqueado. Nunca há fallback permissivo.

Ainda exigidos para `inputAuthorized`: serviço de acessibilidade conectado, tela interativa,
nenhuma janela ativa de sistema/IME/overlay estranho (`INCOMPATIBLE_OVERLAY`).

No lado Android (`GameAccessibilityService`): reavaliação **periódica a cada 500 ms** (o status
não depende mais de eventos chegarem), cache de 80 ms para o caminho do gesto, e o engine trata
status com **idade > 2 s como não autorizado** (`FOREGROUND_STALE(...)`). Permissão
`QUERY_ALL_PACKAGES` adicionada para a verificação de Activity funcionar com qualquer app em
Android 11+ (build sideload de teste).

Registrado em log/UI/overlay: package, activity/janela, `robloxDetected`, `inputAuthorized`,
`blockReason`, `source`, timestamp e idade do status.

## 4. Input (spec §6/§7/§8)

* `tap / holdStart / holdExtend / holdRelease / cancelAll` preservados (`GestureService`, strokes
  continuados ≤ 65 ms com lease ≤ 250 ms, hold contínuo máx. 5 s, watchdog 350 ms).
* Proteções: hold preso (lease/watchdog), gesto não liberado (release 1 ms sem `willContinue`),
  serviço desconectado (`onUnbind/onDestroy/onInterrupt` → cancelAll + Emergency), Roblox saindo
  do primeiro plano (evento → cancelAll; guard por segmento), frame antigo / tracking inválido /
  confiança baixa (`InputSafetyGuard`), Emergency Stop (latch + listener → cancelAll/releaseAll).
* **Novo**: `holdStillActive()` — se a plataforma encerrou o hold, o pipeline re-emite
  `HOLD_START` (passando pelo guard) em vez de "estender" um dedo que já subiu.
* Emergency Stop: botão na notificação e na UI; latch persistido; reativação apenas pelo botão
  "Limpar latch de emergência" (não re-arma o macro).
* `realInput = OFF` por padrão; opt-in por sessão com diálogo de confirmação (inalterado).

## 5. Desempenho no A22 (spec §4/§12)

* Captura escalada em hardware; ~184 k pixels/frame copiados por linha (antes: 1,15 M pixels
  com 3 `get()` cada + Bitmap de 4,6 MB + Canvas).
* Gate de FPS na captura (frames acima do alvo nem são copiados) + taxa adaptativa pelo tempo de
  processamento medido (piso 12 FPS) + duty-cycle de 4 FPS fora do Roblox.
* ROIs dinâmicas dos detectores de peixe/bloco/progresso só rodam com barra travada (já era assim;
  verificado).
* Removidas alocações/joins por frame no engine; DEBUG filtrado.

## 6. Arquivos alterados/criados

Novos: `core/common/CoordinateMapper.kt`, `app/ScreenGeometry.kt` (+ `InputGeometry`),
`core/test/.../CoordinateMapperTest.kt`, `ControllersTest.kt`, `TrackersTest.kt`,
`EmergencyStopAndInputGateTest.kt`, `docs/CHANGES_A22.md`, `docs/INSTALL_A22.md`.

Modificados: `RobloxForegroundDetector.kt` (+teste), `InputExecutor.kt`, `VisionPipeline.kt`
(hold-lost + sem setOf por frame), `InputSafetyGuard.kt` (sem alocação por frame),
`ScreenCaptureSource.kt` (reescrito), `GameAccessibilityService.kt` (reescrito),
`GestureService.kt` (mapper + logs), `AndroidInputExecutor.kt`, `FischEngineService.kt`,
`LogRingBuffer.kt`, `DebugOverlay.kt`, `MainActivity.kt`, `AndroidManifest.xml`,
`app/build.gradle.kts` (versão 0.2.0-a22), `README.md`, `docs/TEST_RESULTS.md`, `docs/LIMITATIONS.md`.
