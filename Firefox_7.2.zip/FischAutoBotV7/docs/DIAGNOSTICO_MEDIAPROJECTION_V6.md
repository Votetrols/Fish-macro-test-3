# V6 — Diagnóstico da MediaProjection no Samsung Galaxy A22 (SM-A225M / Android 13 / API 33)

> Documento pedido pela especificação V6 §1/§2/§25.6. Descreve o problema real observado na V5,
> a causa provável com as evidências, o que a V6 mudou e o que ainda **não** foi validado em
> aparelho físico.

---

## 1. Sintoma observado na V5 (dado de campo)

Na V5, no Galaxy A22:

- a tela de diagnóstico mostrava `Acessibilidade: ON`, `Roblox: false`, `Fonte: NONE`,
  `Input autorizado: NO`, `realInput: OFF`, janela `com.fischa.app.MainActivity`,
  `Bloqueio: FOREGROUND_PACKAGE_MISMATCH`, `Captura: false`, `estado: IDLE`, `FPS: 0.0`,
  `frame age: 9223372036854775807 ms`;
- ao pressionar **START / SOLICITAR CAPTURA DE TELA** aparecia o Toast
  **“MediaProjection indisponível — tente novamente”**;
- a captura nunca chegou a `true`.

Interpretação: **nada de captura foi criado** — o serviço nem chegou a rodar (por isso
`frame age = Long.MAX_VALUE`, ou seja, “nenhum frame jamais existiu”, exibido como número).

---

## 2. Caminho de código da V5 (o que estava errado)

`app/src/main/java/com/fischa/app/MainActivity.kt` (V5), em `onActivityResult`:

```kotlin
val manager = getSystemService(MediaProjectionManager::class.java)
val projection = try {
    manager.getMediaProjection(resultCode, data)      // <— executado na ACTIVITY
} catch (e: Exception) {
    DiagnosticsLog.event("CAPTURE", "getMediaProjection failed: ${e.javaClass.simpleName}: ${e.message}")
    null                                               // <— a exceção era DESCARTADA aqui
}
if (projection == null) {
    Toast.makeText(this, "MediaProjection indisponível — tente novamente", Toast.LENGTH_LONG).show()
    return                                             // <— fim do fluxo, sem diagnóstico
}
ProjectionHolder.set(projection)                       // <— projeção criada fora do serviço
context.startForegroundService(ACTION_START …)         // <— serviço de foreground só DEPOIS
```

Consequências diretas:

1. **Ordem invertida em relação ao que a plataforma exige.** Desde o Android 10 (e documentado
   como requisito para apps que miram API 34+) o `getMediaProjection()` só pode ser chamado
   enquanto **um foreground service com type `mediaProjection` já está rodando**. A V5 fazia o
   contrário: chamava o `getMediaProjection()` na Activity, *sem* foreground service ativo.
   Referências: [MediaProjectionManager.getMediaProjection](https://developer.android.com/reference/android/media/projection/MediaProjectionManager)
   (“the app must have started the foreground service with that type before calling this API
   here, or else it'll receive a SecurityException from this API call”) e
   [Foreground service types are required (Android 14)](https://developer.android.com/about/versions/14/changes/fgs-types-required)
   (“After you have created the foreground service, you can call MediaProjectionManager.getMediaProjection()”).
   O caso clássico do mesmo erro em campo: `SecurityException: Media projections require a
   foreground service of type ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION` lançada
   dentro de `MediaProjectionManager.getMediaProjection()`.
2. **A exceção real era engolida.** O `catch` devolvia `null` e o app mostrava um texto genérico
   que não diz nada sobre a causa. Como o serviço nunca subiu, o sink de log do
   `DiagnosticsLog` também nunca existiu (ele era ligado em `FischEngineService.onCreate()`) —
   a única evidência ia para o logcat, e a tela mostrava o genérico.
3. **A projeção pertencia ao componente errado.** O objeto `MediaProjection` criado na Activity
   era repassado por um `object ProjectionHolder` (estático) para o serviço, contrariando o
   modelo determinístico pedido na spec §3 (“não permitir que a Activity tente usar uma
   MediaProjection que deveria pertencer ao serviço”).
4. **`frame age` impresso cru.** A UI imprimia `frameAgeMs` sem tratamento; o valor default do
   `PipelineOutput`/`StatusSnapshot` é `Long.MAX_VALUE`, daí o `9223372036854775807 ms` (spec §14
   proíbe exibir isso; o correto é `N/A`).

> Observação honesta: não temos o logcat do teste no A22. A causa nº 1 é a única explicação
> compatível com **todos** os sintomas (Toast genérico exatamente naquele ponto do código, nenhum
> frame, `Captura: false`, serviço ausente). A V6 corrige essa arquitetura *e* passa a registrar a
> exceção real, então na próxima execução no aparelho o diagnóstico é conclusivo: se ainda falhar,
> o app mostrará **classe + mensagem + stack** da exceção do Samsung.

---

## 3. Fluxo correto implementado na V6

```
MainActivity                          FischEngineService (dono único da captura)
────────────                          ──────────────────────────────────────────
START / DIAGNÓSTICO
  │
  ├─ createScreenCaptureIntent()
  │     registerForActivityResult(StartActivityForResult)      ← API moderna (spec §5)
  │
  ├─ resultCode == RESULT_OK && data != null ?
  │     não → log CAPTURE_PERMISSION_RESULT + mensagem específica + FIM
  │     sim → park de consentimento (fallback) + startForegroundService(ACTION_START|DIAGNOSE)
  │                                                          │
  │                                            onStartCommand
  │                                                          │
  │                                         1. avalia consentimento (CAPTURE_PERMISSION_RESULT)
  │                                         2. startForeground(id=42, type=mediaProjection)   ← FGS PRIMEIRO
  │                                         3. getMediaProjection(resultCode, data)           ← só agora
  │                                         4. registerCallback (obrigatório antes do display, U+)
  │                                         5. ImageReader.newInstance(640×288, RGBA_8888, 3)
  │                                         6. createVirtualDisplay(surface = reader.surface)
  │                                         7. espera o 1º frame (timeout capture.firstFrameTimeoutMs)
  │                                              └─ ok  → CaptureState.RUNNING
  │                                              └─ nok → CaptureState.FAILED (causa original)
  │                                         8. START  → pipeline armado, FSM = WAITING_FOR_ROD
  │                                            DIAG.  → relatório + teardown, sem input nenhum
```

Pontos-chave:

- **Um único dono**: a projeção nasce e morre dentro do serviço; a Activity não toca nela.
- **Nenhuma etapa engole exceção**: `getMediaProjection`, `startForeground`, `ImageReader.newInstance`,
  `createVirtualDisplay`, `acquireLatestImage` — cada uma tem `try/catch` que registra
  `exceptionClass`, `exceptionMessage` e stack, mais o estágio exato (`CaptureStage`).
- **A captura é infraestrutura**: ela não depende de Roblox em foreground, de `realInput`, nem da
  vara (spec §13). O que exige Roblox/`realInput` é o **input**.
- **Falha de captura ≠ falha de pesca**: uma falha de MediaProjection move apenas a máquina de
  captura (`CaptureState.FAILED`); a FSM de pesca continua em `IDLE`, e a sessão é encerrada
  liberando tudo para permitir um START limpo (spec §6/§15).

---

## 4. Bloco de diagnóstico `[MEDIA_PROJECTION]`

Toda tentativa imprime (logcat, log interno e relatório):

```
[MEDIA_PROJECTION]
sdk=33
manufacturer=samsung
model=SM-A225M
device=a22
screen=720x1600 dpi=280 rot=1
mode=START
resultCode=-1
dataPresent=true
managerPresent=true
serviceStarted=true serviceState=RUNNING
foregroundStarted=true foregroundType=mediaProjection notificationPosted=true
projectionCreated=true callbackRegistered=true projectionStoppedBySystem=false
imageReaderCreated=true 640x288 format=1 maxImages=3
virtualDisplayCreated=true 640x288 density=280 flags=AUTO_MIRROR
firstFrameReceived=true firstFrameLatencyMs=412
framesReceived=37 framesProcessed=31 framesDropped=0
fps=29.4 frameAge=33 ms
stage=FIRST_FRAME(first frame)
exceptionClass=none
exceptionMessage=none
hint=none
elapsedMs=612
```

Em caso de falha, `exceptionClass`/`exceptionMessage`/`stackTrace` trazem a exceção **original**
(ex.: `java.lang.SecurityException: Media projections require a foreground service of type …`) e a
UI mostra a linha amigável **junto** da causa técnica (`causa técnica:` na seção CAPTURA e no relatório).

---

## 5. Botão “DIAGNÓSTICO DE CAPTURA”

- Testa **somente** a infraestrutura, na ordem: `MediaProjectionManager` → consentimento →
  foreground service (type mediaProjection) → `getMediaProjection` + callback → `ImageReader` →
  `VirtualDisplay` → **primeiro frame**.
- **Não** pesca, **não** clica no Roblox, **não** liga `realInput`, **não** procura a vara.
- Ao final libera tudo (mesmo em falha) e grava `files/diagnostico_captura_v6.txt`.
- Critério de sucesso (spec §20): `Captura = RUNNING` **e** `FPS > 0` **e** frame age válido **e**
  frames recebidos > 0.

---

## 6. O que a V6 faz se o Samsung ainda recusar

Nada é escondido. O app mostra/imprime:

1. a etapa exata que falhou (`stage=VIRTUAL_DISPLAY`, `GET_PROJECTION`, `FOREGROUND`, …);
2. `exceptionClass` + `exceptionMessage` + primeiras linhas de stack da exceção do sistema;
3. o estado de cada componente (manager, serviço, foreground, projeção, callback, reader, display);
4. `resultCode` e `dataPresent` do consentimento;
5. o perfil do aparelho (`sdk`, `manufacturer`, `model`, `screen`, `dpi`, `rot`).

Passo a passo de teste e o que enviar de volta se falhar: [`COMO_TESTAR_A22_V6.md`](COMO_TESTAR_A22_V6.md).

---

## 7. Limites conhecidos desta iteração

- **Teste real no Galaxy A22 não executado neste ambiente.** Só existem: compilação, testes
  automatizados e APK válido. Nenhum resultado de captura real é inventado aqui.
- **Android 15 (API 35):** a plataforma exige que `getMediaProjection()` seja chamado com uma
  Activity visível. O alvo desta versão é o Android 13 do A22; em um aparelho com API 35 a etapa
  pode falhar — a V6 registra isso explicitamente (`aviso: sdk>=35 …`) e o bloco
  `[MEDIA_PROJECTION]` mostrará a exceção exata para a próxima iteração.
