# Relatório de testes — Fisch AutoBot V6 (0.4.0-a22)

Execução neste ambiente (sem aparelho físico):

```
JAVA_HOME=/opt/jdk17  GRADLE_USER_HOME=<cache>  ANDROID_HOME=<sdk 35>
./gradlew --no-daemon :core:test :core:selfTest :app:assembleDebug
```

| Suíte | Resultado |
|---|---|
| `:core:test` (JUnit, JVM) | **120 testes, 0 falhas, 0 erros** |
| `:core:selfTest` (harness determinístico) | **138 checks, 0 falhas** (V5: 97) |
| `:app:lintDebug` | **0 erros**, 14 avisos (todos benignos/pré-existentes) |
| `:app:assembleDebug` | **BUILD SUCCESSFUL**, APK 3.635.728 bytes |

## Detalhe por classe (`:core:test`)

| Classe | Testes | Falhas |
|---|---|---|
| CaptureDiagnosticsTest | 13 | 0 |
| RobloxForegroundDetectorTest | 12 | 0 |
| CaptureStateMachineTest | 11 | 0 |
| ControllersTest | 10 | 0 |
| StartSemanticsV5Test | 10 | 0 |
| CaptureConsentPolicyTest | 8 | 0 |
| CoordinateMapperTest | 8 | 0 |
| RodConfirmTrackerTest | 7 | 0 |
| CaptureInputSeparationTest | 6 | 0 |
| EmergencyStopAndInputGateTest | 6 | 0 |
| TrackersTest | 6 | 0 |
| FrameAgeTest | 5 | 0 |
| InputSafetyGuardTest | 5 | 0 |
| FishingStateMachineTest | 5 | 0 |
| AppConfigTest | 3 | 0 |
| GestureLeaseTest | 3 | 0 |
| FrameBufferTest | 2 | 0 |
| **TOTAL** | **120** | **0** |

## Mapeamento dos 22 testes exigidos (spec §19)

| # | Item exigido | Onde é testado | Resultado |
|---|---|---|---|
| 1 | Activity Result `RESULT_OK` | `CaptureConsentPolicyTest.resultOkProceeds` (+ `consentNeverStartsCaptureByItself`) | ✅ |
| 2 | Activity Result cancelado | `CaptureConsentPolicyTest.userCancellationIsNotAnError` | ✅ |
| 3 | `data == null` | `CaptureConsentPolicyTest.nullDataBlocksCapture` (+ `dataWithoutTokenBlocksCapture`, `missingResultCodeBlocksCapture`) | ✅ |
| 4 | MediaProjectionManager nulo | `CaptureConsentPolicyTest.missingManagerBlocksCapture` | ✅ |
| 5 | Exceção de `getMediaProjection` | `CaptureDiagnosticsTest.getMediaProjectionExceptionIsPreserved` (SecurityException real, com "requires a foreground service") | ✅ |
| 6 | Exceção de `createVirtualDisplay` | `CaptureDiagnosticsTest.createVirtualDisplayExceptionIsPreserved` | ✅ |
| 7 | ImageReader inválido | `CaptureDiagnosticsTest.invalidImageReaderFailsTheStep` | ✅ |
| 8 | `projection onStop` | `CaptureStateMachineTest.projectionStopAllowsCleanRetry` (+ `CaptureDiagnosticsTest.projectionStoppedStepMarksFailure`) | ✅ |
| 9 | STOP libera recursos | `CaptureStateMachineTest.stopReleasesAndAllowsRestart` + `CaptureDiagnosticsTest.teardownAlwaysRuns` | ✅ |
| 10 | Emergency Stop libera recursos | `CaptureStateMachineTest.emergencyStopDoesNotFabricateFishingError` + `teardownAlwaysRuns` + `EmergencyStopAndInputGateTest` (V5) | ✅ |
| 11 | Restart depois de STOP | `CaptureStateMachineTest.restartAfterStopUsesFreshState` (+ `CaptureDiagnosticsTest.diagSessionCanRunTwiceOnFreshObjects`) | ✅ |
| 12 | Transições de `CaptureState` | `CaptureStateMachineTest.happyPathTransitions`, `illegalTransitionsAreRejectedInStrictMode`, `permissionDeniedDoesNotStartAnything`, `requestWhileRunningIsRefused` | ✅ |
| 13 | Frame inexistente | `FrameAgeTest.noFrameIsNA`, `CaptureInputSeparationTest.captureReportsNaButVisionNeverUsesMaxValue` | ✅ |
| 14 | Frame stale | `FrameAgeTest.staleFrameIsDetectedAndMissingFrameIsStale` + `StartSemanticsV5Test.staleFrameBlocksInput` | ✅ |
| 15 | START não executa CAST | `StartSemanticsV5Test.startDoesNotExecuteInputAndInitialStateIsWaitingForRod`, `CaptureStateMachineTest.startOnlyRequestsPermission` | ✅ |
| 16 | `WAITING_FOR_ROD` sem input | `StartSemanticsV5Test.rodNotDetectedMeansZeroInput` | ✅ |
| 17 | Rod com confiança baixa sem input | `StartSemanticsV5Test.lowRodConfidenceMeansZeroInput` | ✅ |
| 18 | Rod confirmada permite decisão de cast | `StartSemanticsV5Test.confirmedRodAuthorizesCast` | ✅ |
| 19 | `realInput OFF` bloqueia input | `StartSemanticsV5Test.realInputOffBlocksInputButStillReportsRodDetected`, `CaptureInputSeparationTest.realInputOffRecordsWouldCastButNeverTouchesTheExecutor` | ✅ |
| 20 | Roblox ausente bloqueia input | `StartSemanticsV5Test.robloxAbsentBlocksInput`, `CaptureInputSeparationTest.robloxAbsentBlocksInputButNotCapture` | ✅ |
| 21 | Captura funcionando **sem** Roblox em foreground | `CaptureInputSeparationTest.captureRunsWithoutRobloxForeground`, `captureKeepsRunningWithRealInputOff` | ✅ |
| 22 | `catch` retorna `WAITING_FOR_ROD` | `CaptureInputSeparationTest.catchReturnsToWaitingForRod` (+ `FishingStateMachineTest.fullCycleRequiresVisualCatchConfirmationAndRecovery`) | ✅ |

## Checks V6 adicionados ao `selfTest` (spec §21/§20)

- `testCaptureStateMachineV6` — ciclo completo STOPPED→…→RUNNING, transição ilegal em modo strict,
  preservação de `SecurityException` + mensagem original, `onStop` → STOPPED, STOP sem fabricar falha.
- `testCaptureConsentPolicyV6` — RESULT_OK, cancelamento (não é erro), `data null`, manager nulo,
  formato da linha `CAPTURE_PERMISSION_RESULT`.
- `testCaptureDiagnosticReportV6` — relatório OK só com RUNNING + FPS>0 + frame age válido + frames>0;
  falha por exceção não mascarada; etapa da falha identificada; nada depois da falha é reportado como
  OK; teardown sempre executado (inclusive quando a primeira etapa falha).
- `testFrameAgeV6` — `N/A` sem frame, `Long.MAX_VALUE` tratado como inválido/stale, contadores.
- `testGalaxyA22DeviceProfileV6` — perfil `samsung/SM-A225M/sdk 33/720x1600/rot 1`, bloco
  `[MEDIA_PROJECTION]` completo, e não declarar captura sem frames.

**Resultado: 138/138 checks, 0 falhas.**

## Teste que NÃO foi executado (declaração exigida pela spec §24)

> **Teste real no Galaxy A22 não executado neste ambiente.**

Não há aparelho físico, `adb` conectado a um A22, nem Roblox disponível aqui. Portanto:

- ❌ não há medição real de `FPS`, `frame age` nem de recepção do primeiro frame no A22;
- ❌ não há confirmação de que o Android 13 do Samsung aceita a sequência
  `startForeground(mediaProjection)` → `getMediaProjection`;
- ✅ o que existe é: compilação real, 120 testes automatizados, 138 checks de self-test, lint sem
  erros e um APK debug assinado e válido.

O roteiro para produzir essa evidência no aparelho (e o que enviar de volta caso falhe) está em
[`COMO_TESTAR_A22_V6.md`](COMO_TESTAR_A22_V6.md).
