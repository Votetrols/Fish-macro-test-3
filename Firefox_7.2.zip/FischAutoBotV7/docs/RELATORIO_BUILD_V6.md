# Relatório de build — Fisch AutoBot V6 (0.4.0-a22)

## 1. Toolchain usada neste ambiente

| Componente | Versão / caminho |
|---|---|
| JDK | Temurin **17** (`/opt/jdk17`) |
| Android SDK | platform **android-35**, build-tools **35.0.0**, platform-tools |
| Gradle | wrapper **8.9** |
| AGP / Kotlin | **8.7.3** / **2.0.21** |
| Compilação | `compileSdk 35`, `buildToolsVersion 35.0.0`, `minSdk 26`, `targetSdk 35` |
| Kotlin/Java target | 11 |

## 2. Comando executado

```bash
export JAVA_HOME=/opt/jdk17
export ANDROID_HOME=/opt/android-sdk ANDROID_SDK_ROOT=/opt/android-sdk
export GRADLE_USER_HOME=<cache de dependências>
./gradlew --no-daemon :core:test :core:selfTest :app:assembleDebug
```

## 3. Resultado

```
> Task :core:test                     → 120 testes, 0 falhas
== SelfTest: 138 checks, 0 failures ==
> Task :app:assembleDebug
BUILD SUCCESSFUL
```

Complementar (best-effort, também executado):

```
./gradlew --no-daemon :app:lintDebug   → BUILD SUCCESSFUL · 0 erros · 14 avisos
```

Avisos de lint (nenhum é erro; todos pré-existentes ou de estilo):
`SetTextI18n` (×7, textos montados por código), `GradleDependency` (×3, versões de libs um pouco
antigas), `UnusedAttribute` (×1, `isAccessibilityTool` em api<31), `UseSwitchCompatOrMaterialCode`
(×1), `DataExtractionRules` (×1), `ObsoleteSdkInt` (×1).

## 4. Artefato

| Item | Valor |
|---|---|
| Arquivo | `app/build/outputs/apk/debug/app-debug.apk` |
| Tamanho | 3.635.728 bytes (3,5 MB) |
| SHA-256 | `855b1945b1a0181537a97bce8d038c63c7938883afdef8ec4ba39889bce0e9e0` |
| Assinatura | APK Signature Scheme **v2** verificada (`apksigner verify`) |

### 4.1 Verificação de manifesto (`aapt2 dump badging/xmltree`)

```
package: name='com.fischa.app' versionCode='4' versionName='0.4.0-a22'
sdkVersion:  '26'          (minSdk — Android 8.0)
targetSdkVersion: '35'
uses-permission: android.permission.FOREGROUND_SERVICE
uses-permission: android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION
uses-permission: android.permission.POST_NOTIFICATIONS
uses-permission: android.permission.QUERY_ALL_PACKAGES
launchable-activity: com.fischa.app.MainActivity

service com.fischa.app.FischEngineService
  android:exported="false"
  android:foregroundServiceType="0x00000020"   (= FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

service com.fischa.app.GameAccessibilityService
  android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
  intent-filter: android.accessibilityservice.AccessibilityService
```

### 4.2 Verificação do dex (classes V6 empacotadas)

`dexdump` encontrou no APK (contagem de referências):

| Classe | Refs |
|---|---|
| `com.fischa.app.FischEngineService` | 280 |
| `com.fischa.app.ScreenCaptureSource` | 193 |
| `com.fischa.app.MainActivity` | 181 |
| `com.fischa.core.capture.CaptureSessionState` | 108 |
| `com.fischa.core.capture.CaptureDiagnostics` | 41 |
| `com.fischa.app.AppLog` | 39 |
| `com.fischa.app.CaptureConsentHolder` | 18 |

Total: 4.978 classes no dex, 436 arquivos no APK.

## 5. Progressão do build (evidência de que o projeto compila de fato)

| Etapa | Resultado |
|---|---|
| Baseline V5 (cópia intacta) — `:core:test :app:assembleDebug` | BUILD SUCCESSFUL (2m19s) |
| V6 — `:core:compileKotlin :app:compileDebugKotlin` (1ª vez) | 2 erros de `when` exaustivo → corrigidos |
| V6 — compilação final | BUILD SUCCESSFUL |
| V6 — `:core:test` | BUILD SUCCESSFUL (120/0) |
| V6 — `:core:selfTest` | 138/138 |
| V6 — `:app:assembleDebug` | BUILD SUCCESSFUL |
| V6 — `:app:lintDebug` | 0 erros |

### Correções que o compilador exigiu no caminho (registro honesto)

1. `CaptureErrorText`: `when` sobre `CaptureStage` deixou de ser exaustivo ao adicionar `CONSENT` →
   tratado em `userMessage`/`isRetryable`.
2. `VirtualDisplay.getWidth()/getHeight()/getDensityDpi()` **não existem mais no android-35**
   (removidos após deprecação no 34). O diagnóstico passou a registrar os valores **requeridos** na
   criação (`captureWidth × captureHeight × density`), que são a mesma informação para o relatório.
3. `AppLog`/`StatusSnapshot`/imports: pequenos ajustes de assinatura até o build ficar limpo.

## 6. O que este relatório NÃO afirma

Não houve instalação em aparelho nem execução no Roblox. **Instalação, permissões em runtime
(POST_NOTIFICATIONS), acessibilidade e o comportamento real da MediaProjection no Galaxy A22 não
foram verificados aqui** — os itens acima cobrem compilação, empacotamento, manifesto, testes e
lint. O roteiro de validação no aparelho está em [`COMO_TESTAR_A22_V6.md`](COMO_TESTAR_A22_V6.md).
