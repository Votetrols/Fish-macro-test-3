# Fisch AutoBot V5 (0.3.0-a22) — relatório de alterações

Base: **FischAutoBotV3-V4** (`FischAutoBotV3-V4-clean.zip`, build 0.2.0-a22). **Nada foi recriado
do zero** — toda a arquitetura V4 foi preservada (CAPTURE → VISION → TRACKING → FSM →
CONTROLLER → SAFETY → INPUT) e as mudanças são cirúrgicas.

Alvo: **Samsung Galaxy A22** (Android 11–14 dependendo da variante; o fluxo foi corrigido para
Android 13 **e** 14).

---

## 1. CRASH PÓS-MEDIAPROJECTION — CAUSA RAIZ E CORREÇÃO (spec §1/§2 do pedido)

**Sintoma (V4, confirmado no A22):** START → o sistema pede captura de tela → o usuário permite
→ **o aplicativo fecha imediatamente**.

**Causa raiz encontrada no código V4** (`MainActivity.onActivityResult` →
`FischEngineService.onStartCommand(ACTION_START)`):

1. A Activity chamava `startForegroundService(...)` e o serviço, dentro de `onStartCommand`,
   chamava **`startForeground()` com o tipo `mediaProjection` ANTES de obter a sessão
   `MediaProjection`** (`getMediaProjection` só era chamado depois, dentro de `startEngine`).
   O manifest declara `android:foregroundServiceType="mediaProjection"`. **No Android 14**, o
   sistema exige que exista uma sessão de MediaProjection **ativa** quando um serviço de
   primeiro plano do tipo `mediaProjection` é iniciado/chama `startForeground()` — caso
   contrário a chamada lança uma exceção (`SecurityException`/`ForegroundServiceTypeException`)
   **dentro de `onStartCommand`, na thread principal → processo morto**. É exatamente o crash
   observado: acontece depois do usuário permitir a captura, na inicialização do serviço.
2. A exceção não tinha tratamento: qualquer falha nesse caminho (startForeground rejeitado,
   `getMediaProjection` nulo/lançando, `startForegroundService` negado) propagava e matava o app.
3. Bug de lifecycle adicional: a sessão `MediaProjection` **nunca era encerrada** (`stop()` nunca
   era chamado) — vazamento da sessão de captura.

**Correções V5 (não mascaramos exceção nenhuma — a causa foi corrigida e todo o caminho agora é
à prova de falhas):**

- **`ProjectionHolder` (novo)**: a Activity cria a sessão `MediaProjection` **imediatamente em
  `onActivityResult`** (antes de qualquer start de serviço) e a entrega ao serviço por um holder
  no mesmo processo. O serviço só chama `startForeground(mediaProjection)` **depois** de a sessão
  existir — a ordem exigida no Android 14. Os extras da Intent (`resultCode`/`data`) viraram
  fallback (lidos com `IntentCompat.getParcelableExtra`, a API correta no API 33+).
- **`FischEngineService.onStartCommand(ACTION_START)`** reescrito: pega a projeção do holder →
  só então `startForeground` (dentro da janela de 5 s do `startForegroundService`, amplamente
  cumprida) → só então inicia a captura. Tudo wrapped em `runCatching`: se `startForeground`
  falhar, o erro é registrado, a projeção é liberada e o serviço para **sem matar o processo**.
- **`MainActivity.onActivityResult`**: `getMediaProjection` protegido (null/exception → toast,
  nada quebra); `startForegroundService` protegido com **fallback para `startService()`** (o app
  está em primeiro plano nesse momento, então o serviço ainda pode chamar `startForeground()`
  imediatamente); se nada funcionar, a projeção é descartada com `stop()` e um toast explica.
- **`shutdownCapture()`** agora encerra a sessão: `unregisterCallback()` + `projection.stop()`
  (o callback é desregistrado antes para o nosso próprio `stop()` não dispare `onStop` →
  latch de emergência em uma parada normal).
- **`handleCaptureError()` (novo, spec §13)**: toda falha de captura loga
  `[CAPTURE] CAPTURE ERROR` + exception + stack trace + timestamp + estado da FSM + status da
  MediaProjection + status do serviço, libera gestos via `pipeline.disarm()`, para a sessão com
  estado `CAPTURE_ERROR` e **mantém o app aberto** — o usuário pode tentar de novo com START
  (sem precisar limpar latch de emergência).
- **Stream timeout** (frames pararam de chegar) também passou a parada graciosa com
  `CAPTURE ERROR` (na V4 travava emergência).
- `ScreenCaptureSource`: falhas transitórias de `acquireLatestImage`/cópia agora contam erros
  consecutivos e só terminam a sessão após 10 falhas seguidas (um soluço não mata nada);
  `Image.close()` garantido em `finally` em todos os caminhos (spec §15).

**Pontos de atenção remanescentes no aparelho** (ver §"Erros conhecidos"): a correção foi
validada por compilação + testes de unidade do fluxo de estados/safety; o teste real no A22
(Android 13 ou 14) deve confirmar no logcat que, após "Iniciar agora", aparece
`[CAPTURE] display …` e **nenhum crash**.

## 2. REGRA FUNDAMENTAL DO START (spec §1)

START agora significa **apenas** ligar a infraestrutura de observação:

```
START → MediaProjection (criada na Activity) → startForeground (tipo mediaProjection)
      → ScreenCapture (VirtualDisplay no tamanho de processamento) → engine loop
      → visão + FSM + tracking + controller inicializados
      → FSM: IDLE → WAITING_FOR_ROD   (estado seguro, observando a tela)
```

- START **não** envia gesto algum (tap/hold/click), não inicia CAST, não ativa `realInput`.
- `realInput` continua **OFF por padrão** e só pode ser ligado pelo switch da UI (opt-in de
  sessão, com diálogo) — START não ativa.
- Com `realInput=OFF`, mesmo com a vara confirmada, o sistema registra `ROD_DETECTED` /
  `WOULD_CAST` nos logs e **não toca na tela** (modo de teste da visão, spec §19/§20).

## 3. FLUXO OBRIGATÓRIO V5 (spec §2) — FSM

A máquina de estados foi **evoluída** (não recriada). Novos nomes/estados:

| Estado V5 | Papel |
|---|---|
| `IDLE` | infraestrutura desligada (antes do START / após STOP) |
| `WAITING_FOR_ROD` | **observando**; a vara confirmada visualmente é a ÚNICA saída (era `SEARCH_FISHING_BUTTON`) |
| `CASTING` | hold do cast (`holdStart → holdExtend → holdRelease`, `CAST_HOLD_DURATION_MS`) |
| `WAITING_FOR_WATER` | **novo**: após o release do cast, espera evidência visual (shake ou barra) — sem shake imediato, sem timer como gatilho |
| `SEARCHING_SHAKE` / `PRESSING_SHAKE` | ciclo do shake (preservado da V4) |
| `FISHING_MINIGAME_DETECTED` / `TRACKING_FISH` / `CONTROLLING_PLAYER_BAR` | minigame (preservado) |
| `CATCH_CONFIRMATION` | confirmação de captura (preservada) |
| `RESET` | waypoint de recuperação → volta para `WAITING_FOR_ROD` |
| `VISION_LOST` / `CAPTURE_ERROR` / `ROBLOX_NOT_DETECTED` / `INVALID_STATE` / `EMERGENCY_STOP` | erros (preservados) |

Mudanças de transição (spec §2/§4):

- `IDLE → WAITING_FOR_ROD` quando armada.
- `WAITING_FOR_ROD → CASTING` **somente** se `rodConfirmed && castAuthorized`.
  - Os atalhos da V4 (barra/prompt de shake já na tela ao entrar em `SEARCH_FISHING_BUTTON`)
    foram **removidos**: spec §4 — sem a vara detectada, não inicia CAST, nem Shake, nem minigame.
- `CASTING → WAITING_FOR_WATER` quando o CastController termina o hold (release emitido);
  `CASTING → WAITING_FOR_ROD` se o alvo da vara se perder no meio do press.
- `WAITING_FOR_WATER → SEARCHING_SHAKE` (shake visível) ou `→ FISHING_MINIGAME_DETECTED`
  (barra por `minigameEnterFrames`); **timeout de segurança** `state.waitingForWaterMs`
  (padrão 10 s) devolve a `WAITING_FOR_ROD` — o timeout **nunca** inicia ciclo, só devolve.
- `CATCH_CONFIRMATION → RESET → WAITING_FOR_ROD`; o novo ciclo exige **nova** confirmação
  visual da vara (o tracker é resetado na entrada de `WAITING_FOR_ROD`/`CASTING`).
- Shake/minigame/controller/safety/emergência: **preservados** (spec §8/§9).

## 4. GATILHO VISUAL DA VARA (spec §3/§4/§5)

- `FishingButtonDetector` (V4, preservado) já usa ROI otimizada (`rodSearchX0..Y1`) + prior de
  posição apenas como **peso** de score — nunca como gatilho.
- **Novo `RodConfirmTracker`** (core/tracking): confirmação temporal curta e configurável:
  - `rod.confirmFrames` (padrão **3**) frames consecutivos;
  - `rod.confidenceThreshold` (padrão **0.55**, = ROD_CONFIDENCE_THRESHOLD);
  - `rod.stableToleranceF` (padrão 0.02) — posição estável dentro da tolerância (pulo reinicia);
  - `rod.confirmWindowMs` (padrão 1500) — a sequência deve completar dentro da janela (sem
    espera fixa longa, sem latência desnecessária).
- **Novo `InputSafetyGuard.evaluateCastGate()`**: a transição `WAITING_FOR_ROD → CASTING`
  exige que o guard autorize (macro ligado, **realInput ON**, captura saudável, Roblox
  detectado, plataforma autorizada, sem overlay, estado `WAITING_FOR_ROD`, frame fresco,
  confiança da vara ≥ `safety.minActionConfidence`, coordenadas válidas). Se o botão não está
  detectado ou a confiança está baixa → `WAITING_FOR_ROD` (zero input).

## 5. CAST / WAITING_FOR_WATER (spec §6/§7)

- `cast.holdMs` **é** a configuração `CAST_HOLD_DURATION_MS` (padrão 3000 ms, configurável,
  exposta na UI como "CAST_HOLD_DURATION_MS (carga do cast)").
- `CastController` agora sinaliza `releaseIssued`/`releaseWasComplete` para a FSM distinguir
  cast completo (→ `WAITING_FOR_WATER`) de cast abortado por perda do alvo (→ `WAITING_FOR_ROD`).
- Após o cast, o sistema **não** começa Shake imediatamente: `WAITING_FOR_WATER` aguarda a
  evidência visual (prompt de shake ou barra do minigame) usando os detectores existentes.

## 6. SHAKE / MINIGAME / CONTROLLER (spec §8/§9) — PRESERVADOS

- Shake: detecta → valida confiança → toca o centro detectado → procura de novo; sem coordenadas
  fixas, sem quantidade fixa de shakes (V4 preservado).
- Minigame: barra/bloco/peixe/progresso detectados dinamicamente (limites atuais da barra,
  normalizados); controller P-D + feedforward + deriva + dead zone + confiança + controle
  adaptativo preservados; usa `tap`/`holdStart`/`holdExtend`/`holdRelease`.
- Fim do minigame → `CATCH_CONFIRMATION` → `WAITING_FOR_ROD`; **nunca** recast por timer.

## 7. ROBLOX FOREGROUND / INPUT SAFETY / REAL INPUT (spec §17/§18/§19)

- `RobloxForegroundDetector` **preservado** (pacote esperado `com.roblox.client`); sem Roblox
  confirmado → `INPUT BLOCKED` (nunca "não consegui verificar → permite").
- `InputSafetyGuard` (porta única) **preservado** + novo gate de cast; checagens antes de cada
  gesto: realInput, controllerEnabled, Roblox foreground, AccessibilityService, captura ativa,
  frame válido, frame não stale, confiança, FSM, emergência, coordenadas, duração.
- `realInput = OFF` por padrão; START não ativa; com OFF o sistema loga `ROD_DETECTED` +
  `WOULD_CAST` e não envia gesto real.

## 8. MODO DE TESTE / LOGS (spec §20)

Linha periódica (1 s) no log, com os tokens pedidos:

```
[STATE] STATE=WAITING_FOR_ROD ROD_DETECTED=true ROD_CONFIDENCE=0.85 ROD_CONFIRMED=true ROBLOX=true INPUT_AUTHORIZED=true DECISION=WOULD_CAST ACTION=NONE BLOCK_REASON=REAL_INPUT_DISABLED
```

A UI mostra estado, `Vara: detectada/conf/confirmada | cast autorizado`, e o overlay de debug
ganhou a linha `Rod: confirmed=… conf=… castAuthorized=…`.

## 9. PERFORMANCE (spec §21) — preservado + Nachtrag

VirtualDisplay já no tamanho de processamento (640×288), cópia por linha via IntBuffer, buffer
latest-only, gate de FPS + taxa adaptativa, duty-cycle ~4 FPS fora do Roblox, detectores só com
ROI/prior quando aplicável. A V5 **não** adiciona processamento por frame (o gate da vara é O(1);
o RodConfirmTracker não aloca). `WAITING_FOR_ROD` exige o detector da vara por frame — é o
custo necessário para observar a tela.

## 10. TESTES (spec §22)

- **Preservados** todos os testes da V4 (atualizados para os novos estados/evidências):
  `FishingStateMachineTest`, `ControllersTest`, `TrackersTest`, `InputSafetyGuardTest`,
  `EmergencyStopAndInputGateTest`, `GestureLeaseTest`, `RobloxForegroundDetectorTest`,
  `CoordinateMapperTest`, `AppConfigTest`, `FrameBufferTest`, e o `SelfTest` (harness
  determinístico — ganhou a seção `testRodConfirmationGate`).
- **Novos**:
  - `RodConfirmTrackerTest` (7 testes: frames consecutivos, frame único, confiança baixa,
    posição instável, janela, desaparecimento/reset, coordenadas inválidas);
  - `StartSemanticsV5Test` (11 testes de pipeline com frames sintéticos desenhados —
    1. START não executa input; 2. estado inicial = WAITING_FOR_ROD; 3. vara não detectada →
    zero input; 4. confiança baixa → zero input; 5. vara confirmada → CAST permitido
    (HOLD_START emitido); 6. Roblox ausente → bloqueado; 7. realInput OFF → bloqueado com
    ROD_DETECTED/WOULD_CAST; 8. emergência → bloqueado; 9. captura inválida → bloqueado;
    10. frame stale → bloqueado; + extra: cast → WAITING_FOR_WATER após o release);
  - `FishingStateMachineTest` ganhou: só vara confirmada+autorizada abre CASTING;
    novo ciclo exige nova confirmação; WAITING_FOR_WATER devolve a WAITING_FOR_ROD no timeout.
- Resultados numéricos em `docs/TEST_RESULTS.md`.

## 11. BUILD (spec §23)

- `./gradlew :app:assembleDebug` executado neste ambiente (JDK 17 Temurin, Android SDK
  platform 35 / build-tools 35.0.0, Gradle 8.9 wrapper, AGP 8.7.3, Kotlin 2.0.21).
- `versionName` = **0.3.0-a22**, `versionCode` = 3, `applicationId` = `com.fischa.app`.
- Verificação física do APK em `docs/TEST_RESULTS.md` (tamanho, badging, assinatura, sha256).

## 12. ARQUIVOS ALTERADOS / NOVOS

**Novos:** `app/.../ProjectionHolder.kt`, `core/.../tracking/RodConfirmTracker.kt`,
`core/src/test/.../tracking/RodConfirmTrackerTest.kt`,
`core/src/test/.../pipeline/StartSemanticsV5Test.kt`, `docs/CHANGES_V5.md`.

**Modificados:** `core/.../config/AppConfig.kt` (seção `Rod`, `state.waitingForWaterMs`,
serialização/validação), `core/.../state/States.kt` (WAITING_FOR_ROD/WAITING_FOR_WATER +
StateEvidence), `core/.../state/FishingStateMachine.kt` (fluxo V5), `core/.../control/CastController.kt`
(sinal de release), `core/.../safety/InputSafetyGuard.kt` (`evaluateCastGate`),
`core/.../pipeline/VisionPipeline.kt` (gate da vara, castComplete, logs §20, saídas),
`core/.../pipeline/PipelineEvent.kt`, `core/.../debug/RenderModel.kt`,
`core/.../tools/SelfTest.kt`, `core/src/test/.../state/FishingStateMachineTest.kt`,
`app/.../MainActivity.kt` (V5, projection-first, UI), `app/.../FischEngineService.kt` (crash fix,
CAPTURE ERROR, projection.stop, status), `app/.../ScreenCaptureSource.kt` (falhas transitórias),
`app/.../DebugOverlay.kt` (linha da vara), `app/src/main/res/values/strings.xml`,
`app/build.gradle.kts` (0.3.0-a22 / versionCode 3), `settings.gradle.kts`,
`README.md`, `docs/TEST_RESULTS.md`, `docs/INSTALL_A22.md`, `docs/LIMITATIONS.md`.

## 13. ERROS CONHECIDOS / NÃO TESTADO

- **Nada foi testado em dispositivo real nem no Roblox** (spec §25). A correção do crash é
  validada por análise de código + build + testes; o A22 (Android 13/14) deve confirmar.
- O crash original não pôde ser reproduzido em logcat neste ambiente (sem aparelho) — a causa
  foi corrigida no código (ordem MediaProjection → startForeground) e o caminho inteiro agora é
  à prova de exceções; se ainda houver crash no aparelho, o log `[CAPTURE]` + logcat dirá a
  causa exata (nada é mascarado).
- Pontos de observação no primeiro teste no A22 (iguais à V4): ordem de bytes RGBA/rowStride da
  captura, precisão do toque (`[INPUT] … px=(…)`), hold contínuo via `continueStroke`, Activity
  reportada pelo Roblox (`[SAFETY] activity changed:`).
- A detección da vara no Fisch real depende do botão ter o fingerprint visual esperado
  (disco escuro + anel claro + glifo); se o botão real diferir, `ROD_CONFIDENCE` fica baixo e o
  sistema **não** pesca (fail-closed) — ajustar `rod.*` / `vision.rod*` nas Configurações.
