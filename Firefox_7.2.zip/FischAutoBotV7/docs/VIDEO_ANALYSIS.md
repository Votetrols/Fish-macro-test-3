# Análise visual do vídeo de referência

Arquivo: `Roblox_2026-10-06-13-57-21.mp4` (commit `2b85675` do repo Votetrols/Fish-macro-test-3)
Método: 626 frames extraídos (1066×480, 15 fps, áudio ignorado), análise por script
(`analysis/` no workspace: scan de diferença entre frames, conectados-componentes, medição
de geometria por frame, zooms inspecionados visualmente).

## Timeline real do vídeo (1 ciclo completo + interrupção de sistema)

| Tempo | Frames | O que acontece |
|---|---|---|
| 0.0–4.1s | f_0001–f_0061 | Jogador parado na praia (noite). HUD padrão visível. Botão da vara (círculo escuro com ícone de anzol) presente. |
| ~4.1–5.9s | f_0061–f_0088 | Lançamento: linha vermelha/branca do arremesso visível ao lado do personagem. |
| 6.0–18.9s | f_0091–f_0285 | Fase de mordidas: **múltiplos prompts SHAKE em posições diferentes**: (537,100) em 7.1s; (238,341) em 18.1s; outros em 8–15s. O botão da vara continua visível. |
| 19.0–19.2s | f_0286–f_0288 | **HUD some inteiro** (menu topo, inventário embaixo, botão da vara) → minigame começa. Texto "Tap & Hold Anywhere!" aparece. |
| 19.2–30.9s | f_0288–f_0462 | Minigame: barra escura + bloco branco + agulha do peixe + barra de progresso. Progresso enche. Bloco fica **avermelhado quando desalinhado**. |
| 30.9–31.3s | f_0454–f_0469 | Captura: "!" vermelho some, barra desaparece, HUD volta, popup dourado de XP "450". |
| 31.3–35s | f_0470–f_0525 | **Confirmação visual**: texto de notificação no centro — "You just caught a **Big Log** at 7.9kg! (1/19)" + "Bestiary: New Highest Weight!". |
| 35–38s | f_0526–f_0570 | Estado normal restaurado (pronto para novo ciclo). |
| 38.1–41.7s | f_0571–f_0626 | **A barra de notificações do Android cobre a tela** (overlay do sistema, tela escurecida; "Toque para interromper a gravação"). Isto NÃO é estado do jogo — validação do requisito VISION_LOST/overlay. |

## Elementos medidos (pixels no vídeo 1066×480 → dar preferência a frações)

### Botão da vara (FishingButton)
- Círculo escuro semitransparente com anel cinza-claro e ícone de anzol.
- Centro ≈ (872, 332) → **normalizado (0.818, 0.692)**; raio ≈ 52–56 px (≈ 0.11×W).
- Fica sobre a região do botão de pulo — nunca sobre o canto extremo.
- Some completamente quando o minigame começa (HUD oculta).

### Prompt SHAKE
- Disco escuro (~55% opaco) com anel claro fino e texto branco **"SHAKE"**.
- Diâmetro observado ≈ 110 px (≈ 0.10×W), **posição variável** (topo-centro 7.1s;
  centro-esquerda-inferior 18.1s; etc.).
- Pode haver texto de flutuação do jogo com fundo escuro em outros locais — validar por
  anel circular + glifos brancos.
- Aparece em rajadas; some após o último shake quando o minigame começa.
- O prompt também pode estar coberto pela câmera/movimento; usar detecção por frame com
  persistência temporal (2+ frames) e debounce na remoção (2–3 frames).

### Barra do minigame (FishingBar)
- Faixa horizontal quase preta, levemente translúcida: valor de cinza do interior 18–30.
- Extensão (vara "Trout" do vídeo): x 332→724 (0.312W–0.679W, ~37% W), y 388→408
  (0.808H–0.850H, altura ≈ 0.042H ≈ 20 px).
- Marcadores triangulares vermelhos nas duas pontas da barra (≈ 10×14 px) — úteis como
  evidência de bordas.
- A largura varia por vara (spec) → detectar sempre; usar prior só como ponderação.

### Área do jogador (bloco branco)
- Retângulo branco arredondado **dentro** da barra, altura = altura da barra,
  largura ≈ 115–122 px (≈ 0.30× largura da barra no vídeo).
- Contém glifos de seta cinza "←" e "→" (esquerda/direita do bloco, ~14 px).
- Quando o peixe está FORA do bloco, o bloco fica **avermelhado/escuro** (val ~64 no vídeo,
  matiz vermelho) — forte evidência de desalinhamento ("mismatch tint").
- Bloco **não** muda de tamanho com a vara (spec §2/§23) — detectar largura uma vez e
  manter; clamp visual: bloco fica preso nas bordas da barra (visto em f_0348–f_0388 no
  limite esquerdo).

### Peixe (Fish)
- Ícone de peixe cinza (~20×22 px) sobre a barra + "agulha" vertical cinza (~6–8 px de
  largura) que cruza a barra e sobe ~14–30 px acima do topo da barra.
- Sobre o bloco branco a agulha aparece escura (~50–90); fora do bloco, sobre a barra
  escura, aparece clara (~120–180). Detector precisa dos dois modos.

### Barra de progresso
- Traço fino arredondado abaixo da barra: x 422→646 (centro ≈ centro da barra),
  y ≈ 427–436 (0.890H–0.908H), preenchimento branco crescendo da esquerda;
  fundo cinza escuro com contorno claro.
- Preenchimento ≈ progresso 0–100%.
- Abaixo dela, texto "+1% Progress Speed" (ignorável).

### Confirmação de captura
- Sem modal com imagem do peixe neste vídeo: **linhas de texto de notificação** na região
  central (verde/branco sobre fundo de mundo) contendo "You just caught a ..." e, para
  recordes, "Bestiary: New Highest Weight!", + popup dourado de XP grande no topo
  (ex.: "450"). Persistem por vários segundos e somem.
- Implementação: sinal principal = fim do minigame (barra some + HUD volta); sinal de
  confirmação = burst de texto claro/movimento estável na região central nos ~6s seguintes
  (CatchEvidence), combinado com tendência de progresso ≥ ~0.9 antes do fim. Falha/escape
  tratado como ciclo sem confirmação (não assume captura).

## Dinâmica medida (para calibrar o controlador)

- Drift do bloco para esquerda sem toque: ≈ −0.27 … −0.34 larguras-de-barra/segundo.
- Movimento para direita com toque/hold: ≈ +0.5 … +0.7 larguras-de-barra/segundo.
- Peixe: velocidade de pico ≈ ±0.5 larguras/s; para; inverte bruscamente (ex. inversão em
  ~2 frames em f_0441→f_0447).
- Consequências: duty cycle de ~35–40% de hold apenas sustenta posição; para acompanhar o
  peixe é preciso hold contínuo quando erro > +0.05 e pulsos curtos para micro-ajustes.
  A latência de ação deve ser < ~200 ms → controlador roda a cada frame e usa
  previsao leve (pos + 0.5·vel·Δt limitado) em vez de filtro pesado.

## Falsos positivos observados (projetar contra eles)

- Texto flutuante do jogo ("[Blue Tang]", "[Angelfish]", "[Clownfish]" — nomes de peixes
  de outros jogadores, VERDE/branco sobre o mundo), chat "Tap & Hold Anywhere!" (some?),
  "Good!", nome do jogador — todos brancos sobre fundo escuro; o detector SHAKE exige
  ANEL circular + disco, não só texto.
- A barra superior do Roblox (Shop/Menu/Aquariums) contém texto branco em fundo escuro com
  barras escuras — o detector SHAKE ignora regiões onde o fundo é estático entre frames
  (o prompt do jogo surge/some; a HUD não).
- **Overlay do sistema Android** (shade de notificação, 38–41.7s) escurece a cena inteira e
  muda tudo — deve colapsar confiança global → VISION_LOST → SafetyGuard bloqueia input.

## Estado do HUD como evidência

- Minigame ativo ⇒ HUD padrão Some (botão da vara e barra inferior desaparecem
  simultaneamente) ⇒ "Roblox presente" pode ser aferido por: HUD normal presente OU
  barra do minigame presente. Nenhum dos dois por > ~3s ⇒ ROBLOX_NOT_DETECTED/overlay.
