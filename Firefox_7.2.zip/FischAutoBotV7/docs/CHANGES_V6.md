# V5 → V6 — resumo das alterações (0.3.0-a22 → 0.4.0-a22)

> Atualização **incremental**. Nada de arquitetura foi reescrito sem necessidade: a FSM de pesca,
> os 7 detectores, o tracking, os controladores, o InputSafetyGuard, o EmergencyStop, o
> `FrameBuffer` latest-only, o overlay de debug e o harness de replay continuam sendo os da V5.
> A V6 mexe onde o teste no Galaxy A22 provou que havia problema: **o fluxo da MediaProjection, o
> foreground service, o diagnóstico e a exibição de “frame age”**.

## 1. Núcleo novo (`core/…/capture/`) — lógica testável na JVM

| Arquivo | Papel |
|---|---|
| `CaptureState.kt` | `CaptureState` (STOPPED/REQUESTING_PERMISSION/AUTHORIZED/STARTING/RUNNING/FAILED), `ProjectionState`, `ServiceState`, `CaptureStage`, `CapturedException`, `CaptureFailure`, `CaptureSessionState` (máquina determinística com tabela de transições válidas, modo `strict` para testes, histórico limitado e listeners) e `CaptureStateSnapshot`. |
| `CaptureDiagnostics.kt` | `DeviceProfile` (sdk/manufacturer/model/device/screen/dpi/rot/app) + `CaptureAttempt` com **todos** os campos pedidos na spec §1 e `formatBlock()` (bloco `[MEDIA_PROJECTION]`). |
| `CaptureConsent.kt` | `CaptureConsentPolicy.evaluate()` + `ConsentEvaluation` (`CAPTURE_PERMISSION_RESULT resultCode=… dataPresent=… managerPresent=… failureReason=…`), `mayStartCapture`, cancelamento do usuário ≠ erro. |
| `CaptureProbe.kt` | Interface `CaptureProbe` + `CaptureDiagnostics.run()` → `CaptureDiagnosticReport` (7 etapas, critério de sucesso §20, relatório textual). Usado pelo botão “DIAGNÓSTICO DE CAPTURA” e pelos testes. |
| `FrameStats.kt` | `FrameAge` (`NONE = -1`, `format()` → `"N/A"`, `isStale` fail-closed) + `FrameStatsTracker`/`FrameCounters` (received/processed/dropped/gated). |
| `CaptureErrorText.kt` | Texto amigável + **linha técnica com a causa original** + `isRetryable`/`retryHint`. |

`log/GameLog.kt`: novas tags da spec §21 — `MEDIA_PROJECTION`, `FOREGROUND_SERVICE`,
`VIRTUAL_DISPLAY`, `IMAGE_READER`, `FRAME`, `ROBLOX`, `FSM` (as antigas continuam).

`config/AppConfig.kt`: novo `capture.firstFrameTimeoutMs` (default 2500 ms) usado no critério
“primeiro frame” do START e do diagnóstico.

## 2. Android (`app/`)

| Arquivo | V5 | V6 |
|---|---|---|
| `MainActivity.kt` | `startActivityForResult` + `onActivityResult` (deprecated); criava a MediaProjection; UI com “Captura: true/false” | `registerForActivityResult(ActivityResultContracts.StartActivityForResult())`; **não** cria projeção — entrega o consentimento ao serviço; tela de captura com Capture/Projection/Service/frame age/frames received/processed/dropped/última falha (amigável **e** técnica); botões **DIAGNÓSTICO DE CAPTURA**, **Mostrar relatório**, **Compartilhar log**; `AppCompatActivity` |
| `FischEngineService.kt` | `getMediaProjection` na Activity → `ProjectionHolder` → `startForeground` depois | ordem correta: consentimento → `startForegroundService` → **`startForeground(type=mediaProjection)`** → `getMediaProjection` → `registerCallback` → reader/display → 1º frame → `RUNNING`; novas ações `ACTION_START_CAPTURE`/`ACTION_DIAGNOSE_CAPTURE`; `handleCaptureError` preserva a exceção; `onStop` do sistema **não** trava emergência (permite retry limpo); status ganhou `captureState/projectionState/serviceState/lastCaptureError/frames*/device…` |
| `ScreenCaptureSource.kt` | `start()` único, `captureHealthy` | `createImageReader()`/`createVirtualDisplay()`/`begin()` separados e diagnosticáveis por etapa; valida Surface do reader, dimensões, formato; registra reader/display no `CaptureAttempt`; mede **primeiro frame** (`firstFrameLatencyMs`) e contadores reais; cópia de pixels **inalterada** |
| `ProjectionHolder.kt` | handoff do objeto `MediaProjection` | **removido** |
| `CaptureConsentHolder.kt` | — | handoff do **consentimento** (resultCode + Intent) como fallback de ROM, com validade de 20 s e uso único |
| `AppLog.kt` | — | sink de log **process-wide** (ring 600 linhas + arquivo `files/fisch-log.txt`) inicializado por qualquer componente: a Activity vê o log mesmo quando o serviço nunca subiu (falha exata da V5) |
| `ui/DiagnosticsLog.kt` | `event()` | + `failure(category, msg, throwable)` (classe + mensagem + stack, nunca mascara) + `block()` |
| `ServiceCaptureProbe.kt` | — | implementação Android do probe (etapas reais, sem pescar/clicar) |
| `app/build.gradle.kts` | versionCode 3 / 0.3.0-a22 | **versionCode 4 / versionName 0.4.0-a22**; `androidx.activity` explícito |
| `strings.xml`, `settings.gradle.kts` | “V5”, rootProject V5 | “V6”, rootProject V6 |

`AndroidManifest.xml`: inalterado na essência (já tinha `FOREGROUND_SERVICE`,
`FOREGROUND_SERVICE_MEDIA_PROJECTION`, `POST_NOTIFICATIONS`, `QUERY_ALL_PACKAGES`,
`<service … android:foregroundServiceType="mediaProjection">`, `queries` do Roblox) — verificado
no APK final: `foregroundServiceType=0x00000020` (= mediaProjection).

## 3. O que mudou de comportamento (e por quê)

1. **START não pesca** — continua igual: liga captura + visão, FSM vai para `WAITING_FOR_ROD`; o
   `CAST` só sai com a vara confirmada visualmente (multi-frame + confiança + InputSafetyGuard).
2. **`realInput = OFF` por padrão** — inalterado. Com OFF o log pode registrar
   `ROD_CONFIRMED`/`WOULD_CAST` (`castGateReason=REAL_INPUT_DISABLED`) e **nenhum gesto** é enviado.
3. **Falha de MediaProjection não vira falha de pesca** — a FSM de pesca não é mais marcada como
   `CAPTURE_ERROR` quando a captura morre; a máquina de captura vai para `FAILED` (com a causa) e a
   sessão é encerrada limpa.
4. **`onStop` da projeção (sistema) não trava mais a emergência** — V5 latcheava `EMERGENCY_STOP`
   (exigia “Limpar latch” antes de tentar de novo). V6 libera recursos, marca captura como parada e
   deixa o START funcionar de novo na hora (spec §6: “permitir nova tentativa limpa”).
5. **`frame age`**: nunca mais `9223372036854775807`. Sem frame → `N/A`
   (`FrameAge.NONE = -1`); `Long.MAX_VALUE` é tratado como inválido/stale em todo o código novo.
6. **Consulta de acessibilidade** — START ainda exige acessibilidade (o caminho de **input** precisa
   dela), mas o **DIAGNÓSTICO DE CAPTURA não exige** nada além do consentimento: a captura é
   infraestrutura e pode ser diagnosticada sem Roblox, sem acessibilidade e sem `realInput`.

## 4. Preservado sem alteração

`VisionPipeline` e suas etapas (visão → tracking → FSM → decisão → gate → executor),
`FishingStateMachine` e `States` (nomes V5 dos estados mantidos), `InputSafetyGuard` (incluindo
`evaluateCastGate`), `EmergencyStop`, `GestureLease`, `CastController`, `ShakeController`,
`FishingController`, todos os detectores, `FrameBuffer` latest-only, `ThrottledLog`,
`RobloxForegroundDetector`, `GameAccessibilityService`, overlay de debug, `SettingsActivity`,
`ReplayMain`, `SelfTest` (apenas estendido) e os testes V5 (todos continuam passando).

## 5. Números

| Métrica | V5 | V6 |
|---|---|---|
| Testes JUnit (`:core:test`) | 77, 0 falhas | **120, 0 falhas** |
| `:core:selfTest` | 97 checks | **138 checks, 0 falhas** |
| Lint (`:app:lintDebug`) | — | **0 erros**, 14 avisos benignos |
| APK | versionCode 3 / 0.3.0-a22 | **versionCode 4 / 0.4.0-a22**, `com.fischa.app` |
