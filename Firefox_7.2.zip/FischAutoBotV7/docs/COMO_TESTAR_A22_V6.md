# Como testar a V6 no Samsung Galaxy A22 (SM-A225M / Android 13)

Objetivo do teste: provar, **no aparelho**, que a captura chega a `RUNNING` com frames reais e que
`START` não pesca sozinho.

---

## 0. Instalação

1. Copie `FischAutoBotV6-debug.apk` para o A22 (USB, Drive, etc.).
2. Instale (é permitido APK fora da Play Store: *Configurações → Segurança → Instalar apps
   desconhecidos* para o app que abrir o arquivo).
3. `applicationId = com.fischa.app`, versão **0.4.0-a22** (versionCode 4). Se você já tem a V5
   instalada, **desinstale antes** (a V5 usava o mesmo `applicationId`, mas assinaturas iguais
   costumam atualizar direto; desinstalar evita estado antigo de configuração).

## 1. Acessibilidade (necessária para INPUT, não para o diagnóstico de captura)

1. Abra o app → **“Habilitar / revisar serviço de acessibilidade”**.
2. Ative **“Fisch AutoBot Input”** na lista de serviços instalados.
3. Volte ao app: a linha `Acessibilidade:` deve mostrar **ON**.

> A partir da V6, o **DIAGNÓSTICO DE CAPTURA funciona mesmo sem acessibilidade e sem Roblox**.

## 2. Diagnóstico de captura (faça este primeiro)

1. Toque em **“DIAGNÓSTICO DE CAPTURA (só infraestrutura; não pesca, não clica, não ativa input)”**.
2. O Android mostra o diálogo **“Iniciar captura de tela?”** → **“Iniciar agora”**.
3. O app imprime no campo **Relatório** as 7 etapas e o veredito. Sucesso esperado:

```
[ OK ] MediaProjectionManager — MediaProjectionManager disponível
[ OK ] consentimento (Activity Result) — CAPTURE_PERMISSION_RESULT resultCode=-1 dataPresent=true …
[ OK ] startForeground — startForeground type=mediaProjection OK
[ OK ] getMediaProjection — MediaProjection ativa + callback + capture source
[ OK ] ImageReader.newInstance — ImageReader 640x288 RGBA_8888 maxImages=3
[ OK ] createVirtualDisplay — VirtualDisplay 640x288 dpi=280 surface=ImageReader
[ OK ] first frame — primeiro frame em NNNms (received=… processed=…)
CAPTURA = RUNNING, FPS > 0, frame age válido, frames recebidos > 0 → MediaProjection OK
```

4. O diagnóstico **libera a captura no final** (não deixa o indicador de gravação ligado).

### Se falhar (o mais importante deste teste)

A V6 **não** esconde nada. Copie e envie o bloco `[MEDIA_PROJECTION]` que aparece no relatório
(botão **“Compartilhar log + diagnóstico”**) — ele contém:

```
stage=…                     ← etapa exata que falhou
exceptionClass=…            ← classe da exceção original (ex.: java.lang.SecurityException)
exceptionMessage=…          ← mensagem original do sistema
stackTrace=…                ← primeiras linhas
resultCode=… dataPresent=… managerPresent=…
serviceStarted=… foregroundStarted=… projectionCreated=…
imageReaderCreated=… virtualDisplayCreated=… firstFrameReceived=…
sdk=33 manufacturer=samsung model=SM-A225M screen=720x1600 rot=…
```

Também é útil o arquivo `files/diagnostico_captura_v6.txt` (mesmo conteúdo) e
`files/fisch-log.txt`. Nada de dado pessoal é coletado; o log é local.

## 3. Sessão de pesca (START) — deve **observar**, não pescar

1. Com a captura OK, toque em **START / solicitar captura de tela** e autorize a captura.
2. Confira na tela:

| Campo | Esperado |
|---|---|
| `Capture state` | `RUNNING` |
| `Projection` | `ACTIVE` |
| `Service` | `RUNNING` |
| `frame age` | número em ms (ex.: `33 ms`) — **nunca** `9223372036854775807` e `N/A` só se não houver frame |
| `frames received/processed` | crescendo |
| `FPS` | > 0 |
| `FSM pesca` | `WAITING_FOR_ROD` |
| `realInput` | **OFF** |

3. Abra o Roblox/Fisch e vá até a tela com o **botão da vara** visível. Sem tocar em nada, observe:
   - `Vara: detected=true` quando a vara aparece;
   - `confirmed=true` só depois de ~3 frames estáveis com confiança acima do limiar;
   - `castAutorizado=false` com `realInput` OFF (motivo `REAL_INPUT_DISABLED` ou
     `ROBLOX_NOT_DETECTED` se o Roblox não estiver em foreground).
4. `WOULD CAST` pode aparecer no log: é o comportamento correto com `realInput` OFF.
5. **Nada deve ser clicado.** Se a vara desaparecer da tela, `rodConfirmed` volta a falso e o
   estado permanece `WAITING_FOR_ROD`.

## 4. Input real (só quando você decidir testar gestos)

1. Ligue o switch **“Autorizar gestos reais nesta sessão”** e confirme o diálogo.
2. O Roblox precisa estar em foreground (o detector exige evidência de janela verificada).
3. Requisitos simultâneos para um gesto sair: captura `RUNNING` + frame fresco (`frame age` abaixo de
   `safety.maxFrameAgeMs`) + vara confirmada + sem overlay suspeito + sem emergency stop.
4. **EMERGÊNCIA** está na notificação do serviço e cancela tudo imediatamente.

## 5. STOP / EMERGENCY STOP

- **STOP**: encerra a sessão, libera VirtualDisplay, ImageReader, Surface e a projeção
  (o indicador de captura do Android desaparece) e volta `Capture state = STOPPED`.
- **EMERGENCY STOP**: mesma liberação + latch; exige “Limpar latch de emergência” antes de novo START.
- Depois de qualquer um dos dois, um novo START deve funcionar sem reiniciar o app
  (nada é reaproveitado da sessão anterior).

## 6. Checklist de sucesso da V6 no A22

- [ ] `DIAGNÓSTICO DE CAPTURA` termina com `CAPTURA = RUNNING` e `FPS > 0`;
- [ ] `frame age` mostra um valor em ms (não `N/A`, nunca `9223372036854775807`);
- [ ] `frames received > 0` e crescendo com a tela mudando;
- [ ] START deixa a FSM em `WAITING_FOR_ROD` e **não** clica em nada;
- [ ] `realInput` permanece `OFF` por padrão;
- [ ] STOP e EMERGENCY liberam a captura (indicador do sistema apaga);
- [ ] novo START funciona após STOP;
- [ ] se algo falhar, existe `exceptionClass`, `exceptionMessage`, `stage` e stack no relatório.

## 7. Como reportar um problema

Envie: (1) o relatório completo do botão *“Compartilhar log + diagnóstico”*, (2) o
`device:` do topo do app (`samsung SM-A225M (a22) sdk=33 screen=720x1600 dpi=… rot=…`) e (3) o
instante em que o problema aconteceu. Com o bloco `[MEDIA_PROJECTION]` em mãos, a correção da
próxima iteração é direta — não há mais “MediaProjection indisponível” sem causa.
