package com.fischa.core.config

/**
 * Single source of truth for every tunable in the system.
 *
 * Rules enforced by this class:
 *  - no absolute screen coordinates anywhere (geometry is expressed as fractions of the
 *    processed frame, i.e. resolution/orientation independent);
 *  - no hardcoded shake counts / minigame durations / fish speeds;
 *  - time constants in seconds, angles/sizes as fractions of frame width/height.
 *
 * Serialized with [toMap]/[fromMap] so the Android Settings UI and the replay harness share
 * one representation.
 */
data class AppConfig(
    val capture: Capture = Capture(),
    val vision: Vision = Vision(),
    val tracking: Tracking = Tracking(),
    val control: Control = Control(),
    val shake: Shake = Shake(),
    val cast: Cast = Cast(),
    val rod: Rod = Rod(),
    val state: StateTiming = StateTiming(),
    val safety: Safety = Safety(),
) {

    data class Capture(
        /** Width the frame is rescaled to before vision processing (keeps aspect). */
        val processingWidth: Int = 640,
        /** Target pipeline rate; capture may run faster, processing is rate-limited. */
        val targetFps: Int = 30,
        /** Ring size of the shared frame buffer (older entries get overwritten). */
        val bufferSlots: Int = 3,
        /** Drop the incoming frame if the consumer is slower than this (backpressure). */
        val maxQueueLatencyMs: Int = 220,
        /** Consider the capture stream dead after this long without a new frame. */
        val streamTimeoutMs: Long = 2500,
        /**
         * V6 §20: how long START/DIAGNÓSTICO waits for the first frame before declaring the
         * capture broken. The A22 (Android 13) typically delivers it within 300–900 ms.
         */
        val firstFrameTimeoutMs: Long = 2500,
    )

    data class Vision(
        // -- fishing (rod) button --
        val rodSearchX0: Float = 0.55f, val rodSearchX1: Float = 1.0f,
        val rodSearchY0: Float = 0.40f, val rodSearchY1: Float = 0.95f,
        val rodRadiusMinF: Float = 0.040f, val rodRadiusMaxF: Float = 0.085f,
        /** Interior of the rod button is dark; ring is brighter than both sides. */
        val rodInteriorMaxGray: Int = 90,
        val rodRingMinDelta: Int = 18,
        val rodPriorCx: Float = 0.818f, val rodPriorCy: Float = 0.692f,
        val rodPriorWeight: Float = 0.25f,

        // -- shake prompt --
        val shakeRadiusMinF: Float = 0.055f, val shakeRadiusMaxF: Float = 0.105f,
        /** Shake text glyphs are white on dark. */
        val shakeGlyphMinGray: Int = 205,
        val shakeInteriorMaxGray: Int = 70,
        val shakeRingMinDelta: Int = 14,
        /** ignore the very top (roblox/system HUD) and bottom hotbar strips */
        val shakeSearchY0: Float = 0.06f, val shakeSearchY1: Float = 0.98f,
        val shakeSearchX0: Float = 0.02f, val shakeSearchX1: Float = 1.0f,

        // -- minigame bar --
        val barSearchY0: Float = 0.55f, val barSearchY1: Float = 0.88f,
        val barMinWidthF: Float = 0.14f, val barMaxWidthF: Float = 0.72f,
        val barMinHeightF: Float = 0.016f, val barMaxHeightF: Float = 0.065f,
        /** interior gray window of the dark bar (measured 18..30; tolerant band for lighting) */
        val barDarkMin: Int = 8, val barDarkMax: Int = 140,
        val barDarkColFrac: Float = 0.42f,
        val barDarkRowFrac: Float = 0.30f,
        val barDarkMaxChroma: Int = 80,
        /** a bar pixel must be darker than the world [bar] rows below it (night water is dark
         *  in absolute terms too — the relative test is what separates them) */
        val barBgBelowOffset: Int = 24,
        val barBgBelowDelta: Int = 18,
        /** non-dark columns tolerated while growing a bar run (fish icon, borders) */
        val barGrowMaxHoles: Int = 6,
        /** red end-cap triangles are strong evidence of bar edges */
        val barEndCapWeight: Float = 0.30f,

        // -- white player block --
        val blockMinWidthF: Float = 0.06f, val blockMaxWidthF: Float = 0.45f,
        val blockWhiteMinGray: Int = 185,
        /** tint when fish outside the block: measured val~64 red hue */
        val mismatchSatMin: Int = 45, val mismatchValMin: Int = 35, val mismatchValMax: Int = 170,

        // -- fish indicator --
        val fishNeedleMinGray: Int = 88, val fishNeedleMaxGray: Int = 215,
        val fishDarkMinGray: Int = 32, val fishDarkMaxGray: Int = 125, // needle inside white block
        val fishNeedleAbovePx: Int = 26, // search height above bar top, at 640w scale
        val fishNeedleMinRunF: Float = 0.10f, // as fraction of bar width for scoring

        // -- progress --
        val progressSearchBelowF: Float = 0.30f,
        val progressMinWidthFracOfBar: Float = 0.35f,
        val progressMaxWidthFracOfBar: Float = 1.15f,
        val progressFillMinGray: Int = 175,
        val progressOutlineMinGray: Int = 118,

        // -- hud presence (roblox alive signal) --
        /** sample strips where the standard Roblox hud sits: top-left menu + right rod area */
        val hudTopStripH: Float = 0.16f,
    )

    data class Tracking(
        val fishAlpha: Float = 0.55f,
        val fishBeta: Float = 0.30f,
        /** innovation (in normalized bar units) beyond which a jump re-syncs hard */
        val fishJumpResyncNorm: Float = 0.22f,
        val fishMaxLostMs: Long = 420,
        val blockAlpha: Float = 0.62f,
        val blockMaxLostMs: Long = 500,
        val barAlpha: Float = 0.35f,
        val barLockMinConf: Float = 0.55f,
        val barUnlockConf: Float = 0.30f,
        val confEmaAlpha: Float = 0.45f,
        val confDecayPerSec: Float = 1.8f,
    )

    data class Control(
        /** normalized deadband on |error| (fraction of bar width). Inside it we do nothing. */
        val deadband: Float = 0.030f,
        val tapBand: Float = 0.075f,          // deadband..tapBand -> short taps
        val holdBand: Float = 0.155f,          // beyond -> sustained hold
        val kP: Float = 4.2f,                  // proportional gain (1/s)
        val kFF: Float = 1.15f,                // fish-velocity feedforward gain
        val kDrift: Float = 0.55f,             // leftward drift compensation added when aligned
        val lookaheadSec: Float = 0.10f,       // prediction horizon for fish position
        val lookaheadVelClamp: Float = 0.55f,  // normalized units/s cap used by lookahead
        val minHoldMs: Int = 90,
        val minReleaseMs: Int = 55,
        val minTapGapMs: Int = 70,             // avoid useless press spam
        val tapDurMs: Int = 120,               // single short tap length
        val maxHoldMs: Int = 2200,             // hold is re-evaluated after this even if error persists
        /**
         * The game's mobile control is "tap & hold anywhere"; on Android without root we
         * emulate a hold as a cadence of overlapping-duration taps (see docs/LIMITATIONS.md).
         */
        val tapHoldPeriodMs: Int = 280,
        val tapHoldDurMs: Int = 240,
        val tapDurScaleByErr: Boolean = true,
        /** when either tracker loses confidence below this, controller freezes (safe hold-off) */
        val minConfidence: Float = 0.34f,
        /** near-edge margins (fraction of bar) where extra caution is applied */
        val edgeMargin: Float = 0.06f,
        /** don't tap when already at the right edge; release-only there */
        val rightEdgeNoHold: Boolean = false,
        /** smooth progress: if progress decreasing for this long, widen hold band */
        val catchUpAfterMs: Long = 900,
        val catchUpBandBonus: Float = 0.10f,
    )

    data class Shake(
        /** frames the shake must persist before we tap (temporal validation) */
        val confirmFrames: Int = 2,
        /** frames without detection before we consider it gone */
        val lostFrames: Int = 3,
        val tapCooldownMs: Long = 130,
        val tapDurMs: Int = 60,
        /** never tap the same center twice without the prompt having moved/vanished */
        val sameSpotGuardMs: Long = 700,
        val sameSpotEpsF: Float = 0.02f,
        val minConfidence: Float = 0.45f,
    )

    data class Cast(
        /**
         * CAST_HOLD_DURATION_MS (spec V5 §6): how long the rod-button hold is extended before
         * release. Default 3000 ms; configurable, never a hard dependency of the cycle.
         */
        val holdMs: Long = 3000,
        val minConfidence: Float = 0.40f,
        val confirmFrames: Int = 2,
        /** after a successful cast press we wait at least this before looking for shakes */
        val postCastSettleMs: Long = 600,
        val pressCooldownMs: Long = 4000,
    )

    /**
     * Visual confirmation of the fishing-rod button (spec V5 §3/§4/§5). The rod button is the
     * ONLY trigger that may start a fishing cycle; a single frame is never enough:
     *  - the detector must report it for [confirmFrames] consecutive frames;
     *  - each frame's confidence must be >= [confidenceThreshold] (ROD_CONFIDENCE_THRESHOLD);
     *  - the button center must stay within [stableToleranceF] (normalized) of the streak anchor;
     *  - the whole streak must complete within [confirmWindowMs] (no slow accumulation).
     * All values are configurable; no fixed sleep is used anywhere.
     */
    data class Rod(
        val confirmFrames: Int = 3,
        val confidenceThreshold: Float = 0.55f,
        val stableToleranceF: Float = 0.02f,
        val confirmWindowMs: Long = 1500,
    )

    data class StateTiming(
        /** min time a stable state must hold before a "vision lost" escalation */
        val visionLostAfterMs: Long = 2500,
        /** min frames of bar presence to enter MINIGAME */
        val minigameEnterFrames: Int = 3,
        /** min frames of bar absence to leave MINIGAME */
        val minigameExitFrames: Int = 5,
        /** how long to keep the progress trend memory after the bar vanished */
        val catchMemoryMs: Long = 1600,
        /** catch confirmation text watch window after minigame exit */
        val confirmWindowMs: Long = 6000,
        /** min progress value that still counts as "was winning" at exit (catch vs escape) */
        val catchMinProgress: Float = 0.30f,
        val resetDwellMs: Long = 900,
        /** safety timeout of WAITING_FOR_WATER: no shake/bar evidence after a cast → back to rod watch */
        val waitingForWaterMs: Long = 10_000,
        val idleAutoArm: Boolean = true,
    )

    data class Safety(
        val minGlobalConfidence: Float = 0.30f,
        /** Minimum confidence of the visual target for an individual gesture. */
        val minActionConfidence: Float = 0.30f,
        val denyWhenCaptureStale: Boolean = true,
        val denyWhenRobloxMissing: Boolean = true,
        /** A decision older than this is never allowed to begin or renew an input. */
        val maxFrameAgeMs: Long = 180,
        /** Rate floor applies to new taps/holds, not bounded hold renewals/releases. */
        val minInputGapMs: Long = 25,
        val maxTapMs: Long = 500,
        val maxHoldLeaseMs: Long = 250,
        /** Android StrokeDescription continuation quantum; actual holds renew after each frame. */
        val holdQuantumMs: Long = 65,
        /** Maximum one continuous AccessibilityService stroke train before forced release. */
        val maxManualHoldMs: Long = 5000,
        /** A hold renewal must be refreshed before this watchdog expires. */
        val watchdogMs: Long = 350,
    )

    /** Validate tunables at every load boundary; bounded gesture and frame values fail closed. */
    fun validate(): AppConfig {
        require(capture.processingWidth in 320..1600)
        require(capture.targetFps in 10..60)
        require(capture.bufferSlots in 2..8)
        require(capture.maxQueueLatencyMs in 20..1000)
        require(capture.streamTimeoutMs in 500..10_000)
        require(capture.firstFrameTimeoutMs in 500..10_000)

        require(vision.rodPriorCx.isFinite() && vision.rodPriorCx in 0f..1f)
        require(vision.rodPriorCy.isFinite() && vision.rodPriorCy in 0f..1f)
        require(vision.blockWhiteMinGray in 0..255)
        require(vision.fishNeedleAbovePx in 1..200)
        require(vision.progressFillMinGray in 0..255)

        require(tracking.fishAlpha.isFinite() && tracking.fishAlpha in 0f..1f)
        require(tracking.fishBeta.isFinite() && tracking.fishBeta in 0f..1f)
        require(tracking.fishJumpResyncNorm.isFinite() && tracking.fishJumpResyncNorm in 0.01f..1f)
        require(tracking.fishMaxLostMs in 50..3000)
        require(tracking.blockAlpha.isFinite() && tracking.blockAlpha in 0f..1f)
        require(tracking.barAlpha.isFinite() && tracking.barAlpha in 0f..1f)
        require(tracking.barLockMinConf.isFinite() && tracking.barLockMinConf in 0f..1f)
        require(tracking.barUnlockConf.isFinite() && tracking.barUnlockConf in 0f..tracking.barLockMinConf)
        require(tracking.confEmaAlpha.isFinite() && tracking.confEmaAlpha in 0f..1f)
        require(tracking.confDecayPerSec.isFinite() && tracking.confDecayPerSec in 0f..10f)

        require(control.deadband.isFinite() && control.deadband in 0.001f..0.25f)
        require(control.tapBand.isFinite() && control.tapBand in 0.01f..0.5f && control.tapBand > control.deadband)
        require(control.holdBand.isFinite() && control.holdBand in control.tapBand..1f)
        require(control.kP.isFinite() && control.kP in 0f..20f)
        require(control.kFF.isFinite() && control.kFF in 0f..10f)
        require(control.kDrift.isFinite() && control.kDrift in -5f..5f)
        require(control.lookaheadSec.isFinite() && control.lookaheadSec in 0f..1f)
        require(control.lookaheadVelClamp.isFinite() && control.lookaheadVelClamp in 0f..2f)
        require(control.minHoldMs in 0..2000)
        require(control.minReleaseMs in 0..2000)
        require(control.minTapGapMs in 0..2000)
        require(control.tapDurMs in 1..500)
        require(control.maxHoldMs in 250..5000)
        require(control.tapHoldPeriodMs in 30..5000)
        require(control.tapHoldDurMs in 1..500)
        require(control.minConfidence.isFinite() && control.minConfidence in 0f..1f)
        require(control.edgeMargin.isFinite() && control.edgeMargin in 0f..0.5f)
        require(control.catchUpAfterMs in 0..10_000)
        require(control.catchUpBandBonus.isFinite() && control.catchUpBandBonus in 0f..0.5f)

        require(shake.confirmFrames in 1..30)
        require(shake.lostFrames in 1..60)
        require(shake.tapCooldownMs in 0..10_000)
        require(shake.tapDurMs.toLong() in 1L..safety.maxTapMs)
        require(shake.sameSpotGuardMs in 0..60_000)
        require(shake.sameSpotEpsF.isFinite() && shake.sameSpotEpsF in 0f..1f)
        require(shake.minConfidence.isFinite() && shake.minConfidence in 0f..1f)

        require(cast.holdMs in 500..5000)
        require(cast.minConfidence.isFinite() && cast.minConfidence in 0f..1f)
        require(cast.confirmFrames in 1..30)
        require(cast.postCastSettleMs in 0..15_000)
        require(cast.pressCooldownMs in 0..60_000)

        require(rod.confirmFrames in 1..30)
        require(rod.confidenceThreshold.isFinite() && rod.confidenceThreshold in 0f..1f)
        require(rod.stableToleranceF.isFinite() && rod.stableToleranceF in 0f..1f)
        require(rod.confirmWindowMs in 100..10_000)

        require(state.visionLostAfterMs in 100..60_000)
        require(state.minigameEnterFrames in 1..30)
        require(state.minigameExitFrames in 1..60)
        require(state.catchMemoryMs in 0..30_000)
        require(state.confirmWindowMs in 100..30_000)
        require(state.catchMinProgress.isFinite() && state.catchMinProgress in 0f..1f)
        require(state.resetDwellMs in 0..30_000)
        require(state.waitingForWaterMs in 500..60_000)

        require(safety.minGlobalConfidence.isFinite() && safety.minGlobalConfidence in 0f..1f)
        require(safety.minActionConfidence.isFinite() && safety.minActionConfidence in 0f..1f)
        require(safety.maxFrameAgeMs in 20..1000)
        require(safety.minInputGapMs in 0..250)
        require(safety.maxTapMs in 1..500)
        require(safety.maxHoldLeaseMs in 30..500)
        require(safety.holdQuantumMs in 30..100)
        require(safety.maxManualHoldMs in 500..10_000)
        require(safety.watchdogMs in 100..1000)
        return this
    }

    // ---- (de)serialization: flat string map, one source of truth for Settings UI & harness ----

    /**
     * Only the tunables that materially change behaviour are exposed as a settings map; the
     * rest stay in code defaults so the Settings UI does not become a wall of numbers.
     */
    fun toMap(): Map<String, String> = buildMap {
        put("capture.processingWidth", capture.processingWidth.toString())
        put("capture.targetFps", capture.targetFps.toString())
        put("capture.bufferSlots", capture.bufferSlots.toString())
        put("capture.maxQueueLatencyMs", capture.maxQueueLatencyMs.toString())
        put("capture.streamTimeoutMs", capture.streamTimeoutMs.toString())
        put("capture.firstFrameTimeoutMs", capture.firstFrameTimeoutMs.toString())
        put("vision.rodPriorCx", vision.rodPriorCx.toString())
        put("vision.rodPriorCy", vision.rodPriorCy.toString())
        put("vision.blockWhiteMinGray", vision.blockWhiteMinGray.toString())
        put("vision.fishNeedleAbovePx", vision.fishNeedleAbovePx.toString())
        put("vision.progressFillMinGray", vision.progressFillMinGray.toString())
        put("tracking.fishAlpha", tracking.fishAlpha.toString())
        put("tracking.fishBeta", tracking.fishBeta.toString())
        put("tracking.fishJumpResyncNorm", tracking.fishJumpResyncNorm.toString())
        put("tracking.fishMaxLostMs", tracking.fishMaxLostMs.toString())
        put("tracking.blockAlpha", tracking.blockAlpha.toString())
        put("control.deadband", control.deadband.toString())
        put("control.tapBand", control.tapBand.toString())
        put("control.holdBand", control.holdBand.toString())
        put("control.kP", control.kP.toString())
        put("control.kFF", control.kFF.toString())
        put("control.kDrift", control.kDrift.toString())
        put("control.lookaheadSec", control.lookaheadSec.toString())
        put("control.minHoldMs", control.minHoldMs.toString())
        put("control.minReleaseMs", control.minReleaseMs.toString())
        put("control.minTapGapMs", control.minTapGapMs.toString())
        put("control.tapDurMs", control.tapDurMs.toString())
        put("control.maxHoldMs", control.maxHoldMs.toString())
        put("control.tapHoldPeriodMs", control.tapHoldPeriodMs.toString())
        put("control.tapHoldDurMs", control.tapHoldDurMs.toString())
        put("control.minConfidence", control.minConfidence.toString())
        put("shake.confirmFrames", shake.confirmFrames.toString())
        put("shake.lostFrames", shake.lostFrames.toString())
        put("shake.tapCooldownMs", shake.tapCooldownMs.toString())
        put("shake.tapDurMs", shake.tapDurMs.toString())
        put("shake.minConfidence", shake.minConfidence.toString())
        put("cast.holdMs", cast.holdMs.toString())
        put("cast.minConfidence", cast.minConfidence.toString())
        put("cast.postCastSettleMs", cast.postCastSettleMs.toString())
        put("cast.pressCooldownMs", cast.pressCooldownMs.toString())
        put("rod.confirmFrames", rod.confirmFrames.toString())
        put("rod.confidenceThreshold", rod.confidenceThreshold.toString())
        put("rod.stableToleranceF", rod.stableToleranceF.toString())
        put("rod.confirmWindowMs", rod.confirmWindowMs.toString())
        put("state.waitingForWaterMs", state.waitingForWaterMs.toString())
        put("safety.minGlobalConfidence", safety.minGlobalConfidence.toString())
        put("safety.minActionConfidence", safety.minActionConfidence.toString())
        put("safety.maxFrameAgeMs", safety.maxFrameAgeMs.toString())
        put("safety.minInputGapMs", safety.minInputGapMs.toString())
        put("safety.maxTapMs", safety.maxTapMs.toString())
        put("safety.maxHoldLeaseMs", safety.maxHoldLeaseMs.toString())
        put("safety.holdQuantumMs", safety.holdQuantumMs.toString())
        put("safety.maxManualHoldMs", safety.maxManualHoldMs.toString())
        put("safety.watchdogMs", safety.watchdogMs.toString())
    }

    fun withOverrides(map: Map<String, String>): AppConfig {
        fun i(key: String, cur: Int) = map[key]?.toIntOrNull() ?: cur
        fun l(key: String, cur: Long) = map[key]?.toLongOrNull() ?: cur
        fun f(key: String, cur: Float) = map[key]?.toFloatOrNull() ?: cur
        return copy(
            capture = capture.copy(
                processingWidth = i("capture.processingWidth", capture.processingWidth),
                targetFps = i("capture.targetFps", capture.targetFps),
                bufferSlots = i("capture.bufferSlots", capture.bufferSlots),
                maxQueueLatencyMs = i("capture.maxQueueLatencyMs", capture.maxQueueLatencyMs),
                streamTimeoutMs = l("capture.streamTimeoutMs", capture.streamTimeoutMs),
                firstFrameTimeoutMs = l("capture.firstFrameTimeoutMs", capture.firstFrameTimeoutMs),
            ),
            vision = vision.copy(
                rodPriorCx = f("vision.rodPriorCx", vision.rodPriorCx),
                rodPriorCy = f("vision.rodPriorCy", vision.rodPriorCy),
                rodSearchX0 = f("vision.rodSearchX0", vision.rodSearchX0),
                rodSearchX1 = f("vision.rodSearchX1", vision.rodSearchX1),
                rodSearchY0 = f("vision.rodSearchY0", vision.rodSearchY0),
                rodSearchY1 = f("vision.rodSearchY1", vision.rodSearchY1),
                shakeSearchX0 = f("vision.shakeSearchX0", vision.shakeSearchX0),
                shakeSearchX1 = f("vision.shakeSearchX1", vision.shakeSearchX1),
                shakeSearchY0 = f("vision.shakeSearchY0", vision.shakeSearchY0),
                shakeSearchY1 = f("vision.shakeSearchY1", vision.shakeSearchY1),
                barSearchY0 = f("vision.barSearchY0", vision.barSearchY0),
                barSearchY1 = f("vision.barSearchY1", vision.barSearchY1),
                blockWhiteMinGray = i("vision.blockWhiteMinGray", vision.blockWhiteMinGray),
                fishNeedleAbovePx = i("vision.fishNeedleAbovePx", vision.fishNeedleAbovePx),
                progressFillMinGray = i("vision.progressFillMinGray", vision.progressFillMinGray),
            ),
            tracking = tracking.copy(
                fishAlpha = f("tracking.fishAlpha", tracking.fishAlpha),
                fishBeta = f("tracking.fishBeta", tracking.fishBeta),
                fishJumpResyncNorm = f("tracking.fishJumpResyncNorm", tracking.fishJumpResyncNorm),
                fishMaxLostMs = l("tracking.fishMaxLostMs", tracking.fishMaxLostMs),
                blockAlpha = f("tracking.blockAlpha", tracking.blockAlpha),
            ),
            control = control.copy(
                deadband = f("control.deadband", control.deadband),
                tapBand = f("control.tapBand", control.tapBand),
                holdBand = f("control.holdBand", control.holdBand),
                kP = f("control.kP", control.kP),
                kFF = f("control.kFF", control.kFF),
                kDrift = f("control.kDrift", control.kDrift),
                lookaheadSec = f("control.lookaheadSec", control.lookaheadSec),
                minHoldMs = i("control.minHoldMs", control.minHoldMs),
                minReleaseMs = i("control.minReleaseMs", control.minReleaseMs),
                minTapGapMs = i("control.minTapGapMs", control.minTapGapMs),
                tapDurMs = i("control.tapDurMs", control.tapDurMs),
                maxHoldMs = i("control.maxHoldMs", control.maxHoldMs),
                tapHoldPeriodMs = i("control.tapHoldPeriodMs", control.tapHoldPeriodMs),
                tapHoldDurMs = i("control.tapHoldDurMs", control.tapHoldDurMs),
                minConfidence = f("control.minConfidence", control.minConfidence),
            ),
            shake = shake.copy(
                confirmFrames = i("shake.confirmFrames", shake.confirmFrames),
                lostFrames = i("shake.lostFrames", shake.lostFrames),
                tapCooldownMs = l("shake.tapCooldownMs", shake.tapCooldownMs),
                tapDurMs = i("shake.tapDurMs", shake.tapDurMs),
                minConfidence = f("shake.minConfidence", shake.minConfidence),
            ),
            cast = cast.copy(
                holdMs = l("cast.holdMs", cast.holdMs),
                minConfidence = f("cast.minConfidence", cast.minConfidence),
                postCastSettleMs = l("cast.postCastSettleMs", cast.postCastSettleMs),
                pressCooldownMs = l("cast.pressCooldownMs", cast.pressCooldownMs),
            ),
            rod = rod.copy(
                confirmFrames = i("rod.confirmFrames", rod.confirmFrames),
                confidenceThreshold = f("rod.confidenceThreshold", rod.confidenceThreshold),
                stableToleranceF = f("rod.stableToleranceF", rod.stableToleranceF),
                confirmWindowMs = l("rod.confirmWindowMs", rod.confirmWindowMs),
            ),
            state = state.copy(
                waitingForWaterMs = l("state.waitingForWaterMs", state.waitingForWaterMs),
            ),
            safety = safety.copy(
                minGlobalConfidence = f("safety.minGlobalConfidence", safety.minGlobalConfidence),
                minActionConfidence = f("safety.minActionConfidence", safety.minActionConfidence),
                maxFrameAgeMs = l("safety.maxFrameAgeMs", safety.maxFrameAgeMs),
                minInputGapMs = l("safety.minInputGapMs", safety.minInputGapMs),
                maxTapMs = l("safety.maxTapMs", safety.maxTapMs),
                maxHoldLeaseMs = l("safety.maxHoldLeaseMs", safety.maxHoldLeaseMs),
                holdQuantumMs = l("safety.holdQuantumMs", safety.holdQuantumMs),
                maxManualHoldMs = l("safety.maxManualHoldMs", safety.maxManualHoldMs),
                watchdogMs = l("safety.watchdogMs", safety.watchdogMs),
            ),
        )
    }
}
