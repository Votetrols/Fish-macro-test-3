package com.fischa.core.pipeline

import com.fischa.core.common.clamp
import com.fischa.core.config.AppConfig
import com.fischa.core.control.CastController
import com.fischa.core.control.CastGestureAction
import com.fischa.core.control.ControlAction
import com.fischa.core.control.FishingController
import com.fischa.core.control.GestureTarget
import com.fischa.core.control.InputExecutor
import com.fischa.core.control.ShakeController
import com.fischa.core.debug.RenderModel
import com.fischa.core.log.Tags
import com.fischa.core.log.ThrottledLog
import com.fischa.core.safety.DenyReason
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.GestureAction
import com.fischa.core.safety.InputRequest
import com.fischa.core.safety.InputSafetyGuard
import com.fischa.core.safety.RobloxForegroundStatus
import com.fischa.core.safety.SafetyContext
import com.fischa.core.state.Evidence
import com.fischa.core.state.FishingState
import com.fischa.core.state.FishingStateMachine
import com.fischa.core.tracking.BarTracker
import com.fischa.core.tracking.ConfidenceTracker
import com.fischa.core.tracking.FishTracker
import com.fischa.core.tracking.PlayerBarTracker
import com.fischa.core.tracking.ProgressTracker
import com.fischa.core.tracking.RodConfirmTracker
import com.fischa.core.vision.CatchConfirmDetector
import com.fischa.core.vision.DetSnapshot
import com.fischa.core.vision.FishDetector
import com.fischa.core.vision.FishingBarDetector
import com.fischa.core.vision.FishingButtonDetector
import com.fischa.core.vision.PlayerBarDetector
import com.fischa.core.vision.ProgressDetector
import com.fischa.core.vision.ShakeDetector
import com.fischa.core.vision.VisionFrame
import kotlin.math.max

/**
 * Firefox V3 core: vision → temporal tracking → evidence-driven state machine → controllers
 * → one safety gate → input executor. This file intentionally keeps the original Firefox
 * detector/tracker/controller composition; Android and Roblox APIs are injected at the edge.
 */
class VisionPipeline(
    val cfg: AppConfig,
    private val executor: InputExecutor,
    private val log: ThrottledLog,
    val safety: SafetyContext = SafetyContext(),
    val emergency: EmergencyStop = EmergencyStop(),
    /** Optional live platform probe used again for every Android hold segment. */
    private val foregroundStatusProvider: (() -> RobloxForegroundStatus?)? = null,
    private val monotonicNowNs: () -> Long = { System.nanoTime() },
) : AutoCloseable {
    // Vision — original Firefox detector implementations are preserved.
    private val rodDetector = FishingButtonDetector(cfg.vision)
    private val shakeDetector = ShakeDetector(cfg.vision)
    private val barDetector = FishingBarDetector(cfg.vision)
    private val blockDetector = PlayerBarDetector(cfg.vision)
    private val fishDetector = FishDetector(cfg.vision)
    private val progressDetector = ProgressDetector(cfg.vision)
    private val catchDetector = CatchConfirmDetector(cfg.vision)

    // Tracking — original AlphaBeta and confidence trackers are preserved.
    private val barTracker = BarTracker(cfg.tracking)
    private val fishTracker = FishTracker(cfg.tracking)
    private val blockTracker = PlayerBarTracker(cfg.tracking)
    private val progressTracker = ProgressTracker()
    private val confTracker = ConfidenceTracker(cfg.tracking)
    private val barRect = floatArrayOf(0f, 0f, 0f, 0f)

    /** V5: temporal confirmation of the rod button (the only cycle trigger). */
    private val rodTracker = RodConfirmTracker(cfg.rod)
    /** release directives issued by CastController on the previous frame, consumed by the FSM */
    private var pendingCastComplete = false
    private var pendingCastAborted = false

    private val stateMachine = FishingStateMachine(cfg.state)
    private val shakeController = ShakeController(cfg.shake)
    private val castController = CastController(cfg.cast)
    private val controller = FishingController(cfg.control)
    private val guard = InputSafetyGuard(cfg.safety)
    private val evidence = Evidence()

    val output = PipelineOutput()

    /** Set only by the host after the user explicitly chooses Start. */
    @Volatile var armed: Boolean = false
        set(value) {
            field = value
            safety.macroEnabled = value
        }

    @Volatile var lastFps: Float = 0f
    private var lastFrameNs = 0L
    @Volatile private var holdActive = false
    @Volatile private var realGestureActive = false
    private var holdTarget: GestureTarget? = null
    private var holdAnchorOverride: GestureTarget? = null
    private var lastActionName = ControlAction.NONE

    @Volatile var render: RenderModel? = null

    private fun normBox(src: DetSnapshot, w: Int, h: Int): FloatArray? {
        if (!src.detected) return null
        return floatArrayOf(src.box.left / w, src.box.top / h, src.box.right / w, src.box.bottom / h)
    }

    /** Optional user calibration; absent by default, the target is derived from the detected bar. */
    fun setHoldAnchor(nx: Float, ny: Float) {
        holdAnchorOverride = if (nx.isFinite() && ny.isFinite() && nx in 0f..1f && ny in 0f..1f) {
            GestureTarget(nx, ny)
        } else null
    }

    private val emergencyListener: () -> Unit = {
        runCatching { executor.cancelAll() }
        runCatching { executor.releaseAll() }
        realGestureActive = false
        holdActive = false
        holdTarget = null
        controller.reset()
    }

    init {
        emergency.addListener(emergencyListener)
    }

    fun onFrame(frame: VisionFrame, input: PipelineInput) {
        val startedNs = monotonicNowNs()
        val frameNs = frame.timestampNs
        val nowNs = input.currentTimeNs.takeIf { it > 0L } ?: frameNs
        val ageMs = if (frameNs <= 0L || nowNs < frameNs) Long.MAX_VALUE else (nowNs - frameNs) / 1_000_000L
        log.setNow(frameNs)
        frame.ensureGray()
        val w = frame.width
        val h = frame.height

        // Platform/session gates are refreshed before any decision. Unknown is false by design.
        safety.macroEnabled = armed && input.macroEnabled
        safety.realInputEnabled = input.realInputEnabled
        safety.captureHealthy = input.captureHealthy
        safety.robloxDetected = input.robloxDetected
        safety.platformAuthorized = input.inputAuthorized
        safety.overlaySuspected = input.overlaySuspected
        safety.frameTimestampNs = frameNs
        safety.state = stateMachine.state

        if ((!input.inputAuthorized || !input.captureHealthy || !safety.macroEnabled ||
                !input.realInputEnabled || emergency.latched) && realGestureActive) {
            releaseActiveGesture(cancel = true)
        }

        runDetectors(frame)

        // ---- tracking ---------------------------------------------------------------------
        val barDetected = barDetector.out.detected
        val barLocked = barDetected && barTracker.update(
            barDetector.geometry.left,
            barDetector.geometry.top,
            barDetector.geometry.right,
            barDetector.geometry.bottom,
            max(barDetector.out.confidence, 0.6f),
            barRect,
        )
        if (barLocked) barTracker.touch(frameNs)
        val barWidth = max(1f, barRect[2] - barRect[0])

        if (barLocked) {
            blockDetector.setBarPrior(barRect[0], barRect[1], barRect[2], barRect[3])
            fishDetector.setBarPrior(barRect[0], barRect[1], barRect[2], barRect[3])
            progressDetector.setBarPrior(barRect[0], barRect[1], barRect[2], barRect[3])
        } else {
            blockDetector.clearBarPrior()
            fishDetector.clearBarPrior()
            progressDetector.clearBarPrior()
        }
        blockDetector.process(frame)
        if (barLocked && blockDetector.out.detected) {
            fishDetector.blockL = blockDetector.geom.left.toInt()
            fishDetector.blockR = blockDetector.geom.right.toInt()
        } else {
            fishDetector.blockL = -1
            fishDetector.blockR = -1
        }
        fishDetector.priorXNorm = if (fishTracker.out.valid) fishTracker.out.x else -1f
        fishDetector.process(frame)
        progressDetector.process(frame)

        if (barLocked) {
            if (blockDetector.out.detected) {
                blockTracker.update(
                    frameNs,
                    (blockDetector.geom.centerX - barRect[0]) / barWidth,
                    blockDetector.geom.width / barWidth,
                    blockDetector.out.confidence,
                    blockDetector.out.v0 > 0.5f,
                    barRect[0], barRect[2], blockDetector.geom.left, blockDetector.geom.right,
                )
            } else {
                blockTracker.update(frameNs, null, 0f, 0f, false, barRect[0], barRect[2], 0f, 0f)
            }
            if (fishDetector.out.detected) {
                fishTracker.update(frameNs, fishDetector.out.v0, fishDetector.out.confidence, barWidth)
            } else {
                fishTracker.update(frameNs, null, 0f, barWidth)
            }
        } else {
            blockTracker.reset()
            fishTracker.reset()
        }
        progressTracker.update(
            frameNs,
            if (progressDetector.out.detected) progressDetector.out.v0 else null,
            progressDetector.out.confidence,
        )
        confTracker.update(barDetector.out.confidence, fishTracker.out.confidence, blockTracker.out.confidence, frameNs)
        safety.trackingOk = fishTracker.out.valid && !fishTracker.out.lost &&
            blockTracker.out.valid && !blockTracker.out.lost &&
            fishTracker.out.confidence >= cfg.control.minConfidence &&
            blockTracker.out.confidence >= cfg.control.minConfidence

        // ---- state evidence ---------------------------------------------------------------
        evidence.fishingButton = rodDetector.out.detected
        evidence.fishingButtonConf = rodDetector.out.confidence
        evidence.shake = shakeDetector.out.detected
        evidence.shakeConf = shakeDetector.out.confidence
        evidence.bar = barDetector.out.detected
        evidence.barConf = barDetector.out.confidence
        evidence.fishOk = fishTracker.out.valid && !fishTracker.out.lost
        evidence.playerOk = blockTracker.out.valid && !blockTracker.out.lost
        evidence.progress = progressTracker.value
        evidence.catchConfirm = catchDetector.out.detected
        evidence.catchConfirmConf = catchDetector.out.confidence
        evidence.robloxForeground = input.inputAuthorized
        evidence.captureHealthy = input.captureHealthy
        evidence.overlaySuspected = input.overlaySuspected
        evidence.globalConf = confTracker.global
        evidence.shakeGone = shakeController.phase == ShakeController.Phase.SEARCHING && !shakeDetector.out.detected
        evidence.nowNs = frameNs
        evidence.dtSec = if (lastFrameNs == 0L) 1f / 30f
        else clamp((frameNs - lastFrameNs) / 1e9f, 0.001f, 0.25f)
        lastFrameNs = frameNs

        // ---- V5 rod-button gate (spec §3/§4/§5) ------------------------------------------
        // ROI-optimized detector → presence → confidence → temporal confirmation → safety gate.
        // The rod button is the only trigger that may start a cycle; nothing here sends input.
        val rodCx = if (rodDetector.out.detected) rodDetector.out.box.centerX / w else 0f
        val rodCy = if (rodDetector.out.detected) rodDetector.out.box.centerY / h else 0f
        val rodConfirmed = rodTracker.update(
            rodDetector.out.detected, rodDetector.out.confidence, rodCx, rodCy, frameNs,
        )
        val castGate = guard.evaluateCastGate(
            safety, rodDetector.out.confidence, rodCx, rodCy, nowNs, emergency,
        )
        evidence.rodConfirmed = rodConfirmed
        evidence.castAuthorized = castGate.allowed
        evidence.castComplete = pendingCastComplete
        evidence.castAborted = pendingCastAborted
        pendingCastComplete = false
        pendingCastAborted = false

        val oldState = stateMachine.state
        stateMachine.armed = safety.macroEnabled
        stateMachine.update(evidence)
        val state = stateMachine.state
        safety.state = state
        if (state != oldState) {
            log.i(Tags.STATE, "st", "[STATE] ${oldState.name} -> ${state.name} (${stateMachine.lastReason})")
            if ((oldState == FishingState.CASTING && state != FishingState.CASTING) ||
                (oldState.isMinigame() && !state.isMinigame()) || state.isError) {
                releaseActiveGesture(cancel = state.isError)
            }
            onStateEntry(state, frameNs)
        }

        // ---- controllers ------------------------------------------------------------------
        var request: InputRequest? = null
        var reason = ""
        var intendedAction = ControlAction.NONE
        var reportedDurationMs = 0

        if (state == FishingState.CASTING) {
            val press = castController.tick(
                rodDetector.out.detected,
                rodDetector.out.confidence,
                if (rodDetector.out.detected) rodDetector.out.box.centerX / w else 0f,
                if (rodDetector.out.detected) rodDetector.out.box.centerY / h else 0f,
                frameNs,
            )
            if (press != null) {
                reason = press.reason
                reportedDurationMs = cfg.cast.holdMs.toInt()
                val action = when (press.action) {
                    CastGestureAction.START -> GestureAction.HOLD_START
                    CastGestureAction.EXTEND -> GestureAction.HOLD_EXTEND
                    CastGestureAction.RELEASE -> GestureAction.HOLD_RELEASE
                }
                if (action == GestureAction.HOLD_START) {
                    holdTarget = GestureTarget(press.nx, press.ny)
                    holdActive = true
                }
                if (action == GestureAction.HOLD_RELEASE) {
                    holdActive = false
                    // consumed by the FSM on the next frame: finished cast → WAITING_FOR_WATER,
                    // aborted cast (target lost) → back to WAITING_FOR_ROD
                    pendingCastComplete = castController.releaseWasComplete
                    pendingCastAborted = !castController.releaseWasComplete
                }
                safety.controllerSafe = action == GestureAction.HOLD_RELEASE ||
                    (press.confidence.isFinite() && press.confidence >= cfg.cast.minConfidence &&
                        press.nx.isFinite() && press.nx in 0f..1f &&
                        press.ny.isFinite() && press.ny in 0f..1f)
                request = InputRequest(
                    action = action,
                    nx = press.nx,
                    ny = press.ny,
                    durationMs = if (action == GestureAction.HOLD_RELEASE) 0L else cfg.safety.maxHoldLeaseMs,
                    confidence = press.confidence,
                    reason = reason,
                )
            }
        }

        if (stateMachine.shakePhaseActive()) {
            val cx = if (shakeDetector.out.detected) shakeDetector.out.box.centerX / w else -1f
            val cy = if (shakeDetector.out.detected) shakeDetector.out.box.centerY / h else -1f
            val tap = shakeController.tick(shakeDetector.out.detected, shakeDetector.out.confidence, cx, cy, frameNs)
            if (tap != null) {
                reason = tap.reason
                reportedDurationMs = tap.durMs
                safety.controllerSafe = shakeDetector.out.detected &&
                    shakeDetector.out.confidence.isFinite() &&
                    shakeDetector.out.confidence >= cfg.shake.minConfidence &&
                    tap.nx.isFinite() && tap.nx in 0f..1f &&
                    tap.ny.isFinite() && tap.ny in 0f..1f &&
                    tap.durMs.toLong() in 1L..cfg.safety.maxTapMs
                request = InputRequest(
                    GestureAction.TAP,
                    tap.nx,
                    tap.ny,
                    tap.durMs.toLong(),
                    shakeDetector.out.confidence,
                    tap.reason,
                )
            }
        }

        if (barLocked && state.controlling) {
            val decision = controller.update(
                frameNs,
                evidence.dtSec,
                fishTracker.out,
                blockTracker.out,
                progressTracker.rate,
            )
            safety.controllerSafe = decision.safe
            intendedAction = decision.action
            reason = decision.reason
            output.errorNorm = decision.error
            output.fishVel = decision.fishVel
            output.playerVel = decision.playerVel
            output.desiredVel = decision.desiredVel
            val target = holdAnchorOverride ?: GestureTarget(
                ((barRect[0] + barRect[2]) * 0.5f / w).coerceIn(0f, 1f),
                ((barRect[1] + barRect[3]) * 0.5f / h).coerceIn(0f, 1f),
            )
            val confidence = minOf(fishTracker.out.confidence, blockTracker.out.confidence)
            when (decision.action) {
                ControlAction.TAP -> {
                    request = InputRequest(
                        GestureAction.TAP,
                        target.x,
                        target.y,
                        decision.tapDurMs.toLong(),
                        confidence,
                        decision.reason,
                    )
                    reportedDurationMs = decision.tapDurMs
                }
                ControlAction.HOLD_START -> {
                    holdTarget = target
                    holdActive = true
                    request = InputRequest(
                        GestureAction.HOLD_START,
                        target.x,
                        target.y,
                        cfg.safety.maxHoldLeaseMs,
                        confidence,
                        decision.reason,
                    )
                    reportedDurationMs = cfg.safety.maxHoldLeaseMs.toInt()
                }
                ControlAction.HOLD_EXTEND -> {
                    val activeTarget = holdTarget ?: target.also { holdTarget = it }
                    request = InputRequest(
                        GestureAction.HOLD_EXTEND,
                        activeTarget.x,
                        activeTarget.y,
                        cfg.safety.maxHoldLeaseMs,
                        confidence,
                        decision.reason,
                    )
                    reportedDurationMs = cfg.safety.maxHoldLeaseMs.toInt()
                }
                ControlAction.HOLD_RELEASE -> {
                    holdActive = false
                    request = InputRequest(GestureAction.HOLD_RELEASE, reason = decision.reason)
                }
                ControlAction.NONE -> Unit
            }
            lastActionName = decision.action
        } else {
            if (holdActive && !state.isMinigame() && state != FishingState.CASTING) {
                holdActive = false
                request = InputRequest(GestureAction.HOLD_RELEASE, reason = "state no longer permits hold")
            }
            if (!state.isMinigame()) {
                controller.reset()
                lastActionName = ControlAction.NONE
                output.errorNorm = 0f
                output.fishVel = 0f
                output.playerVel = 0f
                output.desiredVel = 0f
            }
        }

        // A safe-release directive always wins over any earlier command from the frame.
        if (emergency.latched || !input.captureHealthy || !input.inputAuthorized || !safety.macroEnabled ||
            !input.realInputEnabled
        ) {
            if (realGestureActive) request = InputRequest(GestureAction.CANCEL_ALL, reason = "safety context lost")
        }

        // ---- single input safety gate -----------------------------------------------------
        var denied = DenyReason.OK
        var issued = false
        request?.let { original ->
            val platformHoldDown = executor.holdStillActive()
            if (original.action == GestureAction.HOLD_EXTEND && realGestureActive && platformHoldDown == false) {
                // The platform ended the hold on its own (lease/watchdog/Android cancel). Never
                // keep "extending" a finger that is no longer down — re-press through the guard.
                log.w(Tags.INPUT, "hold-lost", "[INPUT] platform hold ended; re-issuing HOLD_START")
                realGestureActive = false
            }
            val effective = when {
                original.action == GestureAction.HOLD_EXTEND && !realGestureActive ->
                    original.copy(action = GestureAction.HOLD_START)
                else -> original
            }
            if (effective.action == GestureAction.HOLD_RELEASE || effective.action == GestureAction.CANCEL_ALL) {
                if (effective.action == GestureAction.CANCEL_ALL) executor.cancelAll() else executor.holdRelease()
                realGestureActive = false
                holdTarget = null
            } else {
                safety.targetConfidence = effective.confidence
                val verdict = guard.evaluate(safety, effective, nowNs, emergency)
                if (!verdict.allowed) {
                    denied = verdict.reason
                    log.w(Tags.SAFETY, "deny", "[SAFETY] INPUT BLOCKED reason=${verdict.reason.name} package=${input.foregroundPackage} frameAge=${ageMs}ms")
                    if (realGestureActive) releaseActiveGesture(cancel = true)
                } else if (!input.realInputEnabled) {
                    // Normally caught by the guard; retained explicitly as a defense-in-depth
                    // assertion. Simulation still publishes the controller's intended action.
                    denied = DenyReason.REAL_INPUT_DISABLED
                } else {
                    val authorizeSegment = {
                        refreshPlatformSafety()
                        safety.targetConfidence = effective.confidence
                        val liveNow = monotonicNowNs()
                        guard.evaluate(safety, effective, liveNow, emergency).allowed
                    }
                    val accepted = when (effective.action) {
                        GestureAction.TAP -> executor.tap(
                            effective.nx, effective.ny, effective.durationMs.toInt(), authorizeSegment,
                        )
                        GestureAction.HOLD_START -> executor.holdStart(
                            effective.nx, effective.ny, effective.durationMs.toInt(), authorizeSegment,
                        )
                        GestureAction.HOLD_EXTEND -> executor.holdExtend(
                            effective.nx, effective.ny, effective.durationMs.toInt(), authorizeSegment,
                        )
                        else -> false
                    }
                    if (accepted) {
                        issued = true
                        if (effective.action == GestureAction.HOLD_START || effective.action == GestureAction.HOLD_EXTEND) {
                            realGestureActive = true
                            holdTarget = GestureTarget(effective.nx, effective.ny)
                        }
                        safety.lastInputNs = nowNs
                        log.i(
                            Tags.INPUT,
                            "gesture",
                            "[INPUT] ${effective.action.name} x=${"%.3f".format(effective.nx)} y=${"%.3f".format(effective.ny)} duration=${effective.durationMs}ms confidence=${"%.2f".format(effective.confidence)}",
                        )
                    } else {
                        denied = DenyReason.INVALID_COMMAND
                        if (effective.action == GestureAction.HOLD_START || effective.action == GestureAction.HOLD_EXTEND) {
                            realGestureActive = false
                        }
                        log.w(Tags.INPUT, "dispatch", "[INPUT] gesture dispatch rejected")
                    }
                }
            }
        }

        if (ageMs > cfg.safety.maxFrameAgeMs && denied == DenyReason.OK && request != null) {
            denied = DenyReason.FRAME_STALE
        }
        val safetyBasePass = safety.macroEnabled && safety.realInputEnabled && safety.captureHealthy &&
            safety.robloxDetected && safety.platformAuthorized && !safety.overlaySuspected &&
            !emergency.latched && ageMs in 0..cfg.safety.maxFrameAgeMs

        // ---- outputs / debug snapshot -----------------------------------------------------
        with(output) {
            fishingButton.copyFrom(rodDetector.out)
            shake.copyFrom(shakeDetector.out)
            bar.copyFrom(barDetector.out)
            player.copyFrom(blockDetector.out)
            fish.copyFrom(fishDetector.out)
            progress.copyFrom(progressDetector.out)
            catchConfirm.copyFrom(catchDetector.out)
            this.state = state
            this.stateReason = stateMachine.lastReason
            this.fishXNorm = fishTracker.out.x
            this.playerXNorm = blockTracker.out.x
            this.progressValue = max(0f, progressTracker.value)
            this.progressRate = progressTracker.rate
            this.globalConfidence = confTracker.global
            this.frameAgeMs = ageMs
            this.intendedAction = intendedAction
            this.tapDurationMs = reportedDurationMs
            this.holdActive = holdActive
            this.decisionReason = reason
            this.inputIssued = issued
            this.inputDeniedReason = if (denied == DenyReason.OK) "" else denied.name
            this.inputAuthorized = safetyBasePass
            this.realInputEnabled = input.realInputEnabled
            this.robloxDetected = input.robloxDetected
            this.foregroundPackage = input.foregroundPackage
            this.foregroundActivityWindow = input.foregroundActivityWindow
            this.foregroundBlockReason = input.foregroundBlockReason
            this.emergencyLatched = emergency.latched
            this.armed = safety.macroEnabled
            this.shakeSessionTaps = shakeController.tapsThisSession
            this.shakeSession = stateMachine.shakeSession
            this.castPhase = castController.phase.name
            this.rodDetected = rodDetector.out.detected
            this.rodConfidence = rodDetector.out.confidence
            this.rodConfirmed = rodConfirmed
            this.castAuthorized = castGate.allowed
            this.castGateReason = if (castGate.allowed) "" else castGate.reason.name
            this.barRectPx[0] = barRect[0]
            this.barRectPx[1] = barRect[1]
            this.barRectPx[2] = barRect[2]
            this.barRectPx[3] = barRect[3]
            this.barLocked = barLocked
            this.blockCenterPx = if (blockDetector.out.detected) blockDetector.geom.centerX else -1f
            this.fishCenterPx = if (fishDetector.out.detected) (fishDetector.out.box.left + fishDetector.out.box.right) / 2f else -1f
        }
        render = RenderModel(
            state = state,
            fps = lastFps,
            procMs = (monotonicNowNs() - startedNs) / 1e6f,
            barBox = if (barLocked) floatArrayOf(barRect[0] / w, barRect[1] / h, barRect[2] / w, barRect[3] / h) else null,
            blockBox = normBox(blockDetector.out, w, h),
            fishBox = normBox(fishDetector.out, w, h),
            shakeBox = normBox(shakeDetector.out, w, h),
            rodBox = normBox(rodDetector.out, w, h),
            progressBox = normBox(progressDetector.out, w, h),
            fishCx = fishTracker.out.x,
            playerCx = blockTracker.out.x,
            error = output.errorNorm,
            fishVel = output.fishVel,
            playerVel = output.playerVel,
            desiredVel = output.desiredVel,
            action = lastActionName.name,
            actionReason = reason,
            progress = output.progressValue,
            progressRate = output.progressRate,
            confGlobal = confTracker.global,
            confBar = confTracker.bar,
            confFish = confTracker.fish,
            confPlayer = confTracker.player,
            confShake = shakeDetector.out.confidence,
            confRod = rodDetector.out.confidence,
            rodConfirmed = rodConfirmed,
            castAuthorized = castGate.allowed,
            holdActive = holdActive,
            tapsThisSession = shakeController.tapsThisSession,
            shakeSession = stateMachine.shakeSession,
            denyReason = if (denied == DenyReason.OK) "" else denied.name,
            emergency = emergency.latched,
            armed = safety.macroEnabled,
            robloxDetected = input.robloxDetected,
            foregroundPackage = input.foregroundPackage,
            foregroundWindow = input.foregroundActivityWindow,
            inputAuthorized = safetyBasePass,
            realInputEnabled = input.realInputEnabled,
            frameAgeMs = ageMs,
            safetyBlockedReason = when {
                denied != DenyReason.OK -> denied.name
                !safetyBasePass -> if (!input.realInputEnabled) "REAL_INPUT_DISABLED" else input.foregroundBlockReason
                else -> "PASS"
            },
        )

        if (frameNs - lastInputLogNs >= 1_000_000_000L || lastInputLogNs == 0L) {
            lastInputLogNs = frameNs
            // V5 §20 test-mode line: one compact, greppable status per second for the A22.
            log.i(
                Tags.STATE,
                "watch",
                "[STATE] STATE=${state.name} ROD_DETECTED=${rodDetector.out.detected} " +
                    "ROD_CONFIDENCE=${"%.2f".format(rodDetector.out.confidence)} ROD_CONFIRMED=$rodConfirmed " +
                    "ROBLOX=${input.robloxDetected} INPUT_AUTHORIZED=$safetyBasePass " +
                    "DECISION=${when {
                        state == FishingState.CASTING -> "CASTING"
                        rodConfirmed && !castGate.allowed -> "WOULD_CAST"
                        else -> intendedAction.name
                    }} " +
                    "ACTION=${request?.action?.name ?: "NONE"} " +
                    "BLOCK_REASON=${when {
                        denied != DenyReason.OK -> denied.name
                        state == FishingState.WAITING_FOR_ROD && rodConfirmed && !castGate.allowed -> castGate.reason.name
                        !safetyBasePass -> input.foregroundBlockReason
                        else -> "NONE"
                    }}",
            )
            log.i(
                Tags.SAFETY,
                "snapshot",
                "[SAFETY] foregroundPackage=${input.foregroundPackage} foregroundActivity/window=${input.foregroundActivityWindow} robloxDetected=${input.robloxDetected} inputAuthorized=${safetyBasePass} blockReason=${input.foregroundBlockReason} frameAge=${ageMs}ms realInput=${input.realInputEnabled}",
            )
            log.i(
                Tags.TRACKING,
                "tracks",
                "[TRACK] fish=${"%.3f".format(fishTracker.out.x)} v=${"%+.3f".format(fishTracker.out.v)} conf=${"%.2f".format(fishTracker.out.confidence)} player=${"%.3f".format(blockTracker.out.x)} v=${"%+.3f".format(blockTracker.out.v)} conf=${"%.2f".format(blockTracker.out.confidence)} progress=${"%.2f".format(progressTracker.value)}",
            )
            log.i(
                Tags.CONTROL,
                "decision",
                "[CONTROL] state=${state.name} error=${"%+.3f".format(output.errorNorm)} action=${request?.action ?: intendedAction} reason=$reason",
            )
        }
    }

    private var lastInputLogNs = 0L

    private fun refreshPlatformSafety() {
        val status = runCatching { foregroundStatusProvider?.invoke() }.getOrNull()
        if (status == null) {
            safety.robloxDetected = false
            safety.platformAuthorized = false
            safety.overlaySuspected = true
            return
        }
        safety.robloxDetected = status.robloxDetected
        safety.platformAuthorized = status.inputAuthorized
        safety.overlaySuspected = status.overlayActive
    }

    private fun releaseActiveGesture(cancel: Boolean) {
        if (cancel) runCatching { executor.cancelAll() }
        runCatching { executor.releaseAll() }
        realGestureActive = false
        holdActive = false
        holdTarget = null
    }

    private fun onStateEntry(state: FishingState, nowNs: Long) {
        when (state) {
            FishingState.WAITING_FOR_ROD -> {
                // a new cycle may only begin after a FRESH visual confirmation of the rod button
                rodTracker.reset()
            }
            FishingState.SEARCHING_SHAKE -> {
                shakeController.resetSession()
                castController.onShakeOrBarSeen(nowNs)
            }
            FishingState.CASTING -> {
                castController.start()
                rodTracker.reset()
            }
            FishingState.FISHING_MINIGAME_DETECTED -> {
                controller.reset()
                holdActive = false
                fishTracker.reset()
                blockTracker.reset()
                progressTracker.reset()
            }
            FishingState.RESET -> {
                shakeController.resetSession()
                castController.reset()
                controller.reset()
                holdActive = false
                catchDetector.reset()
            }
            FishingState.CATCH_CONFIRMATION -> catchDetector.noteBarGone(nowNs)
            FishingState.VISION_LOST,
            FishingState.CAPTURE_ERROR,
            FishingState.ROBLOX_NOT_DETECTED,
            FishingState.EMERGENCY_STOP,
            FishingState.INVALID_STATE -> {
                releaseActiveGesture(cancel = true)
                controller.reset()
                fishTracker.reset()
                blockTracker.reset()
            }
            else -> Unit
        }
    }

    private fun runDetectors(frame: VisionFrame) {
        rodDetector.process(frame)
        shakeDetector.process(frame)
        barDetector.process(frame)
        catchDetector.process(frame)
    }

    fun setFpsMeasured(fps: Float) { lastFps = fps }

    /** User-initiated disarm; gesture cleanup does not require authorization. */
    fun disarm(nowNs: Long) {
        armed = false
        stateMachine.armed = false
        safety.macroEnabled = false
        releaseActiveGesture(cancel = true)
        controller.reset()
        log.i(Tags.SYSTEM, "disarm", "[SYSTEM] macro disarmed at $nowNs")
    }

    override fun close() {
        disarm(monotonicNowNs())
        emergency.removeListener(emergencyListener)
    }

    private fun FishingState.isMinigame() = controlling
}
