# Fisch AutoBot — macro de pesca para Roblox Fisch (Android, visão computacional)

Implementação completa em Kotlin do ciclo de pesca (captura → visão → rastreamento →
máquina de estados → controle em malha fechada → entrada), guiada por **detecção visual**,
sem coordenadas, tempos, larguras de barra ou resoluções fixas no comportamento.

**Base oficial: Fisch AutoBot V5 (Firefox).** A V6 é uma **atualização incremental** dela — nada de
reescrita: FSM, detectores, tracking, controladores, SafetyGuard, FrameBuffer e harnesses são os da
V5; o que mudou foi o que o teste no Galaxy A22 provou estar quebrado (MediaProjection, foreground
service, diagnóstico e exibição de “frame age”).

## Status (build 0.4.0-a22 — V6 — alvo: Samsung Galaxy A22 / SM-A225M / Android 13)

- ✅ **APK debug compilado e verificado neste ambiente**: `com.fischa.app`, versionCode 4,
  versionName `0.4.0-a22`, minSdk 26, targetSdk 35, assinado (v2). Manifesto conferido:
  `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION`, `POST_NOTIFICATIONS` e
  `FischEngineService` com `foregroundServiceType=mediaProjection`. Ver
  [`docs/RELATORIO_BUILD_V6.md`](docs/RELATORIO_BUILD_V6.md).
- ✅ **V6 — MediaProjection corrigida de verdade.** A V5 criava a projeção na Activity e só depois
  subia o foreground service; desde o Android 10 (e obrigatório para API 34+) o
  `getMediaProjection()` só é aceito com um **foreground service type `mediaProjection` já ativo** —
  a V5 levava `SecurityException`, engolia a exceção e mostrava
  “MediaProjection indisponível — tente novamente”. A V6 faz a ordem correta
  (consentimento → `startForegroundService` → `startForeground(type=mediaProjection)` →
  `getMediaProjection` → callback → ImageReader → VirtualDisplay → primeiro frame) e **nunca esconde
  a causa**: registra classe, mensagem, stack, SDK, fabricante, modelo, resultCode, dataPresent,
  estado do serviço/foreground/projeção/reader/display. Diagnóstico completo:
  [`docs/DIAGNOSTICO_MEDIAPROJECTION_V6.md`](docs/DIAGNOSTICO_MEDIAPROJECTION_V6.md).
- ✅ **Status de captura separado da pesca** (`STOPPED / REQUESTING_PERMISSION / AUTHORIZED /
  STARTING / RUNNING / FAILED`) e status de `Projection`/`Service` na tela de diagnóstico, com
  `frames received / processed / dropped`, `FPS`, e **frame age = `N/A` quando não há frame**
  (nunca mais `9223372036854775807`).
- ✅ **Botão “DIAGNÓSTICO DE CAPTURA”** (spec §18): testa só a infraestrutura (manager →
  consentimento → foreground service → MediaProjection → ImageReader → VirtualDisplay → primeiro
  frame), gera relatório e libera tudo. **Não pesca, não clica, não liga realInput, não procura a
  vara.**
- ✅ **START só liga a infraestrutura**: estado inicial `WAITING_FOR_ROD`; o ciclo só começa com o
  **botão da vara confirmado visualmente** (frames estáveis + confiança + autorização do
  InputSafetyGuard); após cada captura volta a `WAITING_FOR_ROD`. `realInput` segue **OFF por
  padrão** (com OFF o log pode registrar `ROD_CONFIRMED`/`WOULD_CAST`, mas **nenhum gesto** é
  enviado).
- ✅ **Captura ≠ entrada**: a captura roda independente de Roblox/`realInput`/vara (é
  infraestrutura, e precisa ser diagnosticável). Roblox em foreground é exigido **apenas** para
  enviar input.
- ✅ **Testes**: `./gradlew :core:test` → **120 testes, 0 falhas**; `./gradlew :core:selfTest` →
  **138 checks, 0 falhas**; `:app:lintDebug` → 0 erros. Mapeamento dos 22 testes exigidos em
  [`docs/RESULTADO_TESTES_V6.md`](docs/RESULTADO_TESTES_V6.md).
- ⚠️ **Teste real no Galaxy A22 não executado neste ambiente** (sem aparelho/Roblox). Não afirmamos
  captura funcionando no A22 — afirmamos que ela compila, que o fluxo foi corrigido e que, se o
  Samsung recusar, o app agora **mostra a exceção original**. Roteiro de teste no aparelho:
  [`docs/COMO_TESTAR_A22_V6.md`](docs/COMO_TESTAR_A22_V6.md).
- 📄 O que mudou na V6: [`docs/CHANGES_V6.md`](docs/CHANGES_V6.md) · limite/estado da V5:
  [`docs/LIMITATIONS.md`](docs/LIMITATIONS.md) · V5: [`docs/CHANGES_V5.md`](docs/CHANGES_V5.md) ·
  V4/A22: [`docs/CHANGES_A22.md`](docs/CHANGES_A22.md) · instalação:
  [`docs/INSTALL_A22.md`](docs/INSTALL_A22.md) · análise do vídeo:
  [`docs/VIDEO_ANALYSIS.md`](docs/VIDEO_ANALYSIS.md).

### Estados

- **Captura (V6, separada):** `STOPPED → REQUESTING_PERMISSION → AUTHORIZED → STARTING → RUNNING`
  e, em qualquer falha, `FAILED` (com a causa original preservada). `Projection`:
  `NONE / AUTHORIZED / ACTIVE / STOPPED / ERROR`. `Service`: `STOPPED / STARTING / RUNNING / ERROR`.
- **Pesca (FSM V5, preservada):** `IDLE → WAITING_FOR_ROD → CASTING → WAITING_FOR_WATER →
  SEARCHING_SHAKE ⇄ PRESSING_SHAKE → FISHING_MINIGAME_DETECTED → TRACKING_FISH →
  CONTROLLING_PLAYER_BAR → CATCH_CONFIRMATION → RESET → WAITING_FOR_ROD`; erros:
  `VISION_LOST / CAPTURE_ERROR / ROBLOX_NOT_DETECTED / INVALID_STATE / EMERGENCY_STOP`.
  A V6 não mistura as duas: falha de MediaProjection **não** vira erro da FSM de pesca.

## Fluxo da MediaProjection na V6 (spec §3/§4/§5/§6)

```
START / DIAGNÓSTICO
   ↓ createScreenCaptureIntent()                    (Activity, API moderna registerForActivityResult)
   ↓ resultCode == RESULT_OK && data != null ?      (senão: log CAPTURE_PERMISSION_RESULT + fim)
   ↓ startForegroundService(ACTION_START|ACTION_DIAGNOSE_CAPTURE, resultCode, data)
   ↓ onStartCommand: avalia consentimento → startForeground(id=42, type=mediaProjection)  ← PRIMEIRO
   ↓ getMediaProjection(resultCode, data)                                                  ← DEPOIS
   ↓ registerCallback  (obrigatório antes do VirtualDisplay em API 34+)
   ↓ ImageReader.newInstance(640×288, RGBA_8888, 3)
   ↓ createVirtualDisplay(surface = imageReader.surface)
   ↓ espera o 1º frame (capture.firstFrameTimeoutMs = 2500 ms)
   ↓ CaptureState.RUNNING
        ├─ START      → pipeline armado, FSM = WAITING_FOR_ROD (nunca CAST automático)
        └─ DIAGNÓSTICO→ relatório + teardown (sem input, sem pesca)
STOP / EMERGENCY STOP → cancela gestos, para o VirtualDisplay, fecha o ImageReader, libera a
                        Surface e a projeção, `CaptureState.STOPPED`, pronto para novo START.
```

Tags de log (spec §21): `[CAPTURE] [MEDIA_PROJECTION] [FOREGROUND_SERVICE] [VIRTUAL_DISPLAY]
[IMAGE_READER] [FRAME] [ROBLOX] [INPUT] [SAFETY] [FSM] [STATE] [DETECTION] [TRACKING] [CONTROL]
[ERROR] [SYSTEM]`.

## Arquitetura

```
core/  (kotlin-jvm, sem dependências Android)
  config/     AppConfig — todo tunable centralizado (inclui capture.firstFrameTimeoutMs)
  common/     RectF, CoordinateMapper (CAPTURE→NORMALIZED→DEVICE, única camada), clamp/lerp
  capture/    V6: CaptureState/CaptureSessionState (máquina de captura), CaptureDiagnostics
              (DeviceProfile + CaptureAttempt + bloco [MEDIA_PROJECTION]), CaptureConsent
              (CAPTURE_PERMISSION_RESULT), CaptureProbe/CaptureDiagnostics.run (diagnóstico §18),
              FrameStats (FrameAge N/A + contadores), CaptureErrorText
  vision/     VisionFrame (buffers reusados), DiscMatcher, 7 detectores + TemporalDetector
  tracking/   AlphaBeta, FishTracker, PlayerBarTracker, BarTracker, ProgressTracker,
              ConfidenceTracker, RodConfirmTracker (gatilho da vara)
  control/    FishingController, ShakeController, CastController, InputExecutor (interface)
  safety/     InputSafetyGuard (porta única de toda entrada real), EmergencyStop (latch)
  state/      FishingStateMachine (inalterada na V6)
  log/        ThrottledLog + Tags (incl. MEDIA_PROJECTION/FOREGROUND_SERVICE/VIRTUAL_DISPLAY/
              IMAGE_READER/FRAME/ROBLOX/FSM)
  debug/      RenderModel
  pipeline/   VisionPipeline — visão→tracking→estados→decisão→gate→executor
  tools/      SelfTest (138 checks), ReplayMain
app/  (android, camada fina)
  MainActivity  consentimento via registerForActivityResult; tela de diagnóstico de captura
                (Capture/Projection/Service/frame age/frames/última falha amigável + técnica);
                botões DIAGNÓSTICO DE CAPTURA / relatório / compartilhar log
  FischEngineService  dono ÚNICO da captura: foreground service (type mediaProjection) →
                MediaProjection → callback → reader → display → 1º frame → loop de frames;
                ações START/STOP/EMERGENCY/CLEAR_EMERGENCY/DIAGNOSE_CAPTURE/DEBUG_OVERLAY
  ScreenCaptureSource  ImageReader/VirtualDisplay diagnosticáveis por etapa, Surface validada,
                primeiro frame medido, contadores received/processed/dropped/gated
  CaptureConsentHolder  fallback de ROM p/ o consentimento (substitui o ProjectionHolder da V5)
  AppLog        log process-wide (ring 600 linhas + files/fisch-log.txt) visível já na Activity
  ui/DiagnosticsLog  event()/failure()/block() — nunca mascara exceção
  GameAccessibilityService / AndroidInputExecutor / DebugOverlay / SettingsActivity  (V5)
```

Decisões de design herdadas da V5 (continua valendo):

1. **Core determinístico e portátil** — o mesmo código roda no celular e no replay; nada de
   `android.*` no core; entrada sai só por `InputExecutor`.
2. **Barra de pesca = âncora do bloco branco** (não varredura de “linha escura”.
3. **Tudo normalizado pela barra** (medida por frame, nunca assumida).
4. **Bloco do jogador com tamanho fixo medido**; controle P-D + feedforward + tendência de deriva.
5. **`Shake` sem timeout artificial** (enquanto o prompt existir, pode pressionar).
6. **Segurança acima de tudo**: `InputSafetyGuard` decide cada gesto; `EmergencyStop` com latch.
7. **Overlay/notificação do sistema cobre o jogo** → pausa via `overlaySuspected`.

## Como rodar

### Harnesses (sem Android)

```bash
./gradlew :core:test        # 120 testes JUnit (JVM)
./gradlew :core:selfTest    # 138 checks determinísticos
./gradlew :core:runReplay   # (se presente) replay dos frames de testdata/
```

### Android

1. JDK 17 + Android SDK (`platforms;android-35`, `build-tools;35.0.0`); `local.properties` com
   `sdk.dir=…`; `./gradlew :app:assembleDebug` (wrapper Gradle 8.9 incluso).
2. Instalar → abrir o app → **Habilitar acessibilidade** (“Fisch AutoBot Input”).
3. **DIAGNÓSTICO DE CAPTURA** (não pesca) → confirme `CAPTURA = RUNNING`, `FPS > 0`,
   `frame age` em ms e `frames received > 0`.
4. **START** (autorizar captura) → FSM vai para `WAITING_FOR_ROD`; abra o Roblox/Fisch e não toque
   em nada: a vara deve ser detectada/confirmada sem nenhum gesto (input real OFF).
5. Só ligue **“Autorizar gestos reais nesta sessão”** quando quiser testar gestos de verdade.
   Detalhes e checklist: [`docs/COMO_TESTAR_A22_V6.md`](docs/COMO_TESTAR_A22_V6.md).

## Segurança de uso

- Uma instância só de macro; use em conta alt, não na principal (ToS do Roblox pode punir
  automação — risco por sua conta).
- `realInput` é **OFF por padrão** e só vale para a sessão.
- Botão **EMERGÊNCIA** na notificação: cancela gestos pendentes, destrava holds e para o pipeline.
- O serviço para tudo (e libera a captura) se a captura morrer, o Roblox sair do foreground ou a
  confiança global cair abaixo do mínimo por > watchdog.
- O log é local (`files/fisch-log.txt` + `files/diagnostico_captura_v6.txt`), sem dados pessoais.
