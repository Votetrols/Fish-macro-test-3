# Entrega — Fisch AutoBot V6 (0.4.0-a22)

Alvo: **Samsung Galaxy A22 / SM-A225M / Android 13 (API 33)** · applicationId **`com.fischa.app`**
· base oficial: **Fisch AutoBot V5 (Firefox_v5.zip)**, atualizada de forma incremental.

## 1. Índice dos 7 itens pedidos (spec §25)

| # | Entrega pedida | Onde está |
|---|---|---|
| 1 | **Código-fonte V6** | `FischAutoBotV6-clean.zip` (148 arquivos, só fontes/config/docs) ou a pasta do projeto no workspace (`FischAutoBotV6/`) |
| 2 | **APK V6** | `FischAutoBotV6-debug.apk` — 3.635.728 bytes · SHA-256 `855b1945b1a0181537a97bce8d038c63c7938883afdef8ec4ba39889bce0e9e0` · assinado (v2) |
| 3 | **Relatório de testes** | `RESULTADO_TESTES_V6.md` (120 testes JUnit, 138 checks self-test, mapeamento dos 22 testes exigidos) |
| 4 | **Relatório de build** | `RELATORIO_BUILD_V6.md` (+ `build_v6.log` cru do Gradle) |
| 5 | **Resumo das alterações V5 → V6** | `CHANGES_V6.md` (arquivo por arquivo, comportamento, o que foi preservado) |
| 6 | **Diagnóstico específico da MediaProjection** | `DIAGNOSTICO_MEDIAPROJECTION_V6.md` (causa raiz, evidências, fluxo correto, bloco `[MEDIA_PROJECTION]`) |
| 7 | **README atualizado** | `README.md` |

Roteiro de teste no aparelho: `COMO_TESTAR_A22_V6.md`.

## 2. Resultado da execução neste ambiente

| Verificação | Resultado |
|---|---|
| `:core:test` (JUnit) | **120 testes, 0 falhas** |
| `:core:selfTest` | **138 checks, 0 falhas** (V5 tinha 97) |
| `:app:assembleDebug` | **BUILD SUCCESSFUL** |
| `:app:lintDebug` | **0 erros**, 14 avisos benignos |
| Manifesto no APK | `com.fischa.app`, versionCode 4, versionName `0.4.0-a22`, minSdk 26, targetSdk 35, `FischEngineService` com `foregroundServiceType=mediaProjection`, permissões `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_MEDIA_PROJECTION` + `POST_NOTIFICATIONS` |
| Assinatura | APK Signature Scheme **v2** verificada |

## 3. Declaração honesta (spec §24)

> **Teste real no Galaxy A22 não executado neste ambiente.**

Sem aparelho físico e sem Roblox, não há medição real de captura. Os critérios de sucesso da spec
§20 — `Captura = RUNNING`, `FPS > 0`, frame age válido, `frames received > 0` — **não foram
comprovados no A22**; nenhum resultado de MediaProjection foi inventado. O que a entrega garante:

1. o fluxo da MediaProjection foi corrigido para a ordem exigida pela plataforma
   (foreground service `type=mediaProjection` **antes** de `getMediaProjection()`), que era o defeito
   arquitetural da V5;
2. **nenhuma exceção é mais mascarada**: se o Android/Samsung recusar, a etapa exata, a classe, a
   mensagem e o stack da exceção aparecem na tela e no log;
3. existe um botão de diagnóstico que testa somente a infraestrutura de captura, e
   `START` continua **sem pescar** (`WAITING_FOR_ROD`, `realInput` OFF por padrão).

## 4. Critério final de aceitação (spec, checklist)

| Critério | Estado |
|---|---|
| BUILD OK | ✅ |
| TESTS = 0 FAILURES | ✅ (120 + 138) |
| APK válido | ✅ (assinado, manifesto conferido) |
| applicationId = `com.fischa.app` | ✅ |
| realInput = OFF por padrão | ✅ |
| START não pesca | ✅ (testes `StartSemanticsV5Test`, `CaptureStateMachineTest`) |
| MediaProjection não mascarada por erro genérico | ✅ (`CaptureErrorText`, bloco `[MEDIA_PROJECTION]`, testes) |
| Foreground Service corretamente configurado | ✅ (manifesto verificado + ordem de start) |
| MediaProjection lifecycle correto | ✅ (callback, `onStop`, STOP/Emergency liberam) |
| VirtualDisplay correto | ✅ (surface do próprio ImageReader validada) |
| ImageReader correto | ✅ (dimensões/formato/maxImages registrados) |
| Captura capaz de chegar a RUNNING | ⚠️ implementado; **não comprovado no aparelho** |
| Primeiro frame capaz de ser recebido | ⚠️ implementado (timeout, latência medida); **não comprovado no aparelho** |
| frame age válido (e `N/A` sem frame) | ✅ |
| STOP libera recursos / Emergency libera recursos | ✅ (código + testes) |
| WAITING_FOR_ROD funciona | ✅ |
| Rod detection não gera input sem confirmação | ✅ |
| Roblox foreground exigido somente para INPUT | ✅ |
