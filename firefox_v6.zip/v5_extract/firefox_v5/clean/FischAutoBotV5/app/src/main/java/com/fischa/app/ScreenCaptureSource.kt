package com.fischa.app

import android.content.Context
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.SystemClock
import com.fischa.core.capture.FrameBuffer
import com.fischa.core.common.CoordinateMapper
import com.fischa.core.config.AppConfig
import com.fischa.core.vision.VisionFrame
import java.nio.ByteOrder

/**
 * MediaProjection capture tuned for the Galaxy A22 (spec §4):
 *
 *  - The VirtualDisplay is created directly at the *processing* size (e.g. 640×288 for the A22's
 *    1600×720 landscape), so SurfaceFlinger does the downscale in hardware. No full-resolution
 *    Bitmap, no Canvas rescale, no per-pixel ByteBuffer.get() loop (the previous implementation
 *    touched ~3.5 M bytes per frame in Kotlin — far too slow for the A22's Cortex-A55 cores).
 *  - RGBA_8888 rows are bulk-copied through an IntBuffer into reusable [VisionFrame] slots; the only
 *    per-pixel work is the R/B swap into Android's logical ARGB layout.
 *  - `acquireLatestImage()` + the bounded [FrameBuffer] (latest-only) discard obsolete frames, and a
 *    time gate drops images that arrive faster than `capture.targetFps` without copying them at all
 *    (the A22's 90 Hz panel would otherwise triple the work for no control benefit).
 *  - Every Image is closed in `finally`; failure paths cancel the slot instead of leaking it.
 *
 * The capture size and the physical display size are published as one [CoordinateMapper] so the
 * gesture layer maps touches with exactly the geometry the frames were produced in.
 */
class ScreenCaptureSource(
    private val context: Context,
    private val projection: MediaProjection,
    private val captureHandler: Handler,
    private val cfg: AppConfig.Capture,
    private val onCaptureFailure: (String) -> Unit = {},
) : AutoCloseable {

    @Volatile var captureHealthy: Boolean = false
        private set
    @Volatile var lastFrameTimestampNs: Long = 0L
        private set
    @Volatile var droppedFrames: Long = 0L
        private set
    /** Images skipped by the FPS gate (never copied); diagnostic only. */
    @Volatile var gatedFrames: Long = 0L
        private set
    @Volatile var producedFrames: Long = 0L
        private set

    lateinit var geometry: ScreenGeometry
        private set
    lateinit var mapper: CoordinateMapper
        private set

    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var frameBuffer: FrameBuffer? = null
    private var rowInts = IntArray(0)
    private var captureWidth = 0
    private var captureHeight = 0
    private var serial = 0L
    private var lastPublishedUptimeNs = 0L
    @Volatile private var minIntervalNs = 0L
    @Volatile var effectiveFps: Int = 0
        private set
    @Volatile private var strideWarned = false
    /** V5 §13: transient ImageReader hiccups are counted; only a persistent failure is terminal. */
    private var consecutiveCopyFailures = 0

    val frameWidth: Int get() = captureWidth
    val frameHeight: Int get() = captureHeight

    fun start() {
        geometry = ScreenGeometry.read(context)
        val size = CoordinateMapper.captureSizeFor(geometry.width, geometry.height, cfg.processingWidth)
        captureWidth = size[0]
        captureHeight = size[1]
        mapper = CoordinateMapper(captureWidth, captureHeight, geometry.width, geometry.height)
        setRateLimit(cfg.targetFps)

        frameBuffer?.close()
        frameBuffer = FrameBuffer(captureWidth, captureHeight, cfg.bufferSlots.coerceIn(2, 8))
        rowInts = IntArray(captureWidth)

        reader?.setOnImageAvailableListener(null, null)
        reader?.close()
        display?.release()
        val imageReader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 3)
        reader = imageReader
        imageReader.setOnImageAvailableListener({ source -> copyLatestImage(source) }, captureHandler)
        display = projection.createVirtualDisplay(
            "fisch-v3-capture",
            captureWidth,
            captureHeight,
            geometry.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.surface,
            null,
            captureHandler,
        )
        captureHealthy = display != null && frameBuffer != null
        if (!captureHealthy) onCaptureFailure("VirtualDisplay/FrameBuffer initialization failed")
    }

    private fun copyLatestImage(source: ImageReader) {
        val image = try { source.acquireLatestImage() } catch (e: Exception) {
            // V5 §13: count transient failures; only a persistent failure terminates the session
            // (a single hiccup must not kill the app or the session).
            consecutiveCopyFailures++
            if (consecutiveCopyFailures >= 10) {
                onCaptureFailure("acquireLatestImage failed $consecutiveCopyFailures times: ${e.message}")
            }
            null
        } ?: return
        try {
            val nowNs = SystemClock.elapsedRealtimeNanos()
            if (minIntervalNs > 0L && lastPublishedUptimeNs != 0L && nowNs - lastPublishedUptimeNs < minIntervalNs) {
                gatedFrames++
                return
            }
            val buffer = frameBuffer ?: return
            val frame = buffer.acquireWritable()
            if (frame == null) {
                droppedFrames = buffer.droppedFrames()
                return
            }
            try {
                copyPixels(image, frame)
                val ts = System.nanoTime()
                frame.resetFor(ts, ++serial)
                frame.fps = cfg.targetFps.toFloat()
                if (!buffer.publish(frame)) {
                    buffer.cancelWrite(frame)
                    return
                }
                consecutiveCopyFailures = 0
                lastPublishedUptimeNs = nowNs
                lastFrameTimestampNs = ts
                producedFrames++
                droppedFrames = buffer.droppedFrames()
            } catch (e: Exception) {
                buffer.cancelWrite(frame)
                consecutiveCopyFailures++
                if (consecutiveCopyFailures >= 10) {
                    onCaptureFailure("frame copy failed $consecutiveCopyFailures times: ${e.message}")
                }
            }
        } finally {
            // every Image is closed exactly once, on every path (spec §15)
            image.close()
        }
    }

    private fun copyPixels(image: Image, frame: VisionFrame) {
        val plane = image.planes.firstOrNull() ?: error("ImageReader returned no planes")
        require(image.width == captureWidth && image.height == captureHeight) {
            "capture dimensions changed ${image.width}x${image.height} != ${captureWidth}x${captureHeight}"
        }
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        require(pixelStride == 4) { "RGBA plane pixelStride=$pixelStride (expected 4)" }
        if (rowStride % 4 != 0 && !strideWarned) {
            strideWarned = true
            onCaptureFailure("unexpected rowStride=$rowStride (not a multiple of 4)")
        }
        val bytes = plane.buffer
        bytes.rewind()
        val ints = bytes.order(ByteOrder.nativeOrder()).asIntBuffer()
        val rowStrideInts = rowStride / 4
        val w = captureWidth
        val dst = frame.argb
        val row = rowInts
        val littleEndian = ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN
        var dstOff = 0
        for (y in 0 until captureHeight) {
            ints.position(y * rowStrideInts)
            ints.get(row, 0, w)
            if (littleEndian) {
                // memory R,G,B,A → int 0xAABBGGRR; want 0xFFRRGGBB
                for (x in 0 until w) {
                    val p = row[x]
                    dst[dstOff + x] = (0xFF shl 24) or ((p and 0xFF) shl 16) or (p and 0xFF00) or ((p ushr 16) and 0xFF)
                }
            } else {
                // memory R,G,B,A → int 0xRRGGBBAA
                for (x in 0 until w) {
                    val p = row[x]
                    dst[dstOff + x] = (0xFF shl 24) or (p ushr 8)
                }
            }
            dstOff += w
        }
    }

    /**
     * Adaptive rate gate (spec §4/§12): the engine lowers this when vision processing cannot keep
     * up, so the capture thread stops copying frames that would only be discarded anyway.
     */
    fun setRateLimit(fps: Int) {
        val clamped = fps.coerceIn(5, 60)
        effectiveFps = clamped
        // Allow ~15% jitter so a 30 Hz gate on a 60/90 Hz source does not alias down to 20/22 Hz.
        minIntervalNs = ((1_000_000_000L / clamped) * 0.85f).toLong()
    }

    /** Worker takes only the latest frame; older pending frames have already been returned to the pool. */
    fun takeLatest(): VisionFrame? = frameBuffer?.takeLatest()

    fun release(frame: VisionFrame) {
        frameBuffer?.release(frame)
    }

    fun hasPendingFrame(): Boolean = (frameBuffer?.pendingCount() ?: 0) > 0

    /** True while the physical display still has the size/rotation the session was calibrated for. */
    fun displayConfigurationUnchanged(): Boolean {
        val now = runCatching { ScreenGeometry.read(context) }.getOrNull() ?: return false
        return now.sameAs(geometry)
    }

    override fun close() {
        captureHealthy = false
        runCatching { reader?.setOnImageAvailableListener(null, null) }
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { frameBuffer?.close() }
        display = null
        reader = null
        frameBuffer = null
        rowInts = IntArray(0)
    }
}
