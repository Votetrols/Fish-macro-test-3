package com.fischa.app.ui

import android.util.Log

/** Small bridge from Android callbacks into logcat and the engine's bounded log sink. */
object DiagnosticsLog {
    @Volatile private var sink: ((String, String) -> Unit)? = null

    fun bind(writer: ((String, String) -> Unit)?) { sink = writer }

    fun event(category: String, message: String) {
        Log.i("Fisch/$category", message)
        runCatching { sink?.invoke(category, message) }
    }
}
