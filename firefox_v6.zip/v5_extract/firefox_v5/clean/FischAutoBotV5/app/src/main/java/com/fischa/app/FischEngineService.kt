package com.fischa.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import com.fischa.app.ui.DiagnosticsLog
import com.fischa.core.config.AppConfig
import com.fischa.core.log.LogSink
import com.fischa.core.log.Tags
import com.fischa.core.log.ThrottledLog
import com.fischa.core.pipeline.PipelineInput
import com.fischa.core.pipeline.VisionPipeline
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.RobloxForegroundStatus
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Owns capture, the Firefox core loop, centralized safety signals and Android input lifecycle.
 * Real input is session-scoped and false unless the user explicitly enabled it in the UI.
 */
class FischEngineService : Service() {
    companion object {
        const val ACTION_START = "com.fischa.app.START"
        const val ACTION_STOP = "com.fischa.app.STOP"
        const val ACTION_EMERGENCY = "com.fischa.app.EMERGENCY"
        const val ACTION_CLEAR_EMERGENCY = "com.fischa.app.CLEAR_EMERGENCY"
        const val ACTION_DEBUG_OVERLAY = "com.fischa.app.DEBUG_OVERLAY"
        const val EXTRA_DEBUG_ENABLED = "debugEnabled"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        const val EXTRA_REAL_INPUT = "realInput"
        const val CHANNEL_ID = "fisch-engine"
        private const val IDLE_SLEEP_MS = 250L

        @Volatile var status: StatusSnapshot = StatusSnapshot()
        @Volatile private var accessibilityEmergency: ((String) -> Unit)? = null

        fun prefs(c: Context): SharedPreferences =
            c.getSharedPreferences("fisch-config", Context.MODE_PRIVATE)

        fun loadConfig(c: Context): AppConfig {
            val map = HashMap<String, String>()
            val all = prefs(c).all
            for (key in all.keys) map[key] = all[key].toString()
            return AppConfig().withOverrides(map)
        }

        fun triggerEmergencyFromAccessibility(reason: String) {
            runCatching { accessibilityEmergency?.invoke(reason) }
        }
    }

    data class StatusSnapshot(
        val running: Boolean = false,
        val state: String = "IDLE",
        val fps: Float = 0f,
        val procMs: Float = 0f,
        val barLocked: Boolean = false,
        val globalConf: Float = 0f,
        val denyReason: String = "",
        val emergency: Boolean = false,
        val lastLogLine: String = "",
        val foregroundPackage: String = RobloxForegroundStatus.UNKNOWN,
        val foregroundActivityWindow: String = RobloxForegroundStatus.UNKNOWN,
        val robloxDetected: Boolean = false,
        val inputAuthorized: Boolean = false,
        val foregroundBlockReason: String = "FOREGROUND_UNKNOWN",
        val foregroundTimestampMs: Long = 0L,
        val frameAgeMs: Long = Long.MAX_VALUE,
        val message: String = "Parado",
        val realInputEnabled: Boolean = false,
        val droppedFrames: Long = 0L,
        val gatedFrames: Long = 0L,
        val geometry: String = "",
        val evidenceSource: String = "NONE",
        val foregroundAgeMs: Long = Long.MAX_VALUE,
        // V5 rod-button gate (spec §3/§4/§20)
        val rodDetected: Boolean = false,
        val rodConfidence: Float = 0f,
        val rodConfirmed: Boolean = false,
        val castAuthorized: Boolean = false,
        val castGateReason: String = "",
    )

    /** Foreground status older than this is treated as unknown → input blocked (fail-closed). */
    private val maxForegroundAgeMs = 2_000L

    /**
     * Reads the AccessibilityService's cached status and applies the staleness rule: a cached
     * "Roblox detected" from seconds ago must never authorize a gesture now.
     */
    private fun freshForegroundStatus(): Pair<RobloxForegroundStatus, Long> {
        val raw = GameAccessibilityService.latestForegroundStatus()
        val age = (SystemClock.elapsedRealtime() - raw.timestampMs).coerceAtLeast(0L)
        if (age > maxForegroundAgeMs && (raw.robloxDetected || raw.inputAuthorized)) {
            return raw.copy(
                robloxDetected = false,
                inputAuthorized = false,
                blockReason = "FOREGROUND_STALE(${age}ms)",
            ) to age
        }
        return raw to age
    }

    inner class LocalBinder : Binder() {
        val service: FischEngineService get() = this@FischEngineService
    }

    private val binder = LocalBinder()
    private val main = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)

    private var projectionManager: MediaProjectionManager? = null
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var capture: ScreenCaptureSource? = null
    private var captureThread: HandlerThread? = null
    private var loopThread: Thread? = null
    private val logSink = LogRingBuffer()
    private lateinit var log: ThrottledLog
    private lateinit var cfg: AppConfig
    private lateinit var executor: AndroidInputExecutor
    private lateinit var emergency: EmergencyStop
    private lateinit var pipeline: VisionPipeline
    private var realInputForSession = false

    override fun onCreate() {
        super.onCreate()
        cfg = loadConfig(this)
        logSink.file = File(filesDir, "fisch-log.txt")
        logSink.verbose = getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).getBoolean("verbose", false)
        log = ThrottledLog(logSink)
        DiagnosticsLog.bind { category, message ->
            log.raw(LogSink.Level.INFO, category, "[$category] $message")
        }
        executor = AndroidInputExecutor()
        emergency = EmergencyStop(prefs(this).getBoolean("emergency_latched", false))
        emergency.addListener {
            prefs(this).edit().putBoolean("emergency_latched", true).apply()
            runCatching { executor.cancelAll() }
            runCatching { executor.releaseAll() }
        }
        pipeline = buildPipeline(cfg, emergency)
        accessibilityEmergency = { reason ->
            emergency.activate(reason)
            pipeline.disarm(System.nanoTime())
            main.post { stopEngine(emergencyStop = true) }
        }
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        createChannel()
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                realInputForSession = intent.getBooleanExtra(EXTRA_REAL_INPUT, false)
                // V5 crash fix: the MediaProjection session must exist BEFORE startForeground()
                // with type mediaProjection (Android 14 requirement). MainActivity parks it in
                // ProjectionHolder right after the user allows capture; the intent extras are a
                // fallback for direct service starts.
                val held = ProjectionHolder.take()
                val proj = held ?: runCatching {
                    val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                    val data = IntentCompat.getParcelableExtra(intent, EXTRA_RESULT_DATA, Intent::class.java)
                    if (data != null) projectionManager?.getMediaProjection(resultCode, data) else null
                }.getOrNull()
                if (proj == null) {
                    log.e(Tags.ERROR, "capture", "[CAPTURE] no MediaProjection available; aborting start")
                    status = status.copy(running = false, message = "MediaProjection indisponível")
                    stopSelf()
                    return START_NOT_STICKY
                }
                // startForeground AFTER the projection session is active. Any failure here must
                // not kill the process (spec §13): record it, release the projection, stop cleanly.
                val fgOk = runCatching { startForegroundWithNotification() }
                    .onFailure {
                        log.e(Tags.ERROR, "capture", "[CAPTURE] startForeground failed: ${it.javaClass.simpleName}: ${it.message}")
                    }
                    .isSuccess
                if (!fgOk) {
                    status = status.copy(running = false, message = "Falha ao iniciar Foreground Service (startForeground rejeitado)")
                    runCatching { proj.stop() }
                    stopSelf()
                    return START_NOT_STICKY
                }
                startEngine(proj)
            }
            ACTION_EMERGENCY -> {
                emergency.activate("notification action")
                pipeline.disarm(System.nanoTime())
                stopEngine(emergencyStop = true)
            }
            ACTION_STOP -> stopEngine(emergencyStop = false)
            ACTION_CLEAR_EMERGENCY -> clearEmergency()
            ACTION_DEBUG_OVERLAY -> setDebugOverlay(intent.getBooleanExtra(EXTRA_DEBUG_ENABLED, false))
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        stopEngine(emergencyStop = false)
        runCatching { pipeline.close() }
        accessibilityEmergency = null
        DiagnosticsLog.bind(null)
        logSink.flushAndClose()
        super.onDestroy()
    }

    private fun buildPipeline(config: AppConfig, stop: EmergencyStop) = VisionPipeline(
        cfg = config,
        executor = executor,
        log = log,
        emergency = stop,
        foregroundStatusProvider = { GameAccessibilityService.latestForegroundStatus() },
    )

    private fun startEngine(projection: MediaProjection) {
        if (emergency.latched) {
            status = status.copy(
                running = false,
                emergency = true,
                message = "Parada de emergência travada; desarme explicitamente antes de iniciar",
            )
            runCatching { projection.stop() }
            stopSelf()
            return
        }
        if (running.getAndSet(true)) {
            // already running: never leak the freshly handed-over projection session
            runCatching { projection.stop() }
            return
        }
        this.projection = projection
        cfg = loadConfig(this)
        logSink.verbose = getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).getBoolean("verbose", false)
        logSink.rotateIfLarge()
        runCatching { pipeline.close() }
        pipeline = buildPipeline(cfg, emergency)

        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                log.e(Tags.ERROR, "capture", "[CAPTURE] projection stopped by system")
                emergency.activate("MediaProjection stopped")
                running.set(false)
                shutdownCapture()
                status = status.copy(running = false, emergency = true, inputAuthorized = false)
            }
        }
        projectionCallback = callback
        runCatching { projection.registerCallback(callback, main) }

        val captureWorker = HandlerThread("FischCapture").apply { start() }
        captureThread = captureWorker
        val src = ScreenCaptureSource(
            context = this,
            projection = projection,
            captureHandler = Handler(captureWorker.looper),
            cfg = cfg.capture,
            onCaptureFailure = { message -> handleCaptureError(message) },
        )
        capture = src
        try {
            src.start()
        } catch (e: Exception) {
            handleCaptureError("capture start failed: ${e.javaClass.simpleName}: ${e.message}")
            return
        }
        InputGeometry.publish(src.mapper, src.geometry)
        log.i(Tags.CAPTURE, "geometry", "[CAPTURE] display ${src.geometry.describe()}")
        log.i(Tags.CAPTURE, "mapper", "[CAPTURE] mapper ${src.mapper.describe()} targetFps=${cfg.capture.targetFps}")
        if (!src.mapper.isConsistent(2f)) {
            handleCaptureError("capture/device aspect mismatch ${src.mapper.describe()}; refusing session")
            return
        }
        pipeline.armed = true
        setDebugOverlay(getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).getBoolean("overlay", false))
        status = StatusSnapshot(
            running = true,
            emergency = emergency.latched,
            realInputEnabled = realInputForSession,
            foregroundPackage = RobloxForegroundStatus.UNKNOWN,
            foregroundActivityWindow = RobloxForegroundStatus.UNKNOWN,
            foregroundBlockReason = "WAITING_FOR_ROBLOX_WINDOW",
            geometry = src.geometry.describe() + " | " + src.mapper.describe(),
        )

        val thread = Thread { loop(src) }.apply {
            name = "fisch-engine"
            priority = Thread.NORM_PRIORITY + 2
        }
        loopThread = thread
        thread.start()
    }

    private fun loop(src: ScreenCaptureSource) {
        var prevFrameNs = 0L
        var fpsEma = 0f
        var lastDisplayCheckNs = 0L
        var lastSafetyLogNs = 0L
        var lastNoFrameLogNs = 0L
        var procEmaMs = 0f
        var lastRateAdjustNs = 0L
        while (running.get()) {
            val nowNs = System.nanoTime()
            if (nowNs - lastDisplayCheckNs >= 250_000_000L) {
                lastDisplayCheckNs = nowNs
                if (!src.displayConfigurationUnchanged()) {
                    log.w(Tags.CAPTURE, "display", "[CAPTURE] orientation/size changed; stopping session")
                    emergency.activate("display configuration changed")
                    pipeline.disarm(nowNs)
                    running.set(false)
                    break
                }
            }

            val frame = try { src.takeLatest() } catch (e: Exception) {
                log.e(Tags.ERROR, "capture", "[CAPTURE] takeLatest failed: ${e.message}")
                null
            }
            if (frame == null) {
                if (lastNoFrameLogNs == 0L || nowNs - lastNoFrameLogNs >= 1_000_000_000L) {
                    lastNoFrameLogNs = nowNs
                    log.d(Tags.CAPTURE, "waiting", "[CAPTURE] waiting for latest frame; dropped=${src.droppedFrames}")
                }
                val last = src.lastFrameTimestampNs
                if (last > 0L && nowNs - last > cfg.capture.streamTimeoutMs * 1_000_000L) {
                    // V5 §13: a dead capture stream is a capture error — stop gracefully (the
                    // pipeline disarm releases any held gesture) so the user can simply press
                    // START again; no exception may kill the app.
                    log.e(Tags.ERROR, "capture", "[CAPTURE] frame stream timed out; releasing input")
                    handleCaptureError("frame stream timed out after ${cfg.capture.streamTimeoutMs} ms")
                    break
                }
                try { Thread.sleep(5) } catch (_: InterruptedException) { break }
                continue
            }

            try {
                val timestampNs = frame.timestampNs
                val ageAtStartMs = ((System.nanoTime() - timestampNs).coerceAtLeast(0L)) / 1_000_000L
                if (prevFrameNs > 0L) {
                    val delta = (timestampNs - prevFrameNs).coerceAtLeast(1L)
                    val inst = 1_000_000_000f / delta
                    fpsEma = if (fpsEma == 0f) inst else fpsEma * 0.90f + inst * 0.10f
                }
                prevFrameNs = timestampNs
                frame.fps = fpsEma
                pipeline.setFpsMeasured(fpsEma)
                log.setNow(timestampNs)

                val (foreground, foregroundAge) = freshForegroundStatus()
                val input = PipelineInput(
                    frameTimestampNs = timestampNs,
                    currentTimeNs = System.nanoTime(),
                    captureHealthy = src.captureHealthy,
                    robloxDetected = foreground.robloxDetected,
                    inputAuthorized = foreground.inputAuthorized,
                    overlaySuspected = foreground.overlayActive,
                    macroEnabled = pipeline.armed,
                    realInputEnabled = realInputForSession,
                    foregroundPackage = foreground.foregroundPackage,
                    foregroundActivityWindow = foreground.foregroundActivityWindow,
                    foregroundBlockReason = foreground.blockReason,
                    foregroundTimestampMs = foreground.timestampMs,
                )
                try {
                    pipeline.onFrame(frame, input)
                } catch (e: Exception) {
                    log.e(Tags.ERROR, "pipeline", "[ERROR] pipeline step threw: ${e.message}")
                    emergency.activate("pipeline exception")
                    running.set(false)
                }

                val out = pipeline.output
                status = StatusSnapshot(
                    running = running.get(),
                    state = out.state.name,
                    fps = fpsEma,
                    procMs = pipeline.render?.procMs ?: 0f,
                    barLocked = out.barLocked,
                    globalConf = out.globalConfidence,
                    denyReason = out.inputDeniedReason.ifEmpty {
                        pipeline.render?.safetyBlockedReason.orEmpty()
                    },
                    emergency = emergency.latched,
                    lastLogLine = logSink.lastLine(),
                    foregroundPackage = out.foregroundPackage,
                    foregroundActivityWindow = out.foregroundActivityWindow,
                    robloxDetected = out.robloxDetected,
                    inputAuthorized = out.inputAuthorized,
                    foregroundBlockReason = out.foregroundBlockReason,
                    foregroundTimestampMs = input.foregroundTimestampMs,
                    frameAgeMs = out.frameAgeMs,
                    realInputEnabled = out.realInputEnabled,
                    droppedFrames = src.droppedFrames,
                    gatedFrames = src.gatedFrames,
                    geometry = status.geometry,
                    evidenceSource = foreground.evidenceSource,
                    foregroundAgeMs = foregroundAge,
                    rodDetected = out.rodDetected,
                    rodConfidence = out.rodConfidence,
                    rodConfirmed = out.rodConfirmed,
                    castAuthorized = out.castAuthorized,
                    castGateReason = out.castGateReason,
                )
                if (timestampNs - lastSafetyLogNs >= 1_000_000_000L || lastSafetyLogNs == 0L) {
                    lastSafetyLogNs = timestampNs
                    log.i(
                        Tags.SAFETY,
                        "foreground",
                        "[SAFETY] foregroundPackage=${foreground.foregroundPackage} foregroundActivity/window=${foreground.foregroundActivityWindow} robloxDetected=${foreground.robloxDetected} inputAuthorized=${foreground.inputAuthorized} blockReason=${foreground.blockReason} source=${foreground.evidenceSource} statusAge=${foregroundAge}ms timestamp=${foreground.timestampMs}",
                    )
                    log.i(
                        Tags.CAPTURE,
                        "stats",
                        "[CAPTURE] fps=${"%.1f".format(fpsEma)} proc=${"%.1f".format(pipeline.render?.procMs ?: 0f)}ms frameAge=${out.frameAgeMs}ms produced=${src.producedFrames} dropped=${src.droppedFrames} gated=${src.gatedFrames}",
                    )
                }
                GameAccessibilityService.instance?.updateDebugOverlay(pipeline.render)
                // Adaptive capture rate: keep the capture thread from copying frames that the
                // vision thread cannot consume (Galaxy A22 CPU budget). Bounded to [12, targetFps].
                val procMsNow = pipeline.render?.procMs ?: 0f
                procEmaMs = if (procEmaMs == 0f) procMsNow else procEmaMs * 0.9f + procMsNow * 0.1f
                if (timestampNs - lastRateAdjustNs >= 1_000_000_000L) {
                    lastRateAdjustNs = timestampNs
                    val sustainable = if (procEmaMs > 1f) (800f / procEmaMs).toInt() else cfg.capture.targetFps
                    val wanted = sustainable.coerceIn(12, cfg.capture.targetFps)
                    if (wanted != src.effectiveFps) {
                        src.setRateLimit(wanted)
                        log.i(Tags.CAPTURE, "rate", "[CAPTURE] adaptive rate -> ${wanted} fps (proc=${"%.1f".format(procEmaMs)}ms)")
                    }
                }
                // Duty cycle (spec §12): while Roblox is not the authorized foreground app (our own
                // UI, launcher, lock screen…) there is nothing to control — idle at ~4 FPS instead
                // of burning the A22's CPU on frames of other apps.
                if (!foreground.inputAuthorized) {
                    Thread.sleep(IDLE_SLEEP_MS)
                } else {
                    val targetMs = if (fpsEma > 5f) (1000f / fpsEma).toLong() else 33L
                    val spentMs = ((System.nanoTime() - timestampNs) / 1_000_000L).coerceAtLeast(0L)
                    val sleepMs = targetMs - spentMs
                    if (sleepMs in 1..30) Thread.sleep(sleepMs)
                }
            } catch (e: Exception) {
                log.e(Tags.ERROR, "engine", "[ERROR] frame loop failed: ${e.message}")
                emergency.activate("engine loop exception")
                running.set(false)
            } finally {
                src.release(frame)
            }
        }
        shutdownCapture()
        status = status.copy(running = false, inputAuthorized = false, emergency = emergency.latched)
        main.post {
            runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
            if (emergency.latched) stopSelf()
        }
    }

    /**
     * V5 §13: a capture failure never kills the process and never latches the emergency stop —
     * it logs the full context (exception, stack, timestamp, FSM state, projection/service
     * status), releases every held gesture through the pipeline disarm, stops the session
     * cleanly and leaves the app open so the user can press START again.
     */
    private fun handleCaptureError(message: String, cause: Throwable? = null) {
        val ts = SystemClock.elapsedRealtime()
        log.e(Tags.ERROR, "capture", "[CAPTURE] CAPTURE ERROR: $message")
        if (cause != null) {
            log.e(Tags.ERROR, "capture", "[CAPTURE] exception=${cause.javaClass.name}: ${cause.message}")
            log.e(Tags.ERROR, "capture", "[CAPTURE] stack=${cause.stackTraceToString().lineSequence().take(8).joinToString(" | ")}")
        }
        log.e(
            Tags.ERROR, "capture",
            "[CAPTURE] timestamp=${ts}ms state=${pipeline.output.state.name} projectionActive=${projection != null} " +
                "serviceRunning=${running.get()} captureHealthy=${capture?.captureHealthy ?: false}",
        )
        if (Looper.myLooper() == Looper.getMainLooper()) {
            stopEngine(emergencyStop = false, captureError = message)
        } else {
            main.post { stopEngine(emergencyStop = false, captureError = message) }
        }
    }

    private fun shutdownCapture() {
        InputGeometry.clear()
        runCatching { capture?.close() }
        capture = null
        runCatching { captureThread?.quitSafely() }
        captureThread = null
        // V5 §14/§15: release the MediaProjection session itself. V4 leaked it (the system kept
        // the screen-capture indicator alive and a clean restart was impossible). Unregister the
        // callback first so our own stop() does not fire onStop → emergency latch.
        val proj = projection
        val cb = projectionCallback
        projection = null
        projectionCallback = null
        if (proj != null) {
            runCatching { cb?.let { proj.unregisterCallback(it) } }
            runCatching { proj.stop() }
        }
    }

    private fun stopEngine(emergencyStop: Boolean, captureError: String? = null) {
        val wasRunning = running.getAndSet(false)
        pipeline.disarm(System.nanoTime())
        runCatching { executor.cancelAll() }
        runCatching { executor.releaseAll() }
        val thread = loopThread
        loopThread = null
        if (thread != null && thread !== Thread.currentThread()) runCatching { thread.join(1000) }
        shutdownCapture()
        GameAccessibilityService.instance?.setDebugOverlay(false)
        status = status.copy(
            running = false,
            inputAuthorized = false,
            realInputEnabled = false,
            emergency = emergency.latched || emergencyStop,
            state = when {
                emergencyStop -> "EMERGENCY_STOP"
                captureError != null -> "CAPTURE_ERROR"
                else -> status.state
            },
            message = when {
                captureError != null -> "CAPTURE ERROR: $captureError"
                emergencyStop -> status.message.ifEmpty { "Parado (emergência)" }
                else -> "Parado"
            },
        )
        if (emergencyStop && !emergency.latched) emergency.activate("stop")
        if (wasRunning || !status.running) runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        if (wasRunning || emergencyStop) stopSelf()
    }

    fun setDebugOverlay(enabled: Boolean) {
        // TYPE_ACCESSIBILITY_OVERLAY must be attached by the owning AccessibilityService.
        GameAccessibilityService.instance?.setDebugOverlay(enabled)
    }

    /** Explicit operator action only; clearing the latch does not re-arm the macro. */
    fun clearEmergency() {
        emergency.clear()
        prefs(this).edit().putBoolean("emergency_latched", false).apply()
        pipeline.disarm(System.nanoTime())
        status = status.copy(emergency = false, running = false, inputAuthorized = false, realInputEnabled = false)
    }

    fun applyConfig(newCfg: AppConfig) {
        cfg = newCfg
        if (running.get()) main.post { stopEngine(emergencyStop = false) }
    }

    private fun startForegroundWithNotification() {
        createChannel()
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, FischEngineService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stopNow = PendingIntent.getService(
            this, 2, Intent(this, FischEngineService::class.java).setAction(ACTION_EMERGENCY),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Fisch AutoBot V5 ativo")
            .setContentText("Captura local; estado WAITING_FOR_ROD; input real somente após opt-in explícito")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Parar", stopIntent)
            .addAction(android.R.drawable.ic_delete, "EMERGÊNCIA", stopNow)
            .build()
        ServiceCompat.startForeground(
            this,
            42,
            notification,
            if (Build.VERSION.SDK_INT >= 34)
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            else 0,
        )
    }

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.notification_channel), NotificationManager.IMPORTANCE_LOW),
            )
        }
    }
}
