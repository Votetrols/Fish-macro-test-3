package com.fischa.app

import android.media.projection.MediaProjection

/**
 * Process-wide handoff of the [MediaProjection] between [MainActivity] (which receives the
 * system screen-capture consent result) and [FischEngineService].
 *
 * V5 crash fix (Galaxy A22, Android 13/14): the MediaProjection session MUST exist **before**
 * the foreground service is started with type `mediaProjection`. On Android 14 the system
 * rejects `startForeground(FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)` while no projection
 * session is active, which is exactly what killed the app right after the user allowed screen
 * capture in V4 (the service called startForeground before `getMediaProjection`).
 *
 * The activity therefore creates the projection first, parks it here, and only then starts the
 * service; the service takes it over and calls startForeground immediately (well inside the
 * 5-second window of `startForegroundService`).
 */
object ProjectionHolder {
    @Volatile private var projection: MediaProjection? = null

    fun set(p: MediaProjection) {
        // never leak a previous session if one is still parked
        clear()
        projection = p
    }

    /** Takes (and clears) the parked projection; null when none was handed off. */
    fun take(): MediaProjection? = projection.also { projection = null }

    /** Stops and drops any parked projection (failure paths). */
    fun clear() {
        val p = projection
        projection = null
        runCatching { p?.stop() }
    }
}
