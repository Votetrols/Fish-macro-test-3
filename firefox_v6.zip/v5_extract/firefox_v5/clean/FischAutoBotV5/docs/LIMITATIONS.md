# Limitações e avisos honestos

## O que NÃO foi verificado (build 0.3.0-a22)

1. **Nada rodou em dispositivo real.** O módulo `app/` agora **compila com AGP e gera o APK**
   (ver `TEST_RESULTS.md`), mas MediaProjection, `dispatchGesture`, overlay e o serviço de
   acessibilidade só são validáveis no Galaxy A22. Pontos a observar no primeiro teste:
   ordem de bytes RGBA / `rowStride` da captura (cores trocadas = detecção falha), precisão do
   toque (`[INPUT] … px=(…)`), hold contínuo via `continueStroke`, e a classe de Activity que o
   Roblox reporta (`[SAFETY] activity changed: com.roblox.client/...`).
2. **Roblox/Fisch não foram controlados de verdade** (spec §25). O laço fechado só foi validado
   em simulação (SelfTest) e testes unitários. O replay do vídeo de referência **não pôde ser
   rodado nesta rodada**: os frames (`testdata/frames`) não vieram no zip.
3. **Detecção do Roblox**: a regra nova depende de (a) o Roblox expor um root de acessibilidade
   *ou* (b) seu evento de janela trazer uma classe de Activity verificável. Se o One UI reportar
   a classe de outra forma, o status mostrará `Fonte: NONE` / `FOREGROUND_UNKNOWN` e o log
   `[SAFETY]` indica exatamente o que foi observado (package, classe, janela ativa) para ajuste.
   O fallback continua sendo bloquear, nunca permitir.
4. **Galaxy A22 apenas**: tablets, 21:9, multi-janela, DeX e outros fabricantes não foram
   considerados nesta etapa (a lógica continua sem coordenadas fixas, mas não foi revisada para
   eles).

## Comportamentos conhecidos que podem precisar ajuste fino

- **Hold contínuo** é feito com `StrokeDescription.continueStroke` (`willContinue=true`) em
  segmentos de ≤ 65 ms, cada um reautorizado pelo SafetyGuard; o dedo permanece "em baixo" entre
  segmentos. Se o Roblox no A22 interpretar a transição entre segmentos como soltar, o sintoma é
  o cast não carregar — ajustar `safety.holdQuantumMs` (30–100) é o primeiro passo.
- **Cancelamento de emergência**: segmentos são curtos (≤ 65 ms) e o release é um stroke de 1 ms
  sem continuação; o Android injeta ACTION_CANCEL em `onCancelled`.
- **`robloxForeground`**: sem serviço de acessibilidade o status é `ACCESSIBILITY_UNAVAILABLE`
  e o input fica bloqueado (não há mais suposição permissiva). Overlay de terceiros (HUD de FPS,
  Discord, Game Tools) pode acionar `INCOMPATIBLE_OVERLAY` e pausar o macro; é conservador por design.
- **Captura interrompida pelo sistema** (notificação "parar compartilhamento", troca de
  orientação) aciona o Emergency Stop: é preciso "Limpar latch" antes de um novo START.
- **`QUERY_ALL_PACKAGES`** está declarada para a verificação de Activity; aceitável para um APK
  sideload de teste, não para distribuição na Play Store.
- **Shake sem timeout**: por especificação, enquanto o prompt existe o macro insiste em
  tocar. Se um "SHAKE" fantasma aparecer fora do fluxo (notificação com fonte parecida),
  ele vai ser martelado até sumir — mitigado pela confirmação temporal de 2 frames +
  confiança mínima, mas vale observar nos logs (`[DETECTION] shake`).
- **Resoluções/telas muito diferentes** (21:9, notch, tablet): os recorte de busca do botão
  da vara/shake são proporcionais e o DiscMatcher é multi-escala, mas só o 16:9 do vídeo de
  referência foi medido. Re-calibrar via `vision.*` se necessário.
- **Fase noturna/águas claras**: o detector da barra usa (a) âncora do bloco branco/tingido,
  (b) faixa escura relativa ao fundo abaixo do bloco. Cenários onde a areia embaixo da barra
  também for escura (p. ex. caverna) derrubam (b) — visível como barra piscando no log
  `[DETECTION] bar`. Ajustar `vision.barDarkMin/Max`, `barBgBelowDelta`.
- **Peixe dentro do bloco**: o sprite do peixe encobre o bloco; a detecção usa largura
  esperada + âncora de borda para sobreviver, e o AlphaBeta cobre ≤ 500 ms de oclusão.
  Oclusões longas (> `tracking.blockMaxLostMs`) entram em VISION_LOST da minigame —
  comportamento desejado (não "chutar" o controle sem ver).
- **Catch confirmation** atual detecta o cartão central; não lê o nome do peixe (fora de
  escopo do controle) nem faz nada com o "450 XP" dourado.
- **Rodada de captura com ruído JPEG** (vídeo 1066×480 @ ~2 Mbps): limiares foram calibrados
  com uma margem, mas stream de MediaProjection real tem artefatos diferentes; começar os
  testes com `debug` ligado e olhar `[CAPTURE]/[DETECTION]`.

## Dívida técnica assumida (documentada, não escondida)

- `InputExecutor` tem `tap/holdStart/holdExtend/holdRelease/cancelAll` + `holdStillActive()`;
  o `AndroidInputExecutor` devolve `true` para `holdStart/holdExtend` assim que o comando é
  postado no main looper (a rejeição posterior pela lease é compensada pela realimentação
  `holdStillActive`, não pelo retorno).
- O executor do replay é `DryExecutor` (decisões logadas, sem planta física do jogador);
  o laço fechado com planta sintética está coberto no SelfTest (simulação com deriva,
  tap/hold e ruído), não no replay.
- Config aplicada em runtime exige reinício do motor (SettingsActivity → `applyConfig`).
- `LogRingBuffer` grava arquivo sem rotação; deletar `files/fisch-log.txt` se crescer.
