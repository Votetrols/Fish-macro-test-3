package com.fischa.core.log

/**
 * Structured logging (spec §18). Format: `[TAG] message`. Implementations: in-app ring buffer
 * + optional file sink (Android side). Core only defines the contract and a repeat-suppressing
 * wrapper that keeps hot loops quiet without losing information.
 */
fun interface LogSink {
    fun log(level: Level, tag: String, msg: String, timestampNs: Long)

    enum class Level { DEBUG, INFO, WARN, ERROR }
}

object NoopSink : LogSink {
    override fun log(level: LogSink.Level, tag: String, msg: String, timestampNs: Long) {}
}

/**
 * Rate-limits identical (tag,key) lines: first occurrence passes, repeats within [windowMs]
 * are counted and flushed as "×N" on window expiry — good for frame-rate loops.
 */
class ThrottledLog(private val sink: LogSink) {

    private class Slot(var lastNs: Long = 0L, var count: Int = 0, var key: String = "")
    private val slots = HashMap<String, Slot>()
    private val clock = object { var now = 0L }

    fun setNow(ns: Long) { clock.now = ns }

    fun d(tag: String, key: String, msg: String) = log(LogSink.Level.DEBUG, tag, key, msg)
    fun i(tag: String, key: String, msg: String) = log(LogSink.Level.INFO, tag, key, msg)
    fun w(tag: String, key: String, msg: String) = log(LogSink.Level.WARN, tag, key, msg)
    fun e(tag: String, key: String, msg: String) = log(LogSink.Level.ERROR, tag, key, msg)

    fun raw(level: LogSink.Level, tag: String, msg: String) = sink.log(level, tag, msg, clock.now)

    private val windowNs = 1_500_000_000L

    private fun log(level: LogSink.Level, tag: String, key: String, msg: String) {
        val id = "$tag|$key"
        val s = slots.getOrPut(id) { Slot() }
        val now = clock.now
        if (s.lastNs == 0L || now - s.lastNs >= windowNs) {
            if (s.count > 1) sink.log(level, tag, "$msg (×${s.count + 1} in ${windowNs / 1_000_000}ms)", now)
            else sink.log(level, tag, msg, now)
            s.lastNs = now; s.count = 0; s.key = key
        } else {
            s.count++
        }
        if (slots.size > 64) { // bounded memory, drop oldest
            val it = slots.entries.iterator()
            while (it.hasNext() && slots.size > 48) {
                val e = it.next()
                if (now - e.value.lastNs > windowNs * 4) it.remove() else if (!it.hasNext()) break
            }
        }
    }
}

/** Tags per spec §18. */
object Tags {
    const val CAPTURE = "CAPTURE"
    const val DETECTION = "DETECTION"
    const val TRACKING = "TRACKING"
    const val CONTROL = "CONTROL"
    const val STATE = "STATE"
    const val INPUT = "INPUT"
    const val SAFETY = "SAFETY"
    const val ERROR = "ERROR"
    const val SYSTEM = "SYSTEM"
}
