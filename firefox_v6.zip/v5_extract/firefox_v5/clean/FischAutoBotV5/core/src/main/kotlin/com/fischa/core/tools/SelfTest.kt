package com.fischa.core.tools

import com.fischa.core.common.clamp01
import com.fischa.core.config.AppConfig
import com.fischa.core.control.ControlAction
import com.fischa.core.control.FishingController
import com.fischa.core.control.GestureLease
import com.fischa.core.control.GestureSessionState
import com.fischa.core.control.GestureTarget
import com.fischa.core.control.InputExecutor
import com.fischa.core.log.LogSink
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.safety.DenyReason
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.ForegroundObservation
import com.fischa.core.safety.GestureAction
import com.fischa.core.safety.InputRequest
import com.fischa.core.safety.InputSafetyGuard
import com.fischa.core.safety.RobloxForegroundDetector
import com.fischa.core.safety.SafetyContext
import com.fischa.core.state.Evidence
import com.fischa.core.state.FishingState
import com.fischa.core.state.FishingStateMachine
import com.fischa.core.tracking.AlphaBeta
import com.fischa.core.tracking.FishTracker
import com.fischa.core.tracking.PlayerBarTracker
import kotlin.math.abs
import kotlin.random.Random

/**
 * Self-contained logic tests runnable with `kotlinc` + `java` (no JUnit dependency), so the
 * exact shipped code paths are exercised: state machine, safety gate, trackers, controller on
 * a physically faithful minigame simulator (drift/hold dynamics measured from the video).
 */
object SelfTest {

    private var failures = 0
    private var checks = 0

    private fun check(name: String, cond: Boolean, detail: String = "") {
        checks++
        if (!cond) { failures++; println("FAIL  $name  $detail") }
    }

    @JvmStatic
    fun main(args: Array<String>) {
        testAlphaBeta()
        testStateMachineCycle()
        testStateMachineShakePersistence()
        testVisionLostAndRecovery()
        testRodConfirmationGate()
        testEmergencyStop()
        testSafetyGuard()
        testRobloxForegroundDetection()
        testGestureLeaseAndExecutorContract()
        testControllerOnSimulatedPlant()
        println("== SelfTest: $checks checks, $failures failures ==")
        if (failures > 0) kotlin.system.exitProcess(1)
    }

    private fun testAlphaBeta() {
        val ab = AlphaBeta(alpha = 0.55f, beta = 0.3f, jumpThreshold = 0.22f)
        var t = 0f
        repeat(30) { ab.update(0.5f + 0.01f * it, 1f / 30f); t += 1f / 30f }
        check("ab tracks ramp", abs(ab.vel - 0.30f) < 0.20f, "vel=${ab.vel}")
        // abrupt jump must re-sync within a few frames, not smooth for a second
        ab.update(0.9f, 1f / 30f)
        check("ab resyncs on jump", abs(ab.pos - 0.9f) < 0.06f, "pos=${ab.pos}")
        ab.update(0.9f, 1f / 30f); ab.update(0.9f, 1f / 30f)
        check("ab holds after resync", abs(ab.pos - 0.9f) < 0.08f, "pos=${ab.pos}")
        ab.coast(1f / 30f)
        check("ab coasts forward", ab.pos > 0.88f)
    }

    private fun evidence(block: Evidence.() -> Unit): Evidence = Evidence().apply(block)

    /** V5 rod-button gate evidence (spec §4): visually confirmed + authorized. */
    private fun rodGate(e: Evidence) {
        e.fishingButton = true
        e.fishingButtonConf = 0.9f
        e.rodConfirmed = true
        e.castAuthorized = true
    }

    private fun testStateMachineCycle() {
        val cfg = AppConfig()
        val sm = FishingStateMachine(cfg.state)
        sm.armed = true
        var t = 0L
        fun step(e: Evidence) { e.nowNs = t; sm.update(e); t += 33_000_000 }

        step(evidence { rodGate(this); robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("armed→waiting_for_rod", sm.state == FishingState.WAITING_FOR_ROD, "state=${sm.state}")
        // one transition per frame by design (stable, no double-jump states): frame 2 sees the
        // confirmed rod button + authorization and enters CASTING
        step(evidence { rodGate(this); robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("waiting_for_rod→cast", sm.state == FishingState.CASTING, "state=${sm.state}")
        step(evidence { rodGate(this); robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("casting waits for evidence", sm.state == FishingState.CASTING)
        // V5: cast released → WAITING_FOR_WATER (no immediate shake, wait for visual evidence)
        step(evidence { rodGate(this); castComplete = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("cast→waiting_for_water", sm.state == FishingState.WAITING_FOR_WATER, "state=${sm.state}")
        step(evidence { shake = true; shakeConf = 0.9f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("water→searching_shake", sm.state == FishingState.SEARCHING_SHAKE, "state=${sm.state}")
        step(evidence { shake = true; shakeConf = 0.95f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("shake→pressing", sm.state == FishingState.PRESSING_SHAKE, "state=${sm.state}")
        // shake keeps appearing at different positions: still pressing, no timeout
        repeat(30) {
            step(evidence { shake = true; shakeConf = 0.9f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        }
        check("long shake session stays", sm.state == FishingState.PRESSING_SHAKE, "state=${sm.state}")
        // minigame appears: bar 3+ frames
        for (i in 0 until 3) step(evidence { bar = true; barConf = 0.8f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("shake→minigame detected", sm.state == FishingState.FISHING_MINIGAME_DETECTED, "state=${sm.state}")
        step(evidence { bar = true; barConf = 0.9f; fishOk = true; playerOk = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("detected→tracking", sm.state == FishingState.TRACKING_FISH, "state=${sm.state}")
        step(evidence { bar = true; barConf = 0.9f; fishOk = true; playerOk = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("tracking→controlling", sm.state == FishingState.CONTROLLING_PLAYER_BAR, "state=${sm.state}")
        // progress high then bar disappears → catch confirmation
        repeat(6) { step(evidence { bar = true; barConf = 0.9f; fishOk = true; playerOk = true; progress = 0.98f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f }) }
        repeat(6) { step(evidence { bar = false; progress = 1.0f; robloxForeground = true; captureHealthy = true; globalConf = 0.5f }) }
        check("controlling→catch confirmation", sm.state == FishingState.CATCH_CONFIRMATION, "state=${sm.state}")
        step(evidence { catchConfirm = true; catchConfirmConf = 0.8f; robloxForeground = true; captureHealthy = true; globalConf = 0.7f })
        check("confirm→reset", sm.state == FishingState.RESET, "state=${sm.state}")
        // Recovery waits for the confirmation notice to disappear and the detected rod button to return.
        repeat(30) {
            if (sm.state != FishingState.WAITING_FOR_ROD) {
                step(evidence { fishingButton = true; robloxForeground = true; captureHealthy = true; globalConf = 0.7f })
            }
        }
        check("reset→waiting_for_rod after visual recovery", sm.state == FishingState.WAITING_FOR_ROD, "state=${sm.state}")
    }

    private fun testStateMachineShakePersistence() {
        val sm = FishingStateMachine(AppConfig.StateTiming())
        sm.armed = true
        var t = 0L
        fun step(e: Evidence) { e.nowNs = t; sm.update(e); t += 33_000_000 }
        step(evidence { rodGate(this); robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        step(evidence { rodGate(this); robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        step(evidence { rodGate(this); castComplete = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        step(evidence { shake = true; shakeConf = 0.9f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        step(evidence { shake = true; shakeConf = 0.9f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("in pressing", sm.state == FishingState.PRESSING_SHAKE)
        // shake blinks out for 1 frame (occlusion) then returns — must NOT bail to searching
        step(evidence { shake = false; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("short blink stays pressing", sm.state == FishingState.PRESSING_SHAKE)
        step(evidence { shake = true; shakeConf = 0.9f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        // many distinct shakes (no fixed count limit!)
        var sessions = 0
        for (s in 0 until 10) {
            repeat(4) { step(evidence { shake = true; shakeConf = 0.9f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f }) }
            repeat(5) { step(evidence { shake = false; shakeGone = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f }) }
            if (sm.state == FishingState.SEARCHING_SHAKE) sessions++
        }
        check("shake sessions unbounded", sessions >= 9, "sessions=$sessions state=${sm.state}")
    }

    /**
     * V5 §3/§4/§5: the rod-button gate. Temporal confirmation (consecutive frames, confidence,
     * stability, window) + the InputSafetyGuard cast gate decide WAITING_FOR_ROD → CASTING.
     */
    private fun testRodConfirmationGate() {
        // --- RodConfirmTracker -------------------------------------------------------
        val tracker = com.fischa.core.tracking.RodConfirmTracker(AppConfig.Rod())
        var t = 0L
        fun tick(detected: Boolean, conf: Float, x: Float = 0.8f, y: Float = 0.7f): Boolean {
            val r = tracker.update(detected, conf, x, y, t)
            t += 33_000_000L
            return r
        }
        check("rod: single frame is not enough", !tick(true, 0.9f))
        check("rod: two frames are not enough", !tick(true, 0.9f))
        check("rod: three stable frames confirm", tick(true, 0.9f))
        check("rod: stays confirmed while stable", tick(true, 0.9f))
        check("rod: disappearance resets", !tick(false, 0f))
        check("rod: reconfirm needs 3 fresh frames", !tick(true, 0.9f) && !tick(true, 0.9f) && tick(true, 0.9f))
        tracker.reset()
        check("rod: reset clears confirmation", !tracker.confirmed)
        // low confidence never confirms
        tracker.reset(); t = 0L
        var confirmed = false
        repeat(10) { confirmed = tick(true, 0.4f) }
        check("rod: low confidence never confirms", !confirmed)
        // jumping position restarts the streak
        tracker.reset(); t = 0L
        confirmed = false
        repeat(2) { confirmed = tick(true, 0.9f, 0.80f, 0.70f) }
        check("rod: jumping target does not confirm", !confirmed)
        repeat(2) { confirmed = tick(true, 0.9f, 0.83f, 0.71f) }
        check("rod: moved target needs fresh streak", !confirmed)
        check("rod: fresh streak confirms at new spot", tick(true, 0.9f, 0.83f, 0.71f))
        // a streak that spans longer than the confirmation window never confirms (no slow
        // accumulation across seconds, no fixed long wait)
        tracker.reset(); t = 0L
        confirmed = false
        repeat(5) { confirmed = tick(true, 0.9f); t += 800_000_000L }
        check("rod: streak beyond window never confirms", !confirmed)

        // --- InputSafetyGuard.evaluateCastGate ----------------------------------------
        val guard = InputSafetyGuard(AppConfig.Safety())
        val emergency = EmergencyStop()
        val now = 5_000_000_000L
        fun gateCtx(block: SafetyContext.() -> Unit) = SafetyContext().apply {
            macroEnabled = true
            realInputEnabled = true
            captureHealthy = true
            robloxDetected = true
            platformAuthorized = true
            state = FishingState.WAITING_FOR_ROD
            frameTimestampNs = now
            block()
        }
        check("cast gate allows when everything is authorized",
            guard.evaluateCastGate(gateCtx {}, 0.9f, 0.8f, 0.7f, now, emergency).allowed)
        check("cast gate: realInput OFF blocks",
            guard.evaluateCastGate(gateCtx { realInputEnabled = false }, 0.9f, 0.8f, 0.7f, now, emergency).reason == DenyReason.REAL_INPUT_DISABLED)
        check("cast gate: Roblox absent blocks",
            guard.evaluateCastGate(gateCtx { robloxDetected = false }, 0.9f, 0.8f, 0.7f, now, emergency).reason == DenyReason.ROBLOX_NOT_DETECTED)
        check("cast gate: capture dead blocks",
            guard.evaluateCastGate(gateCtx { captureHealthy = false }, 0.9f, 0.8f, 0.7f, now, emergency).reason == DenyReason.CAPTURE_STOPPED)
        check("cast gate: stale frame blocks",
            guard.evaluateCastGate(gateCtx {}, 0.9f, 0.8f, 0.7f, now + (AppConfig.Safety().maxFrameAgeMs + 50) * 1_000_000L, emergency).reason == DenyReason.FRAME_STALE)
        check("cast gate: low rod confidence blocks",
            guard.evaluateCastGate(gateCtx {}, 0.1f, 0.8f, 0.7f, now, emergency).reason == DenyReason.TARGET_CONFIDENCE_LOW)
        check("cast gate: wrong state blocks",
            guard.evaluateCastGate(gateCtx { state = FishingState.CASTING }, 0.9f, 0.8f, 0.7f, now, emergency).reason == DenyReason.STATE_NOT_ACTIONABLE)
        emergency.activate("test")
        check("cast gate: emergency blocks",
            guard.evaluateCastGate(gateCtx {}, 0.9f, 0.8f, 0.7f, now, emergency).reason == DenyReason.EMERGENCY_STOP)
        emergency.clear()
    }

    private fun testVisionLostAndRecovery() {
        val sm = FishingStateMachine(AppConfig.StateTiming())
        sm.armed = true
        var t = 0L
        fun step(e: Evidence) { e.nowNs = t; sm.update(e); t += 33_000_000 }
        step(evidence { fishingButton = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        // overlay: nothing detectable for > visionLostAfterMs
        repeat(80) { step(evidence { robloxForeground = true; captureHealthy = true; globalConf = 0.1f }) }
        check("vision lost engaged", sm.state == FishingState.VISION_LOST, "state=${sm.state}")
        // evidence returns → recovery via RESET (not straight to casting)
        step(evidence { fishingButton = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("recovery via reset", sm.state == FishingState.RESET, "state=${sm.state}")
        // overlay suspected (notification shade like the reference video tail)
        t += 33_000_000L
        step(evidence { overlaySuspected = true; robloxForeground = true; captureHealthy = true; globalConf = 0.2f })
        repeat(35) { step(evidence { overlaySuspected = true; robloxForeground = false; captureHealthy = true; globalConf = 0.2f }) }
        check("roblox-not-detected on overlay", sm.state == FishingState.ROBLOX_NOT_DETECTED, "state=${sm.state}")
    }

    private class RecordingExecutor : InputExecutor {
        val events = mutableListOf<String>()
        override fun tap(nx: Float, ny: Float, durationMs: Int) { events += "tap" }
        override fun tap(nx: Float, ny: Float, durationMs: Int, authorize: () -> Boolean): Boolean {
            if (!authorize()) return false
            events += "tap"
            return true
        }
        override fun holdStart(nx: Float, ny: Float, leaseMs: Int, authorize: () -> Boolean): Boolean {
            if (!authorize()) return false
            events += "holdStart"
            return true
        }
        override fun holdExtend(nx: Float, ny: Float, leaseMs: Int, authorize: () -> Boolean): Boolean {
            if (!authorize()) return false
            events += "holdExtend"
            return true
        }
        override fun holdRelease() { events += "holdRelease" }
        override fun cancelAll() { events += "cancelAll" }
    }

    private fun validSafetyContext(now: Long, state: FishingState = FishingState.PRESSING_SHAKE) = SafetyContext().apply {
        macroEnabled = true
        realInputEnabled = true
        captureHealthy = true
        robloxDetected = true
        platformAuthorized = true
        overlaySuspected = false
        this.state = state
        targetConfidence = 0.95f
        trackingOk = true
        controllerSafe = true
        frameTimestampNs = now
    }

    private fun testEmergencyStop() {
        val emergency = EmergencyStop()
        var listenerFired = 0
        val listener: () -> Unit = { listenerFired++ }
        emergency.addListener(listener)
        emergency.activate("test")
        check("emergency listener fired", listenerFired == 1)
        val now = 1_000_000_000L
        val guard = InputSafetyGuard(AppConfig.Safety())
        val context = validSafetyContext(now)
        val tap = InputRequest(GestureAction.TAP, .5f, .5f, 60, .95f, "test")
        val blocked = guard.evaluate(context, tap, now, emergency)
        check("emergency denies new input", !blocked.allowed && blocked.reason == DenyReason.EMERGENCY_STOP)
        val release = guard.evaluate(context, InputRequest(GestureAction.HOLD_RELEASE), now, emergency)
        check("emergency never blocks cleanup release", release.allowed)
        emergency.clear()
        check("explicit clear unlatches", !emergency.latched)
        emergency.removeListener(listener)
    }

    private fun testSafetyGuard() {
        val cfg = AppConfig.Safety()
        val guard = InputSafetyGuard(cfg)
        val emergency = EmergencyStop()
        val now = 10_000_000_000L
        fun ctx(state: FishingState = FishingState.PRESSING_SHAKE, block: SafetyContext.() -> Unit = {}) =
            validSafetyContext(now, state).apply(block)
        val tap = InputRequest(GestureAction.TAP, .5f, .5f, 60, .95f, "shake")
        fun denial(context: SafetyContext, request: InputRequest = tap) =
            guard.evaluate(context, request, now, emergency).reason

        check("allows with valid foreground and fresh frame", denial(ctx()) == DenyReason.OK)
        check("cast does not require fish/player tracking", denial(ctx(FishingState.CASTING) { trackingOk = false }, tap.copy(action = GestureAction.HOLD_START)) == DenyReason.OK)
        check("controller disabled blocks", denial(ctx { macroEnabled = false }) == DenyReason.MACRO_DISABLED)
        check("real input disabled blocks", denial(ctx { realInputEnabled = false }) == DenyReason.REAL_INPUT_DISABLED)
        check("capture stopped blocks", denial(ctx { captureHealthy = false }) == DenyReason.CAPTURE_STOPPED)
        check("Roblox false blocks", denial(ctx { robloxDetected = false }) == DenyReason.ROBLOX_NOT_DETECTED)
        check("foreground authorization false blocks", denial(ctx { platformAuthorized = false }) == DenyReason.FOREGROUND_UNAUTHORIZED)
        check("incompatible overlay blocks", denial(ctx { overlaySuspected = true }) == DenyReason.OVERLAY_ACTIVE)
        check("idle state blocks", denial(ctx(FishingState.IDLE)) == DenyReason.STATE_NOT_ACTIONABLE)
        check("stale frame blocks", denial(ctx { frameTimestampNs = now - (cfg.maxFrameAgeMs + 1) * 1_000_000L }) == DenyReason.FRAME_STALE)
        check("future frame blocks", denial(ctx { frameTimestampNs = now + 1 }) == DenyReason.FRAME_STALE)
        check("low target confidence blocks", denial(ctx(), tap.copy(confidence = cfg.minActionConfidence - .01f)) == DenyReason.TARGET_CONFIDENCE_LOW)
        check("tracking loss blocks minigame control", denial(ctx(FishingState.CONTROLLING_PLAYER_BAR) { trackingOk = false }, tap.copy(action = GestureAction.HOLD_START)) == DenyReason.TRACKING_LOST)
        check("unsafe controller blocks", denial(ctx { controllerSafe = false }) == DenyReason.CONTROLLER_UNSAFE)
        check("invalid coordinates block", denial(ctx(), tap.copy(nx = Float.NaN)) == DenyReason.COORDINATES_OUT_OF_BOUNDS)
        check("out-of-bounds coordinates block", denial(ctx(), tap.copy(nx = 1.1f)) == DenyReason.COORDINATES_OUT_OF_BOUNDS)
        check("invalid duration blocks", denial(ctx(), tap.copy(durationMs = cfg.maxTapMs + 1)) == DenyReason.INVALID_DURATION)
        check("rate limited new tap blocks", denial(ctx { lastInputNs = now - 10_000_000L }) == DenyReason.RATE_LIMITED)
        emergency.activate("test");
        check("emergency latch blocks", denial(ctx()) == DenyReason.EMERGENCY_STOP)
        check("release is always permitted for cleanup", guard.evaluate(ctx { realInputEnabled = false }, InputRequest(GestureAction.CANCEL_ALL), now, emergency).allowed)
    }

    private fun testRobloxForegroundDetection() {
        val detector = RobloxForegroundDetector()
        val expected = RobloxForegroundDetector.ROBLOX_PACKAGE
        val good = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = expected,
            rootInActiveWindowPackage = expected,
            lastWindowEventPackage = expected,
            foregroundActivity = "com.roblox.client.Activity",
            activeWindow = "type=APPLICATION active=true",
            timestampMs = 1234,
        ))
        check("Roblox foreground recognized", good.robloxDetected && good.inputAuthorized && good.foregroundPackage == expected)
        val fullscreenFallback = detector.evaluate(ForegroundObservation(
            lastWindowEventPackage = expected,
            foregroundActivity = "com.roblox.client.GameActivity",
            timestampMs = 1240,
        ))
        check("fullscreen Roblox event fallback", fullscreenFallback.inputAuthorized)
        val other = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = "com.android.launcher",
            lastWindowEventPackage = "com.android.launcher",
            timestampMs = 1250,
        ))
        check("other foreground app rejected", !other.robloxDetected && !other.inputAuthorized && other.blockReason == "FOREGROUND_PACKAGE_MISMATCH")
        val unknown = detector.evaluate(ForegroundObservation(timestampMs = 1260))
        check("unknown package rejected", !unknown.robloxDetected && !unknown.inputAuthorized && unknown.foregroundPackage == "<unknown>")
        val staleEvent = detector.evaluate(ForegroundObservation(
            lastWindowEventPackage = expected,
            timestampMs = 5000,
            lastWindowEventTimestampMs = 1000,
        ))
        check("stale Roblox event fails closed", !staleEvent.inputAuthorized && staleEvent.foregroundPackage == "<unknown>")
        val overlay = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = expected,
            lastWindowEventPackage = expected,
            incompatibleOverlay = true,
            timestampMs = 1270,
        ))
        check("overlay keeps detection but blocks authorization", overlay.robloxDetected && !overlay.inputAuthorized && overlay.blockReason == "INCOMPATIBLE_OVERLAY")
        val conflict = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = expected,
            rootInActiveWindowPackage = "com.android.systemui",
            lastWindowEventPackage = expected,
            timestampMs = 1280,
        ))
        check("conflicting live window evidence fails closed", !conflict.inputAuthorized)
        val noA11y = detector.evaluate(ForegroundObservation(
            lastWindowEventPackage = expected,
            accessibilityAvailable = false,
            timestampMs = 1290,
        ))
        check("accessibility unavailable blocks", noA11y.robloxDetected && !noA11y.inputAuthorized && noA11y.blockReason == "ACCESSIBILITY_UNAVAILABLE")
    }

    private fun testGestureLeaseAndExecutorContract() {
        val lease = GestureLease(maxLeaseMs = 250, maxContinuousMs = 1000, watchdogMs = 100)
        val point = GestureTarget(.4f, .55f)
        check("tap accepted", lease.tap(point, 60, 1000))
        check("tap tracked active", lease.state == GestureSessionState.TAP && lease.activeCount == 1)
        lease.completeTap()
        check("tap release clears state", lease.state == GestureSessionState.IDLE && lease.activeCount == 0)
        check("holdStart accepted", lease.holdStart(point, 100, 2000))
        check("holdExtend accepted", lease.holdExtend(point, 100, 2050))
        check("hold lease continues when fresh", lease.shouldContinue(2100))
        check("hold target cannot migrate", !lease.holdExtend(GestureTarget(.8f, .8f), 100, 2110))
        lease.holdRelease()
        check("holdRelease clears state", lease.state == GestureSessionState.IDLE)
        check("released hold cannot extend", !lease.holdExtend(point, 100, 2200))
        check("new hold can start", lease.holdStart(point, 100, 2300))
        val generation = lease.generation
        lease.cancelAll()
        check("cancelAll clears active gesture", lease.activeCount == 0 && lease.state == GestureSessionState.IDLE)
        check("cancelAll invalidates queued callbacks", lease.generation == generation + 1)
        check("watchdog expires unrenewed hold", lease.holdStart(point, 50, 3000) && !lease.shouldContinue(3051) && lease.state == GestureSessionState.IDLE)

        val executor = RecordingExecutor()
        check("input tap API", executor.tap(.5f, .5f, 60) { true })
        check("input holdStart API", executor.holdStart(.5f, .5f, 65) { true })
        check("input holdExtend API", executor.holdExtend(.5f, .5f, 65) { true })
        executor.holdRelease()
        executor.cancelAll()
        check("executor tap/start/extend/release/cancel contract", executor.events == listOf("tap", "holdStart", "holdExtend", "holdRelease", "cancelAll"), "events=${executor.events}")
        check("executor rejects unauthorized tap", !executor.tap(.5f, .5f, 60) { false })
    }

    /**
     * Full-loop test on a *simulated plant* built from measurements in the reference video
     * (drift −0.3/s, hold +0.6/s net, catch zone = block ± half width): pipeline → trackers →
     * controller → back into plant. Verifies the controller actually tracks (converges and
     * stays), does not chatter excessively, and does not press when aligned.
     */
    private fun testControllerOnSimulatedPlant() {
        val cfg = AppConfig()
        val rng = Random(42)
        val tc = cfg.tracking; val cc = cfg.control
        val fishTracker = FishTracker(tc)
        val blockTracker = PlayerBarTracker(tc)
        val controller = FishingController(cc)

        // fish trajectory: piecewise random walk with direction changes & stops
        var fishX = 0.5f; var fishV = 0f
        var blockX = 0.5f
        var progress = 0f
        var hold = false
        var t = 0L
        val dt = 1f / 30f
        var alignedFrames = 0; var frames = 0
        var pressCount = 0; var idlePresses = 0
        val half = 0.145f // half block width in bar units (measured ~0.29 bar width)
        repeat(30 * 45) { i -> // 45 s of simulated fishing
            t += (dt * 1e9).toLong()
            // fish dynamics: OU-ish with occasional hard reversals
            fishV += rng.nextFloat() * 0.20f - 0.10f
            if (i % 210 == 0) fishV = (rng.nextFloat() * 0.9f - 0.45f) // burst reversal
            fishV = clamp01((fishV + 0.5f) / 1f) - 0.5f // clamp ±0.5/s
            if (rng.nextFloat() < 0.01f) fishV = 0f       // fish stops dead
            fishX = (fishX + fishV * dt).coerceIn(0.05f, 0.95f)

            // block dynamics
            blockX += (if (hold) 0.55f else -0.30f) * dt
            blockX = blockX.coerceIn(half, 1f - half)

            // progress rule: |err| < half → gains; else loses
            val err = fishX - blockX
            progress += (if (abs(err) < half) 0.030f else -0.025f) * dt
            progress = progress.coerceIn(0f, 1f)

            // "vision": noisy measurements (±1.5 px of 640 ≈ 0.0023) + rare miss
            val measFish = if (rng.nextFloat() < 0.06f) null else (fishX + rng.nextFloat() * 0.012f - 0.006f)
            val measBlock = if (rng.nextFloat() < 0.05f) null else (blockX + rng.nextFloat() * 0.012f - 0.006f)
            fishTracker.update(t, measFish, if (measFish == null) 0f else 0.85f, 300f)
            blockTracker.update(t, measBlock, 0.29f, if (measBlock == null) 0f else 0.85f, abs(err) > half,
                0f, 300f, (blockX - half) * 300f, (blockX + half) * 300f)

            val d = controller.update(t, dt, fishTracker.out, blockTracker.out, 0f)
            frames++
            if (abs(err) < half * 0.7f) alignedFrames++
            when (d.action) {
                ControlAction.TAP -> {
                    pressCount++
                    // "unnecessary press" = pressed while the *predicted* error is inside the
                    // deadband (what the controller actually minimizes)
                    if (abs(d.predictedError) < cc.deadband * 0.5f) idlePresses++
                }
                ControlAction.HOLD_START -> { hold = true; pressCount++ }
                ControlAction.HOLD_EXTEND -> {}
                ControlAction.HOLD_RELEASE -> hold = false
                ControlAction.NONE -> {}
            }
        }
        val alignRate = alignedFrames.toFloat() / frames
        check("controller tracks fish (≥85% aligned)", alignRate >= 0.85f, "aligned=${(alignRate * 100).toInt()}% progress=$progress")
        check("progress reaches catch", progress > 0.80f, "progress=$progress")
        check("no idle presses (aligned deadband respected)", idlePresses == 0, "idlePresses=$idlePresses")
        check("reasonable press count", pressCount in 20..frames, "presses=$pressCount/$frames")
    }
}
