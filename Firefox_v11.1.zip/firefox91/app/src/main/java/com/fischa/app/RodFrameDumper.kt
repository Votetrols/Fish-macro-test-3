package com.fischa.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.fischa.core.common.NormRegion
import com.fischa.core.log.Tags
import com.fischa.core.vision.RodDiagEvent
import com.fischa.core.vision.RodFrameDiagnostics
import com.fischa.core.vision.RodV9Result
import com.fischa.core.vision.VisionFrame
import java.io.File
import java.io.FileOutputStream

/**
 * V9 §9 — gravação dos **frames de diagnóstico** da ROI.
 *
 * Este é o lado Android do contrato [RodFrameDiagnostics] definido no core: quando o detector V9
 * sinaliza um evento (candidato encontrado, nenhum candidato, confiança baixa, `TARGET_NOT_FOUND`,
 * recuperação, alvo confirmado), este sink salva um PNG anotado da ROI — com a janela, **todos** os
 * candidatos, o candidato escolhido, o alvo confirmado e `lastKnownTarget` desenhados por cima.
 *
 * É exatamente o que a spec pede: poder comparar **o que o detector vê** com **o que aparece no
 * Roblox**. Os arquivos ficam em
 * `Android/data/com.fischa.app/files/rod_diag/` e podem ser baixados por adb:
 *
 * ```
 * adb pull /sdcard/Android/data/com.fischa.app/files/rod_diag .
 * ```
 *
 * Freios de segurança (o sink nunca deve custar FPS nem encher o armazenamento):
 *  * intervalo mínimo entre arquivos ([minIntervalMs]);
 *  * teto de arquivos mantidos ([maxFiles] — os mais antigos são apagados);
 *  * qualquer falha de I/O é engolida e registrada — diagnóstico nunca derruba a sessão;
 *  * **não executa input**: este arquivo só lê pixels e escreve PNG.
 */
class RodFrameDumper(
    context: Context,
    private val minIntervalMs: Long = 750L,
    private val maxFiles: Int = 60,
    private val log: (String) -> Unit = {},
) : RodFrameDiagnostics {

    private val dir = File(context.getExternalFilesDir(null) ?: context.filesDir, "rod_diag")
    private val lastWriteNs = HashMap<RodDiagEvent, Long>()
    private var written = 0

    val directory: File get() = dir

    override fun onRodFrame(
        event: RodDiagEvent,
        frame: VisionFrame,
        roi: NormRegion,
        result: RodV9Result,
        note: String,
    ) {
        val now = System.nanoTime()
        val last = lastWriteNs[event] ?: 0L
        if (now - last < minIntervalMs * 1_000_000L) return
        lastWriteNs[event] = now
        runCatching { write(event, frame, roi, result, note, now) }
            .onFailure { log("[ROD_DIAG] falha ao gravar frame de diagnóstico: ${it.message}") }
    }

    private fun write(
        event: RodDiagEvent,
        frame: VisionFrame,
        roi: NormRegion,
        result: RodV9Result,
        note: String,
        nowNs: Long,
    ) {
        if (!dir.exists()) dir.mkdirs()
        val w = frame.width
        val h = frame.height
        // recorte da ROI com folga de contexto (mesma ideia do MemoryRodDiagnostics do core)
        val pad = 0.10f
        val x0 = ((roi.left - roi.width * pad) * w).toInt().coerceIn(0, w - 1)
        val y0 = ((roi.top - roi.height * pad) * h).toInt().coerceIn(0, h - 1)
        val x1 = ((roi.right + roi.width * pad) * w).toInt().coerceIn(x0 + 1, w)
        val y1 = ((roi.bottom + roi.height * pad) * h).toInt().coerceIn(y0 + 1, h)
        val cw = (x1 - x0).coerceAtLeast(1)
        val ch = (y1 - y0).coerceAtLeast(1)

        // ---- desenha o recorte ampliado + anotações do detector -------------------------------
        val scale = ((TARGET_WIDTH / cw).coerceAtLeast(1))
        val bmp = Bitmap.createBitmap(cw * scale, ch * scale, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(cw * ch)
        for (y in 0 until ch) {
            val src = (y0 + y) * w
            for (x in 0 until cw) pixels[y * cw + x] = frame.argb[src + x0 + x]
        }
        // fundo: o recorte da ROI (escalado pelo Bitmap.createScaledBitmap)
        val crop = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
        crop.setPixels(pixels, 0, cw, 0, 0, cw, ch)
        val canvas = Canvas(bmp)
        val scaledBase = Bitmap.createScaledBitmap(crop, bmp.width, bmp.height, false)
        canvas.drawBitmap(scaledBase, 0f, 0f, null)
        crop.recycle()
        scaledBase.recycle()
        val k = scale.toFloat()
        fun tx(fx: Float) = (fx * w - x0) * k
        fun ty(fy: Float) = (fy * h - y0) * k

        // ROI (janela móvel)
        boxPaint.color = colorForState(result)
        canvas.drawRect(
            tx(roi.left), ty(roi.top), tx(roi.right), ty(roi.bottom), boxPaint,
        )
        // todos os candidatos
        for (c in result.candidateData) {
            val r = c.r * k
            val cx = (c.cx - x0) * k
            val cy = (c.cy - y0) * k
            candidatePaint.color = CANDIDATE
            canvas.drawRect(cx - r, cy - r, cx + r, cy + r, candidatePaint)
            canvas.drawLine(cx - 8f, cy, cx + 8f, cy, candidatePaint)
            canvas.drawLine(cx, cy - 8f, cx, cy + 8f, candidatePaint)
            textPaint.color = CANDIDATE
            canvas.drawText("%.2f".format(c.score), cx + r + 3f, cy, textPaint)
        }
        // alvo confirmado
        if (result.targetFound) {
            val cx = (result.centerPx.x - x0) * k
            val cy = (result.centerPx.y - y0) * k
            confirmedPaint.color = CONFIRMED
            canvas.drawCircle(cx, cy, 14f * k, confirmedPaint)
            textPaint.color = CONFIRMED
            canvas.drawText("ALVO", cx + 16f * k, cy, textPaint)
        }
        // lastKnownTarget (memória)
        if (result.lastKnownX.isFinite()) {
            val cx = (result.lastKnownX * w - x0) * k
            val cy = (result.lastKnownY * h - y0) * k
            canvas.drawLine(cx - 12f * k, cy, cx + 12f * k, cy, lastKnownPaint)
            canvas.drawLine(cx, cy - 12f * k, cx, cy + 12f * k, lastKnownPaint)
            textPaint.color = Color.GRAY
            canvas.drawText("lastKnown", cx + 14f * k, cy, textPaint)
        }

        val header = "#$written ${event.name} (${event.tag})\n$note\n" +
            "roi=(${x0},${y0},${x1 - x0},${y1 - y0}) frame=${w}x${h} t=${nowNs / 1_000_000L}ms"
        paintBg.color = Color.argb(170, 0, 0, 0)
        canvas.drawRect(0f, 0f, bmp.width.toFloat(), 62f, paintBg)
        textPaint.color = Color.WHITE
        canvas.drawText(header, 6f, 16f, textPaint)

        val name = "%s_%04d_%d.png".format(event.tag, written, nowNs / 1_000_000L)
        val file = File(dir, name)
        FileOutputStream(file).use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }
        bmp.recycle()
        written++
        log("[ROD_DIAG] frame salvo: ${file.absolutePath} ($note)")
        prune()
    }

    /** mantém no máximo [maxFiles] arquivos (os mais recentes ficam) */
    private fun prune() {
        val files = dir.listFiles()?.sortedBy { it.lastModified() } ?: return
        if (files.size <= maxFiles) return
        for (i in 0 until files.size - maxFiles) runCatching { files[i].delete() }
    }

    private fun colorForState(result: RodV9Result): Int = when {
        result.targetNotFound -> LOST
        result.recovering -> CANDIDATE
        result.targetFound -> TRACKING
        result.candidateFound -> CANDIDATE
        else -> SEARCH
    }

    private val boxPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f }
    private val candidatePaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 2f }
    private val confirmedPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f }
    private val lastKnownPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = Color.GRAY }
    private val textPaint = Paint().apply { textSize = 14f; color = Color.WHITE; isAntiAlias = false }
    private val paintBg = Paint().apply { style = Paint.Style.FILL }

    companion object {
        /** o recorte é ampliado até ~este tamanho para que o botão seja legível no PNG */
        private const val TARGET_WIDTH = 320

        private val SEARCH = 0xFFFFD400.toInt()
        private val CANDIDATE = 0xFFFF9800.toInt()
        private val CONFIRMED = 0xFF00E676.toInt()
        private val TRACKING = 0xFF00E5FF.toInt()
        private val LOST = 0xFFFF1744.toInt()

        /** diretório relativo do diagnóstico (usado no texto de ajuda do app) */
        const val RELATIVE_DIR = "rod_diag"

        /** tag de log do dumper (reusa o canal do detector) */
        val LOG_TAG = Tags.ROD_DIAG
    }
}
