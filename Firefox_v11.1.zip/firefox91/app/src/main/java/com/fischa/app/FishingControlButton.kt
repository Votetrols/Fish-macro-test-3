package com.fischa.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import com.fischa.app.ui.DiagnosticsLog
import com.fischa.core.state.AutomationState
import com.fischa.core.state.AutomationUi

/**
 * **Controle manual da automação (V9.1 §2/§14).**
 *
 * Um único botão flutuante pequeno, de alto contraste, arrastável, desenhado com
 * `TYPE_ACCESSIBILITY_OVERLAY` **pelo serviço de acessibilidade já existente**
 * ([GameAccessibilityService]) — nenhuma segunda arquitetura de AccessibilityService, nenhum
 * overlay próprio do engine.
 *
 *  - texto/visibilidade vêm de [AutomationUi] (regra testável em JVM, sem Android);
 *  - `START FISHING` (READY) ⇄ `STOP` (FISHING_ACTIVE); durante `STOPPING` o botão fica
 *    desabilitado mostrando `STOPPING`;
 *  - **uma única instância**: [render] reaproveita a view e o listener (o clique é lido do estado
 *    ATUAL do serviço, nunca do texto desenhado);
 *  - é arrastável para não cobrir a área do jogo; a posição é lembrada;
 *  - some quando a automação volta para `APP_IDLE` ([render] esconde) ou quando o serviço de
 *    acessibilidade termina ([hide]).
 */
class FishingControlButton(
    private val context: Context,
    private val onToggle: () -> Unit,
) {
    private val windowManager: WindowManager? =
        (context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager)

    private var view: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var current: AutomationState = AutomationState.APP_IDLE
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    /** true quando o botão está na tela. */
    val isShowing: Boolean get() = view != null

    /** Estado desenhado atualmente (diagnóstico/tests de UI). */
    val drawnState: AutomationState get() = current

    private fun prefs() = context.getSharedPreferences("fisch-ui", Context.MODE_PRIVATE)

    /**
     * Mostra/atualiza/esconde conforme o estado. Idempotente: chamar de novo com o mesmo estado não
     * cria outra view nem outro listener.
     */
    fun render(state: AutomationState) {
        current = state
        if (!AutomationUi.buttonVisible(state)) {
            hide()
            return
        }
        val existing = view
        if (existing != null) {
            applyState(existing, state)
            return
        }
        val wm = windowManager ?: run {
            DiagnosticsLog.event("AUTOMATION", "WindowManager indisponível: botão flutuante não criado")
            return
        }
        val label = TextView(context).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            val pad = (14 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, pad / 2)
            minHeight = (44 * resources.displayMetrics.density).toInt()
            minWidth = (120 * resources.displayMetrics.density).toInt()
            isClickable = true
            isFocusable = false
            // Um único listener para a vida do botão (nada de listeners acumulados, §14).
            setOnClickListener { onToggle() }
            setOnTouchListener(dragListener)
        }
        val layout = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs().getInt(KEY_X, DEFAULT_X)
            y = prefs().getInt(KEY_Y, DEFAULT_Y)
        }
        val added = runCatching { wm.addView(label, layout) }.isSuccess
        if (!added) {
            DiagnosticsLog.event("AUTOMATION", "não foi possível adicionar o botão flutuante (overlay recusado)")
            return
        }
        view = label
        params = layout
        applyState(label, state)
        DiagnosticsLog.event("AUTOMATION", "botão flutuante criado: '${AutomationUi.buttonLabel(state)}' em (${layout.x},${layout.y})")
    }

    /** Esconde e libera a view (sem vazar: view/params zerados). */
    fun hide() {
        val v = view ?: return
        val wm = windowManager
        runCatching { wm?.removeViewImmediate(v) }
        view = null
        params = null
        DiagnosticsLog.event("AUTOMATION", "botão flutuante removido")
    }

    private fun applyState(target: TextView, state: AutomationState) {
        target.text = AutomationUi.buttonLabel(state)
        target.background = background(state)
        target.isEnabled = AutomationUi.buttonEnabled(state)
        target.alpha = if (target.isEnabled) 1f else 0.7f
        target.contentDescription = when (state) {
            AutomationState.APP_READY -> "Iniciar a automação de pesca"
            AutomationState.FISHING_ACTIVE -> "Parar a automação de pesca"
            AutomationState.FISHING_STOPPING -> "Parando a automação de pesca"
            AutomationState.APP_IDLE -> "Automação desligada"
        }
    }

    private fun background(state: AutomationState): GradientDrawable {
        val fill = when (state) {
            AutomationState.APP_READY -> READY_COLOR
            AutomationState.FISHING_ACTIVE -> ACTIVE_COLOR
            AutomationState.FISHING_STOPPING -> STOPPING_COLOR
            AutomationState.APP_IDLE -> STOPPING_COLOR
        }
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 12f * context.resources.displayMetrics.density
            setColor(fill)
            setStroke((2f * context.resources.displayMetrics.density).toInt(), Color.BLACK)
        }
    }

    /**
     * Arrasta para reposicionar; um toque curto (sem arrasto) é um clique. Sem isso o botão
     * cobriria uma área fixa do jogo (§2: "não bloquear desnecessariamente a área do jogo").
     */
    private val dragListener = View.OnTouchListener { touched, event ->
        val layout = params
        val target = view
        if (layout == null || target == null) {
            false
        } else when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragStartX = layout.x
                dragStartY = layout.y
                touchDownX = event.rawX
                touchDownY = event.rawY
                dragging = false
                true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - touchDownX
                val dy = event.rawY - touchDownY
                if (!dragging && (kotlin.math.abs(dx) > touchSlop || kotlin.math.abs(dy) > touchSlop)) {
                    dragging = true
                }
                if (dragging) {
                    layout.x = dragStartX + dx.toInt()
                    layout.y = dragStartY + dy.toInt()
                    runCatching { windowManager?.updateViewLayout(target, layout) }
                }
                true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    prefs().edit().putInt(KEY_X, layout.x).putInt(KEY_Y, layout.y).apply()
                    invalidatePosition(target, layout)
                    dragging = false
                } else {
                    // toque curto = clique (e o clique passa pelo caminho normal de acessibilidade)
                    touched.performClick()
                }
                true
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                true
            }
            else -> true
        }
    }

    /** Reposiciona para caber na tela (rotação/mudança de layout) e reaplica o layout. */
    private fun invalidatePosition(target: View, layout: WindowManager.LayoutParams) {
        val metrics = context.resources.displayMetrics
        val maxX = (metrics.widthPixels - target.width).coerceAtLeast(0)
        val maxY = (metrics.heightPixels - target.height).coerceAtLeast(0)
        layout.x = layout.x.coerceIn(0, maxX)
        layout.y = layout.y.coerceIn(0, maxY)
        runCatching { windowManager?.updateViewLayout(target, layout) }
    }

    private var dragStartX = 0
    private var dragStartY = 0
    private var touchDownX = 0f
    private var touchDownY = 0f
    private var dragging = false

    companion object {
        /** verde = pronto para começar; vermelho = pescando (pode parar); cinza = parando */
        private val READY_COLOR = 0xFF1B5E20.toInt()
        private val ACTIVE_COLOR = 0xFFC62828.toInt()
        private val STOPPING_COLOR = 0xFF4E4E4E.toInt()
        private const val KEY_X = "controlButtonX"
        private const val KEY_Y = "controlButtonY"
        /** canto superior esquerdo, longe dos controles de jogo mais comuns (joystick/cast) */
        private const val DEFAULT_X = 24
        private const val DEFAULT_Y = 120
    }
}
