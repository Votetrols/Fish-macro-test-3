# Como testar a V8 no aparelho (Galaxy A22 / Android 13)

Objetivo deste roteiro: **ver com os próprios olhos** que a praça de detecção (janela/ROI) se move
seguindo o botão da vara, que ela não dá pulos com falso positivo, que ela recupera quando o botão
sai e que **nada é clicado** enquanto `REAL_INPUT` está `DISABLED`.

## 0. Instalar

```bash
./gradlew :app:assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk   # ou deliverables/FischAutoBotV8-debug.apk
```

Permissões: serviço de acessibilidade (overlay de debug) + consentimento de captura (MediaProjection).
`REAL_INPUT` permanece **OFF** — com OFF o log pode registrar `WOULD_CAST`, mas nenhum gesto é
enviado.

## 1. O que aparece na tela (overlay de debug)

- **janela de detecção** (a praça), sempre com o tamanho real:
  - **ciano** = `TRACKING` (seguindo o alvo confirmado);
  - **laranja** = `RECOVERING` (busca ampliada);
  - **vermelho** = `TARGET_LOST` (alvo ausente na janela, dentro do grace);
  - **amarelo** = `INITIAL` / `SEARCHING` (ainda procurando dentro da janela);
- **cruzeta laranja** = candidato visto neste frame (dentro da janela);
- **cruzeta cinza** = posição anterior do alvo (para onde a janela está indo);
- **cruzeta colorida** = centro do alvo confirmado;
- linha de texto:

```
V8: window=(x,y,w,h) state=<INITIAL|SEARCHING|TRACKING|TARGET_LOST|RECOVERING> conf=0.00
    candidate=(x,y) prev=(x,y) recovery=YES/NO etapa=N expand=YES/NO
```

e, acima dela, `STATE=… SEARCH=WINDOW/RECOVERY CANDIDATE=NONE/FOUND/CONFIRMED … CONFIRM=k/3`.

## 2. Roteiro de teste visual (5 minutos)

1. **START** com o botão da vara visível.
   - Esperado: a praça nasce na **posição inicial configurada** (`0.62, 0.47` do frame, tamanho
     `0.32 × 0.36`), mostra `CANDIDATE=FOUND` e depois `CONFIRMED`/`TRACKING` (ciano).
2. **Mova o personagem/câmera** devagar para a esquerda/direita/cima/baixo.
   - Esperado: a praça **acompanha** o botão, mantendo-o perto do centro, sem tremer
     (`deadZone`) e sem saltos (a cada frame anda no máximo `maxMovePerFrame`).
3. **Pare** com o botão parado.
   - Esperado: a praça **fica parada** (nada de oscilação de 1–2 px).
4. **Vire para o lado / tape o botão com o dedo** para escondê-lo.
   - Esperado: `TARGET_LOST` por ~120 ms com a praça **parada**; depois `RECOVERING etapa 1/3` com a
     praça **maior** (laranja). Se continuar sem botão: etapas 2 e 3 (busca na área inicial) e, ao
     esgotar o orçamento (~1,5 s), o texto passa a indicar **`TARGET_NOT_FOUND`**.
   - Em nenhum momento aparece uma cruzeta de alvo "inventada" (nenhuma coordenada falsa).
5. **Mostre o botão de novo.**
   - Esperado: `TARGET_FOUND (tracking)`; a praça **volta ao tamanho normal** e a posição é
     atualizada; o log mostra `[ROD_V8] TARGET_FOUND …`.
6. **Falso positivo:** aponte para uma mancha escura parecida **longe** do botão.
   - Esperado: a praça **não pula** para a mancha (o candidato é rejeitado/`suspeito`); a busca pode
     ser ampliada em torno da **última posição conhecida** e o alvo volta a ser encontrado quando o
     botão reaparece.
7. **Confirme que nada é clicado:** o texto continua `REAL_INPUT=DISABLED` e a tela não recebe toques.

## 3. Logs (o que olhar)

```bash
adb logcat -s ROD_V8:* STATE:* ROD_CONFIRM:* TRACKING:* SafetyGuard:*
```

Mensagens úteis:

| Mensagem | Significado |
|---|---|
| `[STATE] ROD_V8=TRACKING` | mudança de estado da janela |
| `[ROD_V8] TARGET_FOUND center=… r=… score=… conf=… streak=k/3 roi=…` | alvo confirmado |
| `[ROD_V8] TARGET_LOST (…ms sem detecção) → recuperação` | perdeu o alvo (grace) |
| `[ROD_V8] RECOVERING etapa=N rota=… lastKnown=(x,y)` | recuperação em andamento |
| `[ROD_V8] TARGET_NOT_FOUND (…ms de recuperação, estágios 1..3 esgotados)` | orçamento esgotado, sem invenção |
| `[ROD_V8] candidato rejeitado na validação: <motivo>` | motivo exato da rejeição (tamanho, borda, inconsistência espacial) |
| `[ROD_V8] reconfirmação exigida (…)` | ciclo novo exigindo confirmação nova |

## 4. Ajustar a janela (se necessário)

As chaves seguem o padrão existente (`rodV8.<nome>`): `initialRoiX`, `initialRoiY`, `roiWidth`,
`roiHeight`, `maxMovePerFrame`, `deadZone`, `smoothing`, `minimumConfidence`, `confirmationFrames`,
`recoveryExpansion`, `recoveryTimeout`. Se o botão **não** aparece na janela inicial do aparelho,
o ajuste mais direto é `initialRoiX`/`initialRoiY` (movem a praça) ou `roiWidth`/`roiHeight`
(aumentam a área). Nada disso é obrigatório: os defaults já funcionam.

## 5. O que este roteiro **não** prova

- Não substitui o teste em campo (captura real, Roblox real, diferentes aparelhos).
- O overlay de debug é informativo; ele não altera o detector (teste automatizado garante isso).
- Só vale a pena testar com o **input real desligado** enquanto a política de sessão estiver travada:
  nenhum passo deste roteiro precisa de `REAL_INPUT` ligado.
