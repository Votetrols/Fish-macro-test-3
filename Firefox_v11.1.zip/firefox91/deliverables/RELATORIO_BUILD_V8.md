# Relatório de build — V8

Ambiente: sandbox Linux, JDK 17 (`/home/user/.cache/toolchain/jdk17`), Gradle 8.9 (wrapper do
projeto), Android SDK 35 + build-tools instalados, `local.properties` apontando `sdk.dir` para o SDK.

| Comando | Resultado |
|---|---|
| `./gradlew :core:test` | **BUILD SUCCESSFUL — 171 testes, 0 falhas** (inclui `V8RodDetectionTest` 30 e `V8PipelineIntegrationTest` 5) |
| `./gradlew :core:selfTest` | **138 checks, 0 falhas** |
| `./gradlew :app:assembleDebug` | **BUILD SUCCESSFUL em 2m19s** — `app/build/outputs/apk/debug/app-debug.apk` (3.632.944 bytes, 3,6 MB) |

APK gerado: `com.fischa.app`, minSdk 26, targetSdk 35 (mesmas configurações da V7).

Artefatos entregues nesta pasta:

- `FischAutoBotV8-debug.apk` — APK debug compilado neste build (instalável para o teste visual);
- `FischAutoBotV8-clean.zip` — código-fonte completo da V8 (sem `build/`, `.gradle/`, `.kotlin/`
  nem `local.properties`);
- `ENTREGA_V8.md`, `CHANGES_V8.md`, `RESULTADO_TESTES_V8.md`, `COMO_TESTAR_A22_V8.md`.

Observação: como na V7, **o teste real no aparelho não foi executado neste ambiente** (sem
aparelho/Roblox). O que está provado aqui é: compila, os 171 testes passam, o self-test passa, o APK
é gerado, e o comportamento da janela móvel é verificado por cenas sintéticas determinísticas
(inclusive FPS, resoluções e bordas diferentes). O roteiro de verificação visual está em
`COMO_TESTAR_A22_V8.md`.
