# ENTREGA V8 — Detecção por Janela Móvel (Rod Detection V8)

**O que foi pedido:** substituir a detecção automática atual (busca ampla global com candidatos
ranqueados) por um método mais simples e previsível: **uma janela/ROI de detecção que se move pela
tela seguindo o botão da vara**. Mantém-se o *mecanismo visual* da praça de detecção que já existia
(contraste do anel, núcleo escuro, tamanho, histórico), mas a busca **não é global** — ela acontece
dentro da janela atual.

**Resultado:** implementado como `RodDetectionV8` (`core/src/main/kotlin/com/fischa/core/vision/RodDetectionV8.kt`),
plugado no `VisionPipeline` como **detector principal** (`AppConfig.rodDetector = RodDetectorKind.V8`,
default). A V7 continua no código, selecionável (`rodDetector = V7`).

Verificação executada neste ambiente:

| Comando | Resultado |
|---|---|
| `./gradlew :core:test` | **171 testes, 0 falhas** (30 da V8 + 5 de integração V8) |
| `./gradlew :core:selfTest` | **138 checks, 0 falhas** |
| `./gradlew :app:assembleDebug` | **BUILD SUCCESSFUL** — `app-debug.apk` (3,6 MB) |

Detalhamento: [`../docs/RESULTADO_TESTES_V8.md`](../docs/RESULTADO_TESTES_V8.md) ·
Mudanças por arquivo: [`../docs/CHANGES_V8.md`](../docs/CHANGES_V8.md) ·
Teste no aparelho: [`../docs/COMO_TESTAR_A22_V8.md`](../docs/COMO_TESTAR_A22_V8.md).

---

## 1. Janela configurável (posição e tamanho)

`AppConfig.RodV8` — a janela é expressa em **frações do frame processado** (independente de
resolução/orientação), com valores seguros de fábrica:

| Parâmetro | Default | Papel |
|---|---|---|
| `initialRoiX`, `initialRoiY` | `0.62`, `0.47` | canto superior esquerdo da janela inicial |
| `roiWidth`, `roiHeight` | `0.32`, `0.36` | tamanho da janela (constante fora da recuperação) |
| `maxMovePerFrame` | `0.06` | deslocamento máximo da janela por frame |
| `deadZone` | `0.035` | variações menores não movem a janela (anti-jitter) |
| `smoothing` | `0.35` | `new = old*smoothing + target*(1-smoothing)` |
| `minimumConfidence` | `0.50` | confiança mínima para confirmar o alvo |
| `confirmationFrames` | `3` | frames consecutivos antes de `TRACKING` |
| `recoveryExpansion` | `1.8` | fator de expansão da janela por etapa |
| `recoveryTimeout` | `1500` ms | orçamento total da recuperação → `TARGET_NOT_FOUND` |
| extras (sempre com default) | `lostGraceMs=120`, `targetConfirmMs=120`, `confirmWindowMs=1500`, `minSizeNormalized=0.030`, `maxSizeNormalized=0.110`, `maxCandidateJump=0.18`, `searchStepPx=3`, `maxRefinedCandidates=5`, `minRingDelta=12`, `confidenceDecaySec=0.30` |  |

Funciona sem configurar nada: todos os parâmetros têm default. Chaves expostas em
`toMap()`/`withOverrides()` como `rodV8.<nome>` (e `rodDetector`), no mesmo formato já usado pelas
configurações existentes.

## 2. Detecção **dentro** da janela (e não na tela toda)

Fluxo por frame (spec §2):

```
frame → janela atual → RodWindowDetector.scan/refine (só dentro da janela)
      → candidato?  não → janela fica perto da última posição conhecida → recuperação
                    sim → centro → validação (§5) → janela se move na direção do candidato
```

Nada fora da janela é avaliado (teste `windowOnlySearchesInsideItself`). O `RodWindowDetector` é o
**mesmo mecanismo visual** da praça usada antes (fila de hits da V7 / praça da V5) — foi extraído
para uma classe única, usada pela V8 e pela V7, para não haver duas implementações divergentes.

## 3. A janela segue o alvo

- o alvo é mantido **perto do centro** da janela (`moveWindowTowards` usa o centro do candidato);
- com `deadZone` (default 3,5 % do frame) variações de poucos pixels **não** movem a janela;
- `smoothing` faz a aproximação gradual (não "cola" no alvo, nem fica para trás);
- o movimento é limitado por `maxMovePerFrame` **por frame**;
- perto das bordas a janela é reposicionada para **continuar inteira dentro da tela**.

## 4. Limite de movimento / nada de teletransporte

`maxMovePerFrame` é aplicado em `moveWindowTowards()` (e testado por
`windowNeverMovesMoreThanMaxMovePerFrame`, `aSingleDistantCandidateCannotTeleportTheWindow`).
Um candidato que passe a validação mas esteja longe demais da última posição é tratado como
**suspeito** (`maxCandidateJump`) e não move a ROI: o detector entra em recuperação em vez de pular.

## 5. Validação do candidato (antes de mover a ROI)

`validationFailure()` devolve o motivo (e o motivo vai para o log), exigindo:

1. score finito e ≥ piso de viabilidade (0,35);
2. posição plausível (dentro do frame, não colado na borda);
3. **tamanho plausível**: raio medido dentro da faixa calibrada (`minSizeNormalized`…`maxSizeNormalized`
   com folga de 0,6×…1,3×, porque o blob escuro medido é ~0,7–1,0 do anel visual);
4. **consistência espacial**: em tracking, distância da última posição conhecida ≤ `maxCandidateJump`
   (na recuperação a tolerância é a própria janela expandida);
5. **consistência temporal**: streak ancorado com desvio máximo `max(0,020 ; 0,8×raio)` dentro de
   `confirmWindowMs` + persistência no histórico de candidatos.

## 6. Rastreamento simplificado

`lastKnownTargetX/lastKnownTargetY` guardam a última posição confirmada; a busca do próximo frame
começa **na janela em torno dessa posição**. Não existe busca contínua de tela cheia.

## 7. Recuperação em etapas (nunca "sumiu" de imediato)

| Etapa | Quando | O que faz |
|---|---|---|
| grace | primeiros `lostGraceMs` (120 ms) sem candidato | `TARGET_LOST`: janela **parada** na última posição |
| 1 | até 1/3 do `recoveryTimeout` | busca ampliada (`recoveryExpansion`) **ao redor da última posição conhecida** |
| 2 | até 2/3 | busca ainda maior ao redor da mesma posição |
| 3 | até o fim do orçamento | usa a **área inicial configurada** como fallback |
| 4 | orçamento esgotado | **`TARGET_NOT_FOUND`** — e continua varrendo; nada é inventado |

`TARGET_NOT_FOUND` é reportado em `RodV8Result.targetNotFound` (+ motivo e log), com
`targetX/targetY` vazios (`NaN`) e `targetFound=false`.

## 8. Volta ao normal quando o alvo reaparece

Achou de novo → `TARGET_FOUND` → `lastKnownTarget` atualizado → ROI reposicionada → busca normal →
janela volta ao **tamanho normal** (só a posição é dinâmica; ver §12).

## 9. Estabilização (`deadZone`)

Variações pequenas (poucos pixels) não movem a janela — testado nos dois sentidos
(`deadZoneSuppressesSmallMovements` e, como controle, `withoutDeadZoneTheSameSceneMovesTheWindow`).

## 10. Suavização

`newPosition = oldPosition * smoothing + targetPosition * (1 - smoothing)`, configurável
(default 0,35 → ~65 % do caminho por frame; nada de detecção atrasada).
Teste: `smoothingMakesTheWindowApproachGradually` (duas configurações, uma aproxima rápido e a outra
devagar, **sem perder o alvo**).

## 11. Limites da ROI

Nunca sai da tela: `0 ≤ x ≤ right ≤ 1`, `0 ≤ y ≤ bottom ≤ 1` (a janela é reposicionada perto das
bordas para caber inteira). Testes: `windowNeverLeavesTheScreenEvenWhenChasingATargetAtEveryBorder`,
`targetNearTheScreenEdgesIsStillFoundAndTheWindowStaysInside`.

## 12. Tamanho da janela

`roiWidth`/`roiHeight` configuráveis; em operação normal **só a posição muda**. Durante a recuperação
a janela fica temporariamente maior (`recoveryExpansion`, indicado por `windowExpanded`) e volta ao
tamanho configurado assim que o alvo é confirmado de novo
(`lostTargetIsRecoveredAroundTheLastKnownPositionAndTheWindowReturnsToNormalSize`).

## 13. Máquina de estados

`INITIAL → SEARCHING → TRACKING → TARGET_LOST → RECOVERING → TRACKING` (+ `TARGET_NOT_FOUND` como
resposta explícita quando a recuperação esgota). Implementada em `RodV8State` e verificada em
`walksTheSpecifiedStateSequence`; a ordem dos estados aparece no log (`[STATE] ROD_V8=…`).

## 14. Confirmação temporal antes de `TRACKING`

`confirmationFrames` (default 3) com o número derivado também do tempo medido
(`targetConfirmMs`/FPS → `requiredFrames`), streak ancorado (desvio ≤ tolerância dentro de
`confirmWindowMs`) — sem precisar de uma sequência longa que atrase a pesca.

## 15. Independente de FPS

Todo o tempo usa `nowNs`/`dtSec` (confirmado em `lossAndRecoveryAreTimedNotFrameCounted` e
`worksAtDifferentFrameRatesAndConfirmationFollowsTheMeasuredFps` com 8/15/30/60 FPS). O FPS **não**
é presumido 60; quando não é informado, o detector assume ~30 FPS apenas para derivar
`requiredFrames`.

## 16. Visualização de debug (sem alterar o comportamento)

`RenderModel`/`PipelineOutput` ganharam: janela atual, candidato, centro do alvo, estado, confiança,
posição anterior, indicação de recuperação/etapa/expansão. O `DebugOverlay` do app desenha:

- **janela** ciano (tracking) / laranja (recuperação), com o tamanho real;
- **candidato** (cruzeta laranja) e **posição anterior** (cruzeta cinza);
- **centro do alvo** (cruzeta da cor do estado);
- linha de texto `V8: window=(x,y,w,h) state=… conf=… candidate=… prev=… recovery=YES/NO etapa=N expand=YES/NO`.

O overlay é passivo: o teste `debugVisualizationIsAPassiveSnapshotAndDoesNotChangeDetection` compara
duas execuções idênticas (lendo e não lendo o modelo) e exige a **mesma sequência de estados**.

## 17. Nenhum input na V8

A V8 **só** devolve `targetFound, targetX, targetY, confidence, state` (e campos de debug). O fluxo
continua: `RodDetectionV8 → VisionPipeline → decisão existente → InputSafetyGuard →
AndroidInputExecutor`. Teste de fonte `detectorNeverImportsOrCallsTheInputLayer` garante que o código
da V8 (comentários removidos) não referencia `dispatchGesture`, `performAction`,
`AndroidInputExecutor`, `InputExecutor`, `InputRequest`, `GestureAction`, `InputSafetyGuard`,
`com.fischa.core.control` nem `com.fischa.core.safety`. Em integração,
`detectionCycleRunsEndToEndWhileNoInputReachesTheExecutor` prova que, mesmo com a detecção
funcionando e o chamador pedindo input real, **nenhum gesto** chega ao executor e nenhum `UNLOCK`
aparece.

## 18. Compatibilidade com a arquitetura atual

- `VisionPipeline` usa a V8 quando `cfg.rodDetector == RodDetectorKind.V8` (default) e a V7 quando
  `V7` — a troca é uma linha de configuração;
- a V8 **não** reaproveita silenciosamente a implementação V6/V7 como método principal: ela tem
  classe própria (`RodDetectionV8`), estado próprio (`RodV8State`) e resultado próprio
  (`RodV8Result`); o que ela compartilha é o **mecanismo visual** (`RodWindowDetector`), que é a
  praça de detecção que a spec manda manter;
- a V7 continua disponível e testada (`V7RodFinderTest`, 13 testes).

## 19. Configuração exposta

`initialRoiX, initialRoiY, roiWidth, roiHeight, maxMovePerFrame, deadZone, smoothing,
minimumConfidence, confirmationFrames, recoveryExpansion, recoveryTimeout` — todos com default
seguro, opção de trocar por `rodV8.*` via `withOverrides`.

## 20. Testes obrigatórios

As 17 cenas pedidas (+ `TARGET_NOT_FOUND` e "nenhuma coordenada falsa") estão em
`V8RodDetectionTest` (30 testes) com o mapeamento completo em
[`../docs/RESULTADO_TESTES_V8.md`](../docs/RESULTADO_TESTES_V8.md). Resumo: alvo parado, esquerda,
direita, cima, baixo, bordas, falso positivo, perda temporária, recuperação, recuperação sem alvo,
limite de movimento, dead zone, suavização, resoluções diferentes, ROI de tamanhos diferentes, FPS
diferentes, ROI nunca fora da tela.

## 21. Critério de sucesso

| Critério | Onde é provado |
|---|---|
| praça inicial configurável | `windowStartsAtTheConfiguredPositionAndSize`, `AppConfigTest` |
| alvo encontrado dentro dela | `targetMoving*`, `stationaryTarget…`, `windowOnlySearchesInsideItself` |
| a praça segue o alvo | `targetMovingLeft/Right/Up/Down`, `assertFollows` |
| movimentos pequenos não tremem | `deadZoneSuppressesSmallMovements`, `stationaryTargetIsFoundConfirmedAndTrackedWithoutJitter` |
| falso positivo não move a ROI drasticamente | `falsePositiveFarFromTheLastKnownPositionIsRejected`, `aSingleDistantCandidateCannotTeleportTheWindow`, `falsePositiveInANoisyEmptySceneNeverMovesTheWindowDrasticly` |
| recupera quando o alvo sai da janela | `temporaryLossKeepsTheWindowAndRecoversWithoutFullRecovery`, `lostTargetIsRecoveredAround…` |
| ROI nunca sai da tela | `windowNeverLeavesTheScreen…`, `targetNearTheScreenEdges…` |
| funciona em posições diferentes | todas as cenas de movimento + bordas + resoluções |
| `VisionPipeline` recebe os resultados corretamente | `V8PipelineIntegrationTest` (5 testes) |
| nenhum input real executado pelo detector | `detectorNeverImportsOrCallsTheInputLayer` + `detectionCycleRunsEndToEndWhileNoInputReachesTheExecutor` |

---

## Regra final

A V8 é **simples**: é uma praça de detecção que **se move** — achou → segue; perdeu → procura perto
de onde estava; não achou → `TARGET_NOT_FOUND`; **nunca inventa posição**; **nunca executa input**.
