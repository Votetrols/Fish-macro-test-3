# V8 — Detecção por Janela Móvel (Rod Detection V8) · Resultado dos testes

Execução neste ambiente (sandbox Linux, JDK 17, Gradle 8.9, Android SDK 35):

| Comando | Resultado |
|---|---|
| `./gradlew :core:test` | **171 testes, 0 falhas** |
| `./gradlew :core:selfTest` | **138 checks, 0 falhas** |
| `./gradlew :app:assembleDebug` | **BUILD SUCCESSFUL** → `app-debug.apk` (3,6 MB) |

Suíte do detector novo (`core/src/test/kotlin/com/fischa/core/v8/`):

- `V8RodDetectionTest` — **30 testes** (as 17 cenas obrigatórias da spec §20 + TARGET_NOT_FOUND + invariantes "sem coordenada falsa" + "sem input");
- `V8PipelineIntegrationTest` — **5 testes** (§17/§18/§21: V8 como detector principal dentro do `VisionPipeline`, lock de input, `TARGET_NOT_FOUND`, debug passivo).

---

## 1. Mapeamento das 17 cenas obrigatórias (§20)

| # | Cena exigida | Teste | O que verifica |
|---|---|---|---|
| 1 | alvo parado | `stationaryTargetIsFoundConfirmedAndTrackedWithoutJitter` | encontra → confirma (§14) → TRACKING; a janela não oscila (sem jitter) |
| 2 | movimento para a esquerda | `targetMovingLeft` | segue o alvo a −6 px/frame |
| 3 | movimento para a direita | `targetMovingRight` | segue o alvo a +6 px/frame |
| 4 | movimento para cima | `targetMovingUp` | segue o alvo a −4 px/frame |
| 5 | movimento para baixo | `targetMovingDown` | segue o alvo a +4 px/frame |
| 6 | perto das bordas | `targetNearTheScreenEdgesIsStillFoundAndTheWindowStaysInside` | acha o botão nas 4 quinas; janela sempre dentro da tela |
| 7 | falso positivo | `falsePositiveFarFromTheLastKnownPositionIsRejected`, `falsePositiveInANoisyEmptySceneNeverMovesTheWindowDrasticly`, `whiteTextPromptInsideTheWindowNeverConfirms` | um "botão" longe/errado não move a ROI nem confirma |
| 8 | perda temporária | `temporaryLossKeepsTheWindowAndRecoversWithoutFullRecovery` | a janela fica no lugar (grace) e retoma sem recuperação completa |
| 9 | recuperação | `lostTargetIsRecoveredAroundTheLastKnownPositionAndTheWindowReturnsToNormalSize` | etapas 1..3 e volta ao tamanho normal |
| 10 | recuperação sem alvo | `recoveryWithoutAnyTargetEndsInTargetNotFoundWithoutInventingAPosition` | esgota o orçamento → `TARGET_NOT_FOUND` |
| 11 | limite de movimento | `windowNeverMovesMoreThanMaxMovePerFrame`, `aSingleDistantCandidateCannotTeleportTheWindow` | nenhum frame anda mais que `maxMovePerFrame`; um candidato distante não teletransporta a janela |
| 12 | dead zone | `deadZoneSuppressesSmallMovements`, `withoutDeadZoneTheSameSceneMovesTheWindow` | variações pequenas não movem; sem dead zone a mesma cena move (controle) |
| 13 | suavização | `smoothingMakesTheWindowApproachGradually` | `smoothing` alto aproxima devagar, baixo aproxima rápido |
| 14 | resoluções diferentes | `worksOnDifferentFrameResolutions` | 640×288, 960×540, 1280×720, 320×240 |
| 15 | ROI de tamanhos diferentes | `worksWithDifferentWindowSizes` | ROI pequena e grande; o tamanho configurado é mantido |
| 16 | FPS diferentes | `worksAtDifferentFrameRatesAndConfirmationFollowsTheMeasuredFps`, `lossAndRecoveryAreTimedNotFrameCounted` | 15/30/60 FPS: confirmação derivada do tempo, perda/recuperação medidas por `ns` |
| 17 | ROI nunca fora da tela | `windowNeverLeavesTheScreenEvenWhenChasingATargetAtEveryBorder` | persegue alvo em todas as bordas; janela sempre `0 ≤ x, right ≤ W` |
| extra | `TARGET_NOT_FOUND` | `targetNotFoundNeverComesWithAFakeCoordinate`, `theDetectorKeepsRetryingAfterTargetNotFoundAndFindsTheTargetWhenItComesBack` | `targetNotFound` nunca vem com coordenada; volta a achar quando o alvo reaparece |
| extra | nunca inventa posição | `neverPublishesAPositionInFramesWithoutATarget` | `targetX/targetY` são `NaN`/vazios quando não há alvo |
| extra | **no input** (§17) | `detectorNeverImportsOrCallsTheInputLayer` | o código da V8 (sem comentários) não referencia `dispatchGesture`, `performAction`, `AndroidInputExecutor`, `InputExecutor`, `InputRequest`, `GestureAction`, `InputSafetyGuard`, `com.fischa.core.control`, `com.fischa.core.safety` |
| extra | configuração inicial (§1/§13) | `windowStartsAtTheConfiguredPositionAndSize`, `walksTheSpecifiedStateSequence` | a janela nasce na posição/tamanho configurados e a ordem dos estados é a da spec |
| extra | rastreabilidade | `logsExplainEveryDecision` | cada decisão (confirmação, perda, etapa de recuperação, rejeição) sai no log |
| extra | busca dentro da janela (§2) | `windowOnlySearchesInsideItself` | nada fora da janela é considerado |

## 2. Integração com o pipeline (§17/§18/§21)

| Teste | O que prova |
|---|---|
| `visionPipelineUsesV8AsTheMainDetectorAndPublishesItsResults` | `AppConfig().validate()` (default) → `rodDetector == "V8"`; `targetFound/targetX/targetY/confidence/state` chegam ao pipeline; centro publicado = centro real do botão (520,199 de 640×288) |
| `detectionCycleRunsEndToEndWhileNoInputReachesTheExecutor` | com `REAL_INPUT` travado a detecção funciona (TRACKING) e **nenhum** gesto chega ao executor; nenhum `UNLOCK` novo aparece |
| `unlockedTheGesturesComeFromTheSafetyPathNotFromTheDetector` | com o input liberado, `holdStart`/`holdRelease` vêm do caminho `guard → executor`, com as coordenadas do alvo detectado |
| `emptyScenePublishesTargetNotFoundAndNeverFabricatesCoordinates` | 160 frames sem alvo: nunca confirma, nunca publica coordenada, a janela expande na recuperação, o orçamento esgota → `TARGET_NOT_FOUND`, janela sempre dentro da tela |
| `debugVisualizationIsAPassiveSnapshotAndDoesNotChangeDetection` | ler (ou não) o `RenderModel` não altera a sequência de estados; o modelo é reconstruído a cada frame (imutável) |

## 3. Suítes legadas preservadas

- `StartSemanticsV5Test` (10) — semântica do START/cast gate, agora rodando com **V8 como
  detector principal** (o teste de confiança mínima configura `rodV8.minimumConfidence`);
- `V7RealInputLockTest` (3) — trava de `REAL_INPUT`; roda explicitamente com a política **V7**
  (`rodDetector = V7`) porque verifica nomes/estados da V7 (a cobertura V8 equivalente está em
  `V8PipelineIntegrationTest`);
- `V7RodFinderTest` (13) — a política V7 continua funcionando (não foi destruída, §18).

## 4. Como reproduzir

```bash
./gradlew :core:test        # 171 testes
./gradlew :core:selfTest    # 138 checks
./gradlew :app:assembleDebug
```

Por classe:

```bash
./gradlew :core:test --tests "com.fischa.core.v8.*" -i
```

O log da V8 (`[ROD_V8]`, `[STATE] ROD_V8=…`) fica visível com `-i` e é a forma mais rápida de
acompanhar confirmação, rejeição de candidato, perda, etapas de recuperação e `TARGET_NOT_FOUND`.
