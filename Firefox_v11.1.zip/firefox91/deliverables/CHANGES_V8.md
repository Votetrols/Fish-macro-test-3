# CHANGES V8 — Detecção por Janela Móvel (substitui a busca ampla como método principal)

A V8 troca o **método principal** de detecção do botão da vara: em vez da busca ampla global
com candidatos ranqueados, o detector passa a ser uma **janela (ROI) móvel**: a mesma praça de
detecção que já existia, agora **configurável, móvel, limitada e com recuperação em etapas**.
A V7 não foi destruída — ela continua no código, atrás de `rodDetector = V7`.

## Arquivos

### Novos

| Arquivo | Conteúdo |
|---|---|
| `core/src/main/kotlin/com/fischa/core/vision/RodDetectionV8.kt` | **Detector V8** (`RodDetectionV8`), resultado (`RodV8Result`), estados (`RodV8State`), máquina de estados da janela, validação de candidato, dead zone, suavização, clamp na tela, recuperação em 3 etapas + `TARGET_NOT_FOUND`, `requireFreshConfirmation()` (ciclo novo exige confirmação nova). |
| `core/src/main/kotlin/com/fischa/core/vision/RodWindowDetector.kt` | **Mecanismo visual compartilhado** extraído da V7 (`scan`/`refine`/`best`/`detail`/`measureBlob`, `CandidateHistory`): a V8 e a V7 usam exatamente os mesmos critérios visuais (contraste do anel, blob escuro, tamanho, histórico temporal). Isso mantém "a mesma praça de detecção" e evita duas implementações divergentes. |
| `core/src/test/kotlin/com/fischa/core/v8/V8RodDetectionTest.kt` | 30 testes: as 17 cenas obrigatórias + `TARGET_NOT_FOUND` + "nunca inventa posição" + "não toca na camada de input" + ordem dos estados + logs. |
| `core/src/test/kotlin/com/fischa/core/v8/V8PipelineIntegrationTest.kt` | 5 testes de integração: V8 como detector principal do `VisionPipeline`, trava de input, `TARGET_NOT_FOUND`, debug passivo. |
| `docs/RESULTADO_TESTES_V8.md` | Resultado da execução + mapeamento cena → teste. |

### Alterados

| Arquivo | Mudança |
|---|---|
| `core/.../config/AppConfig.kt` | `enum class RodDetectorKind { V8, V7 }`; `rodDetector` **default `V8`**; bloco `RodV8` com `initialRoiX, initialRoiY, roiWidth, roiHeight, maxMovePerFrame, deadZone, smoothing, minimumConfidence, confirmationFrames, recoveryExpansion, recoveryTimeout` (+ extras com default seguro: `lostGraceMs, targetConfirmMs, confirmWindowMs, minSizeNormalized, maxSizeNormalized, maxCandidateJump, searchStepPx, maxRefinedCandidates, minRingDelta, confidenceDecaySec`); validação, `toMap()`/`withOverrides()` para todas as chaves `rodV8.*` e `rodDetector`. |
| `core/.../pipeline/VisionPipeline.kt` | Detecta o tipo ativo (`useRodV8`); `rodV8.update(frame, fps, nowNs)` quando V8; `applyRodV8Snapshot()` mapeia o resultado para a forma que o resto do pipeline já consumia; `publishRodV8()` publica estado/ROI/centro/calibração/debug; `requireFreshRodConfirmation()` roteia para o detector ativo (entradas de `WAITING_FOR_ROD`/`CASTING`). Nenhuma mudança na decisão, no `InputSafetyGuard` ou no executor. |
| `core/.../pipeline/PipelineEvent.kt` | `PipelineOutput` ganhou os campos de debug da V8 (`rodDetector`, `rodV8TargetFound`, `rodV8TargetNotFound`, `rodV8Recovering`, `rodV8RecoveryStage`, `rodV8CandidateFound`, `rodV8CandidateConfidence`, `rodV8WindowExpanded`, `rodV8CandidateNorm`, `rodV8PreviousNorm`). |
| `core/.../debug/RenderModel.kt` | Campos equivalentes para o overlay (`rodV8WindowBox`, `rodV8CandidateNorm`, `rodV8PreviousNorm`, `rodV8TargetFound`, `rodV8TargetNotFound`, `rodV8Recovering`, `rodV8RecoveryStage`, `rodV8WindowExpanded`, `rodDetector`), todos com default → nenhuma tela quebra. |
| `app/src/main/java/com/fischa/app/DebugOverlay.kt` | Quando `rodDetector == "V8"`: desenha a **janela móvel** (ciano em tracking, laranja na recuperação), o **candidato** (cruzeta laranja), a **posição anterior** (cruzeta cinza), o **centro do alvo** (cruzeta) e a linha `V8: window=… state=… conf=… candidate=… prev=… recovery=… etapa=… expand=…`. |
| `core/.../vision/RodFinder.kt` | Refatorado para usar o `RodWindowDetector` compartilhado (comportamento idêntico, verificado pelos 13 testes da V7). Continua funcionando se `rodDetector = V7`. |
| `core/.../log/GameLog.kt` | Tag `ROD_V8`. |
| `core/src/test/.../pipeline/StartSemanticsV5Test.kt` | Passa a rodar com o detector principal (V8); o teste de confiança mínima usa `rodV8.minimumConfidence`. |
| `core/src/test/.../v7/V7RealInputLockTest.kt` | Fixa `rodDetector = V7` (a suíte verifica nomes/estados da V7; a cobertura V8 equivalente está em `V8PipelineIntegrationTest`). |
| `README.md` | Seção V8 + comandos. |

## Comportamento (o que muda na prática)

1. **Nada de busca global como método principal.** A procura acontece **dentro da janela**;
   o que não está na janela não é considerado.
2. **A janela nasce onde e do tamanho que o usuário configurou** (`initialRoiX/Y`, `roiWidth/Height`).
3. **Encontrou → segue** o alvo, mantendo-o perto do centro da janela, com `deadZone` (anti-jitter),
   `smoothing` (aproximação suave) e `maxMovePerFrame` (limite por frame).
4. **Perdeu → procura perto de onde estava** (grace → etapa 1 → etapa 2 → área inicial → etapa 3).
5. **Nada válido → `TARGET_NOT_FOUND`**, sem inventar coordenada (`targetX/targetY` ficam vazios).
6. **Ciclo novo exige confirmação nova** (`requireFreshConfirmation`) — mantém a regra da V5 de que
   o START/cast só acontece com o botão confirmado visualmente **e** com o input autorizado.
7. **A V8 nunca executa input**: ela só devolve `targetFound, targetX, targetY, confidence, state`.
