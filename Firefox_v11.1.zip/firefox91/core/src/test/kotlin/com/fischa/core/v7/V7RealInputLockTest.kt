package com.fischa.core.v7

import com.fischa.core.config.AppConfig
import com.fischa.core.config.RodDetectorKind
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.pipeline.PipelineInput
import com.fischa.core.pipeline.VisionPipeline
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.RealInputPolicy
import com.fischa.core.safety.RecordingExecutor
import com.fischa.core.safety.RobloxForegroundStatus
import com.fischa.core.vision.RodDetectionState
import com.fischa.core.vision.VisionFrame
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * V7 §10 — REAL_INPUT stays blocked through the whole detection cycle.
 *
 * This is the test that guards the acceptance criterion of the delivery: even with detection
 * *working* (candidate found, confirmed, tracked), with the macro armed and the caller asking for
 * real input, the INPUT layer must stay `DISABLED` and no gesture may reach the executor. Nothing
 * in the detection/tracking/adapter code may unlock it — there is no auto-unlock by design.
 */
class V7RealInputLockTest {

    private companion object {
        const val W = 640
        const val H = 288
    }

    /** Pipeline rig: fake clock, fake Roblox foreground, recording executor. */
    private inner class Rig {
        var nowNs = 1_000_000_000L
        var serial = 0L
        val exec = RecordingExecutor()
        val pipeline = VisionPipeline(
            // suíte da política V7 (a política V8 é coberta por core.v8)
            cfg = AppConfig().copy(rodDetector = RodDetectorKind.V7).validate(),
            executor = exec,
            log = ThrottledLog(NoopSink),
            emergency = EmergencyStop(),
            foregroundStatusProvider = {
                RobloxForegroundStatus(
                    foregroundPackage = "com.roblox.client",
                    robloxDetected = true,
                    inputAuthorized = true,
                    blockReason = "NONE",
                    timestampMs = nowNs / 1_000_000L,
                )
            },
            monotonicNowNs = { nowNs },
        )

        fun step(rod: RodSceneFixture.Rod?) {
            val frame = VisionFrame.allocate(W, H)
            RodSceneFixture.draw(frame, rod)
            frame.resetFor(nowNs, ++serial)
            frame.ensureGray()
            pipeline.onFrame(
                frame,
                PipelineInput(
                    frameTimestampNs = nowNs,
                    currentTimeNs = nowNs,
                    captureHealthy = true,
                    robloxDetected = true,
                    inputAuthorized = true,
                    macroEnabled = true,
                    // the caller *asks* for real input: the V7 lock must still refuse it
                    realInputEnabled = true,
                    foregroundPackage = "com.roblox.client",
                    foregroundBlockReason = "NONE",
                ),
            )
            nowNs += 33_000_000L
        }

        fun gestures() = exec.calls.filter { it == "tap" || it == "holdStart" || it == "holdExtend" }
    }

    @After fun keepTheLockOn() {
        RealInputPolicy.lock()
    }

    @Test
    fun detectionWorksEndToEndWhileRealInputStaysDisabled() {
        RealInputPolicy.lock()
        assertFalse("a política deve nascer travada", RealInputPolicy.allows())
        val unlocksBefore = RealInputPolicy.history().count { it.startsWith("UNLOCK") }
        val rig = Rig()
        rig.pipeline.armed = true

        var tracked = false
        repeat(40) {
            rig.step(RodSceneFixture.Rod(520, 199))
            val state = rig.pipeline.output.rodState
            if (state == RodDetectionState.TRACKING_ROD.name) tracked = true
        }

        val out = rig.pipeline.output
        // 1. the detection stack really did its job (otherwise this test proves nothing)
        assertTrue("detecção não confirmou/rastreou (state=${out.rodState} reason=${out.rodReason})",
            tracked || out.rodState == RodDetectionState.ROD_CONFIRMED.name)
        assertTrue("rodConfirmed", out.rodConfirmed)
        assertTrue("rodDetected", out.rodDetected)
        assertNotNull("calibração não publicada", out.rodCalibration)
        assertTrue("calibração deve descrever a tela", out.rodCalibration.contains("screen="))
        assertTrue("calibração concluída", out.rodCalibrationDone)

        // 2. …and yet the INPUT layer is blocked, as required for the V7 validation cycle
        assertEquals("REAL_INPUT", "DISABLED", out.layerInput)
        assertTrue("realInputLocked", out.realInputLocked)
        assertEquals("VISION", "ACTIVE", out.layerVision)
        assertEquals("DETECTION", "ACTIVE", out.layerDetection)
        assertEquals("DECISION", "ACTIVE", out.layerDecision)
        assertTrue("nenhum gesto pode chegar ao executor: ${rig.exec.calls}", rig.gestures().isEmpty())
        assertTrue("nenhuma chamada ao executor: ${rig.exec.calls}", rig.exec.calls.isEmpty())
        assertFalse("REAL_INPUT não pode ser habilitado pelo pipeline", rig.pipeline.safety.realInputEnabled)

        // 3. no automatic unlock happened anywhere along the way
        assertFalse("a política continua travada após a detecção", RealInputPolicy.allows())
        assertEquals(
            "nenhum UNLOCK novo pode aparecer durante o ciclo de detecção: ${RealInputPolicy.history()}",
            unlocksBefore, RealInputPolicy.history().count { it.startsWith("UNLOCK") },
        )
    }

    @Test
    fun rodsDisappearingAndReappearingNeverUnlocksInput() {
        RealInputPolicy.lock()
        val unlocksBefore = RealInputPolicy.history().count { it.startsWith("UNLOCK") }
        val rig = Rig()
        rig.pipeline.armed = true
        repeat(30) { rig.step(RodSceneFixture.Rod(520, 199)) }   // detect + confirm + track
        repeat(45) { rig.step(null) }                            // lose it → back to SEARCHING_ROD
        repeat(60) { rig.step(RodSceneFixture.Rod(200, 140)) }   // find it somewhere else
        val out = rig.pipeline.output
        assertTrue("deveria ter re-encontrado o botão (state=${out.rodState} reason=${out.rodReason})",
            out.rodState == RodDetectionState.TRACKING_ROD.name ||
                out.rodState == RodDetectionState.ROD_CONFIRMED.name)
        assertEquals("REAL_INPUT", "DISABLED", out.layerInput)
        assertTrue(rig.exec.calls.isEmpty())
        assertFalse(RealInputPolicy.allows())
        assertEquals(
            "detect→perde→re-encontra não pode destravar nada",
            unlocksBefore, RealInputPolicy.history().count { it.startsWith("UNLOCK") },
        )
    }

    @Test
    fun debugModelExposesTheDetectionVisualDataNormalized() {
        RealInputPolicy.lock()
        val rig = Rig()
        rig.pipeline.armed = true
        repeat(30) { rig.step(RodSceneFixture.Rod(520, 199)) }
        val model = rig.pipeline.render
        assertNotNull("render model ausente", model)
        val m = model!!
        assertTrue("rodState no debug: ${m.rodState}", m.rodState.isNotEmpty())
        assertTrue("rodScore > 0", m.rodScore > 0f)
        assertTrue("rodRequiredFrames > 0 (confirmação adaptativa)", m.rodRequiredFrames > 0)
        assertTrue("rodCalibrationDone", m.rodCalibrationDone)
        assertTrue("rodCalibration deve trazer os parâmetros principais",
            m.rodCalibration.contains("screen=") && m.rodCalibration.contains("confirmFrames="))
        assertTrue("rodCandidateDetail com candidatos", m.rodCandidateDetail.isNotEmpty())
        assertEquals("camada INPUT no debug", "DISABLED", m.layerInput)

        // the boxes the overlay draws must be normalized (0..1) and actually on the button
        val search = m.rodSearchBox
        assertNotNull("região de busca ausente no debug", search)
        assertTrue("busca normalizada", search!!.all { it in -0.01f..1.01f } && search[2] > search[0])
        val roi = m.rodRoiBox
        assertNotNull("ROI dinâmica ausente no debug", roi)
        assertTrue("ROI normalizada", roi!!.all { it in -0.01f..1.01f })
        assertTrue("ROI pequena", roi[2] - roi[0] < 0.5f)
        val box = m.rodBox
        assertNotNull("caixa do candidato ausente no debug", box)
        assertTrue("caixa normalizada", box!!.all { it in -0.01f..1.01f })
        // the candidate box must sit on the drawn button (520,199 ±30 px in a 640×288 frame)
        val cx = (box[0] + box[2]) * 0.5f * W
        val cy = (box[1] + box[3]) * 0.5f * H
        assertTrue("caixa do debug fora do botão: ($cx,$cy)", kotlin.math.hypot(cx - 520f, cy - 199f) <= 8f)
        val center = m.rodCenterNorm
        assertNotNull("centro normalizado ausente", center)
        assertTrue("centro normalizado fora da tela: ${center!![0]},${center[1]}",
            center[0] in 0f..1f && center[1] in 0f..1f)
        assertTrue("centro normalizado errado (${center[0]},${center[1]})",
            kotlin.math.hypot(center[0] * W - 520f, center[1] * H - 199f) <= 8f)
    }
}
