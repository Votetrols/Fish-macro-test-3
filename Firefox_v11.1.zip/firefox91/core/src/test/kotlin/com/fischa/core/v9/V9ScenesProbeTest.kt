package com.fischa.core.v9

import com.fischa.core.common.NormRegion
import com.fischa.core.config.AppConfig
import com.fischa.core.config.RodDetectorKind
import com.fischa.core.log.LogSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.vision.RodButtonDetectorV9
import com.fischa.core.vision.RodDetectionV9
import com.fischa.core.vision.VisionFrame
import org.junit.Test

/**
 * PROBE 3 (temporário): roda as cenas dos testes que falham e despeja frame a frame o candidato, o
 * score e os motivos de descarte. Escreve `/home/user/v9_scenes_probe.txt`.
 */
class V9ScenesProbeTest {

    private object NullSink : LogSink {
        override fun log(level: LogSink.Level, tag: String, msg: String, timestampNs: Long) {}
    }

    private class Run(
        private val outer: StringBuilder,
        val label: String,
        val w: Int,
        val h: Int,
        val fps: Float,
        val cfg: AppConfig,
    ) {
        val det = RodDetectionV9(cfg.copy(rodDetector = RodDetectorKind.V9), ThrottledLog(NullSink))
        val periodNs = (1_000_000_000.0 / fps).toLong()
        var nowNs = 1_000_000_000L
        var serial = 0L
        private val sb = outer

        fun step(button: RodSceneV9Fixture.Button?): com.fischa.core.vision.RodV9Result {
            val f = VisionFrame.allocate(w, h)
            RodSceneV9Fixture.draw(
                f,
                RodSceneV9Fixture.FrameState(wavePhase = serial * 0.7f, seed = 7L + serial),
                button = button,
                hotbar = RodSceneV9Fixture.Hotbar(y = h - 14),
            )
            f.resetFor(nowNs, ++serial)
            f.ensureGray()
            val snap = det.update(f, fps, nowNs)
            nowNs += periodNs
            val b = button
            val err = if (b != null && snap.candidateFound) {
                "%.0fpx".format(
                    Math.hypot(
                        (snap.candidatePx.x - b.cx).toDouble(),
                        (snap.candidatePx.y - b.cy).toDouble(),
                    ),
                )
            } else "-"
            val c = snap.candidateData.firstOrNull()
            val candLine = if (c == null) "" else " | c=(" + c.cx.toInt() + "," + c.cy.toInt() + ") r=" +
                "%.1f".format(c.r) + " clo=" + "%.2f".format(c.edgeClosure) +
                " al=" + "%.2f".format(c.edgeAlignment) + " rgh=" + "%.2f".format(c.profileRoughness) +
                " vm=" + "%.2f".format(c.visualMatch) + " ct=" + "%.2f".format(c.localContrast) +
                " tmp=" + "%.2f".format(c.temporalScore) + " sp=" + "%.2f".format(c.spatialScore) +
                " text=" + "%.2f".format(c.textFraction) + " tex=" + "%.2f".format(c.interiorTexture)
            sb.appendLine(
                "  f" + serial + " st=" + snap.state + " dstate=" + snap.detectorState +
                    " cand=" + snap.candidates + " score=" + "%.2f".format(snap.score) +
                    " conf=" + "%.2f".format(snap.confidence) + " found=" + snap.targetFound +
                    " nf=" + snap.targetNotFound + " req=" + snap.requiredFrames + " err=" + err +
                    candLine,
            )
            sb.appendLine("    why: " + snap.reason)
            if (snap.targetFound) sb.appendLine("    rej: " + det.detector.lastRejections.joinToString(" | "))
            if (serial <= 3L) {
                val hf = RodButtonDetectorV9::class.java.getDeclaredField("hyps").apply { isAccessible = true }
                @Suppress("UNCHECKED_CAST")
                val hs = hf.get(det.detector) as List<Any>
                for (hh in hs) {
                    val cc = hh.javaClass
                    fun ff(n: String) = cc.getDeclaredField(n).apply { isAccessible = true }.get(hh)
                    sb.appendLine("      hyp " + ff("source") + " (" + "%.1f".format(ff("cx") as Float) + "," +
                        "%.1f".format(ff("cy") as Float) + ") rM=" + "%.1f".format(ff("rMoment") as Float) +
                        " px=" + ff("pixels"))
                }
            }
            for (cc in snap.candidateData) {
                sb.appendLine(
                    "      cand seed=" + cc.seed + " c=(" + cc.cx.toInt() + "," + cc.cy.toInt() + ") r=" +
                        "%.1f".format(cc.r) + " score=" + "%.2f".format(cc.score) +
                        " vm=" + "%.2f".format(cc.visualMatch) + " ct=" + "%.2f".format(cc.localContrast) +
                        " ed=" + "%.2f".format(cc.edgeEvidence) + " fc=" + "%.2f".format(cc.regionStrength) +
                        " ru=" + "%.2f".format(cc.roundness) + " tp=" + "%.2f".format(cc.temporalScore) +
                        " sp=" + "%.2f".format(cc.spatialScore) + " tr=" + "%.2f".format(cc.trackingScore) +
                        " clo=" + "%.2f".format(cc.edgeClosure) + " al=" + "%.2f".format(cc.edgeAlignment) +
                        " rgh=" + "%.2f".format(cc.profileRoughness) + " txt=" + "%.2f".format(cc.textFraction) +
                        " tex=" + "%.2f".format(cc.interiorTexture),
                )
            }
            return snap
        }

        fun noCandidateNotes() {
            sb.appendLine("    rejections: " + det.detector.lastRejections.joinToString(" | "))
        }
    }

    private fun cfg(v9: AppConfig.RodButtonV9? = null): AppConfig {
        val base = AppConfig().validate()
        return if (v9 == null) base else base.copy(rodButtonV9 = v9)
    }

    @Test
    fun dumpScenes() {
        val sb = StringBuilder()
        val fx = 0.81f
        val fy = 0.69f

        fun header(t: String) { sb.appendLine("\n==================== $t") }

        // A) 60 FPS
        header("60 FPS, 640x288")
        run {
            val w = 640; val h = 288
            val r = Run(sb, "60fps", w, h, 60f, cfg())
            val b = RodSceneV9Fixture.buttonAt(fx, fy, w, h)
            sb.appendLine("  button c=(${b.cx},${b.cy}) r=${b.r}")
            repeat(24) { r.step(b) }
            r.noCandidateNotes()
        }

        // N) cena SEM botão (nenhum alvo pode ser publicado)
        header("SEM BOTÃO 640x288")
        run {
            val w = 640; val h = 288
            val r = Run(sb, "nobutton", w, h, 30f, cfg())
            var hits = 0
            for (i in 0 until 120) {
                val snap = r.step(null)
                if (snap.targetFound) {
                    hits++
                    sb.appendLine("    >>> ALVO FALSO no frame ${i + 1}")
                }
            }
            sb.appendLine("    >>> frames com alvo: $hits/120")
            r.noCandidateNotes()
        }

        // B) 480x216
        header("480x216")
        run {
            val w = 480; val h = 216
            val r = Run(sb, "480x216", w, h, 30f, cfg())
            val b = RodSceneV9Fixture.buttonAt(fx, fy, w, h)
            sb.appendLine("  button c=(${b.cx},${b.cy}) r=${b.r} roi=${r.det.window.describe()}")
            repeat(12) { r.step(b) }
            r.noCandidateNotes()
        }

        // C) 640x360
        header("640x360")
        run {
            val w = 640; val h = 360
            val r = Run(sb, "640x360", w, h, 30f, cfg())
            val b = RodSceneV9Fixture.buttonAt(fx, fy, w, h)
            sb.appendLine("  button c=(${b.cx},${b.cy}) r=${b.r} roi=${r.det.window.describe()}")
            repeat(12) { r.step(b) }
            r.noCandidateNotes()
        }

        // D) ROUNDED_SQUARE
        header("ROUNDED_SQUARE 640x288")
        run {
            val w = 640; val h = 288
            val r = Run(sb, "square", w, h, 30f, cfg())
            val b = RodSceneV9Fixture.buttonAt(
                fx, fy, w, h, style = RodSceneV9Fixture.ButtonStyle.ROUNDED_SQUARE,
            )
            sb.appendLine("  button c=(${b.cx},${b.cy}) r=${b.r}")
            repeat(12) { r.step(b) }
            r.noCandidateNotes()
        }

        // E) minimumConfidence 0.995 (espera candidato porém nunca confirmado)
        header("minimumConfidence=0.995")
        run {
            val w = 640; val h = 288
            val r = Run(sb, "minconf", w, h, 30f, cfg(AppConfig.RodButtonV9(minimumConfidence = 0.995f)))
            val b = RodSceneV9Fixture.buttonAt(fx, fy, w, h)
            repeat(10) { r.step(b) }
            r.noCandidateNotes()
        }

        // F) confirmationFrames = 5
        header("confirmationFrames=5")
        run {
            val w = 640; val h = 288
            val r = Run(sb, "frames5", w, h, 30f, cfg(AppConfig.RodButtonV9(confirmationFrames = 5)))
            val b = RodSceneV9Fixture.buttonAt(fx, fy, w, h)
            repeat(14) { r.step(b) }
            r.noCandidateNotes()
        }

        // G) botão parado, 45 frames (janela estável)
        header("botão parado 45 frames")
        run {
            val w = 640; val h = 288
            val r = Run(sb, "stable", w, h, 30f, cfg())
            val b = RodSceneV9Fixture.buttonAt(fx, fy, w, h)
            repeat(20) { r.step(b) }
            repeat(3) { r.step(b) }
            r.noCandidateNotes()
        }

        // H) botão deslocando
        header("botão deslocando 3px/frame")
        run {
            val w = 640; val h = 288
            val r = Run(sb, "moving", w, h, 30f, cfg())
            var b = RodSceneV9Fixture.buttonAt(0.70f, 0.66f, w, h)
            repeat(10) { r.step(b) }
            for (i in 1..12) {
                b = b.copy(cx = b.cx + 3, cy = b.cy + i / 5)
                r.step(b)
            }
            r.noCandidateNotes()
        }

        java.io.File("/home/user/v9_scenes_probe.txt").writeText(sb.toString())
    }
}
