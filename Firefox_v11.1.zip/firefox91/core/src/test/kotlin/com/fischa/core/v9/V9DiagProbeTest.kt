package com.fischa.core.v9

import com.fischa.core.config.AppConfig
import com.fischa.core.config.RodDetectorKind
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.vision.RodDetectionV9
import com.fischa.core.vision.VisionFrame
import org.junit.Test
import java.io.File

/** PROBE TEMPORÁRIO — diagnóstico de candidatos por frame. Remover ao final. */
class V9DiagProbeTest {

    private val out = StringBuilder()

    private fun dump(
        title: String,
        w: Int = 640,
        h: Int = 288,
        frames: Int = 25,
        cfg: AppConfig = AppConfig().copy(rodDetector = RodDetectorKind.V9).validate(),
        button: (Int) -> RodSceneV9Fixture.Button? = { null },
        decorate: ((VisionFrame, Int) -> Unit)? = null,
        camX: (Int) -> Int = { 0 },
    ) {
        val det = RodDetectionV9(cfg, ThrottledLog(NoopSink))
        out.append("\n=== $title (${w}x$h) ===\n")
        for (i in 0 until frames) {
            val f = VisionFrame.allocate(w, h)
            RodSceneV9Fixture.draw(
                f,
                RodSceneV9Fixture.FrameState(
                    wavePhase = i * 0.7f, seed = 7L + i, cameraX = camX(i),
                ),
                button = button(i),
                hotbar = RodSceneV9Fixture.Hotbar(y = h - 14),
            )
            decorate?.invoke(f, i)
            val nowNs = 1_000_000_000L + i * 33_000_000L
            f.resetFor(nowNs, i.toLong())
            f.ensureGray()
            val r = det.update(f, 30f, nowNs)
            out.append(
                ("f%-3d state=%-11s dstate=%-10s found=%d notFound=%d streak=%d/%d cands=%d rej=%d conf=%.2f " +
                    "roi=(%.0f,%.0f)->(%.0f,%.0f) stage=%d | %s\n").format(
                    i, r.state, r.detectorState, if (r.targetFound) 1 else 0, if (r.targetNotFound) 1 else 0,
                    r.confirmation, r.requiredFrames, r.candidates, r.rejections, r.confidence,
                    r.roi.left * w, r.roi.top * h, r.roi.right * w, r.roi.bottom * h, r.recoveryStage, r.reason,
                ),
            )
            if (r.candidates == 0 && r.rejectionNotes.isNotEmpty()) {
                out.append("      descartes: ${r.rejectionNotes.joinToString(" | ")}\n")
            }
            for ((k, c) in r.candidateData.withIndex()) {
                if (k >= 3) break
                out.append(
                    ("      #%d c=(%.0f,%.0f) r=%.1f sc=%.3f seed=%s vm=%.2f ct=%.2f ed=%.2f fc=%.2f ru=%.2f " +
                        "tp=%.2f sp=%.2f tr=%.2f tex=%.2f clo=%.2f al=%.2f rough=%.2f text=%.3f stable=%d\n").format(
                        k, c.cx, c.cy, c.r, c.score, c.seed, c.visualMatch, c.localContrast, c.edgeEvidence,
                        c.regionStrength, c.roundness, c.temporalScore, c.spatialScore, c.trackingScore,
                        c.texture, c.edgeClosure, c.edgeAlignment, c.profileRoughness, c.textFraction,
                        c.stableFrames,
                    ),
                )
            }
        }
    }

    @Test
    fun probe() {
        dump("SEM BOTÃO (cena de jogo)", frames = 30)
        dump(
            title = "PROMPT SHAKE", frames = 30,
            decorate = { f, _ ->
                RodSceneV9Fixture.draw(
                    f,
                    shake = RodSceneV9Fixture.ShakePrompt(
                        cx = (f.width * 0.81f).toInt(), cy = (f.height * 0.69f).toInt(),
                    ),
                )
            },
        )
        dump(
            title = "BOTÃO MOVENDO 8px/frame", frames = 20,
            button = { i ->
                val b = RodSceneV9Fixture.buttonAt(0.70f, 0.66f, 640, 288)
                b.copy(cx = b.cx + i * 8, cy = b.cy + (i % 3) * 4)
            },
        )
        dump("BOTÃO PARADO 0.81/0.69", frames = 20, button = { _ ->
            RodSceneV9Fixture.buttonAt(0.81f, 0.69f, 640, 288)
        })
        dump("BOTÃO CLARO 0.81/0.69", frames = 20, button = { _ ->
            RodSceneV9Fixture.buttonAt(0.81f, 0.69f, 640, 288, style = RodSceneV9Fixture.ButtonStyle.LIGHT_BUTTON)
        })
        dump("BOTÃO 480x216", w = 480, h = 216, frames = 20, button = { _ ->
            RodSceneV9Fixture.buttonAt(0.81f, 0.69f, 480, 216)
        })
        dump("SEM BOTÃO 480x216", w = 480, h = 216, frames = 30)
        dump(
            "BOTÃO NA BORDA (canto inferior direito)", frames = 25,
            cfg = AppConfig().copy(
                rodDetector = RodDetectorKind.V9,
                rodButtonV9 = AppConfig.RodButtonV9(
                    initialRoiX = 0.60f, initialRoiY = 0.52f, roiWidth = 0.36f, roiHeight = 0.42f,
                ),
            ).validate(),
            button = { _ ->
                RodSceneV9Fixture.Button(cx = 640 - 30 - 3, cy = 288 - 30 - 3, r = 30)
            },
        )
        File("/home/user/v9_diag.txt").writeText(out.toString())
    }
}
