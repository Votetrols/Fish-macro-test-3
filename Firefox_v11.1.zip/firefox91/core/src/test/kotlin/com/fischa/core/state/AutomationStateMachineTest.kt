package com.fischa.core.state

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * V9.1 §3/§4/§5/§14/§16 — máquina de estados da **automação**.
 *
 * Cobre, sem depender de Android: o fluxo `APP_IDLE → APP_READY → FISHING_ACTIVE → STOPPING →
 * APP_READY`, a proibição de dois ciclos simultâneos, STOP repetido idempotente, START FISHING
 * recusado durante o STOPPING, perda de infraestrutura e os textos do botão flutuante.
 */
class AutomationStateMachineTest {

    private var now = 1_000_000_000L
    private fun machine() = AutomationStateMachine(clockNs = { now })
    private fun tick() { now += 33_000_000L }

    private fun ready(m: AutomationStateMachine): AutomationStateMachine {
        m.setInfrastructureReady(true, "captura RUNNING", now); tick()
        return m
    }

    // ---- 1/2: START principal leva a READY e NÃO pesca ----------------------------------

    @Test fun mainStartLeadsToReadyAndNeverStartsFishing() {
        val m = machine()
        assertEquals("estado inicial", AutomationState.APP_IDLE, m.state)
        assertFalse("APP_IDLE não pode rodar automação", m.pumping)
        val change = m.setInfrastructureReady(true, "captura RUNNING", now)
        assertNotNull("START principal precisa publicar a transição", change)
        assertEquals(AutomationEvent.INFRASTRUCTURE_READY, change!!.event)
        assertEquals(AutomationState.APP_READY, m.state)
        assertEquals("READY", m.state.label)
        assertTrue(m.ready)
        assertFalse("READY não é FISHING_ACTIVE", m.pumping)
        assertEquals("AUTOMATION: READY", m.debugLine)
    }

    @Test fun readyIsAStableRestingStateAndRepeatedMainStartIsHarmless() {
        val m = ready(machine())
        assertNull("publicar READY de novo não muda nada", m.setInfrastructureReady(true, "captura RUNNING", now))
        assertEquals(AutomationState.APP_READY, m.state)
        assertFalse(m.pumping)
    }

    // ---- 3: START FISHING → FISHING_ACTIVE ----------------------------------------------

    @Test fun startFishingMovesReadyToActive() {
        val m = ready(machine())
        val change = m.startFishing("START FISHING", now)
        assertNotNull(change)
        assertEquals(AutomationEvent.START_FISHING_REQUESTED, change!!.event)
        assertEquals(AutomationState.APP_READY, change.from)
        assertEquals(AutomationState.FISHING_ACTIVE, change.to)
        assertTrue("somente ACTIVE executa automação", m.pumping)
        assertEquals("AUTOMATION: ACTIVE", m.debugLine)
    }

    // ---- 4: o botão muda de texto conforme o estado --------------------------------------

    @Test fun floatingButtonLabelsFollowTheState() {
        assertEquals("START FISHING", AutomationUi.buttonLabel(AutomationState.APP_READY))
        assertEquals("STOP", AutomationUi.buttonLabel(AutomationState.FISHING_ACTIVE))
        assertEquals("STOPPING", AutomationUi.buttonLabel(AutomationState.FISHING_STOPPING))
        assertEquals("", AutomationUi.buttonLabel(AutomationState.APP_IDLE))
        assertFalse("sem READY não existe botão de pesca", AutomationUi.buttonVisible(AutomationState.APP_IDLE))
        assertTrue(AutomationUi.buttonVisible(AutomationState.APP_READY))
        assertTrue(AutomationUi.buttonVisible(AutomationState.FISHING_ACTIVE))
        assertFalse("durante o STOP o botão não aceita um 2º comando",
            AutomationUi.buttonEnabled(AutomationState.FISHING_STOPPING))
        assertEquals("AUTOMATION: OFF", AutomationUi.debugLine(AutomationState.APP_IDLE))
        assertEquals("AUTOMATION: STOPPING", AutomationUi.debugLine(AutomationState.FISHING_STOPPING))
    }

    // ---- 5/6: STOP → STOPPING → READY ----------------------------------------------------

    @Test fun stopGoesThroughStoppingAndOnlyFinishesWhenCleanupCompletes() {
        val m = ready(machine())
        m.startFishing("START FISHING", now); tick()
        val stopping = m.requestStop("STOP", now)
        assertNotNull(stopping)
        assertEquals(AutomationEvent.STOP_REQUESTED, stopping!!.event)
        assertEquals(AutomationState.FISHING_STOPPING, m.state)
        assertFalse("STOPPING não executa automação", m.pumping)
        // Enquanto a limpeza não termina, o sistema fica em STOPPING — e STOPPING não executa
        // automação. A conclusão é um EVENTO do host (limpeza terminou), nunca um timer interno:
        // `completeStop` pode ser chamado imediatamente, com o relógio do chamador.
        assertFalse("STOPPING nunca autoriza automação", m.pumping)
        val done = m.completeStop("limpeza concluída", now)
        assertNotNull(done)
        assertEquals(AutomationEvent.STOP_COMPLETED, done!!.event)
        assertEquals(AutomationState.APP_READY, m.state)
        assertTrue("a infraestrutura continua pronta", m.ready)
        assertFalse(m.pumping)
    }

    @Test fun stopRepeatedStartRequestedDuringStoppingAndStrayEventsAreSafe() {
        val m = ready(machine())
        m.startFishing(); tick()
        assertNotNull(m.requestStop("STOP", now))
        assertNull("STOP repetido é no-op", m.requestStop("STOP", now))
        assertNull("START FISHING durante o STOPPING é recusado (o STOP vence)", m.startFishing("START FISHING", now))
        assertEquals(AutomationState.FISHING_STOPPING, m.state)
        assertNull("STOP em READY é no-op", ready(machine()).requestStop("STOP", now))
        assertNull("START em APP_IDLE não passa por STOPPING", machine().completeStop("nada a concluir", now))
    }

    // ---- 7/9: nenhum ciclo duplicado ------------------------------------------------------

    @Test fun startFishingTwiceDoesNotCreateASecondCycle() {
        val m = ready(machine())
        assertNotNull(m.startFishing("START FISHING", now))
        val firstAt = m.lastChange!!.timestampNs
        val second = m.startFishing("START FISHING", now)
        assertNull("pedido repetido não cria outro ciclo", second)
        assertEquals(AutomationState.FISHING_ACTIVE, m.state)
        assertEquals("nenhuma transição nova foi publicada", firstAt, m.lastChange!!.timestampNs)
    }

    @Test fun everyTransitionIsPublishedExactlyOnce() {
        val m = ready(machine())
        val seen = ArrayList<String>()
        val listener: (AutomationChange) -> Unit = { seen.add("${it.from.name}->${it.to.name}:${it.event.name}") }
        m.addListener(listener)
        m.startFishing(); tick()
        m.requestStop(); tick()
        m.completeStop(); tick()
        assertEquals(
            listOf(
                "APP_READY->FISHING_ACTIVE:START_FISHING_REQUESTED",
                "FISHING_ACTIVE->FISHING_STOPPING:STOP_REQUESTED",
                "FISHING_STOPPING->APP_READY:STOP_COMPLETED",
            ),
            seen,
        )
        m.removeListener(listener)
        assertEquals("o listener não pode continuar registrado", 3, seen.size)
    }

    // ---- 8: START FISHING depois do STOP funciona de novo ---------------------------------

    @Test fun startFishingWorksAgainAfterACompleteStop() {
        val m = ready(machine())
        repeat(3) {
            assertNotNull("ciclo $it não começou", m.startFishing("START FISHING", now)); tick()
            assertTrue(m.pumping)
            assertNotNull(m.requestStop("STOP", now)); tick()
            assertNotNull(m.completeStop("limpeza concluída", now)); tick()
            assertEquals(AutomationState.APP_READY, m.state)
            assertFalse(m.pumping)
        }
    }

    // ---- infraestrutura perdida / emergência ----------------------------------------------

    @Test fun lostInfrastructureDropsBackToIdleFromAnyState() {
        val active = ready(machine())
        active.startFishing()
        val change = active.setInfrastructureReady(false, "MediaProjection encerrada", now)
        assertNotNull(change)
        assertEquals(AutomationEvent.INFRASTRUCTURE_LOST, change!!.event)
        assertEquals(AutomationState.APP_IDLE, active.state)
        assertFalse(active.pumping)

        val idle = machine()
        assertNull("já em IDLE: nada a mudar", idle.setInfrastructureReady(false, "nada ligado", now))
        assertEquals(AutomationState.APP_IDLE, idle.state)

        val stopping = ready(machine())
        stopping.startFishing(); stopping.requestStop()
        assertEquals(AutomationState.FISHING_STOPPING, stopping.state)
        stopping.emergency("EMERGENCY STOP", now)
        assertEquals(AutomationState.APP_IDLE, stopping.state)
    }

    @Test fun emergencyFromIdleIsANoOp() {
        val m = machine()
        assertNull(m.emergency("EMERGENCY STOP", now))
        assertEquals(AutomationState.APP_IDLE, m.state)
    }

    // ---- compatibilidade do host legado ----------------------------------------------------

    @Test fun startFromIdleAssumesReadyExplicitlyLogged() {
        val m = machine()
        val changes = ArrayList<AutomationChange>()
        m.addListener { changes.add(it) }
        assertNotNull(m.startFishing("START FISHING", now))
        assertEquals(2, changes.size)
        assertEquals(AutomationState.APP_IDLE, changes[0].from)
        assertEquals(AutomationState.APP_READY, changes[0].to)
        assertTrue("passo intermediário registrado com motivo", changes[0].reason.contains("READY assumido"))
        assertEquals(AutomationState.FISHING_ACTIVE, changes[1].to)
    }
}
