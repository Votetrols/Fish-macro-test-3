package com.fischa.core.v9

import com.fischa.core.config.AppConfig
import com.fischa.core.config.RodDetectorKind
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.pipeline.PipelineInput
import com.fischa.core.pipeline.VisionPipeline
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.RealInputPolicy
import com.fischa.core.safety.RecordingExecutor
import com.fischa.core.safety.RobloxForegroundStatus
import com.fischa.core.vision.MemoryRodDiagnostics
import com.fischa.core.vision.RodDiagEvent
import com.fischa.core.vision.VisionFrame
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.hypot

/**
 * V9 §13/§14 — o detector V9 dentro do pipeline real.
 *
 * Verifica o que a suíte do detector sozinha não vê:
 *
 *  * `VisionPipeline` usa a V9 como detector **principal** por default
 *    (`AppConfig().validate().rodDetector == V9`) e encaminha
 *    `targetFound/targetX/targetY/confidence/state` para a camada de decisão;
 *  * a cadeia é `VisionPipeline → RodDetectionV9 → RodButtonDetectorV9` (nada de V8/V7 escondido);
 *  * o caminho de input é intocado: com `REAL_INPUT` travado nenhum gesto chega ao executor, e
 *    com ele liberado os gestos vêm da camada de segurança/executor — o detector V9 não tem
 *    código de input;
 *  * sem candidato válido o pipeline publica `TARGET_NOT_FOUND` e **nenhuma coordenada falsa**;
 *  * o debug §8 é passivo: ler (ou não) o overlay nunca muda a sequência de detecção;
 *  * os frames de diagnóstico §9 chegam ao sink através do pipeline.
 */
class V9PipelineIntegrationTest {

    private companion object {
        const val W = 640
        const val H = 288
        const val BUTTON_FX = 0.81f
        const val BUTTON_FY = 0.69f
    }

    private inner class Rig(cfg: AppConfig = AppConfig().validate()) {
        var nowNs = 1_000_000_000L
        var serial = 0L
        val exec = RecordingExecutor()
        val diag = MemoryRodDiagnostics(48)
        val pipeline = VisionPipeline(
            cfg = cfg,
            executor = exec,
            log = ThrottledLog(NoopSink),
            emergency = EmergencyStop(),
            foregroundStatusProvider = {
                RobloxForegroundStatus(
                    foregroundPackage = "com.roblox.client",
                    robloxDetected = true,
                    inputAuthorized = true,
                    blockReason = "NONE",
                    timestampMs = nowNs / 1_000_000L,
                )
            },
            monotonicNowNs = { nowNs },
        ).also { it.rodDiagnostics = diag }

        val states = ArrayList<String>()

        fun step(button: RodSceneV9Fixture.Button?, readRender: Boolean = true): Unit {
            val frame = VisionFrame.allocate(W, H)
            RodSceneV9Fixture.draw(
                frame,
                state = RodSceneV9Fixture.FrameState(wavePhase = serial * 0.3f, seed = 7L + serial),
                button = button,
            )
            frame.resetFor(nowNs, ++serial)
            frame.ensureGray()
            pipeline.onFrame(
                frame,
                PipelineInput(
                    frameTimestampNs = nowNs,
                    currentTimeNs = nowNs,
                    captureHealthy = true,
                    robloxDetected = true,
                    inputAuthorized = true,
                    macroEnabled = true,
                    realInputEnabled = true,
                    foregroundPackage = "com.roblox.client",
                    foregroundBlockReason = "NONE",
                ),
            )
            states.add(pipeline.output.state.name)
            if (readRender) pipeline.render?.rodState
            nowNs += 33_000_000L
        }

        fun button() = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, W, H)

        /** gestos de verdade (tap/hold) — `cancelAll`/`releaseAll` são limpeza, não input. */
        fun gestures() = exec.calls.filter { it == "tap" || it == "holdStart" || it == "holdExtend" }
    }

    @After
    fun keepTheLockOn() {
        RealInputPolicy.lock()
    }

    // ---- §13: a V9 é o detector principal e o pipeline publica o resultado dela ---------------

    @Test
    fun visionPipelineUsesV9AsTheMainDetectorAndPublishesItsResults() {
        RealInputPolicy.lock()
        assertEquals(
            "o default precisa ser a V9 (spec §13)",
            RodDetectorKind.V9,
            AppConfig().rodDetector,
        )
        val rig = Rig()
        rig.pipeline.armed = true
        val button = rig.button()
        repeat(30) { rig.step(button) }
        val out = rig.pipeline.output

        assertEquals("detector publicado", "V9", out.rodDetector)
        assertEquals("estado publicado pela V9", "TRACKING", out.rodState)
        assertTrue("targetFound chegou ao pipeline", out.rodV8TargetFound)
        assertTrue("rodDetected (botão visível)", out.rodDetected)
        assertTrue("rodConfirmed (porteira temporal)", out.rodConfirmed)
        val cx = out.rodCenterNorm[0] * W
        val cy = out.rodCenterNorm[1] * H
        val d = hypot(cx - button.cx, cy - button.cy)
        assertTrue("centro publicado ($cx,$cy) longe do botão (${button.cx},${button.cy})", d <= button.r * 0.9f)
        // §8: o debug da V9 está publicado (e não é necessário ligar nada para detectar)
        assertTrue("lista de candidatos vazia no debug", out.rodV9CandidateCount > 0)
        assertTrue("estado visual do detector ausente", out.rodV9DetectorState.isNotEmpty())
        assertTrue("texto de debug da V9 vazio", out.rodV9DebugText.isNotEmpty())
        assertTrue("lastKnownTarget não publicado", out.rodV9HasLastKnown)
        assertNotNull("a janela precisa ser publicada", rig.pipeline.render?.rodV8WindowBox)
    }

    @Test
    fun showDetectionDebugOnlyChangesWhatIsPublished() {
        // SHOW_DETECTION_DEBUG=false não pode mudar a detecção — só o que o overlay desenha
        val cfgOn = AppConfig().copy(
            rodButtonV9 = AppConfig.RodButtonV9(showDetectionDebug = true),
        ).validate()
        val cfgOff = AppConfig().copy(
            rodButtonV9 = AppConfig.RodButtonV9(showDetectionDebug = false),
        ).validate()
        val a = Rig(cfgOn)
        val b = Rig(cfgOff)
        a.pipeline.armed = true
        b.pipeline.armed = true
        repeat(25) {
            a.step(a.button())
            b.step(b.button())
        }
        assertEquals("a detecção mudou por causa do debug", a.pipeline.output.rodState, b.pipeline.output.rodState)
        assertEquals(a.pipeline.output.rodV9CandidateCount, b.pipeline.output.rodV9CandidateCount)
        assertEquals(false, b.pipeline.output.rodV9ShowDetectionDebug)
        assertEquals(true, a.pipeline.output.rodV9ShowDetectionDebug)
    }

    // ---- §10/§14: sem evidência ⇒ TARGET_NOT_FOUND e nenhuma coordenada -----------------------

    @Test
    fun withoutEvidenceThePipelinePublishesTargetNotFoundAndNoCoordinates() {
        RealInputPolicy.lock()
        val rig = Rig()
        rig.pipeline.armed = true
        repeat(120) { rig.step(null) }
        val out = rig.pipeline.output
        assertFalse("publicou alvo sem evidência", out.rodV8TargetFound)
        assertFalse("confirmou sem evidência", out.rodConfirmed)
        assertFalse("detectou botão sem botão na cena", out.rodDetected)
        assertEquals("centro publicado sem alvo", 0f, out.rodCenterNorm[0], 1e-6f)
        assertEquals("centro publicado sem alvo", 0f, out.rodCenterNorm[1], 1e-6f)
        assertTrue(
            "TARGET_NOT_FOUND não foi publicado (estado=${out.rodState} reason=${out.rodReason})",
            out.rodV8TargetNotFound,
        )
    }

    // ---- §10: a camada de input continua sendo a única a executar -----------------------------

    @Test
    fun v9NeverSendsInputEvenWithDetectionWorkingAndRealInputRequested() {
        RealInputPolicy.lock()
        val rig = Rig()
        rig.pipeline.armed = true
        val button = rig.button()
        repeat(40) { rig.step(button) }
        assertTrue("a detecção precisa estar funcionando para o teste valer", rig.pipeline.output.rodConfirmed)
        assertEquals("o detector V9 executou input", 0, rig.gestures().size)
        assertEquals("INPUT precisa continuar DISABLED", "DISABLED", rig.pipeline.output.layerInput)
        assertFalse("RealInputPolicy foi destravada", RealInputPolicy.allows())
    }

    // ---- §9: os frames de diagnóstico passam pelo pipeline ------------------------------------

    @Test
    fun pipelineForwardsDiagnosticFramesToTheSink() {
        val rig = Rig()
        rig.pipeline.armed = true
        val button = rig.button()
        repeat(20) { rig.step(button) }
        assertTrue("sem frames de diagnóstico de candidato", rig.diag.count(RodDiagEvent.CANDIDATE_FOUND) > 0)
        assertTrue("sem frames de diagnóstico de confirmação", rig.diag.count(RodDiagEvent.CONFIRMED) > 0)
        repeat(120) { rig.step(null) }
        assertTrue("sem frames de 'nenhum candidato'", rig.diag.count(RodDiagEvent.NO_CANDIDATE) > 0)
        assertTrue("sem frames de TARGET_NOT_FOUND", rig.diag.count(RodDiagEvent.TARGET_NOT_FOUND) > 0)
    }

    // ---- §12: template do usuário via pipeline -----------------------------------------------

    @Test
    fun pipelineAcceptsTheUserTemplate() {
        val rig = Rig()
        rig.pipeline.armed = true
        val button = rig.button()
        val frame = VisionFrame.allocate(W, H)
        RodSceneV9Fixture.draw(frame, button = button)
        frame.ensureGray()
        val json = com.fischa.core.vision.RodTemplateV9
            .extract(frame, button.cx, button.cy, button.r.toFloat())
            .toJson()
        assertTrue("o pipeline recusou o template", rig.pipeline.setRodTemplate(json))
        repeat(25) { rig.step(button) }
        assertTrue("não detectou com template carregado", rig.pipeline.output.rodConfirmed)
        val out = rig.pipeline.output
        val d = hypot(out.rodCenterNorm[0] * W - button.cx, out.rodCenterNorm[1] * H - button.cy)
        assertTrue("centro com template longe do botão: $d", d <= button.r)
    }

    // ---- §1: a janela móvel continua sendo a mesma arquitetura --------------------------------

    @Test
    fun movingWindowKeepsTrackingAndNeverLeavesTheScreen() {
        RealInputPolicy.lock()
        val rig = Rig()
        rig.pipeline.armed = true
        val start = rig.button()
        var moved = false
        for (i in 0..40) {
            val b = start.copy(cx = start.cx - i * 2)
            rig.step(b)
            val wnd = rig.pipeline.render?.rodV8WindowBox ?: continue
            assertTrue(
                "janela fora da tela no frame $i: ${wnd.toList()}",
                wnd[0] >= -1e-4f && wnd[1] >= -1e-4f && wnd[2] <= 1f + 1e-4f && wnd[3] <= 1f + 1e-4f,
            )
            if (wnd[0] < (AppConfig().rodButtonV9.initialRoiX) - 0.02f) moved = true
        }
        assertTrue("a janela não seguiu o botão (não se deslocou)", moved)
        assertTrue("perdeu o alvo durante o deslocamento", rig.pipeline.output.rodConfirmed)
    }
}
