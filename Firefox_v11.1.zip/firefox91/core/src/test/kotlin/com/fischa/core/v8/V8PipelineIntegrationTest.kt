package com.fischa.core.v8

import com.fischa.core.config.AppConfig
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.pipeline.PipelineInput
import com.fischa.core.pipeline.VisionPipeline
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.RealInputPolicy
import com.fischa.core.safety.RecordingExecutor
import com.fischa.core.safety.RobloxForegroundStatus
import com.fischa.core.state.FishingState
import com.fischa.core.v7.RodSceneFixture
import com.fischa.core.vision.VisionFrame
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Rod Detection V8 §17/§18/§21 — the moving-window detector plugged into the real pipeline.
 *
 * What is verified here (things the detector-only suite cannot see):
 *  * `VisionPipeline` really uses V8 as the **main** detector (`AppConfig().validate()` default) and
 *    forwards `targetFound/targetX/targetY/confidence/state` to the decision layer;
 *  * the input path is untouched: with REAL_INPUT locked no gesture ever reaches the executor, and
 *    with it unlocked the gestures come from the safety/executor path (V8 itself has no input code);
 *  * when there is no valid candidate the pipeline publishes `TARGET_NOT_FOUND` and **no fabricated
 *    coordinate** — the target fields stay empty instead of pointing somewhere;
 *  * the §16 debug visualization is a passive, per-frame snapshot: reading it (or not) never changes
 *    the detection sequence.
 */
class V8PipelineIntegrationTest {

    private companion object {
        const val W = 640
        const val H = 288
        /** the synthetic rod button of [RodSceneFixture], in pixels */
        const val ROD_X = 520
        const val ROD_Y = 199
    }

    /** Pipeline rig: fake clock, fake Roblox foreground, recording executor, V8 by default. */
    private inner class Rig {
        var nowNs = 1_000_000_000L
        var serial = 0L
        val exec = RecordingExecutor()
        val pipeline = VisionPipeline(
            // V9 §13: o detector principal do projeto passou a ser a V9 (`rodButtonV9`); esta
            // suíte continua validando a V8 **quando ela é selecionada explicitamente**, que é o
            // que garante que a política de janela da V8 segue intacta depois da V9.
            cfg = AppConfig().copy(rodDetector = com.fischa.core.config.RodDetectorKind.V8).validate(),
            executor = exec,
            log = ThrottledLog(NoopSink),
            emergency = EmergencyStop(),
            foregroundStatusProvider = {
                RobloxForegroundStatus(
                    foregroundPackage = "com.roblox.client",
                    robloxDetected = true,
                    inputAuthorized = true,
                    blockReason = "NONE",
                    timestampMs = nowNs / 1_000_000L,
                )
            },
            monotonicNowNs = { nowNs },
        )

        val states = ArrayList<String>()

        fun step(rod: RodSceneFixture.Rod?) {
            val frame = VisionFrame.allocate(W, H)
            RodSceneFixture.draw(frame, rod)
            frame.resetFor(nowNs, ++serial)
            frame.ensureGray()
            pipeline.onFrame(
                frame,
                PipelineInput(
                    frameTimestampNs = nowNs,
                    currentTimeNs = nowNs,
                    captureHealthy = true,
                    robloxDetected = true,
                    inputAuthorized = true,
                    macroEnabled = true,
                    realInputEnabled = true,
                    foregroundPackage = "com.roblox.client",
                    foregroundBlockReason = "NONE",
                ),
            )
            states.add(pipeline.output.state.name)
            nowNs += 33_000_000L
        }

        fun rod() = RodSceneFixture.Rod(ROD_X, ROD_Y)

        /** gestos de verdade (tap/hold) — `cancelAll`/`releaseAll` são limpeza, não input. */
        fun gestures() = exec.calls.filter { it == "tap" || it == "holdStart" || it == "holdExtend" }
    }

    @After fun keepTheLockOn() {
        RealInputPolicy.lock()
    }

    // ---- §18/§21: the pipeline consumes V8 and republishes its result ------------------------

    @Test
    fun visionPipelineUsesV8AsTheMainDetectorAndPublishesItsResults() {
        RealInputPolicy.lock()
        val rig = Rig()
        rig.pipeline.armed = true
        repeat(30) { rig.step(rig.rod()) }
        val out = rig.pipeline.output

        assertEquals("com rodDetector=V8 a V8 precisa ser o detector usado", "V8", out.rodDetector)
        assertEquals("estado publicado pela V8", "TRACKING", out.rodState)
        assertTrue("targetFound chegou ao pipeline", out.rodV8TargetFound)
        assertTrue("rodDetected (botão visível)", out.rodDetected)
        assertTrue("rodConfirmed (gate temporal)", out.rodConfirmed)
        assertTrue("alvo publicado como centro", out.rodCenterNorm[0] > 0f && out.rodCenterNorm[1] > 0f)
        // o centro publicado é o centro do botão dentro do frame (520,199 de 640x288)
        assertEquals("centro X normalizado", ROD_X.toFloat() / W, out.rodCenterNorm[0], 0.02f)
        assertEquals("centro Y normalizado", ROD_Y.toFloat() / H, out.rodCenterNorm[1], 0.02f)
        assertTrue("candidato publicado", out.rodV8CandidateNorm[0] * W > 400f)
        assertTrue("confiança medida", out.rodV8CandidateConfidence > 0.5f)
        assertTrue("parâmetros da V8 expostos no debug", out.rodCalibration.contains("janela="))
        assertTrue("detalhe do candidato", out.rodCandidateDetail.isNotEmpty())
        // a janela publicada corresponde ao ROI configurado (0.32 x 0.36 do frame)
        val roi = out.rodRoiNorm
        assertNotNull("janela publicada", roi)
        assertEquals("largura da janela", 0.32f, roi!![2] - roi[0], 0.02f)
        assertEquals("altura da janela", 0.36f, roi[3] - roi[1], 0.02f)
    }

    // ---- §17: the detector never drives input; the macro only runs through the safety path ----

    @Test
    fun detectionCycleRunsEndToEndWhileNoInputReachesTheExecutor() {
        RealInputPolicy.lock()
        assertFalse("política nasce travada", RealInputPolicy.allows())
        val unlocksBefore = RealInputPolicy.history().count { it.startsWith("UNLOCK") }
        val rig = Rig()
        rig.pipeline.armed = true
        repeat(60) { rig.step(rig.rod()) }

        val out = rig.pipeline.output
        // a detecção trabalha, mas com o input travado o cast NUNCA é autorizado (é o objetivo do
        // lock): o robô fica observando o botão confirmado.
        assertTrue("o rod foi rastreado (${out.rodState})", out.rodState == "TRACKING")
        assertTrue(
            "com o input travado o ciclo não pode sair de WAITING_FOR_ROD: ${rig.states.distinct()}",
            rig.states.all { it == FishingState.WAITING_FOR_ROD.name },
        )
        assertFalse("castAuthorized exige o input liberado", out.castAuthorized)
        assertTrue("o motivo vem do guard: ${out.castGateReason}", out.castGateReason.isNotEmpty())
        // 1. a detecção funcionou … e ainda assim nada chegou ao executor
        assertTrue("nenhum gesto pode chegar ao executor: ${rig.exec.calls}", rig.gestures().isEmpty())
        assertTrue("nenhum hold chega ao executor: ${rig.exec.calls}",
            rig.exec.calls.none { it.startsWith("hold") || it.startsWith("tap") })
        assertEquals("camada INPUT travada no debug", "DISABLED", out.layerInput)
        assertTrue("output marca o lock", out.realInputLocked)
        assertFalse("o pipeline não destrava a política", rig.pipeline.safety.realInputEnabled)
        // 2. e nenhum UNLOCK apareceu no caminho
        assertEquals(
            "detecção não pode destravar o input: ${RealInputPolicy.history()}",
            unlocksBefore, RealInputPolicy.history().count { it.startsWith("UNLOCK") },
        )
        assertEquals("camadas de visão/decim/ção intactas", "ACTIVE", out.layerVision)
        assertEquals("ACTIVE", out.layerDetection)
    }

    @Test
    fun unlockedTheGesturesComeFromTheSafetyPathNotFromTheDetector() {
        // same scene, real input released for the duration of the test: the pipeline is the only
        // producer of gestures (V8 has none — see detectorNeverImportsOrCallsTheInputLayer)
        RealInputPolicy.unlockForTesting("V8PipelineIntegrationTest: caminho guard→executor")
        val rig = Rig()
        rig.pipeline.armed = true
        // holdMs default = 3000 ms; ~33 ms por frame ⇒ o release só sai depois de ~90 frames
        repeat(140) { rig.step(rig.rod()) }
        assertTrue("o ciclo chegou ao cast (${rig.states.distinct()})",
            rig.states.contains(FishingState.CASTING.name))
        assertTrue("cast iniciado pelo caminho guard→executor: ${rig.exec.calls.take(4)}",
            rig.exec.calls.contains("holdStart"))
        assertTrue("cast liberado pelo caminho guard→executor: ${rig.exec.calls.takeLast(4)}",
            rig.exec.calls.contains("holdRelease"))
        // as coordenadas do gesto são as do alvo detectado (nenhuma invenção de posição)
        val out = rig.pipeline.output
        assertEquals("centro X", ROD_X.toFloat() / W, out.rodCenterNorm[0], 0.03f)
        assertEquals("centro Y", ROD_Y.toFloat() / H, out.rodCenterNorm[1], 0.03f)
    }

    // ---- §7/§8/§17: nothing found → TARGET_NOT_FOUND, never an invented coordinate -------------

    @Test
    fun emptyScenePublishesTargetNotFoundAndNeverFabricatesCoordinates() {
        RealInputPolicy.lock()
        val rig = Rig()
        rig.pipeline.armed = true
        var sawExpanded = false
        var sawExhausted = false
        repeat(160) {
            rig.step(null)
            val out = rig.pipeline.output
            assertFalse("não pode confirmar em cena vazia ($it)", out.rodConfirmed)
            assertFalse("candidato não pode ser publicado ($it)", out.rodDetected)
            // nenhuma coordenada inventada: o alvo simplesmente não existe
            assertEquals("rodCenterNorm X intocado ($it)", 0f, out.rodCenterNorm[0], 0f)
            assertEquals("rodCenterNorm Y intocado ($it)", 0f, out.rodCenterNorm[1], 0f)
            val debugModel = rig.pipeline.render
            assertNotNull("model de debug publicado ($it)", debugModel)
            assertNull("candidato ausente no debug ($it)", debugModel?.rodV8CandidateNorm)
            val roi = out.rodRoiNorm
            assertNotNull("a janela continua publicada ($it)", roi)
            assertTrue(
                "a janela fica dentro da tela ($it): ${roi!!.joinToString()}",
                roi[0] >= -0.001f && roi[1] >= -0.001f && roi[2] <= 1.001f && roi[3] <= 1.001f,
            )
            if (out.rodV8WindowExpanded) sawExpanded = true
            if (out.rodV8TargetNotFound) sawExhausted = true
        }
        assertTrue("a janela precisa expandir na recuperação (§7)", sawExpanded)
        assertTrue("orçamento de recuperação esgotado → TARGET_NOT_FOUND (§7)", sawExhausted)
        // o detector responde TARGET_NOT_FOUND pelo campo próprio (`targetNotFound`) enquanto varre
        // a área inicial; o estado continua RECOVERING — nunca inventando coordenada
        val last = rig.pipeline.output
        assertTrue("a resposta final precisa ser TARGET_NOT_FOUND", last.rodV8TargetNotFound)
        assertTrue("estado final coerente: ${last.rodState}",
            last.rodState == "RECOVERING" || last.rodState == "TARGET_NOT_FOUND")
        assertTrue("nada de input em cena vazia: ${rig.exec.calls}", rig.gestures().isEmpty())
    }

    // ---- §16: the debug view is a passive snapshot, it cannot change the detection -------------

    @Test
    fun debugVisualizationIsAPassiveSnapshotAndDoesNotChangeDetection() {
        RealInputPolicy.lock()
        // run A: reads the render model on every frame
        val withView = Rig()
        withView.pipeline.armed = true
        val seenBoxes = ArrayList<FloatArray>()
        repeat(30) {
            withView.step(withView.rod())
            withView.pipeline.render?.rodV8WindowBox?.let { seenBoxes.add(it.copyOf()) }
        }
        // run B: identical scene, the model is never touched
        val withoutView = Rig()
        withoutView.pipeline.armed = true
        repeat(30) { withoutView.step(withoutView.rod()) }

        assertEquals(
            "ler ou não o debug não pode alterar a detecção",
            withView.states, withoutView.states,
        )
        assertEquals(
            "mesmo estado final", withoutView.pipeline.output.rodState,
            withView.pipeline.output.rodState,
        )
        // the model is rebuilt per frame (immutable snapshot), so an old copy cannot be mutated later
        val first = seenBoxes.first()
        assertTrue("a janela publicada mudou durante o tracking", seenBoxes.any { it[0] != first[0] })
        assertEquals("cópias antigas permanecem estáveis", first[0], seenBoxes.first()[0], 0f)
        val model = withView.pipeline.render
        assertNotNull(model)
        assertSame("model é estável entre leituras do mesmo frame", model, withView.pipeline.render)
    }
}
