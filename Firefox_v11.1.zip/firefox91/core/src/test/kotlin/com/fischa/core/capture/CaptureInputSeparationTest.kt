package com.fischa.core.capture

import com.fischa.core.config.AppConfig
import com.fischa.core.config.RodDetectorKind
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.pipeline.PipelineInput
import com.fischa.core.pipeline.VisionPipeline
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.RecordingExecutor
import com.fischa.core.safety.RobloxForegroundStatus
import com.fischa.core.state.Evidence
import com.fischa.core.state.FishingState
import com.fischa.core.state.FishingStateMachine
import com.fischa.core.vision.VisionFrame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import com.fischa.core.safety.RealInputPolicy
import org.junit.After
import org.junit.Before
import org.junit.Test

/**
 * V6 spec §19 — CAPTURE vs INPUT separation (spec §12/§13) and the "START does not fish" rule (§9).
 *
 *   11. realInput OFF → ROD/WOULD_CAST may be logged, gesture never sent → [realInputOffRecordsWouldCastButNeverTouchesTheExecutor]
 *   19. realInput OFF bloqueia input              → same test + [captureKeepsRunningWithRealInputOff]
 *   20. Roblox ausente bloqueia input             → [robloxAbsentBlocksInputButNotCapture]
 *   21. captura funcionando sem Roblox foreground → [captureRunsWithoutRobloxForeground]
 *   13. frame inexistente/idade inválida           → [captureReportsNaButVisionNeverUsesMaxValue]
 *   22. catch retorna WAITING_FOR_ROD             → [catchReturnsToWaitingForRod]
 *
 * The complementary V5 cases (START não executa input, rod ausente, confiança baixa, Roblox/realInput
 * bloqueando, frame stale) live in `StartSemanticsV5Test` and remain untouched — they are part of the
 * suite the V6 report counts.
 */
class CaptureInputSeparationTest {

    // V7 §10: the shipped app hard-locks REAL_INPUT while the detection is validated.
    // This legacy suite verifies the *unlocked* input chain (V5/V6 behaviour), so the lock
    // is explicitly released for its duration and restored afterwards. The lock itself is
    // covered by the V7 suite (`V7RealInputLockTest`).
    @Before fun unlockRealInputForLegacyInputTests() {
        RealInputPolicy.unlockForTesting("legacy input-chain test (unlocked path)")
    }

    @After fun restoreRealInputLock() {
        RealInputPolicy.lock()
    }


    companion object {
        const val W = 640
        const val H = 288
        const val ROD_CX = 520
        const val ROD_CY = 199
    }

    private fun drawRod(frame: VisionFrame) {
        val bg = 0xFF787878.toInt()
        val interior = 0xFF282828.toInt()
        val ring = 0xFF6E6E6E.toInt()
        val glyph = 0xFFA0A0A0.toInt()
        frame.argb.fill(bg)
        for (y in 0 until H) for (x in 0 until W) {
            val dx = x - ROD_CX; val dy = y - ROD_CY
            val d2 = dx * dx + dy * dy
            frame.argb[y * W + x] = when {
                d2 < 900 -> interior
                d2 <= 1600 -> ring
                else -> bg
            }
        }
        val gx = ROD_CX - 6; val gy = ROD_CY + 4
        for (y in gy - 10..gy + 10) for (x in gx - 10..gx + 10) {
            if ((x - gx) * (x - gx) + (y - gy) * (y - gy) <= 100 && x in 0 until W && y in 0 until H) {
                frame.argb[y * W + x] = glyph
            }
        }
    }

    private inner class Rig(
        cfg: AppConfig = AppConfig().validate().copy(rodDetector = RodDetectorKind.V8),
        val exec: RecordingExecutor = RecordingExecutor(),
        val emergency: EmergencyStop = EmergencyStop(),
    ) {
        var nowNs = 1_000_000_000L
        val pipeline = VisionPipeline(
            cfg = cfg,
            executor = exec,
            log = ThrottledLog(NoopSink),
            emergency = emergency,
            foregroundStatusProvider = {
                RobloxForegroundStatus(
                    foregroundPackage = "com.roblox.client",
                    robloxDetected = true,
                    inputAuthorized = true,
                    blockReason = "NONE",
                    timestampMs = nowNs / 1_000_000L,
                )
            },
            monotonicNowNs = { nowNs },
        )
        private var serial = 0L

        fun step(withRod: Boolean, realInput: Boolean = false, authorized: Boolean = true) {
            val frame = VisionFrame.allocate(W, H)
            frame.argb.fill(0xFF787878.toInt())
            if (withRod) drawRod(frame)
            frame.resetFor(nowNs, ++serial)
            pipeline.onFrame(
                frame,
                PipelineInput(
                    frameTimestampNs = nowNs,
                    currentTimeNs = nowNs,
                    captureHealthy = true,
                    robloxDetected = authorized,
                    inputAuthorized = authorized,
                    macroEnabled = true,
                    realInputEnabled = realInput,
                    foregroundPackage = if (authorized) "com.roblox.client" else "com.android.launcher",
                    foregroundBlockReason = if (authorized) "NONE" else "FOREGROUND_PACKAGE_MISMATCH",
                ),
            )
            nowNs += 33_000_000L
        }

        /** Real gestures only: the shared RecordingExecutor logs denied attempts with a suffix. */
        fun inputCalls() = exec.calls.filter { it == "tap" || it == "holdStart" || it == "holdExtend" }
    }

    @Test fun realInputOffRecordsWouldCastButNeverTouchesTheExecutor() {
        val rig = Rig()
        rig.pipeline.armed = true
        var sawRodConfirmed = false
        repeat(14) {
            rig.step(withRod = true, realInput = false)
            if (rig.pipeline.output.rodDetected && rig.pipeline.output.rodConfirmed) sawRodConfirmed = true
        }
        assertTrue("a vara deve ser detectada/confirmada mesmo com realInput OFF", sawRodConfirmed)
        assertTrue("nenhum gesto pode ser enviado com realInput OFF", rig.inputCalls().isEmpty())
        val out = rig.pipeline.output
        assertFalse(out.inputAuthorized)
        assertEquals("REAL_INPUT_DISABLED", out.castGateReason)
        assertFalse(out.inputIssued)
        rig.pipeline.close()
    }

    @Test fun captureKeepsRunningWithRealInputOff() {
        val rig = Rig()
        rig.pipeline.armed = true
        repeat(14) { rig.step(withRod = true, realInput = false) }
        val out = rig.pipeline.output
        // vision ran on real frames even though input was never authorized (spec §13)
        assertTrue("frame age deve ser válido com captura ativa", FrameAge.isValid(out.frameAgeMs))
        assertTrue(out.globalConfidence >= 0f)
        assertEquals(FishingState.WAITING_FOR_ROD, out.state)
        rig.pipeline.close()
    }

    @Test fun robloxAbsentBlocksInputButNotCapture() {
        val rig = Rig()
        rig.pipeline.armed = true
        repeat(14) { rig.step(withRod = true, realInput = true, authorized = false) }
        val out = rig.pipeline.output
        assertTrue("captura segue viva sem Roblox em foreground", FrameAge.isValid(out.frameAgeMs))
        assertTrue(rig.inputCalls().isEmpty())
        assertEquals("ROBLOX_NOT_DETECTED", out.castGateReason)
        assertFalse(out.inputAuthorized)
        rig.pipeline.close()
    }

    @Test fun captureRunsWithoutRobloxForeground() {
        // This is the V6 §12/§13 requirement: the screen capture is infrastructure and must be
        // diagnosable/usable while Roblox is not in the foreground.
        val rig = Rig()
        rig.pipeline.armed = true
        repeat(10) { rig.step(withRod = false, realInput = false, authorized = false) }
        val out = rig.pipeline.output
        assertTrue(FrameAge.isValid(out.frameAgeMs))
        assertFalse(out.robloxDetected)
        assertFalse(out.inputIssued)
        assertEquals(FishingState.WAITING_FOR_ROD, out.state)
        assertTrue(rig.inputCalls().isEmpty())
        rig.pipeline.close()
    }

    @Test fun captureReportsNaButVisionNeverUsesMaxValue() {
        // "no frame" is modelled as FrameAge.NONE (-1) and formatted as N/A — never Long.MAX_VALUE.
        assertEquals("N/A", FrameAge.format(FrameAge.NONE))
        assertFalse(FrameAge.isValid(FrameAge.NONE))
        assertTrue(FrameAge.isStale(FrameAge.NONE, 350L))
        assertTrue("Long.MAX_VALUE must be treated as unusable", FrameAge.isStale(Long.MAX_VALUE, 350L))
    }

    @Test fun catchReturnsToWaitingForRod() {
        val machine = FishingStateMachine(AppConfig.StateTiming())
        machine.armed = true
        var time = 0L
        fun step(block: Evidence.() -> Unit = {}) {
            machine.update(
                Evidence().apply {
                    robloxForeground = true
                    captureHealthy = true
                    globalConf = 0.9f
                    nowNs = time
                    block()
                },
            )
            time += 33_000_000L
        }
        fun rodGate() {
            step {
                fishingButton = true; fishingButtonConf = 0.9f
                rodConfirmed = true; castAuthorized = true
            }
        }
        rodGate(); rodGate()
        assertEquals(FishingState.CASTING, machine.state)
        step { castComplete = true }
        step { shake = true; shakeConf = 0.9f }
        step { shake = true; shakeConf = 0.9f }
        repeat(3) { step { bar = true; barConf = 0.9f } }
        step { bar = true; barConf = 0.9f; fishOk = true; playerOk = true }
        step { bar = true; barConf = 0.9f; fishOk = true; playerOk = true }
        repeat(7) { step { bar = true; barConf = 0.9f; progress = 0.9f; fishOk = true; playerOk = true } }
        repeat(6) { step { progress = 0.9f } }
        assertEquals(FishingState.CATCH_CONFIRMATION, machine.state)
        step { catchConfirm = true; catchConfirmConf = 0.9f }
        assertEquals(FishingState.RESET, machine.state)
        repeat(40) { if (machine.state != FishingState.WAITING_FOR_ROD) step { fishingButton = true } }
        assertEquals("após o catch a FSM deve voltar para WAITING_FOR_ROD", FishingState.WAITING_FOR_ROD, machine.state)
        // and the next cast still requires the visual rod confirmation (no blind recast)
        step { fishingButton = false }
        assertEquals(FishingState.WAITING_FOR_ROD, machine.state)
    }
}
