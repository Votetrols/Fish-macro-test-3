package com.fischa.core.v9

import com.fischa.core.vision.VisionFrame
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.min
import kotlin.math.sin

/**
 * Cena sintética de jogo para os testes da V9 (spec §12).
 *
 * A cena tem tudo o que a spec §6 manda **rejeitar**: céu, água ondulada, margem/pedra texturizada,
 * silhueta de personagem, partículas brilhantes, sombras alongadas, reflexos finos, barra de
 * inventário e — quando o teste pedir — o prompt "SHAKE" (disco escuro com texto claro) e bolhas de
 * espuma na água.
 *
 * O **botão da vara** é desenhado como um elemento de interface de verdade, com aparência
 * *configurável* ([Button]): face escura ou clara, contorno de espessura variável, ícone da vara,
 * botão quadrado arredondado, semi-transparente — todos os estilos precisam ser encontrados. Em
 * troca, [Foam] pinta manchas na água que **não** são interface.
 *
 * Nenhuma coordenada do detector entra aqui: o botão é desenhado onde o teste mandar.
 */
object RodSceneV9Fixture {

    /** nível da água (fração da altura) — a água fica abaixo dele. */
    const val WATER_LEVEL = 0.42f

    /**
     * Elemento de interface (o botão candidato).
     *
     * @param alpha 1 = opaco; < 1 = semi-transparente, misturado com o que está atrás (§3).
     */
    data class Button(
        val cx: Int,
        val cy: Int,
        val r: Int = 34,
        val faceGray: Int = 0x3A,
        val ringGray: Int = 0x9A,
        val ringWidth: Int = 3,
        val glyphGray: Int = 0xB4,
        val glyph: Boolean = true,
        val alpha: Float = 1f,
        /** botão "quadrado arredondado" (mesma família de interface, forma diferente) */
        val roundedSquare: Boolean = false,
        /** em vez de interface, uma mancha clara e redonda na água (falso positivo a rejeitar) */
        val plainBlob: Boolean = false,
    )

    /** mancha clara e redonda **na água** (espuma/bolha): não é interface, não pode ser confirmada */
    data class Foam(val cx: Int, val cy: Int, val r: Int, val gray: Int = 0xCE)

    /** prompt "SHAKE": disco escuro com texto claro dentro (o falso positivo clássico) */
    data class ShakePrompt(val cx: Int, val cy: Int, val r: Int = 34)

    /**
     * Aparência do botão desenhado ([buttonAt]) — a spec §12 exige que **todos** os estilos
     * abaixo sejam encontrados: é a mesma família de interface (botão escuro/claro, contorno de
     * espessura e tom variáveis, forma quadrada arredondada, sem ícone, semi-transparente).
     */
    enum class ButtonStyle { DEFAULT, DARK_RING, LIGHT_BUTTON, TRANSLUCENT, ROUNDED_SQUARE, NO_GLYPH }

    /**
     * Barra de inventário do rodapé (itens pequenos, **não** são alvo).
     *
     * @param y centro vertical da linha de itens; `< 0` usa o rodapé padrão (`h - 9`).
     */
    data class Hotbar(val y: Int = -1, val size: Int = 13, val count: Int = 8)

    /** raio padrão do botão para uma altura de frame (≈34 px em 288p: HUD em fração da tela). */
    fun defaultButtonRadius(h: Int): Int = max(8, (h * 0.118f).roundToInt())

    /**
     * Botão na posição normalizada ([fx],[fy]) do frame — é assim que os testes dizem "desenhe o
     * botão aqui" sem que nenhuma coordenada entre no detector (§14: o teste usa a verdade do
     * desenho; o detector tem de descobrir sozinho).
     */
    fun buttonAt(
        fx: Float,
        fy: Float,
        w: Int,
        h: Int,
        style: ButtonStyle = ButtonStyle.DEFAULT,
        r: Int = defaultButtonRadius(h),
        glyph: Boolean = true,
    ): Button {
        val base = Button(
            cx = (fx * w).roundToInt(),
            cy = (fy * h).roundToInt(),
            r = r,
            glyph = glyph,
        )
        return when (style) {
            ButtonStyle.DEFAULT -> base
            // contorno escuro sobre face média (interface "outline")
            ButtonStyle.DARK_RING -> base.copy(faceGray = 0x7E, ringGray = 0x40, ringWidth = 3)
            // botão claro (face clara, contorno ainda mais claro, ícone escuro)
            ButtonStyle.LIGHT_BUTTON -> base.copy(faceGray = 0xA8, ringGray = 0xD8, glyphGray = 0x50)
            // HUD translúcido: o botão mistura com a cena atrás dele
            ButtonStyle.TRANSLUCENT -> base.copy(alpha = 0.45f)
            // mesma família de interface, forma quadrada arredondada
            ButtonStyle.ROUNDED_SQUARE -> base.copy(roundedSquare = true)
            // sem ícone dentro
            ButtonStyle.NO_GLYPH -> base.copy(glyph = false)
        }
    }

    /** estado temporal da cena (câmera e ondulação mudam a cada frame, como no jogo) */
    data class FrameState(
        val seed: Long = 1L,
        val wavePhase: Float = 0f,
        val cameraX: Int = 0,
        val cameraY: Int = 0,
    )

    fun draw(
        frame: VisionFrame,
        state: FrameState = FrameState(),
        button: Button? = null,
        shake: ShakePrompt? = null,
        foam: List<Foam> = emptyList(),
        rock: Boolean = true,
        character: Boolean = true,
        reflections: Boolean = true,
        particles: Boolean = true,
        hotbar: Hotbar? = Hotbar(),
        noise: Int = 6,
        waterLevel: Float = WATER_LEVEL,
    ) {
        val w = frame.width
        val h = frame.height
        var rnd = state.seed * 6364136223846793005L + 1442695040888963407L

        fun nextNoise(): Int {
            rnd = rnd * 6364136223846793005L + 1442695040888963407L
            return (((rnd ushr 33) % (2L * noise + 1)) - noise).toInt()
        }

        val waterY = (h * waterLevel).toInt()
        val parallax = state.cameraX

        // ---- céu e água (o mundo se desloca com a câmera; a água ondula) ----------------------
        for (y in 0 until h) {
            val o = y * w
            val worldY = y + state.cameraY
            for (x in 0 until w) {
                val worldX = x + parallax
                val g = if (y < waterY) {
                    val t = y.toFloat() / max(1, waterY)
                    val cloud = (16 * sin(worldX * 0.017f + worldY * 0.011f)).toInt()
                    (86 + 46 * t).toInt() + cloud
                } else {
                    val band = (17 * sin(worldY * 0.33f + state.wavePhase)).toInt()
                    val band2 = (9 * sin(worldX * 0.055f - worldY * 0.12f + state.wavePhase * 1.4f)).toInt()
                    val band3 = (5 * sin(worldX * 0.21f + state.wavePhase * 2.1f)).toInt()
                    58 + band + band2 + band3
                }
                frame.argb[o + x] = gray((g + nextNoise()).coerceIn(0, 255))
            }
        }

        // ---- reflexos: faixas claras e finas na água (não têm contorno fechado) ---------------
        if (reflections) {
            for (k in 0 until 4) {
                val rx = (w * (0.22 + 0.17 * k)).toInt() - parallax + (state.wavePhase * 7f).toInt()
                val ry = waterY + (h * 0.11).toInt() + k * 13
                val halfW = 14 + k * 6
                for (y in ry - 1..ry + 1) {
                    for (x in rx - halfW..rx + halfW) {
                        if (x !in 0 until w || y !in 0 until h) continue
                        val p = frame.argb[y * w + x]
                        val g = min(255, ((p shr 8) and 0xFF) + 46)
                        frame.argb[y * w + x] = gray(g)
                    }
                }
            }
        }

        // ---- sombras: duas elipses escuras alongadas no chão --------------------------------
        for (s in 0 until 2) {
            val sx = (w * (0.34 + 0.22 * s)).toInt() - parallax
            val sy = waterY + (h * 0.02).toInt() - state.cameraY
            for (y in sy - 5..sy + 5) {
                for (x in sx - 34..sx + 34) {
                    if (x !in 0 until w || y !in 0 until h) continue
                    val dx = (x - sx) / 34.0
                    val dy = (y - sy) / 5.0
                    if (dx * dx + dy * dy <= 1.0) {
                        val p = frame.argb[y * w + x]
                        frame.argb[y * w + x] = gray((((p shr 8) and 0xFF) * 0.58).toInt())
                    }
                }
            }
        }

        // ---- margem/pedra: grande, irregular e texturizada (não é interface) ----------------
        if (rock) {
            val rx = (w * 0.13).toInt() - parallax / 2
            val ry = waterY + (h * 0.13).toInt() - state.cameraY / 2
            val rw = (w * 0.12).toInt()
            val rh = (h * 0.14).toInt()
            for (y in ry - rh..ry + rh) {
                for (x in rx - rw..rx + rw) {
                    if (x !in 0 until w || y !in 0 until h) continue
                    val dx = (x - rx).toFloat() / rw
                    val dy = (y - ry).toFloat() / rh
                    val wob = 0.24f * sin(x * 0.19f) + 0.19f * sin(y * 0.26f)
                    if (abs(dx) + abs(dy) + wob <= 1.02f) {
                        val tex = (24 * sin(x * 0.35f) * cos(y * 0.31f)).toInt()
                        frame.argb[y * w + x] = gray((128 + tex + nextNoise()).coerceIn(0, 255))
                    }
                }
            }
        }

        // ---- personagem: silhueta escura de bordas irregulares ------------------------------
        if (character) {
            val px = (w * 0.30).toInt() - parallax
            val py = waterY - state.cameraY
            val bodyW = (w * 0.021).toInt().coerceAtLeast(6)
            val bodyH = (h * 0.30).toInt().coerceAtLeast(36)
            for (y in py - bodyH..py) {
                for (x in px - bodyW..px + bodyW) {
                    if (x !in 0 until w || y !in 0 until h) continue
                    val wob = (4 * sin(y * 0.31f)).toInt()
                    if (abs(x - px - wob) <= bodyW) frame.argb[y * w + x] = gray(0x24)
                }
            }
            val hr = (h * 0.042).toInt().coerceAtLeast(8)
            val hy = py - bodyH
            for (y in hy - hr..hy + hr) {
                for (x in px - hr..px + hr) {
                    if (x !in 0 until w || y !in 0 until h) continue
                    val d2 = (x - px) * (x - px) + (y - hy) * (y - hy)
                    if (d2 <= hr * hr) frame.argb[y * w + x] = gray(0x28)
                }
            }
        }

        // ---- partículas: pontos claros pequenos (não são interface) -------------------------
        if (particles) {
            for (i in 0 until 16) {
                val px = ((i * 53 + parallax / 2 + (state.wavePhase * 11f).toInt()) % w + w) % w
                val py = waterY + ((i * 19) % max(1, h - waterY))
                if (py >= h) continue
                for (y in py - 2..py + 2) {
                    for (x in px - 2..px + 2) {
                        if (x !in 0 until w || y !in 0 until h) continue
                        if (hypot((x - px).toDouble(), (y - py).toDouble()) <= 2.0) {
                            frame.argb[y * w + x] = gray(0xE4)
                        }
                    }
                }
            }
        }

        // ---- espuma: manchas claras redondas na água (falso positivo a rejeitar) ------------
        for (f in foam) {
            for (y in f.cy - f.r..f.cy + f.r) {
                for (x in f.cx - f.r..f.cx + f.r) {
                    if (x !in 0 until w || y !in 0 until h) continue
                    if ((x - f.cx) * (x - f.cx) + (y - f.cy) * (y - f.cy) <= f.r * f.r) {
                        frame.argb[y * w + x] = gray(f.gray)
                    }
                }
            }
        }

        // ---- barra de inventário: itens pequenos no rodapé (tamanho abaixo da faixa) --------
        hotbar?.let { bar ->
            val size = bar.size
            val count = bar.count
            val y0 = if (bar.y >= 0) bar.y else h - 9
            for (i in 0 until count) {
                val x0 = (w * 0.04).toInt() + i * (size + 4)
                for (y in y0 - size / 2..y0 + size / 2) {
                    for (x in x0..x0 + size) {
                        if (x !in 0 until w || y !in 0 until h) continue
                        frame.argb[y * w + x] = gray(0xCA - i * 5)
                    }
                }
            }
        }

        // ---- prompt SHAKE: disco escuro com texto claro ------------------------------------
        shake?.let { sp ->
            for (y in sp.cy - sp.r..sp.cy + sp.r) {
                for (x in sp.cx - sp.r..sp.cx + sp.r) {
                    if (x !in 0 until w || y !in 0 until h) continue
                    if ((x - sp.cx) * (x - sp.cx) + (y - sp.cy) * (y - sp.cy) <= sp.r * sp.r) {
                        frame.argb[y * w + x] = gray(0x26)
                    }
                }
            }
            for (row in 0 until 3) {
                val y0 = sp.cy - sp.r / 2 + row * (sp.r / 2)
                for (dy in 0 until 2) {
                    for (x in sp.cx - sp.r / 2..sp.cx + sp.r / 2) {
                        val y = y0 + dy
                        if (x !in 0 until w || y !in 0 until h) continue
                        frame.argb[y * w + x] = gray(0xF0)
                    }
                }
            }
        }

        // ---- o elemento em teste (por cima de tudo, como um HUD) ---------------------------
        button?.let { drawButton(frame, it) }
        frame.ensureGray()
    }

    /** desenha um elemento de interface (ou uma mancha, quando [Button.plainBlob]). */
    fun drawButton(frame: VisionFrame, b: Button) {
        val w = frame.width
        val h = frame.height
        val r = b.r.toFloat()
        for (y in max(0, b.cy - b.r - 2)..min(h - 1, b.cy + b.r + 2)) {
            for (x in max(0, b.cx - b.r - 2)..min(w - 1, b.cx + b.r + 2)) {
                val dx = x - b.cx
                val dy = y - b.cy
                val inside: Boolean
                val ring: Boolean
                if (b.plainBlob) {
                    inside = dx * dx + dy * dy <= r * r
                    ring = false
                } else if (b.roundedSquare) {
                    val lim = r * 0.84f
                    val qx = max(0f, abs(dx) - (lim - r * 0.28f))
                    val qy = max(0f, abs(dy) - (lim - r * 0.28f))
                    inside = abs(dx) <= lim + 1 && abs(dy) <= lim + 1 &&
                        hypot(qx.toDouble(), qy.toDouble()) <= r * 0.28f
                    ring = inside && hypot(qx.toDouble(), qy.toDouble()) >= r * 0.28f - b.ringWidth
                } else {
                    val d2 = dx * dx + dy * dy
                    inside = d2 <= r * r
                    ring = inside && hypot(dx.toDouble(), dy.toDouble()) >= r - b.ringWidth
                }
                if (!inside) continue
                val target = if (ring) b.ringGray else b.faceGray
                put(frame, x, y, target, b.alpha)
            }
        }
        if (b.glyph && !b.plainBlob) {
            // ícone da vara: diagonal + anzol (cinza médio, como no HUD do jogo)
            val thick = max(1, (r * 0.11f).toInt())
            val x0 = (b.cx - r * 0.42f).toInt()
            val y0 = (b.cy + r * 0.46f).toInt()
            val x1 = (b.cx + r * 0.28f).toInt()
            val y1 = (b.cy - r * 0.50f).toInt()
            val steps = max(16, hypot((x1 - x0).toDouble(), (y1 - y0).toDouble()).toInt())
            for (i in 0..steps) {
                val t = i.toFloat() / steps
                val px = (x0 + (x1 - x0) * t).toInt()
                val py = (y0 + (y1 - y0) * t).toInt()
                for (dy in -thick..thick) {
                    for (dx in -thick..thick) {
                        if (dx * dx + dy * dy > thick * thick) continue
                        val x = px + dx
                        val y = py + dy
                        if (x < 0 || y < 0 || x >= w || y >= h) continue
                        put(frame, x, y, b.glyphGray, b.alpha)
                    }
                }
            }
            val hx = (b.cx + r * 0.20f).toInt()
            val hy = (b.cy + r * 0.26f).toInt()
            val hr = max(2, (r * 0.16f).toInt())
            for (y in hy - hr..hy + hr) {
                for (x in hx - hr..hx + hr) {
                    if (x < 0 || y < 0 || x >= w || y >= h) continue
                    val d = hypot((x - hx).toDouble(), (y - hy).toDouble())
                    if (d <= hr && d >= hr - 2.0) put(frame, x, y, b.glyphGray, b.alpha)
                }
            }
        }
    }

    private fun put(frame: VisionFrame, x: Int, y: Int, value: Int, alpha: Float) {
        val g = value.coerceIn(0, 255)
        if (alpha >= 0.999f) {
            frame.argb[y * frame.width + x] = gray(g)
            return
        }
        val back = frame.argb[y * frame.width + x]
        val bg = (back shr 8) and 0xFF
        val mixed = (bg + (g - bg) * alpha.coerceIn(0f, 1f)).toInt().coerceIn(0, 255)
        frame.argb[y * frame.width + x] = gray(mixed)
    }

    private fun gray(g: Int): Int {
        val v = g.coerceIn(0, 255)
        return (0xFF shl 24) or (v shl 16) or (v shl 8) or v
    }
}
