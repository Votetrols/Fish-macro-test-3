package com.fischa.core.v8

import com.fischa.core.common.NormRegion
import com.fischa.core.config.AppConfig
import com.fischa.core.config.RodDetectorKind
import com.fischa.core.log.LogSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.vision.RodDetectionV8
import com.fischa.core.vision.RodV8Result
import com.fischa.core.vision.RodV8State
import com.fischa.core.vision.VisionFrame
import com.fischa.core.v7.RodSceneFixture
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * **Rod Detection V8 — testes obrigatórios (spec §20).**
 *
 * Cada teste corresponde a um dos 17 casos exigidos pela especificação, mais as duas garantias
 * finais (`TARGET_NOT_FOUND` nunca produz coordenada falsa; a V8 nunca executa input).
 *
 * O harness desenha a cena com [RodSceneFixture] (a mesma cena sintética validada na V7: disco
 * escuro + anel claro + glifo cinza do gancho), colocando o botão em **qualquer** posição, tamanho
 * e resolução — assim as asserções são sempre relativas à *verdade* do desenho, nunca a uma
 * coordenada fixa no código.
 */
class V8RodDetectionTest {

    private class RecordingSink : LogSink {
        val lines = ArrayList<String>()
        override fun log(level: LogSink.Level, tag: String, msg: String, timestampNs: Long) {
            lines.add("$tag|$msg")
        }
        fun any(sub: String) = lines.any { it.contains(sub) }
    }

    /** Drives [RodDetectionV8] frame by frame with a fake clock. */
    private class Driver(
        val w: Int = 640,
        val h: Int = 288,
        val fps: Float = 30f,
        cfg: AppConfig = AppConfig().validate(),
    ) {
        val sink = RecordingSink()
        val log = ThrottledLog(sink)
        val cfg: AppConfig = cfg.copy(rodDetector = RodDetectorKind.V8)
        val det = RodDetectionV8(this.cfg, log)
        val periodNs: Long = (1_000_000_000.0 / fps).toLong().coerceAtLeast(1L)
        var nowNs = 1_000_000_000L
        var serial = 0L
        val states = ArrayList<RodV8State>()
        val windowCenters = ArrayList<Pair<Float, Float>>()
        val windows = ArrayList<NormRegion>()
        var last = copy(det.out)

        /** the *configured* (base) window — where the detector must start */
        fun roi(): NormRegion {
            val v = cfg.rodV8
            return NormRegion(
                v.initialRoiX, v.initialRoiY,
                v.initialRoiX + v.roiWidth, v.initialRoiY + v.roiHeight,
            )
        }

        private fun copy(r: RodV8Result): RodV8Result = RodV8Result().also { it.copyFrom(r) }

        /** one frame; returns a **copy** (the detector reuses its snapshot) */
        fun frame(
            rod: RodSceneFixture.Rod?,
            noise: Int = 0,
            whiteText: Boolean = false,
            whiteTextCenter: Pair<Int, Int>? = null,
        ): RodV8Result {
            val f = VisionFrame.allocate(w, h)
            RodSceneFixture.draw(
                f, rod, noise = noise, whiteText = whiteText, whiteTextCenter = whiteTextCenter,
            )
            f.resetFor(nowNs, ++serial)
            f.ensureGray()
            log.setNow(nowNs)
            val snap = det.update(f, fps, nowNs)
            nowNs += periodNs
            states.add(snap.state)
            windowCenters.add(snap.roi.centerX to snap.roi.centerY)
            windows.add(snap.roi)
            last = copy(snap)
            return last
        }

        fun run(
            frames: Int,
            rod: (Int) -> RodSceneFixture.Rod?,
            noise: Int = 0,
            whiteText: Boolean = false,
            whiteTextCenter: Pair<Int, Int>? = null,
            stopWhen: (RodV8Result) -> Boolean = { false },
        ): RodV8Result {
            var snap = last
            repeat(frames) { i ->
                snap = frame(rod(i), noise = noise, whiteText = whiteText, whiteTextCenter = whiteTextCenter)
                if (stopWhen(snap)) return snap
            }
            return snap
        }

        fun run(frames: Int, rod: RodSceneFixture.Rod?, noise: Int = 0, stopWhen: (RodV8Result) -> Boolean = { false }): RodV8Result =
            run(frames, { rod }, noise = noise, stopWhen = stopWhen)

        /** runs until the detector reports a found (tracking) target */
        fun confirm(rod: RodSceneFixture.Rod, max: Int = 60): RodV8Result =
            run(max, rod) { it.targetFound && it.state == RodV8State.TRACKING }

        fun indexOfFirst(state: RodV8State): Int = states.indexOfFirst { it == state }

        /**
         * Largest per-frame window displacement. Recovery-stage changes are excluded by default:
         * expanding/re-anchoring the search area is a deliberate, timer-driven event (§7), not a
         * detection-driven jump (§4) — what matters here is that *following* the target is bounded.
         */
        fun maxWindowStepPx(excludeRecovery: Boolean = true): Float {
            var worst = 0f
            for (i in 1 until windowCenters.size) {
                if (excludeRecovery && (states[i].isRecovery || states[i - 1].isRecovery)) continue
                val dx = (windowCenters[i].first - windowCenters[i - 1].first) * w
                val dy = (windowCenters[i].second - windowCenters[i - 1].second) * h
                worst = max(worst, hypot(dx, dy))
            }
            return worst
        }
    }

    private fun cfg(
        rodV8: AppConfig.RodV8 = AppConfig.RodV8(),
        rodV7: AppConfig.RodV7 = AppConfig.RodV7(),
    ): AppConfig = AppConfig().copy(rodDetector = RodDetectorKind.V8, rodV8 = rodV8, rodV7 = rodV7).validate()

    private fun rod(cx: Int, cy: Int, interiorR: Int = 30, ringR: Int = 40) =
        RodSceneFixture.Rod(cx, cy, interiorR = interiorR, ringR = ringR)

    /** The window must always be a valid rectangle fully inside the screen (spec §11). */
    private fun assertWindowInsideScreen(r: RodV8Result, tag: String) {
        val roi = r.roi
        assertTrue("$tag: janela inválida ${roi.describe()}", roi.isValid)
        assertTrue(
            "$tag: janela fora da tela ${roi.describe()}",
            roi.left >= -1e-4f && roi.top >= -1e-4f && roi.right <= 1f + 1e-4f && roi.bottom <= 1f + 1e-4f,
        )
    }

    /** Whenever the target is not found, no position may exist (spec §7/§20). */
    private fun assertNoInventedPosition(r: RodV8Result, tag: String) {
        if (!r.targetFound) {
            assertTrue("$tag: targetX inventado (${r.targetX}) com targetFound=false", r.targetX.isNaN())
            assertTrue("$tag: targetY inventado (${r.targetY}) com targetFound=false", r.targetY.isNaN())
        } else {
            assertTrue("$tag: posição não finita com targetFound=true", r.targetX.isFinite() && r.targetY.isFinite())
            assertTrue("$tag: posição fora da tela (${r.targetX},${r.targetY})", r.targetX in 0f..1f && r.targetY in 0f..1f)
        }
    }

    // ============================================================ 1. alvo parado

    @Test
    fun stationaryTargetIsFoundConfirmedAndTrackedWithoutJitter() {
        val d = Driver()
        val snap = d.confirm(rod(520, 199))
        assertTrue("não encontrou o alvo parado (state=${snap.state} reason=${snap.reason})", snap.targetFound)
        assertEquals("estado deveria ser TRACKING", RodV8State.TRACKING, snap.state)
        assertTrue("centro errado: (${snap.centerPx.x},${snap.centerPx.y})",
            hypot(snap.centerPx.x - 520f, snap.centerPx.y - 199f) <= 6f)
        assertTrue("confiança baixa: ${snap.confidence}", snap.confidence >= 0.5f)
        assertNoInventedPosition(snap, "alvo parado")
        assertWindowInsideScreen(snap, "alvo parado")

        // §9: depois de estabilizar, a janela não pode ficar tremendo
        val before = d.windowCenters.size
        d.run(10, rod(520, 199))
        val tail = d.windowCenters.subList(before, d.windowCenters.size)
        val jitterX = tail.maxOf { it.first } - tail.minOf { it.first }
        val jitterY = tail.maxOf { it.second } - tail.minOf { it.second }
        assertTrue("jitter em X: ${jitterX * 640f}px", jitterX * 640f <= 1.5f)
        assertTrue("jitter em Y: ${jitterY * 288f}px", jitterY * 288f <= 1.5f)
    }

    // ==================================================== 2..5. movimento em cada direção

    private fun assertFollows(rodStartX: Int, rodStartY: Int, dxPerFrame: Int, dyPerFrame: Int, tag: String) {
        val d = Driver()
        val start = d.confirm(rod(rodStartX, rodStartY))
        assertTrue("$tag: não confirmou o alvo inicial", start.targetFound)
        var moved = start
        var lastX = rodStartX
        var lastY = rodStartY
        for (i in 1..12) {
            lastX = rodStartX + dxPerFrame * i
            lastY = rodStartY + dyPerFrame * i
            moved = d.run(4, rod(lastX, lastY), stopWhen = { it.targetFound })
        }
        assertTrue(
            "$tag: não seguiu o movimento (state=${moved.state} reason=${moved.reason} target=($lastX,$lastY))",
            moved.targetFound,
        )
        assertTrue(
            "$tag: centro publicado (${moved.centerPx.x},${moved.centerPx.y}) longe do alvo ($lastX,$lastY)",
            hypot(moved.centerPx.x - lastX, moved.centerPx.y - lastY) <= 7f,
        )
        assertTrue("$tag: alvo não está dentro da janela", moved.roi.contains(moved.targetX, moved.targetY))
        assertWindowInsideScreen(moved, tag)
        assertNoInventedPosition(moved, tag)
    }

    @Test fun targetMovingLeft() = assertFollows(560, 199, -6, 0, "movimento p/ esquerda")

    @Test fun targetMovingRight() = assertFollows(470, 199, 6, 0, "movimento p/ direita")

    @Test fun targetMovingUp() = assertFollows(520, 215, 0, -4, "movimento p/ cima")

    @Test fun targetMovingDown() = assertFollows(520, 175, 0, 4, "movimento p/ baixo")

    // ============================================================ 6. alvo próximo às bordas

    @Test
    fun targetNearTheScreenEdgesIsStillFoundAndTheWindowStaysInside() {
        val cases = listOf(
            // (canto da janela inicial, centro do botão) — o botão fica encostado na borda
            Triple(Pair(0.85f, 0.72f), Pair(600, 250), "canto inferior direito"),
            Triple(Pair(0.00f, 0.00f), Pair(40, 45), "canto superior esquerdo"),
            Triple(Pair(0.60f, 0.00f), Pair(565, 40), "borda superior"),
            Triple(Pair(0.00f, 0.60f), Pair(45, 250), "borda inferior esquerda"),
        )
        for ((window, center, tag) in cases) {
            val d = Driver(
                cfg = cfg(
                    AppConfig.RodV8(
                        initialRoiX = window.first, initialRoiY = window.second,
                        roiWidth = 0.32f, roiHeight = 0.36f,
                    ),
                ),
            )
            var snap = d.last
            var found = false
            repeat(60) {
                // botão menor nas bordas: o anel dele precisa caber inteiro na tela
                snap = d.frame(rod(center.first, center.second, interiorR = 22, ringR = 30))
                if (snap.targetFound) found = true
                assertWindowInsideScreen(snap, tag)
                assertNoInventedPosition(snap, tag)
            }
            assertTrue("$tag: alvo perto da borda não foi encontrado (state=${snap.state} reason=${snap.reason})", found)
            assertTrue(
                "$tag: centro errado (${snap.centerPx.x},${snap.centerPx.y}) vs (${center.first},${center.second})",
                hypot(snap.centerPx.x - center.first, snap.centerPx.y - center.second) <= 7f,
            )
        }
    }

    // ============================================================ 7. falso positivo

    @Test
    fun falsePositiveFarFromTheLastKnownPositionIsRejected() {
        // §5 consistência espacial: com o alvo travado, um blob longe da última posição é suspeito
        val cfg = cfg(AppConfig.RodV8(maxCandidateJump = 0.05f))
        val d = Driver(cfg = cfg)
        val tracked = d.confirm(rod(520, 199))
        assertTrue("não rastreou o alvo real", tracked.targetFound)
        val windowBefore = tracked.roi
        // o alvo real desaparece e um sósia escuro (mesmo formato) aparece longe da última posição
        val falsePositive = rod(470, 180, interiorR = 30, ringR = 40)
        val distanceNorm = hypot((470 - 520) / 640f, (180 - 199) / 288f)
        assertTrue("o teste precisa de um salto maior que a tolerância", distanceNorm > 0.05f)
        // dentro da janela de carência (TARGET_LOST) o candidato suspeito não pode mover a ROI
        val snap = d.frame(falsePositive)
        val snap2 = d.frame(falsePositive)
        assertFalse("falso positivo não pode virar alvo", snap.targetFound || snap2.targetFound)
        assertFalse("não pode confirmar em TRACKING pelo falso positivo",
            snap.state == RodV8State.TRACKING || snap2.state == RodV8State.TRACKING)
        assertEquals("a ROI não pode se mover para o falso positivo (carência)", windowBefore.left, snap.roi.left, 1e-4f)
        assertEquals("a ROI não pode se mover para o falso positivo (carência)", windowBefore.top, snap.roi.top, 1e-4f)
        assertWindowInsideScreen(snap, "falso positivo")
        assertNoInventedPosition(snap, "falso positivo")
        // e o movimento da janela, em todo o episódio, continua limitado por maxMovePerFrame
        d.run(30, falsePositive)
        assertTrue("movimento por frame acima do limite: ${d.maxWindowStepPx()}px",
            d.maxWindowStepPx() <= 0.06f * 640f + 1f)
    }

    @Test
    fun whiteTextPromptInsideTheWindowNeverConfirms() {
        val d = Driver()
        // prompt "SHAKE" (disco escuro com texto branco) bem dentro da janela inicial
        var snap = d.last
        repeat(40) {
            snap = d.frame(null, whiteText = true, whiteTextCenter = 520 to 190)
        }
        assertFalse("texto branco (SHAKE) não pode confirmar (state=${snap.state})", snap.targetFound)
        assertEquals("estado não pode ser TRACKING", false, snap.state == RodV8State.TRACKING)
        assertTrue("deveria explicar o motivo", snap.reason.isNotEmpty())
        assertNoInventedPosition(snap, "texto branco")
    }

    @Test
    fun falsePositiveInANoisyEmptySceneNeverMovesTheWindowDrasticly() {
        val d = Driver()
        // cena vazia com ruído: nenhum alvo real, e o movimento da janela é limitado de qualquer forma
        var snap = d.last
        repeat(40) { snap = d.frame(null, noise = 14) }
        assertFalse("cena só com ruído não pode confirmar", snap.targetFound)
        val maxStep = d.maxWindowStepPx()
        assertTrue("movimento por frame acima do limite: ${maxStep}px", maxStep <= 0.06f * 640f + 1f)
        assertWindowInsideScreen(snap, "ruído")
        // durante a recuperação, qualquer que seja a etapa, a janela contém a área inicial
        val base = d.roi()
        assertTrue(
            "a janela de recuperação deveria continuar cobrindo a área inicial (${snap.roi.describe()})",
            snap.roi.left <= base.centerX && snap.roi.right >= base.centerX &&
                snap.roi.top <= base.centerY && snap.roi.bottom >= base.centerY,
        )
    }

    // ============================================ 8. perda temporária e 9. recuperação do alvo

    @Test
    fun temporaryLossKeepsTheWindowAndRecoversWithoutFullRecovery() {
        val d = Driver()
        val tracked = d.confirm(rod(520, 199))
        assertTrue("não confirmou antes da perda", tracked.targetFound)
        val windowAtLoss = tracked.roi
        // oclusão curta: 3 frames (< lostGraceMs em 30 fps → ~4 frames)
        var lost = tracked
        repeat(3) { lost = d.frame(null) }
        assertTrue("deveria estar em TARGET_LOST (state=${lost.state})",
            lost.state == RodV8State.TARGET_LOST || lost.state == RodV8State.TRACKING)
        assertFalse("durante a perda não pode publicar alvo", lost.targetFound)
        assertNoInventedPosition(lost, "perda temporária")
        // a janela não pode ter se mexido sozinha
        assertEquals("janela mudou durante a perda", windowAtLoss.centerX, lost.roi.centerX, 1e-4f)
        // e volta com o alvo no mesmo lugar: recuperação imediata, sem escada de expansão
        val back = d.run(12, rod(520, 199)) { it.targetFound }
        assertTrue("não recuperou o alvo (state=${back.state} reason=${back.reason})", back.targetFound)
        assertEquals("recuperação não deveria escalar etapas", 0, back.recoveryStage)
        assertFalse("janela não deveria ficar expandida depois de recuperar", back.windowExpanded)
    }

    @Test
    fun lostTargetIsRecoveredAroundTheLastKnownPositionAndTheWindowReturnsToNormalSize() {
        val d = Driver()
        val tracked = d.confirm(rod(520, 199))
        assertTrue("não confirmou antes", tracked.targetFound)
        // perda longa o bastante para entrar na recuperação (mas dentro do orçamento)
        var snap = tracked
        repeat(20) { snap = d.frame(null) }
        assertTrue("deveria estar recuperando (state=${snap.state} reason=${snap.reason})",
            snap.state == RodV8State.RECOVERING || snap.state == RodV8State.TARGET_LOST)
        assertTrue("a recuperação precisa expandir a busca em algum momento",
            d.states.contains(RodV8State.RECOVERING))
        // o alvo reaparece perto da última posição conhecida (dentro da janela expandida)
        val recovered = d.run(30, rod(560, 205)) { it.targetFound && it.state == RodV8State.TRACKING }
        assertTrue("não recuperou o alvo (state=${recovered.state} reason=${recovered.reason})", recovered.targetFound)
        assertTrue("centro errado após recuperar: (${recovered.centerPx.x},${recovered.centerPx.y})",
            hypot(recovered.centerPx.x - 560f, recovered.centerPx.y - 205f) <= 8f)
        // §8/§12: depois de estabilizar, a janela volta ao tamanho normal (e a etapa zera)
        val stabilized = d.run(6, rod(560, 205))
        assertEquals("etapa de recuperação deveria voltar a 0", 0, stabilized.recoveryStage)
        assertFalse("janela deveria voltar ao tamanho normal", stabilized.windowExpanded)
        assertEquals("janela deveria ter o tamanho configurado", 0.32f, stabilized.roi.width, 0.01f)
        assertTrue("deveria publicar a recuperação no log",
            d.sink.any("[ROD_V8] RECOVERING") || d.sink.any("TARGET_LOST"))
    }

    // ============================================================ 10. recuperação sem alvo

    @Test
    fun recoveryWithoutAnyTargetEndsInTargetNotFoundWithoutInventingAPosition() {
        val d = Driver()
        assertTrue("não confirmou antes", d.confirm(rod(520, 199)).targetFound)
        var snap = d.last
        var notFoundSeen = false
        repeat(120) {
            snap = d.frame(null)
            assertNoInventedPosition(snap, "recuperação sem alvo")
            assertWindowInsideScreen(snap, "recuperação sem alvo")
            if (snap.targetNotFound) notFoundSeen = true
        }
        assertTrue("TARGET_NOT_FOUND não foi reportado (state=${snap.state} reason=${snap.reason})", notFoundSeen)
        assertFalse("sem alvo, targetFound deve ser sempre false", snap.targetFound)
        assertTrue("a recuperação deve continuar tentando (state=${snap.state})",
            snap.state == RodV8State.RECOVERING || snap.state == RodV8State.TARGET_LOST)
        assertTrue("o log precisa dizer TARGET_NOT_FOUND", d.sink.any("TARGET_NOT_FOUND"))
        assertTrue("deveria registrar a recuperação por etapas", d.sink.any("etapa="))
        assertTrue("a escada de recuperação precisa passar por RECOVERING",
            d.states.contains(RodV8State.RECOVERING))
    }

    @Test
    fun neverPublishesAPositionInFramesWithoutATarget() {
        val d = Driver()
        // sequência mista: nada → alvo → nada → falso positivo branco → alvo longe → nada
        val script: List<RodSceneFixture.Rod?> = buildList {
            repeat(10) { add(null) }
            repeat(10) { add(rod(520, 199)) }
            repeat(10) { add(null) }
            repeat(10) { add(null) }
            repeat(15) { add(rod(560, 205)) }
            repeat(10) { add(null) }
        }
        var bad = 0
        for (r in script) {
            val snap = d.frame(r, whiteText = r == null)
            if (!snap.targetFound && (!snap.targetX.isNaN() || !snap.targetY.isNaN())) bad++
            if (snap.targetFound && (!snap.targetX.isFinite() || !snap.targetY.isFinite())) bad++
            assertWindowInsideScreen(snap, "sequência mista")
        }
        assertEquals("frames com posição inventada", 0, bad)
    }

    // ============================================================ 11. limite de movimento

    @Test
    fun windowNeverMovesMoreThanMaxMovePerFrame() {
        val maxMove = 0.01f                                  // 6.4 px por frame @640
        val d = Driver(cfg = cfg(AppConfig.RodV8(maxMovePerFrame = maxMove, deadZone = 0.001f, smoothing = 0f)))
        d.confirm(rod(470, 199))
        d.run(20, rod(560, 199))                             // salto de 90 px dentro da janela
        val worst = d.maxWindowStepPx()
        assertTrue(
            "deslocamento por frame ${worst}px acima de maxMovePerFrame=${maxMove * 640f}px — um falso positivo " +
                "não pode fazer a ROI pular",
            worst <= maxMove * 640f + 1f,
        )
        val snap = d.last
        assertTrue("deveria ter alcançado o alvo gradualmente", snap.targetFound)
    }

    @Test
    fun aSingleDistantCandidateCannotTeleportTheWindow() {
        val d = Driver()
        val tracked = d.confirm(rod(520, 199))
        val before = tracked.roi
        // alvo "reaparece" dentro da janela, do outro lado dela
        var snap = tracked
        repeat(6) { snap = d.frame(rod(575, 235)) }
        val moved = hypot((snap.roi.centerX - before.centerX) * 640f, (snap.roi.centerY - before.centerY) * 288f)
        assertTrue("salto de ${moved}px em 6 frames (limite ~${6 * 0.06f * 640f}px)",
            moved <= 6 * 0.06f * 640f + 2f)
        assertWindowInsideScreen(snap, "salto")
    }

    // ============================================================ 12. dead zone

    @Test
    fun deadZoneSuppressesSmallMovements() {
        // alvo deslocado ~0.095 em X e 0 em Y do centro da janela, dentro da dead zone configurada
        val d = Driver(cfg = cfg(AppConfig.RodV8(deadZone = 0.20f)))
        val start = d.roi()
        var snap = d.last
        repeat(20) { snap = d.frame(rod(560, 187)) }
        assertEquals("a janela não deveria se mover dentro da dead zone", start.left, snap.roi.left, 1e-4f)
        assertEquals("a janela não deveria se mover dentro da dead zone", start.top, snap.roi.top, 1e-4f)
        assertTrue("ainda assim precisa detectar o alvo", snap.targetFound)
    }

    @Test
    fun withoutDeadZoneTheSameSceneMovesTheWindow() {
        // controle do teste anterior: com dead zone ~0 a janela acompanha o mesmo alvo
        val d = Driver(cfg = cfg(AppConfig.RodV8(deadZone = 0f)))
        val start = d.roi()
        var snap = d.last
        repeat(20) { snap = d.frame(rod(560, 187)) }
        assertTrue("com deadZone=0 a janela deveria ter se movido",
            abs(snap.roi.left - start.left) > 1e-3f || abs(snap.roi.top - start.top) > 1e-3f)
        assertTrue("o alvo deve continuar dentro da janela", snap.roi.contains(snap.targetX, snap.targetY))
    }

    // ============================================================ 13. smoothing

    @Test
    fun smoothingMakesTheWindowApproachGradually() {
        val target = rod(560, 187)
        val fast = Driver(cfg = cfg(AppConfig.RodV8(smoothing = 0f, deadZone = 0f, maxMovePerFrame = 0.4f)))
        val slow = Driver(cfg = cfg(AppConfig.RodV8(smoothing = 0.9f, deadZone = 0f, maxMovePerFrame = 0.4f)))
        val fastStart = fast.roi().centerX
        val slowStart = slow.roi().centerX
        // a janela publicada no frame N é a que foi *varrida*; o movimento feito em N aparece em N+1
        var fastSnap = fast.frame(target)
        var slowSnap = slow.frame(target)
        fastSnap = fast.frame(target)
        slowSnap = slow.frame(target)
        val fastStep = abs(fastSnap.roi.centerX - fastStart)
        val slowStep = abs(slowSnap.roi.centerX - slowStart)
        assertTrue("smoothing=0 deveria andar mais que smoothing=0.9 ($fastStep vs $slowStep)", fastStep > slowStep)
        // e não deve ser lento demais: a suavização não pode travar o acompanhamento (§10)
        fastSnap = fast.run(10, target) { it.targetFound }
        slowSnap = slow.run(30, target) { it.targetFound }
        assertTrue("smoothing=0 deveria alcançar o alvo", fastSnap.targetFound)
        assertTrue("smoothing=0.9 deveria alcançar o alvo em poucos frames (state=${slowSnap.state})",
            slowSnap.targetFound)
    }

    // ============================================================ 14. diferentes resoluções

    @Test
    fun worksOnDifferentFrameResolutions() {
        // mesma posição *relativa* (0.8125, 0.69) e mesmo raio relativo (0.0625 × largura)
        val cases = listOf(
            Triple(480, 216, intArrayOf(390, 150, 22, 30)),
            Triple(640, 288, intArrayOf(520, 199, 30, 40)),
            Triple(960, 540, intArrayOf(780, 373, 45, 60)),
            Triple(1280, 576, intArrayOf(1040, 398, 60, 80)),
        )
        for ((w, h, p) in cases) {
            val d = Driver(w = w, h = h)
            val (cx, cy, ir, rr) = p
            val snap = d.confirm(rod(cx, cy, ir, rr))
            val tag = "${w}x$h"
            assertTrue("$tag: não confirmou (state=${snap.state} reason=${snap.reason})", snap.targetFound)
            assertTrue(
                "$tag: centro (${snap.centerPx.x},${snap.centerPx.y}) != ($cx,$cy)",
                hypot(snap.centerPx.x - cx, snap.centerPx.y - cy) <= w * 0.012f,
            )
            assertEquals("$tag: centro normalizado em X", cx / w.toFloat(), snap.targetX, 0.02f)
            assertWindowInsideScreen(snap, tag)
        }
    }

    // ============================================================ 15. diferentes tamanhos de ROI

    @Test
    fun worksWithDifferentWindowSizes() {
        // janela pequena (botão menor), janela padrão e janela grande — todas devem encontrar o alvo
        val smallBtn = rod(512, 195, interiorR = 18, ringR = 24)
        val small = Driver(
            cfg = cfg(AppConfig.RodV8(initialRoiX = 0.72f, initialRoiY = 0.58f, roiWidth = 0.16f, roiHeight = 0.22f)),
        )
        val smallSnap = small.confirm(smallBtn)
        assertTrue(
            "ROI pequena não encontrou o botão pequeno (${smallSnap.state} reason=${smallSnap.reason})",
            smallSnap.targetFound,
        )
        assertEquals("ROI pequena não manteve o tamanho configurado", 0.16f, smallSnap.roi.width, 0.01f)

        val normal = Driver()
        val normalSnap = normal.confirm(rod(520, 199))
        assertTrue("ROI padrão não encontrou o botão", normalSnap.targetFound)

        val big = Driver(
            cfg = cfg(AppConfig.RodV8(initialRoiX = 0.30f, initialRoiY = 0.25f, roiWidth = 0.50f, roiHeight = 0.60f)),
        )
        val bigSnap = big.confirm(rod(520, 199))
        assertTrue("ROI grande não encontrou o botão (${bigSnap.state})", bigSnap.targetFound)
        assertEquals("ROI grande não manteve o tamanho configurado", 0.50f, bigSnap.roi.width, 0.01f)
        assertWindowInsideScreen(bigSnap, "ROI grande")
    }

    @Test
    fun windowOnlySearchesInsideItself() {
        // janela longe do botão: ele não pode ser "achado" fora dela
        val d = Driver(
            cfg = cfg(AppConfig.RodV8(initialRoiX = 0.00f, initialRoiY = 0.00f, roiWidth = 0.20f, roiHeight = 0.25f)),
        )
        var snap = d.last
        repeat(30) { snap = d.frame(rod(560, 210)) }
        assertFalse("achou um alvo fora da janela (${snap.centerPx.x},${snap.centerPx.y})", snap.targetFound)
        assertWindowInsideScreen(snap, "janela longe")
    }

    // ============================================================ 16. diferentes FPS

    @Test
    fun worksAtDifferentFrameRatesAndConfirmationFollowsTheMeasuredFps() {
        val needs = HashMap<Float, Int>()
        for (fps in listOf(8f, 15f, 30f, 60f)) {
            val d = Driver(fps = fps)
            val snap = d.confirm(rod(520, 199), max = 90)
            assertTrue("fps=$fps: não confirmou (state=${snap.state} reason=${snap.reason})", snap.targetFound)
            assertTrue("fps=$fps: confirmação não pode ser de 1 frame (${snap.requiredFrames})", snap.requiredFrames >= 2)
            needs[fps] = snap.requiredFrames
            // a confirmação precisa ser temporal: com FPS maior, mais frames na mesma janela de tempo
            assertTrue("fps=$fps: requiredFrames absurdo (${snap.requiredFrames})", snap.requiredFrames in 2..12)
        }
        assertTrue("a exigência de frames deve crescer com o FPS: $needs",
            needs[60f]!! >= needs[30f]!! && needs[30f]!! >= needs[8f]!!)
    }

    @Test
    fun lossAndRecoveryAreTimedNotFrameCounted() {
        // o mesmo cenário de perda, em 10 e em 60 fps, deve dar a mesma resposta *em tempo*
        for (fps in listOf(10f, 60f)) {
            val d = Driver(fps = fps)
            d.confirm(rod(520, 199))
            // 1 segundo sem alvo ≈ recuperação em andamento; 5s sem alvo ⇒ TARGET_NOT_FOUND
            var snap = d.last
            val oneSecond = (fps).roundToInt()
            repeat(oneSecond) { snap = d.frame(null) }
            assertTrue("fps=$fps: depois de 1s deveria estar tentando recuperar (state=${snap.state})",
                snap.state == RodV8State.RECOVERING || snap.state == RodV8State.TARGET_LOST)
            assertNoInventedPosition(snap, "fps=$fps")
            repeat((fps * 5).roundToInt()) { snap = d.frame(null) }
            assertTrue("fps=$fps: 5s sem alvo precisa reportar TARGET_NOT_FOUND", snap.targetNotFound)
            assertFalse("fps=$fps: sem alvo não pode haver targetFound", snap.targetFound)
        }
    }

    // ============================================================ 17. ROI nunca sai da tela

    @Test
    fun windowNeverLeavesTheScreenEvenWhenChasingATargetAtEveryBorder() {
        data class Edge(val initX: Float, val initY: Float, val cx: Int, val cy: Int, val tag: String)
        val cases = listOf(
            Edge(0.90f, 0.85f, 600, 260, "canto inferior direito"),
            Edge(0.00f, 0.00f, 30, 30, "canto superior esquerdo"),
            Edge(0.95f, 0.00f, 605, 30, "borda superior direita"),
            Edge(0.00f, 0.95f, 30, 255, "borda inferior esquerda"),
        )
        for (c in cases) {
            val d = Driver(
                cfg = cfg(
                    AppConfig.RodV8(
                        initialRoiX = c.initX, initialRoiY = c.initY,
                        roiWidth = 0.30f, roiHeight = 0.30f, deadZone = 0f, maxMovePerFrame = 0.2f,
                    ),
                ),
            )
            // persegue o botão pela borda e depois o remove
            repeat(40) { d.frame(rod(c.cx, c.cy, interiorR = 14, ringR = 20)) }
            repeat(10) { d.frame(null) }
            for (w in d.windows) {
                assertTrue(
                    "janela saiu da tela: ${w.describe()}",
                    w.isValid && w.left >= -1e-4f && w.top >= -1e-4f &&
                        w.right <= 1f + 1e-4f && w.bottom <= 1f + 1e-4f,
                )
            }
            assertWindowInsideScreen(d.last, "bordas ${c.tag}")
        }
    }

    // =========================================== TARGET_NOT_FOUND (invariantes finais §20/§21)

    @Test
    fun targetNotFoundNeverComesWithAFakeCoordinate() {
        val d = Driver()
        var notFound = 0
        var firstNotFoundFrame = -1
        for (i in 0 until 100) {
            val snap = d.frame(null)
            if (snap.targetNotFound) {
                notFound++
                if (firstNotFoundFrame < 0) firstNotFoundFrame = i
            }
            assertFalse("TARGET_NOT_FOUND não pode trazer targetFound", snap.targetFound)
            assertTrue("TARGET_NOT_FOUND não pode trazer coordenada", snap.targetX.isNaN() && snap.targetY.isNaN())
            assertTrue("confiança deve decair sem alvo (${snap.confidence})", snap.confidence <= 0.5f)
        }
        assertTrue("TARGET_NOT_FOUND nunca foi reportado em 100 frames sem alvo", notFound > 0)
        assertTrue("TARGET_NOT_FOUND deveria ser registrado no log", d.sink.any("TARGET_NOT_FOUND"))
        // e continua tentando: o orçamento reinicia, sem travar o detector
        assertTrue("primeiro TARGET_NOT_FOUND no frame $firstNotFoundFrame",
            firstNotFoundFrame <= 60)
    }

    @Test
    fun theDetectorKeepsRetryingAfterTargetNotFoundAndFindsTheTargetWhenItComesBack() {
        val d = Driver()
        assertTrue("não confirmou antes", d.confirm(rod(520, 199)).targetFound)
        var snap = d.last
        repeat(90) { snap = d.frame(null) }
        assertTrue("deveria estar em TARGET_NOT_FOUND depois de 3s sem alvo", snap.targetNotFound)
        // o botão volta para a área inicial: o detector volta a encontrá-lo sozinho
        val back = d.run(60, rod(520, 199)) { it.targetFound }
        assertTrue("não voltou a encontrar o alvo (state=${back.state} reason=${back.reason})", back.targetFound)
        assertFalse("TARGET_NOT_FOUND precisa ser limpo quando o alvo volta", back.targetNotFound)
    }

    // ============================================================ configuração e logs

    @Test
    fun windowStartsAtTheConfiguredPositionAndSize() {
        val cfg = cfg(AppConfig.RodV8(initialRoiX = 0.10f, initialRoiY = 0.20f, roiWidth = 0.25f, roiHeight = 0.30f))
        val d = Driver(cfg = cfg)
        val first = d.frame(null)
        assertEquals("estado inicial", RodV8State.INITIAL, first.state)
        assertEquals("roiX inicial", 0.10f, first.roi.left, 0.01f)
        assertEquals("roiY inicial", 0.20f, first.roi.top, 0.01f)
        assertEquals("largura inicial", 0.25f, first.roi.width, 0.01f)
        assertEquals("altura inicial", 0.30f, first.roi.height, 0.01f)
        // e depois do primeiro frame o detector está realmente procurando
        val second = d.frame(null)
        assertEquals("estado seguinte", RodV8State.SEARCHING, second.state)
    }

    @Test
    fun walksTheSpecifiedStateSequence() {
        val d = Driver()
        var snap = d.last
        repeat(10) { snap = d.frame(null) }
        assertTrue("SEARCHING precisa aparecer procurando sem alvo: ${d.states}", d.states.contains(RodV8State.SEARCHING))
        val confirmedIdx = d.states.size
        d.run(20, rod(520, 199)) { it.state == RodV8State.TRACKING }
        assertTrue("TRACKING precisa aparecer depois de achar o alvo",
            d.indexOfFirst(RodV8State.TRACKING) >= 0)
        assertTrue("TRACKING só depois de SEARCHING",
            d.indexOfFirst(RodV8State.SEARCHING) < d.indexOfFirst(RodV8State.TRACKING))
        d.run(80, null) { it.targetNotFound }
        assertTrue("TARGET_LOST precisa aparecer na perda", d.states.contains(RodV8State.TARGET_LOST))
        assertTrue("RECOVERING precisa aparecer depois da perda", d.states.contains(RodV8State.RECOVERING))
        val trackingIdx = d.indexOfFirst(RodV8State.TRACKING)
        val lostIdx = d.states.indexOfLast { it == RodV8State.TARGET_LOST }
        val recoveringIdx = d.states.indexOfLast { it == RodV8State.RECOVERING }
        assertTrue("a ordem precisa ser TRACKING → TARGET_LOST → RECOVERING", trackingIdx < lostIdx && lostIdx <= recoveringIdx)
        assertTrue("confirmedIdx válido", confirmedIdx >= 0)
    }

    @Test
    fun logsExplainEveryDecision() {
        val d = Driver()
        d.run(10, null)
        val snap = d.confirm(rod(520, 199))
        assertTrue("alvo deveria ter sido confirmado", snap.targetFound)
        assertTrue("faltou o log de TARGET_FOUND", d.sink.any("[ROD_V8] TARGET_FOUND"))
        assertTrue("faltou a janela no log", d.sink.any("roi="))
        assertTrue("faltou o resumo da configuração da janela",
            d.last.configSummary.contains("janela=") && d.last.configSummary.contains("maxMove="))
        assertTrue("faltou o estado no log", d.sink.any("[STATE] ROD_V8="))
        d.run(20, null)
        assertTrue("faltou TARGET_LOST no log", d.sink.any("TARGET_LOST"))
    }

    @Test
    fun detectorNeverImportsOrCallsTheInputLayer() {
        // §17: a V8 não executa input — nem por referência direta no código-fonte
        val path = listOf(
            java.io.File("src/main/kotlin/com/fischa/core/vision/RodDetectionV8.kt"),
            java.io.File("core/src/main/kotlin/com/fischa/core/vision/RodDetectionV8.kt"),
        ).firstOrNull { it.exists() }
        assertNotNull("fonte da V8 não encontrada (cwd=${java.io.File(".").absolutePath})", path)
        val raw = path!!.readText()
        // o código (sem comentários) não pode tocar em nada da camada de input
        val code = raw
            .replace(Regex("/\\*[\\s\\S]*?\\*/"), "")
            .replace(Regex("//[^\\n]*"), "")
        val forbidden = listOf(
            "dispatchGesture", "performAction", "AndroidInputExecutor", "InputExecutor",
            "InputRequest", "GestureAction", "InputSafetyGuard", "GestureTarget",
            "com.fischa.core.control", "com.fischa.core.safety",
        )
        for (token in forbidden) {
            assertFalse("V8 não pode referenciar '$token' no código", code.contains(token))
        }
        // e o resultado é exatamente o contrato da spec §17
        val result = RodV8Result()
        assertFalse(result.targetFound)
        assertTrue("targetX deve ser NaN por padrão", result.targetX.isNaN())
        assertTrue("targetY deve ser NaN por padrão", result.targetY.isNaN())
        assertEquals(0f, result.confidence, 0f)
        assertEquals(RodV8State.INITIAL, result.state)
    }
}
