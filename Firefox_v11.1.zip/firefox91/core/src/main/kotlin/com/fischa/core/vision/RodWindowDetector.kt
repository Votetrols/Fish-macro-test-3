package com.fischa.core.vision

import com.fischa.core.calib.CalibrationConfig
import com.fischa.core.common.RectF
import com.fischa.core.config.AppConfig
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * **The visual mechanism** of the rod detector, shared by both search policies.
 *
 * The project already had a rod detection that *works* on a region of the frame: a cheap coarse
 * dark-disc pass ([CoarseScanner]) → full-resolution disc verification ([DiscMatcher]) →
 * dark-blob measurement (sub-cell centre + footprint) → scored features
 * (shape/size/contrast/position/temporal/identity — [RodScorer]). What the V7 policy wrapped
 * around it was an *auto-calibrated wide search*; what the V8 policy wraps around it is a
 * *moving window* (see [RodDetectionV8]).
 *
 * This class holds the mechanism only — it answers "given this pixel region, is there a rod
 * button inside it, and how convincing is it?" — and knows nothing about *where* the region came
 * from, about state machines, timing, or input. Nothing here ever touches input.
 *
 * The search-policy knobs (steps, limits, strides) are passed in by the caller; the *visual*
 * tuning (weights, interior brightness ceiling) comes from the V7 tuning block
 * ([AppConfig.RodV7]) because that is exactly the mechanism already validated on device — the V8
 * policy reuses it explicitly instead of re-deriving a second, unproven one.
 */
class RodWindowDetector(
    private val search: AppConfig.RodV7,
) {
    /** exposed so the calibration stage can read the coarse map statistics of the last [scan] */
    val scanner = CoarseScanner()
    private val refiner = DiscMatcher(24)
    private val refineScore = DiscMatcher.Score()

    /** weighted feature combiner; shared so that adaptation learned in one policy helps the other */
    val scorer = RodScorer(search.weights)

    /** coarse hits of the last [scan], best first (reused between frames) */
    val hits = ArrayList<CoarseScanner.Hit>(24)

    // ---- blob measurement scratch (no allocation per frame) --------------------------------
    private val scratchSamples = IntArray(12)

    /** centre/radius/fill of the dark blob measured by the last successful [measureBlob] */
    var blobCx = 0f
        private set
    var blobCy = 0f
        private set
    var blobRadius = 0f
        private set
    var blobInteriorGray = 0
        private set
    var blobBackgroundGray = 0
        private set
    var blobFill = 0f
        private set

    /** winning candidate of the last [refine] (already score-weighted cluster centroid) */
    val best = RodCandidate()

    /** human readable list of the clusters of the last [refine] (logs/overlay) */
    var detail = ""
        private set

    /** number of coarse hits produced by the last [scan] */
    val hitCount: Int get() = hits.size

    /**
     * Scans [regionPx] (`[x0, y0, x1, y1]`, processing pixels) for dark discs whose ring is
     * brighter than their interior and their surroundings. The coarse map is built only over the
     * requested region (plus the ring margin), which is why a small window costs almost nothing.
     */
    fun scan(
        frame: VisionFrame,
        regionPx: IntArray,
        calib: CalibrationConfig,
        step: Int,
        limit: Int,
        centerStride: Int,
    ) {
        val w = frame.width
        val minRc = max(2f, calib.minRadiusPx(w).toFloat() / step)
        val maxRc = max(minRc + 1f, calib.maxRadiusPx(w).toFloat() / step)
        // the coarse map is built ONLY over the region about to be scanned, expanded just enough
        // for the ring samples of the border candidates to stay inside the frame
        val marginPx = ((maxRc + 2f) * step).toInt()
        val expanded = intArrayOf(
            (regionPx[0] - marginPx).coerceAtLeast(0),
            (regionPx[1] - marginPx).coerceAtLeast(0),
            (regionPx[2] + marginPx).coerceAtMost(frame.width),
            (regionPx[3] + marginPx).coerceAtMost(frame.height),
        )
        scanner.prepare(frame, step, expanded)
        scanner.scan(
            regionPx, minRc, maxRc,
            limit = limit,
            centerStride = centerStride,
            interiorMaxGray = search.interiorMaxGray.toFloat(),
            out = hits,
        )
    }

    /**
     * Turns the coarse hits of the last [scan] into fully measured, scored candidates.
     *
     * For every surviving hit: (1) the dark blob it points at is measured with an adaptive
     * threshold → true centre and footprint, independent of the coarse grid; (2) the ring is
     * verified at full resolution around that blob; (3) the remaining features (roundness, dark
     * fill, hook glyph, white text, temporal persistence) are measured and scored. Candidates that
     * fall on the same physical button are merged into one cluster (score-weighted centroid), so
     * the reported centre does not hop between near-identical boxes.
     *
     * @param persistence temporal feature: how often this position was a candidate recently
     * @param maxRefine how many coarse hits are refined per frame
     * @param out receives every surviving candidate (cleared first)
     * @return number of candidates that survived (0 → nothing was found in the region)
     */
    fun refine(
        frame: VisionFrame,
        step: Int,
        calib: CalibrationConfig,
        persistence: (Float, Float, Float) -> Float,
        maxRefine: Int,
        out: ArrayList<RodCandidate>,
    ): Int {
        out.clear()
        val w = frame.width
        val limit = min(maxRefine, hits.size)
        for (i in 0 until limit) {
            candidateFromHit(frame, hits[i], step, w, calib, persistence)?.let { out.add(it) }
        }
        best.score = 0f
        detail = ""
        if (out.isEmpty()) return 0
        out.sortByDescending { it.score }
        clusterAndPick(out, w)
        detail = clusters.joinToString(" | ") { cl ->
            val cs = cl.sumX / cl.weight
            val cyv = cl.sumY / cl.weight
            "(${cs.toInt()},${cyv.toInt()},r${cl.r.toInt()})=${"%.2f".format(cl.lead.score)}"
        }
        return out.size
    }

    // ---------------------------------------------------------------------------------------
    private class Cluster {
        var sumX = 0f
        var sumY = 0f
        var weight = 0f
        var r = 0f
        var merged = 1
        val lead = RodCandidate()
    }

    private val clusters = ArrayList<Cluster>(8)

    private fun w8(score: Float): Float = if (score > 0.02f) score else 0.02f

    /**
     * Merges candidates that describe the same physical button and picks the strongest one,
     * exposing it through [best] (score-weighted centroid = sub-pixel stable centre).
     */
    private fun clusterAndPick(candidates: List<RodCandidate>, w: Int) {
        clusters.clear()
        for (c in candidates) {
            var hitCluster: Cluster? = null
            for (cl in clusters) {
                val dx = c.cx - cl.sumX / cl.weight
                val dy = c.cy - cl.sumY / cl.weight
                val lim = CLUSTER_LINK * max(c.r, cl.r)
                if (dx * dx + dy * dy <= lim * lim) { hitCluster = cl; break }
            }
            if (hitCluster == null) {
                val cl = Cluster()
                cl.sumX = c.cx * w8(c.score); cl.sumY = c.cy * w8(c.score); cl.weight = w8(c.score)
                cl.r = c.r
                cl.lead.copyFrom(c)
                clusters.add(cl)
            } else {
                val wc = w8(c.score)
                hitCluster.sumX += c.cx * wc
                hitCluster.sumY += c.cy * wc
                hitCluster.weight += wc
                hitCluster.r = max(hitCluster.r, c.r)
                hitCluster.merged++
                if (c.score > hitCluster.lead.score) hitCluster.lead.copyFrom(c)
            }
        }
        var choice = clusters[0]
        for (cl in clusters) if (cl.lead.score > choice.lead.score) choice = cl
        best.copyFrom(choice.lead)
        best.cx = choice.sumX / choice.weight
        best.cy = choice.sumY / choice.weight
        best.r = choice.r
        best.radiusNorm = best.r / w
        best.bounds()
    }

    /**
     * One coarse hit → one measured + scored candidate (or `null` when the hit does not survive
     * the blob/ring verification).
     */
    private fun candidateFromHit(
        frame: VisionFrame,
        hit: CoarseScanner.Hit,
        step: Int,
        w: Int,
        calib: CalibrationConfig,
        persistence: (Float, Float, Float) -> Float,
    ): RodCandidate? {
        val ccx = (hit.cx * step).toInt()
        val ccy = (hit.cy * step).toInt()
        val rr = hit.r * step
        // measure the dark blob (adaptive threshold, disc-shape check). The window is sized from
        // the *calibrated* size band: the coarse cell's radius estimate is noisy and would
        // otherwise clip a small button (biasing the centre and shrinking the footprint).
        val guessR = max(rr, calib.minRadiusPx(w).toFloat())
        if (!measureBlob(frame, ccx, ccy, guessR, search.interiorMaxGray)) return null
        val blobR = blobRadius
        // ring verification at full resolution around the blob
        val win = (blobR * 0.55f).toInt().coerceIn(3, 24)
        val s = refiner.bestDisc(
            frame,
            blobCx.toInt() - win, blobCy.toInt() - win,
            blobCx.toInt() + win, blobCy.toInt() + win,
            max(3, (blobR * 0.90f).toInt()), max(6, (blobR * 1.50f).toInt()), step = 1,
            interiorMaxGray = search.interiorMaxGray,
            minRingDelta = max(4f, calib.minRingDelta * 0.5f).toInt(),
            out = refineScore,
        )
        if (s.r <= 0) return null
        // the disc matcher verifies the ring; the *geometry* stays anchored to the measured blob
        if (s.r < blobR * 0.70f) return null
        val cand = RodCandidate()
        cand.cx = blobCx
        cand.cy = blobCy
        // clamping keeps a mis-matched disc from inflating the box
        cand.r = s.r.toFloat().coerceIn(blobR, blobR * RING_MAX_INCLUSION)
        cand.radiusNorm = cand.r / w
        cand.ringDelta = s.ringDelta
        cand.interiorGray = blobInteriorGray.toFloat()
        cand.outsideGray = blobBackgroundGray.toFloat()
        cand.roundness = s.roundness
        cand.fill = refiner.interiorFrac(frame, s.cx, s.cy, s.r, 0, search.interiorMaxGray)
        cand.glyphFrac = refiner.interiorFrac(frame, s.cx, s.cy, s.r, 115, 215)
        // same band the legacy detector used for the "not a rod, it is the SHAKE prompt" test
        cand.whiteFrac = refiner.interiorFrac(frame, s.cx, s.cy, s.r, 205, 255)
        cand.persistence = persistence(cand.cx / w, cand.cy / frame.height, cand.radiusNorm)
        cand.bounds()
        scorer.score(cand, calib, w, frame.height)
        return cand
    }

    /**
     * Measures the dark blob a coarse hit refers to: adaptive threshold between the local interior
     * (sampled on a ring inside the disc, robust to the hook glyph) and the window background
     * (corner samples). Fills [blobCx]/[blobCy]/[blobRadius]/[blobInteriorGray]/
     * [blobBackgroundGray]/[blobFill].
     *
     * @return true when a disc-shaped dark blob consistent with the expected size was found.
     */
    fun measureBlob(frame: VisionFrame, cx: Int, cy: Int, guessR: Float, interiorMax: Int): Boolean {
        val half = (guessR * 1.6f + 5f).toInt().coerceIn(8, 220)
        val x0 = (cx - half).coerceIn(0, frame.width - 1)
        val x1 = (cx + half).coerceIn(0, frame.width - 1)
        val y0 = (cy - half).coerceIn(0, frame.height - 1)
        val y1 = (cy + half).coerceIn(0, frame.height - 1)
        if (x1 - x0 < 8 || y1 - y0 < 8) return false

        // interior estimate: samples on a ring *inside* the disc (0.45·guess — outside the hook
        // glyph, inside the ring) and take a low percentile, so neither the glyph nor a partially
        // occluded edge can pull the threshold up and swallow the ring.
        val sr = (guessR * 0.45f).coerceAtLeast(2f)
        val samples = scratchSamples
        for (i in 0 until samples.size) {
            val a = Math.PI * 2.0 * i / samples.size
            val sx = (cx + Math.cos(a) * sr).toInt().coerceIn(x0, x1)
            val sy = (cy + Math.sin(a) * sr).toInt().coerceIn(y0, y1)
            samples[i] = frame.grayAt(sx, sy)
        }
        samples.sort()
        val interior = samples[1]

        // background: the four window corners (median-ish) — the world behind the button
        val bg = medianOfFour(
            cornerMean(frame, x0, y0), cornerMean(frame, x1, y0),
            cornerMean(frame, x0, y1), cornerMean(frame, x1, y1),
        )
        if (bg - interior < 6) return false // not darker than its surroundings → not a button blob
        // adaptive threshold: clearly above the dark interior, clearly below the ring/background
        val thr = (interior + min(0.40f * (bg - interior), 45f)).toInt()
            .coerceIn(interior + 5, interiorMax + 45)

        var minX = x1; var maxX = x0; var minY = y1; var maxY = y0
        var dark = 0
        var y = y0
        while (y <= y1) {
            var x = x0
            while (x <= x1) {
                if (frame.grayAt(x, y) <= thr) {
                    dark++
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
                x++
            }
            y++
        }
        val bw = maxX - minX + 1
        val bh = maxY - minY + 1
        if (dark < 24 || bw < 6 || bh < 6) return false
        // disc-shaped: width ≈ height and the blob fills its bounding box like a disc (~0.78)
        val big = max(bw, bh)
        val small = min(bw, bh)
        if (small < big * 0.62f) return false
        val fill = dark.toFloat() / (bw * bh).toFloat()
        if (fill < 0.45f) return false
        val r = (bw + bh) * 0.25f
        if (r < guessR * 0.45f || r > guessR * 2.2f) return false

        blobCx = (minX + maxX) * 0.5f
        blobCy = (minY + maxY) * 0.5f
        blobRadius = r
        blobInteriorGray = interior
        blobBackgroundGray = bg
        blobFill = fill
        return true
    }

    private fun cornerMean(frame: VisionFrame, x: Int, y: Int): Int {
        var sum = 0; var n = 0
        for (dy in -3..3) {
            for (dx in -3..3) {
                val px = (x + dx).coerceIn(0, frame.width - 1)
                val py = (y + dy).coerceIn(0, frame.height - 1)
                sum += frame.grayAt(px, py); n++
            }
        }
        return sum / max(1, n)
    }

    private fun medianOfFour(a: Int, b: Int, c: Int, d: Int): Int {
        val lo = min(min(a, b), min(c, d))
        val hi = max(max(a, b), max(c, d))
        val mid1 = if (a in lo..hi && a != lo && a != hi) a
        else if (b in lo..hi && b != lo && b != hi) b
        else if (c != lo && c != hi) c else d
        val mid2 = when {
            a != lo && a != hi && a != mid1 -> a
            b != lo && b != hi && b != mid1 -> b
            c != lo && c != hi && c != mid1 -> c
            else -> d
        }
        return (mid1 + mid2) / 2
    }

    companion object {
        /** the debug box covers the button including its ring: blob radius × this factor */
        private const val RING_MAX_INCLUSION = 1.35f

        /** two candidates closer than this × radius belong to the same physical button */
        private const val CLUSTER_LINK = 0.6f
    }
}

/**
 * Short memory of recent candidate positions, used as the *temporal* feature of the score: a
 * position that keeps showing a candidate is worth more than a one-off blob. All coordinates are
 * normalized, so the same history works at any resolution.
 */
class CandidateHistory(private val size: Int = 12) {
    private val xs = FloatArray(size.coerceAtLeast(2))
    private val ys = FloatArray(size.coerceAtLeast(2))
    private var count = 0
    private var head = 0

    val samples: Int get() = count

    fun remember(nx: Float, ny: Float) {
        xs[head] = nx
        ys[head] = ny
        head = (head + 1) % xs.size
        count = min(xs.size, count + 1)
    }

    fun reset() {
        count = 0
        head = 0
    }

    /** 0..1 persistence of a candidate at ([nx], [ny]) (a brand-new sighting gets a neutral value) */
    fun persistenceAt(nx: Float, ny: Float, radiusNorm: Float): Float {
        if (count == 0) return 0f
        val tol = max(0.012f, radiusNorm * 2f)
        var hits = 0
        for (i in 0 until count) {
            if (abs(xs[i] - nx) + abs(ys[i] - ny) <= tol) hits++
        }
        val ratio = hits.toFloat() / count
        return if (hits == 0) 0.15f else (0.35f + 0.65f * ratio).coerceIn(0f, 1f)
    }
}

/** Small helper used by the V8 policy: a pixel rectangle it can fill without allocating. */
internal fun RectF.setFromRegion(region: com.fischa.core.common.NormRegion, w: Int, h: Int) {
    set(region.left * w, region.top * h, region.right * w, region.bottom * h)
}
