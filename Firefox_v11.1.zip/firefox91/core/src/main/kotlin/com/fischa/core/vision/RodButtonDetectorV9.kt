package com.fischa.core.vision

import com.fischa.core.common.NormRegion
import com.fischa.core.common.PointF
import com.fischa.core.common.RectF
import com.fischa.core.config.AppConfig
import com.fischa.core.log.Tags
import com.fischa.core.log.ThrottledLog
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * §4 — estágio do pipeline visual do frame (publicado apenas no debug §8).
 *
 * `SEARCH` = procurando estrutura na janela; `HYPOTHESES` = hipóteses nascidas da imagem;
 * `SCORE` = hipóteses medidas e pontuadas; `TEMPORAL` = confirmação ao longo dos frames.
 */
enum class RodV9Stage { SEARCH, HYPOTHESES, SCORE, TEMPORAL }

/**
 * **Detector visual do botão da vara — V9.**
 *
 * Este é o único ponto do projeto onde o botão é *descoberto visualmente*: ele recebe o frame e a
 * ROI móvel (a V8 continua dona da janela, dos estados e da recuperação) e devolve **candidatos
 * com evidência medida**, nunca uma ordem de input (§10).
 *
 * ## O que mudou em relação ao detector antigo
 *
 * O detector antigo (V6/V7/V8) procurava **um disco escuro com um anel claro** em posições
 * varridas por uma grade. Se o botão real não tivesse essa aparência, nada era encontrado; e a
 * grade varria água/céu/personagem e produzia candidatos falsos que o resto do sistema tinha de
 * filtrar depois.
 *
 * A V9 **não** procura forma nem posição: ela procura **estrutura** que se comporte como um
 * elemento de interface, com múltiplas evidências medidas no próprio frame e entre frames:
 *
 *  1. **onde há hipótese** — os pixels de borda forte, os pixels que **mudaram** desde o frame
 *     anterior e as **faces estáveis e lisas** são agrupados em componentes conexos. Cada
 *     componente é uma hipótese; a grade de posições acabou.
 *  2. **onde está o contorno** — de cada hipótese parte-se do centro para fora: 24 direções
 *     amostram o **raio** onde a borda é mais forte *e* coerente com a direção radial (perfil de
 *     raio agregado, resistente a detalhe interno como o ícone do botão). O contorno pode ser
 *     circular, quadrado arredondado ou irregular — o que se mede é **fechamento + coerência**,
 *     nunca "ser um disco".
 *  3. **como é por dentro e por fora** — uniformidade, textura, contraste da face contra o anel e
 *     contra o entorno, fração de pixels claros (texto), cromaticidade.
 *  4. **como se comporta no tempo** — o contorno e a face ficam onde estavam? A água, o reflexo e
 *     a partícula mudam; o botão, não. Um elemento que aparece do nada precisa **persistir**.
 *
 * Cada candidato carrega os sinais medidos e um `score` (soma ponderada com **pesos
 * configuráveis** — §11), e o alvo só existe depois de **vários frames compatíveis** (§5). Sem
 * candidato, o detector devolve `targetFound = false` com `targetX/targetY = NaN` — posição
 * inventada nunca é publicada (§14), e a ROI estar em cima do lugar esperado **não** significa
 * que o botão existe.
 *
 * Nenhum caminho deste arquivo executa input: só leitura do frame (e do frame anterior guardado
 * em buffer próprio) e escrita do resultado.
 */
class RodButtonDetectorV9(
    private val cfg: AppConfig.RodButtonV9,
    private val log: ThrottledLog? = null,
) {
    // =============================================================================================
    //  estado publicado (sempre recriado frame a frame — nada de posição herdada)
    // =============================================================================================

    private val out = RodButtonV9Result()
    private val candidates = ArrayList<RodButtonCandidateV9>(MAX_CANDIDATES_KEEP)
    private val hyps = ArrayList<Hyp>(24)

    /** motivos de descarte deste frame (diagnóstico §9) — na ordem de avaliação. */
    val lastRejections = ArrayList<String>(MAX_REJECT_NOTES)

    /** §4 — estágio do pipeline visual neste frame. */
    var stage: RodV9Stage = RodV9Stage.SEARCH
        private set

    /** estado **visual** do detector (`SEARCHING`/`CANDIDATE`/`CONFIRMING`/`CONFIRMED`/`LOST`). */
    var state: RodButtonV9State = RodButtonV9State.SEARCHING
        private set

    private var confirmedX = Float.NaN
    private var confirmedY = Float.NaN
    private var confirmedNs = 0L
    private var lastNs = 0L
    private var everConfirmed = false

    /** posição normalizada da última confirmação (`NaN` enquanto nunca confirmou). */
    val lastConfirmedX: Float get() = confirmedX
    val lastConfirmedY: Float get() = confirmedY

    /** ms desde a última confirmação (`Long.MAX_VALUE` enquanto nunca confirmou). */
    var msSinceConfirmed: Long = Long.MAX_VALUE
        private set

    /** o detector está ligado pela configuração? */
    val isEnabled: Boolean get() = cfg.rodButtonDetectionEnabled

    // streak de confirmação temporal (§5)
    private var streak = 0
    private var anchorX = 0f
    private var anchorY = 0f
    private var streakStartNs = 0L
    private var confidence = 0f

    private var template: RodTemplateV9? = null

    /** memória temporal entre frames (estabilidade de posição/aparência — §5/§6). */
    private val history = RodV9TemporalMemory(cfg.historyFrames)

    private val data = RoiWorkspace()
    private val profile = RayProfile()

    /** segunda medida de contorno (âncora no alvo anterior) — nunca aloca por frame. */
    private val profileAlt = RayProfile()
    private val probe = Probe()
    private val sigScratch = IntArray(16)

    // =============================================================================================
    //  §9 — template visual opcional (nunca obrigatório)
    // =============================================================================================

    /** carrega o template do usuário (JSON gerado pelo `RodFrameLab`). */
    fun loadTemplate(json: String?): Boolean {
        if (json.isNullOrBlank()) return false
        val t = RodTemplateV9.parse(json) ?: return false
        template = t
        log?.i(Tags.ROD_V9, "template", "[ROD_V9] template carregado (${t.w}x${t.h}px)")
        return true
    }

    fun clearTemplate() {
        template = null
    }

    /** resumo do que está ligado (vai para o debug §8). */
    fun configSummary(): String =
        "v9(enabled=${cfg.rodButtonDetectionEnabled} minConf=${cfg.minimumConfidence} " +
            "frames=${cfg.confirmationFrames}+${cfg.targetConfirmMs.toInt()}ms cands=${cfg.maxCandidates} " +
            "pesos[vm=${cfg.visualMatchWeight} ct=${cfg.contrastWeight} ed=${cfg.edgeWeight} " +
            "tp=${cfg.temporalWeight} sp=${cfg.spatialWeight} tr=${cfg.trackingWeight}] " +
            "faixa=${cfg.minSizeNormalized}..${cfg.maxSizeNormalized} template=${template != null})"

    /** limpa o histórico (troca de cena / novo alvo). */
    fun reset() {
        reset(true)
    }

    fun reset(freshConfirmation: Boolean) {
        history.reset()
        data.reset()
        everConfirmed = false
        confirmedX = Float.NaN
        confirmedY = Float.NaN
        confirmedNs = 0L
        msSinceConfirmed = Long.MAX_VALUE
        lastNs = 0L
        state = RodButtonV9State.SEARCHING
        stage = RodV9Stage.SEARCH
        if (freshConfirmation) {
            streak = 0
            anchorX = 0f
            anchorY = 0f
            streakStartNs = 0L
            confidence = 0f
        }
    }

    // =============================================================================================
    //  frame
    // =============================================================================================

    /**
     * Processa **um** frame dentro da janela [roi] (normalizada).
     *
     * @param tracking true quando a máquina já tem alvo (a janela está seguindo um alvo confirmado)
     * @param recovering true durante a escada de recuperação (aí procurar longe é o objetivo)
     * @return o resultado do frame — nenhum outro efeito colateral
     */
    fun update(
        frame: VisionFrame,
        roi: NormRegion,
        nowNs: Long,
        fps: Float,
        tracking: Boolean,
        recovering: Boolean,
    ): RodButtonV9Result {
        val w = frame.width
        val h = frame.height
        out.reset()
        out.frameW = w
        out.frameH = h
        out.frameTimestampNs = nowNs
        out.roiRegion = roi
        out.detectorEnabled = cfg.rodButtonDetectionEnabled
        out.lastKnownX = confirmedX
        out.lastKnownY = confirmedY
        msSinceConfirmed = if (confirmedNs == 0L) Long.MAX_VALUE else (nowNs - confirmedNs) / 1_000_000L
        out.msSinceConfirmed = msSinceConfirmed
        out.templateUsed = cfg.useTemplate && template != null
        lastRejections.clear()
        stage = RodV9Stage.SEARCH

        if (!cfg.rodButtonDetectionEnabled) {
            state = RodButtonV9State.DISABLED
            out.state = state
            out.reason = "rodButtonDetectionEnabled=false"
            lastNs = nowNs
            return out
        }

        val roiPx = roiPx(roi, w, h)
        if (roiPx[2] - roiPx[0] < 12 || roiPx[3] - roiPx[1] < 12) {
            state = RodButtonV9State.SEARCHING
            out.state = state
            out.reason = "ROI degenerada ${roi.describe()}"
            miss()
            lastNs = nowNs
            return out
        }

        val fpsSafe = if (fps.isFinite() && fps > 1f) fps else 30f
        val p = Params(w, h, fpsSafe, cfg)

        // ---- §4/§6: prepara os mapas da janela (cinza, gradiente, borda, mudança) ---------------
        data.prepare(frame, roiPx)
        stage = RodV9Stage.HYPOTHESES

        // ---- §3: hipóteses nascem da ESTRUTURA da imagem, não de uma grade de posições ---------
        collectHypotheses(p)
        out.proposals = hyps.size

        // ---- §3: mede cada hipótese e transforma em candidato pontuado -------------------------
        stage = RodV9Stage.SCORE
        candidates.clear()
        for (hyp in hyps) {
            val c = measure(hyp, p, tracking, recovering)
            if (c != null) candidates.add(c)
        }
        if (candidates.size > 1) candidates.sortByDescending { it.score }
        while (candidates.size > cfg.maxCandidates) candidates.removeAt(candidates.size - 1)

        out.candidates = candidates.size
        out.rejections = lastRejections.size
        for (c in candidates) out.candidateData.add(c.snapshot())
        val best = candidates.firstOrNull()
        out.bestScore = best?.score ?: 0f
        out.chosenIndex = if (best != null) 0 else -1
        if (best != null) {
            out.bestCxPx = best.cx
            out.bestCyPx = best.cy
            out.bestRadiusPx = best.r
            out.bestXNorm = best.cx / w
            out.bestYNorm = best.cy / h
            out.box.set(best.box)
        }

        // ---- §5: confirmação temporal (um frame isolado nunca é um alvo) -----------------------
        stage = RodV9Stage.TEMPORAL
        if (best == null) {
            miss()
            out.reason = "nenhum elemento de interface na ROI (${out.proposals} hipóteses" +
                (if (lastRejections.isEmpty()) "" else "; ${lastRejections.first()}") + ")"
            lastNs = nowNs
            return out
        }

        out.candidateFound = true
        val required = requiredFrames(fpsSafe)
        val nx = best.cx / w
        val ny = best.cy / h
        buildSignature(frame, best.cx.toInt(), best.cy.toInt(), best.r, sigScratch)
        val temporalStability = history.stabilityAt(nx, ny, best.radiusNorm, sigScratch)

        val driftTol = max(DRIFT_TOL_MIN, DRIFT_TOL_FACTOR * best.radiusNorm)
        val keepsStreak = streak > 0 && nowNs - streakStartNs <= cfg.confirmWindowMs * 1_000_000L &&
            abs(nx - anchorX) + abs(ny - anchorY) <= driftTol
        if (keepsStreak) {
            streak++
        } else {
            streak = 1
            anchorX = nx
            anchorY = ny
            streakStartNs = nowNs
        }
        history.remember(nx, ny, best.radiusNorm, best.score, sigScratch)

        val gain = min(1f, streak.toFloat() / required)
        confidence = (best.score * (0.72f + 0.28f * gain)).coerceIn(0f, 1f)
        val stableEnough = temporalStability >= cfg.minTemporalStability || streak >= required
        val confirmed = streak >= required &&
            best.score >= cfg.minimumConfidence &&
            confidence >= cfg.minimumConfidence &&
            stableEnough

        out.state = when {
            confirmed -> RodButtonV9State.CONFIRMED
            streak > 1 -> RodButtonV9State.CONFIRMING
            else -> RodButtonV9State.CANDIDATE
        }
        state = out.state
        out.score = best.score
        out.confidence = confidence
        out.confirmation = streak
        out.requiredFrames = required
        out.anchorX = anchorX
        out.anchorY = anchorY
        out.temporalStability = temporalStability

        if (confirmed) {
            val dx = if (confirmedX.isFinite()) nx - confirmedX else 0f
            val dy = if (confirmedY.isFinite()) ny - confirmedY else 0f
            out.jumpNorm = sqrt(dx * dx + dy * dy)
            confirmedX = nx
            confirmedY = ny
            confirmedNs = nowNs
            everConfirmed = true
            msSinceConfirmed = 0L
            out.msSinceConfirmed = 0L
            out.lastKnownX = nx
            out.lastKnownY = ny
            out.targetFound = true
            out.targetX = nx
            out.targetY = ny
            out.centerPx.x = best.cx
            out.centerPx.y = best.cy
            out.radiusPx = best.r
            out.box.set(best.box)
            out.reason = "TARGET_FOUND confirmado $streak/$required frames " +
                "(score=${"%.2f".format(best.score)} conf=${"%.2f".format(confidence)} " +
                "sinais[vm=${"%.2f".format(best.visualMatch)} ct=${"%.2f".format(best.localContrast)} " +
                "ed=${"%.2f".format(best.edgeEvidence)} fc=${"%.2f".format(best.regionStrength)} " +
                "ru=${"%.2f".format(best.roundness)} tp=${"%.2f".format(best.temporalScore)} " +
                "sp=${"%.2f".format(best.spatialScore)} tr=${"%.2f".format(best.trackingScore)}])"
            log?.i(
                Tags.ROD_V9, "found",
                "[ROD_V9] TARGET_FOUND c=(${(best.cx).toInt()},${(best.cy).toInt()}) " +
                    "r=${"%.1f".format(best.r)} score=${"%.2f".format(best.score)} " +
                    "conf=${"%.2f".format(confidence)} streak=$streak/$required " +
                    "hipoteses=${out.proposals} origem=${best.seed}",
            )
        } else {
            out.targetFound = false
            out.targetX = Float.NaN
            out.targetY = Float.NaN
            out.reason = when {
                best.score < cfg.minimumConfidence ->
                    "confirmando: score ${"%.2f".format(best.score)} < mínimo " +
                        "${"%.2f".format(cfg.minimumConfidence)}"
                !stableEnough ->
                    "confirmando: instabilidade temporal ${"%.2f".format(temporalStability)}"
                else -> "confirmando $streak/$required (conf ${"%.2f".format(confidence)})"
            }
            log?.d(
                Tags.ROD_V9, "confirming",
                "[ROD_V9] candidato c=(${(best.cx).toInt()},${(best.cy).toInt()}) " +
                    "score=${"%.2f".format(best.score)} conf=${"%.2f".format(confidence)} " +
                    "streak=$streak/$required origem=${best.seed}",
            )
        }
        lastNs = nowNs
        return out
    }

    // =============================================================================================
    //  §3/§4 — hipóteses a partir da estrutura da imagem
    // =============================================================================================

    /**
     * Três famílias de hipóteses, nenhuma delas obrigatória (o botão pode aparecer por contorno,
     * por mudança de cena, ou por face estável cujo contorno é tênue):
     *
     *  * **CONTOUR** — componentes de borda forte: o contorno de um elemento de interface;
     *  * **CHANGE** — componentes do que mudou entre este frame e o anterior: algo apareceu/sumiu;
     *  * **FACE** — componentes estáveis e lisas (a face do elemento, que não se move com a água).
     */
    private fun collectHypotheses(p: Params) {
        hyps.clear()
        // 1) contornos: pixels com gradiente forte
        val contourPixels = max(20, (p.rMin * 0.35f * (p.rMin * 0.35f)).toInt())
        data.components(contourPixels, Source.CONTOUR) { x, y -> data.edgeAt(x, y) >= p.edgeThreshold }
            .forEach { addHyp(it, Source.CONTOUR, p) }
        // 2) mudança entre frames (elemento que apareceu/sumiu/piscou)
        if (data.prevValid) {
            val changePixels = max(20, (p.rMin * 0.45f * (p.rMin * 0.45f)).toInt())
            data.components(changePixels, Source.CHANGE) { x, y -> data.temporalAt(x, y) >= p.changeTol }
                .forEach { addHyp(it, Source.CHANGE, p) }
        }
        // 3) faces estáveis e lisas (o botão para de mudar; a água não)
        val facePixels = max(24, (p.rMin * 0.5f * (p.rMin * 0.5f)).toInt())
        data.components(facePixels, Source.FACE) { x, y ->
            data.temporalAt(x, y) <= p.stableTol && data.edgeAt(x, y) < p.edgeThreshold
        }.forEach { addHyp(it, Source.FACE, p) }
    }

    /** aceita um componente conexo como hipótese (tamanho plausível, dentro da janela). */
    private fun addHyp(h: Hyp, source: Source, p: Params) {
        h.source = source
        if (h.boundingAspect > SEED_MAX_BOUNDING_ASPECT) {
            reject(
                Reject.ELONGATED,
                "${source.label} alongada em (${h.cx.toInt()},${h.cy.toInt()}) " +
                    "(aspecto ${"%.2f".format(h.boundingAspect)})",
            )
            return
        }
        if (h.rMoment < p.rMin * 0.45f || h.rMoment > p.rMax * 1.6f) {
            reject(
                if (h.rMoment < p.rMin) Reject.TINY else Reject.HUGE,
                "${source.label} com raio ${"%.1f".format(h.rMoment)}px fora da faixa " +
                    "${"%.1f".format(p.rMin)}..${"%.1f".format(p.rMax)}px",
            )
            return
        }
        if (!data.insideRoi(h.cx.toInt(), h.cy.toInt())) return
        // dedupe: hipóteses vizinhas já aceitas (a mesma coisa vista por outra máscara)
        for (o in hyps) {
            if (abs(o.cx - h.cx) + abs(o.cy - h.cy) < max(2f, 0.5f * min(o.rMoment, h.rMoment))) return
        }
        hyps.add(h.copyOf())
    }

    /**
     * Mede a hipótese e devolve o candidato — ou `null` com o motivo em [lastRejections] (§6).
     *
     * A ordem importa: primeiro o que é estrutural (contorno, forma, tamanho, texto), depois a
     * pontuação dos sinais. Nada aqui é "ser um disco escuro".
     */
    private fun measure(h: Hyp, p: Params, tracking: Boolean, recovering: Boolean): RodButtonCandidateV9? {
        stage = RodV9Stage.SCORE

        // ---- perfil de raio: 24 direções, borda mais forte coerente com a direção radial ---------
        var cx = h.cx
        var cy = h.cy
        var r0 = h.rMoment
        refineContour(profile, cx, cy, r0, p, searchCentre = true)
        // §10: com um alvo já confirmado existe uma âncora melhor que o centro de momento do
        // componente (que pode vazar para a água): mede o contorno também a partir da última
        // posição conhecida e fica com a geometria de melhor qualidade — o alvo continua sendo **o
        // mesmo** elemento e o gate de salto (§7) segue cuidando de candidatos distantes.
        //
        // A âncora só **escolhe entre contornos válidos**: se a própria hipótese não tem contorno
        // (fechamento insuficiente) a hipótese é rejeitada como antes — senão a posição antiga
        // sozinha sustentaria um alvo fantasma numa cena sem botão (§14: TARGET_NOT_FOUND honesto).
        if (confirmedX.isFinite() && profile.found >= profile.nAngles * 0.6f) {
            refineContour(
                profileAlt, confirmedX * p.w, confirmedY * p.h, max(2f, h.rMoment), p,
                searchCentre = false,
            )
            if (contourQuality(profileAlt, cfg) > contourQuality(profile, cfg)) {
                profile.copyFrom(profileAlt)
            }
        }
        cx = profile.centreX
        cy = profile.centreY
        r0 = max(2f, profile.radius)
        if (profile.found < profile.nAngles * 0.6f) {
            reject(
                Reject.OPEN_CONTOUR,
                "contorno incompleto em (${cx.toInt()},${cy.toInt()}) " +
                    "(${profile.found}/${profile.nAngles} direções, pico " +
                    "${"%.1f".format(profile.radiusRef)}px, ref $r0 px)",
            )
            return null
        }
        if (profile.found < profile.nAngles * 0.6f) {
            reject(Reject.OPEN_CONTOUR, "contorno incompleto após refino em (${cx.toInt()},${cy.toInt()})")
            return null
        }

        val r = profile.radius
        val radiusNorm = r / p.w
        val closure = profile.found.toFloat() / profile.nAngles
        if (r < p.rMin || r > p.rMax) {
            reject(
                if (r < p.rMin) Reject.TINY else Reject.HUGE,
                "raio ${"%.1f".format(r)}px fora da faixa " +
                    "${"%.1f".format(p.rMin)}..${"%.1f".format(p.rMax)}px",
            )
            return null
        }
        val roughness = profile.spread
        if (roughness > cfg.maxProfileRoughness) {
            reject(
                Reject.RAGGED,
                "contorno irregular em (${cx.toInt()},${cy.toInt()}) " +
                    "(variação de raio ${"%.2f".format(roughness)})",
            )
            return null
        }
        if (closure < cfg.minBoundaryClosure) {
            reject(
                Reject.OPEN_CONTOUR,
                "fechamento ${"%.2f".format(closure)} < ${"%.2f".format(cfg.minBoundaryClosure)}",
            )
            return null
        }
        val align = profile.alignment
        if (align < cfg.minBoundaryAlign) {
            reject(Reject.OPEN_CONTOUR, "orientação de borda incoerente (${"%.2f".format(align)})")
            return null
        }

        val roi = out.roiRegion
        if (!roi.contains(cx / p.w, cy / p.h)) {
            reject(Reject.OUTSIDE_ROI, "centro fora da ROI")
            return null
        }
        if (cx - r < 0f || cy - r < 0f || cx + r >= p.w || cy + r >= p.h) {
            reject(Reject.FRAME_EDGE, "contorno cortado pela borda do frame")
            return null
        }

        // ---- face, anel e entorno ---------------------------------------------------------------
        // a face medida é a **superfície lisa** do elemento: os traços do ícone (pixels que são
        // borda) não entram na estatística da face — senão um botão COM ícone seria reprovado por
        // "textura" apesar de a face ser uniforme (medido: era o que rejeitava o contorno do
        // botão inteiro e deixava passar um fragmento interno mais liso que ele).
        data.interiorStats(cx, cy, r * INTERIOR_FACTOR, probe, p.edgeThreshold)
        if (probe.count < 16) return null
        val faceMean = probe.mean
        val faceStd = probe.std
        val texture = (faceStd / TEXTURE_SAT).coerceIn(0f, 1f)
        val chromaScore = (1f - probe.chroma / CHROMA_SAT).coerceIn(0f, 1f)
        data.bandStats(cx, cy, r * RING_INNER, r * RING_OUTER, probe)
        val ringMean = if (probe.count > 0) probe.mean else faceMean
        data.bandStats(cx, cy, r * OUTSIDE_INNER, r * OUTSIDE_OUTER, probe)
        val outsideMean = if (probe.count > 0) probe.mean else ringMean

        // ---- §6: texto claro em face escura (o prompt "SHAKE" tem exatamente essa cara) ---------
        val brightFraction = data.brightFraction(cx, cy, r * INTERIOR_FACTOR, BRIGHT_LEVEL)
        val textEvidence = if (faceMean < DARK_FACE_MAX) brightFraction else 0f
        if (textEvidence >= cfg.textRejectionFraction * TEXT_HARD_REJECT) {
            reject(
                Reject.TEXT,
                "texto claro em ${"%.0f".format(textEvidence * 100)}% da face " +
                    "(provável prompt sem botão)",
            )
            return null
        }
        val textPenalty = if (cfg.textRejectionFraction > 0f) {
            (textEvidence / cfg.textRejectionFraction).coerceIn(0f, 1f)
        } else {
            0f
        }

        // ---- §6: face texturizada (água, folhagem, pedra, partícula) ---------------------------
        val textureHard = (cfg.maxInteriorTexture + (1f - cfg.maxInteriorTexture) * TEXTURE_HARD)
            .coerceAtMost(0.92f)
        if (texture >= textureHard) {
            reject(Reject.TEXTURED, "face texturizada (${"%.2f".format(texture)})")
            return null
        }
        val texturePenalty = ((texture - cfg.maxInteriorTexture) /
            max(0.05f, 1f - cfg.maxInteriorTexture)).coerceIn(0f, 1f)

        // ---- §3: sinais (todos 0..1) -----------------------------------------------------------
        val uniformity = (1f - faceStd / UNIFORMITY_SAT).coerceIn(0f, 1f)
        val roundness = (1f - roughness / ROUGHNESS_SAT).coerceIn(0f, 1f)
        val contrastRaw = 0.65f * abs(faceMean - ringMean) + 0.35f * abs(faceMean - outsideMean)
        val localContrast = (contrastRaw / CONTRAST_SAT).coerceIn(0f, 1f)
        val edgeEvidence = (closure * (0.5f + 0.5f * align)).coerceIn(0f, 1f)
        val regionStrength = (profile.magnitude / EDGE_SAT).coerceIn(0f, 1f)

        val structural = data.structureAt(cx, cy, r, profile, p)
        val contourStability = structural.contourStability
        val interiorStability = structural.interiorStability
        val frameMotion = structural.frameMotion
        val temporalScore = if (!data.prevValid) 0.5f else
            (0.45f * contourStability + 0.35f * interiorStability +
                0.20f * (1f - frameMotion)).coerceIn(0f, 1f)

        val templateScore = if (cfg.useTemplate && template != null) {
            template!!.match(data.frame!!, cx.toInt(), cy.toInt(), r)
        } else {
            -1f
        }
        val uiLook = (0.40f * uniformity + 0.25f * (1f - texture) + 0.20f * roundness +
            0.15f * chromaScore).coerceIn(0f, 1f)
        val visualMatch = if (templateScore >= 0f) {
            (cfg.templateWeight * templateScore + (1f - cfg.templateWeight) * uiLook).coerceIn(0f, 1f)
        } else {
            uiLook
        }

        val relX = (cx / p.w - roi.left) / max(1e-4f, roi.width)
        val relY = (cy / p.h - roi.top) / max(1e-4f, roi.height)
        val radial = sqrt((relX - 0.5f) * (relX - 0.5f) + (relY - 0.5f) * (relY - 0.5f))
        val centrality = (1f - radial / 0.75f).coerceIn(0f, 1f)
        val sizeFit = sizeBandFit(radiusNorm)
        val spatialScore = (0.5f * centrality + 0.5f * sizeFit).coerceIn(0f, 1f)

        var trackingScore = NEUTRAL_TRACKING
        var jumpNorm = Float.NaN
        if (confirmedX.isFinite()) {
            val dx = cx / p.w - confirmedX
            val dy = cy / p.h - confirmedY
            jumpNorm = sqrt(dx * dx + dy * dy)
            val tol = max(cfg.maxTargetJump, cfg.maxCandidateJump)
            // §7: não saltar para posições distantes; em recuperação procurar longe é o objetivo.
            if (tracking && !recovering && jumpNorm > tol) {
                reject(
                    Reject.JUMP,
                    "candidato distante do último alvo (${"%.3f".format(jumpNorm)} > " +
                        "${"%.3f".format(tol)})",
                )
                return null
            }
            trackingScore = (1f - jumpNorm / tol).coerceIn(0f, 1f)
            if (recovering) trackingScore = (0.4f + 0.6f * trackingScore).coerceIn(0f, 1f)
        }

        // ---- sinal AUXILIAR (jamais requisito): disco escuro + anel claro ----------------------
        val auxiliary = if (cfg.useAuxiliaryDarkDisc) {
            when {
                faceMean < AUX_DARK_MAX && abs(ringMean - faceMean) > AUX_RING_DELTA -> 1f
                faceMean < AUX_DARK_MAX -> 0.55f
                abs(ringMean - faceMean) > AUX_RING_DELTA -> 0.35f
                else -> 0f
            }
        } else 0f

        // ---- pontuação ponderada (pesos configuráveis — §11) ----------------------------------
        val wSum = cfg.visualMatchWeight + cfg.contrastWeight + cfg.edgeWeight +
            cfg.regionStrengthWeight + cfg.roundnessWeight + cfg.temporalWeight +
            cfg.spatialWeight + cfg.trackingWeight + cfg.auxiliaryDiscWeight
        val k = if (wSum > 0f) 1f / wSum else 0f
        var score = k * (
            cfg.visualMatchWeight * visualMatch +
                cfg.contrastWeight * localContrast +
                cfg.edgeWeight * edgeEvidence +
                cfg.regionStrengthWeight * regionStrength +
                cfg.roundnessWeight * roundness +
                cfg.temporalWeight * temporalScore +
                cfg.spatialWeight * spatialScore +
                cfg.trackingWeight * trackingScore +
                cfg.auxiliaryDiscWeight * auxiliary
            )
        score *= (1f - TEXT_DAMP * textPenalty)
        score *= (1f - TEXTURE_DAMP * texturePenalty)
        score = score.coerceIn(0f, 1f)

        val c = RodButtonCandidateV9()
        c.cx = cx
        c.cy = cy
        c.r = r
        c.halfA = r
        c.halfB = r
        c.shape = if (roundness >= ROUND_SHAPE_MIN) "circle" else "box"
        c.radiusNorm = radiusNorm
        c.score = score
        c.visualMatch = visualMatch
        c.templateMatch = templateScore
        c.localContrast = localContrast
        c.edgeEvidence = edgeEvidence
        c.temporalScore = temporalScore
        c.spatialScore = spatialScore
        c.trackingScore = trackingScore
        c.regionStrength = regionStrength
        c.roundness = roundness
        c.auxiliaryDarkDisc = auxiliary
        c.texture = texture
        c.textFraction = textEvidence
        c.chroma = probe.chroma
        c.interiorMean = faceMean
        c.interiorStd = faceStd
        c.interiorTexture = texture
        c.ringMean = ringMean
        c.outsideMean = outsideMean
        c.edgeClosure = closure
        c.edgeAlignment = align
        c.profileRoughness = roughness
        c.brightFraction = brightFraction
        c.contourStability = contourStability
        c.interiorStability = interiorStability
        c.frameMotion = frameMotion
        c.stableFrames = data.stabilityAge(cx.toInt(), cy.toInt())
        c.seed = h.source.label
        c.reject = Reject.NONE
        c.rejectReason = ""
        c.jumpNorm = jumpNorm
        c.relX = relX
        c.relY = relY
        c.stableEnoughForTarget = temporalScore >= cfg.minTemporalStability || !data.prevValid
        c.bounds()
        return c
    }

    /**
     * Mede o contorno de uma hipótese: escolhe o centro em que o perfil agregado fica mais
     * **concentrado** (o componente que gerou a hipótese pode juntar o contorno do elemento com
     * bordas da água, o que desloca o centro de momento) e refina até estabilizar. Medido: com o
     * centro ~10px fora o pico cai à metade e o refino converge para um contorno INTERNO do botão
     * (raio 24 em vez de 32); escolhendo o centro pela concentração o contorno do botão aparece
     * (raio 31,4 / fechamento 24/24) já no primeiro frame.
     *
     * @param searchCentre varre os centros vizinhos (passo = fração do raio inicial)
     */
    private fun refineContour(
        out: RayProfile,
        cx0: Float,
        cy0: Float,
        r0Start: Float,
        p: Params,
        searchCentre: Boolean,
    ) {
        var cx = cx0
        var cy = cy0
        val r0 = max(2f, r0Start)
        if (searchCentre) {
            val centreStep = max(2f, r0 * CENTRE_SEARCH_STEP)
            var bestCx = cx
            var bestCy = cy
            var bestMass = -1f
            for (oy in -1..1) {
                for (ox in -1..1) {
                    val tx = cx + ox * centreStep
                    val ty = cy + oy * centreStep
                    data.rayProfile(tx, ty, r0, p, out)
                    val mass = if (out.found >= out.nAngles * 0.5f) out.peakMass else -1f
                    if (mass > bestMass) {
                        bestMass = mass
                        bestCx = tx
                        bestCy = ty
                    }
                }
            }
            cx = bestCx
            cy = bestCy
        }
        data.rayProfile(cx, cy, r0, p, out)
        var refinePass = 0
        while (true) {
            data.recentre(out, p)
            cx = out.centreX
            cy = out.centreY
            val rr = max(2f, out.radius)
            data.rayProfile(cx, cy, rr, p, out)
            refinePass++
            if (refinePass >= MAX_REFINE_PASSES) break
            if (out.centreX == cx && out.centreY == cy && out.radius == rr) break
        }
    }

    /** qualidade de uma geometria medida: fechamento do contorno corrigido pela irregularidade. */
    private fun contourQuality(pr: RayProfile, cfg: AppConfig.RodButtonV9): Float {
        val closure = pr.found.toFloat() / pr.nAngles
        val rough = (pr.spread / max(0.01f, cfg.maxProfileRoughness)).coerceIn(0f, 1f)
        return closure * (1f - rough)
    }

    /** quanto o raio está dentro da faixa de tamanho esperada (1 = centro da faixa) */
    private fun sizeBandFit(radiusNorm: Float): Float {
        val lo = cfg.minSizeNormalized
        val hi = cfg.maxSizeNormalized
        if (radiusNorm < lo || radiusNorm > hi) return 0f
        val mid = (lo + hi) * 0.5f
        val half = max(1e-4f, (hi - lo) * 0.5f)
        return (1f - abs(radiusNorm - mid) / half).coerceIn(0f, 1f)
    }

    private fun reject(r: Reject, why: String) {
        if (lastRejections.size < MAX_REJECT_NOTES) lastRejections.add("$r: $why")
    }

    // =============================================================================================
    //  temporal / utilidades
    // =============================================================================================

    /** §5/§11 — frames exigidos no FPS medido (tempo, não frames: vale em 15/30/60 FPS). */
    private fun requiredFrames(fps: Float): Int {
        val fromTime = (cfg.targetConfirmMs / 1000f * fps).toInt()
        return max(cfg.confirmationFrames, fromTime.coerceIn(1, MAX_CONFIRM_FRAMES))
    }

    /** nenhum candidato neste frame: cai o streak e o estado visual acompanha (§5/§7). */
    private fun miss() {
        if (everConfirmed) {
            state = RodButtonV9State.LOST
            out.state = state
        } else if (state != RodButtonV9State.DISABLED) {
            state = RodButtonV9State.SEARCHING
            out.state = state
        }
        streak = 0
        confidence = 0f
    }

    private fun roiPx(roi: NormRegion, w: Int, h: Int): IntArray {
        val x0 = (roi.left * w).toInt().coerceIn(0, w - 1)
        val y0 = (roi.top * h).toInt().coerceIn(0, h - 1)
        val x1 = (roi.right * w).toInt().coerceIn(x0 + 1, w)
        val y1 = (roi.bottom * h).toInt().coerceIn(y0 + 1, h)
        return intArrayOf(x0, y0, x1, y1)
    }

    /** assinatura grosseira da aparência (grade 4×4 de médias dentro do raio) para a memória. */
    private fun buildSignature(frame: VisionFrame, cx: Int, cy: Int, r: Float, into: IntArray) {
        val half = r * SIGNATURE_SPAN
        for (gy in 0 until 4) {
            for (gx in 0 until 4) {
                var sum = 0
                var n = 0
                for (dy in 0 until 3) {
                    for (dx in 0 until 3) {
                        val fx = (cx + half * ((gx + (dx + 0.5f) / 3f) / 2f - 1f)).toInt()
                        val fy = (cy + half * ((gy + (dy + 0.5f) / 3f) / 2f - 1f)).toInt()
                        if (fx < 0 || fy < 0 || fx >= frame.width || fy >= frame.height) continue
                        sum += frame.grayAt(fx, fy)
                        n++
                    }
                }
                into[gy * 4 + gx] = if (n > 0) sum / n else -1
            }
        }
    }

    // =============================================================================================
    //  tipos internos
    // =============================================================================================

    /** de onde a hipótese nasceu (nenhuma das três é obrigatória — são caminhos para o alvo). */
    enum class Source(val label: String) {
        CONTOUR("CONTOUR"),
        CHANGE("CHANGE"),
        FACE("FACE"),
    }

    /** motivo do descarte (vai para o diagnóstico §9 — não é decisão do usuário). */
    enum class Reject {
        NONE, TINY, HUGE, ELONGATED, RAGGED, OPEN_CONTOUR, FRAME_EDGE, OUTSIDE_ROI, TEXT, TEXTURED, JUMP,
    }

    /** limites derivados em pixels (a única ponte entre configuração relativa e pixels). */
    private class Params(val w: Int, val h: Int, val fps: Float, val cfg: AppConfig.RodButtonV9) {
        val rMin = max(3f, cfg.minSizeNormalized * w * SIZE_BAND_LO)
        val rMax = max(rMin + 3f, cfg.maxSizeNormalized * w * SIZE_BAND_HI)
        val edgeThreshold = max(cfg.minEdgeMagnitude, MIN_EDGE_FLOOR)
        val changeTol = max(cfg.changeTol, MIN_CHANGE_TOL)
        val stableTol = cfg.stableTol.coerceAtLeast(1f)
    }

    /** hipótese: componente conexo da imagem, com centro/raio estimados por momentos. */
    private class Hyp {
        var cx = 0f
        var cy = 0f
        var rMoment = 0f
        var source = Source.CONTOUR
        var pixels = 0
        var bw = 0
        var bh = 0
        val boundingAspect: Float
            get() = if (bh <= 0) 99f else max(bw.toFloat() / bh, bh.toFloat() / bw)

        fun copyOf(): Hyp = Hyp().also {
            it.cx = cx
            it.cy = cy
            it.rMoment = rMoment
            it.source = source
            it.pixels = pixels
            it.bw = bw
            it.bh = bh
        }
    }

    /** perfil de raio de uma hipótese (uma passada de 24 direções). */
    private class RayProfile {
        val nAngles = N_ANGLES
        private val radii = FloatArray(N_ANGLES)
        private val aligns = FloatArray(N_ANGLES)
        private val profile = FloatArray(MAX_PROFILE)
        var found = 0
        var centreX = 0f
        var centreY = 0f
        /** raio (px) onde a varredura do perfil começa — o bin 0 do histograma. */
        var tLo = 0f
        var radiusRef = 0f
        var radius = 0f
        var spread = 1f
        var alignment = 0f
        var magnitude = 0f

        /** massa acumulada no pico do histograma: mede o quanto o contorno está *concentrado*
         *  (com o centro certo o contorno cai todo no mesmo raio; deslocado, ele se espalha). */
        var peakMass = 0f

        fun angleRadius(i: Int): Float = radii[i]

        /** copia a medida de outra hipótese/perfil (usado quando uma segunda âncora vence). */
        fun copyFrom(o: RayProfile) {
            System.arraycopy(o.radii, 0, radii, 0, radii.size)
            System.arraycopy(o.aligns, 0, aligns, 0, aligns.size)
            System.arraycopy(o.profile, 0, profile, 0, profile.size)
            found = o.found
            centreX = o.centreX
            centreY = o.centreY
            tLo = o.tLo
            radiusRef = o.radiusRef
            radius = o.radius
            spread = o.spread
            alignment = o.alignment
            magnitude = o.magnitude
            peakMass = o.peakMass
        }

        fun resetAt(cx: Float, cy: Float, r: Float) {
            centreX = cx
            centreY = cy
            radiusRef = r
            tLo = 0f
            found = 0
            radii.fill(0f)
            aligns.fill(0f)
            java.util.Arrays.fill(profile, 0f)
        }

        fun setHit(i: Int, t: Float, a: Float) {
            radii[i] = t
            aligns[i] = a
        }

        /** acumula a borda encontrada no bin de raio correspondente (evidência por raio). */
        fun addProfile(bin: Int, v: Float) {
            if (bin in 1 until MAX_PROFILE) profile[bin] += v
        }

        /**
         * Fecha o perfil: suaviza e escolhe o **pico** — o raio que aparece como borda coerente em
         * muitas direções ao mesmo tempo. Detalhe interno (ícone, texto) aparece em poucas direções
         * e não forma pico; o contorno do elemento aparece em todas.
         */
        fun finishProfile(): Float {
            var bestI = 0
            var best = -1f
            for (i in 2 until MAX_PROFILE - 2) {
                val v = (profile[i - 1] + profile[i] + profile[i + 1]) / 3f
                profile[i] = v
                if (v > best) {
                    best = v
                    bestI = i
                }
            }
            // o pico do histograma é um **bin** (deslocado de `tLo`), mas quem consome isto
            // (`recentre`) espera um **raio em px**: a conversão é feita aqui (medido: sem ela a
            // janela de refino do `recentre` cai longe do contorno e o contorno real é perdido).
            peakMass = max(0f, best)
            radiusRef = tLo + bestI.toFloat()
            return radiusRef
        }
    }

    /** amostrador reutilizável de médias/estatísticas. */
    private class Probe {
        var count = 0
        var mean = 0f
        var std = 0f
        var chroma = 0f

        fun reset() {
            count = 0
            mean = 0f
            std = 0f
            chroma = 0f
        }
    }

    private class Structural(
        val contourStability: Float,
        val interiorStability: Float,
        val frameMotion: Float,
    )


    // =============================================================================================
    //  buffers da janela (sem alocação por frame)
    // =============================================================================================

    /**
     * Buffers cobrindo a **ROI** (nada além dela: a janela define *onde procurar* — §1/§4) com os
     * níveis de cinza suavizados, os gradientes, a máscara de borda, a mudança entre frames e a
     * idade de estabilidade por pixel.
     */
    private class RoiWorkspace {
        var x0 = 0
        var y0 = 0
        var w = 0
        var h = 0
        var roiX0 = 0
        var roiY0 = 0
        var roiX1 = 0
        var roiY1 = 0
        var frameW = 0
        var frameH = 0
        var frame: VisionFrame? = null
        var prevValid = false
        private var gray = IntArray(0)
        private var prevGray = IntArray(0)
        private var gx = IntArray(0)
        private var gy = IntArray(0)
        private var edge = IntArray(0)
        private var diff = IntArray(0)
        private var stability = IntArray(0)
        private var visited = IntArray(0)
        private var stamp = 0
        private var stack = IntArray(0)
        private val grad = FloatArray(2)
        private val gradNear = FloatArray(2)

        fun reset() {
            prevValid = false
            if (stability.isNotEmpty()) stability.fill(0)
        }

        fun prepare(f: VisionFrame, roiPx: IntArray) {
            frame = f
            frameW = f.width
            frameH = f.height
            roiX0 = roiPx[0].coerceIn(0, max(0, f.width - 2))
            roiY0 = roiPx[1].coerceIn(0, max(0, f.height - 2))
            roiX1 = roiPx[2].coerceIn(roiX0 + 2, f.width)
            roiY1 = roiPx[3].coerceIn(roiY0 + 2, f.height)
            x0 = roiX0
            y0 = roiY0
            w = roiX1 - roiX0
            h = roiY1 - roiY0
            val n = w * h
            if (gray.size != n) {
                gray = IntArray(n)
                prevGray = IntArray(n)
                gx = IntArray(n)
                gy = IntArray(n)
                edge = IntArray(n)
                diff = IntArray(n)
                stability = IntArray(n)
                visited = IntArray(n)
                stack = IntArray(n)
                prevValid = false
            }
            for (y in 0 until h) {
                var i = (y + y0) * f.width + x0
                var o = y * w
                for (x in 0 until w) {
                    gray[o + x] = f.gray[i + x].toInt() and 0xFF
                }
            }
            // suavização 3×3 dentro da janela: o ruído da captura não pode virar "borda"
            for (y in 0 until h) {
                val o = y * w
                val ym = if (y > 0) o - w else o
                val yp = if (y < h - 1) o + w else o
                for (x in 0 until w) {
                    val xm = if (x > 0) x - 1 else x
                    val xp = if (x < w - 1) x + 1 else x
                    val sum = gray[ym + xm] + gray[ym + x] + gray[ym + xp] +
                        gray[o + xm] + gray[o + x] + gray[o + xp] +
                        gray[yp + xm] + gray[yp + x] + gray[yp + xp]
                    gx[o + x] = sum / 9
                }
            }
            for (i in 0 until n) {
                gray[i] = gx[i]
                gx[i] = 0
            }
            // gradientes/borda (diferenças centrais, com clamp na janela)
            for (y in 0 until h) {
                val o = y * w
                val ym = if (y > 0) o - w else o
                val yp = if (y < h - 1) o + w else o
                for (x in 0 until w) {
                    val xm = if (x > 0) x - 1 else x
                    val xp = if (x < w - 1) x + 1 else x
                    val dx = gray[o + xp] - gray[o + xm]
                    val dy = gray[yp + x] - gray[ym + x]
                    gx[o + x] = dx
                    gy[o + x] = dy
                    edge[o + x] = sqrt((dx * dx + dy * dy).toFloat()).toInt()
                }
            }
            // mudança entre frames + idade de estabilidade por pixel
            if (prevValid) {
                for (i in 0 until n) {
                    val d = abs(gray[i] - prevGray[i])
                    diff[i] = d
                    stability[i] = if (d <= STABILITY_TOL) min(stability[i] + 1, STABILITY_CAP) else 0
                }
            } else {
                java.util.Arrays.fill(stability, 0)
                java.util.Arrays.fill(diff, 0)
            }
            System.arraycopy(gray, 0, prevGray, 0, n)
            prevValid = true
        }

        fun insideRoi(x: Int, y: Int): Boolean = x >= roiX0 && x < roiX1 && y >= roiY0 && y < roiY1

        fun idx(x: Int, y: Int): Int = (y - y0) * w + (x - x0)

        private fun at(a: IntArray, x: Int, y: Int): Int {
            val xx = x.coerceIn(x0, x0 + w - 1)
            val yy = y.coerceIn(y0, y0 + h - 1)
            return a[(yy - y0) * w + (xx - x0)]
        }

        fun grayAt(x: Int, y: Int): Int = at(gray, x, y)
        fun edgeAt(x: Int, y: Int): Int = at(edge, x, y)
        fun temporalAt(x: Int, y: Int): Int = if (prevValid) at(diff, x, y) else 0
        fun stabilityAge(x: Int, y: Int): Int = at(stability, x, y)

        // ---------------------------------------------------------------------------------------
        //  componentes conexos
        // ---------------------------------------------------------------------------------------

        /** componentes conexos da máscara (dentro da ROI), com momentos — são as hipóteses. */
        fun components(minPixels: Int, source: Source, accept: (Int, Int) -> Boolean): List<Hyp> {
            val list = ArrayList<Hyp>(12)
            stamp++
            for (y in roiY0 until roiY1) {
                val o = (y - y0) * w
                for (x in roiX0 until roiX1) {
                    val i = o + (x - x0)
                    if (visited[i] == stamp) continue
                    if (!accept(x, y)) continue
                    val hyp = flood(si = i, sx = x, sy = y, mark = stamp, accept = accept) ?: continue
                    if (hyp.pixels >= minPixels) list.add(hyp)
                }
            }
            return list
        }

        /** flood fill iterativo (sem recursão) — devolve momentos/bbox do componente. */
        private fun flood(si: Int, sx: Int, sy: Int, mark: Int, accept: (Int, Int) -> Boolean): Hyp? {
            var top = 0
            stack[top++] = si
            visited[si] = mark
            var pixels = 0
            var sumX = 0L
            var sumY = 0L
            var sumXX = 0L
            var sumYY = 0L
            var bx0 = sx
            var by0 = sy
            var bx1 = sx
            var by1 = sy
            while (top > 0) {
                val i = stack[--top]
                val yy = y0 + i / w
                val xx = x0 + i % w
                pixels++
                sumX += xx
                sumY += yy
                sumXX += (xx.toLong() * xx)
                sumYY += (yy.toLong() * yy)
                if (xx < bx0) bx0 = xx
                if (xx > bx1) bx1 = xx
                if (yy < by0) by0 = yy
                if (yy > by1) by1 = yy
                // 8-vizinhos, sempre dentro da janela
                for (k in 0 until 8) {
                    val nx = xx + DX[k]
                    val ny = yy + DY[k]
                    if (nx < roiX0 || nx >= roiX1 || ny < roiY0 || ny >= roiY1) continue
                    val ni = (ny - y0) * w + (nx - x0)
                    if (visited[ni] == mark) continue
                    if (!accept(nx, ny)) continue
                    visited[ni] = mark
                    stack[top++] = ni
                }
            }
            if (pixels <= 0) return null
            val hyp = Hyp()
            val n = pixels.toFloat()
            hyp.cx = sumX / n
            hyp.cy = sumY / n
            hyp.pixels = pixels
            hyp.bw = bx1 - bx0 + 1
            hyp.bh = by1 - by0 + 1
            // raio por momentos (2σ): anel, disco e caixa ficam na mesma escala
            val varX = sumXX / n - (sumX / n) * (sumX / n)
            val varY = sumYY / n - (sumY / n) * (sumY / n)
            val spread = max(1f, sqrt((varX + varY).toDouble()).toFloat())
            hyp.rMoment = max(spread * 0.9f, 2f)
            return hyp
        }

        // ---------------------------------------------------------------------------------------
        //  perfil de raio (24 direções)
        // ---------------------------------------------------------------------------------------

        /**
         * Amostra o perfil de raio da hipótese: em cada direção varre-se para fora medindo
         * magnitude de borda × coerência radial; o perfil agregado (soma por raio) tem pico no
         * **contorno** — em qualquer forma fechada (círculo, quadrado arredondado, contorno de
         * interface irregular).
         */
        fun rayProfile(cx: Float, cy: Float, rRef: Float, p: Params, out: RayProfile) {
            out.resetAt(cx, cy, rRef)
            val tLo = max(2f, rRef * 0.25f)
            val tHi = min(max(tLo + 4f, rRef * 1.9f), min(frameW, frameH) * 0.5f - 2f)
            out.tLo = tLo
            val steps = ((tHi - tLo) / RAY_STEP_PX).toInt().coerceIn(1, MAX_PROFILE - 2)
            for (k in 0 until out.nAngles) {
                val a = TWO_PI * k / out.nAngles
                val ux = cos(a)
                val uy = sin(a)
                var t = tLo
                for (s in 0 until steps) {
                    val sx = cx + ux * t
                    val sy = cy + uy * t
                    if (sx >= 1f && sy >= 1f && sx < frameW - 1f && sy < frameH - 1f) {
                        val m = edgeNear(sx, sy)
                        if (m >= p.edgeThreshold) {
                            val g = gradientNear(sx, sy)
                            val len = sqrt(g[0] * g[0] + g[1] * g[1])
                            if (len > 1e-3f) {
                                val align = abs((g[0] * ux + g[1] * uy) / len)
                                val v = m * ((align - RAY_MIN_ALIGN) /
                                    (1f - RAY_MIN_ALIGN)).coerceIn(0f, 1f)
                                if (v > 0f) out.addProfile((t - tLo).toInt(), v)
                            }
                        }
                    }
                    t += RAY_STEP_PX
                }
            }
            out.finishProfile()
            // O pico do perfil agregado diz *onde* está o contorno; a medida por direção (o mesmo
            // procedimento do `recentre`) diz *quanto* do contorno existe. Sem isto `found` ficaria
            // sempre 0 e nenhuma hipótese sobreviveria ao teste de fechamento (medido §14).
            recentre(out, p)
        }

        /**
         * Re-centra a hipótese no contorno encontrado e mede, por direção, o raio e a coerência da
         * borda dentro de uma janela em torno do pico. É o que dá precisão ao centro publicado.
         */
        fun recentre(out: RayProfile, p: Params, loFactor: Float = FIT_LO, hiFactor: Float = FIT_HI) {
            val peak = out.radiusRef
            if (peak < 2f) return
            val lo = max(2f, peak * loFactor)
            val hi = peak * hiFactor
            val cx = out.centreX
            val cy = out.centreY
            var sumA = 0f
            var sumM = 0f
            var n = 0
            // ajuste de círculo por mínimos quadrados (Kåsa) sobre os pontos de contorno medidos:
            // o centro da hipótese pode estar deslocado (a face é cortada pelo ícone, a borda é
            // recortada pela água) e a média dos pontos de um ARCO PARCIAL puxa o centro para o
            // lado do arco — medido: sem o ajuste o refino caminha para dentro (32→20→16→13px) e
            // perde o contorno do botão.
            var sx = 0.0
            var sy = 0.0
            var su = 0.0
            var sxx = 0.0
            var sxy = 0.0
            var syy = 0.0
            var sxu = 0.0
            var syu = 0.0
            for (k in 0 until out.nAngles) {
                val a = TWO_PI * k / out.nAngles
                val ux = cos(a)
                val uy = sin(a)
                var bestT = -1f
                var bestA = 0f
                var bestM = 0f
                var t = lo
                while (t <= hi) {
                    val sx1 = cx + ux * t
                    val sy1 = cy + uy * t
                    if (sx1 >= 1f && sy1 >= 1f && sx1 < frameW - 1f && sy1 < frameH - 1f) {
                        val m = edgeNear(sx1, sy1)
                        if (m >= p.edgeThreshold) {
                            val g = gradientNear(sx1, sy1)
                            val len = sqrt(g[0] * g[0] + g[1] * g[1])
                            if (len > 1e-3f) {
                                val align = abs((g[0] * ux + g[1] * uy) / len)
                                if (align >= RAY_MIN_ALIGN && m > bestM) {
                                    bestT = t
                                    bestA = align
                                    bestM = m.toFloat()
                                }
                            }
                        }
                    }
                    t += RAY_STEP_PX
                }
                if (bestT > 0f) {
                    out.setHit(k, bestT, bestA)
                    val px = (cx + ux * bestT).toDouble()
                    val py = (cy + uy * bestT).toDouble()
                    val u = px * px + py * py
                    sx += px; sy += py; su += u
                    sxx += px * px; sxy += px * py; syy += py * py
                    sxu += px * u; syu += py * u
                    sumA += bestA
                    sumM += bestM
                    n++
                } else {
                    out.setHit(k, 0f, 0f)
                }
            }
            out.found = n
            if (n == 0) return
            out.alignment = sumA / n
            out.magnitude = sumM / n
            val fit = circleFit(sx, sy, su, sxx, sxy, syy, sxu, syu, n.toDouble())
            val fcx = if (fit != null) fit[0] else (sx / n).toFloat()
            val fcy = if (fit != null) fit[1] else (sy / n).toFloat()
            out.centreX = fcx
            out.centreY = fcy
            // raio = distância média ao centro ajustado (não a média da varredura, que é medida a
            // partir do centro antigo)
            var sumR = 0f
            for (k in 0 until out.nAngles) {
                val rr = out.angleRadius(k)
                if (rr > 0f) {
                    val a = TWO_PI * k / out.nAngles
                    val px = cx + cos(a) * rr
                    val py = cy + sin(a) * rr
                    sumR += sqrt((px - fcx) * (px - fcx) + (py - fcy) * (py - fcy))
                }
            }
            val mean = max(1f, sumR / n)
            out.radius = mean
            var v = 0f
            for (k in 0 until out.nAngles) {
                val rr = out.angleRadius(k)
                if (rr > 0f) {
                    val a = TWO_PI * k / out.nAngles
                    val px = cx + cos(a) * rr
                    val py = cy + sin(a) * rr
                    val d = sqrt((px - fcx) * (px - fcx) + (py - fcy) * (py - fcy)) - mean
                    v += d * d
                }
            }
            out.spread = sqrt(v / n) / mean
        }

        /**
         * Ajuste de círculo (mínimos quadrados, forma de Kåsa): resolve
         * `x² + y² = a·x + b·y + c` e devolve o centro `(a/2, b/2)`. `null` quando o sistema é
         * degenerado (pontos colineares/poucos pontos) — aí quem chama usa a média simples.
         */
        private fun circleFit(
            sx: Double, sy: Double, su: Double,
            sxx: Double, sxy: Double, syy: Double,
            sxu: Double, syu: Double, n: Double,
        ): FloatArray? {
            val m = arrayOf(
                doubleArrayOf(sxx, sxy, sx, sxu),
                doubleArrayOf(sxy, syy, sy, syu),
                doubleArrayOf(sx, sy, n, su),
            )
            // eliminação de Gauss com pivô parcial
            for (col in 0 until 3) {
                var piv = col
                for (r in col + 1 until 3) if (abs(m[r][col]) > abs(m[piv][col])) piv = r
                if (abs(m[piv][col]) < 1e-6) return null
                val tmp = m[col]; m[col] = m[piv]; m[piv] = tmp
                for (r in 0 until 3) {
                    if (r == col) continue
                    val f = m[r][col] / m[col][col]
                    for (cc in col until 4) m[r][cc] -= f * m[col][cc]
                }
            }
            val a = m[0][3] / m[0][0]
            val b = m[1][3] / m[1][1]
            val c = m[2][3] / m[2][2]
            val r2 = c + a * a * 0.25 + b * b * 0.25
            if (!r2.isFinite() || r2 <= 1.0) return null
            return floatArrayOf((a * 0.5).toFloat(), (b * 0.5).toFloat())
        }

        private fun edgeNear(fx: Float, fy: Float): Int {
            val x = fx.toInt().coerceIn(x0, x0 + w - 2)
            val y = fy.toInt().coerceIn(y0, y0 + h - 2)
            val dx = (fx - x).coerceIn(0f, 1f)
            val dy = (fy - y).coerceIn(0f, 1f)
            val i = (y - y0) * w + (x - x0)
            val e00 = edge[i]
            val e10 = edge[i + 1]
            val e01 = edge[i + w]
            val e11 = edge[i + w + 1]
            val a = e00 + (e10 - e00) * dx
            val b = e01 + (e11 - e01) * dx
            return (a + (b - a) * dy).toInt()
        }

        private fun gradientNear(fx: Float, fy: Float): FloatArray {
            val x = fx.toInt().coerceIn(x0, x0 + w - 1)
            val y = fy.toInt().coerceIn(y0, y0 + h - 1)
            val i = (y - y0) * w + (x - x0)
            gradNear[0] = gx[i].toFloat()
            gradNear[1] = gy[i].toFloat()
            return gradNear
        }

        // ---------------------------------------------------------------------------------------
        //  estatísticas de face / anel / entorno
        // ---------------------------------------------------------------------------------------

        fun interiorStats(
            cx: Float, cy: Float, radius: Float, out: Probe, skipEdgeAbove: Float = Float.MAX_VALUE,
        ) {
            out.reset()
            val step = max(1f, radius * 0.11f)
            var sum = 0f
            var sumSq = 0f
            var sumChroma = 0f
            var n = 0
            var y = cy - radius
            while (y <= cy + radius) {
                var x = cx - radius
                while (x <= cx + radius) {
                    val dx = x - cx
                    val dy = y - cy
                    if (dx * dx + dy * dy <= radius * radius && insidePixel(x, y) &&
                        smoothFace(x.toInt(), y.toInt(), skipEdgeAbove)
                    ) {
                        val g = grayAt(x.toInt(), y.toInt())
                        val argb = frame!!.argb[
                            y.toInt().coerceIn(0, frameH - 1) * frameW + x.toInt().coerceIn(0, frameW - 1)
                        ]
                        val r = (argb shr 16) and 0xFF
                        val gg = (argb shr 8) and 0xFF
                        val b = argb and 0xFF
                        sum += g
                        sumSq += (g * g).toFloat()
                        sumChroma += (max(r, max(gg, b)) - min(r, min(gg, b))).toFloat()
                        n++
                    }
                    x += step
                }
                y += step
            }
            if (n == 0) return
            val mean = sum / n
            out.count = n
            out.mean = mean
            out.std = sqrt(max(0f, sumSq / n - mean * mean).toDouble()).toFloat()
            out.chroma = sumChroma / n
        }

        /**
         * O pixel é **face lisa** do elemento? Um traço de ícone fino (o ícone do botão) tem o
         * gradiente nas bordas mas o miolo liso — medido: só olhar o próprio pixel deixava o ícone
         * dentro da estatística da face e a face uniforme era reprovada por "textura" (std 37 numa
         * face de 58 níveis). Por isso a vizinhança de 2px também precisa ser lisa.
         */
        private fun smoothFace(x: Int, y: Int, edgeLimit: Float): Boolean {
            if (edgeAt(x, y) >= edgeLimit) return false
            val d = FACE_NEIGHBOUR_PX
            return edgeAt(x - d, y) < edgeLimit && edgeAt(x + d, y) < edgeLimit &&
                edgeAt(x, y - d) < edgeLimit && edgeAt(x, y + d) < edgeLimit
        }

        fun bandStats(cx: Float, cy: Float, r0: Float, r1: Float, out: Probe) {
            out.reset()
            val step = max(1f, (r1 - r0) * 0.5f)
            var sum = 0f
            var sumSq = 0f
            var n = 0
            var y = cy - r1
            while (y <= cy + r1) {
                var x = cx - r1
                while (x <= cx + r1) {
                    val dx = x - cx
                    val dy = y - cy
                    val d = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                    if (d >= r0 && d <= r1 && insidePixel(x, y)) {
                        val g = grayAt(x.toInt(), y.toInt())
                        sum += g
                        sumSq += (g * g).toFloat()
                        n++
                    }
                    x += step
                }
                y += step
            }
            if (n == 0) return
            val mean = sum / n
            out.count = n
            out.mean = mean
            out.std = sqrt(max(0f, sumSq / n - mean * mean).toDouble()).toFloat()
        }

        /** fração de pixels claros dentro do raio (texto claro sobre face escura — §6). */
        fun brightFraction(cx: Float, cy: Float, radius: Float, level: Int): Float {
            var n = 0
            var bright = 0
            val step = max(1f, radius * 0.12f)
            var y = cy - radius
            while (y <= cy + radius) {
                var x = cx - radius
                while (x <= cx + radius) {
                    val dx = x - cx
                    val dy = y - cy
                    if (dx * dx + dy * dy <= radius * radius && insidePixel(x, y)) {
                        if (grayAt(x.toInt(), y.toInt()) >= level) bright++
                        n++
                    }
                    x += step
                }
                y += step
            }
            return if (n == 0) 0f else bright.toFloat() / n
        }

        /** §5/§6: o contorno e a face continuam iguais ao frame anterior? A água não. */
        fun structureAt(cx: Float, cy: Float, r: Float, profile: RayProfile, p: Params): Structural {
            if (!prevValid) return Structural(0.5f, 0.5f, 0f)
            var hits = 0
            var stable = 0
            for (k in 0 until profile.nAngles) {
                val rr = profile.angleRadius(k)
                if (rr <= 0f) continue
                val a = TWO_PI * k / profile.nAngles
                val x = (cx + cos(a) * rr).toInt()
                val y = (cy + sin(a) * rr).toInt()
                if (!insidePixel(x.toFloat(), y.toFloat())) continue
                hits++
                if (temporalAt(x, y) <= MOTION_TOL) stable++
            }
            val contourStability = if (hits > 0) stable.toFloat() / hits else 0f
            var isum = 0f
            var iCount = 0
            val step = max(1, (r * 0.2f).toInt())
            var y = (cy - r * 0.5f).toInt()
            while (y <= (cy + r * 0.5f).toInt()) {
                var x = (cx - r * 0.5f).toInt()
                while (x <= (cx + r * 0.5f).toInt()) {
                    if (insidePixel(x.toFloat(), y.toFloat())) {
                        isum += temporalAt(x, y).toFloat()
                        iCount++
                    }
                    x += step
                }
                y += step
            }
            val interiorChange = if (iCount > 0) isum / iCount else 0f
            val interiorStability = (1f - interiorChange / max(1f, p.stableTol * 3f)).coerceIn(0f, 1f)
            var msum = 0f
            var mCount = 0
            val mstep = max(2, w / 24)
            var yy = 0
            while (yy < h) {
                var xx = 0
                while (xx < w) {
                    msum += diff[yy * w + xx].toFloat()
                    mCount++
                    xx += mstep
                }
                yy += mstep
            }
            val frameMotion = if (mCount > 0) {
                ((msum / mCount) / max(1f, p.stableTol * 4f)).coerceIn(0f, 1f)
            } else {
                0f
            }
            return Structural(contourStability, interiorStability, frameMotion)
        }

        private fun insidePixel(x: Float, y: Float): Boolean =
            x >= x0 + 1f && y >= y0 + 1f && x <= x0 + w - 2f && y <= y0 + h - 2f
    }

    // =============================================================================================
    //  constantes de medida
    // =============================================================================================

    companion object {
        /** direções amostradas no perfil de raio. */
        const val N_ANGLES = 24

        private const val MAX_CANDIDATES_KEEP = 16
        private const val MAX_CONFIRM_FRAMES = 12
        private const val MAX_REJECT_NOTES = 8
        private const val STABILITY_CAP = 255

        /** confirmação: deslocamento máximo entre frames comparados (relativo à largura). */
        internal const val DRIFT_TOL_FACTOR = 0.35f
        internal const val DRIFT_TOL_MIN = 0.012f

        /** faixa de tamanho aceita (folga sobre a faixa configurada). */
        private const val SIZE_BAND_LO = 0.6f
        private const val SIZE_BAND_HI = 1.5f

        private const val SEED_MAX_BOUNDING_ASPECT = 2.6f

        private const val MIN_EDGE_FLOOR = 12f
        private const val MIN_CHANGE_TOL = 6f

        /** perfil de raio: passo (px), bins (1 px cada) e coerência radial mínima. */
        private const val MAX_PROFILE = 512
        private const val RAY_STEP_PX = 1.0f
        private const val RAY_MIN_ALIGN = 0.40f

        /** janela do refino em torno do pico do perfil (× raio): larga o bastante para o contorno
         *  entrar quando o centro da hipótese está deslocado, estreita o bastante para não trocar
         *  de estrutura (medido: uma janela larga — 0.62..1.42 — inclui os traços do ícone, mais
         *  fortes que o contorno, e o refino caminha para dentro; 0.78..1.30 converge para o
         *  contorno: 32,9 → 27,8 → 31,8 → 32,3px com fechamento 24/24). */
        /** busca grosseira de centro: passo = fração do raio da hipótese. */
        private const val CENTRE_SEARCH_STEP = 0.35f

        /** refino do contorno: passadas máximas e critério de estabilização (px). */
        private const val MAX_REFINE_PASSES = 6

        /** vizinhança (px) que precisa estar lisa para um pixel contar como face do elemento. */
        private const val FACE_NEIGHBOUR_PX = 2

        internal const val FIT_LO = 0.78f
        internal const val FIT_HI = 1.30f

        /** mudança máxima (níveis de cinza) para um pixel contar como "estável" / "mexeu". */
        private const val STABILITY_TOL = 8
        private const val MOTION_TOL = 12

        private val DX = intArrayOf(-1, 0, 1, -1, 1, -1, 0, 1)
        private val DY = intArrayOf(-1, -1, -1, 0, 0, 1, 1, 1)

        /** saturações dos sinais (valores de cinza / níveis de borda). */
        private const val INTERIOR_FACTOR = 0.62f
        private const val RING_INNER = 0.88f
        private const val RING_OUTER = 1.12f
        private const val OUTSIDE_INNER = 1.30f
        private const val OUTSIDE_OUTER = 1.70f
        private const val CONTRAST_SAT = 42f
        private const val UNIFORMITY_SAT = 26f
        private const val TEXTURE_SAT = 32f
        private const val CHROMA_SAT = 48f
        private const val EDGE_SAT = 44f
        private const val ROUGHNESS_SAT = 0.50f
        private const val ROUND_SHAPE_MIN = 0.55f
        private const val BRIGHT_LEVEL = 195
        private const val DARK_FACE_MAX = 155f
        private const val TEXT_HARD_REJECT = 1.7f
        private const val TEXTURE_HARD = 0.5f
        private const val TEXT_DAMP = 0.35f
        private const val TEXTURE_DAMP = 0.45f

        /** sinal auxiliar (disco escuro + anel claro) — só soma, nunca decide sozinho. */
        private const val AUX_DARK_MAX = 120f
        private const val AUX_RING_DELTA = 20f

        private const val NEUTRAL_TRACKING = 0.5f
        private const val SIGNATURE_SPAN = 1.0f
        private const val TWO_PI = 6.2831855f
    }
}

enum class RodButtonV9State {
    /** `rodButtonDetectionEnabled = false` — o detector não responde nada além de "não encontrado" */
    DISABLED,

    /** procurando dentro da ROI; nada com cara de elemento de interface */
    SEARCHING,

    /** um candidato viável apareceu; aguardando a confirmação temporal */
    CANDIDATE,

    /** candidato compatível com o anterior; streak em andamento (spec §5) */
    CONFIRMING,

    /** alvo confirmado: `targetFound = true` e posição publicada */
    CONFIRMED,

    /** tinha alvo e ele desapareceu (memória preservada para a recuperação) */
    LOST,
    ;

    val isConfirmed: Boolean get() = this == CONFIRMED
}

/**
 * Um candidato do detector V9 com **todas** as evidências que o pontuaram (spec §3/§8).
 * Coordenadas em pixels do frame processado (`cx/cy/r`, [box]); [snapshot] devolve uma cópia.
 */
class RodButtonCandidateV9 {
    var cx = 0f
    var cy = 0f
    var r = 0f
    var halfA = 0f
    var halfB = 0f

    /** hipótese que gerou o candidato: `circle` ou `box` */
    var shape = "circle"

    var radiusNorm = 0f
    var score = 0f

    // ---- sub-scores (0..1) -----------------------------------------------------------------
    var visualMatch = 0f
    /** NCC com o template do usuário; `-1` quando não há template carregado */
    var templateMatch = -1f
    var localContrast = 0f
    var edgeEvidence = 0f
    var temporalScore = 0f
    var spatialScore = 0f
    var trackingScore = 0f

    // ---- medições cruas ---------------------------------------------------------------------
    var interiorMean = 0f
    var interiorStd = 0f
    var interiorTexture = 0f
    var ringMean = 0f
    var outsideMean = 0f
    var edgeClosure = 0f
    var edgeAlignment = 0f
    /** fração de pixels claros na face (texto ⇒ provável prompt "SHAKE") */
    var brightFraction = 0f
    var chroma = 0f
    /** sinal auxiliar (disco escuro + anel claro) — jamais obrigatório */
    var auxiliaryDarkDisc = 0f

    // ---- V9 (descoberta estrutural) ---------------------------------------------------------
    /** força regional do contorno (|∇| médio na borda, 0..1) — §3 §8 */
    var regionStrength = 0f
    /** quão "redondo/regular" é o contorno (1 = círculo perfeito, 0 = muito irregular) */
    var roundness = 0f
    /** variação relativa do raio ao longo do contorno (irregularidade) */
    var profileRoughness = 0f
    /** textura interna (|∇| médio da face normalizado) */
    var texture = 0f
    /** fração da face coberta por pixels muito claros (texto/prompt) */
    var textFraction = 0f
    /** fração dos pontos do contorno estáveis entre frames */
    var contourStability = 0f
    /** estabilidade da face entre frames */
    var interiorStability = 0f
    /** movimento global medido dentro da ROI (câmera/cena) */
    var frameMotion = 0f
    /** idade de estabilidade do pixel central (frames) */
    var stableFrames = 0
    /** de onde veio a hipótese: `EDGE`, `CHANGE` ou `FACE` */
    var seed = ""
    /** distância normalizada até o último alvo conhecido (`NaN` quando não há memória) */
    var jumpNorm = Float.NaN
    /** posição relativa dentro da ROI (0..1) */
    var relX = 0f
    var relY = 0f

    val box = RectF()

    /** o candidato reúne estabilidade suficiente para virar *alvo* (§5/§6)? */
    var stableEnoughForTarget = false

    /** códigos de descarte medidos neste frame (auditoria §9). */
    var reject = RodButtonDetectorV9.Reject.NONE
    var rejectReason = ""

    val signals: List<Pair<String, Float>>
        get() = listOf(
            "visualMatch" to visualMatch,
            "localContrast" to localContrast,
            "edgeEvidence" to edgeEvidence,
            "regionStrength" to regionStrength,
            "roundness" to roundness,
            "temporalStability" to temporalScore,
            "spatialConsistency" to spatialScore,
            "trackingConsistency" to trackingScore,
            "auxiliaryDisc" to auxiliaryDarkDisc,
        )

    fun bounds() {
        val hx = if (halfA > 0f) halfA else r
        val hy = if (halfB > 0f) halfB else r
        box.set(cx - hx, cy - hy, cx + hx, cy + hy)
    }

    /** cópia imutável publicada em `candidateData` (o detector reusa as instâncias internas) */
    fun snapshot(): RodButtonCandidateV9 {
        val c = RodButtonCandidateV9()
        c.cx = cx; c.cy = cy; c.r = r; c.halfA = halfA; c.halfB = halfB; c.shape = shape
        c.radiusNorm = radiusNorm; c.score = score
        c.visualMatch = visualMatch; c.templateMatch = templateMatch
        c.localContrast = localContrast; c.edgeEvidence = edgeEvidence
        c.temporalScore = temporalScore; c.spatialScore = spatialScore; c.trackingScore = trackingScore
        c.interiorMean = interiorMean; c.interiorStd = interiorStd; c.interiorTexture = interiorTexture
        c.ringMean = ringMean; c.outsideMean = outsideMean
        c.edgeClosure = edgeClosure; c.edgeAlignment = edgeAlignment
        c.brightFraction = brightFraction; c.chroma = chroma
        c.auxiliaryDarkDisc = auxiliaryDarkDisc
        c.jumpNorm = jumpNorm; c.relX = relX; c.relY = relY
        c.regionStrength = regionStrength; c.roundness = roundness
        c.profileRoughness = profileRoughness; c.texture = texture
        c.textFraction = textFraction
        c.contourStability = contourStability; c.interiorStability = interiorStability
        c.frameMotion = frameMotion; c.stableFrames = stableFrames
        c.stableEnoughForTarget = stableEnoughForTarget
        c.seed = seed; c.reject = reject; c.rejectReason = rejectReason
        c.box.set(box)
        return c
    }

    fun describe(): String =
        "$shape/$seed c=(${cx.toInt()},${cy.toInt()}) r=${"%.1f".format(r)} " +
            "score=${"%.2f".format(score)} " +
            "vm=${"%.2f".format(visualMatch)}" +
            (if (templateMatch >= 0f) "(tmpl=${"%.2f".format(templateMatch)})" else "") +
            " ct=${"%.2f".format(localContrast)} ed=${"%.2f".format(edgeEvidence)} " +
            "fc=${"%.2f".format(regionStrength)} ru=${"%.2f".format(roundness)} " +
            "tp=${"%.2f".format(temporalScore)} sp=${"%.2f".format(spatialScore)} " +
            "tr=${"%.2f".format(trackingScore)} " +
            "fech=${"%.2f".format(edgeClosure)} alin=${"%.2f".format(edgeAlignment)} " +
            "irreg=${"%.2f".format(profileRoughness)} tex=${"%.2f".format(texture)}"
}

/**
 * Resultado do [RodButtonDetectorV9] para **um** frame — exatamente o que a spec §10 autoriza o
 * detector a devolver, e nada mais: `targetFound`, `targetX`, `targetY`, `confidence`, `state`,
 * `roi` e `candidateData`. Nenhum campo representa uma ordem de input.
 *
 * `targetX/targetY` só valem quando [targetFound] é true; fora disso ficam `NaN` (nunca uma
 * posição inventada).
 */
class RodButtonV9Result {
    // ---- §10: a resposta pública ------------------------------------------------------------
    var targetFound = false

    /** posição normalizada (0..1 do frame) — `NaN` a menos que [targetFound] */
    var targetX = Float.NaN
    var targetY = Float.NaN
    var confidence = 0f
    var state: RodButtonV9State = RodButtonV9State.SEARCHING

    internal var roiRegion: NormRegion = NormRegion.UNIT

    /** a ROI que foi analisada neste frame (normalizada) */
    val roi: NormRegion get() = roiRegion

    /** cópias dos candidatos do frame, melhor primeiro (nunca as instâncias internas) */
    val candidateData = ArrayList<RodButtonCandidateV9>(8)

    // ---- debug / política (§8) ---------------------------------------------------------------
    var detectorEnabled = true
    var candidateFound = false
    var proposals = 0
    var rejections = 0
    var candidates = 0
    var bestScore = 0f
    var score = 0f
    var chosenIndex = -1
    var templateUsed = false
    var bestCxPx = 0f
    var bestCyPx = 0f
    var bestRadiusPx = 0f
    var bestXNorm = Float.NaN
    var bestYNorm = Float.NaN
    val centerPx = PointF()
    val box = RectF()
    var radiusPx = 0f
    var confirmation = 0
    var requiredFrames = 0
    var anchorX = 0f
    var anchorY = 0f
    var temporalStability = 0f
    var lastKnownX = Float.NaN
    var lastKnownY = Float.NaN
    var msSinceConfirmed = Long.MAX_VALUE
    var jumpNorm = Float.NaN
    var reason = ""
    var frameW = 1
    var frameH = 1
    var frameTimestampNs = 0L

    fun reset() {
        targetFound = false
        targetX = Float.NaN
        targetY = Float.NaN
        confidence = 0f
        state = RodButtonV9State.SEARCHING
        candidateData.clear()
        detectorEnabled = true
        candidateFound = false
        proposals = 0
        candidates = 0
        bestScore = 0f
        score = 0f
        chosenIndex = -1
        templateUsed = false
        bestCxPx = 0f
        bestCyPx = 0f
        bestRadiusPx = 0f
        bestXNorm = Float.NaN
        bestYNorm = Float.NaN
        centerPx.x = 0f
        centerPx.y = 0f
        box.set(0f, 0f, 0f, 0f)
        radiusPx = 0f
        confirmation = 0
        requiredFrames = 0
        anchorX = 0f
        anchorY = 0f
        temporalStability = 0f
        lastKnownX = Float.NaN
        lastKnownY = Float.NaN
        msSinceConfirmed = Long.MAX_VALUE
        jumpNorm = Float.NaN
        reason = ""
    }

    fun centerString(): String =
        if (targetFound) "(${(centerPx.x).toInt()},${(centerPx.y).toInt()})" else "(-)"

    fun roiString(): String =
        "(${(roi.left * frameW).toInt()},${(roi.top * frameH).toInt()}," +
            "${(roi.width * frameW).toInt()},${(roi.height * frameH).toInt()})"
}

// =============================================================================================
//  memória temporal (spec §5/§6): o que separa "elemento de interface" de "blob do cenário"
// =============================================================================================

/**
 * Guarda as últimas observações de candidatos (posição normalizada, raio, score e assinatura da
 * face) e responde:
 *
 *  * **persistência** — este ponto reaparece? (elemento de UI fica onde está; partícula não)
 *  * **estabilidade de posição** — quando reaparece, é no mesmo lugar?
 *  * **estabilidade de aparência** — a face muda muito entre frames? (água/reflexo muda; botão não)
 *
 * 0..1, sempre usado como sinal ponderado (`temporalWeight`) — nunca como veto isolado.
 */
class RodV9TemporalMemory(historyFrames: Int = 8) {
    private val n = historyFrames.coerceIn(2, 64)
    private val xs = FloatArray(n)
    private val ys = FloatArray(n)
    private val rs = FloatArray(n)
    private val scores = FloatArray(n)
    private val sigs = Array(n) { IntArray(16) }
    private var count = 0
    private var head = 0

    val samples: Int get() = count

    fun reset() {
        count = 0
        head = 0
    }

    fun remember(nx: Float, ny: Float, radiusNorm: Float, score: Float, signature: IntArray) {
        xs[head] = nx
        ys[head] = ny
        rs[head] = radiusNorm
        scores[head] = score
        System.arraycopy(signature, 0, sigs[head], 0, min(signature.size, sigs[head].size))
        head = (head + 1) % n
        count = min(n, count + 1)
    }

    fun stabilityAt(nx: Float, ny: Float, radiusNorm: Float, signature: IntArray): Float {
        if (count == 0) return NEUTRAL
        val tol = max(0.015f, radiusNorm * 1.2f)
        var hits = 0
        var sx = 0f
        var sy = 0f
        var appSum = 0f
        var appN = 0
        for (i in 0 until count) {
            if (abs(xs[i] - nx) + abs(ys[i] - ny) > tol) continue
            hits++
            sx += xs[i]
            sy += ys[i]
            val s = ncc(signature, sigs[i])
            if (s.isFinite()) {
                appSum += s
                appN++
            }
        }
        if (hits == 0) return LOW
        val persistence = hits.toFloat() / count
        val meanX = sx / hits
        val meanY = sy / hits
        var varSum = 0f
        for (i in 0 until count) {
            if (abs(xs[i] - nx) + abs(ys[i] - ny) > tol) continue
            val dx = xs[i] - meanX
            val dy = ys[i] - meanY
            varSum += dx * dx + dy * dy
        }
        val scatter = sqrt(varSum / hits)
        val positionStability = (1f - (scatter / (tol * 0.75f))).coerceIn(0f, 1f)
        val appearance = if (appN > 0) ((appSum / appN) * 0.5f + 0.5f).coerceIn(0f, 1f) else NEUTRAL
        return (0.45f * persistence + 0.30f * positionStability + 0.25f * appearance).coerceIn(0f, 1f)
    }

    /** correlação normalizada (−1..1) entre duas assinaturas; `NaN` quando não há variância */
    private fun ncc(a: IntArray, b: IntArray): Float {
        val k = min(a.size, b.size)
        var ma = 0f
        var mb = 0f
        var cnt = 0
        for (i in 0 until k) {
            if (a[i] < 0 || b[i] < 0) continue
            ma += a[i]; mb += b[i]; cnt++
        }
        if (cnt < 4) return Float.NaN
        ma /= cnt
        mb /= cnt
        var num = 0f
        var da = 0f
        var db = 0f
        for (i in 0 until k) {
            if (a[i] < 0 || b[i] < 0) continue
            val va = a[i] - ma
            val vb = b[i] - mb
            num += va * vb
            da += va * va
            db += vb * vb
        }
        if (da < 1e-3f || db < 1e-3f) return Float.NaN
        return (num / sqrt(da * db)).coerceIn(-1f, 1f)
    }

    private companion object {
        const val NEUTRAL = 0.5f
        const val LOW = 0.15f
    }
}

// =============================================================================================
//  template visual do usuário (frames reais)
// =============================================================================================

/**
 * Template visual extraído de um **frame real** fornecido pelo usuário (`RodFrameLab`).
 *
 * O patch cobre a região do botão (a circunferência inscrita em [w]×[h] amostras) e é guardado
 * normalizado (média 0, desvio 1), de modo que o casamento por NCC seja invariante a brilho e
 * escala: a amostragem do candidato usa o raio medido, então o mesmo template vale em qualquer
 * resolução — a referência visual do usuário **não** vira coordenada rígida (spec V9).
 */
class RodTemplateV9(
    val w: Int,
    val h: Int,
    val px: IntArray,
    val mean: Float,
    val std: Float,
) {
    init {
        require(w > 3 && h > 3 && px.size >= w * h)
    }

    /**
     * NCC entre o template e o patch do candidato em ([cx],[cy]) com raio [r]. O patch do
     * candidato é amostrado na **mesma grade relativa** (o raio do template é 1.0 do patch),
     * portanto a comparação é invariante à escala da tela.
     *
     * @return 0..1 (0 = nada parecido, 1 = idêntico); `-1` quando o patch não pôde ser amostrado
     */
    fun match(frame: VisionFrame, cx: Int, cy: Int, r: Float): Float {
        val half = r * TEMPLATE_SPAN
        if (half < 2f) return -1f
        var sum = 0f
        var sumSq = 0f
        var n = 0
        val scratch = patchScratch()
        for (gy in 0 until h) {
            for (gx in 0 until w) {
                val fx = (cx + ((gx + 0.5f) / w - 0.5f) * 2f * half).toInt()
                val fy = (cy + ((gy + 0.5f) / h - 0.5f) * 2f * half).toInt()
                if (fx < 0 || fy < 0 || fx >= frame.width || fy >= frame.height) {
                    scratch[gy * w + gx] = -1
                    continue
                }
                val g = frame.grayAt(fx, fy)
                scratch[gy * w + gx] = g
                sum += g
                sumSq += g.toFloat() * g
                n++
            }
        }
        if (n < (w * h) / 2) return -1f
        val m = sum / n
        val variance = max(0f, sumSq / n - m * m)
        val sd = sqrt(variance)
        if (sd < 1e-3f) return 0f
        var num = 0f
        var da = 0f
        var db = 0f
        for (i in 0 until w * h) {
            val v = scratch[i]
            if (v < 0) continue
            val a = (v - m) / sd
            val b = (px[i] - mean) / std
            num += a * b
            da += a * a
            db += b * b
        }
        if (da < 1e-3f || db < 1e-3f) return 0f
        val ncc = (num / sqrt(da * db)).coerceIn(-1f, 1f)
        return ((ncc + 1f) * 0.5f).coerceIn(0f, 1f)
    }

    fun toJson(): String = buildString {
        append("{\"w\":").append(w).append(",\"h\":").append(h)
        append(",\"mean\":").append(mean).append(",\"std\":").append(std)
        append(",\"px\":[")
        for (i in px.indices) {
            if (i > 0) append(',')
            append(px[i])
        }
        append("]}")
    }

    private fun patchScratch(): IntArray {
        var s = scratch
        if (s.size < w * h) {
            s = IntArray(w * h)
            scratch = s
        }
        return s
    }

    private var scratch = IntArray(0)

    companion object {
        /** o patch do template cobre o botão + um pouco do contorno (× raio) */
        const val TEMPLATE_SPAN = 1.15f

        private const val DEFAULT_SIZE = 24

        /**
         * Extrai um template de um frame real: ([cx],[cy]) é o centro do botão na imagem e [r] o
         * raio em pixels **daquela imagem** (fornecido pelo usuário/por anotação). A extração
         * normaliza o patch, então o mesmo template serve em qualquer resolução.
         */
        fun extract(frame: VisionFrame, cx: Int, cy: Int, r: Float, size: Int = DEFAULT_SIZE): RodTemplateV9 {
            val s = size.coerceIn(8, 64)
            val px = IntArray(s * s)
            val half = r * TEMPLATE_SPAN
            var sum = 0f
            var sumSq = 0f
            var n = 0
            for (gy in 0 until s) {
                for (gx in 0 until s) {
                    val fx = (cx + ((gx + 0.5f) / s - 0.5f) * 2f * half).toInt()
                    val fy = (cy + ((gy + 0.5f) / s - 0.5f) * 2f * half).toInt()
                    val g = if (fx < 0 || fy < 0 || fx >= frame.width || fy >= frame.height) {
                        -1
                    } else {
                        frame.grayAt(fx, fy)
                    }
                    px[gy * s + gx] = g
                    if (g >= 0) {
                        sum += g
                        sumSq += g.toFloat() * g
                        n++
                    }
                }
            }
            val m = if (n > 0) sum / n else 0f
            val variance = if (n > 0) max(0f, sumSq / n - m * m) else 0f
            val sd = max(1e-3f, sqrt(variance))
            val normalized = IntArray(px.size)
            for (i in px.indices) {
                normalized[i] = if (px[i] < 0) -1 else px[i]
            }
            return RodTemplateV9(s, s, normalized, m, sd)
        }

        /** parser tolerante do JSON produzido por [toJson] (sem dependências externas) */
        fun parse(json: String?): RodTemplateV9? {
            if (json.isNullOrBlank()) return null
            val w = intField(json, "w") ?: return null
            val h = intField(json, "h") ?: return null
            val mean = floatField(json, "mean") ?: return null
            val std = floatField(json, "std") ?: 1f
            val start = json.indexOf("\"px\"")
            if (start < 0) return null
            val open = json.indexOf('[', start)
            val close = json.indexOf(']', open)
            if (open < 0 || close < 0) return null
            val body = json.substring(open + 1, close)
            val values = body.split(',').mapNotNull { it.trim().toIntOrNull() }
            if (values.size < w * h || w <= 3 || h <= 3) return null
            return RodTemplateV9(w, h, values.toIntArray(), mean, std)
        }

        private fun intField(json: String, key: String): Int? =
            floatField(json, key)?.toInt()

        private fun floatField(json: String, key: String): Float? {
            val k = "\"$key\""
            val i = json.indexOf(k)
            if (i < 0) return null
            val colon = json.indexOf(':', i + k.length)
            if (colon < 0) return null
            var end = colon + 1
            while (end < json.length && (json[end] == ' ' || json[end] == ':')) end++
            var e = end
            while (e < json.length && (json[e].isDigit() || json[e] == '.' || json[e] == '-' || json[e] == 'E' ||
                    json[e] == 'e' || json[e] == '+')
            ) e++
            return json.substring(end, e).toFloatOrNull()
        }
    }
}

// =============================================================================================
//  workspace da ROI: gradientes, média local e amostradores (sem alocação por frame)
// =============================================================================================

/**
 * Buffers reutilizados cobrindo a ROI **expandida** (ROI + o maior raio avaliado), para que as
 * amostras de contorno/entorno de um botão colado na borda da janela continuem válidas. A ROI
 * define *onde procurar*; ela não recorta o botão.
 *
 * Contém níveis de cinza locais, gradientes (|gx|,|gy|) e média local por *box filter* separável.
 */
