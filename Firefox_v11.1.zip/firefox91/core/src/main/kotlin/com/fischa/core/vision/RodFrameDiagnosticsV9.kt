package com.fischa.core.vision

import com.fischa.core.common.NormRegion

/**
 * V9 §9 — **captura para diagnóstico**.
 *
 * A especificação pede que seja possível salvar/mostrar um frame da ROI quando:
 *
 *  * um candidato é encontrado ([RodDiagEvent.CANDIDATE_FOUND] / [RodDiagEvent.CONFIRMED]);
 *  * nenhum candidato é encontrado ([RodDiagEvent.NO_CANDIDATE]);
 *  * a confiança fica baixa ([RodDiagEvent.LOW_CONFIDENCE]);
 *  * ocorre `TARGET_NOT_FOUND` ([RodDiagEvent.TARGET_NOT_FOUND]).
 *
 * Isso permite comparar **o que o detector vê** com **o que realmente aparece no Roblox** — a
 * diferença entre os dois é a informação mais valiosa para ajustar o detector.
 *
 * O contrato vive no core (sem Android), então ele pode ser exercitado nos testes; a gravação em
 * arquivo é feita pela camada Android (`RodFrameDumper`), e um implementador em memória
 * ([MemoryRodDiagnostics]) serve aos testes automatizados.
 *
 * Nada aqui executa input, e nada aqui altera a detecção: o sink é passivo.
 */
enum class RodDiagEvent {
    /** um candidato viável apareceu dentro da ROI */
    CANDIDATE_FOUND,

    /** a varredura não encontrou nenhum candidato válido */
    NO_CANDIDATE,

    /** havia candidato, mas a confiança ficou abaixo do mínimo */
    LOW_CONFIDENCE,

    /** o alvo foi confirmado (streak completo) */
    CONFIRMED,

    /** orçamento de recuperação esgotado sem evidência suficiente */
    TARGET_NOT_FOUND,

    /** a busca está expandida (escada de recuperação) */
    RECOVERING,
    ;

    /** rótulo curto usado em nome de arquivo/log */
    val tag: String get() = name.lowercase()
}

/**
 * Sink passivo de frames de diagnóstico da V9. Implementado pela camada Android (arquivo PNG) e por
 * [MemoryRodDiagnostics] (testes). Recebe o frame **de leitura** e a ROI em que o evento ocorreu.
 */
fun interface RodFrameDiagnostics {
    fun onRodFrame(
        event: RodDiagEvent,
        frame: VisionFrame,
        roi: NormRegion,
        result: RodV9Result,
        note: String,
    )

    companion object {
        val NONE = RodFrameDiagnostics { _, _, _, _, _ -> }
    }
}

/**
 * Implementação em memória: guarda as últimas ocorrências com um recorte da ROI em ARGB, para que
 * os testes possam verificar *quais eventos foram emitidos* e *o que o detector estava olhando* —
 * e para que o `RodFrameLab` possa desenhar anotações a partir do mesmo recorte.
 */
class MemoryRodDiagnostics(private val maxEvents: Int = 24) : RodFrameDiagnostics {

    class Entry(
        val event: RodDiagEvent,
        val note: String,
        val roi: NormRegion,
        val targetFound: Boolean,
        val candidateFound: Boolean,
        val confidence: Float,
        val score: Float,
        val candidates: Int,
        val state: String,
        val msSinceConfirmed: Long,
        val frameTimestampNs: Long,
        /** recorte da ROI em pixels do frame processado: largura, altura e ARGB linha a linha */
        val cropWidth: Int,
        val cropHeight: Int,
        val cropX0: Int,
        val cropY0: Int,
        val crop: IntArray,
    )

    val entries = ArrayList<Entry>(maxEvents.coerceAtLeast(1))

    override fun onRodFrame(
        event: RodDiagEvent,
        frame: VisionFrame,
        roi: NormRegion,
        result: RodV9Result,
        note: String,
    ) {
        val w = frame.width
        val h = frame.height
        // recorte da ROI com uma folga proporcional: mostra o contexto ao redor da janela
        val pad = 0.10f
        val x0 = ((roi.left - roi.width * pad) * w).toInt().coerceIn(0, w - 1)
        val y0 = ((roi.top - roi.height * pad) * h).toInt().coerceIn(0, h - 1)
        val x1 = ((roi.right + roi.width * pad) * w).toInt().coerceIn(x0 + 1, w)
        val y1 = ((roi.bottom + roi.height * pad) * h).toInt().coerceIn(y0 + 1, h)
        val cw = x1 - x0
        val ch = y1 - y0
        val crop = IntArray(cw * ch)
        for (y in 0 until ch) {
            val src = (y0 + y) * w
            val dst = y * cw
            for (x in 0 until cw) crop[dst + x] = frame.argb[src + x0 + x]
        }
        entries.add(
            Entry(
                event = event,
                note = note,
                roi = roi,
                targetFound = result.targetFound,
                candidateFound = result.candidateFound,
                confidence = result.confidence,
                score = result.score,
                candidates = result.candidates,
                state = result.state.name,
                msSinceConfirmed = result.msSinceConfirmed,
                frameTimestampNs = frame.timestampNs,
                cropWidth = cw,
                cropHeight = ch,
                cropX0 = x0,
                cropY0 = y0,
                crop = crop,
            ),
        )
        while (entries.size > maxEvents) entries.removeAt(0)
    }

    fun count(event: RodDiagEvent): Int = entries.count { it.event == event }
    fun last(event: RodDiagEvent): Entry? = entries.lastOrNull { it.event == event }
    fun clear() = entries.clear()
}
