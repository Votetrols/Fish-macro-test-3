package com.fischa.core.vision

import com.fischa.core.calib.CalibrationConfig
import com.fischa.core.common.NormRegion
import com.fischa.core.common.PointF
import com.fischa.core.common.RectF
import com.fischa.core.config.AppConfig
import com.fischa.core.log.Tags
import com.fischa.core.log.ThrottledLog
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * V8 — detector state machine (spec §13). It is deliberately small and *separate* from the
 * fishing state machine: this one answers only "where is the rod button and how sure am I?".
 *
 * ```
 * INITIAL → SEARCHING → TRACKING → TARGET_LOST → RECOVERING → TRACKING
 *                            ↑                        │
 *                            └──── TARGET_NOT_FOUND ───┘  (recovery budget exhausted)
 * ```
 */
enum class RodV8State {
    /** the window is at the configured initial position (first frame of a session) */
    INITIAL,

    /** the window is searched for the button */
    SEARCHING,

    /** the button was found, confirmed and the window is following it */
    TRACKING,

    /** the button was not found in the current frame (short grace; window stays near last known) */
    TARGET_LOST,

    /** the search expanded around the last known position (and then to the initial area) */
    RECOVERING,
    ;

    val isTracking: Boolean get() = this == TRACKING
    val isRecovery: Boolean get() = this == TARGET_LOST || this == RECOVERING
}

/**
 * V8 §17 — everything the detector reports, and *nothing else*: the detector never issues input.
 *
 * `targetX`/`targetY` are **only** meaningful when [targetFound] is true. When the target is not
 * found they stay `NaN` — the detector never invents a position (spec §7/§20). [targetNotFound]
 * is the explicit `TARGET_NOT_FOUND` answer: the recovery budget was exhausted without a valid
 * candidate.
 */
class RodV8Result {
    var state: RodV8State = RodV8State.INITIAL

    /** true only when a validated candidate passed the temporal confirmation */
    var targetFound = false

    /** recovery budget exhausted: the honest answer is `TARGET_NOT_FOUND` */
    var targetNotFound = false

    /** normalized target position (0..1 of the frame) — `NaN` unless [targetFound] */
    var targetX = Float.NaN
    var targetY = Float.NaN

    /** temporal confidence of the detection (0..1) */
    var confidence = 0f

    /** single-frame candidate score of the winner (0..1) */
    var score = 0f

    /** candidates that survived the search inside the window this frame */
    var candidates = 0

    /** confirmation streak (frames) and how many are required at the measured FPS */
    var confirmation = 0
    var requiredFrames = 0

    /** a candidate was seen (and validated) in this frame — even if not confirmed yet */
    var candidateFound = false

    /** candidate centre/radius in processing pixels (debug §16); valid when [candidateFound] */
    val candidatePx = PointF()
    var candidateRadiusPx = 0f

    /** target centre/radius in processing pixels (only meaningful when [targetFound]) */
    val centerPx = PointF()
    var radiusPx = 0f

    /** the candidate box in processing pixels (debug), empty when no candidate */
    val box = RectF()

    /** last known target position (memory used by the recovery search — spec §6) */
    var lastKnownX = Float.NaN
    var lastKnownY = Float.NaN

    /** target position of the previous confirmed frame (debug: "posição anterior") */
    var previousX = Float.NaN
    var previousY = Float.NaN

    /** true while the detector is in the recovery ladder */
    var recovering = false

    /** 0 = normal window, 1..3 = recovery stages (expanded windows / initial area fallback) */
    var recoveryStage = 0

    /** true when the window currently searched is bigger than the configured one */
    var windowExpanded = false

    /** ms since the target was last seen (0 while tracking) */
    var lostMs = 0L

    /** true when the window moved this frame (debug/log) */
    var moved = false

    /** why the detector is in this state (goes to the log/overlay verbatim) */
    var reason = ""

    var frameW = 1
    var frameH = 1

    /** frame timestamp this result was produced from (same monotonic clock as the pipeline) */
    var frameTimestampNs = 0L

    /** one-line summary of the window configuration in force (debug overlay) */
    var configSummary = ""

    internal var roiRegion: NormRegion = NormRegion.UNIT

    /** the window that was searched on this frame (normalized) — spec §16 debug */
    val roi: NormRegion get() = roiRegion

    fun copyFrom(o: RodV8Result) {
        state = o.state
        targetFound = o.targetFound; targetNotFound = o.targetNotFound
        targetX = o.targetX; targetY = o.targetY
        confidence = o.confidence; score = o.score; candidates = o.candidates
        confirmation = o.confirmation; requiredFrames = o.requiredFrames
        candidateFound = o.candidateFound
        candidatePx.x = o.candidatePx.x; candidatePx.y = o.candidatePx.y
        candidateRadiusPx = o.candidateRadiusPx
        centerPx.x = o.centerPx.x; centerPx.y = o.centerPx.y
        radiusPx = o.radiusPx
        box.set(o.box)
        lastKnownX = o.lastKnownX; lastKnownY = o.lastKnownY
        previousX = o.previousX; previousY = o.previousY
        recovering = o.recovering; recoveryStage = o.recoveryStage
        windowExpanded = o.windowExpanded; lostMs = o.lostMs; moved = o.moved
        reason = o.reason
        frameW = o.frameW; frameH = o.frameH
        frameTimestampNs = o.frameTimestampNs
        configSummary = o.configSummary
        roiRegion = o.roiRegion
    }

    fun centerString(): String =
        if (targetFound) "(${(centerPx.x).toInt()},${(centerPx.y).toInt()})" else "(-)"

    fun roiString(): String =
        "(${(roi.left * frameW).toInt()},${(roi.top * frameH).toInt()}," +
            "${(roi.width * frameW).toInt()},${(roi.height * frameH).toInt()})"
}

/**
 * # Rod Detection V8 — moving detection window
 *
 * The V7 detector found the button by *searching for it* with an auto-calibrated wide pass.
 * V8 replaces that **search strategy** by something simpler and more predictable: a
 * **moving square window** (spec §1).
 *
 * * the window starts at a configurable position/size ([AppConfig.RodV8.initialRoiX] …, all
 *   relative to the frame, so it works at any resolution);
 * * inside the window, detection uses **the same visual mechanism the project already validated**
 *   — [RodWindowDetector] (coarse dark-disc pass → blob measurement → ring verification → scored
 *   candidate features). V8 does *not* re-invent recognition;
 * * when the target is validated, the window **follows** it, bounded by
 *   [AppConfig.RodV8.maxMovePerFrame] (spec §4), a [AppConfig.RodV8.deadZone] against jitter
 *   (spec §9) and simple [AppConfig.RodV8.smoothing] (spec §10);
 * * the window **never leaves the frame** (spec §11);
 * * when the target disappears the state goes `TARGET_LOST` → `RECOVERING`, expanding the search
 *   around the **last known position** in stages, then falling back to the configured initial
 *   area, and finally answering **`TARGET_NOT_FOUND`** instead of inventing a position (spec §7);
 * * `TRACKING` is only entered after [AppConfig.RodV8.confirmationFrames] consecutive frames
 *   (FPS-robust, spec §14/§15) with confidence above [AppConfig.RodV8.minimumConfidence];
 * * everything is time-stamped: loss/recovery/confirmation use `ns` deltas, never an assumed FPS.
 *
 * ## What it does NOT do
 *
 * It never touches input (spec §17): no gesture, no executor, no safety call. It publishes
 * [RodV8Result] (`targetFound`, `targetX`, `targetY`, `confidence`, `state`) and the pipeline —
 * which owns `InputSafetyGuard` and `AndroidInputExecutor` — decides everything else.
 */
class RodDetectionV8(
    private val cfg: AppConfig,
    private val log: ThrottledLog,
) {
    private val v8 = cfg.rodV8

    /** the shared, already validated visual mechanism — V8 only changes *where* it looks */
    private val win = RodWindowDetector(cfg.rodV7)
    private val history = CandidateHistory()

    // ---- window: top-left corner (normalized) + the configured base size --------------------
    private var roiX = v8.initialRoiX
    private var roiY = v8.initialRoiY
    private val baseW = v8.roiWidth
    private val baseH = v8.roiHeight

    // ---- state ------------------------------------------------------------------------------
    private var state = RodV8State.INITIAL
    private var started = false
    private var streak = 0
    private var streakStartNs = 0L
    private var anchorX = 0f
    private var anchorY = 0f
    private var confidence = 0f
    private var lastKnownX = Float.NaN
    private var lastKnownY = Float.NaN
    private var previousX = Float.NaN
    private var previousY = Float.NaN
    private var freshRequired = false
    private var lostSinceNs = 0L
    private var recoverySinceNs = 0L
    private var recoveryStage = 0
    private var exhausted = false
    private var lastNs = 0L
    private var fps = 30f
    private var lastLogState: RodV8State? = null

    private val candidates = ArrayList<RodCandidate>(16)
    private val snapshot = RodV8Result()

    /** Read-only views (the pipeline copies what it needs; the snapshot is the source of truth). */
    val currentState: RodV8State get() = state
    val out: RodV8Result get() = snapshot
    val tracking: Boolean get() = state == RodV8State.TRACKING
    val window: NormRegion get() = snapshot.roi

    /**
     * A new fishing cycle may only begin from a **fresh** visual confirmation: the window and the
     * lock survive, but `TRACKING`/`targetFound` have to be reconquered with a new streak.
     */
    fun requireFreshConfirmation(reason: String) {
        freshRequired = true
        streak = 0
        snapshot.targetFound = false
        log.i(Tags.ROD_V8, "fresh", "[ROD_V8] reconfirmação exigida ($reason)")
    }

    /** Full reset (new capture session): window back to the configured position. */
    fun reset(nowNs: Long, reason: String) {
        state = RodV8State.INITIAL
        started = false
        streak = 0; streakStartNs = 0L
        confidence = 0f
        lastKnownX = Float.NaN; lastKnownY = Float.NaN
        previousX = Float.NaN; previousY = Float.NaN
        freshRequired = false
        lostSinceNs = 0L; recoverySinceNs = 0L; recoveryStage = 0; exhausted = false
        roiX = v8.initialRoiX; roiY = v8.initialRoiY
        history.reset()
        snapshot.targetFound = false; snapshot.targetNotFound = false
        snapshot.targetX = Float.NaN; snapshot.targetY = Float.NaN
        snapshot.candidateFound = false; snapshot.confirmation = 0
        log.i(Tags.ROD_V8, "reset", "[ROD_V8] reset ($reason)")
    }

    /**
     * One frame → one result. Never allocates the frame, never touches input.
     *
     * @param fpsMeasured pipeline FPS measured by the host (never assumed); it only makes the
     *        confirmation count FPS-robust — falling back to ~30 when unknown.
     * @param nowNs frame timestamp on the pipeline's monotonic clock.
     */
    fun update(frame: VisionFrame, fpsMeasured: Float, nowNs: Long): RodV8Result {
        if (fpsMeasured.isFinite() && fpsMeasured > 0.5f) fps = fpsMeasured
        val w = frame.width
        val h = frame.height
        val dtSec = if (lastNs == 0L) 1f / fps else ((nowNs - lastNs) / 1e9f).coerceIn(0.001f, 0.5f)
        lastNs = nowNs
        // INITIAL is the very first frame (window at the configured position); after that the
        // detector is genuinely searching.
        if (!started) started = true else if (state == RodV8State.INITIAL) state = RodV8State.SEARCHING

        val required = requiredFrames()
        val window = currentWindow()
        val windowPx = window.toPx(w, h)
        val calib = calibFor(window, w, h, required)

        // ---- detection INSIDE the window (single source: the shared visual mechanism) --------
        win.scan(frame, windowPx, calib, v8.searchStepPx, HIT_LIMIT, CENTER_STRIDE)
        val found = win.refine(
            frame, v8.searchStepPx, calib, history::persistenceAt, v8.maxRefinedCandidates, candidates,
        )

        // ---- publish the frame basics --------------------------------------------------------
        snapshot.frameW = w
        snapshot.frameH = h
        snapshot.frameTimestampNs = nowNs
        snapshot.configSummary = configSummary()
        snapshot.roiRegion = window
        snapshot.candidates = found
        snapshot.requiredFrames = required
        snapshot.lostMs = if (lostSinceNs == 0L) 0L else (nowNs - lostSinceNs) / 1_000_000L
        snapshot.moved = false
        snapshot.candidateFound = false
        snapshot.targetX = Float.NaN
        snapshot.targetY = Float.NaN
        snapshot.lastKnownX = lastKnownX
        snapshot.lastKnownY = lastKnownY
        snapshot.previousX = previousX
        snapshot.previousY = previousY

        val candidate = if (found > 0) win.best else null
        val rejection = if (candidate != null) validationFailure(candidate, w, h, jumpTolerance(window)) else null
        if (candidate != null && rejection == null) {
            onCandidate(candidate, w, h, nowNs, required)
        } else {
            if (candidate != null) {
                // §5: a candidate that does not validate never moves the window and never publishes
                log.i(
                    Tags.ROD_V8, "reject",
                    "[ROD_V8] candidato rejeitado na validação: $rejection " +
                        "(score=${"%.2f".format(candidate.score)} r=${"%.1f".format(candidate.r)} " +
                        "c=(${(candidate.cx).toInt()},${(candidate.cy).toInt()}))",
                )
            }
            onMiss(nowNs, dtSec, candidate != null)
        }

        snapshot.state = state
        snapshot.recovering = state.isRecovery
        snapshot.recoveryStage = if (state.isRecovery) recoveryStage else 0
        snapshot.windowExpanded = window.width > baseW * 1.001f || window.height > baseH * 1.001f
        snapshot.targetNotFound = exhausted
        if (state != lastLogState) {
            lastLogState = state
            log.i(Tags.ROD_V8, "state", "[STATE] ROD_V8=${state.name}")
        }
        return snapshot
    }

    // ---------------------------------------------------------------------------------------
    //  state handling
    // ---------------------------------------------------------------------------------------

    private fun onCandidate(c: RodCandidate, w: Int, h: Int, nowNs: Long, required: Int) {
        val nx = c.cx / w
        val ny = c.cy / h

        // §14: never confirm from a single frame — an anchored streak inside a time window
        val driftTol = max(DRIFT_TOL_MIN, DRIFT_TOL_FACTOR * (c.r / w))
        val keepsStreak = streak > 0 && nowNs - streakStartNs <= v8.confirmWindowMs * 1_000_000L &&
            abs(nx - anchorX) + abs(ny - anchorY) <= driftTol
        if (keepsStreak) {
            streak++
        } else {
            streak = 1
            anchorX = nx; anchorY = ny; streakStartNs = nowNs
        }
        history.remember(nx, ny)

        // confidence combines the frame evidence with the temporal evidence
        val gain = min(1f, streak.toFloat() / required)
        confidence = (c.score * (0.72f + 0.28f * gain)).coerceIn(0f, 1f)
        val confirmed = streak >= required &&
            c.score >= v8.minimumConfidence &&
            confidence >= v8.minimumConfidence
        if (confirmed) freshRequired = false

        snapshot.candidateFound = true
        snapshot.candidatePx.x = c.cx; snapshot.candidatePx.y = c.cy
        snapshot.candidateRadiusPx = c.r
        snapshot.box.set(c.cx - c.r, c.cy - c.r, c.cx + c.r, c.cy + c.r)
        snapshot.score = c.score
        snapshot.confidence = confidence
        snapshot.confirmation = streak

        if (confirmed) {
            // §3: the window follows the target; §8: normal mode and normal window size again
            previousX = lastKnownX
            previousY = lastKnownY
            lastKnownX = nx
            lastKnownY = ny
            lostSinceNs = 0L
            recoverySinceNs = 0L
            recoveryStage = 0
            exhausted = false
            freshRequired = false
            state = RodV8State.TRACKING
            moveWindowTowards(nx, ny)
            snapshot.targetFound = true
            snapshot.targetNotFound = false
            snapshot.targetX = nx
            snapshot.targetY = ny
            snapshot.centerPx.x = c.cx
            snapshot.centerPx.y = c.cy
            snapshot.radiusPx = c.r
            snapshot.reason = "TARGET_FOUND (tracking)"
            log.i(
                Tags.ROD_V8, "found",
                "[ROD_V8] TARGET_FOUND center=(${(c.cx).toInt()},${(c.cy).toInt()}) r=${"%.1f".format(c.r)} " +
                    "score=${"%.2f".format(c.score)} conf=${"%.2f".format(confidence)} streak=$streak/$required " +
                    "roi=${snapshot.roiString()}",
            )
        } else {
            // a validated candidate that is not confirmed yet: the window may approach it, but the
            // state is not TRACKING and no target is published (§5/§14)
            snapshot.targetFound = false
            state = if (state.isRecovery) RodV8State.RECOVERING else RodV8State.SEARCHING
            if (!state.isRecovery) moveWindowTowards(nx, ny)
            val why = if (freshRequired) "reconfirmação" else "confirmação"
            snapshot.reason = when {
                c.score < v8.minimumConfidence ->
                    "$why: score ${"%.2f".format(c.score)} < mínimo ${"%.2f".format(v8.minimumConfidence)}"
                else -> "$why: ${streak}/${required} (conf ${"%.2f".format(confidence)})"
            }
            log.i(
                Tags.ROD_V8, "confirming",
                "[ROD_V8] $why candidato streak=$streak/$required score=${"%.2f".format(c.score)} " +
                    "conf=${"%.2f".format(confidence)} center=(${(c.cx).toInt()},${(c.cy).toInt()})",
            )
        }
    }

    private fun onMiss(nowNs: Long, dtSec: Float, hadCandidate: Boolean) {
        streak = 0
        // time-based decay: identical behaviour at 15 or 60 FPS
        confidence = (confidence * exp(-dtSec / v8.confidenceDecaySec)).coerceIn(0f, 1f)
        snapshot.candidateFound = false
        snapshot.targetFound = false
        snapshot.targetX = Float.NaN
        snapshot.targetY = Float.NaN
        snapshot.score = 0f
        snapshot.confidence = confidence
        snapshot.confirmation = 0
        if (lostSinceNs == 0L) lostSinceNs = nowNs
        val lostMs = (nowNs - lostSinceNs) / 1_000_000L
        snapshot.lostMs = lostMs

        if (state == RodV8State.TRACKING) {
            // spec §7: a single missing frame does not mean the target is gone — but the detector
            // never publishes a position it cannot see either.
            state = RodV8State.TARGET_LOST
            snapshot.reason = "TARGET_LOST (alvo ausente na janela, ${lostMs}ms)"
            log.w(Tags.ROD_V8, "lost", "[ROD_V8] TARGET_LOST (${lostMs}ms sem detecção) → recuperação")
            return
        }
        if (lostSinceNs > 0L && lostMs <= v8.lostGraceMs) {
            // §7: a missing frame is not "the target is gone". During the grace the window stays
            // exactly where it was (near the last known position, or at the configured one while
            // the detector is still acquiring) and nothing is invented.
            state = when {
                state == RodV8State.INITIAL -> RodV8State.INITIAL      // frame 1: configuração inicial
                lastKnownX.isFinite() -> RodV8State.TARGET_LOST
                else -> RodV8State.SEARCHING
            }
            snapshot.reason = if (lastKnownX.isFinite()) {
                "TARGET_LOST ${lostMs}ms/${v8.lostGraceMs}ms (aguardando)"
            } else {
                "SEARCHING ${lostMs}ms/${v8.lostGraceMs}ms (sem candidato na janela)"
            }
            return
        }
        enterRecovery(nowNs, hadCandidate)
    }

    /**
     * Spec §7 — staged recovery. Stage 1/2 expand the search around the **last known position**;
     * stage 3 falls back to the **configured initial area**; when the whole budget is spent the
     * detector answers `TARGET_NOT_FOUND` (and starts another ladder instead of giving up
     * silently — a target that comes back is still detected).
     */
    private fun enterRecovery(nowNs: Long, hadCandidate: Boolean) {
        if (recoverySinceNs == 0L) {
            recoverySinceNs = nowNs
            recoveryStage = 1
            exhausted = false
        }
        val elapsed = (nowNs - recoverySinceNs) / 1_000_000L
        if (elapsed > v8.recoveryTimeout) {
            // §7 etapa 4: nothing valid was found → the honest answer, not an invented position
            if (!exhausted) {
                exhausted = true
                log.w(
                    Tags.ROD_V8, "notfound",
                    "[ROD_V8] TARGET_NOT_FOUND (${elapsed}ms de recuperação, estágios 1..3 esgotados) " +
                        "lastKnown=(${if (lastKnownX.isFinite()) (lastKnownX * snapshot.frameW).toInt() else -1}," +
                        "${if (lastKnownY.isFinite()) (lastKnownY * snapshot.frameH).toInt() else -1})",
                )
            }
            // restart the ladder (window back to the smallest expansion near the last known spot)
            recoverySinceNs = nowNs
            recoveryStage = 1
        } else {
            recoveryStage = stageFor(elapsed)
        }
        state = RodV8State.RECOVERING
        snapshot.targetNotFound = exhausted
        snapshot.reason = "RECOVERING etapa $recoveryStage/${RECOVERY_STAGES} " +
            "(busca ampliada, alvo não encontrado${if (hadCandidate) ": candidato rejeitado" else ""})"
        log.i(
            Tags.ROD_V8, "recovery",
            "[ROD_V8] RECOVERING etapa=$recoveryStage rota=${recoveryWindow().describe()} " +
                "lastKnown=(${if (lastKnownX.isFinite()) (lastKnownX * snapshot.frameW).toInt() else -1}," +
                "${if (lastKnownY.isFinite()) (lastKnownY * snapshot.frameH).toInt() else -1})",
        )
    }

    private fun stageFor(elapsedMs: Long): Int = when {
        elapsedMs <= v8.recoveryTimeout / 3 -> 1
        elapsedMs <= (v8.recoveryTimeout * 2) / 3 -> 2
        else -> 3
    }

    // ---------------------------------------------------------------------------------------
    //  window geometry (spec §3/§4/§9/§10/§11/§12)
    // ---------------------------------------------------------------------------------------

    /** the window that must be searched on this frame. */
    private fun currentWindow(): NormRegion = when (state) {
        RodV8State.RECOVERING -> recoveryWindow()
        // TARGET_LOST keeps the window at its last position (grace) — never teleporting on a miss
        else -> baseWindow()
    }

    private fun baseWindow(): NormRegion =
        fitInside(NormRegion(roiX, roiY, roiX + baseW, roiY + baseH))

    private fun initialWindow(): NormRegion =
        fitInside(NormRegion(v8.initialRoiX, v8.initialRoiY, v8.initialRoiX + baseW, v8.initialRoiY + baseH))

    private fun recoveryWindow(): NormRegion {
        val ax = if (lastKnownX.isFinite()) lastKnownX else roiX + baseW * 0.5f
        val ay = if (lastKnownY.isFinite()) lastKnownY else roiY + baseH * 0.5f
        return when (recoveryStage) {
            1 -> fitInside(centered(ax, ay, baseW * v8.recoveryExpansion, baseH * v8.recoveryExpansion))
            2 -> fitInside(
                centered(
                    ax, ay,
                    baseW * v8.recoveryExpansion * v8.recoveryExpansion,
                    baseH * v8.recoveryExpansion * v8.recoveryExpansion,
                ),
            )
            // §7 etapa 3: the configured initial area is the last resort
            else -> initialWindow()
        }
    }

    private fun centered(cx: Float, cy: Float, w: Float, h: Float): NormRegion =
        NormRegion(cx - w * 0.5f, cy - h * 0.5f, cx + w * 0.5f, cy + h * 0.5f)

    /**
     * §11 — the window can never leave the frame: the size is kept and the rectangle is *shifted*
     * back inside (only shrinking if it is physically larger than the whole frame).
     */
    private fun fitInside(region: NormRegion): NormRegion {
        val w = min(region.width, 1f)
        val h = min(region.height, 1f)
        val cx = region.centerX.coerceIn(w * 0.5f, 1f - w * 0.5f)
        val cy = region.centerY.coerceIn(h * 0.5f, 1f - h * 0.5f)
        return NormRegion(cx - w * 0.5f, cy - h * 0.5f, cx + w * 0.5f, cy + h * 0.5f)
    }

    /**
     * §3/§4/§9/§10 — move the window towards the (already validated) target: no movement inside
     * the dead zone, smoothed, and never more than [AppConfig.RodV8.maxMovePerFrame] per frame,
     * so one suspicious detection can never make the ROI jump across the screen.
     */
    private fun moveWindowTowards(nx: Float, ny: Float) {
        val cx = roiX + baseW * 0.5f
        val cy = roiY + baseH * 0.5f
        val dxT = nx - cx
        val dyT = ny - cy
        if (abs(dxT) <= v8.deadZone && abs(dyT) <= v8.deadZone) return
        val sx = cx * v8.smoothing + nx * (1f - v8.smoothing)
        val sy = cy * v8.smoothing + ny * (1f - v8.smoothing)
        val dx = (sx - cx).coerceIn(-v8.maxMovePerFrame, v8.maxMovePerFrame)
        val dy = (sy - cy).coerceIn(-v8.maxMovePerFrame, v8.maxMovePerFrame)
        val moved = fitInside(centered(cx + dx, cy + dy, baseW, baseH))
        snapshot.moved = true
        roiX = moved.left
        roiY = moved.top
    }

    // ---------------------------------------------------------------------------------------
    //  validation (spec §5) and confirmation requirements (spec §14/§15)
    // ---------------------------------------------------------------------------------------

    /**
     * §5 — a candidate only counts after: minimum confidence (viability floor), plausible size
     * (calibrated band), fully inside the frame and spatially consistent with the last known
     * position while a lock exists.
     *
     * @return `null` when the candidate is valid, otherwise the human readable reason it was not.
     */
    private fun validationFailure(c: RodCandidate, w: Int, h: Int, tolerance: Float): String? {
        if (!c.score.isFinite()) return "score não finito"
        if (c.score < CANDIDATE_FLOOR) return "score ${"%.2f".format(c.score)} < piso ${"%.2f".format(CANDIDATE_FLOOR)}"
        if (c.cx < c.r * 0.5f || c.cy < c.r * 0.5f ||
            c.cx > w - c.r * 0.5f || c.cy > h - c.r * 0.5f
        ) return "borda do frame (c=(${c.cx.toInt()},${c.cy.toInt()}) r=${"%.1f".format(c.r)})"
        // the measured radius is anchored on the dark blob (≈0.7..1.0 of the visual ring radius),
        // so the plausibility band is deliberately forgiving: it rejects grotesque sizes (a speck
        // or a huge blob), not the normal variation of the button's rendering.
        val rNorm = c.r / w
        if (rNorm < v8.minSizeNormalized * SIZE_BAND_SLACK_LO) {
            return "tamanho ${"%.4f".format(rNorm)}W < mínimo " +
                "${"%.4f".format(v8.minSizeNormalized * SIZE_BAND_SLACK_LO)}W"
        }
        if (rNorm > v8.maxSizeNormalized * SIZE_BAND_SLACK_HI) {
            return "tamanho ${"%.4f".format(rNorm)}W > máximo " +
                "${"%.4f".format(v8.maxSizeNormalized * SIZE_BAND_SLACK_HI)}W"
        }
        if (lastKnownX.isFinite() && state != RodV8State.INITIAL) {
            val d = hypot(c.cx / w - lastKnownX, c.cy / h - lastKnownY)
            if (d > tolerance) {
                return "inconsistência espacial d=${"%.3f".format(d)} > tol=${"%.3f".format(tolerance)}"
            }
        }
        return null
    }

    /**
     * Spatial consistency tolerance: while tracking it is [AppConfig.RodV8.maxCandidateJump]; while
     * recovering it grows with the (deliberately expanded) window, because looking farther is
     * exactly the point of the recovery stages.
     */
    private fun jumpTolerance(window: NormRegion): Float =
        if (state.isRecovery) max(v8.maxCandidateJump, 0.5f * min(window.width, window.height))
        else v8.maxCandidateJump

    /** §14/§15: frames required at the measured FPS, never below the configured minimum. */
    private fun requiredFrames(): Int {
        val fromTime = (v8.targetConfirmMs / 1000f * fps).roundToInt()
        return max(v8.confirmationFrames, fromTime.coerceIn(1, MAX_CONFIRM_FRAMES))
    }

    /**
     * The calibration object the shared mechanism consumes. Everything comes from the V8 config;
     * the *position prior* is the window itself, so "consistency" means "near the centre of the
     * window this frame is looking at".
     */
    private fun calibFor(window: NormRegion, w: Int, h: Int, required: Int): CalibrationConfig =
        CalibrationConfig(
            screenWidth = w,
            screenHeight = h,
            scale = 1f,
            gameRegion = window,
            estimatedFps = fps,
            rodSearchRegion = window,
            minCandidateSize = v8.minSizeNormalized,
            maxCandidateSize = v8.maxSizeNormalized,
            confidenceThreshold = v8.minimumConfidence,
            temporalConfirmationFrames = required,
            roiPadding = 0f,
            processingWidth = w,
            processingHeight = h,
            minRingDelta = v8.minRingDelta,
            searchStepCoarse = v8.searchStepPx,
            targetConfirmMs = v8.targetConfirmMs,
        )

    /** One-line, greppable description of the moving window in force (log + debug overlay §16). */
    fun configSummary(): String =
        "janela=${"%.2f".format(baseW)}x${"%.2f".format(baseH)} inicial=(" +
            "${"%.2f".format(v8.initialRoiX)},${"%.2f".format(v8.initialRoiY)}) " +
            "maxMove=${"%.3f".format(v8.maxMovePerFrame)} deadZone=${"%.3f".format(v8.deadZone)} " +
            "smooth=${"%.2f".format(v8.smoothing)} confMin=${"%.2f".format(v8.minimumConfidence)} " +
            "frames=${v8.confirmationFrames} expansao=${"%.2f".format(v8.recoveryExpansion)} " +
            "recovery=${v8.recoveryTimeout}ms"

    companion object {
        /** below this the frame has no usable evidence at all (same floor the V7 detector uses) */
        private const val CANDIDATE_FLOOR = 0.35f

        /** the plausibility band tolerates the blob↔ring difference by a wide margin (§5) */
        private const val SIZE_BAND_SLACK_LO = 0.6f
        private const val SIZE_BAND_SLACK_HI = 1.3f

        /** accepted center drift while confirming: max(min, factor × radius), normalized */
        private const val DRIFT_TOL_FACTOR = 0.8f
        private const val DRIFT_TOL_MIN = 0.020f

        private const val MAX_CONFIRM_FRAMES = 12
        private const val HIT_LIMIT = 8
        private const val CENTER_STRIDE = 1

        /** number of recovery stages (expanded → more expanded → initial area fallback) */
        const val RECOVERY_STAGES = 3

        /** explicit answer of the detector when the recovery budget is exhausted (spec §7) */
        const val TARGET_NOT_FOUND = "TARGET_NOT_FOUND"

        /** explicit answer when a validated, confirmed target is available */
        const val TARGET_FOUND = "TARGET_FOUND"
    }
}
