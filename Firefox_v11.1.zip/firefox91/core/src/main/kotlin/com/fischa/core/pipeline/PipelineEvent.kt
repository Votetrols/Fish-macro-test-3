package com.fischa.core.pipeline

import com.fischa.core.control.ControlAction
import com.fischa.core.safety.RobloxForegroundStatus
import com.fischa.core.state.AutomationState
import com.fischa.core.state.FishingState
import com.fischa.core.vision.DetSnapshot

/**
 * Platform signals for one captured frame. [currentTimeNs] must use the same monotonic clock
 * as [frameTimestampNs]; replay defaults to the frame timestamp, Android supplies now() so
 * stale frames are rejected before an input command.
 */
class PipelineInput(
    var frameTimestampNs: Long = 0L,
    var currentTimeNs: Long = frameTimestampNs,
    var captureHealthy: Boolean = false,
    var robloxDetected: Boolean = false,
    var inputAuthorized: Boolean = false,
    var overlaySuspected: Boolean = false,
    var macroEnabled: Boolean = false,
    /** Explicit, session-scoped user opt-in. False in all defaults and replay runs. */
    var realInputEnabled: Boolean = false,
    var foregroundPackage: String = RobloxForegroundStatus.UNKNOWN,
    var foregroundActivityWindow: String = RobloxForegroundStatus.UNKNOWN,
    var foregroundBlockReason: String = "FOREGROUND_UNKNOWN",
    var foregroundTimestampMs: Long = 0L,
    // ---- V7 §1: platform screen facts for AUTO_CALIBRATION (0/unknown in replay & tests) ----
    var screenWidthPx: Int = 0,
    var screenHeightPx: Int = 0,
    var densityDpi: Int = 0,
    var rotationDeg: Int = 0,
    var appWindowWidthPx: Int = 0,
    var appWindowHeightPx: Int = 0,
    var statusBarPx: Int = 0,
    var navBarPx: Int = 0,
)

class PipelineOutput {
    // detection snapshots (owned instances — read before next call or copy)
    val fishingButton = DetSnapshot()
    val shake = DetSnapshot()
    val bar = DetSnapshot()
    val player = DetSnapshot()
    val fish = DetSnapshot()
    val progress = DetSnapshot()
    val catchConfirm = DetSnapshot()

    var state: FishingState = FishingState.IDLE
    var stateReason: String = ""

    // ---- V9.1 §3/§13: estado da AUTOMAÇÃO (separado do ciclo de pesca) ----------------------
    /** APP_IDLE / APP_READY / FISHING_ACTIVE / FISHING_STOPPING */
    var automationState: AutomationState = AutomationState.APP_IDLE
    /** linha de diagnóstico pronta: `AUTOMATION: OFF|READY|ACTIVE|STOPPING` */
    var automationLine: String = "AUTOMATION: OFF"
    /** motivo/última transição (vai para o log/overlay sem tradução) */
    var automationReason: String = ""

    var fishXNorm = 0f
    var playerXNorm = 0f
    var errorNorm = 0f
    var fishVel = 0f
    var playerVel = 0f
    var desiredVel = 0f
    var progressValue = 0f
    var progressRate = 0f
    var globalConfidence = 0f
    var frameAgeMs = Long.MAX_VALUE

    /** the control action the controller *intends*; executed only if safety allows */
    var intendedAction: ControlAction = ControlAction.NONE
    var tapDurationMs = 0
    var holdActive = false
    var decisionReason = ""

    var inputIssued = false
    var inputDeniedReason = ""
    var inputAuthorized = false
    var realInputEnabled = false
    var robloxDetected = false
    var foregroundPackage: String = RobloxForegroundStatus.UNKNOWN
    var foregroundActivityWindow: String = RobloxForegroundStatus.UNKNOWN
    var foregroundBlockReason: String = "FOREGROUND_UNKNOWN"
    var emergencyLatched = false
    var armed = false
    var shakeSessionTaps = 0
    var shakeSession = 0
    var castPhase = ""

    // V5 rod-button gate (spec §3/§4/§20 test mode)
    var rodDetected = false
    var rodConfidence = 0f
    var rodConfirmed = false
    var castAuthorized = false
    var castGateReason = ""

    // pixel-space helpers for the harness/tests (processing coordinates)
    val barRectPx = FloatArray(4)
    var barLocked = false
    var blockCenterPx = -1f
    var fishCenterPx = -1f

    // ---- V7 §2…§6, §9: auto-calibrated rod detection (all normalized; no fixed coordinates) --
    /** detection state machine: INIT/AUTO_CALIBRATION/SEARCHING_ROD/…/TRACKING_ROD */
    var rodState = "INIT"
    /** single-frame candidateScore of the winning candidate */
    var rodScore = 0f
    /** candidates that survived the wide search this frame */
    var rodCandidates = 0
    /** temporal confirmation streak and the (FPS-adaptive) requirement */
    var rodStreak = 0
    var rodRequiredFrames = 0
    /** true while the cheap local search inside the dynamic ROI is running */
    var rodTracking = false
    /** ms without a detection (0 while tracking) */
    var rodLostMs = 0L
    /** why the rod is not confirmed right now (goes to the log/overlay verbatim) */
    var rodReason = ""
    /** dynamic ROI around the detected button (normalized l,t,r,b) */
    val rodRoiNorm = FloatArray(4)
    /** current wide-search region (normalized) */
    val rodSearchNorm = FloatArray(4)
    /** detected button centre (normalized) */
    val rodCenterNorm = FloatArray(2)
    var rodCalibrationDone = false
    /** one-line human summary of the calibration in force */
    var rodCalibration = ""
    var rodCandidateDetail = ""

    // ---- V8 (spec Rod Detection V8): the moving window is the main detector ------------------
    /** which rod detector produced the fields above: "V8" (moving window) or "V7" (wide search) */
    var rodDetector = "V8"
    /** V8 §17 — the only answer the detector gives: target found + position + confidence + state */
    var rodV8TargetFound = false
    /** V8 §7 — recovery budget exhausted: the honest `TARGET_NOT_FOUND` (never an invented spot) */
    var rodV8TargetNotFound = false
    /** V8 §7/§8 — recovery ladder indication and its current stage (0 = normal window) */
    var rodV8Recovering = false
    var rodV8RecoveryStage = 0
    /** V8 §16 — debug: candidate position/confidence seen inside the window this frame */
    var rodV8CandidateFound = false
    var rodV8CandidateConfidence = 0f
    /** true when the window currently searched is bigger than the configured one (recovery) */
    var rodV8WindowExpanded = false
    /** V8 §16 — normalized candidate position (debug) */
    val rodV8CandidateNorm = FloatArray(2)
    /** V8 §16 — normalized target position of the previous confirmed frame (debug) */
    val rodV8PreviousNorm = FloatArray(2)

    // ---- V9 (spec Rod Detection V9 §8): debug da identificação visual ------------------------
    /** estado **visual** do RodButtonDetectorV9 (SEARCHING/CANDIDATE/CONFIRMING/CONFIRMED/LOST) */
    var rodV9DetectorState = "SEARCHING"
    /** `SHOW_DETECTION_DEBUG` — quando false o overlay mostra só o essencial */
    var rodV9ShowDetectionDebug = true
    /** quantos candidatos foram publicados neste frame (≤ [MAX_V9_CANDIDATES]) */
    var rodV9CandidateCount = 0
    /** candidatos (x,y normalizados, pares) — todos, na ordem do score */
    val rodV9CandidatesNorm = FloatArray(MAX_V9_CANDIDATES * 2)
    val rodV9CandidateScore = FloatArray(MAX_V9_CANDIDATES)
    val rodV9CandidateRadiusNorm = FloatArray(MAX_V9_CANDIDATES)
    /** candidato escolhido (normalizado) e seu score/raio */
    val rodV9ChosenNorm = FloatArray(2)
    var rodV9ChosenRadiusNorm = 0f
    var rodV9ChosenScore = 0f
    /** lastKnownTarget (memória de rastreamento; pode existir mesmo sem alvo no frame) */
    var rodV9HasLastKnown = false
    val rodV9LastKnownNorm = FloatArray(2)
    var rodV9MsSinceConfirmed = Long.MAX_VALUE
    /** linha pronta para o overlay/log com estado, ROI, candidatos, confiança e recuperação */
    var rodV9DebugText = ""

    // ---- V7 §10: layer separation (VISION/DETECTION/DECISION may run; INPUT stays blocked) --
    var layerVision = "ACTIVE"
    var layerDetection = "ACTIVE"
    var layerDecision = "ACTIVE"
    var layerInput = "DISABLED"
    val realInputLocked: Boolean get() = layerInput == "DISABLED"

    companion object {
        /** teto de candidatos publicados no debug (o detector mede no máximo `maxCandidates`) */
        const val MAX_V9_CANDIDATES = 16
    }
}
