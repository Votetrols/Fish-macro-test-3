package com.fischa.core.tools

import com.fischa.core.common.NormRegion
import com.fischa.core.config.AppConfig
import com.fischa.core.config.RodDetectorKind
import com.fischa.core.log.LogSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.vision.RodDetectionV9
import com.fischa.core.vision.RodTemplateV9
import com.fischa.core.vision.RodV9Result
import com.fischa.core.vision.VisionFrame
import java.awt.Color
import java.awt.Font
import java.awt.Graphics2D
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO
import kotlin.math.hypot
import kotlin.system.exitProcess

/**
 * # RodFrameLab — modo de teste com **frames reais** (spec V9 §12)
 *
 * O critério de aceitação da V9 é explícito: **testes sintéticos não bastam** para declarar que o
 * detector funciona no Roblox. Este laboratório roda exatamente o mesmo
 * `VisionPipeline → RodDetectionV9 → RodButtonDetectorV9` sobre **imagens reais** fornecidas pelo
 * usuário (capturas de tela do jogo, frames extraídos de um vídeo, o print que ele já mandou) e
 * devolve:
 *
 *  * um **CSV** por frame (estado, alvo encontrado, posição, confiança, nº de candidatos, erro em
 *    pixels quando existe anotação);
 *  * **PNGs anotados** mostrando o que o detector viu (ROI, candidatos, escolhido, alvo, verdade);
 *  * um **resumo PASS/FAIL** comparando com a anotação (`gt.csv`).
 *
 * E, com o comando `template`, extrai o **template visual do botão** de uma imagem real — o arquivo
 * JSON que o app carrega em `files/rod_template_v9.json` para reforçar o `visualMatch`. A imagem do
 * usuário entra como *referência visual*, nunca como coordenada rígida (§ "não transforme os pixels
 * da imagem de referência em coordenadas rígidas").
 *
 * ## Uso
 *
 * ```bash
 * # 1) coloque os frames reais numa pasta (qualquer nome de arquivo .png/.jpg) e, se tiver a
 * #    posição do botão em cada um, um gt.csv ao lado:  arquivo,cx,cy,r   (pixels DA IMAGEM)
 * ./gradlew :core:rodFrameLab -Pframes=/caminho/dos/frames -Pout=/caminho/saida
 *
 * # 2) extraia o template do botão de uma imagem real (centro e raio em pixels da imagem)
 * ./gradlew :core:rodFrameLab -Pcmd=template \
 *     -Pimage=/caminho/frame.png -Pcx=520 -Pcy=199 -Pr=34 -Pout=/caminho/rod_template_v9.json
 * ```
 *
 * Também roda direto na JVM (sem Gradle):
 * ```
 * java -cp core/build/libs/core.jar:kotlin-stdlib.jar com.fischa.core.tools.RodFrameLab run <framesDir> [outDir]
 * ```
 *
 * **Nada aqui executa input**: o laboratório só lê imagens e escreve arquivos de diagnóstico.
 */
object RodFrameLab {

    private const val PROC_W_DEFAULT = 640
    private val IMAGE_EXT = Regex(".*\\.(png|jpg|jpeg|bmp|webp)$", RegexOption.IGNORE_CASE)

    @JvmStatic
    fun main(args: Array<String>) {
        val cmd = args.getOrNull(0) ?: "help"
        when (cmd.lowercase()) {
            "run" -> run(args.getOrNull(1))
            "check" -> run(args.getOrNull(1), writeImages = false)
            "template" -> template(args)
            else -> usage()
        }
    }

    private fun usage() {
        println(
            """
            RodFrameLab — teste do detector V9 com frames REAIS (spec V9 §12)

              run      <framesDir> [outDir]   roda a V9 sobre os frames e escreve CSV + PNGs anotados
              check    <framesDir>            só o resumo (não escreve imagens)
              template <img> <cx> <cy> <r> [out.json]
                                              extrai o template visual do botão da imagem real

            Em <framesDir> você pode colocar opcionalmente:
              gt.csv    linhas "arquivo,cx,cy,r" (pixels DA IMAGEM) = posição verdadeira do botão
              meta.txt  "fps=30" e "processingWidth=640" (defaults)
              rod_template_v9.json   template já extraído (opcional)
            """.trimIndent(),
        )
    }

    private fun fail(msg: String): Nothing {
        System.err.println("RodFrameLab: $msg")
        exitProcess(2)
    }

    /** roda o detector V9 sobre todos os frames de [framesDir] */
    fun run(framesDirPath: String?, writeImages: Boolean = true, outDirPath: String? = null): Boolean {
        val dir = File(framesDirPath ?: error("informe a pasta de frames (run <framesDir>)"))
        require(dir.isDirectory) { "não é uma pasta: ${dir.absolutePath}" }
        val images = dir.listFiles { f: File -> f.isFile && IMAGE_EXT.matches(f.name) }
            ?.sortedBy { it.name } ?: emptyList()
        require(images.isNotEmpty()) { "nenhuma imagem .png/.jpg em ${dir.absolutePath}" }

        val out = File(outDirPath ?: File(dir, "rod_lab_out").path).apply { mkdirs() }
        val gt = readGt(File(dir, "gt.csv"))
        val meta = readMeta(File(dir, "meta.txt"))
        val templateFile = File(dir, "rod_template_v9.json")

        val cfg = AppConfig().copy(rodDetector = RodDetectorKind.V9).validate()
        val lines = ArrayList<String>()
        val log = ThrottledLog(LogSink { level, tag, msg, _ -> lines.add("[$tag] $msg") })
        val det = RodDetectionV9(cfg, log)
        if (templateFile.isFile) {
            val ok = det.detector.loadTemplate(templateFile.readText())
            println("template ${templateFile.name}: ${if (ok) "carregado" else "inválido (ignorado)"}")
        }

        println("RodFrameLab: ${images.size} frames de ${dir.absolutePath}")
        println("config: ${det.configSummary()}")

        val csv = File(out, "rod_v9_lab.csv").bufferedWriter()
        csv.write("frame,file,state,detector_state,target_found,target_x,target_y,confidence,score,candidates,gt_x,gt_y,error_px\n")
        var confirmed = 0
        var hits = 0
        var misses = 0
        var falsePositives = 0
        var annotated = 0
        var errSum = 0f
        var errMax = 0f
        val periodNs = (1_000_000_000.0 / meta.first).toLong().coerceAtLeast(1L)

        for ((i, file) in images.withIndex()) {
            val img = ImageIO.read(file) ?: continue
            val frame = toVisionFrame(img, meta.second)
            frame.resetFor(i * periodNs, i.toLong())
            frame.ensureGray()
            log.setNow(i * periodNs)
            val snap: RodV9Result = copy(det.update(frame, meta.first, i * periodNs))

            val truth = gt[file.name]
            val hasTruth = truth != null && truth.present
            var errPx = -1f
            if (truth != null) {
                if (truth.present && snap.targetFound) {
                    val gx = truth.x ?: 0f
                    val gy = truth.y ?: 0f
                    val px = snap.targetX * frame.width
                    val py = snap.targetY * frame.height
                    // a verdade é dada em pixels DA IMAGEM: converte para o espaço de processamento
                    val sx = frame.width.toFloat() / img.width
                    errPx = hypot(px - gx * sx, py - gy * sx)
                    if (errPx <= (truth.radius?.times(sx) ?: 12f) * 1.6f) hits++ else misses++
                    errSum += errPx
                    errMax = maxOf(errMax, errPx)
                } else if (truth.present && !snap.targetFound) {
                    misses++
                } else if (!truth.present && snap.targetFound) {
                    falsePositives++
                }
            }
            if (snap.targetFound) confirmed++

            val px = if (snap.targetFound) snap.targetX * frame.width else Float.NaN
            val py = if (snap.targetFound) snap.targetY * frame.height else Float.NaN
            csv.write(
                "$i,${file.name},${snap.state},${snap.detectorState},${snap.targetFound}," +
                    "${fmt(px)},${fmt(py)},${fmt(snap.confidence)},${fmt(snap.score)},${snap.candidates}," +
                    "${truth?.x?.let { fmt(it) } ?: ""},${truth?.y?.let { fmt(it) } ?: ""}," +
                    "${if (errPx >= 0f) fmt(errPx) else ""}\n",
            )

            if (writeImages && (i % WRITE_EVERY == 0 || hasTruth != snap.targetFound)) {
                val anno = annotate(img, det, snap, frame)
                ImageIO.write(anno, "png", File(out, "anno_%04d.png".format(i)))
                annotated++
            }
        }
        csv.close()

        val present = gt.count { it.value.present }
        println("---- resumo (Rod Detection V9, frames reais) ----")
        println("frames processados=${images.size} com alvo confirmado=$confirmed")
        println("anotação fornecida: $present frames | acertos=$hits erros=$misses falsos positivos=$falsePositives")
        if (hits > 0 || misses > 0) {
            val n = hits + misses
            println("erro do centro: médio=${"%.1f".format(errSum / maxOf(1, n))}px máx=${"%.1f".format(errMax)}px " +
                "(espaço de processamento ${meta.second}px de largura)")
            println("taxa de acerto=${"%.0f".format(100f * hits / maxOf(1, n))}%")
        }
        println("saída: ${out.absolutePath} (rod_v9_lab.csv${if (annotated > 0) " + $annotated PNGs anotados" else ""})")
        if (lines.isNotEmpty()) {
            println("log (últimas linhas):")
            lines.takeLast(8).forEach { println("  $it") }
        }

        val ok = when {
            present == 0 -> confirmed >= 0   // sem anotação: só relatório (não é PASS/FAIL)
            else -> falsePositives == 0 && hits >= (present * 0.8f).toInt()
        }
        println(
            when {
                present == 0 -> "SEM ANOTAÇÃO (gt.csv) — relatório apenas; para PASS/FAIL anote a posição do botão"
                ok -> "ROD V9 LAB PASS"
                else -> "ROD V9 LAB FAIL (erros=$misses falsosPositivos=$falsePositives)"
            },
        )
        if (present > 0 && !ok) exitProcess(1)
        return ok
    }

    /** extrai o template visual do botão a partir de uma imagem real */
    private fun template(args: Array<String>) {
        val imgPath = args.getOrNull(1) ?: error("template <img> <cx> <cy> <r> [out.json]")
        val cx = args.getOrNull(2)?.toIntOrNull() ?: error("cx (pixels da imagem)")
        val cy = args.getOrNull(3)?.toIntOrNull() ?: error("cy (pixels da imagem)")
        val r = args.getOrNull(4)?.toFloatOrNull() ?: error("r (raio em pixels da imagem)")
        val outPath = args.getOrNull(5) ?: "rod_template_v9.json"
        val img = ImageIO.read(File(imgPath)) ?: error("não consegui ler $imgPath")
        val frame = toVisionFrame(img, PROC_W_DEFAULT)
        frame.ensureGray()
        // converte o centro anotado (pixels da imagem) para o espaço de processamento
        val sf = frame.width.toFloat() / img.width
        val t = RodTemplateV9.extract(frame, (cx * sf).toInt(), (cy * sf).toInt(), r * sf)
        File(outPath).writeText(t.toJson())
        println("template extraído (${t.w}x${t.h}) de $imgPath → $outPath")
        println("no aparelho, coloque este arquivo em: /sdcard/Android/data/com.fischa.app/files/rod_template_v9.json")
    }

    // ---------------------------------------------------------------------------------------

    private data class Truth(val x: Float?, val y: Float?, val radius: Float?, val present: Boolean)

    private fun readGt(file: File): Map<String, Truth> {
        if (!file.isFile) return emptyMap()
        val m = HashMap<String, Truth>()
        file.forEachLine { raw ->
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) return@forEachLine
            val p = line.split(',')
            if (p.size >= 3) {
                val name = p[0].trim()
                // "arquivo,-1,-1" (ou vazio) marca explicitamente "não há botão neste frame"
                val x = p[1].trim().toFloatOrNull()
                val y = p[2].trim().toFloatOrNull()
                val r = p.getOrNull(3)?.trim()?.toFloatOrNull()
                m[name] = Truth(x, y, r, present = x != null && y != null && x >= 0f && y >= 0f)
            }
        }
        return m
    }

    private fun readMeta(file: File): Pair<Float, Int> {
        var fps = 30f
        var width = PROC_W_DEFAULT
        if (file.isFile) {
            file.forEachLine {
                if (it.startsWith("fps=")) fps = it.substringAfter('=').trim().toFloatOrNull() ?: fps
                if (it.startsWith("processingWidth=")) {
                    width = it.substringAfter('=').trim().toIntOrNull() ?: width
                }
            }
        }
        return fps to width
    }

    /** imagem real → frame de processamento na largura pedida (mantendo a proporção) */
    fun toVisionFrame(img: BufferedImage, procWidth: Int): VisionFrame {
        val w = procWidth.coerceIn(160, 1920)
        val h = (img.height.toFloat() * w / img.width).toInt().coerceAtLeast(16)
        val frame = VisionFrame(w, h, IntArray(w * h), ByteArray(w * h))
        val sf = w.toFloat() / img.width
        for (y in 0 until h) {
            val sy = (y / sf).toInt().coerceAtMost(img.height - 1)
            var i = y * w
            for (x in 0 until w) {
                val sx = (x / sf).toInt().coerceAtMost(img.width - 1)
                frame.argb[i++] = img.getRGB(sx, sy)
            }
        }
        return frame
    }

    /** cópia do resultado (o detector reutiliza o snapshot) */
    private fun copy(r: RodV9Result): RodV9Result = RodV9Result().also { it.copyFrom(r) }

    /** desenha o que o detector viu: ROI, candidatos, escolhido, alvo e (se houver) a verdade */
    private fun annotate(
        img: BufferedImage,
        det: RodDetectionV9,
        snap: RodV9Result,
        frame: VisionFrame,
    ): BufferedImage {
        val out = BufferedImage(img.width, img.height, BufferedImage.TYPE_INT_RGB)
        val g: Graphics2D = out.createGraphics()
        g.drawImage(img, 0, 0, null)
        g.font = Font("Monospaced", Font.BOLD, 16)
        val kx = img.width.toFloat() / frame.width
        val ky = img.height.toFloat() / frame.height

        // ROI (janela móvel) — azul
        g.color = Color(0x00, 0x88, 0xFF)
        val roi: NormRegion = snap.roi
        g.drawRect(
            (roi.left * frame.width * kx).toInt(), (roi.top * frame.height * ky).toInt(),
            (roi.width * frame.width * kx).toInt(), (roi.height * frame.height * ky).toInt(),
        )
        // candidatos — laranja (caixa + centro)
        for (c in snap.candidateData) {
            val cx = c.cx * kx
            val cy = c.cy * ky
            val r = c.r * kx
            g.color = Color(0xFF, 0x98, 0x00)
            g.drawRect((cx - r).toInt(), (cy - r).toInt(), (2 * r).toInt(), (2 * r).toInt())
            g.drawLine((cx - 6).toInt(), cy.toInt(), (cx + 6).toInt(), cy.toInt())
            g.drawLine(cx.toInt(), (cy - 6).toInt(), cx.toInt(), (cy + 6).toInt())
            g.drawString("%.2f".format(c.score), (cx + r + 2).toInt(), cy.toInt())
        }
        // alvo confirmado — verde; sem alvo, o texto diz o estado (nada é desenhado "por suposição")
        if (snap.targetFound) {
            g.color = Color(0x00, 0xE6, 0x76)
            val cx = snap.centerPx.x * kx
            val cy = snap.centerPx.y * ky
            val r = (snap.radiusPx * kx).toInt().coerceAtLeast(6)
            g.drawOval((cx - r).toInt(), (cy - r).toInt(), 2 * r, 2 * r)
            g.drawLine((cx - 18).toInt(), cy.toInt(), (cx + 18).toInt(), cy.toInt())
            g.drawLine(cx.toInt(), (cy - 18).toInt(), cx.toInt(), (cy + 18).toInt())
            g.drawString("ALVO V9", (cx + r + 2).toInt(), cy.toInt())
        }
        // lastKnownTarget — cinza
        if (snap.lastKnownX.isFinite()) {
            g.color = Color.GRAY
            val cx = snap.lastKnownX * frame.width * kx
            val cy = snap.lastKnownY * frame.height * ky
            g.drawLine((cx - 10).toInt(), cy.toInt(), (cx + 10).toInt(), cy.toInt())
            g.drawLine(cx.toInt(), (cy - 10).toInt(), cx.toInt(), (cy + 10).toInt())
            g.drawString("lastKnown", (cx + 12).toInt(), cy.toInt())
        }
        // cabeçalho
        g.color = Color(0, 0, 0)
        g.fillRect(0, 0, img.width, 54)
        g.color = Color.WHITE
        g.drawString("${snap.state}/${snap.detectorState} found=${snap.targetFound} cands=${snap.candidates}", 6, 18)
        g.drawString(
            "conf=%.2f score=%.2f roi=%s".format(snap.confidence, snap.score, snap.roiString()),
            6, 38,
        )
        g.color = Color.GRAY
        g.drawString(snap.reason.take(120), 6, img.height - 8)
        g.dispose()
        return out
    }

    private fun fmt(v: Float): String = if (v.isFinite()) "%.4f".format(v) else ""

    private const val WRITE_EVERY = 5
}
