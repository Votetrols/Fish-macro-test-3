package com.fischa.core.vision

import com.fischa.core.calib.AutoCalibrator
import com.fischa.core.calib.CalibrationConfig
import com.fischa.core.calib.RodAdaptiveModel
import com.fischa.core.common.NormRegion
import com.fischa.core.common.PointF
import com.fischa.core.common.RectF
import com.fischa.core.config.AppConfig
import com.fischa.core.log.Tags
import com.fischa.core.log.ThrottledLog
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Immutable-by-convention snapshot of the V7 rod finder for one frame (the pipeline copies what
 * it needs; the debug overlay reads the normalized variants).
 */
class RodSnapshot {
    var state: RodDetectionState = RodDetectionState.INIT
    /** V6-compatible: a candidate for the rod button is present on this frame. */
    var detected = false
    /** V6-compatible: the temporal confirmation gate has passed (ROD_CONFIRMED/TRACKING). */
    var confirmed = false
    /** temporal (EMA) confidence 0..1 */
    var confidence = 0f
    /** single-frame candidate score of the winner (0..1) */
    var score = 0f
    /** how many candidates survived the wide search this frame */
    var candidates = 0
    /** temporal validation streak (frames) and the requirement derived from the measured FPS */
    var streak = 0
    var requiredFrames = 0
    /** true while running the cheap local (ROI) search instead of the wide search */
    var tracking = false
    /** milliseconds since the last accepted detection (0 while tracking) */
    var lostMs = 0L
    /** distance the button moved since the previous frame (normalized) */
    var movedNorm = 0f
    /** last reason a confirmation was not reached (human readable, goes to the log/overlay) */
    var reason = ""
    /** where the search is looking right now (normalized) — the *wide* region while searching */
    val searchRegion: NormRegion get() = search
    /** the dynamic ROI built around the detected button (normalized); UNIT when not tracking */
    val roi: NormRegion get() = roiRegion
    /** detected button bounds in processing pixels (the debug box follows this) */
    val box = RectF()
    /** centre of the detected candidate in **processing pixels** (V6-compatible `DetSnapshot.box`) */
    val center = PointF()
    /** the same centre **normalized** — this is what the debug overlay draws the cross from */
    val centerNorm = PointF()
    /** size of the frame this snapshot was produced from (needed to normalize) */
    var frameW = 1
    var frameH = 1
    var radius = 0f
    /** full calibration in force this frame (never null after INIT) */
    var calibration: CalibrationConfig? = null
    var calibrationDone = false
    var searchActive = false
    var candidatesDetail = ""

    internal var search: NormRegion = NormRegion.UNIT
    internal var roiRegion: NormRegion = NormRegion.UNIT

    fun copyFrom(o: RodSnapshot) {
        state = o.state
        detected = o.detected; confirmed = o.confirmed; confidence = o.confidence; score = o.score
        candidates = o.candidates; streak = o.streak; requiredFrames = o.requiredFrames
        tracking = o.tracking; lostMs = o.lostMs; movedNorm = o.movedNorm; reason = o.reason
        search = o.search; roiRegion = o.roiRegion
        box.set(o.box); center.x = o.center.x; center.y = o.center.y
        centerNorm.x = o.centerNorm.x; centerNorm.y = o.centerNorm.y
        frameW = o.frameW; frameH = o.frameH
        radius = o.radius; calibration = o.calibration; calibrationDone = o.calibrationDone
        searchActive = o.searchActive; candidatesDetail = o.candidatesDetail
    }

    fun centerString(): String = "(${center.x.toInt()},${center.y.toInt()})"

    /** Sets the pixel centre and derives the normalized one (single source of truth). */
    internal fun setCenter(cx: Float, cy: Float) {
        center.x = cx; center.y = cy
        centerNorm.x = cx / frameW.toFloat(); centerNorm.y = cy / frameH.toFloat()
    }

    fun roiString(frameW: Int, frameH: Int): String {
        val r = roiRegion
        return "(${(r.left * frameW).toInt()},${(r.top * frameH).toInt()}," +
            "${(r.width * frameW).toInt()},${(r.height * frameH).toInt()})"
    }
}

/**
 * V7 §2…§4, §6, §8, §11 — the rod-button finder.
 *
 * Replaces the V6 fixed-ROI detector. Nothing about the button's position, size, threshold or
 * frame count is hardcoded: the finder
 *  1. runs **AUTO_CALIBRATION** ([AutoCalibrator]) to measure the screen, FPS, noise floor, size
 *     band and a proportional search region;
 *  2. performs a **wide search** over that region (coarse-to-fine, proportional to the frame);
 *  3. turns the cheap coarse hits into **candidates** with full-resolution features (shape, size,
 *     contrast, position, temporal persistence, glyph-vs-text identity);
 *  4. **scores** them (`candidateScore`, configurable + auto-adjusted weights) and picks the best;
 *  5. requires **temporal confirmation** over an FPS-adaptive number of consecutive frames before
 *     declaring `ROD_CONFIRMED`;
 *  6. builds the **dynamic ROI** around the detected button (padding proportional to its size);
 *  7. **tracks** it locally every frame afterwards (no wide search), re-building the ROI when the
 *     button moves, and recovers through LOCAL_RETRY → SEARCHING_ROD when it disappears.
 *
 * The finder never touches input. It only answers "can I see the rod button, where, and how sure
 * am I?".
 */
class RodFinder(
    private val cfg: AppConfig,
    private val log: ThrottledLog,
) {
    private val v7: AppConfig.RodV7 = cfg.rodV7

    /**
     * The *visual mechanism* (coarse dark-disc pass → blob/ring measurement → scored candidate),
     * extracted so that the V8 moving-window policy reuses exactly the same, already validated
     * detection inside its window instead of growing a second, unproven one. The V7 policy only
     * adds the auto-calibrated wide search and the adaptive confirmation on top of it.
     */
    private val win = RodWindowDetector(v7)
    private val scorer get() = win.scorer
    val adaptive = RodAdaptiveModel(v7)
    private val calibrator = AutoCalibrator(v7)

    /** candidate history (normalized centers) for the temporal feature */
    private val history = CandidateHistory(HISTORY)

    private var calib: CalibrationConfig = CalibrationConfig.provisional(
        cfg.capture.processingWidth, (cfg.capture.processingWidth * 0.45f).toInt(),
    )

    private val candidateScratch = ArrayList<RodCandidate>(16)

    // tracking / confirmation state
    private var streak = 0
    private var streakStartNs = 0L
    private var anchorX = 0f
    private var anchorY = 0f
    private var lastHitNs = 0L
    private var lostSinceNs = 0L
    private var missingFrames = 0
    private var lastConfidenceNs = 0L
    private var lastFalsePositiveNs = 0L
    private var recalibratedAtNs = 0L
    private var firstFrameNs = 0L
    private var lastFps = 30f
    private var lastLogState: RodDetectionState? = null

    private var freshRequired = false
    private var freshStreak = 0

    private var trackX = 0f
    private var trackY = 0f
    private var trackR = 0f
    private var movedNorm = 0f
    /** when the current wide-search cycle started (0 = not searching) — drives the widening */
    private var wideSinceNs = 0L
    private var expansionLogged = false

    private val snapshot = RodSnapshot()
    private val best = RodCandidate()
    private val tracked = RodCandidate()
    private var haveTrack = false

    val calibration: CalibrationConfig get() = calib
    val state: RodDetectionState get() = snapshot.state
    val out: RodSnapshot get() = snapshot
    val calibrationSamples: Int get() = calibrator.samples

    /** V7 §1: feed the platform's screen facts once (they cannot be measured from the frame). */
    fun setScreenInfo(
        screenWidthPx: Int,
        screenHeightPx: Int,
        densityDpi: Int,
        rotationDeg: Int,
        appWindowWidthPx: Int,
        appWindowHeightPx: Int,
        statusBarPx: Int,
        navBarPx: Int,
    ) {
        calibrator.setScreenInfo(
            screenWidthPx, screenHeightPx, densityDpi, rotationDeg,
            appWindowWidthPx, appWindowHeightPx, statusBarPx, navBarPx,
        )
    }

    /**
     * V5/V6 semantics preserved: a new fishing cycle may only start from a **fresh** visual
     * confirmation. The ROI/tracking survive (we do not throw away a good lock), but `confirmed`
     * stays false until a new confirmation streak of the required length completes.
     */
    fun requireFreshConfirmation(reason: String) {
        freshRequired = true
        freshStreak = 0
        streak = 0
        snapshot.confirmed = false
        snapshot.reason = "fresh confirmation required ($reason)"
    }

    /** V7 §7: a confirmed detection that later proved wrong feeds the adaptive model. */
    fun noteFalsePositive(nowNs: Long, reason: String) {
        if (nowNs - lastFalsePositiveNs < v7.adaptCooldownMs * 1_000_000L) return
        lastFalsePositiveNs = nowNs
        if (v7.adaptiveTuning) {
            adaptive.onFalsePositive(nowNs)
            scorer.tune(confirmed = false, step = 0.015f)
        }
        log.w(
            Tags.ROD_SEARCH, "fp", "[ROD_SEARCH] false-positive pattern rejected ($reason); " +
                "raising the bar → thr=${"%.3f".format(calib.confidenceThreshold)} " +
                "frames=${calib.temporalConfirmationFrames} $scorer",
        )
    }

    /** Full reset, e.g. when the capture session restarts. */
    fun reset(nowNs: Long, reason: String) {
        streak = 0; streakStartNs = 0L; lastHitNs = 0L; lostSinceNs = 0L; missingFrames = 0
        wideSinceNs = 0L; expansionLogged = false
        history.reset()
        haveTrack = false
        freshRequired = false
        freshStreak = 0
        snapshot.state = RodDetectionState.INIT
        snapshot.detected = false; snapshot.confirmed = false; snapshot.confidence = 0f
        snapshot.tracking = false; snapshot.searchActive = false
        calibrator.reset()
        firstFrameNs = 0L
        log.i(Tags.ROD_FINDER, "reset", "[ROD_FINDER] reset ($reason)")
    }

    /**
     * One frame. Returns the shared [RodSnapshot] (read before the next call).
     *
     * @param fps measured pipeline FPS (never assumed); used for the adaptive confirmation count
     * @param nowNs frame timestamp on the same monotonic clock as the pipeline
     */
    fun update(frame: VisionFrame, fps: Float, nowNs: Long): RodSnapshot {
        if (fps.isFinite() && fps > 0.5f) lastFps = fps
        if (firstFrameNs == 0L) firstFrameNs = nowNs
        val w = frame.width
        val h = frame.height
        snapshot.frameW = w
        snapshot.frameH = h
        if (calibrator.needsScreenInfo) {
            // Without platform screen facts the calibration still works: the frame *is* the screen.
            calibrator.setScreenInfo(w, h, 0, 0, w, h, 0, 0)
        }

        // ---- V7 §1: AUTO_CALIBRATION -------------------------------------------------------
        if (!calibrator.done) {
            scan(frame, calibProvisionalRegion(w, h), wide = true)
            val finished = calibrator.observe(frame, win.scanner, win.hits, v7.wideSearchStepPx, fps, nowNs)
            snapshot.state = RodDetectionState.AUTO_CALIBRATION
            snapshot.calibrationDone = false
            snapshot.search = calib.rodSearchRegion
            snapshot.detected = false; snapshot.confirmed = false; snapshot.confidence = 0f
            snapshot.tracking = false; snapshot.searchActive = true
            snapshot.calibration = calib
            snapshot.reason = "auto-calibration ${calibrator.samples}/${v7.calibrationFrames}"
            if (finished != null) {
                calib = finished
                scorer.setFromCalibration(v7.weights)
                logCalibration(finished)
                snapshot.state = RodDetectionState.SEARCHING_ROD
                snapshot.calibrationDone = true
                log.i(Tags.ROD_SEARCH, "begin", "[ROD_SEARCH] wide search armed search=${calib.rodSearchRegion.describe()}")
            }
            return snapshot
        }

        // ---- low-frequency re-calibration (never a hard re-acquire) -------------------------
        if (nowNs - recalibratedAtNs > v7.recalibrationIntervalMs * 1_000_000L) {
            recalibratedAtNs = nowNs
            val updated = calib.withFps(lastFps)
            if (updated != calib) {
                calib = updated
                log.i(Tags.CALIBRATION, "recal", "[CALIBRATION] recalibrado (fps=${"%.1f".format(lastFps)}) → ${calib.describe()}")
            }
        }

        // ---- V7 §4: wide search vs. confirmation verification vs. local tracking -----------
        when (snapshot.state) {
            RodDetectionState.INIT,
            RodDetectionState.SEARCHING_ROD -> {
                // Wide, screen-proportional search (the only place the whole region is scanned).
                // V7 §11: start from the calibrated *estimate* (cheap) and, if it keeps failing,
                // widen it to the proportional fallback band — a bad estimate can never trap the
                // search, and a good one is never paid for twice.
                if (wideSinceNs == 0L) wideSinceNs = nowNs
                var region = calib.rodSearchRegion
                val searchingMs = (nowNs - wideSinceNs) / 1_000_000L
                if (searchingMs >= v7.wideExpandAfterMs) {
                    val widened = region.union(CalibrationConfig.WIDE_FALLBACK).clamp()
                    if (widened.width * widened.height > region.width * region.height + 1e-4f) {
                        if (!expansionLogged) {
                            expansionLogged = true
                            log.i(
                                Tags.ROD_SEARCH, "expand",
                                "[ROD_SEARCH] estimativa sem candidato por ${searchingMs}ms → região " +
                                    "ampliada ${region.describe()} → ${widened.describe()} (fallback proporcional)",
                            )
                        }
                        region = widened
                    }
                }
                snapshot.search = region
                scan(frame, region.toPx(w, h), wide = true)
                val winners = refineAndScore(frame, nowNs, wide = true)
                snapshot.candidates = winners
                if (winners == 0) onMiss(nowNs, w, "no valid candidate")
                else onCandidate(frame, nowNs, w, h, directAcquire = true)
            }
            RodDetectionState.CANDIDATE_FOUND,
            RodDetectionState.CONFIRMING_ROD -> {
                endWideSearch()
                snapshot.search = calib.rodSearchRegion
                // verification: only the neighbourhood of the streak anchor — cheaper than the
                // wide pass and impossible to hijack by a different blob elsewhere on screen
                scan(frame, verificationRegionPx(w, h), wide = false)
                val winners = refineAndScore(frame, nowNs, wide = false)
                snapshot.candidates = winners
                if (winners == 0) onConfirmLost(nowNs, w, "candidate lost during confirmation")
                else if (best.score < VIABILITY_FLOOR) onConfirmLost(nowNs, w, "candidate fell below the viability floor")
                else onCandidate(frame, nowNs, w, h, directAcquire = false)
            }
            else -> {
                endWideSearch()
                snapshot.search = calib.rodSearchRegion
                // local tracking inside the dynamic ROI (plus a proportional margin)
                scan(frame, localRegionPx(w, h), wide = false)
                val winners = refineAndScore(frame, nowNs, wide = false)
                snapshot.candidates = winners
                val roiRegion = snapshot.roiRegion
                if (winners == 0) {
                    onMiss(
                        nowNs, w,
                        if (snapshot.state == RodDetectionState.LOCAL_RETRY) "local retry failed"
                        else "button not found in ROI",
                    )
                } else {
                    onTrack(frame, nowNs, w, h, roiRegion)
                }
            }
        }

        snapshot.calibration = calib
        if (snapshot.state != lastLogState) {
            lastLogState = snapshot.state
            log.i(Tags.ROD_FINDER, "state", "[STATE] ${snapshot.state.name}")
        }
        return snapshot
    }

    // ---------------------------------------------------------------------------------------
    /** V7 §1: calibration samples the estimate **plus** the proportional fallback band. */
    private fun calibProvisionalRegion(w: Int, h: Int): IntArray = calib.calibrationScanRectPx(w, h)

    /** leaves the wide-search cycle (candidate found / tracking): the next one starts fresh */
    private fun endWideSearch() {
        wideSinceNs = 0L
        expansionLogged = false
    }

    /**
     * V7 §2 FASE A — coarse scan of the requested region (the wide search or the local ROI),
     * delegated to the shared visual mechanism ([RodWindowDetector]).
     */
    private fun scan(frame: VisionFrame, regionPx: IntArray, wide: Boolean) {
        win.scan(
            frame, regionPx, calib,
            step = if (wide) v7.wideSearchStepPx else v7.localSearchStepPx,
            limit = if (wide) 14 else 6,
            centerStride = if (wide) v7.wideCenterStride else v7.localCenterStride,
        )
    }

    /**
     * V7 §2 FASE B/C — turns the coarse hits of the last [scan] into fully measured, scored
     * candidates and picks the winner (clusters merged), all inside [RodWindowDetector]. What
     * stays here is only the policy: how many hits are refined, and which candidate the V7
     * confirmation gate then considers.
     *
     * @return number of candidates that survived (0 → nothing to confirm).
     */
    private fun refineAndScore(frame: VisionFrame, nowNs: Long, wide: Boolean): Int {
        val n = win.refine(
            frame,
            step = if (wide) v7.wideSearchStepPx else v7.localSearchStepPx,
            calib = calib,
            persistence = ::persistenceAt,
            maxRefine = v7.maxRefinedCandidates,
            out = candidateScratch,
        )
        if (n == 0) {
            snapshot.candidatesDetail = ""
            return 0
        }
        best.copyFrom(win.best)
        snapshot.candidatesDetail = win.detail
        return n
    }

    /**
     * Effective confidence floor for *confirmation* this frame: the calibrated threshold, never
     * below the legacy V6 floor (`rod.confidenceThreshold`, kept as a lower bound for
     * compatibility), plus whatever the adaptive model learned from false positives.
     */
    private fun effectiveThreshold(): Float =
        max(max(calib.confidenceThreshold, cfg.rod.confidenceThreshold), 0.35f) + adaptive.thresholdBump()

    /** wide-search result → candidate / confirmation entry point */
    private fun onCandidate(frame: VisionFrame, nowNs: Long, w: Int, h: Int, directAcquire: Boolean) {
        snapshot.candidates = max(1, snapshot.candidates)
        val thr = effectiveThreshold()
        snapshot.score = best.score
        log.i(Tags.ROD_SEARCH, "search", "[ROD_SEARCH] candidates=${snapshot.candidates} bestScore=${"%.2f".format(best.score)}")

        // A candidate that cannot even reach the viability floor is not evidence of anything.
        if (best.score < VIABILITY_FLOOR) {
            streak = 0
            snapshot.detected = false
            snapshot.confirmed = false
            snapshot.confidence = 0f
            snapshot.state = RodDetectionState.SEARCHING_ROD
            snapshot.searchActive = true
            snapshot.tracking = false
            snapshot.reason = "candidate below viability floor"
            log.i(
                Tags.ROD_SEARCH, "none",
                "[ROD_SEARCH] no valid candidate (bestScore=${"%.2f".format(best.score)} < floor=${"%.2f".format(VIABILITY_FLOOR)}) " +
                    "→ ${snapshot.candidatesDetail}",
            )
            return
        }

        // candidate accepted for temporal confirmation
        val tx = best.cx / w
        val ty = best.cy / h
        val tol = driftTolerance(best.radiusNorm)
        val withinStreak = streak > 0 && nowNs - streakStartNs <= v7.confirmWindowMs * 1_000_000L &&
            abs(tx - anchorX) + abs(ty - anchorY) <= tol
        if (streak == 0 || !withinStreak) {
            if (streak > 0) {
                // the winner jumped: a different blob, or the button moved too far to keep the
                // streak — restart the confirmation anchored at the new position (never confirm
                // across a jump).
                log.i(
                    Tags.ROD_CONFIRM, "unstable",
                    "[ROD_CONFIRM] center unstable drift=${"%.3f".format(abs(tx - anchorX) + abs(ty - anchorY))} " +
                        "> tol=${"%.3f".format(tol)} → streak reiniciado",
                )
            }
            anchorX = tx; anchorY = ty; streakStartNs = nowNs
            trackR = best.r
            streak = 1
        } else {
            streak++
        }
        snapshot.streak = streak
        snapshot.detected = true
        snapshot.score = best.score
        snapshot.box.set(best.box)
        snapshot.setCenter(best.cx, best.cy)
        snapshot.radius = best.r
        // the temporal feature of candidateScore is fed here: a candidate only keeps its
        // persistence (and therefore wins ties) while it keeps being seen near the same spot
        rememberCandidate(best.cx / w, best.cy / h)
        val requirement = requirementFrames()
        snapshot.requiredFrames = requirement
        // confidence grows with the streak (temporal evidence), bounded by the frame score
        val temporalGain = min(1f, streak.toFloat() / requirement)
        val conf = (best.score * (0.72f + 0.28f * temporalGain)).coerceIn(0f, 1f).toFloat()
        snapshot.confidence = conf
        snapshot.tracking = false
        snapshot.searchActive = true
        snapshot.lostMs = 0L

        if (conf < thr) {
            // visible, but not trustworthy yet: publish the candidate, refuse to confirm
            snapshot.state = RodDetectionState.CONFIRMING_ROD
            snapshot.confirmed = false
            snapshot.reason = "confidence too low (${"%.2f".format(conf)} < ${"%.2f".format(thr)})"
            log.i(
                Tags.ROD_CONFIRM, "lowconf",
                "[ROD_CONFIRM] confidence too low confidence=${"%.2f".format(conf)} threshold=${"%.2f".format(thr)} " +
                    "score=${"%.2f".format(best.score)} streak=$streak/$requirement",
            )
            log.i(Tags.STATE, "searching", "[STATE] SEARCHING_ROD (confiança insuficiente, candidato mantido em observação)")
            return
        }
        if (streak >= requirement) {
            snapshot.state = RodDetectionState.ROD_CONFIRMED
            snapshot.confirmed = true
            enterTracking(best, nowNs, w, h)
            log.i(Tags.ROD, "confirmed", "[ROD] CONFIRMED")
            log.i(Tags.ROD, "center", "[ROD] center=${snapshot.centerString()} r=${"%.1f".format(best.r)} score=${"%.2f".format(best.score)}")
            log.i(Tags.ROD, "roi", "[ROD] roi=${snapshot.roiString(w, h)} (norm=${snapshot.roiRegion.describe()})")
            log.i(Tags.TRACKING, "active", "[TRACKING] ACTIVE (local search, ROI dinâmica)")
            if (v7.adaptiveTuning) {
                adaptive.onConfirmed(best.radiusNorm, best.cx / w, best.cy / h, nowNs)
                scorer.tune(confirmed = true, step = 0.01f)
            }
            if (requirement > 1) log.i(Tags.ROD_CONFIRM, "done", "[ROD_CONFIRM] frame=$streak/$requirement → confidence=${"%.2f".format(conf)}")
        } else {
            snapshot.state = if (directAcquire && streak == 1) RodDetectionState.CANDIDATE_FOUND else RodDetectionState.CONFIRMING_ROD
            snapshot.confirmed = false
            snapshot.reason = "confirming $streak/$requirement"
            log.i(
                Tags.ROD_CONFIRM, "f$streak",
                "[ROD_CONFIRM] frame=$streak/$requirement confidence=${"%.2f".format(conf)} thr=${"%.2f".format(thr)} " +
                    "center=${snapshot.centerString()} score=${"%.2f".format(best.score)}",
            )
        }
    }

    /** the candidate vanished (or degraded) while the confirmation streak was running */
    private fun onConfirmLost(nowNs: Long, w: Int, reason: String) {
        streak = 0
        snapshot.streak = 0
        snapshot.confirmed = false
        snapshot.detected = false
        snapshot.confidence = snapshot.confidence * 0.6f
        snapshot.state = RodDetectionState.SEARCHING_ROD
        snapshot.searchActive = true
        snapshot.tracking = false
        snapshot.reason = reason
        log.i(Tags.ROD_CONFIRM, "lost", "[ROD_CONFIRM] $reason → streak zerado")
        log.i(Tags.STATE, "searching", "[STATE] SEARCHING_ROD")
    }

    /** local (ROI) hit while TRACKING_ROD / LOCAL_RETRY / ROD_LOST */
    private fun onTrack(frame: VisionFrame, nowNs: Long, w: Int, h: Int, roiRegion: NormRegion) {
        val nx = best.cx / w
        val ny = best.cy / h
        val dx = nx - snapshot.center.x
        val dy = ny - snapshot.center.y
        val moved = if (snapshot.center.x == 0f && snapshot.center.y == 0f) 0f else abs(dx) + abs(dy)
        movedNorm = moved
        snapshot.movedNorm = moved
        snapshot.box.set(best.box)
        snapshot.setCenter(best.cx, best.cy)
        snapshot.radius = best.r
        rememberCandidate(best.cx / w, best.cy / h)
        // temporal confidence: EMA, refreshed on every accepted local hit
        val gain = if (lastConfidenceNs == 0L) 1f else 0.35f
        snapshot.confidence = if (snapshot.confidence == 0f) best.score
        else snapshot.confidence * (1f - gain) + best.score * gain
        snapshot.detected = true
        snapshot.confirmed = true
        val wasRetry = snapshot.state == RodDetectionState.ROD_LOST || snapshot.state == RodDetectionState.LOCAL_RETRY
        snapshot.state = RodDetectionState.TRACKING_ROD
        snapshot.tracking = true
        snapshot.searchActive = false
        snapshot.lostMs = 0L
        missingFrames = 0
        lostSinceNs = 0L
        lastHitNs = nowNs
        lastConfidenceNs = nowNs
        streak = max(streak, requirementFrames())

        // A brand-new cycle (entered WAITING_FOR_ROD / CASTING) needs a FRESH confirmation even
        // though the button is already being tracked: the lock survives, the confirmation restarts.
        if (freshRequired) {
            freshStreak++
            val need = requirementFrames()
            snapshot.requiredFrames = need
            snapshot.confirmed = freshStreak >= need && snapshot.confidence >= effectiveThreshold()
            if (snapshot.confirmed) {
                freshRequired = false
                log.i(Tags.ROD_CONFIRM, "fresh", "[ROD_CONFIRM] re-confirmação concluída ($freshStreak/$need) → ROD_CONFIRMED")
            } else {
                snapshot.reason = "re-confirmação $freshStreak/$need"
            }
        } else {
            snapshot.confirmed = snapshot.confidence >= effectiveThreshold()
        }

        // dynamic ROI (re)built around the detected button: padding ∝ button size
        val pad = calib.paddingPx(best.box.width, best.box.height)
        val nextRoi = NormRegion.fromPx(
            best.box.left - pad.first, best.box.top - pad.second,
            best.box.right + pad.first, best.box.bottom + pad.second,
            w, h,
        ).clamp()
        val changed = roiRegion.isValid && (nextRoi.left != roiRegion.left || nextRoi.top != roiRegion.top ||
            nextRoi.right != roiRegion.right || nextRoi.bottom != roiRegion.bottom)
        snapshot.roiRegion = nextRoi
        if (wasRetry) log.i(Tags.ROD_FINDER, "reacquired", "[ROD_FINDER] detecção recuperada (${snapshot.state.name}) center=${snapshot.centerString()}")
        if (changed && wasRetry.not()) {
            if (moved >= MOVE_LOG_THRESHOLD) {
                log.i(
                    Tags.TRACKING, "moved",
                    "[TRACKING] BUTTON_MOVED d=(${"%+.3f".format(dx)},${"%+.3f".format(dy)}) → ROI atualizada " +
                        "roi=${snapshot.roiString(w, h)}",
                )
            }
        }
        if (v7.adaptiveTuning) adaptive.onStable(best.radiusNorm, nx, ny, nowNs)
        snapshot.reason = "tracking"
    }

    private fun onMiss(nowNs: Long, w: Int, reason: String) {
        missingFrames++
        if (lostSinceNs == 0L) lostSinceNs = nowNs
        val missingMs = (nowNs - lostSinceNs) / 1_000_000L
        val retainedConfidence = snapshot.confidence * 0.7f
        snapshot.confidence = retainedConfidence.coerceAtLeast(0f)
        snapshot.candidates = 0
        snapshot.score = 0f
        snapshot.detected = false
        snapshot.streak = 0
        streak = 0

        when (snapshot.state) {
            RodDetectionState.TRACKING_ROD, RodDetectionState.ROD_CONFIRMED -> {
                snapshot.lostMs = missingMs
                if (missingMs <= v7.lostTimeoutMs) {
                    // short occlusion: keep the state, keep the ROI, do not confirm this frame
                    snapshot.confirmed = false
                    snapshot.reason = "transient miss (${missingMs}ms of ${v7.lostTimeoutMs}ms)"
                    log.i(
                        Tags.TRACKING, "miss",
                        "[TRACKING] miss ${missingMs}ms/${v7.lostTimeoutMs}ms (candidato ausente na ROI) — aguardando",
                    )
                } else {
                    snapshot.state = RodDetectionState.ROD_LOST
                    snapshot.confirmed = false
                    snapshot.tracking = false
                    snapshot.reason = "ROD_LOST after ${missingMs}ms"
                    log.w(Tags.TRACKING, "lost", "[TRACKING] LOST (${missingMs}ms sem detecção) → LOCAL_RETRY")
                    onEnterLost(nowNs)
                }
            }
            RodDetectionState.ROD_LOST, RodDetectionState.LOCAL_RETRY -> {
                val retryMs = (nowNs - lostSinceNs) / 1_000_000L
                snapshot.lostMs = retryMs
                if (retryMs > v7.retryTimeoutMs) {
                    snapshot.state = RodDetectionState.SEARCHING_ROD
                    snapshot.searchActive = true
                    snapshot.tracking = false
                    snapshot.reason = "local retry failed → wide search"
                    log.w(
                        Tags.ROD_SEARCH, "widesearch",
                        "[ROD_SEARCH] local retry failed after ${retryMs}ms → WIDE SEARCH (search=${calib.rodSearchRegion.describe()})",
                    )
                    if (calib.temporalConfirmationFrames < CalibrationConfig.MAX_CONFIRM_FRAMES) {
                        calib = calib.copy(
                            temporalConfirmationFrames = min(
                                CalibrationConfig.MAX_CONFIRM_FRAMES,
                                calib.temporalConfirmationFrames + 1,
                            ),
                        )
                        log.i(Tags.ROD_CONFIRM, "raise", "[ROD_CONFIRM] exigência elevada para ${calib.temporalConfirmationFrames} frames (perda de rastreio)")
                    }
                    noteFalsePositive(nowNs, "tracking lost")
                } else {
                    snapshot.state = RodDetectionState.LOCAL_RETRY
                    snapshot.reason = "local retry ${retryMs}ms/${v7.retryTimeoutMs}ms"
                }
            }
            else -> {
                snapshot.state = RodDetectionState.SEARCHING_ROD
                snapshot.confirmed = false
                snapshot.tracking = false
                snapshot.searchActive = true
                snapshot.reason = reason
                log.i(Tags.ROD_SEARCH, "none", "[ROD_SEARCH] candidates=0 $reason")
                log.i(Tags.STATE, "searching", "[STATE] SEARCHING_ROD")
            }
        }
    }

    private fun onEnterLost(nowNs: Long) {
        haveTrack = false
        lostSinceNs = nowNs
        noteFalsePositive(nowNs, "tracking lost")
    }

    private fun enterTracking(candidate: RodCandidate, nowNs: Long, w: Int, h: Int) {
        trackX = candidate.cx; trackY = candidate.cy; trackR = candidate.r
        haveTrack = true
        lastHitNs = nowNs
        lastConfidenceNs = nowNs
        missingFrames = 0
        lostSinceNs = 0L
        rememberCandidate(candidate.cx / w, candidate.cy / h)
        val pad = calib.paddingPx(candidate.box.width, candidate.box.height)
        snapshot.roiRegion = NormRegion.fromPx(
            candidate.box.left - pad.first, candidate.box.top - pad.second,
            candidate.box.right + pad.first, candidate.box.bottom + pad.second,
            w, h,
        ).clamp()
        snapshot.tracking = true
        snapshot.searchActive = false
    }

    /**
     * The window used while CONFIRMING_ROD: centred on the streak anchor, sized from the
     * button radius (proportional, never a fixed number of pixels), clamped to the game region.
     */
    private fun verificationRegionPx(w: Int, h: Int): IntArray {
        val rNorm = if (trackR > 0f) trackR / w else calib.maxCandidateSize
        val half = (rNorm * 3.0f).coerceIn(0.02f, 0.25f)
        val region = NormRegion.around(
            if (streak > 0) anchorX else snapshot.center.x / w,
            if (streak > 0) anchorY else snapshot.center.y / h,
            half * 2f, half * 2f,
        ).clamp()
        val allowed = region.intersect(calib.gameRegion) ?: region
        return allowed.toPx(w, h)
    }

    /** pixel bounds of the local search: the dynamic ROI inflated by a proportional margin */
    private fun localRegionPx(w: Int, h: Int): IntArray {
        val roi = if (snapshot.roiRegion.isValid) snapshot.roiRegion else {
            val r = if (trackR > 0f) trackR / w else 0.05f
            NormRegion.around(snapshot.center.x / w, snapshot.center.y / h, r * 3f, r * 3f)
        }
        val margin = v7.localSearchMarginFactor
        val region = roi.inflateRelative(margin * 0.5f, margin * 0.5f)
        val clamped = region.clamp()
        // never leave the useful game area
        val allowed = clamped.intersect(calib.gameRegion) ?: clamped
        return allowed.toPx(w, h)
    }

    /** frames required by the temporal gate at the measured FPS (adaptative, bounded) */
    private fun requirementFrames(): Int {
        val fromFps = CalibrationConfig.framesForConfirm(lastFps, v7.targetConfirmMs)
        val base = max(fromFps, calib.temporalConfirmationFrames)
        return adaptive.effectiveConfirmFrames(base)
    }

    private fun driftTolerance(radiusNorm: Float): Float =
        max(v7.driftToleranceMin, v7.driftToleranceFactor * radiusNorm)

    // ---- candidate persistence history (the "temporal" feature of the score) ---------------
    private fun rememberCandidate(nx: Float, ny: Float) = history.remember(nx, ny)

    private fun persistenceAt(nx: Float, ny: Float, radiusNorm: Float): Float =
        history.persistenceAt(nx, ny, radiusNorm)

    private fun logCalibration(c: CalibrationConfig) {
        log.i(Tags.CALIBRATION, "screen", "[CALIBRATION] screen=${c.screenWidth}x${c.screenHeight}")
        log.i(Tags.CALIBRATION, "scale", "[CALIBRATION] scale=${"%.2f".format(c.scale)} rot=${c.rotationDeg} dpi=${c.densityDpi}")
        log.i(Tags.CALIBRATION, "fps", "[CALIBRATION] fps=${"%.1f".format(c.estimatedFps)}")
        log.i(Tags.CALIBRATION, "region", "[CALIBRATION] gameRegion=${c.gameRegion.describe()} (área útil)")
        log.i(Tags.CALIBRATION, "search", "[CALIBRATION] rodSearchRegion=${c.rodSearchRegion.describe()} (estimativa inicial, não coordenada fixa)")
        log.i(
            Tags.CALIBRATION, "size",
            "[CALIBRATION] minCandidateSize=${"%.3f".format(c.minCandidateSize)}W maxCandidateSize=${"%.3f".format(c.maxCandidateSize)}W " +
                "(raio relativo)",
        )
        log.i(Tags.CALIBRATION, "thr", "[CALIBRATION] confidenceThreshold=${"%.2f".format(c.confidenceThreshold)} (acima do ruído da cena)")
        log.i(Tags.CALIBRATION, "confirm", "[CALIBRATION] temporalConfirmationFrames=${c.temporalConfirmationFrames} (≈${c.targetConfirmMs.toInt()}ms @ ${"%.1f".format(c.estimatedFps)}fps)")
        log.i(Tags.CALIBRATION, "roi", "[CALIBRATION] roiPadding=${"%.2f".format(c.roiPadding)} → ROI = botão × ${"%.2f".format(v7.roiScale)}")
        log.i(Tags.CALIBRATION, "noise", "[CALIBRATION] noise=${"%.1f".format(c.sceneNoise)} minRingDelta=${"%.1f".format(c.minRingDelta)} searchStep=${c.searchStepCoarse}px")
    }

    companion object {
        /** below this the frame has no usable evidence at all (pure noise) */
        private const val VIABILITY_FLOOR = 0.35f
        /** the debug box covers the button including its ring: blob radius × this factor */
        private const val RING_MAX_INCLUSION = 1.35f

        /** Two candidates closer than this × radius belong to the same physical button. */
        private const val CLUSTER_LINK = 0.6f
        private const val HISTORY = 12
        private const val MOVE_LOG_THRESHOLD = 0.004f
        /** states that scan the whole proportional search region (the expensive pass) */
        val WIDE_STATES = setOf(
            RodDetectionState.INIT,
            RodDetectionState.SEARCHING_ROD,
        )
    }
}
