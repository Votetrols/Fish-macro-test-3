package com.fischa.core.safety

import com.fischa.core.config.AppConfig
import com.fischa.core.state.FishingState

/** Why a requested real gesture was refused. Token values are included in debug/log output. */
enum class DenyReason {
    OK,
    /** V9.1 — a automação não está em FISHING_ACTIVE (APP_IDLE/APP_READY/FISHING_STOPPING). */
    AUTOMATION_NOT_ACTIVE,
    MACRO_DISABLED,
    REAL_INPUT_DISABLED,
    CAPTURE_STOPPED,
    ROBLOX_NOT_DETECTED,
    FOREGROUND_UNAUTHORIZED,
    OVERLAY_ACTIVE,
    STATE_NOT_ACTIONABLE,
    FRAME_STALE,
    TARGET_CONFIDENCE_LOW,
    TRACKING_LOST,
    CONTROLLER_UNSAFE,
    EMERGENCY_STOP,
    RATE_LIMITED,
    INVALID_COMMAND,
    INVALID_DURATION,
    COORDINATES_OUT_OF_BOUNDS,
}

data class Verdict(val allowed: Boolean, val reason: DenyReason) {
    companion object {
        val ALLOW = Verdict(true, DenyReason.OK)
    }
}

enum class GestureAction { TAP, HOLD_START, HOLD_EXTEND, HOLD_RELEASE, CANCEL_ALL }

data class InputRequest(
    val action: GestureAction,
    val nx: Float = Float.NaN,
    val ny: Float = Float.NaN,
    val durationMs: Long = 0L,
    val confidence: Float = 0f,
    val reason: String = "",
)

/**
 * Live state read by the single authorization gate. The platform updates foreground/capture
 * signals asynchronously; the vision worker updates frame/state/tracking signals per frame.
 */
class SafetyContext {
    /**
     * V9.1 (spec §4/§9): a automação está em `FISHING_ACTIVE`? Falso em `APP_IDLE`, `APP_READY` e
     * durante o `FISHING_STOPPING` — o gate rejeita qualquer input novo nesses estados. O valor é
     * atualizado pelo [com.fischa.core.pipeline.VisionPipeline] a cada frame a partir da máquina de
     * automação (nunca por um timer).
     */
    @Volatile var automationActive = false
    @Volatile var macroEnabled = false
    @Volatile var realInputEnabled = false
    @Volatile var captureHealthy = false
    @Volatile var robloxDetected = false
    @Volatile var platformAuthorized = false
    @Volatile var overlaySuspected = false
    @Volatile var state: FishingState = FishingState.IDLE
    @Volatile var targetConfidence = 0f
    @Volatile var trackingOk = false
    @Volatile var controllerSafe = false
    @Volatile var frameTimestampNs = 0L
    @Volatile var lastInputNs = 0L

    /** Compatibility accessor; new code uses [robloxDetected] + [overlaySuspected]. */
    @Deprecated("Use robloxDetected and overlaySuspected")
    var robloxForeground: Boolean
        get() = robloxDetected && !overlaySuspected
        set(value) {
            robloxDetected = value
            platformAuthorized = value
            overlaySuspected = false
        }

    fun inputAuthorized(): Boolean = robloxDetected && platformAuthorized && !overlaySuspected
}

/**
 * Central fail-closed gate immediately before InputExecutor and before every continued hold
 * segment. No detector/controller/platform input code may create its own allow rule.
 */
class InputSafetyGuard(private val cfg: AppConfig.Safety) {

    fun evaluate(
        ctx: SafetyContext,
        request: InputRequest,
        nowNs: Long,
        emergency: EmergencyStop,
    ): Verdict {
        // Releases and cancellation are cleanup, never a new game input. They must remain
        // available even after every other safety condition fails.
        if (request.action == GestureAction.HOLD_RELEASE || request.action == GestureAction.CANCEL_ALL) {
            return Verdict.ALLOW
        }
        if (emergency.latched) return Verdict(false, DenyReason.EMERGENCY_STOP)
        // V9.1 spec §9: "antes de qualquer ação automática, verificar FISHING_ACTIVE".
        // STOP e o estado READY derrubam esta condição imediatamente.
        if (!ctx.automationActive) return Verdict(false, DenyReason.AUTOMATION_NOT_ACTIVE)
        if (!ctx.macroEnabled) return Verdict(false, DenyReason.MACRO_DISABLED)
        if (!ctx.realInputEnabled) return Verdict(false, DenyReason.REAL_INPUT_DISABLED)
        if (!ctx.captureHealthy) return Verdict(false, DenyReason.CAPTURE_STOPPED)
        if (!ctx.robloxDetected) return Verdict(false, DenyReason.ROBLOX_NOT_DETECTED)
        if (ctx.overlaySuspected) return Verdict(false, DenyReason.OVERLAY_ACTIVE)
        if (!ctx.platformAuthorized) return Verdict(false, DenyReason.FOREGROUND_UNAUTHORIZED)
        if (!ctx.state.allowsInput()) return Verdict(false, DenyReason.STATE_NOT_ACTIONABLE)
        if (!ctx.controllerSafe) return Verdict(false, DenyReason.CONTROLLER_UNSAFE)
        if (ctx.frameTimestampNs <= 0L || nowNs < ctx.frameTimestampNs) {
            return Verdict(false, DenyReason.FRAME_STALE)
        }
        val frameAgeMs = (nowNs - ctx.frameTimestampNs) / 1_000_000L
        if (frameAgeMs > cfg.maxFrameAgeMs) return Verdict(false, DenyReason.FRAME_STALE)
        if (!request.confidence.isFinite() || request.confidence < cfg.minActionConfidence) {
            return Verdict(false, DenyReason.TARGET_CONFIDENCE_LOW)
        }
        if (ctx.state.requiresTracking() && !ctx.trackingOk) {
            return Verdict(false, DenyReason.TRACKING_LOST)
        }
        if (request.action != GestureAction.TAP && request.action != GestureAction.HOLD_START &&
            request.action != GestureAction.HOLD_EXTEND
        ) {
            return Verdict(false, DenyReason.INVALID_COMMAND)
        }
        if (!request.nx.isFinite() || !request.ny.isFinite() || request.nx !in 0f..1f || request.ny !in 0f..1f) {
            return Verdict(false, DenyReason.COORDINATES_OUT_OF_BOUNDS)
        }
        val durationLimit = when (request.action) {
            GestureAction.TAP -> cfg.maxTapMs
            GestureAction.HOLD_START, GestureAction.HOLD_EXTEND -> cfg.maxHoldLeaseMs
            else -> 0L
        }
        if (request.durationMs !in 1..durationLimit) return Verdict(false, DenyReason.INVALID_DURATION)
        if (request.action == GestureAction.TAP || request.action == GestureAction.HOLD_START) {
            val gapNs = cfg.minInputGapMs * 1_000_000L
            if (ctx.lastInputNs > 0L && nowNs - ctx.lastInputNs < gapNs) {
                return Verdict(false, DenyReason.RATE_LIMITED)
            }
        }
        return Verdict.ALLOW
    }

    /** CASTING, PRESSING_SHAKE and the three minigame states (see [FishingState.actionable]). */
    private fun FishingState.allowsInput() = actionable

    /** The three minigame states (see [FishingState.controlling]). */
    private fun FishingState.requiresTracking() = controlling

    /**
     * V5 §4 — the WAITING_FOR_ROD → CASTING transition gate. The rod button alone is not
     * enough: Roblox must be confirmed in the foreground and this guard must authorize the
     * transition. When any condition fails the machine stays in WAITING_FOR_ROD and no
     * gesture is ever produced (with realInput OFF the verdict is REAL_INPUT_DISABLED and the
     * pipeline logs ROD_DETECTED / WOULD_CAST instead of touching the screen).
     *
     * This is the same rule set a HOLD_START for the cast would be judged by, minus the
     * per-gesture rate limit (the actual press is still rate-limited when dispatched).
     */
    fun evaluateCastGate(
        ctx: SafetyContext,
        rodConfidence: Float,
        nx: Float,
        ny: Float,
        nowNs: Long,
        emergency: EmergencyStop,
    ): Verdict {
        if (emergency.latched) return Verdict(false, DenyReason.EMERGENCY_STOP)
        // V9.1 §9: o cast é a primeira ação automática do ciclo — exige FISHING_ACTIVE.
        if (!ctx.automationActive) return Verdict(false, DenyReason.AUTOMATION_NOT_ACTIVE)
        if (!ctx.macroEnabled) return Verdict(false, DenyReason.MACRO_DISABLED)
        if (!ctx.realInputEnabled) return Verdict(false, DenyReason.REAL_INPUT_DISABLED)
        if (!ctx.captureHealthy) return Verdict(false, DenyReason.CAPTURE_STOPPED)
        if (!ctx.robloxDetected) return Verdict(false, DenyReason.ROBLOX_NOT_DETECTED)
        if (ctx.overlaySuspected) return Verdict(false, DenyReason.OVERLAY_ACTIVE)
        if (!ctx.platformAuthorized) return Verdict(false, DenyReason.FOREGROUND_UNAUTHORIZED)
        if (ctx.state != FishingState.WAITING_FOR_ROD) return Verdict(false, DenyReason.STATE_NOT_ACTIONABLE)
        if (ctx.frameTimestampNs <= 0L || nowNs < ctx.frameTimestampNs) {
            return Verdict(false, DenyReason.FRAME_STALE)
        }
        val frameAgeMs = (nowNs - ctx.frameTimestampNs) / 1_000_000L
        if (frameAgeMs > cfg.maxFrameAgeMs) return Verdict(false, DenyReason.FRAME_STALE)
        if (!rodConfidence.isFinite() || rodConfidence < cfg.minActionConfidence) {
            return Verdict(false, DenyReason.TARGET_CONFIDENCE_LOW)
        }
        if (!nx.isFinite() || !ny.isFinite() || nx !in 0f..1f || ny !in 0f..1f) {
            return Verdict(false, DenyReason.COORDINATES_OUT_OF_BOUNDS)
        }
        return Verdict.ALLOW
    }
}

/** Latching stop. Only a deliberate user action may clear it. */
class EmergencyStop(initiallyLatched: Boolean = false) {
    @Volatile var latched = initiallyLatched
        private set
    private val listeners = ArrayList<() -> Unit>()

    fun addListener(listener: () -> Unit) {
        synchronized(listeners) { listeners.add(listener) }
    }

    fun removeListener(listener: () -> Unit) {
        synchronized(listeners) { listeners.remove(listener) }
    }

    fun activate(reason: String) {
        if (latched) return
        latched = true
        val snapshot = synchronized(listeners) { ArrayList(listeners) }
        snapshot.forEach { runCatching { it() } }
    }

    fun clear() { latched = false }
}
