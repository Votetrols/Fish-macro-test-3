package com.fischa.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.view.WindowManager
import com.fischa.core.vision.VisionFrame
import kotlin.math.roundToInt

/**
 * MediaProjection → reused [VisionFrame] pipeline (spec §2, §16 low-cost processing).
 * Everything reusable is allocated once in [start]: capture Bitmap, scaled Bitmap, the frame
 * IntArray/ByteArray. Frames are polled from the engine thread via [readFrame] — no callbacks,
 * no queue churn. On a stride-padded capture (rare, device-specific) we fall back to a
 * per-row copy; the common case is a single [Bitmap.copyPixelsFromBuffer].
 */
class ScreenCaptureSource(
    context: Context,
    private val projection: MediaProjection,
    /** cap capture resolution before downscale — the engine never needs more than this */
    private val captureWidthMax: Int = 720,
    val procWidth: Int = 640,
) : AutoCloseable {

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val densityDpi = context.resources.displayMetrics.densityDpi

    @Volatile
    var captureHealthy = false
        private set

    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var full: Bitmap? = null
    private var scaled: Bitmap? = null
    private var scaledCanvas: Canvas? = null
    private val scalePaint = Paint().apply { isFilterBitmap = false; isDither = false }
    private val dstRect = Rect()

    private var capW = 0
    private var capH = 0
    private var procW = procWidth
    private var procH = 0
    private var frame: VisionFrame? = null
    private var rowPix = IntArray(0)

    val frameWidth: Int get() = procW
    val frameHeight: Int get() = procH

    /** (re)starts capture; call again on display size change */
    @Suppress("DEPRECATION")
    fun start() {
        val size = Point2()
        wm.defaultDisplay.getRealSize(size.p)
        val sw = if (size.x > 0) size.x else 1080
        val sh = if (size.y > 0) size.y else 1920
        val scale = minOf(1f, captureWidthMax.toFloat() / maxOf(1, sw))
        capW = ((sw * scale).roundToInt()).let { it - it % 2 }
        capH = ((sh * scale).roundToInt()).let { it - it % 2 }
        procW = procWidth.coerceAtMost(capW)
        procH = maxOf(16, (capH * (procW.toFloat() / capW)).roundToInt())

        reader?.close()
        display?.release()
        if (full == null || full!!.width != capW || full!!.height != capH) {
            runCatching { full?.recycle() }
            full = Bitmap.createBitmap(capW, capH, Bitmap.Config.ARGB_8888)
        }
        scaled = Bitmap.createBitmap(procW, procH, Bitmap.Config.ARGB_8888).also {
            scaledCanvas = Canvas(it)
        }
        rowPix = IntArray(capW)
        val r = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        reader = r
        display = projection.createVirtualDisplay(
            "fisch-capture", capW, capH, densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, null
        )
        frame = VisionFrame(procW, procH, IntArray(procW * procH), ByteArray(procW * procH))
        captureHealthy = display != null
    }

    private class Point2(val p: android.graphics.Point = android.graphics.Point()) {
        val x get() = p.x
        val y get() = p.y
    }

    /**
     * Copy the newest captured frame into the reused [VisionFrame].
     * @return the frame, or null when no new frame is available.
     */
    fun readFrame(): VisionFrame? {
        if (!captureHealthy) return null
        val img = reader?.acquireLatestImage() ?: return null
        try {
            val f = full ?: return null
            val plane = img.planes[0]
            if (plane.rowStride == img.width * plane.pixelStride) {
                plane.buffer.position(0)
                f.copyPixelsFromBuffer(plane.buffer)
            } else {
                // stride-padded fallback: copy row by row (still allocation-free)
                val buf = plane.buffer
                for (y in 0 until minOf(img.height, capH)) {
                    // read ints directly from the buffer (RGBA bytes → ARGB int)
                    for (x in 0 until minOf(img.width, capW)) {
                        val i = y * plane.rowStride + x * plane.pixelStride
                        val rr = buf.get(i).toInt() and 0xFF
                        val gg = buf.get(i + 1).toInt() and 0xFF
                        val bb = buf.get(i + 2).toInt() and 0xFF
                        rowPix[x] = (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
                    }
                    f.setPixels(rowPix, 0, capW, 0, y, minOf(img.width, capW), 1)
                }
            }
            val canvas = scaledCanvas ?: return null
            dstRect.set(0, 0, procW, procH)
            canvas.drawBitmap(f, null, dstRect, scalePaint)
            val fr = frame ?: return null
            scaled?.getPixels(fr.argb, 0, procW, 0, 0, procW, procH)
            fr.resetFor(System.nanoTime(), fr.serial + 1L)
            return fr
        } finally {
            img.close()
        }
    }

    override fun close() {
        captureHealthy = false
        runCatching { display?.release() }
        runCatching { reader?.close() }
        display = null
        reader = null
        runCatching { full?.recycle() }
        runCatching { scaled?.recycle() }
        full = null
        scaled = null
        scaledCanvas = null
    }
}
