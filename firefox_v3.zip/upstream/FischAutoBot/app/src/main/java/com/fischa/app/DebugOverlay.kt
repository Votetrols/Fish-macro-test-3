package com.fischa.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.fischa.core.debug.RenderModel

/**
 * System-overlay debug HUD (spec §14): FPS, state, bar/block/fish boxes, normalized
 * positions, error, velocities, confidences, current action and progress. Reads only the
 * last published [RenderModel]; draws at view cadence, never blocks the engine.
 */
class DebugOverlay(private val context: Context) {

    private val wm = context.getSystemService(WindowManager::class.java)
        ?: context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var model: RenderModel? = null

    private val view = object : View(context) {
        override fun onDraw(c: Canvas) {
            model?.let { drawModel(c, it, width.toFloat(), height.toFloat()) }
        }
    }

    private val boxPaint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        isAntiAlias = false
    }
    private val txt = Paint().apply {
        color = Color.WHITE
        textSize = 26f
        isAntiAlias = false
        setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }
    private val txtSmall = Paint().apply {
        color = Color.LTGRAY
        textSize = 21f
        isAntiAlias = false
        setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }
    private val fill = Paint().apply { style = Paint.Style.FILL }

    private var params: WindowManager.LayoutParams? = null

    fun enable() {
        if (params != null) return
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            // Accessibility overlays are the only overlay type allowed to sit above other apps
            // without re-requesting the "draw over other apps" permission mid-session.
            if (android.os.Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(view, p)
        params = p
    }

    fun disable() {
        params?.let { runCatching { wm.removeViewImmediate(view) } }
        params = null
    }

    fun setModel(m: RenderModel?) {
        model = m
    }

    fun invalidate() {
        if (params != null) view.invalidate()
    }

    private fun drawModel(c: Canvas, m: RenderModel, w: Float, h: Float) {
        var y = 34f
        val lineH = 30f

        c.drawText("F${"%.1f".format(m.fps)} ${"%.1f".format(m.procMs)}ms  ${m.state}  " +
            if (m.armed) "ARMED" else "off", 12f, y, txt)
        y += lineH
        c.drawText("conf g=${"%.2f".format(m.confGlobal)} bar=${"%.2f".format(m.confBar)} " +
            "fish=${"%.2f".format(m.confFish)} p=${"%.2f".format(m.confPlayer)} " +
            "sk=${"%.2f".format(m.confShake)} rod=${"%.2f".format(m.confRod)}", 12f, y, txtSmall)
        y += lineH
        c.drawText("fish=${"%.3f".format(m.fishCx)} player=${"%.3f".format(m.playerCx)} " +
            "err=${"%+.3f".format(m.error)} vF=${"%+.2f".format(m.fishVel)} " +
            "vP=${"%+.2f".format(m.playerVel)} vD=${"%+.2f".format(m.desiredVel)}", 12f, y, txtSmall)
        y += lineH
        c.drawText("${m.action}${if (m.holdActive) " (HOLD)" else ""} " +
            "prog=${"%.2f".format(m.progress)}(+${"%.2f".format(m.progressRate)}/s) " +
            "taps=${m.tapsThisSession}/sess ${m.shakeSession} ${m.denyReason}", 12f, y, txtSmall)
        if (m.emergency) {
            c.drawText("EMERGENCY STOP — latched", 12f, y + lineH,
                Paint(txt).apply { color = Color.RED })
        }

        m.barBox?.let { drawBox(c, it, w, h, Color.CYAN) }
        m.blockBox?.let { drawBox(c, it, w, h, Color.WHITE) }
        m.fishBox?.let { drawBox(c, it, w, h, Color.YELLOW) }
        m.progressBox?.let { drawBox(c, it, w, h, Color.GREEN) }
        m.shakeBox?.let { drawBox(c, it, w, h, Color.MAGENTA) }
        m.rodBox?.let { drawBox(c, it, w, h, Color.RED) }

        // progress fill bar at the very top for a quick glance
        m.barBox?.let { b ->
            val l = b[0] * w
            val r = b[2] * w
            fill.color = Color.argb(160, 0, 220, 120)
            c.drawRect(l, 4f, l + (r - l) * m.progress.coerceIn(0f, 1f), 12f, fill)
        }
    }

    private fun drawBox(c: Canvas, norm: FloatArray, w: Float, h: Float, color: Int) {
        if (norm.size < 4) return
        boxPaint.color = color
        c.drawRect(norm[0] * w, norm[1] * h, norm[2] * w, norm[3] * h, boxPaint)
    }
}
