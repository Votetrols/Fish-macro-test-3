package com.fischa.app

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Minimal control surface (spec §13): Start/Stop, status, debug-overlay toggle, settings and
 * log viewers. No background work happens here — this activity only configures and commands
 * [FischEngineService].
 */
class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button
    private val ui = Handler(Looper.getMainLooper())
    private var service: FischEngineService? = null
    private var awaitingProjection = false
    private var overlayOn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        statusView = TextView(this).apply { textSize = 14f; setPadding(0, 0, 0, pad) }
        startBtn = Button(this).apply { text = "Iniciar" }
        stopBtn = Button(this).apply { text = "Parar" }
        val emergencyBtn = Button(this).apply { text = "EMERGÊNCIA (soltar tudo)" }
        val overlayCheck = CheckBox(this).apply {
            text = "Overlay de debug"; isChecked = overlayPref()
            setOnCheckedChangeListener { _, v -> overlayOn = v; saveOverlay(v); service?.setDebugOverlay(v) }
        }
        val settingsBtn = Button(this).apply {
            text = "Configurações"; setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        val a11yBtn = Button(this).apply {
            text = "Abrir Acessibilidade (habilitar entrada)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        logView = TextView(this).apply {
            textSize = 10f
            movementMethod = ScrollingMovementMethod()
            setPadding(0, pad, 0, 0)
        }

        row(root) { addView(startBtn) ; addView(stopBtn) }
        row(root) { addView(emergencyBtn); addView(a11yBtn) }
        row(root) { addView(overlayCheck); addView(settingsBtn) }
        root.addView(statusView, LinearLayout.LayoutParams(-1, -2))
        root.addView(ScrollView(this).apply {
            addView(logView, LinearLayout.LayoutParams(-1, -2))
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        startBtn.setOnClickListener { requestStart() }
        stopBtn.setOnClickListener {
            startService(Intent(this, FischEngineService::class.java)
                .setAction(FischEngineService.ACTION_STOP))
        }
        emergencyBtn.setOnClickListener {
            startService(Intent(this, FischEngineService::class.java)
                .setAction(FischEngineService.ACTION_EMERGENCY))
        }

        ui.post(object : Runnable {
            override fun run() {
                renderStatus()
                ui.postDelayed(this, 500)
            }
        })
    }

    override fun onStart() {
        super.onStart()
        bindService(
            Intent(this, FischEngineService::class.java), connection, Context.BIND_AUTO_CREATE
        )
    }

    override fun onStop() {
        runCatching { unbindService(connection) }
        service = null
        super.onStop()
    }

    private val connection = object : android.content.ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = (binder as? FischEngineService.LocalBinder)?.service
            service?.setDebugOverlay(overlayOn)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
        }
    }

    private fun renderStatus() {
        val s = FischEngineService.status
        val a11y = GameAccessibilityService.instance != null
        statusView.text = buildString {
            append("estado: ${s.state}   fps: ${"%.1f".format(s.fps)}   proc: ${"%.1f".format(s.procMs)}ms\n")
            append("rodando: ${s.running}   barra travada: ${s.barLocked}   conf: ${"%.2f".format(s.globalConf)}\n")
            append("acessibilidade: ${if (a11y) "ok" else "DESCONECTADA — ative nas configurações"}\n")
            if (s.emergency) append("EMERGÊNCIA ATIVADA — use 'Emergência' e depois Iniciar de novo para destravar\n")
            if (s.denyReason.isNotEmpty()) append("último deny: ${s.denyReason}\n")
            append("log: ${s.lastLogLine}\n")
        }
        logView.text = s.lastLogLine.ifEmpty { "—" }
    }

    private fun requestStart() {
        if (GameAccessibilityService.instance == null) {
            Toast.makeText(this, "Ative o serviço de acessibilidade do Fisch AutoBot primeiro",
                Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        awaitingProjection = true
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_PROJ)
    }

    @Deprecated("classic activity result on purpose: keeps this module dependency-light")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PROJ) return
        awaitingProjection = false
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, FischEngineService::class.java)
                .setAction(FischEngineService.ACTION_START)
                .putExtra(FischEngineService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(FischEngineService.EXTRA_RESULT_DATA, data)
            startService(i)
            if (overlayOn) service?.setDebugOverlay(true)
        } else {
            Toast.makeText(this, "Gravação de tela negada", Toast.LENGTH_LONG).show()
        }
    }

    private fun overlayPref() =
        getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).getBoolean("overlay", false)

    private fun saveOverlay(v: Boolean) =
        getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).edit().putBoolean("overlay", v).apply()

    private fun row(root: LinearLayout, init: LinearLayout.() -> Unit) {
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; init()
        })
    }

    companion object {
        private const val REQ_PROJ = 77
    }
}
