package com.fischa.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.projection.MediaProjectionManager
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.fischa.core.config.AppConfig
import com.fischa.core.log.Tags
import com.fischa.core.log.ThrottledLog
import com.fischa.core.pipeline.PipelineInput
import com.fischa.core.pipeline.VisionPipeline
import com.fischa.core.safety.EmergencyStop
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Owns the engine loop (spec §15/§24). Lifecycle:
 *   MainActivity --START(data)--> register MediaProjection --> capture thread →
 *   VisionPipeline.onFrame every vsync-ish tick → decisions through InputSafetyGuard (inside
 *   the core) → AndroidInputExecutor. STOP/unbind/error/emergency all funnel through
 *   [shutdown], which latches [EmergencyStop] first so nothing can be mid-gesture.
 */
class FischEngineService : Service() {

    companion object {
        const val ACTION_START = "com.fischa.app.START"
        const val ACTION_STOP = "com.fischa.app.STOP"
        const val ACTION_EMERGENCY = "com.fischa.app.EMERGENCY"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        const val CHANNEL_ID = "fisch-engine"

        /** latest status snapshot for the UI (cheap volatile publication) */
        @Volatile
        var status: StatusSnapshot = StatusSnapshot()

        fun prefs(c: Context): SharedPreferences =
            c.getSharedPreferences("fisch-config", Context.MODE_PRIVATE)

        fun loadConfig(c: Context): AppConfig {
            val map = HashMap<String, String>()
            val all = prefs(c).all
            for (key in all.keys) map[key] = all[key].toString()
            return AppConfig().withOverrides(map)
        }
    }

    data class StatusSnapshot(
        val running: Boolean = false,
        val state: String = "IDLE",
        val fps: Float = 0f,
        val procMs: Float = 0f,
        val barLocked: Boolean = false,
        val globalConf: Float = 0f,
        val denyReason: String = "",
        val emergency: Boolean = false,
        val lastLogLine: String = "",
    )

    inner class LocalBinder : Binder() {
        val service: FischEngineService get() = this@FischEngineService
    }

    private val binder = LocalBinder()
    private val engineThread = Handler(Looper.getMainLooper()) // UI-side helpers only; loop below
    private var loopThread: Thread? = null
    private val running = AtomicBoolean(false)

    private var projectionManager: MediaProjectionManager? = null
    private var capture: ScreenCaptureSource? = null
    private val logSink = LogRingBuffer(null)
    private lateinit var log: ThrottledLog
    private lateinit var cfg: AppConfig
    private lateinit var executor: AndroidInputExecutor
    private lateinit var emergency: EmergencyStop
    private lateinit var pipeline: VisionPipeline
    private var overlay: DebugOverlay? = null
    private var lastResultData: Intent? = null

    override fun onCreate() {
        super.onCreate()
        cfg = loadConfig(this)
        logSink.file = File(filesDir, "fisch-log.txt")
        log = ThrottledLog(logSink)
        executor = AndroidInputExecutor()
        emergency = EmergencyStop()
        pipeline = VisionPipeline(cfg, executor, log, emergency = emergency)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        createChannel()
    }

    @Suppress("DEPRECATION") // getParcelableExtra(String, Class) needs API 33; minSdk is 26
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForegroundWithNotification()
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                if (data != null) startEngine(code, data) else stopSelf()
            }
            ACTION_EMERGENCY -> emergency.activate("notification action")
            ACTION_STOP -> stopEngine()
        }
        return START_NOT_STICKY
    }

    override fun onBind(i: IBinder?): IBinder = binder

    override fun onDestroy() {
        stopEngine()
        super.onDestroy()
    }

    // ---------------------------------------------------------------------------------------

    private fun startEngine(resultCode: Int, data: Intent) {
        if (running.getAndSet(true)) return
        lastResultData = data
        val projection = projectionManager?.getMediaProjection(resultCode, data) ?: run {
            running.set(false)
            stopSelf()
            return
        }
        // API 33+ requires registering a callback before createVirtualDisplay; also our
        // CAPTURE_STARTED/CAPTURE_FAILED → CAPTURE_ERROR path (spec §16).
        projection.registerCallback(object : android.media.projection.MediaProjection.Callback() {
            override fun onStop() {
                log.e(Tags.ERROR, "capture", "[CAPTURE] projection stopped by system")
                emergency.activate("capture stopped")
                shutdownCapture()
            }
        }, engineThread)

        val src = ScreenCaptureSource(this, projection)
        src.start()
        capture = src
        pipeline.armed = true
        status = status.copy(running = true)

        val t = Thread { loop(src) }
        t.name = "fisch-engine"
        t.priority = Thread.NORM_PRIORITY + 2
        loopThread = t
        t.start()
    }

    /** The engine loop: one frame → one pipeline step; paced against measured capture rate. */
    private fun loop(src: ScreenCaptureSource) {
        var prevNs = 0L
        var fpsEma = 0f
        var overlaySampleNs = 0L
        var overlaySuspect = false
        var failures = 0
        val input = PipelineInput()
        while (running.get()) {
            val frame = try {
                src.readFrame()
            } catch (e: Exception) {
                log.e(Tags.ERROR, "capture", "[CAPTURE] frame read failed: ${e.message}")
                null
            }
            if (frame == null) {
                failures++
                if (failures > 60) { // ~2 s of nothing
                    log.e(Tags.ERROR, "capture", "[CAPTURE] no frames; pausing engine")
                    pipeline.armed = false
                    while (running.get() && !src.captureHealthy) Thread.sleep(200)
                    failures = 0
                } else {
                    Thread.sleep(8)
                }
                continue
            }
            failures = 0
            val nowNs = frame.timestampNs
            if (prevNs != 0L) {
                val inst = 1e9f / maxOf(1f, (nowNs - prevNs).toFloat())
                fpsEma = if (fpsEma == 0f) inst else fpsEma * 0.9f + inst * 0.1f
            }
            prevNs = nowNs
            frame.fps = fpsEma
            pipeline.setFpsMeasured(fpsEma)
            log.setNow(nowNs)

            if (nowNs - overlaySampleNs > 250_000_000L) {
                overlaySampleNs = nowNs
                val svc = GameAccessibilityService.instance
                overlaySuspect = svc?.overlaySuspected() == true
            }
            input.frameTimestampNs = nowNs
            input.captureHealthy = src.captureHealthy
            input.robloxForeground = GameAccessibilityService.instance
                ?.isRobloxForeground() ?: true // service off ⇒ don't fake a failure: pass true,
            // state machine still needs detections to act, and users may run without a11y for tests
            input.overlaySuspected = overlaySuspect

            try {
                pipeline.onFrame(frame, input)
            } catch (e: Exception) {
                log.e(Tags.ERROR, "pipeline", "[ERROR] pipeline step threw: ${e.message}")
                emergency.activate("pipeline exception")
            }

            val o = pipeline.output
            status = status.copy(
                running = true,
                state = o.state.name,
                fps = fpsEma,
                procMs = pipeline.render?.procMs ?: 0f,
                barLocked = o.barLocked,
                globalConf = o.globalConfidence,
                denyReason = o.inputDeniedReason,
                emergency = emergency.latched,
                lastLogLine = logSink.snapshot().substringAfterLast('\n'),
            )
            overlay?.let { ov ->
                ov.setModel(pipeline.render)
                ov.invalidate()
            }

            // pacing: never spin faster than the producer; target ≈ capture fps
            val target = if (fpsEma > 5f) (1000f / fpsEma).toLong() else 33L
            val spentMs = ((System.nanoTime() - nowNs) / 1_000_000L).coerceAtLeast(0)
            val sleep = target - spentMs
            if (sleep in 1..50) Thread.sleep(sleep)
        }
        shutdownCapture()
    }

    private fun shutdownCapture() {
        capture?.close()
        capture = null
    }

    private fun stopEngine() {
        if (!running.getAndSet(false)) return
        pipeline.armed = false
        val t = loopThread
        loopThread = null
        runCatching { t?.join(1500) }
        shutdownCapture()
        overlay?.disable()
        overlay = null
        status = StatusSnapshot()
        logSink.flushAndClose()
        stopSelf()
    }

    /** toggle from UI; the overlay shows whatever the last processed frame produced */
    fun setDebugOverlay(enabled: Boolean) {
        if (enabled) {
            if (overlay == null) overlay = DebugOverlay(this).also { it.enable() }
        } else {
            overlay?.disable()
            overlay = null
        }
    }

    fun clearEmergency() {
        emergency.clear()
    }

    fun applyConfig(newCfg: AppConfig) {
        cfg = newCfg
        // The engine captures its config at construction; simplest correct thing is a restart
        // (settings changes are rare and never mid-minigame per the UI flow).
        if (running.get()) {
            Handler(Looper.getMainLooper()).post { stopEngine() }
        }
    }

    private fun startForegroundWithNotification() {
        createChannel()
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, FischEngineService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopNow = PendingIntent.getService(
            this, 2, Intent(this, FischEngineService::class.java).setAction(ACTION_EMERGENCY),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Fisch AutoBot ativo")
            .setContentText("Pesca automática em execução — toque para abrir")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Parar", stopIntent)
            .addAction(android.R.drawable.ic_delete, "EMERGÊNCIA", stopNow)
            .build()
        ServiceCompat.startForeground(
            this, 42, notif,
            if (Build.VERSION.SDK_INT >= 34)
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            else 0
        )
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.notification_channel),
                    NotificationManager.IMPORTANCE_LOW)
            )
        }
    }
}
