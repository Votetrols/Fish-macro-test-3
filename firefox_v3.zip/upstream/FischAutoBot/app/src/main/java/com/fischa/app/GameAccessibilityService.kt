package com.fischa.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import com.fischa.core.control.InputExecutor
import kotlin.math.max
import kotlin.math.min

/**
 * The only path to real input (spec §3/§24). Every gesture the core wants goes through
 * [AndroidInputExecutor] → here; this service clamps coordinates, splits long presses into
 * bounded stroke segments (Android offers no public API to force-release a dispatched
 * gesture, so the bound is how "stuck finger" is prevented: no single segment lasts longer
 * than [maxStrokeMs], and cancelling a hold only drops its *pending* segments), and refuses
 * to overlap strokes.
 *
 * Foreground package + overlay suspicion also come from here (window state events are the
 * cheapest reliable signal, spec §16 ROBLOX_NOT_DETECTED).
 */
class GameAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: GameAccessibilityService? = null
            private set

        @Volatile
        var lastForegroundPackage: String = ""
            private set

        /** upper bound for any single injected stroke (see class doc) */
        @Volatile
        var maxStrokeMs: Int = 500

        /** pause between stroke segments of a long press */
        @Volatile
        var strokeGapMs: Int = 12

        const val ROBLOX_PACKAGE = "com.roblox.client"
    }

    val handler = Handler(Looper.getMainLooper())
    @Volatile private var gestureInFlight = false

    /** bumped by [cancelHold] so pending segments drop themselves */
    @Volatile private var holdGeneration = 0

    override fun onServiceConnected() {
        instance = this
        super.onServiceConnected()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        cancelHold()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cancelHold()
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            lastForegroundPackage = event.packageName?.toString() ?: ""
        }
    }

    fun isRobloxForeground(): Boolean = lastForegroundPackage == ROBLOX_PACKAGE

    /**
     * true when a non-application window (shade, launcher, dialog) is on top of the game.
     * Poll this — the API allocates; the engine samples ~4 Hz, not per frame.
     */
    fun overlaySuspected(): Boolean = try {
        windows.any { w ->
            val type = w.type
            type != android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION
        }
    } catch (_: Exception) {
        false
    }

    /**
     * A press at normalized (nx, ny) for [durationMs], executed as consecutive stroke segments
     * of at most [maxStrokeMs] with [strokeGapMs] gaps. Returns false when the first segment
     * could not be dispatched at all (service busy / not connected).
     */
    fun dispatchPress(nx: Float, ny: Float, durationMs: Int): Boolean {
        if (gestureInFlight) return false
        val metrics = resources.displayMetrics
        val x = nx.coerceIn(0f, 1f) * metrics.widthPixels
        val y = ny.coerceIn(0f, 1f) * metrics.heightPixels
        val gen = holdGeneration
        runSegment(x, y, max(1, durationMs), gen)
        return true
    }

    private fun runSegment(x: Float, y: Float, remainingMs: Int, gen: Int) {
        if (gen != holdGeneration) return // cancelled while queued
        val seg = min(remainingMs, maxStrokeMs)
        if (!dispatchSegment(x, y, seg)) return
        val left = remainingMs - seg - strokeGapMs
        if (left > 0) {
            handler.postDelayed({ runSegment(x, y, left, gen) }, (seg + strokeGapMs).toLong())
        }
    }

    private fun dispatchSegment(x: Float, y: Float, ms: Int): Boolean {
        if (gestureInFlight) return false
        // 1px drift keeps the touch alive for the game engine
        val path = Path().apply {
            moveTo(x, y)
            lineTo(x + 1f, y + 1f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, ms.toLong()))
            .build()
        gestureInFlight = true
        val endsAt = System.currentTimeMillis() + ms + 150L
        val started = try {
            dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) {
                    if (System.currentTimeMillis() >= endsAt - 200) gestureInFlight = false
                }

                override fun onCancelled(g: GestureDescription?) {
                    gestureInFlight = false
                }
            }, handler)
        } catch (_: RuntimeException) {
            false // service not connected / recycled
        }
        if (!started) gestureInFlight = false
        // watchdog: release the slot even if the callback never arrives
        handler.postDelayed({
            if (gestureInFlight && System.currentTimeMillis() > endsAt) gestureInFlight = false
        }, (ms + 400).toLong())
        return started
    }

    /** drops pending segments of the current hold (in-flight segment ends on its own, ≤ maxStrokeMs) */
    fun cancelHold() {
        holdGeneration++
    }

    fun busy(): Boolean = gestureInFlight
}

/**
 * Bridges the core [InputExecutor] to the accessibility service. A hold is realized as a
 * bounded stroke-segment train (see LIMITATIONS.md); the pipeline already cadences its own
 * tap/hold rhythm, so this class just fires and forgets.
 */
class AndroidInputExecutor : InputExecutor {

    @Volatile
    var lastLog = ""

    override fun tap(nx: Float, ny: Float, durationMs: Int) {
        val svc = GameAccessibilityService.instance ?: run {
            lastLog = "no accessibility service"
            return
        }
        val ok = svc.dispatchPress(nx, ny, max(1, durationMs))
        lastLog = if (ok) "ok" else "busy/refused"
    }

    override fun activeHoldCount(): Int =
        if (GameAccessibilityService.instance?.busy() == true) 1 else 0

    override fun cancelAll() {
        GameAccessibilityService.instance?.cancelHold()
    }
}
