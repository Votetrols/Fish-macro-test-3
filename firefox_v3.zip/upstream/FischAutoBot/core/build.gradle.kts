// Pure-JVM engine (vision + tracking + control + state + safety). No Android dependency:
// the replay harness and SelfTest run this exact code off-device.
plugins {
    id("org.jetbrains.kotlin.jvm")
}

java {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
}

dependencies {
    // deliberately empty — the core must stay framework-free
}
