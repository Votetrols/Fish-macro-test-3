package com.fischa.core.control

/**
 * The single door through which input reaches the device (spec §3/§24). The core only ever
 * calls this interface; the Android implementation (AccessibilityService gesture dispatch)
 * owns every device-specific concern and MUST NOT bypass the caller-side safety check.
 *
 * `durationMs` is deliberately allowed to be large (cast press ≈ 3000 ms). The platform side
 * is required to clamp coordinates to screen bounds and to time out any gesture it could not
 * confirm, so a stuck core can never leave a finger down.
 */
interface InputExecutor {
    /** one press of [durationMs] at normalized (nx, ny); implementation may complete later */
    fun tap(nx: Float, ny: Float, durationMs: Int)

    /** number of press gestures the executor currently considers in flight (debug/logging) */
    fun activeHoldCount(): Int = 0

    /** release everything immediately (EmergencyStop path) */
    fun cancelAll()

    object Noop : InputExecutor {
        override fun tap(nx: Float, ny: Float, durationMs: Int) {}
        override fun activeHoldCount(): Int = 0
        override fun cancelAll() {}
    }
}
