package com.fischa.core.pipeline

import com.fischa.core.common.clamp
import com.fischa.core.config.AppConfig
import com.fischa.core.control.CastController
import com.fischa.core.control.ControlAction
import com.fischa.core.control.FishingController
import com.fischa.core.control.InputExecutor
import com.fischa.core.control.ShakeController
import com.fischa.core.debug.RenderModel
import com.fischa.core.log.Tags
import com.fischa.core.log.ThrottledLog
import com.fischa.core.safety.DenyReason
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.InputSafetyGuard
import com.fischa.core.safety.SafetyContext
import com.fischa.core.state.Evidence
import com.fischa.core.state.FishingState
import com.fischa.core.state.FishingStateMachine
import com.fischa.core.tracking.BarTracker
import com.fischa.core.tracking.ConfidenceTracker
import com.fischa.core.tracking.FishTracker
import com.fischa.core.tracking.PlayerBarTracker
import com.fischa.core.tracking.ProgressTracker
import com.fischa.core.vision.CatchConfirmDetector
import com.fischa.core.vision.DetSnapshot
import com.fischa.core.vision.FishDetector
import com.fischa.core.vision.FishingBarDetector
import com.fischa.core.vision.FishingButtonDetector
import com.fischa.core.vision.PlayerBarDetector
import com.fischa.core.vision.ProgressDetector
import com.fischa.core.vision.ShakeDetector
import com.fischa.core.vision.VisionFrame
import kotlin.math.max

/**
 * The whole engine: capture-frame in → detection → tracking → state machine → decision →
 * (safety gate) → input out. Deliberately framework-free: the Android layer supplies frames,
 * timestamps, foreground info and an [InputExecutor]; everything else lives here so the exact
 * same code runs in the replay harness.
 *
 * Threading: single-threaded per instance (the host owns the loop). Host→pipeline flags
 * (armed / capture healthy / foreground) are @Volatile one-way writes.
 */
class VisionPipeline(
    val cfg: AppConfig,
    private val executor: InputExecutor,
    private val log: ThrottledLog,
    val safety: SafetyContext = SafetyContext(),
    val emergency: EmergencyStop = EmergencyStop(),
) {
    // --- vision ---------------------------------------------------------------------------
    private val rodDetector = FishingButtonDetector(cfg.vision)
    private val shakeDetector = ShakeDetector(cfg.vision)
    private val barDetector = FishingBarDetector(cfg.vision)
    private val blockDetector = PlayerBarDetector(cfg.vision)
    private val fishDetector = FishDetector(cfg.vision)
    private val progressDetector = ProgressDetector(cfg.vision)
    private val catchDetector = CatchConfirmDetector(cfg.vision)

    // --- tracking -------------------------------------------------------------------------
    private val barTracker = BarTracker(cfg.tracking)
    private val fishTracker = FishTracker(cfg.tracking)
    private val blockTracker = PlayerBarTracker(cfg.tracking)
    private val progressTracker = ProgressTracker()
    private val confTracker = ConfidenceTracker(cfg.tracking)
    private val barRect = floatArrayOf(0f, 0f, 0f, 0f) // smoothed left top right bottom (px)

    // --- decision --------------------------------------------------------------------------
    private val stateMachine = FishingStateMachine(cfg.state)
    private val shakeController = ShakeController(cfg.shake)
    private val castController = CastController(cfg.cast)
    private val controller = FishingController(cfg.control)
    private val guard = InputSafetyGuard(cfg.safety)
    private val evidence = Evidence()

    val output = PipelineOutput()

    /** host sets this after UI "Start" */
    @Volatile var armed: Boolean = false
        set(v) { field = v; safety.macroEnabled = v }

    @Volatile var lastFps: Float = 0f
    private var lastFrameNs = 0L
    private var lastIssuedInputNs = 0L
    private var lastHoldTapNs = 0L
    private var holdActive = false
    private var holdAnchorX = 0.5f
    private var holdAnchorY = 0.55f
    private var lastActionName = ControlAction.NONE
    private var lastDeny = DenyReason.OK

    @Volatile var render: RenderModel? = null

    /** overlay-friendly normalized box */
    private fun normBox(src: DetSnapshot, w: Int, h: Int): FloatArray? {
        if (!src.detected) return null
        return floatArrayOf(src.box.left / w, src.box.top / h, src.box.right / w, src.box.bottom / h)
    }

    init {
        emergency.addListener {
            // release anything the macro holds, immediately, before state settles
            runCatching { executor.cancelAll() }
            holdActive = false
            controller.reset()
        }
        safety.apply(cfg.safety)
    }

    /** settable "tap & hold anywhere" anchor (normalized) */
    fun setHoldAnchor(nx: Float, ny: Float) { holdAnchorX = nx; holdAnchorY = ny }

    fun onFrame(frame: VisionFrame, input: PipelineInput) {
        val t0 = System.nanoTime()
        val now = frame.timestampNs
        log.setNow(now)
        frame.ensureGray()
        val w = frame.width; val h = frame.height

        safety.captureHealthy = input.captureHealthy
        safety.robloxForeground = input.robloxForeground
        safety.globalConfidence = confTracker.global

        runDetectors(frame)

        // ---- trackers --------------------------------------------------------------------
        val barOk = barDetector.out.detected
        val barLocked = barOk && barTracker.update(
            barDetector.geometry.left, barDetector.geometry.top,
            barDetector.geometry.right, barDetector.geometry.bottom,
            max(barDetector.out.confidence, 0.6f), barRect,
        )
        if (barLocked) barTracker.touch(now)
        val barW = max(1f, barRect[2] - barRect[0])

        // block needs the smoothed bar; fish needs block + tracker prior; progress needs bar.
        // (the raw-geometry priors were injected inside runDetectors; here refine with the
        // tracker-smoothed rect, then re-run the dependent detectors on the final frame.)
        if (barLocked) {
            blockDetector.setBarPrior(barRect[0], barRect[1], barRect[2], barRect[3])
            fishDetector.setBarPrior(barRect[0], barRect[1], barRect[2], barRect[3])
            progressDetector.setBarPrior(barRect[0], barRect[1], barRect[2], barRect[3])
        } else {
            blockDetector.clearBarPrior(); fishDetector.clearBarPrior(); progressDetector.clearBarPrior()
        }
        blockDetector.process(frame)
        if (barLocked && blockDetector.out.detected) {
            fishDetector.blockL = blockDetector.geom.left.toInt()
            fishDetector.blockR = blockDetector.geom.right.toInt()
        } else {
            fishDetector.blockL = -1; fishDetector.blockR = -1
        }
        fishDetector.priorXNorm = if (fishTracker.out.valid) fishTracker.out.x else -1f
        fishDetector.process(frame)
        progressDetector.process(frame)

        if (barLocked) {
            if (blockDetector.out.detected) {
                blockTracker.update(
                    now,
                    (blockDetector.geom.centerX - barRect[0]) / barW,
                    blockDetector.geom.width / barW,
                    blockDetector.out.confidence,
                    blockDetector.out.v0 > 0.5f,
                    barRect[0], barRect[2], blockDetector.geom.left, blockDetector.geom.right,
                )
            } else {
                blockTracker.update(now, null, 0f, 0f, false, barRect[0], barRect[2], 0f, 0f)
            }
            if (fishDetector.out.detected) fishTracker.update(now, fishDetector.out.v0, fishDetector.out.confidence, barW)
            else fishTracker.update(now, null, 0f, barW)
        } else {
            blockTracker.reset(); fishTracker.reset()
        }
        progressTracker.update(now, if (progressDetector.out.detected) progressDetector.out.v0 else null,
            progressDetector.out.confidence)
        confTracker.update(barDetector.out.confidence, fishTracker.out.confidence, blockTracker.out.confidence, now)

        // ---- state machine -----------------------------------------------------------------
        evidence.fishingButton = rodDetector.out.detected; evidence.fishingButtonConf = rodDetector.out.confidence
        evidence.shake = shakeDetector.out.detected; evidence.shakeConf = shakeDetector.out.confidence
        evidence.bar = barDetector.out.detected; evidence.barConf = barDetector.out.confidence
        evidence.fishOk = fishTracker.out.valid && !fishTracker.out.lost
        evidence.playerOk = blockTracker.out.valid && !blockTracker.out.lost
        evidence.progress = progressTracker.value
        evidence.catchConfirm = catchDetector.out.detected; evidence.catchConfirmConf = catchDetector.out.confidence
        evidence.robloxForeground = input.robloxForeground
        evidence.captureHealthy = input.captureHealthy
        evidence.overlaySuspected = input.overlaySuspected
        evidence.globalConf = confTracker.global
        evidence.shakeGone = shakeController.phase == ShakeController.Phase.SEARCHING && !shakeDetector.out.detected
        evidence.nowNs = now
        evidence.dtSec = if (lastFrameNs == 0L) 1f / 30f
        else clamp((now - lastFrameNs) / 1e9f, 0.001f, 0.25f)
        lastFrameNs = now

        val wasState = stateMachine.state
        stateMachine.armed = armed && input.macroEnabled
        stateMachine.update(evidence)
        val state = stateMachine.state
        if (state != wasState) {
            log.i(Tags.STATE, "st", "[STATE] ${wasState.name} -> ${state.name} (${stateMachine.lastReason})")
            onStateEntry(state, now)
        }

        // ---- controllers -------------------------------------------------------------------
        var tapNx = -1f; var tapNy = -1f; var tapDur = 0; var reason = ""
        var intendedAction = ControlAction.NONE

        if (state == FishingState.CASTING) {
            val req = castController.tick(
                rodDetector.out.detected, rodDetector.out.confidence,
                if (rodDetector.out.detected) rodDetector.out.box.centerX / w else 0f,
                if (rodDetector.out.detected) rodDetector.out.box.centerY / h else 0f, now,
            )
            if (req != null) { tapNx = req.nx; tapNy = req.ny; tapDur = req.holdMs.toInt(); reason = req.reason }
        }

        if (stateMachine.shakePhaseActive()) {
            val cxN = if (shakeDetector.out.detected) shakeDetector.out.box.centerX / w else -1f
            val cyN = if (shakeDetector.out.detected) shakeDetector.out.box.centerY / h else -1f
            val tap = shakeController.tick(shakeDetector.out.detected, shakeDetector.out.confidence, cxN, cyN, now)
            if (tap != null) { tapNx = tap.nx; tapNy = tap.ny; tapDur = tap.durMs; reason = tap.reason }
        }

        if (barLocked) {
            if (state.controlling) {
                val d = controller.update(now, evidence.dtSec, fishTracker.out, blockTracker.out, progressTracker.rate)
                intendedAction = d.action
                reason = d.reason
                with(output) {
                    errorNorm = d.error; fishVel = d.fishVel; playerVel = d.playerVel; desiredVel = d.desiredVel
                }
                when (d.action) {
                    ControlAction.TAP -> {
                        tapNx = holdAnchorX; tapNy = holdAnchorY; tapDur = d.tapDurMs
                    }
                    ControlAction.HOLD_START -> { holdActive = true; lastHoldTapNs = 0L }
                    ControlAction.HOLD_EXTEND -> {}
                    ControlAction.HOLD_RELEASE -> holdActive = false
                    ControlAction.NONE -> {}
                }
                if (holdActive) {
                    if (now - lastHoldTapNs >= cfg.control.tapHoldPeriodMs * 1_000_000L) {
                        tapNx = holdAnchorX; tapNy = holdAnchorY; tapDur = cfg.control.tapHoldDurMs
                        lastHoldTapNs = now
                        reason = "$reason | hold cadence"
                    }
                }
                lastActionName = d.action
            } else {
                if (holdActive) holdActive = false
                controller.reset()
                lastActionName = ControlAction.NONE
                with(output) { errorNorm = 0f; fishVel = 0f; playerVel = 0f; desiredVel = 0f }
            }
        } else {
            if (holdActive) holdActive = false
            controller.reset()
            lastActionName = ControlAction.NONE
        }

        // ---- input execution through the safety gate ---------------------------------------
        var denied = DenyReason.OK
        var issued = false
        if (tapNx >= 0f && tapNy >= 0f) {
            val v = guard.evaluate(safety, now, tapNx, tapNy, emergency, isHold = tapDur > 1000)
            if (v.allowed) {
                safety.lastInputNs = now
                executor.tap(tapNx, tapNy, tapDur)
                lastIssuedInputNs = now
                issued = true
                log.i(Tags.INPUT, "tap", "[INPUT] TAP x=%.3f y=%.3f dur=%dms (%s)".format(tapNx, tapNy, tapDur, reason))
            } else {
                denied = v.reason
                log.w(Tags.SAFETY, "deny", "[SAFETY] deny TAP: ${v.reason.name} ($reason)")
            }
        }
        lastDeny = denied

        // ---- outputs / render snapshot -----------------------------------------------------
        with(output) {
            fishingButton.copyFrom(rodDetector.out)
            shake.copyFrom(shakeDetector.out)
            bar.copyFrom(barDetector.out)
            player.copyFrom(blockDetector.out)
            fish.copyFrom(fishDetector.out)
            progress.copyFrom(progressDetector.out)
            catchConfirm.copyFrom(catchDetector.out)
            this.state = state
            this.stateReason = stateMachine.lastReason
            this.fishXNorm = fishTracker.out.x
            this.playerXNorm = blockTracker.out.x
            this.progressValue = max(0f, progressTracker.value)
            this.progressRate = progressTracker.rate
            this.globalConfidence = confTracker.global
            this.intendedAction = intendedAction
            this.tapDurationMs = tapDur
            this.holdActive = holdActive
            this.decisionReason = reason
            this.inputIssued = issued
            this.inputDeniedReason = if (denied == DenyReason.OK) "" else denied.name
            this.emergencyLatched = emergency.latched
            this.armed = armed
            this.shakeSessionTaps = shakeController.tapsThisSession
            this.shakeSession = stateMachine.shakeSession
            this.castPhase = castController.phase.name
            this.barRectPx[0] = barRect[0]; this.barRectPx[1] = barRect[1]
            this.barRectPx[2] = barRect[2]; this.barRectPx[3] = barRect[3]
            this.barLocked = barLocked
            this.blockCenterPx = if (blockDetector.out.detected) blockDetector.geom.centerX else -1f
            this.fishCenterPx = if (fishDetector.out.detected) (fishDetector.out.box.left + fishDetector.out.box.right) / 2f else -1f
        }
        render = RenderModel(
            state = state,
            fps = lastFps,
            procMs = (System.nanoTime() - t0) / 1e6f,
            barBox = if (barLocked) floatArrayOf(barRect[0] / w, barRect[1] / h, barRect[2] / w, barRect[3] / h) else null,
            blockBox = normBox(blockDetector.out, w, h),
            fishBox = normBox(fishDetector.out, w, h),
            shakeBox = normBox(shakeDetector.out, w, h),
            rodBox = normBox(rodDetector.out, w, h),
            progressBox = normBox(progressDetector.out, w, h),
            fishCx = fishTracker.out.x,
            playerCx = blockTracker.out.x,
            error = output.errorNorm,
            fishVel = output.fishVel,
            playerVel = output.playerVel,
            desiredVel = output.desiredVel,
            action = lastActionName.name,
            actionReason = reason,
            progress = output.progressValue,
            progressRate = output.progressRate,
            confGlobal = confTracker.global,
            confBar = confTracker.bar,
            confFish = confTracker.fish,
            confPlayer = confTracker.player,
            confShake = shakeDetector.out.confidence,
            confRod = rodDetector.out.confidence,
            holdActive = holdActive,
            tapsThisSession = shakeController.tapsThisSession,
            shakeSession = stateMachine.shakeSession,
            denyReason = if (denied == DenyReason.OK) "" else denied.name,
            emergency = emergency.latched,
            armed = armed,
        )
    }

    private fun onStateEntry(state: FishingState, now: Long) {
        when (state) {
            FishingState.SEARCHING_SHAKE -> { shakeController.resetSession(); castController.onShakeOrBarSeen(now) }
            FishingState.CASTING -> castController.start()
            FishingState.FISHING_MINIGAME_DETECTED -> {
                controller.reset(); holdActive = false
                fishTracker.reset(); blockTracker.reset(); progressTracker.reset()
            }
            FishingState.RESET -> {
                shakeController.resetSession(); castController.reset(); controller.reset()
                holdActive = false; catchDetector.reset()
            }
            FishingState.CATCH_CONFIRMATION -> catchDetector.noteBarGone(now)
            FishingState.VISION_LOST, FishingState.CAPTURE_ERROR, FishingState.ROBLOX_NOT_DETECTED,
            FishingState.EMERGENCY_STOP, FishingState.INVALID_STATE,
            -> {
                // fail-safe: any active hold released, trackers dropped
                runCatching { executor.cancelAll() }
                holdActive = false; controller.reset()
                fishTracker.reset(); blockTracker.reset()
            }
            else -> {}
        }
    }

    /** detector batch — independent calls, priors injected between them by this orchestrator */
    private fun runDetectors(frame: VisionFrame) {
        rodDetector.process(frame)
        shakeDetector.process(frame)
        barDetector.process(frame)
        catchDetector.process(frame)
        // block/fish/progress are (re)run in onFrame once the smoothed bar prior exists
    }

    fun setFpsMeasured(fps: Float) { lastFps = fps }

    /** user-initiated stop: never leaves input behind */
    fun disarm(nowNs: Long) {
        armed = false
        stateMachine.armed = false
        holdActive = false
        runCatching { executor.cancelAll() }
        controller.reset()
        log.i(Tags.SYSTEM, "disarm", "[SYSTEM] macro disarmed at $nowNs")
    }
}
