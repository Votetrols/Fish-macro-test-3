package com.fischa.core.safety

import com.fischa.core.config.AppConfig
import com.fischa.core.state.FishingState

/** Why an input request was refused — kept in logs, shown in the overlay. */
enum class DenyReason {
    OK,
    MACRO_DISABLED,
    CAPTURE_STOPPED,
    ROBLOX_NOT_DETECTED,
    STATE_NOT_ACTIONABLE,
    GLOBAL_CONFIDENCE_LOW,
    TRACKING_LOST,
    CONTROLLER_UNSAFE,
    EMERGENCY_STOP,
    RATE_LIMITED,
    COORDINATES_OUT_OF_BOUNDS,
}

data class Verdict(val allowed: Boolean, val reason: DenyReason)

/**
 * Live snapshot of everything that gates input. Updated by the pipeline every frame (and by
 * platform callbacks for foreground state). Deliberately separate from both vision and control
 * (spec §15): *nothing* may bypass it.
 */
class SafetyContext {
    @Volatile var macroEnabled = false
    @Volatile var captureHealthy = false
    @Volatile var robloxForeground = false
    @Volatile var state: FishingState = FishingState.IDLE
    @Volatile var globalConfidence = 0f
    @Volatile var trackingOk = false
    @Volatile var controllerSafe = true
    @Volatile var lastInputNs = 0L
    var minInputGapMs: Long = 45   // global floor against pathological loops
    private var cfgMinConf = 0.30f

    fun apply(cfg: AppConfig.Safety) { cfgMinConf = cfg.minGlobalConfidence }
    fun minConfidence() = cfgMinConf
}

/**
 * The single gate in front of [com.fischa.core.control.InputExecutor]. Pure function of
 * [SafetyContext] + request; no side effects. Emergency latch is checked first, cheapest
 * predicates first, all denials logged upstream.
 */
class InputSafetyGuard(private val cfg: AppConfig.Safety) {

    fun evaluate(
        ctx: SafetyContext,
        nowNs: Long,
        nx: Float, ny: Float,
        emergency: EmergencyStop,
        isHold: Boolean,
    ): Verdict {
        if (emergency.latched) return Verdict(false, DenyReason.EMERGENCY_STOP)
        if (!ctx.macroEnabled) return Verdict(false, DenyReason.MACRO_DISABLED)
        if (!ctx.captureHealthy) return Verdict(false, DenyReason.CAPTURE_STOPPED)
        if (!ctx.robloxForeground) return Verdict(false, DenyReason.ROBLOX_NOT_DETECTED)
        if (!ctx.state.actionable) return Verdict(false, DenyReason.STATE_NOT_ACTIONABLE)
        if (ctx.globalConfidence < cfg.minGlobalConfidence) return Verdict(false, DenyReason.GLOBAL_CONFIDENCE_LOW)
        if (!ctx.trackingOk) return Verdict(false, DenyReason.TRACKING_LOST)
        if (!ctx.controllerSafe) return Verdict(false, DenyReason.CONTROLLER_UNSAFE)
        if (nx < 0f || nx > 1f || ny < 0f || ny > 1f) return Verdict(false, DenyReason.COORDINATES_OUT_OF_BOUNDS)
        if (nowNs - ctx.lastInputNs < ctx.minInputGapMs * 1_000_000L) return Verdict(false, DenyReason.RATE_LIMITED)
        if (isHold) {
            // holds are long-lived; the per-hold watchdog in InputExecutor bounds them.
            return Verdict(true, DenyReason.OK)
        }
        return Verdict(true, DenyReason.OK)
    }
}

/**
 * Latching emergency stop. Activation is asynchronous-safe (called from UI thread); the
 * pipeline checks the latch at every decision point and InputExecutor releases input inside
 * the listener. Once latched, ONLY an explicit [clear] from the user resets it — the macro
 * never un-latches itself.
 */
class EmergencyStop {
    @Volatile var latched = false; private set
    private val listeners = ArrayList<() -> Unit>()

    fun addListener(l: () -> Unit) { synchronized(listeners) { listeners.add(l) } }
    fun removeListener(l: () -> Unit) { synchronized(listeners) { listeners.remove(l) } }

    fun activate(reason: String) {
        if (latched) return
        latched = true
        val copy = synchronized(listeners) { ArrayList(listeners) }
        copy.forEach { runCatching { it() } }
        // reason is logged by the caller (pipeline/UI) with full context
    }

    fun clear() { latched = false }
}
