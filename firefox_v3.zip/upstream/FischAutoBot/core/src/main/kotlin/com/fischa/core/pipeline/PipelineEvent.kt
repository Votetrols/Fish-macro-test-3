package com.fischa.core.pipeline

import com.fischa.core.control.ControlAction
import com.fischa.core.state.FishingState
import com.fischa.core.vision.DetSnapshot

/**
 * Everything the platform layer feeds into the pipeline for one frame, and everything the
 * pipeline hands back. Keeping this flat lets the core run headless in the replay/self-test
 * harness (spec §19 FASE 3: full decision loop without real input).
 */
class PipelineInput(
    var frameTimestampNs: Long = 0L,
    var captureHealthy: Boolean = false,
    var robloxForeground: Boolean = false,
    var macroEnabled: Boolean = false,
    /** system overlay (notification shade, launcher) covering the game — from platform hints */
    var overlaySuspected: Boolean = false,
)

class PipelineOutput {
    // detection snapshots (owned instances — read before next call or copy)
    val fishingButton = DetSnapshot()
    val shake = DetSnapshot()
    val bar = DetSnapshot()
    val player = DetSnapshot()
    val fish = DetSnapshot()
    val progress = DetSnapshot()
    val catchConfirm = DetSnapshot()

    var state: FishingState = FishingState.IDLE
    var stateReason: String = ""

    var fishXNorm = 0f
    var playerXNorm = 0f
    var errorNorm = 0f
    var fishVel = 0f
    var playerVel = 0f
    var desiredVel = 0f
    var progressValue = 0f
    var progressRate = 0f
    var globalConfidence = 0f

    /** the control action the controller *intends*; executed only if safety allows */
    var intendedAction: ControlAction = ControlAction.NONE
    var tapDurationMs = 0
    var holdActive = false
    var decisionReason = ""

    var inputIssued = false
    var inputDeniedReason = ""
    var emergencyLatched = false
    var armed = false
    var shakeSessionTaps = 0
    var shakeSession = 0
    var castPhase = ""

    // pixel-space helpers for the harness/tests (processing coordinates)
    val barRectPx = FloatArray(4)
    var barLocked = false
    var blockCenterPx = -1f
    var fishCenterPx = -1f
}
