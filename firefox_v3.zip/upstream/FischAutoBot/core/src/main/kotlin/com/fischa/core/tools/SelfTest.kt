package com.fischa.core.tools

import com.fischa.core.common.clamp01
import com.fischa.core.config.AppConfig
import com.fischa.core.control.ControlAction
import com.fischa.core.control.FishingController
import com.fischa.core.control.InputExecutor
import com.fischa.core.log.LogSink
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.safety.DenyReason
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.InputSafetyGuard
import com.fischa.core.safety.SafetyContext
import com.fischa.core.state.Evidence
import com.fischa.core.state.FishingState
import com.fischa.core.state.FishingStateMachine
import com.fischa.core.tracking.AlphaBeta
import com.fischa.core.tracking.FishTracker
import com.fischa.core.tracking.PlayerBarTracker
import kotlin.math.abs
import kotlin.random.Random

/**
 * Self-contained logic tests runnable with `kotlinc` + `java` (no JUnit dependency), so the
 * exact shipped code paths are exercised: state machine, safety gate, trackers, controller on
 * a physically faithful minigame simulator (drift/hold dynamics measured from the video).
 */
object SelfTest {

    private var failures = 0
    private var checks = 0

    private fun check(name: String, cond: Boolean, detail: String = "") {
        checks++
        if (!cond) { failures++; println("FAIL  $name  $detail") }
    }

    @JvmStatic
    fun main(args: Array<String>) {
        testAlphaBeta()
        testStateMachineCycle()
        testStateMachineShakePersistence()
        testVisionLostAndRecovery()
        testEmergencyStop()
        testSafetyGuard()
        testControllerOnSimulatedPlant()
        println("== SelfTest: $checks checks, $failures failures ==")
        if (failures > 0) kotlin.system.exitProcess(1)
    }

    private fun testAlphaBeta() {
        val ab = AlphaBeta(alpha = 0.55f, beta = 0.3f, jumpThreshold = 0.22f)
        var t = 0f
        repeat(30) { ab.update(0.5f + 0.01f * it, 1f / 30f); t += 1f / 30f }
        check("ab tracks ramp", abs(ab.vel - 0.30f) < 0.20f, "vel=${ab.vel}")
        // abrupt jump must re-sync within a few frames, not smooth for a second
        ab.update(0.9f, 1f / 30f)
        check("ab resyncs on jump", abs(ab.pos - 0.9f) < 0.06f, "pos=${ab.pos}")
        ab.update(0.9f, 1f / 30f); ab.update(0.9f, 1f / 30f)
        check("ab holds after resync", abs(ab.pos - 0.9f) < 0.08f, "pos=${ab.pos}")
        ab.coast(1f / 30f)
        check("ab coasts forward", ab.pos > 0.88f)
    }

    private fun evidence(block: Evidence.() -> Unit): Evidence = Evidence().apply(block)

    private fun testStateMachineCycle() {
        val cfg = AppConfig()
        val sm = FishingStateMachine(cfg.state)
        sm.armed = true
        var t = 0L
        fun step(e: Evidence) { e.nowNs = t; sm.update(e); t += 33_000_000 }

        step(evidence { fishingButton = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        // one transition per frame by design (stable, no double-jump states): frame 1 arms,
        // frame 2 sees the button and enters CASTING
        step(evidence { fishingButton = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("idle→search→cast", sm.state == FishingState.CASTING, "state=${sm.state}")
        step(evidence { fishingButton = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("casting waits for evidence", sm.state == FishingState.CASTING)
        step(evidence { shake = true; shakeConf = 0.9f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("cast→searching_shake", sm.state == FishingState.SEARCHING_SHAKE, "state=${sm.state}")
        step(evidence { shake = true; shakeConf = 0.95f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("shake→pressing", sm.state == FishingState.PRESSING_SHAKE, "state=${sm.state}")
        // shake keeps appearing at different positions: still pressing, no timeout
        repeat(30) {
            step(evidence { shake = true; shakeConf = 0.9f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        }
        check("long shake session stays", sm.state == FishingState.PRESSING_SHAKE, "state=${sm.state}")
        // minigame appears: bar 3+ frames
        for (i in 0 until 3) step(evidence { bar = true; barConf = 0.8f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("shake→minigame detected", sm.state == FishingState.FISHING_MINIGAME_DETECTED, "state=${sm.state}")
        step(evidence { bar = true; barConf = 0.9f; fishOk = true; playerOk = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("detected→tracking", sm.state == FishingState.TRACKING_FISH, "state=${sm.state}")
        step(evidence { bar = true; barConf = 0.9f; fishOk = true; playerOk = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("tracking→controlling", sm.state == FishingState.CONTROLLING_PLAYER_BAR, "state=${sm.state}")
        // progress high then bar disappears → catch confirmation
        repeat(6) { step(evidence { bar = true; barConf = 0.9f; fishOk = true; playerOk = true; progress = 0.98f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f }) }
        repeat(6) { step(evidence { bar = false; progress = 1.0f; robloxForeground = true; captureHealthy = true; globalConf = 0.5f }) }
        check("controlling→catch confirmation", sm.state == FishingState.CATCH_CONFIRMATION, "state=${sm.state}")
        step(evidence { catchConfirm = true; catchConfirmConf = 0.8f; robloxForeground = true; captureHealthy = true; globalConf = 0.7f })
        check("confirm→reset", sm.state == FishingState.RESET, "state=${sm.state}")
        repeat(30) { step(evidence { robloxForeground = true; captureHealthy = true; globalConf = 0.7f }) }
        check("reset→search", sm.state == FishingState.SEARCH_FISHING_BUTTON, "state=${sm.state}")
    }

    private fun testStateMachineShakePersistence() {
        val sm = FishingStateMachine(AppConfig.StateTiming())
        sm.armed = true
        var t = 0L
        fun step(e: Evidence) { e.nowNs = t; sm.update(e); t += 33_000_000 }
        step(evidence { fishingButton = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        step(evidence { shake = true; shakeConf = 0.9f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        step(evidence { shake = true; shakeConf = 0.9f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("in pressing", sm.state == FishingState.PRESSING_SHAKE)
        // shake blinks out for 1 frame (occlusion) then returns — must NOT bail to searching
        step(evidence { shake = false; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("short blink stays pressing", sm.state == FishingState.PRESSING_SHAKE)
        step(evidence { shake = true; shakeConf = 0.9f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        // many distinct shakes (no fixed count limit!)
        var sessions = 0
        for (s in 0 until 10) {
            repeat(4) { step(evidence { shake = true; shakeConf = 0.9f; robloxForeground = true; captureHealthy = true; globalConf = 0.9f }) }
            repeat(5) { step(evidence { shake = false; shakeGone = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f }) }
            if (sm.state == FishingState.SEARCHING_SHAKE) sessions++
        }
        check("shake sessions unbounded", sessions >= 9, "sessions=$sessions state=${sm.state}")
    }

    private fun testVisionLostAndRecovery() {
        val sm = FishingStateMachine(AppConfig.StateTiming())
        sm.armed = true
        var t = 0L
        fun step(e: Evidence) { e.nowNs = t; sm.update(e); t += 33_000_000 }
        step(evidence { fishingButton = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        // overlay: nothing detectable for > visionLostAfterMs
        repeat(80) { step(evidence { robloxForeground = true; captureHealthy = true; globalConf = 0.1f }) }
        check("vision lost engaged", sm.state == FishingState.VISION_LOST, "state=${sm.state}")
        // evidence returns → recovery via RESET (not straight to casting)
        step(evidence { fishingButton = true; robloxForeground = true; captureHealthy = true; globalConf = 0.9f })
        check("recovery via reset", sm.state == FishingState.RESET, "state=${sm.state}")
        // overlay suspected (notification shade like the reference video tail)
        t += 33_000_000L
        step(evidence { overlaySuspected = true; robloxForeground = true; captureHealthy = true; globalConf = 0.2f })
        repeat(35) { step(evidence { overlaySuspected = true; robloxForeground = false; captureHealthy = true; globalConf = 0.2f }) }
        check("roblox-not-detected on overlay", sm.state == FishingState.ROBLOX_NOT_DETECTED, "state=${sm.state}")
    }

    private class RecordingExecutor : InputExecutor {
        var taps = 0
        var cancelled = 0
        override fun tap(nx: Float, ny: Float, durationMs: Int) { taps++ }
        override fun cancelAll() { cancelled++ }
    }

    private fun testEmergencyStop() {
        val ex = RecordingExecutor()
        val emergency = EmergencyStop()
        var listenerFired = 0
        val l: () -> Unit = { listenerFired++ }
        emergency.addListener(l)
        emergency.activate("test")
        check("listener fired", listenerFired == 1)
        val guard = InputSafetyGuard(AppConfig.Safety())
        val ctx = SafetyContext().apply {
            macroEnabled = true; captureHealthy = true; robloxForeground = true
            state = FishingState.PRESSING_SHAKE; globalConfidence = 0.9f; trackingOk = true
        }
        val v = guard.evaluate(ctx, 1_000_000_000L, 0.5f, 0.5f, emergency, false)
        check("emergency denies input", !v.allowed && v.reason == DenyReason.EMERGENCY_STOP)
        emergency.clear()
        val v2 = guard.evaluate(ctx, 1_000_000_000L, 0.5f, 0.5f, emergency, false)
        check("cleared emergency allows", v2.allowed)
        emergency.removeListener(l)
    }

    private fun testSafetyGuard() {
        val emergency = EmergencyStop()
        val guard = InputSafetyGuard(AppConfig.Safety())
        val now = 10_000_000_000L
        fun ctx(block: SafetyContext.() -> Unit) = SafetyContext().apply {
            macroEnabled = true; captureHealthy = true; robloxForeground = true
            state = FishingState.PRESSING_SHAKE; globalConfidence = 0.9f; trackingOk = true
            block()
        }
        check("allows in good state", guard.evaluate(ctx { }, now, 0.5f, 0.5f, emergency, false).allowed)
        check("denies macro off", guard.evaluate(ctx { macroEnabled = false }, now, 0.5f, 0.5f, emergency, false).reason == DenyReason.MACRO_DISABLED)
        check("denies capture off", guard.evaluate(ctx { captureHealthy = false }, now, 0.5f, 0.5f, emergency, false).reason == DenyReason.CAPTURE_STOPPED)
        check("denies non-roblox", guard.evaluate(ctx { robloxForeground = false }, now, 0.5f, 0.5f, emergency, false).reason == DenyReason.ROBLOX_NOT_DETECTED)
        check("denies idle state", guard.evaluate(ctx { state = FishingState.IDLE }, now, 0.5f, 0.5f, emergency, false).reason == DenyReason.STATE_NOT_ACTIONABLE)
        check("denies low conf", guard.evaluate(ctx { globalConfidence = 0.1f }, now, 0.5f, 0.5f, emergency, false).reason == DenyReason.GLOBAL_CONFIDENCE_LOW)
        check("denies tracking lost", guard.evaluate(ctx { trackingOk = false }, now, 0.5f, 0.5f, emergency, false).reason == DenyReason.TRACKING_LOST)
        check("denies unsafe controller", guard.evaluate(ctx { controllerSafe = false }, now, 0.5f, 0.5f, emergency, false).reason == DenyReason.CONTROLLER_UNSAFE)
        check("denies oob coords", guard.evaluate(ctx { }, now, 1.4f, 0.5f, emergency, false).reason == DenyReason.COORDINATES_OUT_OF_BOUNDS)
        check("denies rate limit", guard.evaluate(ctx { lastInputNs = now - 10_000_000 }, now, 0.5f, 0.5f, emergency, false).reason == DenyReason.RATE_LIMITED)
    }

    /**
     * Full-loop test on a *simulated plant* built from measurements in the reference video
     * (drift −0.3/s, hold +0.6/s net, catch zone = block ± half width): pipeline → trackers →
     * controller → back into plant. Verifies the controller actually tracks (converges and
     * stays), does not chatter excessively, and does not press when aligned.
     */
    private fun testControllerOnSimulatedPlant() {
        val cfg = AppConfig()
        val rng = Random(42)
        val tc = cfg.tracking; val cc = cfg.control
        val fishTracker = FishTracker(tc)
        val blockTracker = PlayerBarTracker(tc)
        val controller = FishingController(cc)

        // fish trajectory: piecewise random walk with direction changes & stops
        var fishX = 0.5f; var fishV = 0f
        var blockX = 0.5f
        var progress = 0f
        var hold = false
        var t = 0L
        val dt = 1f / 30f
        var alignedFrames = 0; var frames = 0
        var pressCount = 0; var idlePresses = 0
        val half = 0.145f // half block width in bar units (measured ~0.29 bar width)
        repeat(30 * 45) { i -> // 45 s of simulated fishing
            t += (dt * 1e9).toLong()
            // fish dynamics: OU-ish with occasional hard reversals
            fishV += rng.nextFloat() * 0.20f - 0.10f
            if (i % 210 == 0) fishV = (rng.nextFloat() * 0.9f - 0.45f) // burst reversal
            fishV = clamp01((fishV + 0.5f) / 1f) - 0.5f // clamp ±0.5/s
            if (rng.nextFloat() < 0.01f) fishV = 0f       // fish stops dead
            fishX = (fishX + fishV * dt).coerceIn(0.05f, 0.95f)

            // block dynamics
            blockX += (if (hold) 0.55f else -0.30f) * dt
            blockX = blockX.coerceIn(half, 1f - half)

            // progress rule: |err| < half → gains; else loses
            val err = fishX - blockX
            progress += (if (abs(err) < half) 0.030f else -0.025f) * dt
            progress = progress.coerceIn(0f, 1f)

            // "vision": noisy measurements (±1.5 px of 640 ≈ 0.0023) + rare miss
            val measFish = if (rng.nextFloat() < 0.06f) null else (fishX + rng.nextFloat() * 0.012f - 0.006f)
            val measBlock = if (rng.nextFloat() < 0.05f) null else (blockX + rng.nextFloat() * 0.012f - 0.006f)
            fishTracker.update(t, measFish, if (measFish == null) 0f else 0.85f, 300f)
            blockTracker.update(t, measBlock, 0.29f, if (measBlock == null) 0f else 0.85f, abs(err) > half,
                0f, 300f, (blockX - half) * 300f, (blockX + half) * 300f)

            val d = controller.update(t, dt, fishTracker.out, blockTracker.out, 0f)
            frames++
            if (abs(err) < half * 0.7f) alignedFrames++
            when (d.action) {
                ControlAction.TAP -> {
                    pressCount++
                    // "unnecessary press" = pressed while the *predicted* error is inside the
                    // deadband (what the controller actually minimizes)
                    if (abs(d.predictedError) < cc.deadband * 0.5f) idlePresses++
                }
                ControlAction.HOLD_START -> { hold = true; pressCount++ }
                ControlAction.HOLD_EXTEND -> {}
                ControlAction.HOLD_RELEASE -> hold = false
                ControlAction.NONE -> {}
            }
        }
        val alignRate = alignedFrames.toFloat() / frames
        check("controller tracks fish (≥85% aligned)", alignRate >= 0.85f, "aligned=${(alignRate * 100).toInt()}% progress=$progress")
        check("progress reaches catch", progress > 0.80f, "progress=$progress")
        check("no idle presses (aligned deadband respected)", idlePresses == 0, "idlePresses=$idlePresses")
        check("reasonable press count", pressCount in 20..frames, "presses=$pressCount/$frames")
    }
}
