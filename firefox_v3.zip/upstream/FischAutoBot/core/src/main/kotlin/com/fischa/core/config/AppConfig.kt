package com.fischa.core.config

/**
 * Single source of truth for every tunable in the system.
 *
 * Rules enforced by this class:
 *  - no absolute screen coordinates anywhere (geometry is expressed as fractions of the
 *    processed frame, i.e. resolution/orientation independent);
 *  - no hardcoded shake counts / minigame durations / fish speeds;
 *  - time constants in seconds, angles/sizes as fractions of frame width/height.
 *
 * Serialized with [toMap]/[fromMap] so the Android Settings UI and the replay harness share
 * one representation.
 */
data class AppConfig(
    val capture: Capture = Capture(),
    val vision: Vision = Vision(),
    val tracking: Tracking = Tracking(),
    val control: Control = Control(),
    val shake: Shake = Shake(),
    val cast: Cast = Cast(),
    val state: StateTiming = StateTiming(),
    val safety: Safety = Safety(),
) {

    data class Capture(
        /** Width the frame is rescaled to before vision processing (keeps aspect). */
        val processingWidth: Int = 640,
        /** Target pipeline rate; capture may run faster, processing is rate-limited. */
        val targetFps: Int = 30,
        /** Ring size of the shared frame buffer (older entries get overwritten). */
        val bufferSlots: Int = 3,
        /** Drop the incoming frame if the consumer is slower than this (backpressure). */
        val maxQueueLatencyMs: Int = 220,
        /** Consider the capture stream dead after this long without a new frame. */
        val streamTimeoutMs: Long = 2500,
    )

    data class Vision(
        // -- fishing (rod) button --
        val rodSearchX0: Float = 0.55f, val rodSearchX1: Float = 1.0f,
        val rodSearchY0: Float = 0.40f, val rodSearchY1: Float = 0.95f,
        val rodRadiusMinF: Float = 0.040f, val rodRadiusMaxF: Float = 0.085f,
        /** Interior of the rod button is dark; ring is brighter than both sides. */
        val rodInteriorMaxGray: Int = 90,
        val rodRingMinDelta: Int = 18,
        val rodPriorCx: Float = 0.818f, val rodPriorCy: Float = 0.692f,
        val rodPriorWeight: Float = 0.25f,

        // -- shake prompt --
        val shakeRadiusMinF: Float = 0.055f, val shakeRadiusMaxF: Float = 0.105f,
        /** Shake text glyphs are white on dark. */
        val shakeGlyphMinGray: Int = 205,
        val shakeInteriorMaxGray: Int = 70,
        val shakeRingMinDelta: Int = 14,
        /** ignore the very top (roblox/system HUD) and bottom hotbar strips */
        val shakeSearchY0: Float = 0.06f, val shakeSearchY1: Float = 0.98f,
        val shakeSearchX0: Float = 0.02f, val shakeSearchX1: Float = 1.0f,

        // -- minigame bar --
        val barSearchY0: Float = 0.55f, val barSearchY1: Float = 0.88f,
        val barMinWidthF: Float = 0.14f, val barMaxWidthF: Float = 0.72f,
        val barMinHeightF: Float = 0.016f, val barMaxHeightF: Float = 0.065f,
        /** interior gray window of the dark bar (measured 18..30; tolerant band for lighting) */
        val barDarkMin: Int = 8, val barDarkMax: Int = 140,
        val barDarkColFrac: Float = 0.42f,
        val barDarkRowFrac: Float = 0.30f,
        val barDarkMaxChroma: Int = 80,
        /** a bar pixel must be darker than the world [bar] rows below it (night water is dark
         *  in absolute terms too — the relative test is what separates them) */
        val barBgBelowOffset: Int = 24,
        val barBgBelowDelta: Int = 18,
        /** non-dark columns tolerated while growing a bar run (fish icon, borders) */
        val barGrowMaxHoles: Int = 6,
        /** red end-cap triangles are strong evidence of bar edges */
        val barEndCapWeight: Float = 0.30f,

        // -- white player block --
        val blockMinWidthF: Float = 0.06f, val blockMaxWidthF: Float = 0.45f,
        val blockWhiteMinGray: Int = 185,
        /** tint when fish outside the block: measured val~64 red hue */
        val mismatchSatMin: Int = 45, val mismatchValMin: Int = 35, val mismatchValMax: Int = 170,

        // -- fish indicator --
        val fishNeedleMinGray: Int = 88, val fishNeedleMaxGray: Int = 215,
        val fishDarkMinGray: Int = 32, val fishDarkMaxGray: Int = 125, // needle inside white block
        val fishNeedleAbovePx: Int = 26, // search height above bar top, at 640w scale
        val fishNeedleMinRunF: Float = 0.10f, // as fraction of bar width for scoring

        // -- progress --
        val progressSearchBelowF: Float = 0.30f,
        val progressMinWidthFracOfBar: Float = 0.35f,
        val progressMaxWidthFracOfBar: Float = 1.15f,
        val progressFillMinGray: Int = 175,
        val progressOutlineMinGray: Int = 118,

        // -- hud presence (roblox alive signal) --
        /** sample strips where the standard Roblox hud sits: top-left menu + right rod area */
        val hudTopStripH: Float = 0.16f,
    )

    data class Tracking(
        val fishAlpha: Float = 0.55f,
        val fishBeta: Float = 0.30f,
        /** innovation (in normalized bar units) beyond which a jump re-syncs hard */
        val fishJumpResyncNorm: Float = 0.22f,
        val fishMaxLostMs: Long = 420,
        val blockAlpha: Float = 0.62f,
        val blockMaxLostMs: Long = 500,
        val barAlpha: Float = 0.35f,
        val barLockMinConf: Float = 0.55f,
        val barUnlockConf: Float = 0.30f,
        val confEmaAlpha: Float = 0.45f,
        val confDecayPerSec: Float = 1.8f,
    )

    data class Control(
        /** normalized deadband on |error| (fraction of bar width). Inside it we do nothing. */
        val deadband: Float = 0.030f,
        val tapBand: Float = 0.075f,          // deadband..tapBand -> short taps
        val holdBand: Float = 0.155f,          // beyond -> sustained hold
        val kP: Float = 4.2f,                  // proportional gain (1/s)
        val kFF: Float = 1.15f,                // fish-velocity feedforward gain
        val kDrift: Float = 0.55f,             // leftward drift compensation added when aligned
        val lookaheadSec: Float = 0.10f,       // prediction horizon for fish position
        val lookaheadVelClamp: Float = 0.55f,  // normalized units/s cap used by lookahead
        val minHoldMs: Int = 90,
        val minReleaseMs: Int = 55,
        val minTapGapMs: Int = 70,             // avoid useless press spam
        val tapDurMs: Int = 120,               // single short tap length
        val maxHoldMs: Int = 2200,             // hold is re-evaluated after this even if error persists
        /**
         * The game's mobile control is "tap & hold anywhere"; on Android without root we
         * emulate a hold as a cadence of overlapping-duration taps (see docs/LIMITATIONS.md).
         */
        val tapHoldPeriodMs: Int = 280,
        val tapHoldDurMs: Int = 240,
        val tapDurScaleByErr: Boolean = true,
        /** when either tracker loses confidence below this, controller freezes (safe hold-off) */
        val minConfidence: Float = 0.34f,
        /** near-edge margins (fraction of bar) where extra caution is applied */
        val edgeMargin: Float = 0.06f,
        /** don't tap when already at the right edge; release-only there */
        val rightEdgeNoHold: Boolean = false,
        /** smooth progress: if progress decreasing for this long, widen hold band */
        val catchUpAfterMs: Long = 900,
        val catchUpBandBonus: Float = 0.10f,
    )

    data class Shake(
        /** frames the shake must persist before we tap (temporal validation) */
        val confirmFrames: Int = 2,
        /** frames without detection before we consider it gone */
        val lostFrames: Int = 3,
        val tapCooldownMs: Long = 130,
        val tapDurMs: Int = 60,
        /** never tap the same center twice without the prompt having moved/vanished */
        val sameSpotGuardMs: Long = 700,
        val sameSpotEpsF: Float = 0.02f,
        val minConfidence: Float = 0.45f,
    )

    data class Cast(
        val holdMs: Long = 3000,        // spec: ~3 s is enough to launch the cast
        val minConfidence: Float = 0.40f,
        val confirmFrames: Int = 2,
        /** after a successful cast press we wait at least this before looking for shakes */
        val postCastSettleMs: Long = 600,
        val pressCooldownMs: Long = 4000,
    )

    data class StateTiming(
        /** min time a stable state must hold before a "vision lost" escalation */
        val visionLostAfterMs: Long = 2500,
        /** min frames of bar presence to enter MINIGAME */
        val minigameEnterFrames: Int = 3,
        /** min frames of bar absence to leave MINIGAME */
        val minigameExitFrames: Int = 5,
        /** how long to keep the progress trend memory after the bar vanished */
        val catchMemoryMs: Long = 1600,
        /** catch confirmation text watch window after minigame exit */
        val confirmWindowMs: Long = 6000,
        /** min progress value that still counts as "was winning" at exit (catch vs escape) */
        val catchMinProgress: Float = 0.30f,
        val resetDwellMs: Long = 900,
        val idleAutoArm: Boolean = true,
    )

    data class Safety(
        val minGlobalConfidence: Float = 0.30f,
        val denyWhenCaptureStale: Boolean = true,
        val denyWhenRobloxMissing: Boolean = true,
        val maxManualHoldMs: Long = 8000,
        val watchdogMs: Long = 1500, // controller heartbeat must refresh this often while active
    )

    // ---- (de)serialization: flat string map, one source of truth for Settings UI & harness ----

    /**
     * Only the tunables that materially change behaviour are exposed as a settings map; the
     * rest stay in code defaults so the Settings UI does not become a wall of numbers.
     */
    fun toMap(): Map<String, String> = buildMap {
        put("capture.processingWidth", capture.processingWidth.toString())
        put("capture.targetFps", capture.targetFps.toString())
        put("capture.bufferSlots", capture.bufferSlots.toString())
        put("capture.maxQueueLatencyMs", capture.maxQueueLatencyMs.toString())
        put("capture.streamTimeoutMs", capture.streamTimeoutMs.toString())
        put("vision.rodPriorCx", vision.rodPriorCx.toString())
        put("vision.rodPriorCy", vision.rodPriorCy.toString())
        put("vision.blockWhiteMinGray", vision.blockWhiteMinGray.toString())
        put("vision.fishNeedleAbovePx", vision.fishNeedleAbovePx.toString())
        put("vision.progressFillMinGray", vision.progressFillMinGray.toString())
        put("tracking.fishAlpha", tracking.fishAlpha.toString())
        put("tracking.fishBeta", tracking.fishBeta.toString())
        put("tracking.fishJumpResyncNorm", tracking.fishJumpResyncNorm.toString())
        put("tracking.fishMaxLostMs", tracking.fishMaxLostMs.toString())
        put("tracking.blockAlpha", tracking.blockAlpha.toString())
        put("control.deadband", control.deadband.toString())
        put("control.tapBand", control.tapBand.toString())
        put("control.holdBand", control.holdBand.toString())
        put("control.kP", control.kP.toString())
        put("control.kFF", control.kFF.toString())
        put("control.kDrift", control.kDrift.toString())
        put("control.lookaheadSec", control.lookaheadSec.toString())
        put("control.minHoldMs", control.minHoldMs.toString())
        put("control.minReleaseMs", control.minReleaseMs.toString())
        put("control.minTapGapMs", control.minTapGapMs.toString())
        put("control.tapDurMs", control.tapDurMs.toString())
        put("control.maxHoldMs", control.maxHoldMs.toString())
        put("control.tapHoldPeriodMs", control.tapHoldPeriodMs.toString())
        put("control.tapHoldDurMs", control.tapHoldDurMs.toString())
        put("control.minConfidence", control.minConfidence.toString())
        put("shake.confirmFrames", shake.confirmFrames.toString())
        put("shake.lostFrames", shake.lostFrames.toString())
        put("shake.tapCooldownMs", shake.tapCooldownMs.toString())
        put("shake.tapDurMs", shake.tapDurMs.toString())
        put("shake.minConfidence", shake.minConfidence.toString())
        put("cast.holdMs", cast.holdMs.toString())
        put("cast.minConfidence", cast.minConfidence.toString())
        put("cast.postCastSettleMs", cast.postCastSettleMs.toString())
        put("cast.pressCooldownMs", cast.pressCooldownMs.toString())
        put("safety.minGlobalConfidence", safety.minGlobalConfidence.toString())
        put("safety.maxManualHoldMs", safety.maxManualHoldMs.toString())
        put("safety.watchdogMs", safety.watchdogMs.toString())
    }

    fun withOverrides(map: Map<String, String>): AppConfig {
        fun s(key: String, cur: String) = map[key] ?: cur
        fun i(key: String, cur: Int) = map[key]?.toIntOrNull() ?: cur
        fun l(key: String, cur: Long) = map[key]?.toLongOrNull() ?: cur
        fun f(key: String, cur: Float) = map[key]?.toFloatOrNull() ?: cur
        return copy(
            capture = capture.copy(
                processingWidth = i("capture.processingWidth", capture.processingWidth),
                targetFps = i("capture.targetFps", capture.targetFps),
                bufferSlots = i("capture.bufferSlots", capture.bufferSlots),
                maxQueueLatencyMs = i("capture.maxQueueLatencyMs", capture.maxQueueLatencyMs),
                streamTimeoutMs = l("capture.streamTimeoutMs", capture.streamTimeoutMs),
            ),
            vision = vision.copy(
                rodPriorCx = f("vision.rodPriorCx", vision.rodPriorCx),
                rodPriorCy = f("vision.rodPriorCy", vision.rodPriorCy),
                rodSearchX0 = f("vision.rodSearchX0", vision.rodSearchX0),
                rodSearchX1 = f("vision.rodSearchX1", vision.rodSearchX1),
                rodSearchY0 = f("vision.rodSearchY0", vision.rodSearchY0),
                rodSearchY1 = f("vision.rodSearchY1", vision.rodSearchY1),
                shakeSearchX0 = f("vision.shakeSearchX0", vision.shakeSearchX0),
                shakeSearchX1 = f("vision.shakeSearchX1", vision.shakeSearchX1),
                shakeSearchY0 = f("vision.shakeSearchY0", vision.shakeSearchY0),
                shakeSearchY1 = f("vision.shakeSearchY1", vision.shakeSearchY1),
                barSearchY0 = f("vision.barSearchY0", vision.barSearchY0),
                barSearchY1 = f("vision.barSearchY1", vision.barSearchY1),
                blockWhiteMinGray = i("vision.blockWhiteMinGray", vision.blockWhiteMinGray),
                fishNeedleAbovePx = i("vision.fishNeedleAbovePx", vision.fishNeedleAbovePx),
                progressFillMinGray = i("vision.progressFillMinGray", vision.progressFillMinGray),
            ),
            tracking = tracking.copy(
                fishAlpha = f("tracking.fishAlpha", tracking.fishAlpha),
                fishBeta = f("tracking.fishBeta", tracking.fishBeta),
                fishJumpResyncNorm = f("tracking.fishJumpResyncNorm", tracking.fishJumpResyncNorm),
                fishMaxLostMs = l("tracking.fishMaxLostMs", tracking.fishMaxLostMs),
                blockAlpha = f("tracking.blockAlpha", tracking.blockAlpha),
            ),
            control = control.copy(
                deadband = f("control.deadband", control.deadband),
                tapBand = f("control.tapBand", control.tapBand),
                holdBand = f("control.holdBand", control.holdBand),
                kP = f("control.kP", control.kP),
                kFF = f("control.kFF", control.kFF),
                kDrift = f("control.kDrift", control.kDrift),
                lookaheadSec = f("control.lookaheadSec", control.lookaheadSec),
                minHoldMs = i("control.minHoldMs", control.minHoldMs),
                minReleaseMs = i("control.minReleaseMs", control.minReleaseMs),
                minTapGapMs = i("control.minTapGapMs", control.minTapGapMs),
                tapDurMs = i("control.tapDurMs", control.tapDurMs),
                maxHoldMs = i("control.maxHoldMs", control.maxHoldMs),
                minConfidence = f("control.minConfidence", control.minConfidence),
            ),
            shake = shake.copy(
                confirmFrames = i("shake.confirmFrames", shake.confirmFrames),
                lostFrames = i("shake.lostFrames", shake.lostFrames),
                tapCooldownMs = l("shake.tapCooldownMs", shake.tapCooldownMs),
                minConfidence = f("shake.minConfidence", shake.minConfidence),
            ),
            cast = cast.copy(
                holdMs = l("cast.holdMs", cast.holdMs),
                minConfidence = f("cast.minConfidence", cast.minConfidence),
                postCastSettleMs = l("cast.postCastSettleMs", cast.postCastSettleMs),
                pressCooldownMs = l("cast.pressCooldownMs", cast.pressCooldownMs),
            ),
            safety = safety.copy(
                minGlobalConfidence = f("safety.minGlobalConfidence", safety.minGlobalConfidence),
                maxManualHoldMs = l("safety.maxManualHoldMs", safety.maxManualHoldMs),
                watchdogMs = l("safety.watchdogMs", safety.watchdogMs),
            ),
        )
    }
}
