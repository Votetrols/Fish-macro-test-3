package com.fischa.core.debug

import com.fischa.core.state.FishingState

/**
 * Immutable snapshot the pipeline publishes for the debug overlay (spec §14). Coordinates are
 * normalized (0..1) so the overlay can render them on any display size/orientation. The
 * pipeline builds one small instance per processed frame (cheap; no pixel data).
 */
class RenderModel(
    val state: FishingState,
    val fps: Float,
    val procMs: Float,
    /** normalized boxes (left, top, right, bottom) */
    val barBox: FloatArray?,
    val blockBox: FloatArray?,
    val fishBox: FloatArray?,
    val shakeBox: FloatArray?,
    val rodBox: FloatArray?,
    val progressBox: FloatArray?,
    val fishCx: Float,
    val playerCx: Float,
    val error: Float,
    val fishVel: Float,
    val playerVel: Float,
    val desiredVel: Float,
    val action: String,
    val actionReason: String,
    val progress: Float,
    val progressRate: Float,
    val confGlobal: Float,
    val confBar: Float,
    val confFish: Float,
    val confPlayer: Float,
    val confShake: Float,
    val confRod: Float,
    val holdActive: Boolean,
    val tapsThisSession: Int,
    val shakeSession: Int,
    val denyReason: String,
    val emergency: Boolean,
    val armed: Boolean,
)
