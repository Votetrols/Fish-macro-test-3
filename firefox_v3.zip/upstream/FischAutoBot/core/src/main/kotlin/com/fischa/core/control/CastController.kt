package com.fischa.core.control

import com.fischa.core.config.AppConfig

/**
 * Cast phase driver (spec §2 BOTÃO DA VARA): press the rod button long enough to launch
 * (~3 s by default — configurable, not magic: measured as "long enough" in the game),
 * then wait for evidence the cast landed (shake prompt or minigame). Never assumes fixed
 * outcomes: if no evidence arrives within [AppConfig.Cast.pressCooldownMs] + settle, the
 * state machine re-queries the button.
 */
class CastController(private val cfg: AppConfig.Cast) {

    enum class Phase { IDLE, WAIT_PRESS, PRESS_SENT, COOLDOWN }

    var phase = Phase.IDLE; private set
    private var pressSentNs = 0L

    fun start() { phase = Phase.WAIT_PRESS }

    fun onShakeOrBarSeen(nowNs: Long) {
        if (phase != Phase.IDLE) { phase = Phase.COOLDOWN; pressSentNs = nowNs }
    }

    /**
     * @param rodConfirmed true when FishingButtonDetector currently reports the button
     * @return normalized press target, or null if nothing to do this frame
     */
    fun tick(rodConfirmed: Boolean, conf: Float, cxNorm: Float, cyNorm: Float, nowNs: Long): PressRequest? {
        when (phase) {
            Phase.WAIT_PRESS -> {
                if (rodConfirmed && conf >= cfg.minConfidence) {
                    phase = Phase.PRESS_SENT
                    pressSentNs = nowNs
                    return PressRequest(cxNorm, cyNorm, cfg.holdMs, "cast press ${cfg.holdMs}ms")
                }
            }
            Phase.PRESS_SENT -> {
                // if after settle+cooldown no shake/bar evidence appeared, state machine
                // returns to SEARCH_FISHING_BUTTON and calls start() again.
                if (nowNs - pressSentNs > (cfg.postCastSettleMs + cfg.pressCooldownMs) * 1_000_000L) phase = Phase.WAIT_PRESS
            }
            Phase.COOLDOWN -> {
                if (nowNs - pressSentNs > cfg.pressCooldownMs * 1_000_000L) phase = Phase.IDLE
            }
            Phase.IDLE -> {}
        }
        return null
    }

    fun reset() { phase = Phase.IDLE }
}

class PressRequest(val nx: Float, val ny: Float, val holdMs: Long, val reason: String)
