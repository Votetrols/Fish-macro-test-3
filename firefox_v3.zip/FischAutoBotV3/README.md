# Fisch AutoBot — macro de pesca para Roblox Fisch (Android, visão computacional)

Implementação completa em Kotlin do ciclo de pesca (captura → visão → rastreamento →
máquina de estados → controle em malha fechada → entrada), guiada por **detecção visual**,
sem coordenadas, tempos, larguras de barra ou resoluções fixas no comportamento.

## Status (importante, ler primeiro)

- ✅ **Core puro-JVM** (`core/`): compila e passa em tudo neste ambiente:
  - `SelfTest`: **38/38 checks** (config, detectores em frames reais, trackers, controlador,
    segurança, máquina de estados, simulação de malha fechada);
  - `ReplayMain` contra o vídeo de referência **Roblox_2026-10-06-13-57-21.mp4**
    (206 frames, 168 do minigame): **REPLAY PASS** — barra `162/168` frames travados,
    bloco do jogador `127/127` matched com erro máx. **7 px** (meta ≤ 12 px), minigame
    iniciado em f_293 (GT 288 ± 25), estado atravessou o ciclo completo
    (CASTING → SHAKE → MINIGAME → CONTROLLING → CATCH → RESET).
- ⚠️ **Módulo Android** (`app/`): escrito para revisão — **não foi compilado nem testado em
  dispositivo** (sem Android SDK/JDK 17 neste ambiente, e a spec §20 proíbe fingir testes
  reais). Está pronto para o fluxo de testes conjunto.
- A análise pixel a pixel do vídeo que fundamentou as decisões de visão está em
  [`docs/VIDEO_ANALYSIS.md`](docs/VIDEO_ANALYSIS.md). Limitações honestas em
  [`docs/LIMITATIONS.md`](docs/LIMITATIONS.md).

## Arquitetura

```
core/  (kotlin-jvm, sem dependências Android)
  config/     AppConfig — todo tunable centralizado; toMap()/withOverrides() flat
  common/     RectF, detecção base, clamp/lerp
  vision/     VisionFrame (buffers reusados, gray lazY), DiscMatcher,
              7 detectores (BotãoVara, Shake, BarraPesca, Bloco/Jogador, Peixe,
              Progresso, Confirmacao) + TemporalDetector (on/off frames + EMA conf)
  tracking/   AlphaBeta, FishTracker (baixa latência), PlayerBarTracker,
              BarTracker (prévia suavizada p/ ROI), ProgressTracker, ConfidenceTracker
  control/    FishingController (P-D + feedforward + termo de deriva; taps curtos /
              hold / soltar), ShakeController, CastController, InputExecutor (interface)
  safety/     InputSafetyGuard (porta única de toda entrada real), EmergencyStop (latch)
  state/      FishingStateMachine (IDLE→SEARCH_FISHING_BUTTON→CASTING→SEARCHING_SHAKE↔
              PRESSING_SHAKE→FISHING_MINIGAME_DETECTED→TRACKING_FISH→CONTROLLING_PLAYER_BAR
              →CATCH_CONFIRMATION→RESET; erros: VISION_LOST, CAPTURE_ERROR,
              ROBLOX_NOT_DETECTED, INVALID_STATE, EMERGENCY_STOP)
  log/        ThrottledLog + Tags ([CAPTURE][DETECTION][TRACKING][CONTROL][STATE][INPUT][ERROR])
  debug/      RenderModel — snapshot p/ overlay
  pipeline/   VisionPipeline — liga tudo: visão→tracking→estados→decisão→gate→executor
  tools/      SelfTest, ReplayMain (harnesses executáveis neste ambiente)
app/  (android, camada fina)
  ScreenCaptureSource  MediaProjection → VisionFrame 640w (buffers reusados)
  GameAccessibilityService  único caminho p/ gestos; strokes com teto de 500 ms e watchdog
  AndroidInputExecutor  implementa InputExecutor do core
  FischEngineService  foreground service, loop de frames, armed/stop/emergência
  DebugOverlay  HUD (FPS, estado, caixas, err/vel/conf/progresso) via TYPE_ACCESSIBILITY_OVERLAY
  MainActivity / SettingsActivity  UI mínima; config por key=value (formato do harness)
```

Decisões de design (por quê):

1. **Core determinístico e portátil** — o mesmo código roda no celular e no replay do vídeo.
   Nada de `android.*` no core; entrada sai só por `InputExecutor`.
2. **Barra de pesca = âncora do bloco branco** (não varredura de "linha escura"): a água à
   noite tem o mesmo cinza da barra; o que a desambigua é o bloco branco/tingido dentro dela
   + o fundo mais claro abaixo. Ver `FishingBarDetector` e `VIDEO_ANALYSIS.md`.
3. **Tudo normalizado pela barra**: `normalizedX = (objX − barLeft)/barWidth`, com a barra
   medida (nunca assumida) por frame e suavizada; suporta varas/larguras diferentes (spec §23).
4. **Bloco do jogador com tamanho fixo medido** (não redimensionado pela vara, spec §11);
   controle P-D + feedforward de velocidade do peixe + termo de tendência de deriva
   (esquerda), com deadband → tap curto, banda média → hold, fora dela → soltar.
5. **`Shake`: enquanto o prompt existir, pode pressionar; sem timeout artificial** (spec §9);
   desaparecimento do prompt → início do minigame (detectado, não cronometrado).
6. **Segurança acima de tudo**: `InputSafetyGuard` decide cada gesto (confiança global,
   foreground, captura saudável, overlay suspeito, rate-limit, watchdog de hold).
   `EmergencyStop` com latch libera tudo e só destrava manualmente.
7. **Overlay/notificação do sistema cobre o jogo** → pipeline pausa via
   `overlaySuspected`/`ROBLOX_NOT_DETECTED` (o vídeo mostra a sombra da notification shade
   em f_0571-0626 — foi o gatilho medido para esse caminho).

## Como rodar

### Harnesses (este ambiente, sem Android)

```bash
export PATH=$PWD/../tools/kotlinc/bin:$PATH   # kotlinc 1.9.24
cd core; find src/main/kotlin -name '*.kt' > /tmp/srcs.txt
kotlinc -nowarn @/tmp/srcs.txt -d ../build/core.jar
java -cp ../build/core.jar:<kotlin-stdlib> com.fischa.core.tools.SelfTest
java -cp ../build/core.jar:<kotlin-stdlib> com.fischa.core.tools.ReplayMain ../testdata/frames
```

`testdata/frames` contém os 206 frames JPEG extraídos do vídeo, `gt.csv`
(geometria do bloco por frame, px do vídeo) e `meta.txt` (janela do minigame).

### Android

1. Gradle 8.7+ / JDK 17 / Android SDK 34: `gradle wrapper --gradle-version 8.7 && ./gradlew :app:assembleDebug`
2. Instalar, abrir o app → **Ativar acessibilidade** ("Fisch AutoBot Input") → **Iniciar**
   (permitir gravação de tela). O Roblox precisa estar em primeiro plano.
3. Overlay de debug e edição de config (`key=value`, mesmas chaves do replay) na tela inicial.

## Segurança de uso

- Uma instância só de Macro; use em conta alt, não na principal (ToS do Roblox pode punir
  automação — risco por sua conta).
- Botão **EMERGÊNCIA** na notificação: cancela gestos pendentes, destrava holds e faz o
  pipeline parar de emitir; para retomar: Start de novo.
- O serviço para tudo se a captura morrer, o Roblox sair do foreground, ou confiança global
  cair abaixo do mínimo por > watchdog.
