# Resultados de verificação (ambiente sem Android)

Comando de build (kotlinc 1.9.24, core puro-JVM, 30+ arquivos em `core/src/main/kotlin`):

```
kotlinc -nowarn @srcs.txt -d build/core.jar   → 0 errors, 0 warnings
```

## SelfTest (unidades + laço fechado simulado)

```
== SelfTest: 38 checks, 0 failures ==
```

Cobre: serialização de config (toMap/withOverrides round-trip), geometric utils, AlphaBeta,
trackers (fish/bar/block/progress/confidence), FishingController (deadband, tap/hold/release,
limites), ShakeController, CastController, InputSafetyGuard (todas as negações + latch de
emergência), transições da máquina de estados (incl. erros), detectores em frames reais,
e simulação de planta da minigame (deriva −0.30/s, tap +0.55/s, ruído ±1.5 px, 5 % de
frames perdidos → alinhado ≥ 85 %, progresso > 0.80, zero toques dentro da deadband).

## ReplayMain (206 frames do vídeo de referência; minigame 288–455)

```
frames=206  time≈5 s (23 ms/frame, single-thread, JVM de teste)
bar:   in-minigame locked=162/168   out-of-window clean=37/38
block: gt-matched=127/127  maxErr=7 px @640w (meta ≤ 12)  fails=0
fish-block frames=129  progress frames=49  shake frames=94  rod frames=201
first/last minigame-locked: 293/456 (GT 288/455; janela de aceite 288±25)
states: {SEARCH_FISHING_BUTTON=3, CASTING=27, SEARCHING_SHAKE=1, PRESSING_SHAKE=8,
         FISHING_MINIGAME_DETECTED=1, TRACKING_FISH=1, CONTROLLING_PLAYER_BAR=160,
         CATCH_CONFIRMATION=4, RESET=1}
REPLAY PASS
```

GT = geometria do bloco extraída por script Python independente (máscara branca/tingida,
banda da barra) salva em `testdata/frames/gt.csv`; linhas corrompidas por oclusão do
sprite do peixe (f≈352–361, larguras 54–64) foram filtradas — nesses frames a medição
manual da máscara (dbg7) confirmou que a predição do detector estava certa e a GT errada.

## Observações do tuning final do FishingBarDetector

- Semente por linha = span do bloco branco/tingido (≥ 0.06·w, gap interno ≤ 12 px para os
  marcadores do próprio bloco — gap ≤ 2 falhava em f_300/320: run cortado 21/35 px).
- Crescimento lateral do material escuro com tolerância a furos; critério `isDarkish`:
  gray ∈ [8..140] + chroma ≤ 80 + `gray(row+24) − gray(row) ≥ 18` (água noturna tem o mesmo
  cinza da barra — o teste relativo abaixo é o que separa).
- Banda vertical = extensão vertical do bloco ± 1 px (a sombra sob a barra é tão escura
  quanto a barra; medir a banda pelo escuro falhava — barH 27 > máx).
- Portões extras que matam falsos positivos: `barSearchY0/Y1 = 0.55/0.88` (a faixa escura no
  rodapé do vídeo estava sendo capturada com y1=0.97), razão escura nas laterais fora da
  extensão do progresso (a barra de progresso fica 7 px abaixo — medir abaixo dela exigia
  amostrar fora do span horizontal do progresso), e o mundo acima da barra mais claro.
- Detecção aceita com raw > 0.50; típico 0.76–0.97 nos frames do minigame.

## Módulo Android

`app/` (7 arquivos Kotlin + manifest + gradle): escrito para revisão; os únicos erros de
parser restantes com o kotlinc puro são atribuíveis à ausência do android.jar (unresolved
references). Não compilar com AGP aqui é uma limitação declarada (spec §20) — ver
`docs/LIMITATIONS.md` para a lista completa do que falta validar em dispositivo.
