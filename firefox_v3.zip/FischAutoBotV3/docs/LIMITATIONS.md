# Limitações e avisos honestos

## O que NÃO foi verificado (por enquanto)

1. **Nada rodou em dispositivo real.** O módulo `app/` foi escrito para revisão; sem Android
   SDK/JDK 17 neste ambiente não foi compilado com o AGP. Toda a lógica de plataforma
   (MediaProjection, `dispatchGesture`, overlay, foreground service) é código novo que
   precisa da FASE 4 (dispositivo) da spec §19.
2. **Roblox/Fisch não foram controlados de verdade.** O laço completo foi validado apenas
   em replay offline do vídeo de referência (decisões simuladas, executor dry-run).
   Nada aqui garante comportamento in-game até os testes conjuntos.

## Comportamentos conhecidos que podem precisar ajuste fino

- **Hold ≠ dedo contínuo.** O Android não expõe API pública para estender/reprogamar um
  gesto já despachado. Longos presses (ex.: segurar o botão da vara ~3 s) são executados como
  *trem de strokes* ≤ 500 ms com ~12 ms de intervalo (release+repress). Em jogos que tratam
  "soltar" como fim do carregamento, isso pode não carregar — é o primeiro item a validar na
  FASE 4; alternativa prevista: `willContinue/continueStroke` (API 26+) no
  `GameAccessibilityService.dispatchSegment` se o teste mostrar problema.
- **Cancelamento de emergência** derruba apenas segments pendentes; o stroke em andamento
  termina sozinho em ≤ 500 ms (por isso o teto existe).
- **`robloxForeground`**: quando o serviço de acessibilidade está desligado, o engine assume
  `true` (para permitir testes só de visão). Com acessibilidade ativa, usa eventos de
  janela. Overlay de terceiros (HUD de FPS, Discord) pode acionar `overlaySuspected` e pausar
  o macro; é conservador por design.
- **Shake sem timeout**: por especificação, enquanto o prompt existe o macro insiste em
  tocar. Se um "SHAKE" fantasma aparecer fora do fluxo (notificação com fonte parecida),
  ele vai ser martelado até sumir — mitigado pela confirmação temporal de 2 frames +
  confiança mínima, mas vale observar nos logs (`[DETECTION] shake`).
- **Resoluções/telas muito diferentes** (21:9, notch, tablet): os recorte de busca do botão
  da vara/shake são proporcionais e o DiscMatcher é multi-escala, mas só o 16:9 do vídeo de
  referência foi medido. Re-calibrar via `vision.*` se necessário.
- **Fase noturna/águas claras**: o detector da barra usa (a) âncora do bloco branco/tingido,
  (b) faixa escura relativa ao fundo abaixo do bloco. Cenários onde a areia embaixo da barra
  também for escura (p. ex. caverna) derrubam (b) — visível como barra piscando no log
  `[DETECTION] bar`. Ajustar `vision.barDarkMin/Max`, `barBgBelowDelta`.
- **Peixe dentro do bloco**: o sprite do peixe encobre o bloco; a detecção usa largura
  esperada + âncora de borda para sobreviver, e o AlphaBeta cobre ≤ 500 ms de oclusão.
  Oclusões longas (> `tracking.blockMaxLostMs`) entram em VISION_LOST da minigame —
  comportamento desejado (não "chutar" o controle sem ver).
- **Catch confirmation** atual detecta o cartão central; não lê o nome do peixe (fora de
  escopo do controle) nem faz nada com o "450 XP" dourado.
- **Rodada de captura com ruído JPEG** (vídeo 1066×480 @ ~2 Mbps): limiares foram calibrados
  com uma margem, mas stream de MediaProjection real tem artefatos diferentes; começar os
  testes com `debug` ligado e olhar `[CAPTURE]/[DETECTION]`.

## Dívida técnica assumida (documentada, não escondida)

- `InputExecutor` só tem `tap` (com duração); um `holdBegin/holdEnd` explícito ficaria mais
  limpo — adiado até a FASE 4 dizer qual primitiva o platform aceita melhor.
- O executor do replay é `DryExecutor` (decisões logadas, sem planta física do jogador);
  o laço fechado com planta sintética está coberto no SelfTest (simulação com deriva,
  tap/hold e ruído), não no replay.
- Config aplicada em runtime exige reinício do motor (SettingsActivity → `applyConfig`).
- `LogRingBuffer` grava arquivo sem rotação; deletar `files/fisch-log.txt` se crescer.
