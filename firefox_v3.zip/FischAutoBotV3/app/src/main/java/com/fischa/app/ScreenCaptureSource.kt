package com.fischa.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.view.WindowManager
import com.fischa.core.capture.FrameBuffer
import com.fischa.core.config.AppConfig
import com.fischa.core.vision.VisionFrame
import kotlin.math.roundToInt

/**
 * MediaProjection capture for the Firefox core. ImageReader.acquireLatestImage() and the
 * bounded [FrameBuffer] both discard obsolete frames; the engine never drains an unbounded
 * queue. Frame pixels are copied into reusable slots before Image.close().
 */
class ScreenCaptureSource(
    context: Context,
    private val projection: MediaProjection,
    private val captureHandler: Handler,
    private val cfg: AppConfig.Capture,
    private val onCaptureFailure: (String) -> Unit = {},
    private val captureWidthMax: Int = 720,
) : AutoCloseable {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val densityDpi = context.resources.displayMetrics.densityDpi
    private val scalePaint = Paint().apply { isFilterBitmap = false; isDither = false }
    private val dstRect = Rect()

    @Volatile var captureHealthy: Boolean = false
        private set
    @Volatile var lastFrameTimestampNs: Long = 0L
        private set
    @Volatile var droppedFrames: Long = 0L
        private set

    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var fullBitmap: Bitmap? = null
    private var scaledBitmap: Bitmap? = null
    private var scaledCanvas: Canvas? = null
    private var frameBuffer: FrameBuffer? = null
    private var rowPixels = IntArray(0)
    private var captureWidth = 0
    private var captureHeight = 0
    private var processWidth = 0
    private var processHeight = 0
    private var startDisplayWidth = 0
    private var startDisplayHeight = 0
    private var startRotation = 0
    private var serial = 0L

    val frameWidth: Int get() = processWidth
    val frameHeight: Int get() = processHeight

    @Suppress("DEPRECATION")
    fun start() {
        val size = android.graphics.Point()
        wm.defaultDisplay.getRealSize(size)
        val screenWidth = size.x.coerceAtLeast(1)
        val screenHeight = size.y.coerceAtLeast(1)
        startDisplayWidth = screenWidth
        startDisplayHeight = screenHeight
        startRotation = displayManager.getDisplay(android.view.Display.DEFAULT_DISPLAY)?.rotation ?: 0

        val scale = minOf(1f, captureWidthMax.toFloat() / screenWidth)
        captureWidth = ((screenWidth * scale).roundToInt()).let { (it - it % 2).coerceAtLeast(2) }
        captureHeight = ((screenHeight * scale).roundToInt()).let { (it - it % 2).coerceAtLeast(2) }
        processWidth = minOf(cfg.processingWidth, captureWidth)
        processHeight = (captureHeight * (processWidth.toFloat() / captureWidth)).roundToInt().coerceAtLeast(16)

        frameBuffer?.close()
        frameBuffer = FrameBuffer(processWidth, processHeight, cfg.bufferSlots.coerceIn(2, 8))
        fullBitmap?.let { runCatching { it.recycle() } }
        fullBitmap = Bitmap.createBitmap(captureWidth, captureHeight, Bitmap.Config.ARGB_8888)
        scaledBitmap?.let { runCatching { it.recycle() } }
        scaledBitmap = Bitmap.createBitmap(processWidth, processHeight, Bitmap.Config.ARGB_8888)
        scaledCanvas = Canvas(scaledBitmap!!)
        rowPixels = IntArray(captureWidth)

        reader?.setOnImageAvailableListener(null, null)
        reader?.close()
        display?.release()
        val imageReader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 2)
        reader = imageReader
        imageReader.setOnImageAvailableListener({ source -> copyLatestImage(source) }, captureHandler)
        display = projection.createVirtualDisplay(
            "fisch-v3-capture",
            captureWidth,
            captureHeight,
            densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.surface,
            null,
            captureHandler,
        )
        captureHealthy = display != null && frameBuffer != null
        if (!captureHealthy) onCaptureFailure("VirtualDisplay/FrameBuffer initialization failed")
    }

    private fun copyLatestImage(source: ImageReader) {
        val image = try { source.acquireLatestImage() } catch (e: Exception) {
            onCaptureFailure("acquireLatestImage: ${e.message}")
            null
        } ?: return
        try {
            val buffer = frameBuffer ?: return
            val frame = buffer.acquireWritable()
            if (frame == null) {
                droppedFrames = buffer.droppedFrames()
                return
            }
            try {
                copyPixels(image, frame)
                frame.resetFor(System.nanoTime(), ++serial)
                frame.fps = cfg.targetFps.toFloat()
                if (!buffer.publish(frame)) {
                    buffer.cancelWrite(frame)
                    return
                }
                lastFrameTimestampNs = frame.timestampNs
                droppedFrames = buffer.droppedFrames()
            } catch (e: Exception) {
                buffer.cancelWrite(frame)
                onCaptureFailure("frame copy: ${e.message}")
            }
        } finally {
            image.close()
        }
    }

    private fun copyPixels(image: Image, frame: VisionFrame) {
        val full = fullBitmap ?: error("capture bitmap unavailable")
        val plane = image.planes.firstOrNull() ?: error("ImageReader returned no planes")
        require(image.width == captureWidth && image.height == captureHeight) {
            "capture dimensions changed ${image.width}x${image.height} != ${captureWidth}x${captureHeight}"
        }
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        require(pixelStride >= 4) { "RGBA plane pixelStride=$pixelStride" }
        val bytes = plane.buffer
        val copyWidth = minOf(image.width, captureWidth)
        val copyHeight = minOf(image.height, captureHeight)
        for (y in 0 until copyHeight) {
            for (x in 0 until copyWidth) {
                // Decode the declared RGBA plane into Android's logical ARGB ints explicitly;
                // raw Bitmap buffer byte order varies by device/ABI and may swap red/blue.
                val offset = y * rowStride + x * pixelStride
                val r = bytes.get(offset).toInt() and 0xFF
                val g = bytes.get(offset + 1).toInt() and 0xFF
                val b = bytes.get(offset + 2).toInt() and 0xFF
                rowPixels[x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            full.setPixels(rowPixels, 0, captureWidth, 0, y, copyWidth, 1)
        }
        val canvas = scaledCanvas ?: error("scaled canvas unavailable")
        dstRect.set(0, 0, processWidth, processHeight)
        canvas.drawBitmap(full, null, dstRect, scalePaint)
        val scaled = scaledBitmap ?: error("scaled bitmap unavailable")
        scaled.getPixels(frame.argb, 0, processWidth, 0, 0, processWidth, processHeight)
    }

    /** Worker takes only the latest frame; older pending frames have already been returned to the pool. */
    fun takeLatest(): VisionFrame? = frameBuffer?.takeLatest()

    fun release(frame: VisionFrame) {
        frameBuffer?.release(frame)
    }

    fun hasPendingFrame(): Boolean = (frameBuffer?.pendingCount() ?: 0) > 0

    @Suppress("DEPRECATION")
    fun displayConfigurationUnchanged(): Boolean {
        val point = android.graphics.Point()
        wm.defaultDisplay.getRealSize(point)
        val rotation = displayManager.getDisplay(android.view.Display.DEFAULT_DISPLAY)?.rotation ?: -1
        return point.x == startDisplayWidth && point.y == startDisplayHeight && rotation == startRotation
    }

    override fun close() {
        captureHealthy = false
        runCatching { reader?.setOnImageAvailableListener(null, null) }
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { frameBuffer?.close() }
        runCatching { fullBitmap?.recycle() }
        runCatching { scaledBitmap?.recycle() }
        display = null
        reader = null
        frameBuffer = null
        fullBitmap = null
        scaledBitmap = null
        scaledCanvas = null
        rowPixels = IntArray(0)
    }
}
