package com.fischa.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.projection.MediaProjectionManager
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.fischa.app.ui.DiagnosticsLog
import com.fischa.core.config.AppConfig
import com.fischa.core.log.LogSink
import com.fischa.core.log.Tags
import com.fischa.core.log.ThrottledLog
import com.fischa.core.pipeline.PipelineInput
import com.fischa.core.pipeline.VisionPipeline
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.RobloxForegroundStatus
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Owns capture, the Firefox core loop, centralized safety signals and Android input lifecycle.
 * Real input is session-scoped and false unless the user explicitly enabled it in the UI.
 */
class FischEngineService : Service() {
    companion object {
        const val ACTION_START = "com.fischa.app.START"
        const val ACTION_STOP = "com.fischa.app.STOP"
        const val ACTION_EMERGENCY = "com.fischa.app.EMERGENCY"
        const val ACTION_CLEAR_EMERGENCY = "com.fischa.app.CLEAR_EMERGENCY"
        const val ACTION_DEBUG_OVERLAY = "com.fischa.app.DEBUG_OVERLAY"
        const val EXTRA_DEBUG_ENABLED = "debugEnabled"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        const val EXTRA_REAL_INPUT = "realInput"
        const val CHANNEL_ID = "fisch-engine"

        @Volatile var status: StatusSnapshot = StatusSnapshot()
        @Volatile private var accessibilityEmergency: ((String) -> Unit)? = null

        fun prefs(c: Context): SharedPreferences =
            c.getSharedPreferences("fisch-config", Context.MODE_PRIVATE)

        fun loadConfig(c: Context): AppConfig {
            val map = HashMap<String, String>()
            val all = prefs(c).all
            for (key in all.keys) map[key] = all[key].toString()
            return AppConfig().withOverrides(map)
        }

        fun triggerEmergencyFromAccessibility(reason: String) {
            runCatching { accessibilityEmergency?.invoke(reason) }
        }
    }

    data class StatusSnapshot(
        val running: Boolean = false,
        val state: String = "IDLE",
        val fps: Float = 0f,
        val procMs: Float = 0f,
        val barLocked: Boolean = false,
        val globalConf: Float = 0f,
        val denyReason: String = "",
        val emergency: Boolean = false,
        val lastLogLine: String = "",
        val foregroundPackage: String = RobloxForegroundStatus.UNKNOWN,
        val foregroundActivityWindow: String = RobloxForegroundStatus.UNKNOWN,
        val robloxDetected: Boolean = false,
        val inputAuthorized: Boolean = false,
        val foregroundBlockReason: String = "FOREGROUND_UNKNOWN",
        val foregroundTimestampMs: Long = 0L,
        val frameAgeMs: Long = Long.MAX_VALUE,
        val message: String = "Parado",
        val realInputEnabled: Boolean = false,
        val droppedFrames: Long = 0L,
    )

    inner class LocalBinder : Binder() {
        val service: FischEngineService get() = this@FischEngineService
    }

    private val binder = LocalBinder()
    private val main = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)

    private var projectionManager: MediaProjectionManager? = null
    private var capture: ScreenCaptureSource? = null
    private var captureThread: HandlerThread? = null
    private var loopThread: Thread? = null
    private val logSink = LogRingBuffer()
    private lateinit var log: ThrottledLog
    private lateinit var cfg: AppConfig
    private lateinit var executor: AndroidInputExecutor
    private lateinit var emergency: EmergencyStop
    private lateinit var pipeline: VisionPipeline
    private var realInputForSession = false

    override fun onCreate() {
        super.onCreate()
        cfg = loadConfig(this)
        logSink.file = File(filesDir, "fisch-log.txt")
        log = ThrottledLog(logSink)
        DiagnosticsLog.bind { category, message ->
            log.raw(LogSink.Level.INFO, category, "[$category] $message")
        }
        executor = AndroidInputExecutor()
        emergency = EmergencyStop(prefs(this).getBoolean("emergency_latched", false))
        emergency.addListener {
            prefs(this).edit().putBoolean("emergency_latched", true).apply()
            runCatching { executor.cancelAll() }
            runCatching { executor.releaseAll() }
        }
        pipeline = buildPipeline(cfg, emergency)
        accessibilityEmergency = { reason ->
            emergency.activate(reason)
            pipeline.disarm(System.nanoTime())
            main.post { stopEngine(emergencyStop = true) }
        }
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        createChannel()
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForegroundWithNotification()
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                realInputForSession = intent.getBooleanExtra(EXTRA_REAL_INPUT, false)
                if (data != null) startEngine(resultCode, data) else stopSelf()
            }
            ACTION_EMERGENCY -> {
                emergency.activate("notification action")
                pipeline.disarm(System.nanoTime())
                stopEngine(emergencyStop = true)
            }
            ACTION_STOP -> stopEngine(emergencyStop = false)
            ACTION_CLEAR_EMERGENCY -> clearEmergency()
            ACTION_DEBUG_OVERLAY -> setDebugOverlay(intent.getBooleanExtra(EXTRA_DEBUG_ENABLED, false))
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        stopEngine(emergencyStop = false)
        runCatching { pipeline.close() }
        accessibilityEmergency = null
        DiagnosticsLog.bind(null)
        logSink.flushAndClose()
        super.onDestroy()
    }

    private fun buildPipeline(config: AppConfig, stop: EmergencyStop) = VisionPipeline(
        cfg = config,
        executor = executor,
        log = log,
        emergency = stop,
        foregroundStatusProvider = { GameAccessibilityService.latestForegroundStatus() },
    )

    private fun startEngine(resultCode: Int, data: Intent) {
        if (emergency.latched) {
            status = status.copy(
                running = false,
                emergency = true,
                message = "Parada de emergência travada; desarme explicitamente antes de iniciar",
            )
            stopSelf()
            return
        }
        if (running.getAndSet(true)) return
        cfg = loadConfig(this)
        runCatching { pipeline.close() }
        pipeline = buildPipeline(cfg, emergency)
        val projection = projectionManager?.getMediaProjection(resultCode, data)
        if (projection == null) {
            running.set(false)
            status = status.copy(running = false, message = "MediaProjection indisponível")
            stopSelf()
            return
        }

        projection.registerCallback(object : android.media.projection.MediaProjection.Callback() {
            override fun onStop() {
                log.e(Tags.ERROR, "capture", "[CAPTURE] projection stopped by system")
                emergency.activate("MediaProjection stopped")
                running.set(false)
                shutdownCapture()
                status = status.copy(running = false, emergency = true, inputAuthorized = false)
            }
        }, main)

        val captureWorker = HandlerThread("FischCapture").apply { start() }
        captureThread = captureWorker
        val src = ScreenCaptureSource(
            context = this,
            projection = projection,
            captureHandler = Handler(captureWorker.looper),
            cfg = cfg.capture,
            onCaptureFailure = { message ->
                log.e(Tags.ERROR, "capture", "[CAPTURE] $message")
                emergency.activate("capture failure")
                running.set(false)
            },
        )
        capture = src
        try {
            src.start()
        } catch (e: Exception) {
            log.e(Tags.ERROR, "capture", "[CAPTURE] start failed: ${e.message}")
            emergency.activate("capture start failed")
            running.set(false)
            shutdownCapture()
            stopSelf()
            return
        }
        pipeline.armed = true
        setDebugOverlay(getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).getBoolean("overlay", false))
        status = StatusSnapshot(
            running = true,
            emergency = emergency.latched,
            realInputEnabled = realInputForSession,
            foregroundPackage = RobloxForegroundStatus.UNKNOWN,
            foregroundActivityWindow = RobloxForegroundStatus.UNKNOWN,
            foregroundBlockReason = "WAITING_FOR_ROBLOX_WINDOW",
        )

        val thread = Thread { loop(src) }.apply {
            name = "fisch-engine"
            priority = Thread.NORM_PRIORITY + 2
        }
        loopThread = thread
        thread.start()
    }

    private fun loop(src: ScreenCaptureSource) {
        var prevFrameNs = 0L
        var fpsEma = 0f
        var lastDisplayCheckNs = 0L
        var lastSafetyLogNs = 0L
        var lastNoFrameLogNs = 0L
        while (running.get()) {
            val nowNs = System.nanoTime()
            if (nowNs - lastDisplayCheckNs >= 250_000_000L) {
                lastDisplayCheckNs = nowNs
                if (!src.displayConfigurationUnchanged()) {
                    log.w(Tags.CAPTURE, "display", "[CAPTURE] orientation/size changed; stopping session")
                    emergency.activate("display configuration changed")
                    pipeline.disarm(nowNs)
                    running.set(false)
                    break
                }
            }

            val frame = try { src.takeLatest() } catch (e: Exception) {
                log.e(Tags.ERROR, "capture", "[CAPTURE] takeLatest failed: ${e.message}")
                null
            }
            if (frame == null) {
                if (lastNoFrameLogNs == 0L || nowNs - lastNoFrameLogNs >= 1_000_000_000L) {
                    lastNoFrameLogNs = nowNs
                    log.d(Tags.CAPTURE, "waiting", "[CAPTURE] waiting for latest frame; dropped=${src.droppedFrames}")
                }
                val last = src.lastFrameTimestampNs
                if (last > 0L && nowNs - last > cfg.capture.streamTimeoutMs * 1_000_000L) {
                    log.e(Tags.ERROR, "capture", "[CAPTURE] frame stream timed out; releasing input")
                    emergency.activate("capture stream timeout")
                    pipeline.disarm(nowNs)
                    running.set(false)
                    break
                }
                try { Thread.sleep(5) } catch (_: InterruptedException) { break }
                continue
            }

            try {
                val timestampNs = frame.timestampNs
                val ageAtStartMs = ((System.nanoTime() - timestampNs).coerceAtLeast(0L)) / 1_000_000L
                if (prevFrameNs > 0L) {
                    val delta = (timestampNs - prevFrameNs).coerceAtLeast(1L)
                    val inst = 1_000_000_000f / delta
                    fpsEma = if (fpsEma == 0f) inst else fpsEma * 0.90f + inst * 0.10f
                }
                prevFrameNs = timestampNs
                frame.fps = fpsEma
                pipeline.setFpsMeasured(fpsEma)
                log.setNow(timestampNs)

                val foreground = GameAccessibilityService.latestForegroundStatus()
                val input = PipelineInput(
                    frameTimestampNs = timestampNs,
                    currentTimeNs = System.nanoTime(),
                    captureHealthy = src.captureHealthy,
                    robloxDetected = foreground.robloxDetected,
                    inputAuthorized = foreground.inputAuthorized,
                    overlaySuspected = foreground.overlayActive,
                    macroEnabled = pipeline.armed,
                    realInputEnabled = realInputForSession,
                    foregroundPackage = foreground.foregroundPackage,
                    foregroundActivityWindow = foreground.foregroundActivityWindow,
                    foregroundBlockReason = foreground.blockReason,
                    foregroundTimestampMs = foreground.timestampMs,
                )
                try {
                    pipeline.onFrame(frame, input)
                } catch (e: Exception) {
                    log.e(Tags.ERROR, "pipeline", "[ERROR] pipeline step threw: ${e.message}")
                    emergency.activate("pipeline exception")
                    running.set(false)
                }

                val out = pipeline.output
                status = StatusSnapshot(
                    running = running.get(),
                    state = out.state.name,
                    fps = fpsEma,
                    procMs = pipeline.render?.procMs ?: 0f,
                    barLocked = out.barLocked,
                    globalConf = out.globalConfidence,
                    denyReason = out.inputDeniedReason.ifEmpty {
                        pipeline.render?.safetyBlockedReason.orEmpty()
                    },
                    emergency = emergency.latched,
                    lastLogLine = logSink.snapshot().substringAfterLast('\n'),
                    foregroundPackage = out.foregroundPackage,
                    foregroundActivityWindow = out.foregroundActivityWindow,
                    robloxDetected = out.robloxDetected,
                    inputAuthorized = out.inputAuthorized,
                    foregroundBlockReason = out.foregroundBlockReason,
                    foregroundTimestampMs = input.foregroundTimestampMs,
                    frameAgeMs = out.frameAgeMs,
                    realInputEnabled = out.realInputEnabled,
                    droppedFrames = src.droppedFrames,
                )
                if (timestampNs - lastSafetyLogNs >= 1_000_000_000L || lastSafetyLogNs == 0L) {
                    lastSafetyLogNs = timestampNs
                    log.i(
                        Tags.SAFETY,
                        "foreground",
                        "[SAFETY] foregroundPackage=${foreground.foregroundPackage} foregroundActivity/window=${foreground.foregroundActivityWindow} robloxDetected=${foreground.robloxDetected} inputAuthorized=${foreground.inputAuthorized} blockReason=${foreground.blockReason} timestamp=${foreground.timestampMs}",
                    )
                }
                GameAccessibilityService.instance?.updateDebugOverlay(pipeline.render)
                val targetMs = if (fpsEma > 5f) (1000f / fpsEma).toLong() else 33L
                val spentMs = ((System.nanoTime() - timestampNs) / 1_000_000L).coerceAtLeast(0L)
                val sleepMs = targetMs - spentMs
                if (sleepMs in 1..30) Thread.sleep(sleepMs)
            } catch (e: Exception) {
                log.e(Tags.ERROR, "engine", "[ERROR] frame loop failed: ${e.message}")
                emergency.activate("engine loop exception")
                running.set(false)
            } finally {
                src.release(frame)
            }
        }
        shutdownCapture()
        status = status.copy(running = false, inputAuthorized = false, emergency = emergency.latched)
        main.post {
            runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
            if (emergency.latched) stopSelf()
        }
    }

    private fun shutdownCapture() {
        runCatching { capture?.close() }
        capture = null
        runCatching { captureThread?.quitSafely() }
        captureThread = null
    }

    private fun stopEngine(emergencyStop: Boolean) {
        val wasRunning = running.getAndSet(false)
        pipeline.disarm(System.nanoTime())
        runCatching { executor.cancelAll() }
        runCatching { executor.releaseAll() }
        val thread = loopThread
        loopThread = null
        if (thread != null && thread !== Thread.currentThread()) runCatching { thread.join(1000) }
        shutdownCapture()
        GameAccessibilityService.instance?.setDebugOverlay(false)
        status = status.copy(
            running = false,
            inputAuthorized = false,
            realInputEnabled = false,
            emergency = emergency.latched || emergencyStop,
            state = if (emergencyStop) "EMERGENCY_STOP" else status.state,
        )
        if (emergencyStop && !emergency.latched) emergency.activate("stop")
        if (wasRunning || !status.running) runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        if (wasRunning || emergencyStop) stopSelf()
    }

    fun setDebugOverlay(enabled: Boolean) {
        // TYPE_ACCESSIBILITY_OVERLAY must be attached by the owning AccessibilityService.
        GameAccessibilityService.instance?.setDebugOverlay(enabled)
    }

    /** Explicit operator action only; clearing the latch does not re-arm the macro. */
    fun clearEmergency() {
        emergency.clear()
        prefs(this).edit().putBoolean("emergency_latched", false).apply()
        pipeline.disarm(System.nanoTime())
        status = status.copy(emergency = false, running = false, inputAuthorized = false, realInputEnabled = false)
    }

    fun applyConfig(newCfg: AppConfig) {
        cfg = newCfg
        if (running.get()) main.post { stopEngine(emergencyStop = false) }
    }

    private fun startForegroundWithNotification() {
        createChannel()
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, FischEngineService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stopNow = PendingIntent.getService(
            this, 2, Intent(this, FischEngineService::class.java).setAction(ACTION_EMERGENCY),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Fisch AutoBot V3 ativo")
            .setContentText("Captura local; input real somente após opt-in explícito")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Parar", stopIntent)
            .addAction(android.R.drawable.ic_delete, "EMERGÊNCIA", stopNow)
            .build()
        ServiceCompat.startForeground(
            this,
            42,
            notification,
            if (Build.VERSION.SDK_INT >= 34)
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            else 0,
        )
    }

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.notification_channel), NotificationManager.IMPORTANCE_LOW),
            )
        }
    }
}
