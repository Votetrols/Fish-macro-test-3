package com.fischa.app

import android.os.Handler
import android.os.Looper
import com.fischa.core.control.InputExecutor

/** Normalized-coordinate adapter; conversion to display pixels occurs only in GestureService. */
class AndroidInputExecutor : InputExecutor {
    private val main = Handler(Looper.getMainLooper())

    override fun tap(nx: Float, ny: Float, durationMs: Int) {
        // Deliberately no unauthenticated legacy path. Core must use the authorize-carrying overload.
    }

    override fun tap(nx: Float, ny: Float, durationMs: Int, authorize: () -> Boolean): Boolean =
        dispatch { it.gestures.tap(nx, ny, durationMs, authorize) }

    override fun holdStart(nx: Float, ny: Float, leaseMs: Int, authorize: () -> Boolean): Boolean =
        dispatch { it.gestures.holdStart(nx, ny, leaseMs, authorize) }

    override fun holdExtend(nx: Float, ny: Float, leaseMs: Int, authorize: () -> Boolean): Boolean =
        dispatch { it.gestures.holdExtend(nx, ny, leaseMs, authorize) }

    override fun holdRelease() {
        dispatch { it.gestures.holdRelease(); true }
    }

    override fun cancelAll() {
        dispatch { it.gestures.cancelAll(); true }
    }

    override fun releaseAll() = holdRelease()

    override fun activeGestureCount(): Int = GameAccessibilityService.instance?.gestures?.activeGestureCount ?: 0

    private fun dispatch(block: (GameAccessibilityService) -> Boolean): Boolean {
        val service = GameAccessibilityService.instance ?: return false
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return runCatching { block(service) }.getOrDefault(false)
        }
        val posted = main.post {
            runCatching { block(service) }
        }
        return posted
    }
}
