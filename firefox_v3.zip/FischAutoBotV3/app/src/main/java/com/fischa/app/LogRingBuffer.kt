package com.fischa.app

import android.util.Log
import com.fischa.core.log.LogSink
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter

/**
 * LogSink for Android: logcat + bounded in-memory ring (for the in-app viewer) + append-only
 * file (shareable). Written from the engine thread only; UI reads a copy.
 */
class LogRingBuffer : LogSink {

    companion object {
        private const val TAG = "FischAuto"
        const val MAX_LINES = 600
    }

    private val ring = ArrayDeque<String>(MAX_LINES)
    private var writer: BufferedWriter? = null

    /** set after construction (or to null to stop file logging) */
    var file: File? = null
        set(v) {
            field = v
            runCatching { writer?.flush(); writer?.close() }
            writer = v?.let { BufferedWriter(FileWriter(it, true)) }
        }

    override fun log(level: LogSink.Level, tag: String, msg: String, timestampNs: Long) {
        val line = "[${level.name[0]}][$tag] $msg"
        synchronized(ring) {
            ring.addLast(line)
            while (ring.size > MAX_LINES) ring.removeFirst()
        }
        when (level) {
            LogSink.Level.DEBUG -> Log.d(TAG, line)
            LogSink.Level.INFO -> Log.i(TAG, line)
            LogSink.Level.WARN -> Log.w(TAG, line)
            LogSink.Level.ERROR -> Log.e(TAG, line)
        }
        runCatching { writer?.write(line); writer?.newLine() }
    }

    fun snapshot(): String = synchronized(ring) { ring.joinToString("\n") }

    fun flushAndClose() {
        runCatching { writer?.flush(); writer?.close(); writer = null }
    }
}
