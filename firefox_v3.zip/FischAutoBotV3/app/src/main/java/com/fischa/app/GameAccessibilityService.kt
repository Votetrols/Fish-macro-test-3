package com.fischa.app

import android.accessibilityservice.AccessibilityService
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import com.fischa.app.input.GestureService
import com.fischa.app.ui.DiagnosticsLog
import com.fischa.core.debug.RenderModel
import com.fischa.core.safety.ForegroundObservation
import com.fischa.core.safety.RobloxForegroundDetector
import com.fischa.core.safety.RobloxForegroundStatus

/**
 * The sole Android foreground/window observer and the only AccessibilityService used for input.
 * Package, active-root and accessibility-window evidence are merged by one core detector; a
 * missing service/root/package always resolves to BLOCKED, never to a permissive default.
 */
class GameAccessibilityService : AccessibilityService() {
    companion object {
        const val ROBLOX_PACKAGE = RobloxForegroundDetector.ROBLOX_PACKAGE
        private const val OWN_OVERLAY_CLASS_MARKER = "DebugOverlay"

        @Volatile var instance: GameAccessibilityService? = null
            private set

        @Volatile private var lastSnapshot: RobloxForegroundStatus =
            RobloxForegroundStatus.unknown(SystemClock.elapsedRealtime(), "ACCESSIBILITY_UNAVAILABLE")

        fun latestForegroundStatus(): RobloxForegroundStatus =
            instance?.cachedForegroundStatus() ?: RobloxForegroundStatus.unknown(
                SystemClock.elapsedRealtime(),
                "ACCESSIBILITY_UNAVAILABLE",
            )
    }

    private val foregroundDetector = RobloxForegroundDetector()
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private var debugOverlay: DebugOverlay? = null
    @Volatile private var pendingDebugModel: RenderModel? = null
    private val renderDebugOverlay = Runnable {
        debugOverlay?.let { overlay ->
            overlay.setModel(pendingDebugModel)
            overlay.invalidate()
        }
    }
    @Volatile private var lastWindowEventPackage: String? = null
    @Volatile private var lastWindowEventTimestampMs: Long? = null
    @Volatile private var lastEventActivity: String? = null
    @Volatile private var foregroundStatus: RobloxForegroundStatus = lastSnapshot
    @Volatile private var lastDiagnosticKey: String = ""

    lateinit var gestures: GestureService
        private set

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        gestures = GestureService(this, FischEngineService.loadConfig(this))
        refreshForegroundStatus()
        if (getSharedPreferences("fisch-ui", MODE_PRIVATE).getBoolean("overlay", false)) setDebugOverlay(true)
        DiagnosticsLog.event("SAFETY", "Accessibility service connected; ${formatStatus(foregroundStatus)}")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event != null && (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED)
        ) {
            val pkg = event.packageName?.toString()?.trim().orEmpty()
            val activity = event.className?.toString()?.trim().orEmpty()
            // Our non-touchable debug accessibility overlay is not the game foreground. Do not
            // replace the last actual application/window event with our own overlay event.
            val ownOverlayEvent = pkg == packageName && activity.contains(OWN_OVERLAY_CLASS_MARKER)
            if (pkg.isNotEmpty() && !ownOverlayEvent) {
                lastWindowEventPackage = pkg
                lastWindowEventTimestampMs = SystemClock.elapsedRealtime()
                lastEventActivity = activity.ifBlank { null }
            }
        }
        val status = refreshForegroundStatus()
        if (!status.inputAuthorized && ::gestures.isInitialized) gestures.cancelAll()
    }

    override fun onInterrupt() {
        DiagnosticsLog.event("SAFETY", "Accessibility interrupted; input blocked")
        if (::gestures.isInitialized) gestures.cancelAll()
        FischEngineService.triggerEmergencyFromAccessibility("accessibility interrupted")
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (::gestures.isInitialized) gestures.cancelAll()
        setDebugOverlay(false)
        FischEngineService.triggerEmergencyFromAccessibility("accessibility unbound")
        instance = null
        lastSnapshot = RobloxForegroundStatus.unknown(
            SystemClock.elapsedRealtime(),
            "ACCESSIBILITY_UNAVAILABLE",
        )
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (::gestures.isInitialized) gestures.cancelAll()
        setDebugOverlay(false)
        FischEngineService.triggerEmergencyFromAccessibility("accessibility service destroyed")
        instance = null
        lastSnapshot = RobloxForegroundStatus.unknown(
            SystemClock.elapsedRealtime(),
            "ACCESSIBILITY_UNAVAILABLE",
        )
        super.onDestroy()
    }

    /** Called on the main looper immediately before every hold segment / dispatch. */
    fun refreshForegroundStatus(): RobloxForegroundStatus {
        if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
            return foregroundStatus
        }
        val nowMs = SystemClock.elapsedRealtime()
        var activeAppPackage: String? = null
        var rootPackage: String? = null
        var activity = lastEventActivity
        var activeWindow = "<unknown>"
        var overlayActive = false

        try {
            val allWindows = windows
            var activeAppFound = false
            for (window in allWindows) {
                val windowType = window.type
                val root = try { window.root } catch (_: Exception) { null }
                val rootPkg = root?.packageName?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                val rootClass = root?.className?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                val description = "type=$windowType active=${window.isActive} id=${window.id}" +
                    (rootClass?.let { " class=$it" } ?: "")
                if (window.isActive) activeWindow = description

                if (windowType == AccessibilityWindowInfo.TYPE_APPLICATION && rootPkg != null) {
                    if (!activeAppFound || window.isActive) {
                        activeAppPackage = rootPkg
                        if (window.isActive) {
                            activeAppFound = true
                            rootPackage = rootPkg
                            activity = rootClass ?: activity
                        }
                    }
                } else if (isBlockingWindow(window, rootPkg)) {
                    overlayActive = true
                }
                try { root?.recycle() } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            DiagnosticsLog.event("SAFETY", "Accessibility windows query unavailable: ${e.javaClass.simpleName}")
        }

        // Some full-screen Unity surfaces expose no accessibility windows/root. In that case
        // the most recent window-state package event is used as a fallback, not an allow default.
        try {
            val root = rootInActiveWindow
            if (root != null) {
                val pkg = root.packageName?.toString()?.trim().orEmpty()
                val cls = root.className?.toString()?.trim().orEmpty()
                val ownOverlayRoot = pkg == packageName && cls.contains(OWN_OVERLAY_CLASS_MARKER)
                if (pkg.isNotEmpty() && !ownOverlayRoot) rootPackage = pkg
                if (cls.isNotEmpty() && !ownOverlayRoot) activity = cls
                try { root.recycle() } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            // Root access is optional; the active window event remains a valid second source.
        }

        val interactive = try {
            (getSystemService(POWER_SERVICE) as? PowerManager)?.isInteractive ?: false
        } catch (_: Exception) { false }
        val observation = ForegroundObservation(
            activeAppWindowPackage = activeAppPackage,
            rootInActiveWindowPackage = rootPackage,
            lastWindowEventPackage = lastWindowEventPackage,
            foregroundActivity = activity,
            activeWindow = activeWindow,
            incompatibleOverlay = overlayActive,
            accessibilityAvailable = instance === this,
            screenInteractive = interactive,
            timestampMs = nowMs,
            lastWindowEventTimestampMs = lastWindowEventTimestampMs,
        )
        val next = foregroundDetector.evaluate(observation)
        foregroundStatus = next
        lastSnapshot = next
        val diagnosticKey = listOf(
            next.foregroundPackage,
            next.foregroundActivityWindow,
            next.robloxDetected,
            next.inputAuthorized,
            next.blockReason,
            next.overlayActive,
        ).joinToString("|")
        if (diagnosticKey != lastDiagnosticKey) {
            lastDiagnosticKey = diagnosticKey
            DiagnosticsLog.event("SAFETY", formatStatus(next))
        }
        return next
    }

    fun cachedForegroundStatus(): RobloxForegroundStatus = foregroundStatus

    fun setDebugOverlay(enabled: Boolean) {
        if (android.os.Looper.myLooper() != android.os.Looper.getMainLooper()) {
            main.post { setDebugOverlay(enabled) }
            return
        }
        if (enabled) {
            if (debugOverlay == null) {
                runCatching { DebugOverlay(this).also { it.enable(); debugOverlay = it } }
                    .onFailure { DiagnosticsLog.event("DEBUG", "Overlay unavailable: ${it.javaClass.simpleName}") }
            }
        } else {
            debugOverlay?.disable()
            debugOverlay = null
        }
    }

    fun updateDebugOverlay(model: RenderModel?) {
        pendingDebugModel = model
        main.removeCallbacks(renderDebugOverlay)
        main.post(renderDebugOverlay)
    }

    fun overlaySuspected(): Boolean = foregroundStatus.overlayActive

    private fun isBlockingWindow(window: AccessibilityWindowInfo, rootPackage: String?): Boolean {
        if (!window.isActive) return false
        return when (window.type) {
            AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY ->
                rootPackage != null && rootPackage != packageName
            AccessibilityWindowInfo.TYPE_SYSTEM,
            AccessibilityWindowInfo.TYPE_INPUT_METHOD -> true
            AccessibilityWindowInfo.TYPE_SPLIT_SCREEN_DIVIDER -> true
            else -> false
        }
    }

    private fun formatStatus(status: RobloxForegroundStatus): String =
        "foregroundPackage=${status.foregroundPackage} foregroundActivity/window=${status.foregroundActivityWindow} " +
            "robloxDetected=${status.robloxDetected} inputAuthorized=${status.inputAuthorized} " +
            "blockReason=${status.blockReason} timestamp=${status.timestampMs}"
}
