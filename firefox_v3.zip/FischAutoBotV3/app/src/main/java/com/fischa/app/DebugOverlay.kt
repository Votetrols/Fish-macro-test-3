package com.fischa.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.fischa.core.debug.RenderModel

/** Optional non-touchable, read-only overlay with detector boxes and safety diagnostics. */
class DebugOverlay(private val context: Context) {
    private val windowManager = context.getSystemService(WindowManager::class.java)
        ?: context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var model: RenderModel? = null

    private val view = object : View(context) {
        override fun onDraw(canvas: Canvas) {
            model?.let { drawModel(canvas, it, width.toFloat(), height.toFloat()) }
        }
    }
    private val boxPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = false }
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 24f
        isAntiAlias = false
        setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }
    private val smallTextPaint = Paint(textPaint).apply { textSize = 19f; color = Color.LTGRAY }
    private val fillPaint = Paint().apply { style = Paint.Style.FILL }
    private var params: WindowManager.LayoutParams? = null

    fun enable() {
        if (params != null) return
        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START }
        windowManager.addView(view, layoutParams)
        params = layoutParams
    }

    fun disable() {
        params?.let { runCatching { windowManager.removeViewImmediate(view) } }
        params = null
    }

    fun setModel(snapshot: RenderModel?) { model = snapshot }
    fun invalidate() { if (params != null) view.invalidate() }

    private fun drawModel(canvas: Canvas, m: RenderModel, width: Float, height: Float) {
        var y = 32f
        val lineHeight = 25f
        fun line(text: String, paint: Paint = smallTextPaint) {
            canvas.drawText(text, 12f, y, paint)
            y += lineHeight
        }
        val robloxPaint = Paint(textPaint).apply { color = if (m.robloxDetected) Color.GREEN else Color.RED }
        line("Roblox: ${if (m.robloxDetected) "YES" else "NO"} | package=${m.foregroundPackage}", robloxPaint)
        line("Window=${m.foregroundWindow}")
        line("State=${m.state} | FPS=${"%.1f".format(m.fps)} | frame=${m.frameAgeMs}ms", textPaint)
        line("Fish=${"%.3f".format(m.fishCx)} Player=${"%.3f".format(m.playerCx)} Error=${"%+.3f".format(m.error)}")
        line("Confidence: global=${"%.2f".format(m.confGlobal)} bar=${"%.2f".format(m.confBar)} fish=${"%.2f".format(m.confFish)} player=${"%.2f".format(m.confPlayer)}")
        line("Progress=${"%.2f".format(m.progress)} rate=${"%+.2f".format(m.progressRate)} | action=${m.action}")
        val safetyText = if (m.inputAuthorized) "Safety: PASS" else "Safety: BLOCKED ${m.safetyBlockedReason}"
        val safetyPaint = Paint(textPaint).apply { color = if (m.inputAuthorized) Color.GREEN else Color.RED }
        line("Input=${if (m.realInputEnabled) "ENABLED" else "DISABLED"} | $safetyText", safetyPaint)
        if (m.emergency) line("EMERGENCY STOP LATCHED", Paint(textPaint).apply { color = Color.RED })

        m.barBox?.let { drawBox(canvas, it, width, height, Color.CYAN) }
        m.blockBox?.let { drawBox(canvas, it, width, height, Color.WHITE) }
        m.fishBox?.let { drawBox(canvas, it, width, height, Color.YELLOW) }
        m.progressBox?.let { drawBox(canvas, it, width, height, Color.GREEN) }
        m.shakeBox?.let { drawBox(canvas, it, width, height, Color.MAGENTA) }
        m.rodBox?.let { drawBox(canvas, it, width, height, Color.RED) }
        m.barBox?.let { bar ->
            val left = bar[0] * width
            val right = bar[2] * width
            fillPaint.color = Color.argb(160, 0, 220, 120)
            canvas.drawRect(left, 4f, left + (right - left) * m.progress.coerceIn(0f, 1f), 12f, fillPaint)
        }
    }

    private fun drawBox(canvas: Canvas, norm: FloatArray, width: Float, height: Float, color: Int) {
        if (norm.size < 4) return
        boxPaint.color = color
        canvas.drawRect(norm[0] * width, norm[1] * height, norm[2] * width, norm[3] * height, boxPaint)
    }
}
