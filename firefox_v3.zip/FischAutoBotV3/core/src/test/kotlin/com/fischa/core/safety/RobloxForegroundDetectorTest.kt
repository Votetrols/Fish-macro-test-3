package com.fischa.core.safety

import org.junit.Assert.*
import org.junit.Test

class RobloxForegroundDetectorTest {
    private val detector = RobloxForegroundDetector()
    private val roblox = RobloxForegroundDetector.ROBLOX_PACKAGE

    @Test fun robloxForegroundIsRecognizedFromWindowAndEventEvidence() {
        val status = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = roblox,
            rootInActiveWindowPackage = roblox,
            lastWindowEventPackage = roblox,
            foregroundActivity = "com.roblox.client.GameActivity",
            activeWindow = "type=application active=true",
            timestampMs = 10,
        ))
        assertTrue(status.robloxDetected)
        assertTrue(status.inputAuthorized)
        assertEquals(roblox, status.foregroundPackage)
    }

    @Test fun immersiveSurfaceMayUseFreshWindowEventWhenRootIsNull() {
        val status = detector.evaluate(ForegroundObservation(
            lastWindowEventPackage = roblox,
            foregroundActivity = "com.roblox.client.GameActivity",
            timestampMs = 20,
        ))
        assertTrue(status.inputAuthorized)
    }

    @Test fun otherAndUnknownPackagesFailClosed() {
        val other = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = "com.android.launcher",
            lastWindowEventPackage = "com.android.launcher",
            timestampMs = 30,
        ))
        assertFalse(other.robloxDetected)
        assertFalse(other.inputAuthorized)
        assertEquals("FOREGROUND_PACKAGE_MISMATCH", other.blockReason)

        val unknown = detector.evaluate(ForegroundObservation(timestampMs = 31))
        assertFalse(unknown.robloxDetected)
        assertFalse(unknown.inputAuthorized)
        assertEquals(RobloxForegroundStatus.UNKNOWN, unknown.foregroundPackage)
    }

    @Test fun staleCachedEventCannotAuthorizeUnknownFullscreenForeground() {
        val status = detector.evaluate(ForegroundObservation(
            lastWindowEventPackage = roblox,
            timestampMs = 5_000,
            lastWindowEventTimestampMs = 1_000,
        ))
        assertFalse(status.robloxDetected)
        assertFalse(status.inputAuthorized)
        assertEquals(RobloxForegroundStatus.UNKNOWN, status.foregroundPackage)
    }

    @Test fun overlayAndConflictingWindowBlockInput() {
        val overlay = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = roblox,
            lastWindowEventPackage = roblox,
            incompatibleOverlay = true,
            timestampMs = 40,
        ))
        assertTrue(overlay.robloxDetected)
        assertFalse(overlay.inputAuthorized)
        assertEquals("INCOMPATIBLE_OVERLAY", overlay.blockReason)

        val conflict = detector.evaluate(ForegroundObservation(
            activeAppWindowPackage = roblox,
            rootInActiveWindowPackage = "com.android.systemui",
            lastWindowEventPackage = roblox,
            timestampMs = 41,
        ))
        assertFalse(conflict.inputAuthorized)
    }

    @Test fun accessibilityUnavailableCannotAuthorizeCachedRoblox() {
        val status = detector.evaluate(ForegroundObservation(
            lastWindowEventPackage = roblox,
            accessibilityAvailable = false,
            timestampMs = 50,
        ))
        assertTrue(status.robloxDetected)
        assertFalse(status.inputAuthorized)
        assertEquals("ACCESSIBILITY_UNAVAILABLE", status.blockReason)
    }
}
