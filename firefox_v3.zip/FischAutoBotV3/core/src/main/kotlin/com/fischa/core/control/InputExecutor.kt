package com.fischa.core.control

/**
 * Single gateway from the platform-independent core to Android input.
 *
 * Coordinates are normalized display coordinates (0..1). Every non-release command carries
 * an authorization closure that the Android adapter must re-check before every bounded
 * gesture segment. Release/cancel are deliberately unconditional so safety cleanup cannot be
 * blocked by the same guard that rejected a press.
 */
interface InputExecutor {
    /** A finite tap; [authorize] is checked immediately before dispatch. */
    fun tap(
        nx: Float,
        ny: Float,
        durationMs: Int,
        authorize: () -> Boolean,
    ): Boolean {
        if (!authorize()) return false
        tap(nx, ny, durationMs)
        return true
    }

    /** Legacy/dry-run hook retained for the replay harness and simple test executors. */
    fun tap(nx: Float, ny: Float, durationMs: Int) {}

    /** Start a leased hold. The platform must split it into short, finite segments. */
    fun holdStart(
        nx: Float,
        ny: Float,
        leaseMs: Int,
        authorize: () -> Boolean,
    ): Boolean = tap(nx, ny, leaseMs, authorize)

    /** Renew the active hold only when a fresh frame still authorizes it. */
    fun holdExtend(
        nx: Float,
        ny: Float,
        leaseMs: Int,
        authorize: () -> Boolean,
    ): Boolean = authorize()

    /** Release a hold. This method must never be rejected by the input safety guard. */
    fun holdRelease() = cancelAll()

    /** Number of active/in-flight gestures, for diagnostics and watchdogs. */
    fun activeGestureCount(): Int = 0

    /** End active and pending gestures. Implementations must fail safe if called repeatedly. */
    fun cancelAll()

    /** Explicit synonym used by safety/emergency paths. */
    fun releaseAll() = holdRelease()

    object Noop : InputExecutor {
        override fun tap(nx: Float, ny: Float, durationMs: Int) {}
        override fun holdStart(nx: Float, ny: Float, leaseMs: Int, authorize: () -> Boolean) = false
        override fun holdExtend(nx: Float, ny: Float, leaseMs: Int, authorize: () -> Boolean) = false
        override fun holdRelease() {}
        override fun cancelAll() {}
    }
}
