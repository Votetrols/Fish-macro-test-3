package com.fischa.core.safety

/**
 * Platform-neutral evidence collected by the single Android AccessibilityService monitor.
 * A missing package is unknown, never a positive result.
 */
data class ForegroundObservation(
    val activeAppWindowPackage: String? = null,
    val rootInActiveWindowPackage: String? = null,
    val lastWindowEventPackage: String? = null,
    val foregroundActivity: String? = null,
    val activeWindow: String? = null,
    val incompatibleOverlay: Boolean = false,
    val accessibilityAvailable: Boolean = true,
    val screenInteractive: Boolean = true,
    val timestampMs: Long,
    /** Timestamp of the cached event source; old events cannot authorize a fullscreen window. */
    val lastWindowEventTimestampMs: Long? = timestampMs,
)

data class RobloxForegroundStatus(
    val foregroundPackage: String = UNKNOWN,
    val foregroundActivityWindow: String = UNKNOWN,
    val robloxDetected: Boolean = false,
    val inputAuthorized: Boolean = false,
    val blockReason: String = "FOREGROUND_UNKNOWN",
    val timestampMs: Long = 0L,
    val overlayActive: Boolean = false,
) {
    companion object {
        const val UNKNOWN = "<unknown>"
        fun unknown(timestampMs: Long, reason: String = "FOREGROUND_UNKNOWN") =
            RobloxForegroundStatus(timestampMs = timestampMs, blockReason = reason)
    }
}

/**
 * The one package/window decision rule used by UI diagnostics, engine and gesture watchdog.
 * Explicit live window sources must not contradict the target package. The launcher/window
 * event is the fallback for immersive games whose active accessibility root is null.
 */
class RobloxForegroundDetector(
    private val expectedPackage: String = ROBLOX_PACKAGE,
    private val maxWindowEventAgeMs: Long = 3_000L,
) {
    init { require(maxWindowEventAgeMs >= 0L) }

    fun evaluate(observation: ForegroundObservation): RobloxForegroundStatus {
        val active = normalize(observation.activeAppWindowPackage)
        val root = normalize(observation.rootInActiveWindowPackage)
        val eventTimestamp = observation.lastWindowEventTimestampMs
        val eventAgeMs = eventTimestamp?.let { observation.timestampMs - it } ?: Long.MAX_VALUE
        val eventFresh = eventAgeMs >= 0L && eventAgeMs <= maxWindowEventAgeMs
        val event = if (eventFresh) normalize(observation.lastWindowEventPackage) else null
        val candidates = listOfNotNull(active, root, event)
        val resolved = active ?: root ?: event ?: RobloxForegroundStatus.UNKNOWN
        val conflicts = candidates.filter { it != expectedPackage }
        val detected = candidates.any { it == expectedPackage } && conflicts.isEmpty()
        val reason = when {
            !observation.accessibilityAvailable -> "ACCESSIBILITY_UNAVAILABLE"
            !observation.screenInteractive -> "SCREEN_NOT_INTERACTIVE"
            observation.incompatibleOverlay -> "INCOMPATIBLE_OVERLAY"
            candidates.isEmpty() -> "FOREGROUND_UNKNOWN"
            conflicts.isNotEmpty() -> "FOREGROUND_PACKAGE_MISMATCH"
            !detected -> "ROBLOX_NOT_CONFIRMED"
            else -> "NONE"
        }
        val authorized = detected && observation.accessibilityAvailable &&
            observation.screenInteractive && !observation.incompatibleOverlay
        val window = listOfNotNull(
            observation.foregroundActivity?.takeIf { it.isNotBlank() },
            observation.activeWindow?.takeIf { it.isNotBlank() },
        ).joinToString(" | ").ifBlank { RobloxForegroundStatus.UNKNOWN }
        return RobloxForegroundStatus(
            foregroundPackage = resolved,
            foregroundActivityWindow = window,
            robloxDetected = detected,
            inputAuthorized = authorized,
            blockReason = if (authorized) "NONE" else reason,
            timestampMs = observation.timestampMs,
            overlayActive = observation.incompatibleOverlay,
        )
    }

    private fun normalize(packageName: String?): String? = packageName
        ?.trim()
        ?.takeIf { it.isNotEmpty() && it != RobloxForegroundStatus.UNKNOWN }

    companion object {
        const val ROBLOX_PACKAGE = "com.roblox.client"
    }
}
