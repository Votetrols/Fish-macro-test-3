package com.fischa.core.v9

import com.fischa.core.common.NormRegion
import com.fischa.core.config.AppConfig
import com.fischa.core.config.RodDetectorKind
import com.fischa.core.log.LogSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.vision.MemoryRodDiagnostics
import com.fischa.core.vision.RodDiagEvent
import com.fischa.core.vision.RodDetectionV9
import com.fischa.core.vision.RodTemplateV9
import com.fischa.core.vision.RodV9Result
import com.fischa.core.vision.RodV9State
import com.fischa.core.vision.VisionFrame
import com.fischa.core.v9.RodSceneV9Fixture.Button
import com.fischa.core.v9.RodSceneV9Fixture.ButtonStyle
import com.fischa.core.v9.RodSceneV9Fixture.Foam
import com.fischa.core.v9.RodSceneV9Fixture.FrameState
import com.fischa.core.v9.RodSceneV9Fixture.Hotbar
import com.fischa.core.v9.RodSceneV9Fixture.ShakePrompt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.hypot

/**
 * **Detecção do botão da vara — V9: os casos obrigatórios da spec §12.**
 *
 * Cada teste roda o `RodDetectionV9` (janela móvel + confirmação temporal) sobre a cena sintética
 * de [RodSceneV9Fixture] e compara com a **verdade do desenho**: os testes nunca fixam a posição
 * esperada no código do detector — o botão é desenhado onde o teste quiser e as asserções usam
 * essa posição.
 *
 * Testes sintéticos não provam nada sobre o Roblox (é o que a spec §12 diz): os frames **reais**
 * do usuário entram pelo `RodFrameLab` (`./gradlew :core:rodLab -Pframes=...`) e pelos testes
 * `RealFrame*Test`, que usam os mesmos módulos de produção.
 */
class V9RodButtonDetectionTest {

    private companion object {
        const val BUTTON_FX = 0.81f
        const val BUTTON_FY = 0.69f
    }

    private class RecordingSink : LogSink {
        val lines = ArrayList<String>()

        override fun log(level: LogSink.Level, tag: String, msg: String, timestampNs: Long) {
            lines.add("$tag|$msg")
        }

        /** o log/overlay pode conter o texto? (usado só onde a spec §6/§7 exige motivo) */
        fun has(text: String) = lines.any { it.contains(text) }
    }

    private class Driver(
        val w: Int = 640,
        val h: Int = 288,
        val fps: Float = 30f,
        cfg: AppConfig = AppConfig().validate(),
    ) {
        val sink = RecordingSink()
        val log = ThrottledLog(sink)
        val config: AppConfig = cfg.copy(rodDetector = RodDetectorKind.V9)
        val diag = MemoryRodDiagnostics(200)
        val det = RodDetectionV9(config, log).also { it.diagnostics = diag }
        val v = config.rodButtonV9
        val periodNs: Long = (1_000_000_000.0 / fps).toLong().coerceAtLeast(1L)
        var nowNs = 1_000_000_000L
        var serial = 0L
        val states = ArrayList<RodV9State>()
        val windows = ArrayList<NormRegion>()
        var last = RodV9Result()
        var notFoundSeen = false
        var frames = 0
        var camX = 0
        var camY = 0

        fun windowAtStart(): NormRegion = NormRegion(
            v.initialRoiX, v.initialRoiY, v.initialRoiX + v.roiWidth, v.initialRoiY + v.roiHeight,
        )

        /** um frame da cena; devolve uma cópia (o detector reutiliza o snapshot) */
        fun frame(
            button: Button?,
            decorate: ((VisionFrame) -> Unit)? = null,
        ): RodV9Result {
            val f = VisionFrame.allocate(w, h)
            RodSceneV9Fixture.draw(
                f,
                FrameState(wavePhase = serial * 0.7f, seed = 7L + serial, cameraX = camX, cameraY = camY),
                button = button,
                hotbar = Hotbar(y = h - 14),
            )
            decorate?.invoke(f)
            f.resetFor(nowNs, ++serial)
            f.ensureGray()
            log.setNow(nowNs)
            val snap = det.update(f, fps, nowNs)
            nowNs += periodNs
            frames++
            states.add(snap.state)
            windows.add(snap.roi)
            last = RodV9Result().also { it.copyFrom(snap) }
            if (last.targetNotFound) notFoundSeen = true
            return last
        }

        /** roda até confirmar (ou até [max] frames) */
        fun confirm(button: Button?, max: Int = 60, decorate: ((VisionFrame) -> Unit)? = null): RodV9Result {
            repeat(max) {
                val s = frame(button, decorate)
                if (s.targetFound) return s
            }
            return last
        }

        fun run(frames: Int, button: Button?, decorate: ((VisionFrame) -> Unit)? = null): RodV9Result {
            var s = last
            repeat(frames) {
                s = frame(button, decorate)
                if (s.targetNotFound) return s
            }
            return s
        }

        fun stateIndex(state: RodV9State): Int = states.indexOfFirst { it == state }

        fun stateSeen(state: RodV9State): Boolean = stateIndex(state) >= 0

        fun windowInsideScreen(): Boolean = windows.all {
            it.left >= -1e-4f && it.top >= -1e-4f && it.right <= 1f + 1e-4f && it.bottom <= 1f + 1e-4f
        }

        fun maxWindowStepPx(): Float {
            var maxStep = 0f
            for (i in 1 until windows.size) {
                val dx = (windows[i].centerX - windows[i - 1].centerX) * w
                val dy = (windows[i].centerY - windows[i - 1].centerY) * h
                maxStep = maxOf(maxStep, hypot(dx, dy))
            }
            return maxStep
        }

        /** o alvo publicado aponta para o botão desenhado? */
        fun targetErrorPx(snap: RodV9Result, button: Button): Float =
            hypot(snap.targetX * w - button.cx, snap.targetY * h - button.cy)
    }

    private fun cfg(
        v9: AppConfig.RodButtonV9 = AppConfig.RodButtonV9(),
        base: AppConfig = AppConfig(),
    ): AppConfig = base.copy(rodDetector = RodDetectorKind.V9, rodButtonV9 = v9).validate()

    /** §14: sem alvo, **nenhuma** coordenada pode ser publicada */
    private fun assertNoInventedPosition(snap: RodV9Result, where: String) {
        if (!snap.targetFound) {
            assertTrue("$where: targetX não é NaN sem alvo (${snap.targetX})", snap.targetX.isNaN())
            assertTrue("$where: targetY não é NaN sem alvo (${snap.targetY})", snap.targetY.isNaN())
        } else {
            assertTrue("$where: alvo publicado sem candidato", snap.candidateFound)
            assertTrue("$where: posição publicada não é finita", snap.targetX.isFinite())
        }
    }

    // ============================================================ 1. botão parado

    @Test
    fun stationaryButtonIsFoundConfirmedAndTracked() {
        val d = Driver()
        val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d.w, d.h)
        val snap = d.confirm(button, max = 45)
        assertTrue(
            "não confirmou o botão parado (estado=${snap.state} reason=${snap.reason} " +
                "dstate=${snap.detectorState} conf=${snap.confidence})",
            snap.targetFound,
        )
        assertEquals("a janela móvel deveria estar rastreando", RodV9State.TRACKING, snap.state)
        assertTrue("confiança baixa: ${snap.confidence}", snap.confidence >= d.v.minimumConfidence)
        val err = d.targetErrorPx(snap, button)
        assertTrue("centro publicado a ${err}px do botão (r=${button.r})", err <= button.r * 0.6f)
        assertTrue("TARGET_NOT_FOUND com o botão visível", !snap.targetNotFound)
        assertNoInventedPosition(snap, "botão parado")
    }

    @Test
    fun stationaryButtonKeepsItsWindowStableAfterConfirmation() {
        val d = Driver()
        val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d.w, d.h)
        assertTrue("não confirmou", d.confirm(button, max = 45).targetFound)
        // depois de estabilizar, a janela não pode tremer mais que 2px por frame
        val before = d.windows.size
        val snap = d.run(45, button)
        assertTrue("perdeu o alvo parado", snap.targetFound)
        assertTrue("a janela tremeu ${d.maxWindowStepPx()}px/frame", d.maxWindowStepPx() <= 2.5f)
        val err = d.targetErrorPx(snap, button)
        assertTrue("centro derivou ${err}px do botão parado", err <= button.r * 0.6f)
        assertTrue("estados registrados desde $before", d.states.size > before)
        assertNoInventedPosition(snap, "botão parado (2)")
    }

    // ============================================================ 2. botão deslocado

    @Test
    fun movedButtonIsFollowedByTheWindow() {
        val d = Driver()
        val start = RodSceneV9Fixture.buttonAt(0.70f, 0.66f, d.w, d.h)
        assertTrue("não confirmou o alvo inicial", d.confirm(start, max = 45).targetFound)
        var finalButton = start
        var lastOk = false
        for (i in 1..30) {
            finalButton = start.copy(cx = start.cx + i * 3, cy = start.cy + i / 5)
            val snap = d.frame(finalButton)
            assertTrue("janela saiu da tela movendo o botão", d.windowInsideScreen())
            if (snap.targetFound) {
                val err = d.targetErrorPx(snap, finalButton)
                assertTrue("frame $i: centro a ${err}px do botão em movimento", err <= finalButton.r * 0.9f)
                lastOk = true
            }
        }
        assertTrue("a detecção se perdeu durante o deslocamento", lastOk)
        assertTrue(
            "a janela não acompanhou o alvo (janela=${d.windows.last().centerX * d.w} " +
                "botão=${finalButton.cx})",
            abs(d.windows.last().centerX * d.w - finalButton.cx) <= d.v.roiWidth * d.w * 0.5f,
        )
        assertNoInventedPosition(d.last, "botão deslocado")
    }

    // ============================================================ 3. botão na borda

    @Test
    fun buttonNearTheScreenEdgeIsStillDetected() {
        // botão no canto inferior direito, dentro da janela inicial mas colado na borda da tela
        val d = Driver(cfg = cfg(v9 = AppConfig.RodButtonV9(
            initialRoiX = 0.60f, initialRoiY = 0.52f, roiWidth = 0.36f, roiHeight = 0.42f,
        )))
        val r = 30
        val button = Button(cx = d.w - r - 3, cy = d.h - r - 3, r = r)
        val snap = d.confirm(button, max = 90)
        assertTrue(
            "não detectou o botão junto da borda (estado=${snap.state} reason=${snap.reason})",
            snap.targetFound,
        )
        val err = d.targetErrorPx(snap, button)
        assertTrue("centro a ${err}px do botão da borda", err <= button.r)
        assertTrue("janela saiu da tela", d.windowInsideScreen())
        assertNoInventedPosition(snap, "botão na borda")
    }

    // ============================================================ 4/5. desaparece e volta

    @Test
    fun disappearingButtonGoesToTargetLostWithoutInventingCoordinates() {
        val d = Driver()
        val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d.w, d.h)
        assertTrue("não confirmou antes de sumir", d.confirm(button, max = 45).targetFound)

        // o botão sai da região (a cena continua viva: água, partículas, reflexos…)
        var seenLost = false
        var sawCoordinates = false
        for (i in 0 until 60) {
            val snap = d.frame(null)
            if (!snap.targetFound && snap.state == RodV9State.TARGET_LOST) seenLost = true
            if (!snap.targetFound && (snap.targetX.isFinite() || snap.targetY.isFinite())) sawCoordinates = true
            assertNoInventedPosition(snap, "botão desaparecido frame $i")
        }
        assertTrue("TARGET_LOST não foi observado (estados=${d.states.distinct()})", seenLost)
        assertFalse("coordenada publicada com o botão fora da cena", sawCoordinates)
        assertTrue("estado final inesperado: ${d.last.state}", d.last.state in setOf(
            RodV9State.RECOVERING, RodV9State.TARGET_LOST, RodV9State.SEARCHING,
        ))
    }

    @Test
    fun reappearingButtonIsReacquired() {
        val d = Driver()
        val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d.w, d.h)
        assertTrue("não confirmou antes de sumir", d.confirm(button, max = 45).targetFound)
        d.run(40, null)
        assertFalse("continuou publicando alvo sem o botão", d.last.targetFound)
        val back = d.confirm(button, max = 90)
        assertTrue("não reencontrou o botão reaparecido (${back.reason})", back.targetFound)
        val err = d.targetErrorPx(back, button)
        assertTrue("centro a ${err}px do botão reaparecido", err <= button.r * 0.8f)
        assertNoInventedPosition(back, "botão reaparecido")
    }

    // ============================================================ 6. falsos positivos

    @Test
    fun gameSceneWithoutButtonNeverReportsATarget() {
        val d = Driver()
        var targets = 0
        for (i in 0 until 120) {
            val snap = d.frame(null)
            if (snap.targetFound) targets++
            assertNoInventedPosition(snap, "cena sem botão frame $i")
        }
        assertEquals("a cena sem botão produziu alvo", 0, targets)
        assertTrue("TARGET_NOT_FOUND não foi reportado (${d.last.reason})", d.notFoundSeen)
    }

    @Test
    fun shakePromptIsRejectedAsFalsePositive() {
        val d = Driver()
        val shake = ShakePrompt(cx = (d.w * BUTTON_FX).toInt(), cy = (d.h * BUTTON_FY).toInt(), r = 34)
        var targets = 0
        for (i in 0 until 100) {
            val snap = d.frame(null) { f -> RodSceneV9Fixture.draw(f, shake = shake) }
            if (snap.targetFound) targets++
            assertNoInventedPosition(snap, "prompt SHAKE frame $i")
        }
        assertEquals("o prompt SHAKE foi confundido com o botão", 0, targets)
    }

    @Test
    fun foamBlobsInTheWaterAreNotConfirmed() {
        // manchas claras do tamanho do botão, na água, mudando de lugar a cada frame
        val d = Driver()
        var targets = 0
        for (i in 0 until 90) {
            val snap = d.frame(null) { f ->
                val cx = (f.width * 0.66f).toInt() + (i * 9) % (f.width / 4)
                val cy = (f.height * 0.62f).toInt() + (i * 5) % 26
                RodSceneV9Fixture.draw(f, foam = listOf(Foam(cx, cy, r = (0.05f * f.width).toInt())))
            }
            if (snap.targetFound) targets++
            assertNoInventedPosition(snap, "espuma frame $i")
        }
        assertEquals("espuma na água virou alvo", 0, targets)
    }

    @Test
    fun cameraMotionAloneDoesNotCreateATarget() {
        val d = Driver()
        var targets = 0
        for (i in 0 until 70) {
            d.camX = (i * 7) % 120
            d.camY = (i * 3) % 40
            val snap = d.frame(null)
            if (snap.targetFound) targets++
            assertNoInventedPosition(snap, "câmera em movimento frame $i")
        }
        assertEquals("movimento de câmera gerou alvo", 0, targets)
    }

    @Test
    fun aButtonThatMovesEveryFrameIsNotConfirmedAsATarget() {
        // HUD real não passeia pela tela: um blob do tamanho do botão que anda rápido demais
        // não pode completar a confirmação temporal (§5) — só uma coisa parada vira alvo.
        val d = Driver()
        val base = RodSceneV9Fixture.buttonAt(0.70f, 0.66f, d.w, d.h)
        var targets = 0
        for (i in 0 until 60) {
            val snap = d.frame(base.copy(cx = base.cx + i * 8, cy = base.cy + (i % 3) * 4))
            if (snap.targetFound) targets++
        }
        assertEquals("um elemento em movimento rápido foi confirmado como alvo", 0, targets)
    }

    // ============================================================ 7. resoluções

    @Test
    fun worksAtDifferentResolutions() {
        for ((w, h) in listOf(480 to 216, 640 to 288, 960 to 432, 1280 to 720)) {
            val d = Driver(w = w, h = h)
            val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, w, h)
            val snap = d.confirm(button, max = 60)
            assertTrue("$w x $h: não detectou (${snap.reason})", snap.targetFound)
            val err = d.targetErrorPx(snap, button)
            assertTrue("$w x $h: centro a ${err}px (r=${button.r})", err <= button.r)
            assertNoInventedPosition(snap, "$w x $h")
        }
    }

    // ============================================================ 8. proporções

    @Test
    fun worksAtDifferentAspectRatios() {
        for ((w, h) in listOf(640 to 360, 640 to 400, 720 to 720, 480 to 320)) {
            val d = Driver(w = w, h = h)
            val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, w, h)
            val snap = d.confirm(button, max = 60)
            assertTrue("$w x $h: não detectou (${snap.reason})", snap.targetFound)
            val err = d.targetErrorPx(snap, button)
            assertTrue("$w x $h: centro a ${err}px", err <= button.r)
            assertTrue("$w x $h: janela saiu da tela", d.windowInsideScreen())
        }
    }

    // ============================================================ 9. FPS

    @Test
    fun detectsAt15_30And60FpsWithTimeBasedConfirmation() {
        for (fps in listOf(15f, 30f, 60f)) {
            val d = Driver(fps = fps)
            val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d.w, d.h)
            val snap = d.confirm(button, max = (fps * 2f).toInt())
            assertTrue("${fps.toInt()} FPS: não confirmou (${snap.reason})", snap.targetFound)
            assertTrue("${fps.toInt()} FPS: TARGET_NOT_FOUND indevido", !snap.targetNotFound)
            val err = d.targetErrorPx(snap, button)
            assertTrue("${fps.toInt()} FPS: centro a ${err}px do botão", err <= button.r)
        }
    }

    // ============================================================ 10. ROI longe / perto

    @Test
    fun roiStartingOnTheTargetConfirmsQuickly() {
        val d = Driver(cfg = cfg(v9 = AppConfig.RodButtonV9(initialRoiX = 0.68f, initialRoiY = 0.58f)))
        val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d.w, d.h)
        assertTrue("o botão precisa estar dentro da janela inicial deste teste", d.windowAtStart().contains(button.cx.toFloat() / d.w, button.cy.toFloat() / d.h))
        val snap = d.confirm(button, max = 30)
        assertTrue("não confirmou com a ROI sobre o alvo", snap.targetFound)
        assertTrue("demorou ${d.frames} frames com a ROI já no alvo", d.frames <= 20)
        assertNoInventedPosition(snap, "ROI no alvo")
    }

    @Test
    fun roiStartingFarFromTargetKeepsHonestAndRecoversWhenTheWindowGrows() {
        // janela inicial longe do botão: nada deve ser publicado enquanto ele está fora…
        val d = Driver(cfg = cfg(v9 = AppConfig.RodButtonV9(
            initialRoiX = 0.02f, initialRoiY = 0.02f, roiWidth = 0.22f, roiHeight = 0.24f,
        )))
        val button = RodSceneV9Fixture.buttonAt(0.74f, 0.74f, d.w, d.h)
        assertFalse(
            "o botão não está na janela inicial: nada pode ser publicado",
            d.windowAtStart().contains(button.cx.toFloat() / d.w, button.cy.toFloat() / d.h),
        )
        var earlyTargets = 0
        for (i in 0 until 40) {
            val snap = d.frame(button)
            if (snap.targetFound) earlyTargets++
            assertNoInventedPosition(snap, "ROI longe frame $i")
        }
        assertEquals("publicou alvo com a janela longe e pequena", 0, earlyTargets)
        // …e quando a escada de recuperação amplia a busca, o botão precisa ser encontrado
        val snap = d.confirm(button, max = 200)
        assertTrue(
            "a recuperação não encontrou o botão que estava fora da janela (estado=${snap.state} " +
                "reason=${snap.reason} etapas=${d.states.distinct()})",
            snap.targetFound,
        )
        val err = d.targetErrorPx(snap, button)
        assertTrue("centro a ${err}px do botão recuperado", err <= button.r)
        assertTrue("janela saiu da tela", d.windowInsideScreen())
        assertNoInventedPosition(snap, "ROI longe → recuperação")
    }

    // ============================================================ 11. recuperação

    @Test
    fun recoveryLadderExpandsTheSearchAndReturnsToTracking() {
        val d = Driver()
        val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d.w, d.h)
        assertTrue("não confirmou", d.confirm(button, max = 45).targetFound)
        d.run(30, null)
        assertTrue("a escada de recuperação não foi usada (${d.states.distinct()})",
            d.states.contains(RodV9State.RECOVERING) || d.states.contains(RodV9State.TARGET_LOST))
        val stages = ArrayList<Int>()
        for (i in 0 until 120) {
            val snap = d.frame(null)
            stages.add(snap.recoveryStage)
        }
        assertTrue("nenhuma etapa de recuperação foi usada: $stages", stages.any { it > 0 })
        val back = d.confirm(button, max = 90)
        assertTrue("não voltou a rastrear depois da recuperação (${back.state} / ${back.reason})",
            back.targetFound && back.state == RodV9State.TRACKING)
    }

    // ============================================================ 12. TARGET_NOT_FOUND

    @Test
    fun targetNotFoundIsReportedWhenThereIsNoEvidence() {
        val d = Driver()
        val snap = d.run(150, null)
        assertTrue("TARGET_NOT_FOUND não foi reportado (${snap.reason})", d.notFoundSeen)
        assertFalse("publicou alvo sem evidência", snap.targetFound)
        assertTrue("centro publicado sem alvo", snap.targetX.isNaN() && snap.targetY.isNaN())
        assertTrue("log sem motivo de TARGET_NOT_FOUND", d.sink.has("TARGET_NOT_FOUND") || snap.targetNotFound)
    }

    @Test
    fun disabledDetectionNeverReportsATarget() {
        val d = Driver(cfg = cfg(v9 = AppConfig.RodButtonV9(rodButtonDetectionEnabled = false)))
        val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d.w, d.h)
        val snap = d.run(60, button)
        assertFalse("detecção desligada publicou alvo", snap.targetFound)
        assertTrue("TARGET_NOT_FOUND com a detecção desligada", snap.targetNotFound)
        assertTrue("centro publicado com a detecção desligada", snap.targetX.isNaN())
    }

    // ============================================================ 13. aparências

    @Test
    fun detectsButtonsOfDifferentAppearances() {
        for (style in listOf(
            ButtonStyle.DARK_RING,
            ButtonStyle.LIGHT_BUTTON,
            ButtonStyle.TRANSLUCENT,
            ButtonStyle.ROUNDED_SQUARE,
            ButtonStyle.NO_GLYPH,
        )) {
            val d = Driver()
            val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d.w, d.h, style = style)
            val snap = d.confirm(button, max = 60)
            assertTrue("estilo $style não foi detectado (${snap.reason})", snap.targetFound)
            val err = d.targetErrorPx(snap, button)
            assertTrue("estilo $style: centro a ${err}px (r=${button.r})", err <= button.r)
        }
    }

    // ============================================================ 14. §8 debug ligado/desligado

    @Test
    fun detectionDoesNotDependOnShowDetectionDebug() {
        val on = Driver(cfg = cfg(v9 = AppConfig.RodButtonV9(showDetectionDebug = true)))
        val off = Driver(cfg = cfg(v9 = AppConfig.RodButtonV9(showDetectionDebug = false)))
        val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, on.w, on.h)
        val a = on.confirm(button, max = 45)
        val b = off.confirm(button, max = 45)
        assertEquals("o debug mudou a quantidade de frames até confirmar", true, a.targetFound)
        assertEquals("o debug mudou a detecção", true, b.targetFound)
        assertTrue("a posição mudou com o debug", on.targetErrorPx(a, button) <= button.r)
        assertTrue("a posição mudou com o debug", off.targetErrorPx(b, button) <= button.r)
    }

    // ============================================================ 15. §9 diagnósticos

    @Test
    fun diagnosticsCaptureTheRequiredSituations() {
        // (a) candidato + confirmação
        val d1 = Driver()
        val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d1.w, d1.h)
        d1.confirm(button, max = 45)
        assertTrue("sem evento de candidato", d1.diag.count(RodDiagEvent.CANDIDATE_FOUND) > 0)
        assertTrue("sem evento de confirmação", d1.diag.count(RodDiagEvent.CONFIRMED) > 0)
        val entry = d1.diag.entries.last { it.event == RodDiagEvent.CONFIRMED }
        assertEquals("o recorte não cobre a ROI", true, entry.cropWidth > 0 && entry.cropHeight > 0)
        assertEquals("o recorte não tem o tamanho da ROI", entry.cropWidth * entry.cropHeight, entry.crop.size)
        // (b) nenhum candidato
        val d2 = Driver()
        d2.run(120, null)
        assertTrue("sem evento de 'nenhum candidato'", d2.diag.count(RodDiagEvent.NO_CANDIDATE) > 0)
        // (c) confiança baixa (mínimo alto ⇒ candidato bom nunca confirma)
        val d3 = Driver(cfg = cfg(v9 = AppConfig.RodButtonV9(minimumConfidence = 0.99f)))
        val b3 = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d3.w, d3.h)
        d3.run(40, b3)
        assertTrue("sem evento de confiança baixa", d3.diag.count(RodDiagEvent.LOW_CONFIDENCE) > 0)
        // (d) TARGET_NOT_FOUND
        assertTrue("sem evento de TARGET_NOT_FOUND", d2.diag.count(RodDiagEvent.TARGET_NOT_FOUND) > 0)
    }

    // ============================================================ 16. §5 frames exigidos

    @Test
    fun confirmationFramesAreHonoured() {
        val d = Driver(cfg = cfg(v9 = AppConfig.RodButtonV9(confirmationFrames = 5)))
        val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d.w, d.h)
        val snap = d.confirm(button, max = 30)
        assertTrue("não confirmou com 5 frames exigidos", snap.targetFound)
        val at = d.stateIndex(RodV9State.TRACKING)
        assertTrue("confirmou em $at frames (5 exigidos)", at >= 0 && at <= 12)
        assertEquals("campo requiredFrames errado", 5, snap.requiredFrames)
    }

    @Test
    fun minimumConfidenceIsHonoured() {
        // confiança mínima inalcançável ⇒ nunca confirma, mas continua honesto
        val d = Driver(cfg = cfg(v9 = AppConfig.RodButtonV9(minimumConfidence = 0.995f)))
        val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d.w, d.h)
        val snap = d.run(60, button)
        assertFalse("confirmou apesar do mínimo de 0.995", snap.targetFound)
        assertTrue("coordenada publicada sem confirmação", snap.targetX.isNaN())
        assertTrue("a detecção precisa *ver* o botão mesmo sem confirmar (candidato=${snap.candidates})",
            snap.candidates > 0)
    }

    // ============================================================ 17. §7 salto máximo

    @Test
    fun maxTargetJumpPreventsJumpingToADistantCandidate() {
        val d = Driver(cfg = cfg(v9 = AppConfig.RodButtonV9(maxTargetJump = 0.02f)))
        val a = RodSceneV9Fixture.buttonAt(0.70f, 0.62f, d.w, d.h)
        assertTrue("não confirmou o primeiro alvo", d.confirm(a, max = 60).targetFound)
        val snapA = d.last
        val b = RodSceneV9Fixture.buttonAt(0.90f, 0.78f, d.w, d.h)
        val snapB = d.frame(b)
        if (snapB.targetFound) {
            val jump = hypot(snapB.targetX - snapA.targetX, snapB.targetY - snapA.targetY)
            assertTrue("saltou $jump para um alvo distante com maxTargetJump=0.02", jump <= 0.05f)
        }
        assertNoInventedPosition(snapB, "salto máximo")
    }

    // ============================================================ 18. §12 frames reais (template)

    @Test
    fun templateFromARealFrameMatchesTheButton() {
        // o que o modo de frames reais (§12) faz: extrai o template do botão de um frame real
        val d = Driver()
        val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d.w, d.h)
        val ref = VisionFrame.allocate(d.w, d.h)
        RodSceneV9Fixture.draw(ref, FrameState(seed = 3L), button = button)
        ref.ensureGray()
        val template = RodTemplateV9.extract(ref, button.cx, button.cy, button.r.toFloat())
        val json = template.toJson()

        // ida e volta pelo JSON (é assim que o app carrega o arquivo do usuário)
        val parsed = RodTemplateV9.parse(json)
        assertNotNull("o JSON do template não voltou", parsed)
        val mine = parsed!!
        assertEquals("dimensões do template perdidas", template.w, mine.w)
        val onTarget = mine.match(ref, button.cx, button.cy, button.r.toFloat())
        val offTarget = mine.match(ref, (d.w * 0.30f).toInt(), (d.h * 0.62f).toInt(), button.r.toFloat())
        assertTrue("NCC no botão baixo: $onTarget", onTarget >= 0.75f)
        assertTrue("NCC fora do botão alto demais: $offTarget", offTarget < onTarget - 0.05f)

        // e o detector usa o template de verdade (mesma decisão de alvo)
        val d2 = Driver()
        assertTrue("detector recusou o template", d2.det.detector.loadTemplate(json))
        val snap = d2.confirm(RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d2.w, d2.h), max = 60)
        assertTrue("não detectou com template carregado (${snap.reason})", snap.targetFound)
    }

    // ============================================================ 19. §4/§10 código do detector

    @Test
    fun detectorSourcesContainNoInputCode() {
        val files = listOf(
            "core/src/main/kotlin/com/fischa/core/vision/RodButtonDetectorV9.kt",
            "core/src/main/kotlin/com/fischa/core/vision/RodDetectionV9.kt",
        )
        val forbidden = listOf(
            "dispatchGesture", "InputExecutor", "GestureDescription", "performClick",
            "AccessibilityService", "RobloxInput", "tapAt", "sendInput",
        )
        for (path in files) {
            val f = java.io.File(path)
            assertTrue("arquivo ausente: ${f.absolutePath}", f.isFile)
            val text = f.readText()
            for (token in forbidden) {
                assertFalse("$path menciona '$token' — o detector não pode executar input (§10)",
                    text.contains(token))
            }
        }
    }

    @Test
    fun detectorOnlyReturnsData() {
        // o contrato público do detector (§10) é exatamente: o que foi encontrado + evidências
        val d = Driver()
        val button = RodSceneV9Fixture.buttonAt(BUTTON_FX, BUTTON_FY, d.w, d.h)
        val snap = d.confirm(button, max = 45)
        assertTrue("targetFound ausente", snap.targetFound)
        assertTrue("targetX/Y ausentes", snap.targetX.isFinite() && snap.targetY.isFinite())
        assertTrue("confidence ausente", snap.confidence >= 0f)
        assertNotNull("state ausente", snap.state)
        assertTrue("roi ausente", snap.roi.isValid)
        assertTrue("candidateData vazio", snap.candidateData.isNotEmpty())
        assertTrue(
            "candidato sem sinais (§3): ${snap.candidateData.first().signals}",
            snap.candidateData.first().signals.isNotEmpty(),
        )
    }
}
