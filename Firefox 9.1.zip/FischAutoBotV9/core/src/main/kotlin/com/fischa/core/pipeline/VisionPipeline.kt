package com.fischa.core.pipeline

import com.fischa.core.common.clamp
import com.fischa.core.config.AppConfig
import com.fischa.core.config.RodDetectorKind
import com.fischa.core.control.CastController
import com.fischa.core.control.CastGestureAction
import com.fischa.core.control.ControlAction
import com.fischa.core.control.FishingController
import com.fischa.core.control.GestureTarget
import com.fischa.core.control.InputExecutor
import com.fischa.core.control.ShakeController
import com.fischa.core.debug.RenderModel
import com.fischa.core.log.Tags
import com.fischa.core.log.ThrottledLog
import com.fischa.core.safety.DenyReason
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.GestureAction
import com.fischa.core.safety.InputRequest
import com.fischa.core.safety.InputSafetyGuard
import com.fischa.core.safety.RealInputPolicy
import com.fischa.core.safety.RobloxForegroundStatus
import com.fischa.core.safety.SafetyContext
import com.fischa.core.state.Evidence
import com.fischa.core.state.FishingState
import com.fischa.core.state.FishingStateMachine
import com.fischa.core.tracking.BarTracker
import com.fischa.core.tracking.ConfidenceTracker
import com.fischa.core.tracking.FishTracker
import com.fischa.core.tracking.PlayerBarTracker
import com.fischa.core.tracking.ProgressTracker
import com.fischa.core.vision.CatchConfirmDetector
import com.fischa.core.vision.DetSnapshot
import com.fischa.core.vision.FishDetector
import com.fischa.core.vision.RodButtonV9State
import com.fischa.core.vision.RodDetectionState
import com.fischa.core.vision.RodDetectionV8
import com.fischa.core.vision.RodDetectionV9
import com.fischa.core.vision.RodFrameDiagnostics
import com.fischa.core.vision.RodV8Result
import com.fischa.core.vision.RodV9Result
import com.fischa.core.vision.RodFinder
import com.fischa.core.vision.RodSnapshot
import com.fischa.core.vision.FishingBarDetector
import com.fischa.core.vision.PlayerBarDetector
import com.fischa.core.vision.ProgressDetector
import com.fischa.core.vision.ShakeDetector
import com.fischa.core.vision.VisionFrame
import kotlin.math.max
import kotlin.math.min

/**
 * Firefox V3 core: vision → temporal tracking → evidence-driven state machine → controllers
 * → one safety gate → input executor. This file intentionally keeps the original Firefox
 * detector/tracker/controller composition; Android and Roblox APIs are injected at the edge.
 */
class VisionPipeline(
    val cfg: AppConfig,
    private val executor: InputExecutor,
    private val log: ThrottledLog,
    val safety: SafetyContext = SafetyContext(),
    val emergency: EmergencyStop = EmergencyStop(),
    /** Optional live platform probe used again for every Android hold segment. */
    private val foregroundStatusProvider: (() -> RobloxForegroundStatus?)? = null,
    private val monotonicNowNs: () -> Long = { System.nanoTime() },
) : AutoCloseable {
    // Vision — original Firefox detector implementations are preserved.
    // V7: the rod button is located by the auto-calibrated multi-stage finder (wide search →
    // candidates → weighed score → temporal confirmation → dynamic ROI → local tracking). The
    // V6 fixed-ROI detector is gone; `rodOut` keeps the DetSnapshot-shaped view the rest of the
    // pipeline (evidence, cast gate, debug) already consumes.
    private val rodFinder = RodFinder(cfg, log)

    // V8 (spec *Rod Detection V8*, §18): the *main* detector is the moving window; the V7
    // auto-calibrated wide search stays available and is used **only** when explicitly selected
    // in the config (`rodDetector = V7`) — nothing is silently reused as the main detector.
    private val rodV8 = RodDetectionV8(cfg, log)
    private val useRodV8: Boolean = cfg.rodDetector == RodDetectorKind.V8

    /**
     * V9 (spec *Rod Detection V9* §13): a **mesma** janela móvel da V8, mas a identificação
     * visual do botão passa a ser feita pelo `RodButtonDetectorV9` (múltiplas evidências visuais).
     * É o detector principal por padrão (`AppConfig.rodDetector = V9`).
     */
    private val rodV9 = RodDetectionV9(cfg, log)
    private val useRodV9: Boolean = cfg.rodDetector == RodDetectorKind.V9

    /** last V8 result (copy of the detector's reusable snapshot, safe to read after the frame) */
    val rodV8Out = RodV8Result()

    /** last V9 result (idem; `targetFound`, `targetX/Y`, `confidence`, `state`, `roi`, candidates) */
    val rodV9Out = RodV9Result()

    /**
     * V9 §9 — sink de captura para diagnóstico. É **passivo**: recebe o frame da ROI quando um
     * candidato é encontrado, quando nenhum é encontrado, quando a confiança fica baixa e quando
     * ocorre `TARGET_NOT_FOUND`. Nunca executa input.
     */
    var rodDiagnostics: RodFrameDiagnostics
        get() = rodV9.diagnostics
        set(value) { rodV9.diagnostics = value }

    /** V9 — template visual extraído de um frame real do usuário (`RodFrameLab`) */
    fun setRodTemplate(json: String?): Boolean = rodV9.detector.loadTemplate(json)

    /** V9 — o detector visual em uso (leitura; testes/overlay podem inspecionar o estado) */
    val rodButtonDetectorV9 get() = rodV9.detector

    private val rodOut = DetSnapshot()
    private fun rodSnapshot(): RodSnapshot = rodFinder.out
    private val shakeDetector = ShakeDetector(cfg.vision)
    private val barDetector = FishingBarDetector(cfg.vision)
    private val blockDetector = PlayerBarDetector(cfg.vision)
    private val fishDetector = FishDetector(cfg.vision)
    private val progressDetector = ProgressDetector(cfg.vision)
    private val catchDetector = CatchConfirmDetector(cfg.vision)

    // Tracking — original AlphaBeta and confidence trackers are preserved.
    private val barTracker = BarTracker(cfg.tracking)
    private val fishTracker = FishTracker(cfg.tracking)
    private val blockTracker = PlayerBarTracker(cfg.tracking)
    private val progressTracker = ProgressTracker()
    private val confTracker = ConfidenceTracker(cfg.tracking)
    private val barRect = floatArrayOf(0f, 0f, 0f, 0f)

    /** release directives issued by CastController on the previous frame, consumed by the FSM */
    private var pendingCastComplete = false
    private var pendingCastAborted = false

    private val stateMachine = FishingStateMachine(cfg.state)
    private val shakeController = ShakeController(cfg.shake)
    private val castController = CastController(cfg.cast)
    private val controller = FishingController(cfg.control)
    private val guard = InputSafetyGuard(cfg.safety)
    private val evidence = Evidence()

    val output = PipelineOutput()

    /** Set only by the host after the user explicitly chooses Start. */
    @Volatile var armed: Boolean = false
        set(value) {
            field = value
            safety.macroEnabled = value
        }

    @Volatile var lastFps: Float = 0f
    private var lastFrameNs = 0L
    @Volatile private var holdActive = false
    @Volatile private var realGestureActive = false
    private var holdTarget: GestureTarget? = null
    private var holdAnchorOverride: GestureTarget? = null
    private var lastActionName = ControlAction.NONE

    @Volatile var render: RenderModel? = null

    private fun normBox(src: DetSnapshot, w: Int, h: Int): FloatArray? {
        if (!src.detected) return null
        return floatArrayOf(src.box.left / w, src.box.top / h, src.box.right / w, src.box.bottom / h)
    }

    /**
     * V8 §16 — publishes the moving-window debug view: window (ROI), candidate, target centre,
     * state, confidence, previous position and the recovery indication. Rendering it never changes
     * the detector behaviour (the model is built from the result the detector already produced).
     */
    private fun publishRodV8(r: RodV8Result) {
        output.rodDetector = "V8"
        output.rodState = r.state.name
        output.rodScore = r.score
        output.rodCandidates = r.candidates
        output.rodStreak = r.confirmation
        output.rodRequiredFrames = r.requiredFrames
        output.rodTracking = r.state.isTracking
        output.rodLostMs = r.lostMs
        output.rodReason = r.reason
        output.rodCalibrationDone = true
        output.rodCandidateDetail = if (r.candidateFound) {
            "candidato=(${r.candidatePx.x.toInt()},${r.candidatePx.y.toInt()},r${r.candidateRadiusPx.toInt()}) " +
                "score=${"%.2f".format(r.score)}"
        } else ""
        output.rodCalibration = r.configSummary.ifEmpty { output.rodCalibration }
        val roi = r.roi
        output.rodRoiNorm[0] = roi.left; output.rodRoiNorm[1] = roi.top
        output.rodRoiNorm[2] = roi.right; output.rodRoiNorm[3] = roi.bottom
        // V8 has no separate wide search: the window *is* the search area
        output.rodSearchNorm[0] = roi.left; output.rodSearchNorm[1] = roi.top
        output.rodSearchNorm[2] = roi.right; output.rodSearchNorm[3] = roi.bottom
        output.rodCenterNorm[0] = if (r.targetFound) r.targetX else 0f
        output.rodCenterNorm[1] = if (r.targetFound) r.targetY else 0f
        // ---- V8 §16: debug view of the moving window ------------------------------------
        output.rodV8TargetFound = r.targetFound
        output.rodV8TargetNotFound = r.targetNotFound
        output.rodV8Recovering = r.recovering
        output.rodV8RecoveryStage = r.recoveryStage
        output.rodV8CandidateFound = r.candidateFound
        output.rodV8CandidateConfidence = r.confidence
        output.rodV8WindowExpanded = r.windowExpanded
        output.rodV8CandidateNorm[0] = if (r.candidateFound) r.candidatePx.x / r.frameW else 0f
        output.rodV8CandidateNorm[1] = if (r.candidateFound) r.candidatePx.y / r.frameH else 0f
        output.rodV8PreviousNorm[0] = if (r.previousX.isFinite()) r.previousX else 0f
        output.rodV8PreviousNorm[1] = if (r.previousY.isFinite()) r.previousY else 0f
        output.layerVision = "ACTIVE"
        output.layerDetection = "ACTIVE"
        output.layerDecision = if (safety.macroEnabled) "ACTIVE" else "IDLE"
        output.layerInput = if (RealInputPolicy.allows()) "ENABLED" else "DISABLED"
    }

    /**
     * V9 §8/§13 — publica a visão de debug da V9: janela (ROI), **todos** os candidatos, o
     * candidato escolhido, o alvo confirmado, a confiança, o estado, o `lastKnownTarget` e o
     * estágio de recuperação. Publicar isso nunca muda a detecção: o modelo é construído a partir
     * do resultado que o detector já produziu.
     */
    private fun publishRodV9(r: RodV9Result) {
        output.rodDetector = "V9"
        output.rodState = r.state.name
        output.rodScore = r.score
        output.rodCandidates = r.candidates
        output.rodStreak = r.confirmation
        output.rodRequiredFrames = r.requiredFrames
        output.rodTracking = r.state.isTracking
        output.rodLostMs = r.lostMs
        output.rodReason = r.reason
        output.rodCalibrationDone = true
        output.rodCandidateDetail = r.candidateData.firstOrNull()?.describe() ?: ""
        output.rodCalibration = r.configSummary.ifEmpty { output.rodCalibration }
        val roi = r.roi
        output.rodRoiNorm[0] = roi.left; output.rodRoiNorm[1] = roi.top
        output.rodRoiNorm[2] = roi.right; output.rodRoiNorm[3] = roi.bottom
        // V9 também não tem busca ampla separada: a janela *é* a área de busca
        output.rodSearchNorm[0] = roi.left; output.rodSearchNorm[1] = roi.top
        output.rodSearchNorm[2] = roi.right; output.rodSearchNorm[3] = roi.bottom
        output.rodCenterNorm[0] = if (r.targetFound) r.targetX else 0f
        output.rodCenterNorm[1] = if (r.targetFound) r.targetY else 0f
        // ---- os mesmos slots de debug que o overlay já desenha (janela/candidato/anterior) ---
        output.rodV8TargetFound = r.targetFound
        output.rodV8TargetNotFound = r.targetNotFound
        output.rodV8Recovering = r.recovering
        output.rodV8RecoveryStage = r.recoveryStage
        output.rodV8CandidateFound = r.candidateFound
        output.rodV8CandidateConfidence = r.confidence
        output.rodV8WindowExpanded = r.windowExpanded
        output.rodV8CandidateNorm[0] = if (r.candidateFound) r.candidatePx.x / r.frameW else 0f
        output.rodV8CandidateNorm[1] = if (r.candidateFound) r.candidatePx.y / r.frameH else 0f
        output.rodV8PreviousNorm[0] = if (r.previousX.isFinite()) r.previousX else 0f
        output.rodV8PreviousNorm[1] = if (r.previousY.isFinite()) r.previousY else 0f
        // ---- §8: visão específica da V9 (candidatos, escolhido, lastKnown, estado visual) ----
        output.rodV9DetectorState = r.detectorState.name
        output.rodV9ShowDetectionDebug = cfg.rodButtonV9.showDetectionDebug
        output.rodV9CandidateCount = min(r.candidateData.size, PipelineOutput.MAX_V9_CANDIDATES)
        for (i in 0 until output.rodV9CandidateCount) {
            val c = r.candidateData[i]
            output.rodV9CandidatesNorm[i * 2] = c.cx / r.frameW
            output.rodV9CandidatesNorm[i * 2 + 1] = c.cy / r.frameH
            output.rodV9CandidateScore[i] = c.score
            output.rodV9CandidateRadiusNorm[i] = c.r / r.frameW
        }
        val chosen = r.candidateData.firstOrNull()
        output.rodV9ChosenNorm[0] = if (r.candidateFound && chosen != null) chosen.cx / r.frameW else 0f
        output.rodV9ChosenNorm[1] = if (r.candidateFound && chosen != null) chosen.cy / r.frameH else 0f
        output.rodV9ChosenRadiusNorm = if (r.candidateFound && chosen != null) chosen.r / r.frameW else 0f
        output.rodV9ChosenScore = chosen?.score ?: 0f
        output.rodV9HasLastKnown = r.lastKnownX.isFinite()
        output.rodV9LastKnownNorm[0] = if (r.lastKnownX.isFinite()) r.lastKnownX else 0f
        output.rodV9LastKnownNorm[1] = if (r.lastKnownY.isFinite()) r.lastKnownY else 0f
        output.rodV9MsSinceConfirmed = r.msSinceConfirmed
        output.rodV9DebugText = "V9 ${r.state.name}/${r.detectorState.name} " +
            "roi=${r.roiString()} cands=${r.candidates} score=${"%.2f".format(r.score)} " +
            "conf=${"%.2f".format(r.confidence)} streak=${r.confirmation}/${r.requiredFrames} " +
            "lastKnown=${if (r.lastKnownX.isFinite()) "(${(r.lastKnownX * r.frameW).toInt()}," +
                "${(r.lastKnownY * r.frameH).toInt()})" else "(-)"} " +
            "etapa=${r.recoveryStage} expandida=${r.windowExpanded}"
        output.layerVision = "ACTIVE"
        output.layerDetection = "ACTIVE"
        output.layerDecision = if (safety.macroEnabled) "ACTIVE" else "IDLE"
        output.layerInput = if (RealInputPolicy.allows()) "ENABLED" else "DISABLED"
    }

    /** V7: publishes the detection-stack view (state, ROI, calibration, layers) for UI/logs. */
    private fun publishRodV7(snap: RodSnapshot) {
        output.rodDetector = "V7"
        // the V8/V9 debug views are only meaningful while those detectors are active
        output.rodV9CandidateCount = 0
        output.rodV9DebugText = ""
        output.rodV9DetectorState = "OFF"
        output.rodV9HasLastKnown = false
        output.rodV8TargetFound = false
        output.rodV8TargetNotFound = false
        output.rodV8Recovering = false
        output.rodV8RecoveryStage = 0
        output.rodV8CandidateFound = false
        output.rodV8CandidateConfidence = 0f
        output.rodV8WindowExpanded = false
        output.rodState = snap.state.name
        output.rodScore = snap.score
        output.rodCandidates = snap.candidates
        output.rodStreak = snap.streak
        output.rodRequiredFrames = snap.requiredFrames
        output.rodTracking = snap.tracking
        output.rodLostMs = snap.lostMs
        output.rodReason = snap.reason
        output.rodCalibrationDone = snap.calibrationDone
        output.rodCandidateDetail = snap.candidatesDetail
        val roi = snap.roi
        output.rodRoiNorm[0] = roi.left; output.rodRoiNorm[1] = roi.top
        output.rodRoiNorm[2] = roi.right; output.rodRoiNorm[3] = roi.bottom
        val search = snap.searchRegion
        output.rodSearchNorm[0] = search.left; output.rodSearchNorm[1] = search.top
        output.rodSearchNorm[2] = search.right; output.rodSearchNorm[3] = search.bottom
        output.rodCenterNorm[0] = snap.centerNorm.x; output.rodCenterNorm[1] = snap.centerNorm.y
        snap.calibration?.let { output.rodCalibration = it.describe() }
        output.layerVision = "ACTIVE"
        output.layerDetection = if (snap.calibrationDone) "ACTIVE" else "CALIBRATING"
        output.layerDecision = if (safety.macroEnabled) "ACTIVE" else "IDLE"
        output.layerInput = if (RealInputPolicy.allows()) "ENABLED" else "DISABLED"
    }

    /**
     * V7 — the finder speaks [RodSnapshot]; everything downstream (evidence, cast gate, output,
     * debug overlay) keeps consuming the [DetSnapshot] shape it already knows.
     */
    private fun applyRodSnapshot(snap: RodSnapshot) {
        rodOut.detected = snap.detected
        rodOut.confidence = snap.confidence
        rodOut.rawScore = snap.score
        rodOut.box.set(snap.box)
        rodOut.timestampNs = snap.calibration?.calibratedAtNs ?: 0L
        rodOut.streak = snap.streak
        rodOut.lostFrames = if (snap.detected) 0 else (snap.lostMs / 33L).toInt()
        rodOut.v0 = snap.radius
        rodOut.v1 = snap.score
        rodOut.v2 = if (snap.tracking) 1f else 0f
        rodOut.v3 = snap.candidates.toFloat()
    }

    /**
     * V8 §17 — the pipeline is the ONLY consumer of the detector result: it maps the moving-window
     * answer (`targetFound`, `targetX/targetY`, `confidence`, `state`) into the [DetSnapshot] shape
     * the rest of the pipeline (evidence, cast gate, debug) already consumes. The detector itself
     * runs no input; the decision → [InputSafetyGuard] → executor path below is untouched.
     */
    private fun applyRodV8Snapshot(snap: RodV8Result) {
        rodV8Out.copyFrom(snap)
        // `targetFound` is the TEMPORAL answer: a new cycle (WAITING_FOR_ROD/CASTING entry) demands a
        // fresh confirmation streak, and while that streak rebuilds the answer is "not confirmed yet"
        // even though the button is plainly visible. Downstream needs both facts separately — exactly
        // like the V7 path, where `detected` (button on screen) is independent from `confirmed`
        // (temporal gate). Conflating them would abort an in-flight cast the moment the gate resets.
        val seesTarget = snap.candidateFound || snap.state.isTracking
        rodOut.detected = seesTarget
        rodOut.confidence = if (seesTarget) snap.confidence else 0f
        rodOut.rawScore = snap.score
        if (seesTarget) {
            val cx = if (snap.targetFound) snap.centerPx.x else snap.candidatePx.x
            val cy = if (snap.targetFound) snap.centerPx.y else snap.candidatePx.y
            val r = if (snap.targetFound) snap.radiusPx else snap.candidateRadiusPx
            rodOut.box.set(cx - r, cy - r, cx + r, cy + r)
        } else {
            rodOut.box.set(0f, 0f, 0f, 0f)
        }
        rodOut.timestampNs = snap.frameTimestampNs
        rodOut.streak = snap.confirmation
        rodOut.lostFrames = if (snap.targetFound) 0 else (snap.lostMs / 33L).toInt()
        rodOut.v0 = snap.radiusPx
        rodOut.v1 = snap.score
        rodOut.v2 = if (snap.state.isTracking) 1f else 0f
        rodOut.v3 = snap.candidates.toFloat()
    }

    /**
     * V9 §10/§13 — o pipeline é o ÚNICO consumidor do resultado do detector: mapeia
     * `targetFound`, `targetX/targetY`, `confidence`, `state` para o [DetSnapshot] que o resto do
     * pipeline (evidências, cast gate, debug) já consome. O detector não roda input; o caminho
     * decisão → [InputSafetyGuard] → executor continua intocado.
     */
    private fun applyRodV9Snapshot(snap: RodV9Result) {
        rodV9Out.copyFrom(snap)
        // `targetFound` é a resposta TEMPORAL: um ciclo novo (entrada em WAITING_FOR_ROD/CASTING)
        // exige um streak novo, e enquanto esse streak é reconstruído a resposta é "ainda não
        // confirmado" mesmo com o botão visível. O downstream precisa das duas informações
        // separadas — exatamente como na V7, onde `detected` (botão na tela) é independente de
        // `confirmed` (porteira temporal).
        val seesTarget = snap.candidateFound || snap.state.isTracking
        rodOut.detected = seesTarget
        rodOut.confidence = if (seesTarget) snap.confidence else 0f
        rodOut.rawScore = snap.score
        if (seesTarget) {
            val cx = if (snap.targetFound) snap.centerPx.x else snap.candidatePx.x
            val cy = if (snap.targetFound) snap.centerPx.y else snap.candidatePx.y
            val r = if (snap.targetFound) snap.radiusPx else snap.candidateRadiusPx
            rodOut.box.set(cx - r, cy - r, cx + r, cy + r)
        } else {
            rodOut.box.set(0f, 0f, 0f, 0f)
        }
        rodOut.timestampNs = snap.frameTimestampNs
        rodOut.streak = snap.confirmation
        rodOut.lostFrames = if (snap.targetFound) 0 else (snap.lostMs / 33L).toInt()
        rodOut.v0 = snap.radiusPx
        rodOut.v1 = snap.score
        rodOut.v2 = if (snap.state.isTracking) 1f else 0f
        rodOut.v3 = snap.candidates.toFloat()
    }

    /** Optional user calibration; absent by default, the target is derived from the detected bar. */
    fun setHoldAnchor(nx: Float, ny: Float) {
        holdAnchorOverride = if (nx.isFinite() && ny.isFinite() && nx in 0f..1f && ny in 0f..1f) {
            GestureTarget(nx, ny)
        } else null
    }

    private val emergencyListener: () -> Unit = {
        runCatching { executor.cancelAll() }
        runCatching { executor.releaseAll() }
        realGestureActive = false
        holdActive = false
        holdTarget = null
        controller.reset()
    }

    init {
        emergency.addListener(emergencyListener)
    }

    fun onFrame(frame: VisionFrame, input: PipelineInput) {
        val startedNs = monotonicNowNs()
        val frameNs = frame.timestampNs
        val nowNs = input.currentTimeNs.takeIf { it > 0L } ?: frameNs
        val ageMs = if (frameNs <= 0L || nowNs < frameNs) Long.MAX_VALUE else (nowNs - frameNs) / 1_000_000L
        log.setNow(frameNs)
        frame.ensureGray()
        if (input.screenWidthPx > 0 && input.screenHeightPx > 0) {
            rodFinder.setScreenInfo(
                input.screenWidthPx, input.screenHeightPx, input.densityDpi, input.rotationDeg,
                input.appWindowWidthPx, input.appWindowHeightPx, input.statusBarPx, input.navBarPx,
            )
        }
        val w = frame.width
        val h = frame.height
        val rodV7 = output

        // Platform/session gates are refreshed before any decision. Unknown is false by design.
        safety.macroEnabled = armed && input.macroEnabled
        // V7 §10: the session-level hard lock is applied *here*, before anything else sees the
        // request. With the lock on (the V7 default) the pipeline behaves exactly as if the user
        // had never enabled real input — the layers below keep working, INPUT stays blocked.
        safety.realInputEnabled = input.realInputEnabled && RealInputPolicy.allows()
        safety.captureHealthy = input.captureHealthy
        safety.robloxDetected = input.robloxDetected
        safety.platformAuthorized = input.inputAuthorized
        safety.overlaySuspected = input.overlaySuspected
        safety.frameTimestampNs = frameNs
        safety.state = stateMachine.state

        if ((!input.inputAuthorized || !input.captureHealthy || !safety.macroEnabled ||
                !input.realInputEnabled || emergency.latched) && realGestureActive) {
            releaseActiveGesture(cancel = true)
        }

        runDetectors(frame)

        // ---- tracking ---------------------------------------------------------------------
        val barDetected = barDetector.out.detected
        val barLocked = barDetected && barTracker.update(
            barDetector.geometry.left,
            barDetector.geometry.top,
            barDetector.geometry.right,
            barDetector.geometry.bottom,
            max(barDetector.out.confidence, 0.6f),
            barRect,
        )
        if (barLocked) barTracker.touch(frameNs)
        val barWidth = max(1f, barRect[2] - barRect[0])

        if (barLocked) {
            blockDetector.setBarPrior(barRect[0], barRect[1], barRect[2], barRect[3])
            fishDetector.setBarPrior(barRect[0], barRect[1], barRect[2], barRect[3])
            progressDetector.setBarPrior(barRect[0], barRect[1], barRect[2], barRect[3])
        } else {
            blockDetector.clearBarPrior()
            fishDetector.clearBarPrior()
            progressDetector.clearBarPrior()
        }
        blockDetector.process(frame)
        if (barLocked && blockDetector.out.detected) {
            fishDetector.blockL = blockDetector.geom.left.toInt()
            fishDetector.blockR = blockDetector.geom.right.toInt()
        } else {
            fishDetector.blockL = -1
            fishDetector.blockR = -1
        }
        fishDetector.priorXNorm = if (fishTracker.out.valid) fishTracker.out.x else -1f
        fishDetector.process(frame)
        progressDetector.process(frame)

        if (barLocked) {
            if (blockDetector.out.detected) {
                blockTracker.update(
                    frameNs,
                    (blockDetector.geom.centerX - barRect[0]) / barWidth,
                    blockDetector.geom.width / barWidth,
                    blockDetector.out.confidence,
                    blockDetector.out.v0 > 0.5f,
                    barRect[0], barRect[2], blockDetector.geom.left, blockDetector.geom.right,
                )
            } else {
                blockTracker.update(frameNs, null, 0f, 0f, false, barRect[0], barRect[2], 0f, 0f)
            }
            if (fishDetector.out.detected) {
                fishTracker.update(frameNs, fishDetector.out.v0, fishDetector.out.confidence, barWidth)
            } else {
                fishTracker.update(frameNs, null, 0f, barWidth)
            }
        } else {
            blockTracker.reset()
            fishTracker.reset()
        }
        progressTracker.update(
            frameNs,
            if (progressDetector.out.detected) progressDetector.out.v0 else null,
            progressDetector.out.confidence,
        )
        confTracker.update(barDetector.out.confidence, fishTracker.out.confidence, blockTracker.out.confidence, frameNs)
        safety.trackingOk = fishTracker.out.valid && !fishTracker.out.lost &&
            blockTracker.out.valid && !blockTracker.out.lost &&
            fishTracker.out.confidence >= cfg.control.minConfidence &&
            blockTracker.out.confidence >= cfg.control.minConfidence

        // ---- state evidence ---------------------------------------------------------------
        evidence.fishingButton = rodOut.detected
        evidence.fishingButtonConf = rodOut.confidence
        evidence.shake = shakeDetector.out.detected
        evidence.shakeConf = shakeDetector.out.confidence
        evidence.bar = barDetector.out.detected
        evidence.barConf = barDetector.out.confidence
        evidence.fishOk = fishTracker.out.valid && !fishTracker.out.lost
        evidence.playerOk = blockTracker.out.valid && !blockTracker.out.lost
        evidence.progress = progressTracker.value
        evidence.catchConfirm = catchDetector.out.detected
        evidence.catchConfirmConf = catchDetector.out.confidence
        evidence.robloxForeground = input.inputAuthorized
        evidence.captureHealthy = input.captureHealthy
        evidence.overlaySuspected = input.overlaySuspected
        evidence.globalConf = confTracker.global
        evidence.shakeGone = shakeController.phase == ShakeController.Phase.SEARCHING && !shakeDetector.out.detected
        evidence.nowNs = frameNs
        evidence.dtSec = if (lastFrameNs == 0L) 1f / 30f
        else clamp((frameNs - lastFrameNs) / 1e9f, 0.001f, 0.25f)
        lastFrameNs = frameNs

        // ---- V5 rod-button gate (spec §3/§4/§5) ------------------------------------------
        // ROI-optimized detector → presence → confidence → temporal confirmation → safety gate.
        // The rod button is the only trigger that may start a cycle; nothing here sends input.
        val rodCx = if (rodOut.detected) rodOut.box.centerX / w else 0f
        val rodCy = if (rodOut.detected) rodOut.box.centerY / h else 0f
        // V7: the temporal gate lives inside the finder (FPS-adaptive confirmation streak,
        // confidence vs. the calibrated threshold, center stability in radius-relative units).
        // V8: the moving-window detector only reports `targetFound` after its own confirmation
        // streak (spec §14) — both answers are equally temporal, never a single frame.
        val rodConfirmed = when {
            // V9: o detector visual só devolve `targetFound` depois da confirmação temporal (§5)
            useRodV9 -> rodV9Out.targetFound && rodV9Out.state.isTracking && !rodV9Out.targetNotFound
            useRodV8 -> rodV8Out.targetFound && rodV8Out.state.isTracking && !rodV8Out.targetNotFound
            else -> rodFinder.out.confirmed
        }
        val castGate = guard.evaluateCastGate(
            safety, rodOut.confidence, rodCx, rodCy, nowNs, emergency,
        )
        evidence.rodConfirmed = rodConfirmed
        evidence.castAuthorized = castGate.allowed
        evidence.castComplete = pendingCastComplete
        evidence.castAborted = pendingCastAborted
        pendingCastComplete = false
        pendingCastAborted = false

        val oldState = stateMachine.state
        stateMachine.armed = safety.macroEnabled
        stateMachine.update(evidence)
        val state = stateMachine.state
        safety.state = state
        if (state != oldState) {
            log.i(Tags.STATE, "st", "[STATE] ${oldState.name} -> ${state.name} (${stateMachine.lastReason})")
            if ((oldState == FishingState.CASTING && state != FishingState.CASTING) ||
                (oldState.isMinigame() && !state.isMinigame()) || state.isError) {
                releaseActiveGesture(cancel = state.isError)
            }
            onStateEntry(state, frameNs)
        }

        // ---- controllers ------------------------------------------------------------------
        var request: InputRequest? = null
        var reason = ""
        var intendedAction = ControlAction.NONE
        var reportedDurationMs = 0

        if (state == FishingState.CASTING) {
            val press = castController.tick(
                rodOut.detected,
                rodOut.confidence,
                if (rodOut.detected) rodOut.box.centerX / w else 0f,
                if (rodOut.detected) rodOut.box.centerY / h else 0f,
                frameNs,
            )
            if (press != null) {
                reason = press.reason
                reportedDurationMs = cfg.cast.holdMs.toInt()
                val action = when (press.action) {
                    CastGestureAction.START -> GestureAction.HOLD_START
                    CastGestureAction.EXTEND -> GestureAction.HOLD_EXTEND
                    CastGestureAction.RELEASE -> GestureAction.HOLD_RELEASE
                }
                if (action == GestureAction.HOLD_START) {
                    holdTarget = GestureTarget(press.nx, press.ny)
                    holdActive = true
                }
                if (action == GestureAction.HOLD_RELEASE) {
                    holdActive = false
                    // consumed by the FSM on the next frame: finished cast → WAITING_FOR_WATER,
                    // aborted cast (target lost) → back to WAITING_FOR_ROD
                    pendingCastComplete = castController.releaseWasComplete
                    pendingCastAborted = !castController.releaseWasComplete
                }
                safety.controllerSafe = action == GestureAction.HOLD_RELEASE ||
                    (press.confidence.isFinite() && press.confidence >= cfg.cast.minConfidence &&
                        press.nx.isFinite() && press.nx in 0f..1f &&
                        press.ny.isFinite() && press.ny in 0f..1f)
                request = InputRequest(
                    action = action,
                    nx = press.nx,
                    ny = press.ny,
                    durationMs = if (action == GestureAction.HOLD_RELEASE) 0L else cfg.safety.maxHoldLeaseMs,
                    confidence = press.confidence,
                    reason = reason,
                )
            }
        }

        if (stateMachine.shakePhaseActive()) {
            val cx = if (shakeDetector.out.detected) shakeDetector.out.box.centerX / w else -1f
            val cy = if (shakeDetector.out.detected) shakeDetector.out.box.centerY / h else -1f
            val tap = shakeController.tick(shakeDetector.out.detected, shakeDetector.out.confidence, cx, cy, frameNs)
            if (tap != null) {
                reason = tap.reason
                reportedDurationMs = tap.durMs
                safety.controllerSafe = shakeDetector.out.detected &&
                    shakeDetector.out.confidence.isFinite() &&
                    shakeDetector.out.confidence >= cfg.shake.minConfidence &&
                    tap.nx.isFinite() && tap.nx in 0f..1f &&
                    tap.ny.isFinite() && tap.ny in 0f..1f &&
                    tap.durMs.toLong() in 1L..cfg.safety.maxTapMs
                request = InputRequest(
                    GestureAction.TAP,
                    tap.nx,
                    tap.ny,
                    tap.durMs.toLong(),
                    shakeDetector.out.confidence,
                    tap.reason,
                )
            }
        }

        if (barLocked && state.controlling) {
            val decision = controller.update(
                frameNs,
                evidence.dtSec,
                fishTracker.out,
                blockTracker.out,
                progressTracker.rate,
            )
            safety.controllerSafe = decision.safe
            intendedAction = decision.action
            reason = decision.reason
            output.errorNorm = decision.error
            output.fishVel = decision.fishVel
            output.playerVel = decision.playerVel
            output.desiredVel = decision.desiredVel
            val target = holdAnchorOverride ?: GestureTarget(
                ((barRect[0] + barRect[2]) * 0.5f / w).coerceIn(0f, 1f),
                ((barRect[1] + barRect[3]) * 0.5f / h).coerceIn(0f, 1f),
            )
            val confidence = minOf(fishTracker.out.confidence, blockTracker.out.confidence)
            when (decision.action) {
                ControlAction.TAP -> {
                    request = InputRequest(
                        GestureAction.TAP,
                        target.x,
                        target.y,
                        decision.tapDurMs.toLong(),
                        confidence,
                        decision.reason,
                    )
                    reportedDurationMs = decision.tapDurMs
                }
                ControlAction.HOLD_START -> {
                    holdTarget = target
                    holdActive = true
                    request = InputRequest(
                        GestureAction.HOLD_START,
                        target.x,
                        target.y,
                        cfg.safety.maxHoldLeaseMs,
                        confidence,
                        decision.reason,
                    )
                    reportedDurationMs = cfg.safety.maxHoldLeaseMs.toInt()
                }
                ControlAction.HOLD_EXTEND -> {
                    val activeTarget = holdTarget ?: target.also { holdTarget = it }
                    request = InputRequest(
                        GestureAction.HOLD_EXTEND,
                        activeTarget.x,
                        activeTarget.y,
                        cfg.safety.maxHoldLeaseMs,
                        confidence,
                        decision.reason,
                    )
                    reportedDurationMs = cfg.safety.maxHoldLeaseMs.toInt()
                }
                ControlAction.HOLD_RELEASE -> {
                    holdActive = false
                    request = InputRequest(GestureAction.HOLD_RELEASE, reason = decision.reason)
                }
                ControlAction.NONE -> Unit
            }
            lastActionName = decision.action
        } else {
            if (holdActive && !state.isMinigame() && state != FishingState.CASTING) {
                holdActive = false
                request = InputRequest(GestureAction.HOLD_RELEASE, reason = "state no longer permits hold")
            }
            if (!state.isMinigame()) {
                controller.reset()
                lastActionName = ControlAction.NONE
                output.errorNorm = 0f
                output.fishVel = 0f
                output.playerVel = 0f
                output.desiredVel = 0f
            }
        }

        // A safe-release directive always wins over any earlier command from the frame.
        if (emergency.latched || !input.captureHealthy || !input.inputAuthorized || !safety.macroEnabled ||
            !input.realInputEnabled
        ) {
            if (realGestureActive) request = InputRequest(GestureAction.CANCEL_ALL, reason = "safety context lost")
        }

        // ---- single input safety gate -----------------------------------------------------
        var denied = DenyReason.OK
        var issued = false
        request?.let { original ->
            val platformHoldDown = executor.holdStillActive()
            if (original.action == GestureAction.HOLD_EXTEND && realGestureActive && platformHoldDown == false) {
                // The platform ended the hold on its own (lease/watchdog/Android cancel). Never
                // keep "extending" a finger that is no longer down — re-press through the guard.
                log.w(Tags.INPUT, "hold-lost", "[INPUT] platform hold ended; re-issuing HOLD_START")
                realGestureActive = false
            }
            val effective = when {
                original.action == GestureAction.HOLD_EXTEND && !realGestureActive ->
                    original.copy(action = GestureAction.HOLD_START)
                else -> original
            }
            if (effective.action == GestureAction.HOLD_RELEASE || effective.action == GestureAction.CANCEL_ALL) {
                if (effective.action == GestureAction.CANCEL_ALL) executor.cancelAll() else executor.holdRelease()
                realGestureActive = false
                holdTarget = null
            } else {
                safety.targetConfidence = effective.confidence
                val verdict = guard.evaluate(safety, effective, nowNs, emergency)
                if (!verdict.allowed) {
                    denied = verdict.reason
                    log.w(Tags.SAFETY, "deny", "[SAFETY] INPUT BLOCKED reason=${verdict.reason.name} package=${input.foregroundPackage} frameAge=${ageMs}ms")
                    if (realGestureActive) releaseActiveGesture(cancel = true)
                } else if (!input.realInputEnabled) {
                    // Normally caught by the guard; retained explicitly as a defense-in-depth
                    // assertion. Simulation still publishes the controller's intended action.
                    denied = DenyReason.REAL_INPUT_DISABLED
                } else {
                    val authorizeSegment = {
                        refreshPlatformSafety()
                        safety.targetConfidence = effective.confidence
                        val liveNow = monotonicNowNs()
                        guard.evaluate(safety, effective, liveNow, emergency).allowed
                    }
                    val accepted = when (effective.action) {
                        GestureAction.TAP -> executor.tap(
                            effective.nx, effective.ny, effective.durationMs.toInt(), authorizeSegment,
                        )
                        GestureAction.HOLD_START -> executor.holdStart(
                            effective.nx, effective.ny, effective.durationMs.toInt(), authorizeSegment,
                        )
                        GestureAction.HOLD_EXTEND -> executor.holdExtend(
                            effective.nx, effective.ny, effective.durationMs.toInt(), authorizeSegment,
                        )
                        else -> false
                    }
                    if (accepted) {
                        issued = true
                        if (effective.action == GestureAction.HOLD_START || effective.action == GestureAction.HOLD_EXTEND) {
                            realGestureActive = true
                            holdTarget = GestureTarget(effective.nx, effective.ny)
                        }
                        safety.lastInputNs = nowNs
                        log.i(
                            Tags.INPUT,
                            "gesture",
                            "[INPUT] ${effective.action.name} x=${"%.3f".format(effective.nx)} y=${"%.3f".format(effective.ny)} duration=${effective.durationMs}ms confidence=${"%.2f".format(effective.confidence)}",
                        )
                    } else {
                        denied = DenyReason.INVALID_COMMAND
                        if (effective.action == GestureAction.HOLD_START || effective.action == GestureAction.HOLD_EXTEND) {
                            realGestureActive = false
                        }
                        log.w(Tags.INPUT, "dispatch", "[INPUT] gesture dispatch rejected")
                    }
                }
            }
        }

        if (ageMs > cfg.safety.maxFrameAgeMs && denied == DenyReason.OK && request != null) {
            denied = DenyReason.FRAME_STALE
        }
        val safetyBasePass = safety.macroEnabled && safety.realInputEnabled && safety.captureHealthy &&
            safety.robloxDetected && safety.platformAuthorized && !safety.overlaySuspected &&
            !emergency.latched && ageMs in 0..cfg.safety.maxFrameAgeMs

        // ---- outputs / debug snapshot -----------------------------------------------------
        with(output) {
            fishingButton.copyFrom(rodOut)
            shake.copyFrom(shakeDetector.out)
            bar.copyFrom(barDetector.out)
            player.copyFrom(blockDetector.out)
            fish.copyFrom(fishDetector.out)
            progress.copyFrom(progressDetector.out)
            catchConfirm.copyFrom(catchDetector.out)
            this.state = state
            this.stateReason = stateMachine.lastReason
            this.fishXNorm = fishTracker.out.x
            this.playerXNorm = blockTracker.out.x
            this.progressValue = max(0f, progressTracker.value)
            this.progressRate = progressTracker.rate
            this.globalConfidence = confTracker.global
            this.frameAgeMs = ageMs
            this.intendedAction = intendedAction
            this.tapDurationMs = reportedDurationMs
            this.holdActive = holdActive
            this.decisionReason = reason
            this.inputIssued = issued
            this.inputDeniedReason = if (denied == DenyReason.OK) "" else denied.name
            this.inputAuthorized = safetyBasePass
            this.realInputEnabled = safety.realInputEnabled
            this.robloxDetected = input.robloxDetected
            this.foregroundPackage = input.foregroundPackage
            this.foregroundActivityWindow = input.foregroundActivityWindow
            this.foregroundBlockReason = input.foregroundBlockReason
            this.emergencyLatched = emergency.latched
            this.armed = safety.macroEnabled
            this.shakeSessionTaps = shakeController.tapsThisSession
            this.shakeSession = stateMachine.shakeSession
            this.castPhase = castController.phase.name
            this.rodDetected = rodOut.detected
            this.rodConfidence = rodOut.confidence
            when {
                useRodV9 -> publishRodV9(rodV9Out)
                useRodV8 -> publishRodV8(rodV8Out)
                else -> publishRodV7(rodFinder.out)
            }
            this.rodConfirmed = rodConfirmed
            this.castAuthorized = castGate.allowed
            this.castGateReason = if (castGate.allowed) "" else castGate.reason.name
            this.barRectPx[0] = barRect[0]
            this.barRectPx[1] = barRect[1]
            this.barRectPx[2] = barRect[2]
            this.barRectPx[3] = barRect[3]
            this.barLocked = barLocked
            this.blockCenterPx = if (blockDetector.out.detected) blockDetector.geom.centerX else -1f
            this.fishCenterPx = if (fishDetector.out.detected) (fishDetector.out.box.left + fishDetector.out.box.right) / 2f else -1f
        }
        render = RenderModel(
            state = state,
            fps = lastFps,
            procMs = (monotonicNowNs() - startedNs) / 1e6f,
            barBox = if (barLocked) floatArrayOf(barRect[0] / w, barRect[1] / h, barRect[2] / w, barRect[3] / h) else null,
            blockBox = normBox(blockDetector.out, w, h),
            fishBox = normBox(fishDetector.out, w, h),
            shakeBox = normBox(shakeDetector.out, w, h),
            rodBox = normBox(rodOut, w, h),
            progressBox = normBox(progressDetector.out, w, h),
            fishCx = fishTracker.out.x,
            playerCx = blockTracker.out.x,
            error = output.errorNorm,
            fishVel = output.fishVel,
            playerVel = output.playerVel,
            desiredVel = output.desiredVel,
            action = lastActionName.name,
            actionReason = reason,
            progress = output.progressValue,
            progressRate = output.progressRate,
            confGlobal = confTracker.global,
            confBar = confTracker.bar,
            confFish = confTracker.fish,
            confPlayer = confTracker.player,
            confShake = shakeDetector.out.confidence,
            confRod = rodOut.confidence,
            rodConfirmed = rodConfirmed,
            castAuthorized = castGate.allowed,
            holdActive = holdActive,
            tapsThisSession = shakeController.tapsThisSession,
            shakeSession = stateMachine.shakeSession,
            denyReason = if (denied == DenyReason.OK) "" else denied.name,
            emergency = emergency.latched,
            armed = safety.macroEnabled,
            robloxDetected = input.robloxDetected,
            foregroundPackage = input.foregroundPackage,
            foregroundWindow = input.foregroundActivityWindow,
            inputAuthorized = safetyBasePass,
            realInputEnabled = safety.realInputEnabled,
            frameAgeMs = ageMs,
            safetyBlockedReason = when {
                denied != DenyReason.OK -> denied.name
                !RealInputPolicy.allows() -> "REAL_INPUT_LOCKED_V7"
                !safetyBasePass -> if (!safety.realInputEnabled) "REAL_INPUT_DISABLED" else input.foregroundBlockReason
                else -> "PASS"
            },
            rodState = rodV7.rodState,
            rodScore = rodV7.rodScore,
            rodCandidates = rodV7.rodCandidates,
            rodStreak = rodV7.rodStreak,
            rodRequiredFrames = rodV7.rodRequiredFrames,
            rodTracking = rodV7.rodTracking,
            rodLostMs = rodV7.rodLostMs,
            rodReason = rodV7.rodReason,
            rodRoiBox = if (useRodV9 || useRodV8 || rodV7.rodTracking || rodV7.rodState == "ROD_CONFIRMED")
                floatArrayOf(rodV7.rodRoiNorm[0], rodV7.rodRoiNorm[1], rodV7.rodRoiNorm[2], rodV7.rodRoiNorm[3]) else null,
            rodSearchBox = floatArrayOf(
                rodV7.rodSearchNorm[0], rodV7.rodSearchNorm[1],
                rodV7.rodSearchNorm[2], rodV7.rodSearchNorm[3],
            ),
            rodCenterNorm = if (rodOut.detected) floatArrayOf(rodV7.rodCenterNorm[0], rodV7.rodCenterNorm[1]) else null,
            rodCalibrationDone = rodV7.rodCalibrationDone,
            rodCalibration = rodV7.rodCalibration,
            rodCandidateDetail = rodV7.rodCandidateDetail,
            layerVision = rodV7.layerVision,
            layerDetection = rodV7.layerDetection,
            layerDecision = rodV7.layerDecision,
            layerInput = rodV7.layerInput,
            // V8 §16: moving-window debug view (window, candidate, previous position, recovery)
            rodDetector = rodV7.rodDetector,
            rodV8WindowBox = if (useRodV9 || useRodV8) {
                floatArrayOf(
                    rodV7.rodRoiNorm[0], rodV7.rodRoiNorm[1],
                    rodV7.rodRoiNorm[2], rodV7.rodRoiNorm[3],
                )
            } else null,
            rodV8CandidateNorm = if ((useRodV9 || useRodV8) && rodV7.rodV8CandidateFound) {
                floatArrayOf(rodV7.rodV8CandidateNorm[0], rodV7.rodV8CandidateNorm[1])
            } else null,
            rodV8CandidateConfidence = rodV7.rodV8CandidateConfidence,
            rodV8PreviousNorm = if ((useRodV9 || useRodV8) &&
                (rodV7.rodV8PreviousNorm[0] != 0f || rodV7.rodV8PreviousNorm[1] != 0f)
            ) {
                floatArrayOf(rodV7.rodV8PreviousNorm[0], rodV7.rodV8PreviousNorm[1])
            } else null,
            rodV8TargetFound = rodV7.rodV8TargetFound,
            rodV8TargetNotFound = rodV7.rodV8TargetNotFound,
            rodV8Recovering = rodV7.rodV8Recovering,
            rodV8RecoveryStage = rodV7.rodV8RecoveryStage,
            rodV8WindowExpanded = rodV7.rodV8WindowExpanded,
            // ---- V9 §8: candidatos, escolhido, lastKnown, estado visual e flag de debug -------
            rodV9DetectorState = rodV7.rodV9DetectorState,
            rodV9ShowDetectionDebug = rodV7.rodV9ShowDetectionDebug,
            rodV9CandidatesNorm = if (useRodV9 && rodV7.rodV9CandidateCount > 0) {
                FloatArray(rodV7.rodV9CandidateCount * 2) { i -> rodV7.rodV9CandidatesNorm[i] }
            } else null,
            rodV9CandidateScores = if (useRodV9 && rodV7.rodV9CandidateCount > 0) {
                FloatArray(rodV7.rodV9CandidateCount) { i -> rodV7.rodV9CandidateScore[i] }
            } else null,
            rodV9CandidateRadiiNorm = if (useRodV9 && rodV7.rodV9CandidateCount > 0) {
                FloatArray(rodV7.rodV9CandidateCount) { i -> rodV7.rodV9CandidateRadiusNorm[i] }
            } else null,
            rodV9ChosenNorm = if (useRodV9 && rodV7.rodV9CandidateCount > 0) {
                floatArrayOf(rodV7.rodV9ChosenNorm[0], rodV7.rodV9ChosenNorm[1])
            } else null,
            rodV9ChosenRadiusNorm = rodV7.rodV9ChosenRadiusNorm,
            rodV9ChosenScore = rodV7.rodV9ChosenScore,
            rodV9LastKnownNorm = if (useRodV9 && rodV7.rodV9HasLastKnown) {
                floatArrayOf(rodV7.rodV9LastKnownNorm[0], rodV7.rodV9LastKnownNorm[1])
            } else null,
            rodV9MsSinceConfirmed = rodV7.rodV9MsSinceConfirmed,
            rodV9DebugText = if (useRodV9) rodV7.rodV9DebugText else "",
        )

        if (frameNs - lastInputLogNs >= 1_000_000_000L || lastInputLogNs == 0L) {
            lastInputLogNs = frameNs
            // V5 §20 test-mode line: one compact, greppable status per second for the A22.
            log.i(
                Tags.STATE,
                "watch",
                "[STATE] STATE=${state.name} ROD_DETECTED=${rodOut.detected} " +
                    "ROD_CONFIDENCE=${"%.2f".format(rodOut.confidence)} ROD_CONFIRMED=$rodConfirmed " +
                    "ROBLOX=${input.robloxDetected} INPUT_AUTHORIZED=$safetyBasePass " +
                    "DECISION=${when {
                        state == FishingState.CASTING -> "CASTING"
                        rodConfirmed && !castGate.allowed -> "WOULD_CAST"
                        else -> intendedAction.name
                    }} " +
                    "ACTION=${request?.action?.name ?: "NONE"} " +
                    "BLOCK_REASON=${when {
                        denied != DenyReason.OK -> denied.name
                        state == FishingState.WAITING_FOR_ROD && rodConfirmed && !castGate.allowed -> castGate.reason.name
                        !safetyBasePass -> input.foregroundBlockReason
                        else -> "NONE"
                    }}",
            )
            log.i(
                Tags.SAFETY,
                "snapshot",
                "[SAFETY] foregroundPackage=${input.foregroundPackage} foregroundActivity/window=${input.foregroundActivityWindow} robloxDetected=${input.robloxDetected} inputAuthorized=${safetyBasePass} blockReason=${input.foregroundBlockReason} frameAge=${ageMs}ms realInput=${input.realInputEnabled}",
            )
            log.i(
                Tags.TRACKING,
                "tracks",
                "[TRACK] fish=${"%.3f".format(fishTracker.out.x)} v=${"%+.3f".format(fishTracker.out.v)} conf=${"%.2f".format(fishTracker.out.confidence)} player=${"%.3f".format(blockTracker.out.x)} v=${"%+.3f".format(blockTracker.out.v)} conf=${"%.2f".format(blockTracker.out.confidence)} progress=${"%.2f".format(progressTracker.value)}",
            )
            log.i(
                Tags.CONTROL,
                "decision",
                "[CONTROL] state=${state.name} error=${"%+.3f".format(output.errorNorm)} action=${request?.action ?: intendedAction} reason=$reason",
            )
        }
    }

    private var lastInputLogNs = 0L

    private fun refreshPlatformSafety() {
        val status = runCatching { foregroundStatusProvider?.invoke() }.getOrNull()
        if (status == null) {
            safety.robloxDetected = false
            safety.platformAuthorized = false
            safety.overlaySuspected = true
            return
        }
        safety.robloxDetected = status.robloxDetected
        safety.platformAuthorized = status.inputAuthorized
        safety.overlaySuspected = status.overlayActive
    }

    private fun releaseActiveGesture(cancel: Boolean) {
        if (cancel) runCatching { executor.cancelAll() }
        runCatching { executor.releaseAll() }
        realGestureActive = false
        holdActive = false
        holdTarget = null
    }

    private fun onStateEntry(state: FishingState, nowNs: Long) {
        when (state) {
            FishingState.WAITING_FOR_ROD -> {
                // a new cycle may only begin after a FRESH visual confirmation of the rod button
                requireFreshRodConfirmation("WAITING_FOR_ROD")
            }
            FishingState.SEARCHING_SHAKE -> {
                shakeController.resetSession()
                castController.onShakeOrBarSeen(nowNs)
            }
            FishingState.CASTING -> {
                castController.start()
                requireFreshRodConfirmation("CASTING")
            }
            FishingState.FISHING_MINIGAME_DETECTED -> {
                controller.reset()
                holdActive = false
                fishTracker.reset()
                blockTracker.reset()
                progressTracker.reset()
            }
            FishingState.RESET -> {
                shakeController.resetSession()
                castController.reset()
                controller.reset()
                holdActive = false
                catchDetector.reset()
            }
            FishingState.CATCH_CONFIRMATION -> catchDetector.noteBarGone(nowNs)
            FishingState.VISION_LOST,
            FishingState.CAPTURE_ERROR,
            FishingState.ROBLOX_NOT_DETECTED,
            FishingState.EMERGENCY_STOP,
            FishingState.INVALID_STATE -> {
                releaseActiveGesture(cancel = true)
                controller.reset()
                fishTracker.reset()
                blockTracker.reset()
            }
            else -> Unit
        }
    }

    /** Routes the "fresh confirmation" requirement to whichever detector is the active one. */
    private fun requireFreshRodConfirmation(reason: String) {
        when {
            useRodV9 -> rodV9.requireFreshConfirmation(reason)
            useRodV8 -> rodV8.requireFreshConfirmation(reason)
            else -> rodFinder.requireFreshConfirmation(reason)
        }
    }

    private fun runDetectors(frame: VisionFrame) {
        when {
            useRodV9 -> applyRodV9Snapshot(rodV9.update(frame, lastFps, frame.timestampNs))
            useRodV8 -> applyRodV8Snapshot(rodV8.update(frame, lastFps, frame.timestampNs))
            else -> applyRodSnapshot(rodFinder.update(frame, lastFps, frame.timestampNs))
        }
        shakeDetector.process(frame)
        shakeDetector.process(frame)
        barDetector.process(frame)
        catchDetector.process(frame)
    }

    fun setFpsMeasured(fps: Float) { lastFps = fps }

    /** User-initiated disarm; gesture cleanup does not require authorization. */
    fun disarm(nowNs: Long) {
        armed = false
        stateMachine.armed = false
        safety.macroEnabled = false
        releaseActiveGesture(cancel = true)
        controller.reset()
        log.i(Tags.SYSTEM, "disarm", "[SYSTEM] macro disarmed at $nowNs")
    }

    override fun close() {
        disarm(monotonicNowNs())
        emergency.removeListener(emergencyListener)
    }

    private fun FishingState.isMinigame() = controlling
}
