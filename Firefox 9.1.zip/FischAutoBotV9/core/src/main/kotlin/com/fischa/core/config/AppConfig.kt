package com.fischa.core.config

/**
 * Which search policy drives the rod detector (`VisionPipeline`).
 *
 *  - [V9] — **moving window + visual detector V9** (spec *Rod Detection V9*): the same square
 *    window the V8 validated, but the *visual identification* of the rod button is now done by
 *    [com.fischa.core.vision.RodButtonDetectorV9] (multi-cue candidates + scored confidence)
 *    instead of the legacy “dark disc / ring” requirement. Default.
 *  - [V8] — **moving window** with the legacy visual mechanism (spec *Rod Detection V8*). Kept
 *    intact so the two visual detectors can be compared A/B on the same screen.
 *  - [V7] — the previous auto-calibrated wide search. Kept so the behaviour can be compared A/B
 *    on device; it is **not** used unless explicitly selected here.
 */
enum class RodDetectorKind { V9, V8, V7 }

/**
 * Single source of truth for every tunable in the system.
 *
 * Rules enforced by this class:
 *  - no absolute screen coordinates anywhere (geometry is expressed as fractions of the
 *    processed frame, i.e. resolution/orientation independent);
 *  - no hardcoded shake counts / minigame durations / fish speeds;
 *  - time constants in seconds, angles/sizes as fractions of frame width/height.
 *
 * Serialized with [toMap]/[fromMap] so the Android Settings UI and the replay harness share
 * one representation.
 */
data class AppConfig(
    val capture: Capture = Capture(),
    val vision: Vision = Vision(),
    val tracking: Tracking = Tracking(),
    val control: Control = Control(),
    val shake: Shake = Shake(),
    val cast: Cast = Cast(),
    val rod: Rod = Rod(),
    /** V7 auto-calibrated rod detection (spec V7). */
    val rodV7: RodV7 = RodV7(),
    /** which detector is the *main* one (V9 by default — spec V9 §13: only the visual chain changes). */
    val rodDetector: RodDetectorKind = RodDetectorKind.V9,
    /** V8 moving-window rod detection (spec Rod Detection V8). */
    val rodV8: RodV8 = RodV8(),
    /**
     * V9 — janela móvel (preservada da V8) + **detector visual V9** (spec Rod Detection V9).
     * É o bloco que o `VisionPipeline → RodDetectionV9 → RodButtonDetectorV9` consome.
     */
    val rodButtonV9: RodButtonV9 = RodButtonV9(),
    val state: StateTiming = StateTiming(),
    val safety: Safety = Safety(),
) {

    data class Capture(
        /** Width the frame is rescaled to before vision processing (keeps aspect). */
        val processingWidth: Int = 640,
        /** Target pipeline rate; capture may run faster, processing is rate-limited. */
        val targetFps: Int = 30,
        /** Ring size of the shared frame buffer (older entries get overwritten). */
        val bufferSlots: Int = 3,
        /** Drop the incoming frame if the consumer is slower than this (backpressure). */
        val maxQueueLatencyMs: Int = 220,
        /** Consider the capture stream dead after this long without a new frame. */
        val streamTimeoutMs: Long = 2500,
        /**
         * V6 §20: how long START/DIAGNÓSTICO waits for the first frame before declaring the
         * capture broken. The A22 (Android 13) typically delivers it within 300–900 ms.
         */
        val firstFrameTimeoutMs: Long = 2500,
    )

    data class Vision(
        // -- fishing (rod) button --
        val rodSearchX0: Float = 0.55f, val rodSearchX1: Float = 1.0f,
        val rodSearchY0: Float = 0.40f, val rodSearchY1: Float = 0.95f,
        val rodRadiusMinF: Float = 0.040f, val rodRadiusMaxF: Float = 0.085f,
        /** Interior of the rod button is dark; ring is brighter than both sides. */
        val rodInteriorMaxGray: Int = 90,
        val rodRingMinDelta: Int = 18,
        val rodPriorCx: Float = 0.818f, val rodPriorCy: Float = 0.692f,
        val rodPriorWeight: Float = 0.25f,

        // -- shake prompt --
        val shakeRadiusMinF: Float = 0.055f, val shakeRadiusMaxF: Float = 0.105f,
        /** Shake text glyphs are white on dark. */
        val shakeGlyphMinGray: Int = 205,
        val shakeInteriorMaxGray: Int = 70,
        val shakeRingMinDelta: Int = 14,
        /** ignore the very top (roblox/system HUD) and bottom hotbar strips */
        val shakeSearchY0: Float = 0.06f, val shakeSearchY1: Float = 0.98f,
        val shakeSearchX0: Float = 0.02f, val shakeSearchX1: Float = 1.0f,

        // -- minigame bar --
        val barSearchY0: Float = 0.55f, val barSearchY1: Float = 0.88f,
        val barMinWidthF: Float = 0.14f, val barMaxWidthF: Float = 0.72f,
        val barMinHeightF: Float = 0.016f, val barMaxHeightF: Float = 0.065f,
        /** interior gray window of the dark bar (measured 18..30; tolerant band for lighting) */
        val barDarkMin: Int = 8, val barDarkMax: Int = 140,
        val barDarkColFrac: Float = 0.42f,
        val barDarkRowFrac: Float = 0.30f,
        val barDarkMaxChroma: Int = 80,
        /** a bar pixel must be darker than the world [bar] rows below it (night water is dark
         *  in absolute terms too — the relative test is what separates them) */
        val barBgBelowOffset: Int = 24,
        val barBgBelowDelta: Int = 18,
        /** non-dark columns tolerated while growing a bar run (fish icon, borders) */
        val barGrowMaxHoles: Int = 6,
        /** red end-cap triangles are strong evidence of bar edges */
        val barEndCapWeight: Float = 0.30f,

        // -- white player block --
        val blockMinWidthF: Float = 0.06f, val blockMaxWidthF: Float = 0.45f,
        val blockWhiteMinGray: Int = 185,
        /** tint when fish outside the block: measured val~64 red hue */
        val mismatchSatMin: Int = 45, val mismatchValMin: Int = 35, val mismatchValMax: Int = 170,

        // -- fish indicator --
        val fishNeedleMinGray: Int = 88, val fishNeedleMaxGray: Int = 215,
        val fishDarkMinGray: Int = 32, val fishDarkMaxGray: Int = 125, // needle inside white block
        val fishNeedleAbovePx: Int = 26, // search height above bar top, at 640w scale
        val fishNeedleMinRunF: Float = 0.10f, // as fraction of bar width for scoring

        // -- progress --
        val progressSearchBelowF: Float = 0.30f,
        val progressMinWidthFracOfBar: Float = 0.35f,
        val progressMaxWidthFracOfBar: Float = 1.15f,
        val progressFillMinGray: Int = 175,
        val progressOutlineMinGray: Int = 118,

        // -- hud presence (roblox alive signal) --
        /** sample strips where the standard Roblox hud sits: top-left menu + right rod area */
        val hudTopStripH: Float = 0.16f,
    )

    data class Tracking(
        val fishAlpha: Float = 0.55f,
        val fishBeta: Float = 0.30f,
        /** innovation (in normalized bar units) beyond which a jump re-syncs hard */
        val fishJumpResyncNorm: Float = 0.22f,
        val fishMaxLostMs: Long = 420,
        val blockAlpha: Float = 0.62f,
        val blockMaxLostMs: Long = 500,
        val barAlpha: Float = 0.35f,
        val barLockMinConf: Float = 0.55f,
        val barUnlockConf: Float = 0.30f,
        val confEmaAlpha: Float = 0.45f,
        val confDecayPerSec: Float = 1.8f,
    )

    data class Control(
        /** normalized deadband on |error| (fraction of bar width). Inside it we do nothing. */
        val deadband: Float = 0.030f,
        val tapBand: Float = 0.075f,          // deadband..tapBand -> short taps
        val holdBand: Float = 0.155f,          // beyond -> sustained hold
        val kP: Float = 4.2f,                  // proportional gain (1/s)
        val kFF: Float = 1.15f,                // fish-velocity feedforward gain
        val kDrift: Float = 0.55f,             // leftward drift compensation added when aligned
        val lookaheadSec: Float = 0.10f,       // prediction horizon for fish position
        val lookaheadVelClamp: Float = 0.55f,  // normalized units/s cap used by lookahead
        val minHoldMs: Int = 90,
        val minReleaseMs: Int = 55,
        val minTapGapMs: Int = 70,             // avoid useless press spam
        val tapDurMs: Int = 120,               // single short tap length
        val maxHoldMs: Int = 2200,             // hold is re-evaluated after this even if error persists
        /**
         * The game's mobile control is "tap & hold anywhere"; on Android without root we
         * emulate a hold as a cadence of overlapping-duration taps (see docs/LIMITATIONS.md).
         */
        val tapHoldPeriodMs: Int = 280,
        val tapHoldDurMs: Int = 240,
        val tapDurScaleByErr: Boolean = true,
        /** when either tracker loses confidence below this, controller freezes (safe hold-off) */
        val minConfidence: Float = 0.34f,
        /** near-edge margins (fraction of bar) where extra caution is applied */
        val edgeMargin: Float = 0.06f,
        /** don't tap when already at the right edge; release-only there */
        val rightEdgeNoHold: Boolean = false,
        /** smooth progress: if progress decreasing for this long, widen hold band */
        val catchUpAfterMs: Long = 900,
        val catchUpBandBonus: Float = 0.10f,
    )

    data class Shake(
        /** frames the shake must persist before we tap (temporal validation) */
        val confirmFrames: Int = 2,
        /** frames without detection before we consider it gone */
        val lostFrames: Int = 3,
        val tapCooldownMs: Long = 130,
        val tapDurMs: Int = 60,
        /** never tap the same center twice without the prompt having moved/vanished */
        val sameSpotGuardMs: Long = 700,
        val sameSpotEpsF: Float = 0.02f,
        val minConfidence: Float = 0.45f,
    )

    data class Cast(
        /**
         * CAST_HOLD_DURATION_MS (spec V5 §6): how long the rod-button hold is extended before
         * release. Default 3000 ms; configurable, never a hard dependency of the cycle.
         */
        val holdMs: Long = 3000,
        val minConfidence: Float = 0.40f,
        val confirmFrames: Int = 2,
        /** after a successful cast press we wait at least this before looking for shakes */
        val postCastSettleMs: Long = 600,
        val pressCooldownMs: Long = 4000,
    )

    /**
     * Visual confirmation of the fishing-rod button (spec V5 §3/§4/§5). The rod button is the
     * ONLY trigger that may start a fishing cycle; a single frame is never enough:
     *  - the detector must report it for [confirmFrames] consecutive frames;
     *  - each frame's confidence must be >= [confidenceThreshold] (ROD_CONFIDENCE_THRESHOLD);
     *  - the button center must stay within [stableToleranceF] (normalized) of the streak anchor;
     *  - the whole streak must complete within [confirmWindowMs] (no slow accumulation).
     * All values are configurable; no fixed sleep is used anywhere.
     */
    data class Rod(
        val confirmFrames: Int = 3,
        val confidenceThreshold: Float = 0.55f,
        val stableToleranceF: Float = 0.02f,
        val confirmWindowMs: Long = 1500,
    )

    /**
     * V7 — auto-calibrated rod-button detection (spec V7 §1…§11).
     *
     * These are the *only* remaining knobs of the rod detector, and none of them is a screen
     * coordinate, a pixel size or a fixed frame count: they are ratios, time budgets and adaptive
     * tuning limits. The concrete geometry (search region, size band, threshold, confirmation
     * frame count, ROI padding) is produced at runtime by
     * [com.fischa.core.calib.AutoCalibrator] as a [com.fischa.core.calib.CalibrationConfig].
     */
    data class RodV7(
        /** candidateScore weights (auto-adjusted, gradually, by the adaptive model). */
        val weights: Weights = Weights(),
        /** how many top candidates are refined at full resolution each wide-search frame */
        val maxRefinedCandidates: Int = 5,
        /** coarse map step (processing px) for the wide search and the local tracking scan */
        val wideSearchStepPx: Int = 4,
        val localSearchStepPx: Int = 2,
        /** centers skipped between coarse scan positions (cheaper wide pass) */
        val wideCenterStride: Int = 2,
        val localCenterStride: Int = 1,
        /** interior of the rod button is dark; upper bound used while generating candidates */
        val interiorMaxGray: Int = 120,
        /** accepted center drift while confirming: max(min, factor × radius), normalized units */
        val driftToleranceFactor: Float = 0.8f,
        val driftToleranceMin: Float = 0.020f,
        /** a whole confirmation streak must complete inside this window */
        val confirmWindowMs: Long = 1500,
        /** final ROI = button × (1 + 2·roiPadding); 1.5× by default (spec §3) */
        val roiScale: Float = 1.5f,
        /** local tracking looks this far outside the current ROI (× button size) */
        val localSearchMarginFactor: Float = 1.0f,
        /** time (not frames!) without a local hit before TRACKING_ROD → ROD_LOST */
        val lostTimeoutMs: Long = 320L,
        /** time spent in LOCAL_RETRY before falling back to the wide search */
        val retryTimeoutMs: Long = 700L,
        /**
         * AUTO_CALIBRATION sampling budget (frames). Small on purpose: the measurement only needs
         * a handful of frames to see the FPS, the noise floor and the size of what is on screen,
         * and the detection must not sit idle for seconds.
         */
        val calibrationFrames: Int = 4,
        val calibrationMaxMs: Long = 2500L,
        /** cheap re-calibration cadence (tolerances/FPS only, never a hard re-acquire) */
        val recalibrationIntervalMs: Long = 45_000L,
        /** wall-clock span the temporal confirmation must cover (→ frames from measured FPS) */
        val targetConfirmMs: Float = 120f,
        /** gradual learning rate of the adaptive model (per second, bounded) */
        val adaptTauSec: Float = 4.0f,
        val adaptiveTuning: Boolean = true,
        /** minimum spacing between adaptive weight changes of the same kind */
        val adaptCooldownMs: Long = 1200L,
        /**
         * How long the wide search runs on the calibrated *estimate* before widening it to the
         * proportional fallback band (V7 §11: cheap first, exhaustive only if needed).
         */
        val wideExpandAfterMs: Long = 600L,
    ) {
        data class Weights(
            val shape: Float = 0.26f,
            val size: Float = 0.16f,
            val contrast: Float = 0.24f,
            val position: Float = 0.08f,
            val temporal: Float = 0.18f,
            val identity: Float = 0.08f,
        )
    }

    /**
     * V8 — **janela de detecção móvel** (spec *Rod Detection V8* §19).
     *
     * A V8 troca a *estratégia de busca* do botão da vara (a busca ampla auto-calibrada da V7) por
     * uma **janela quadrada móvel**: o detector procura o botão dentro de uma ROI configurável,
     * acompanha quando ele se move (movimento limitado, dead zone, suavização), guarda a última
     * posição conhecida e recupera ao redor dela quando o botão sai da janela — nunca inventando
     * uma posição e nunca executando input (spec §17).
     *
     * Como no resto do projeto, a geometria é **relativa** (fração 0..1 do frame processado):
     * [initialRoiX]/[initialRoiY] são o canto superior esquerdo da janela e [roiWidth]/[roiHeight]
     * o tamanho. Assim a mesma configuração vale em qualquer resolução/orientação — e nenhum
     * valor precisa ser ajustado à mão para o detector funcionar (todos têm default seguro).
     */
    data class RodV8(
        /** canto superior esquerdo da janela inicial (fração da largura/altura do frame) */
        val initialRoiX: Float = 0.62f,
        val initialRoiY: Float = 0.47f,
        /** tamanho da janela (fração do frame); constante, exceto durante a recuperação (§12) */
        val roiWidth: Float = 0.32f,
        val roiHeight: Float = 0.36f,
        /** §4 — deslocamento máximo da janela por frame (mesma unidade normalizada da posição) */
        val maxMovePerFrame: Float = 0.06f,
        /** §9 — tolerância: variações menores que isso não movem a janela (anti-jitter) */
        val deadZone: Float = 0.035f,
        /** §10 — suavização: 0 = move direto, 1 = nunca move (0.35 ≈ 65 % do caminho por frame) */
        val smoothing: Float = 0.35f,
        /** §5 — confiança mínima para o alvo ser considerado encontrado/confirmado */
        val minimumConfidence: Float = 0.50f,
        /** §14 — frames consecutivos exigidos antes de entrar em TRACKING */
        val confirmationFrames: Int = 3,
        /** §7 — fator de expansão da janela por etapa de recuperação */
        val recoveryExpansion: Float = 1.8f,
        /** §7 — orçamento de tempo total da recuperação (ms); esgotado → TARGET_NOT_FOUND */
        val recoveryTimeout: Long = 1500L,
        // ---- extras com default seguro (nenhum é obrigatório para funcionar) ----------------
        /** §7 — tempo em TARGET_LOST antes de começar a expandir a busca (ms) */
        val lostGraceMs: Long = 120L,
        /** §14/§15 — janela de tempo que a confirmação deve cobrir (frames derivados do FPS) */
        val targetConfirmMs: Float = 120f,
        /** uma confirmação inteira precisa caber neste intervalo (ms) */
        val confirmWindowMs: Long = 1500L,
        /** §5 — faixa plausível de raio do botão, em fração da largura do frame */
        val minSizeNormalized: Float = 0.030f,
        val maxSizeNormalized: Float = 0.110f,
        /** §4/§5 — em tracking, um candidato mais longe que isso da última posição é suspeito */
        val maxCandidateJump: Float = 0.18f,
        /** passo da varredura dentro da janela e quantos candidatos são refinados por frame */
        val searchStepPx: Int = 3,
        val maxRefinedCandidates: Int = 5,
        /** tolerância de contraste do anel usada pelo mecanismo visual dentro da janela */
        val minRingDelta: Float = 12f,
        /** §15 — constante de decaimento da confiança sem alvo (segundos), independente do FPS */
        val confidenceDecaySec: Float = 0.30f,
    )

    /**
     * V9 — **identificação visual do botão da vara** (spec *Rod Detection V9*).
     *
     * A política de janela móvel da V8 é preservada **inteira** (mesmos estados, mesmos
     * parâmetros, mesma geometria relativa). O que muda é *apenas* como o botão é reconhecido
     * dentro da janela: em vez de exigir o padrão antigo (disco escuro + anel claro) a V9 usa o
     * [com.fischa.core.vision.RodButtonDetectorV9], que trabalha por **múltiplas evidências
     * visuais** — contraste local, bordas/contorno, aparência de elemento de interface,
     * estabilidade temporal, consistência espacial e continuidade de rastreamento — combinadas
     * numa pontuação de confiança com pesos configuráveis ([visualMatchWeight] … [trackingWeight]).
     *
     * Nada aqui é coordenada rígida: todos os limiares são frações do frame (ou do raio medido),
     * então o mesmo bloco vale em qualquer resolução, proporção, densidade ou FPS.
     */
    data class RodButtonV9(
        // ---- §11 — parâmetros exigidos pela spec V9 (nomes idênticos) -------------------------
        /** liga/desliga a detecção visual V9 (desligada → a V9 responde TARGET_NOT_FOUND) */
        val rodButtonDetectionEnabled: Boolean = true,
        /** §5 — confiança mínima para um candidato ser confirmado como alvo */
        val minimumConfidence: Float = 0.50f,
        /** §5 — frames consecutivos exigidos antes de `targetFound = true` */
        val confirmationFrames: Int = 3,
        /** §3 — quantos candidatos o detector mantém por frame (depois do score) */
        val maxCandidates: Int = 6,
        /** §3 — peso da aparência visual (elemento de interface / template do usuário) */
        val visualMatchWeight: Float = 0.30f,
        /** §3 — peso do contraste local (interior × anel × entorno) */
        val contrastWeight: Float = 0.18f,
        /** §3 — peso das bordas (fechamento do contorno + alinhamento do gradiente) */
        val edgeWeight: Float = 0.18f,
        /** §3/§5 — peso da estabilidade temporal (o alvo permanece entre frames) */
        val temporalWeight: Float = 0.14f,
        /** §3 — peso da consistência espacial (posição relativa dentro da ROI) */
        val spatialWeight: Float = 0.08f,
        /** §3/§7 — peso da continuidade de rastreamento (proximidade do lastKnownTarget) */
        val trackingWeight: Float = 0.12f,
        /** §7 — em tracking, um candidato mais longe que isso da última posição é suspeito */
        val maxTargetJump: Float = 0.18f,
        /** §7 — orçamento total da recuperação (ms); esgotado → TARGET_NOT_FOUND */
        val targetLostTimeout: Long = 1500L,
        /** §7 — expansão da janela por etapa de recuperação */
        val recoveryExpansion: Float = 1.8f,
        /** §8 — `SHOW_DETECTION_DEBUG`: publica candidatos/estado para o overlay */
        val showDetectionDebug: Boolean = true,

        // ---- §1 — geometria da janela móvel (idêntica à V8) ----------------------------------
        /** canto superior esquerdo da janela inicial (fração da largura/altura do frame) */
        val initialRoiX: Float = 0.62f,
        val initialRoiY: Float = 0.47f,
        /** tamanho da janela (fração do frame); constante, exceto durante a recuperação */
        val roiWidth: Float = 0.32f,
        val roiHeight: Float = 0.36f,
        /** deslocamento máximo da janela por frame (mesma unidade normalizada da posição) */
        val maxMovePerFrame: Float = 0.06f,
        /** tolerância: variações menores que isso não movem a janela (anti-jitter) */
        val deadZone: Float = 0.035f,
        /** suavização: 0 = move direto, 1 = nunca move (0.35 ≈ 65 % do caminho por frame) */
        val smoothing: Float = 0.35f,

        // ---- detector visual: faixas e limiares (todos relativos) ----------------------------
        /** faixa plausível de raio do botão, em fração da largura do frame (§4) */
        val minSizeNormalized: Float = 0.030f,
        val maxSizeNormalized: Float = 0.110f,
        /** em tracking um candidato mais longe que isso do último alvo não é aceito (§7) */
        val maxCandidateJump: Float = 0.18f,
        /** passo da grade de propostas dentro da janela (px do frame processado) */
        val searchStepPx: Int = 5,
        /** amostras no contorno de cada hipótese (círculo/caixa) */
        val ringSamples: Int = 16,
        /** piso de evidência de borda para uma posição virar candidato */
        val proposalFloor: Float = 0.40f,
        /** piso de pontuação para um candidato ser viável em um frame (antes da confirmação) */
        val candidateFloor: Float = 0.34f,
        /** tolerância (× raio) para achar a borda em volta do contorno amostrado */
        val boundaryTolerance: Float = 0.18f,
        /** gradiente mínimo (níveis de cinza) para uma amostra contar como borda */
        val minEdgeMagnitude: Float = 14f,
        /** diferença mínima interior × entorno (níveis de cinza) para a borda valer */
        val minBoundaryDelta: Float = 6f,
        /** quantos frames de histórico a estabilidade temporal consulta */
        val historyFrames: Int = 8,
        /** estabilidade temporal mínima para confirmar (elemento de interface não pula) */
        val minTemporalStability: Float = 0.25f,
        /** fração de pixels claros (texto) que reprova o candidato (prompt SHAKE-like) */
        val textRejectionFraction: Float = 0.07f,
        /** textura interna máxima tolerada (0..1) para "cara de elemento de interface" */
        val maxInteriorTexture: Float = 0.55f,
        /** §3 — fechamento mínimo do contorno (fração dos raios que encontram borda) */
        val minBoundaryClosure: Float = 0.62f,
        /** §3 — coerência mínima entre a orientação da borda e a direção radial */
        val minBoundaryAlign: Float = 0.50f,
        /** §6 — forma mais alongada que isso (eixo maior/eixo menor) não é interface */
        val maxAspectRatio: Float = 1.80f,
        /** §6 — variação relativa do raio ao longo do contorno (irregular = cena, não interface) */
        val maxProfileRoughness: Float = 0.34f,
        /** §3 — peso da força regional do contorno */
        val regionStrengthWeight: Float = 0.06f,
        /** §3 — peso da regularidade da forma (contorno coerente) */
        val roundnessWeight: Float = 0.06f,
        /** §3 — peso do template visual do usuário (quando carregado) */
        val templateWeight: Float = 0.50f,
        /** §3 — peso do sinal auxiliar (disco escuro + anel claro) — nunca decide sozinho */
        val auxiliaryDiscWeight: Float = 0.04f,
        /** §3 — mudança mínima entre frames (níveis de cinza) para uma região contar como "mudou" */
        val changeTol: Float = 9f,
        /** §3 — variação tolerada entre frames (níveis de cinza) para um pixel contar como estável */
        val stableTol: Float = 6f,
        /** hipóteses retangulares além das circulares (botão quadrado/arredondado) */
        val useShapeBoxes: Boolean = true,
        /** usa o disco escuro antigo apenas como sinal **auxiliar** (nunca obrigatório) */
        val useAuxiliaryDarkDisc: Boolean = true,
        /** usa o template visual do usuário (se carregado) para o visualMatch */
        val useTemplate: Boolean = true,
        /** janela de tempo que a confirmação deve cobrir (frames derivados do FPS medido) */
        val targetConfirmMs: Float = 120f,
        /** uma confirmação inteira precisa caber neste intervalo (ms) */
        val confirmWindowMs: Long = 1500L,
        /** tempo em TARGET_LOST antes de começar a expandir a busca (ms) */
        val lostGraceMs: Long = 120L,
        /** constante de decaimento de confiança sem alvo (s), independente do FPS */
        val confidenceDecaySec: Float = 0.30f,

        // ---- §9 — captura de diagnóstico -----------------------------------------------------
        /** salva um frame da ROI quando candidato/ausência/confiança baixa/TARGET_NOT_FOUND */
        val saveDiagnosticFrames: Boolean = true,
        /** intervalo mínimo entre dois arquivos de diagnóstico (ms) */
        val diagnosticMinIntervalMs: Long = 750L,
        /** quantos arquivos de diagnóstico são mantidos no diretório */
        val diagnosticMaxFiles: Int = 60,
    )

    data class StateTiming(
        /** min time a stable state must hold before a "vision lost" escalation */
        val visionLostAfterMs: Long = 2500,
        /** min frames of bar presence to enter MINIGAME */
        val minigameEnterFrames: Int = 3,
        /** min frames of bar absence to leave MINIGAME */
        val minigameExitFrames: Int = 5,
        /** how long to keep the progress trend memory after the bar vanished */
        val catchMemoryMs: Long = 1600,
        /** catch confirmation text watch window after minigame exit */
        val confirmWindowMs: Long = 6000,
        /** min progress value that still counts as "was winning" at exit (catch vs escape) */
        val catchMinProgress: Float = 0.30f,
        val resetDwellMs: Long = 900,
        /** safety timeout of WAITING_FOR_WATER: no shake/bar evidence after a cast → back to rod watch */
        val waitingForWaterMs: Long = 10_000,
        val idleAutoArm: Boolean = true,
    )

    data class Safety(
        val minGlobalConfidence: Float = 0.30f,
        /** Minimum confidence of the visual target for an individual gesture. */
        val minActionConfidence: Float = 0.30f,
        val denyWhenCaptureStale: Boolean = true,
        val denyWhenRobloxMissing: Boolean = true,
        /** A decision older than this is never allowed to begin or renew an input. */
        val maxFrameAgeMs: Long = 180,
        /** Rate floor applies to new taps/holds, not bounded hold renewals/releases. */
        val minInputGapMs: Long = 25,
        val maxTapMs: Long = 500,
        val maxHoldLeaseMs: Long = 250,
        /** Android StrokeDescription continuation quantum; actual holds renew after each frame. */
        val holdQuantumMs: Long = 65,
        /** Maximum one continuous AccessibilityService stroke train before forced release. */
        val maxManualHoldMs: Long = 5000,
        /** A hold renewal must be refreshed before this watchdog expires. */
        val watchdogMs: Long = 350,
    )

    /** Validate tunables at every load boundary; bounded gesture and frame values fail closed. */
    fun validate(): AppConfig {
        require(capture.processingWidth in 320..1600)
        require(capture.targetFps in 10..60)
        require(capture.bufferSlots in 2..8)
        require(capture.maxQueueLatencyMs in 20..1000)
        require(capture.streamTimeoutMs in 500..10_000)
        require(capture.firstFrameTimeoutMs in 500..10_000)

        require(vision.rodPriorCx.isFinite() && vision.rodPriorCx in 0f..1f)
        require(vision.rodPriorCy.isFinite() && vision.rodPriorCy in 0f..1f)
        require(vision.blockWhiteMinGray in 0..255)
        require(vision.fishNeedleAbovePx in 1..200)
        require(vision.progressFillMinGray in 0..255)

        require(tracking.fishAlpha.isFinite() && tracking.fishAlpha in 0f..1f)
        require(tracking.fishBeta.isFinite() && tracking.fishBeta in 0f..1f)
        require(tracking.fishJumpResyncNorm.isFinite() && tracking.fishJumpResyncNorm in 0.01f..1f)
        require(tracking.fishMaxLostMs in 50..3000)
        require(tracking.blockAlpha.isFinite() && tracking.blockAlpha in 0f..1f)
        require(tracking.barAlpha.isFinite() && tracking.barAlpha in 0f..1f)
        require(tracking.barLockMinConf.isFinite() && tracking.barLockMinConf in 0f..1f)
        require(tracking.barUnlockConf.isFinite() && tracking.barUnlockConf in 0f..tracking.barLockMinConf)
        require(tracking.confEmaAlpha.isFinite() && tracking.confEmaAlpha in 0f..1f)
        require(tracking.confDecayPerSec.isFinite() && tracking.confDecayPerSec in 0f..10f)

        require(control.deadband.isFinite() && control.deadband in 0.001f..0.25f)
        require(control.tapBand.isFinite() && control.tapBand in 0.01f..0.5f && control.tapBand > control.deadband)
        require(control.holdBand.isFinite() && control.holdBand in control.tapBand..1f)
        require(control.kP.isFinite() && control.kP in 0f..20f)
        require(control.kFF.isFinite() && control.kFF in 0f..10f)
        require(control.kDrift.isFinite() && control.kDrift in -5f..5f)
        require(control.lookaheadSec.isFinite() && control.lookaheadSec in 0f..1f)
        require(control.lookaheadVelClamp.isFinite() && control.lookaheadVelClamp in 0f..2f)
        require(control.minHoldMs in 0..2000)
        require(control.minReleaseMs in 0..2000)
        require(control.minTapGapMs in 0..2000)
        require(control.tapDurMs in 1..500)
        require(control.maxHoldMs in 250..5000)
        require(control.tapHoldPeriodMs in 30..5000)
        require(control.tapHoldDurMs in 1..500)
        require(control.minConfidence.isFinite() && control.minConfidence in 0f..1f)
        require(control.edgeMargin.isFinite() && control.edgeMargin in 0f..0.5f)
        require(control.catchUpAfterMs in 0..10_000)
        require(control.catchUpBandBonus.isFinite() && control.catchUpBandBonus in 0f..0.5f)

        require(shake.confirmFrames in 1..30)
        require(shake.lostFrames in 1..60)
        require(shake.tapCooldownMs in 0..10_000)
        require(shake.tapDurMs.toLong() in 1L..safety.maxTapMs)
        require(shake.sameSpotGuardMs in 0..60_000)
        require(shake.sameSpotEpsF.isFinite() && shake.sameSpotEpsF in 0f..1f)
        require(shake.minConfidence.isFinite() && shake.minConfidence in 0f..1f)

        require(cast.holdMs in 500..5000)
        require(cast.minConfidence.isFinite() && cast.minConfidence in 0f..1f)
        require(cast.confirmFrames in 1..30)
        require(cast.postCastSettleMs in 0..15_000)
        require(cast.pressCooldownMs in 0..60_000)

        require(rod.confirmFrames in 1..30)
        require(rod.confidenceThreshold.isFinite() && rod.confidenceThreshold in 0f..1f)
        require(rod.stableToleranceF.isFinite() && rod.stableToleranceF in 0f..1f)
        require(rod.confirmWindowMs in 100..10_000)

        require(state.visionLostAfterMs in 100..60_000)
        require(state.minigameEnterFrames in 1..30)
        require(state.minigameExitFrames in 1..60)
        require(state.catchMemoryMs in 0..30_000)
        require(state.confirmWindowMs in 100..30_000)
        require(state.catchMinProgress.isFinite() && state.catchMinProgress in 0f..1f)
        require(state.resetDwellMs in 0..30_000)
        require(state.waitingForWaterMs in 500..60_000)

        require(safety.minGlobalConfidence.isFinite() && safety.minGlobalConfidence in 0f..1f)
        require(safety.minActionConfidence.isFinite() && safety.minActionConfidence in 0f..1f)
        require(safety.maxFrameAgeMs in 20..1000)
        require(safety.minInputGapMs in 0..250)
        require(safety.maxTapMs in 1..500)
        require(safety.maxHoldLeaseMs in 30..500)
        require(safety.holdQuantumMs in 30..100)
        require(safety.maxManualHoldMs in 500..10_000)
        require(safety.watchdogMs in 100..1000)
        require(rodV7.maxRefinedCandidates in 1..16)
        require(rodV7.wideSearchStepPx in 2..12)
        require(rodV7.localSearchStepPx in 2..12)
        require(rodV7.interiorMaxGray in 20..255)
        require(rodV7.roiScale.isFinite() && rodV7.roiScale in 1.05f..4f)
        require(rodV7.lostTimeoutMs in 60..3000)
        require(rodV7.retryTimeoutMs in 100..5000)
        require(rodV7.calibrationFrames in 2..120)
        require(rodV7.targetConfirmMs.isFinite() && rodV7.targetConfirmMs in 30f..1000f)
        require(rodV7.weights.shape.isFinite() && rodV7.weights.shape in 0f..1f)
        require(rodV7.weights.temporal.isFinite() && rodV7.weights.temporal in 0f..1f)

        // V8 — moving window (spec Rod Detection V8 §19): every knob bounded and sane
        require(rodV8.initialRoiX.isFinite() && rodV8.initialRoiX in 0f..1f)
        require(rodV8.initialRoiY.isFinite() && rodV8.initialRoiY in 0f..1f)
        require(rodV8.roiWidth.isFinite() && rodV8.roiWidth in 0.02f..1f)
        require(rodV8.roiHeight.isFinite() && rodV8.roiHeight in 0.02f..1f)
        require(rodV8.maxMovePerFrame.isFinite() && rodV8.maxMovePerFrame in 0.001f..0.5f)
        require(rodV8.deadZone.isFinite() && rodV8.deadZone in 0f..0.5f)
        require(rodV8.smoothing.isFinite() && rodV8.smoothing in 0f..0.95f)
        require(rodV8.minimumConfidence.isFinite() && rodV8.minimumConfidence in 0f..1f)
        require(rodV8.confirmationFrames in 1..30)
        require(rodV8.recoveryExpansion.isFinite() && rodV8.recoveryExpansion in 1f..4f)
        require(rodV8.recoveryTimeout in 100..10_000)
        require(rodV8.lostGraceMs in 0..5_000)
        require(rodV8.targetConfirmMs.isFinite() && rodV8.targetConfirmMs in 30f..1_000f)
        require(rodV8.confirmWindowMs in 100..10_000)
        require(rodV8.minSizeNormalized.isFinite() && rodV8.minSizeNormalized in 0.005f..0.4f)
        require(
            rodV8.maxSizeNormalized.isFinite() &&
                rodV8.maxSizeNormalized in rodV8.minSizeNormalized..0.6f,
        )
        require(rodV8.maxCandidateJump.isFinite() && rodV8.maxCandidateJump in 0.01f..1f)
        require(rodV8.searchStepPx in 1..8)
        require(rodV8.maxRefinedCandidates in 1..16)
        require(rodV8.minRingDelta.isFinite() && rodV8.minRingDelta in 1f..60f)
        require(rodV8.confidenceDecaySec.isFinite() && rodV8.confidenceDecaySec in 0.05f..2f)

        require(rodButtonV9.initialRoiX.isFinite() && rodButtonV9.initialRoiX in 0f..1f)
        require(rodButtonV9.initialRoiY.isFinite() && rodButtonV9.initialRoiY in 0f..1f)
        require(rodButtonV9.roiWidth.isFinite() && rodButtonV9.roiWidth in 0.02f..1f)
        require(rodButtonV9.roiHeight.isFinite() && rodButtonV9.roiHeight in 0.02f..1f)
        require(rodButtonV9.maxMovePerFrame.isFinite() && rodButtonV9.maxMovePerFrame in 0.001f..0.5f)
        require(rodButtonV9.deadZone.isFinite() && rodButtonV9.deadZone in 0f..0.5f)
        require(rodButtonV9.smoothing.isFinite() && rodButtonV9.smoothing in 0f..0.95f)
        require(rodButtonV9.minimumConfidence.isFinite() && rodButtonV9.minimumConfidence in 0f..1f)
        require(rodButtonV9.candidateFloor.isFinite() && rodButtonV9.candidateFloor in 0f..1f)
        require(rodButtonV9.proposalFloor.isFinite() && rodButtonV9.proposalFloor in 0f..1f)
        require(rodButtonV9.confirmationFrames in 1..30)
        require(rodButtonV9.maxCandidates in 1..32)
        require(rodButtonV9.recoveryExpansion.isFinite() && rodButtonV9.recoveryExpansion in 1f..4f)
        require(rodButtonV9.targetLostTimeout in 100..10_000)
        require(rodButtonV9.lostGraceMs in 0..5_000)
        require(rodButtonV9.targetConfirmMs.isFinite() && rodButtonV9.targetConfirmMs in 30f..1_000f)
        require(rodButtonV9.confirmWindowMs in 100..10_000)
        require(rodButtonV9.minSizeNormalized.isFinite() && rodButtonV9.minSizeNormalized in 0.005f..0.4f)
        require(
            rodButtonV9.maxSizeNormalized.isFinite() &&
                rodButtonV9.maxSizeNormalized in rodButtonV9.minSizeNormalized..0.6f,
        )
        require(rodButtonV9.maxTargetJump.isFinite() && rodButtonV9.maxTargetJump in 0.01f..1f)
        require(rodButtonV9.maxCandidateJump.isFinite() && rodButtonV9.maxCandidateJump in 0.01f..1f)
        require(rodButtonV9.searchStepPx in 1..12)
        require(rodButtonV9.ringSamples in 8..64)
        require(rodButtonV9.boundaryTolerance.isFinite() && rodButtonV9.boundaryTolerance in 0.02f..0.6f)
        require(rodButtonV9.minEdgeMagnitude.isFinite() && rodButtonV9.minEdgeMagnitude in 1f..120f)
        require(rodButtonV9.minBoundaryDelta.isFinite() && rodButtonV9.minBoundaryDelta in 0f..80f)
        require(rodButtonV9.historyFrames in 2..64)
        require(rodButtonV9.minTemporalStability.isFinite() && rodButtonV9.minTemporalStability in 0f..1f)
        require(rodButtonV9.textRejectionFraction.isFinite() && rodButtonV9.textRejectionFraction in 0f..0.5f)
        require(rodButtonV9.maxInteriorTexture.isFinite() && rodButtonV9.maxInteriorTexture in 0f..1f)
        require(rodButtonV9.minBoundaryClosure.isFinite() && rodButtonV9.minBoundaryClosure in 0.1f..1f)
        require(rodButtonV9.minBoundaryAlign.isFinite() && rodButtonV9.minBoundaryAlign in 0f..1f)
        require(rodButtonV9.maxAspectRatio.isFinite() && rodButtonV9.maxAspectRatio in 1f..4f)
        require(rodButtonV9.maxProfileRoughness.isFinite() && rodButtonV9.maxProfileRoughness in 0.02f..1f)
        require(rodButtonV9.templateWeight.isFinite() && rodButtonV9.templateWeight in 0f..1f)
        require(rodButtonV9.auxiliaryDiscWeight.isFinite() && rodButtonV9.auxiliaryDiscWeight in 0f..1f)
        require(rodButtonV9.regionStrengthWeight.isFinite() && rodButtonV9.regionStrengthWeight in 0f..1f)
        require(rodButtonV9.roundnessWeight.isFinite() && rodButtonV9.roundnessWeight in 0f..1f)
        require(rodButtonV9.changeTol.isFinite() && rodButtonV9.changeTol in 1f..80f)
        require(rodButtonV9.stableTol.isFinite() && rodButtonV9.stableTol in 0f..40f)
        require(rodButtonV9.confidenceDecaySec.isFinite() && rodButtonV9.confidenceDecaySec in 0.05f..2f)
        require(rodButtonV9.diagnosticMinIntervalMs in 0..60_000)
        require(rodButtonV9.diagnosticMaxFiles in 0..5_000)
        val v9WeightSum = rodButtonV9.visualMatchWeight + rodButtonV9.contrastWeight +
            rodButtonV9.edgeWeight + rodButtonV9.temporalWeight + rodButtonV9.spatialWeight +
            rodButtonV9.trackingWeight + rodButtonV9.regionStrengthWeight +
            rodButtonV9.roundnessWeight + rodButtonV9.auxiliaryDiscWeight
        require(v9WeightSum.isFinite() && v9WeightSum > 0f)
        return this
    }

    // ---- (de)serialization: flat string map, one source of truth for Settings UI & harness ----

    /**
     * Only the tunables that materially change behaviour are exposed as a settings map; the
     * rest stay in code defaults so the Settings UI does not become a wall of numbers.
     */
    fun toMap(): Map<String, String> = buildMap {
        put("capture.processingWidth", capture.processingWidth.toString())
        put("capture.targetFps", capture.targetFps.toString())
        put("capture.bufferSlots", capture.bufferSlots.toString())
        put("capture.maxQueueLatencyMs", capture.maxQueueLatencyMs.toString())
        put("capture.streamTimeoutMs", capture.streamTimeoutMs.toString())
        put("capture.firstFrameTimeoutMs", capture.firstFrameTimeoutMs.toString())
        put("vision.rodPriorCx", vision.rodPriorCx.toString())
        put("vision.rodPriorCy", vision.rodPriorCy.toString())
        put("vision.blockWhiteMinGray", vision.blockWhiteMinGray.toString())
        put("vision.fishNeedleAbovePx", vision.fishNeedleAbovePx.toString())
        put("vision.progressFillMinGray", vision.progressFillMinGray.toString())
        put("tracking.fishAlpha", tracking.fishAlpha.toString())
        put("tracking.fishBeta", tracking.fishBeta.toString())
        put("tracking.fishJumpResyncNorm", tracking.fishJumpResyncNorm.toString())
        put("tracking.fishMaxLostMs", tracking.fishMaxLostMs.toString())
        put("tracking.blockAlpha", tracking.blockAlpha.toString())
        put("control.deadband", control.deadband.toString())
        put("control.tapBand", control.tapBand.toString())
        put("control.holdBand", control.holdBand.toString())
        put("control.kP", control.kP.toString())
        put("control.kFF", control.kFF.toString())
        put("control.kDrift", control.kDrift.toString())
        put("control.lookaheadSec", control.lookaheadSec.toString())
        put("control.minHoldMs", control.minHoldMs.toString())
        put("control.minReleaseMs", control.minReleaseMs.toString())
        put("control.minTapGapMs", control.minTapGapMs.toString())
        put("control.tapDurMs", control.tapDurMs.toString())
        put("control.maxHoldMs", control.maxHoldMs.toString())
        put("control.tapHoldPeriodMs", control.tapHoldPeriodMs.toString())
        put("control.tapHoldDurMs", control.tapHoldDurMs.toString())
        put("control.minConfidence", control.minConfidence.toString())
        put("shake.confirmFrames", shake.confirmFrames.toString())
        put("shake.lostFrames", shake.lostFrames.toString())
        put("shake.tapCooldownMs", shake.tapCooldownMs.toString())
        put("shake.tapDurMs", shake.tapDurMs.toString())
        put("shake.minConfidence", shake.minConfidence.toString())
        put("cast.holdMs", cast.holdMs.toString())
        put("cast.minConfidence", cast.minConfidence.toString())
        put("cast.postCastSettleMs", cast.postCastSettleMs.toString())
        put("cast.pressCooldownMs", cast.pressCooldownMs.toString())
        put("rod.confirmFrames", rod.confirmFrames.toString())
        put("rod.confidenceThreshold", rod.confidenceThreshold.toString())
        put("rod.stableToleranceF", rod.stableToleranceF.toString())
        put("rod.confirmWindowMs", rod.confirmWindowMs.toString())
        put("rodV7.maxRefinedCandidates", rodV7.maxRefinedCandidates.toString())
        put("rodV7.wideSearchStepPx", rodV7.wideSearchStepPx.toString())
        put("rodV7.localSearchStepPx", rodV7.localSearchStepPx.toString())
        put("rodV7.interiorMaxGray", rodV7.interiorMaxGray.toString())
        put("rodV7.roiScale", rodV7.roiScale.toString())
        put("rodV7.lostTimeoutMs", rodV7.lostTimeoutMs.toString())
        put("rodV7.retryTimeoutMs", rodV7.retryTimeoutMs.toString())
        put("rodV7.calibrationFrames", rodV7.calibrationFrames.toString())
        put("rodV7.targetConfirmMs", rodV7.targetConfirmMs.toString())
        put("rodV7.adaptiveTuning", rodV7.adaptiveTuning.toString())
        put("rodDetector", rodDetector.name)
        put("rodV8.initialRoiX", rodV8.initialRoiX.toString())
        put("rodV8.initialRoiY", rodV8.initialRoiY.toString())
        put("rodV8.roiWidth", rodV8.roiWidth.toString())
        put("rodV8.roiHeight", rodV8.roiHeight.toString())
        put("rodV8.maxMovePerFrame", rodV8.maxMovePerFrame.toString())
        put("rodV8.deadZone", rodV8.deadZone.toString())
        put("rodV8.smoothing", rodV8.smoothing.toString())
        put("rodV8.minimumConfidence", rodV8.minimumConfidence.toString())
        put("rodV8.confirmationFrames", rodV8.confirmationFrames.toString())
        put("rodV8.recoveryExpansion", rodV8.recoveryExpansion.toString())
        put("rodV8.recoveryTimeout", rodV8.recoveryTimeout.toString())
        put("rodV8.lostGraceMs", rodV8.lostGraceMs.toString())
        put("rodV8.searchStepPx", rodV8.searchStepPx.toString())
        put("rodV8.maxCandidateJump", rodV8.maxCandidateJump.toString())
        put("rodButtonV9.rodButtonDetectionEnabled", rodButtonV9.rodButtonDetectionEnabled.toString())
        put("rodButtonV9.minimumConfidence", rodButtonV9.minimumConfidence.toString())
        put("rodButtonV9.confirmationFrames", rodButtonV9.confirmationFrames.toString())
        put("rodButtonV9.maxCandidates", rodButtonV9.maxCandidates.toString())
        put("rodButtonV9.visualMatchWeight", rodButtonV9.visualMatchWeight.toString())
        put("rodButtonV9.contrastWeight", rodButtonV9.contrastWeight.toString())
        put("rodButtonV9.edgeWeight", rodButtonV9.edgeWeight.toString())
        put("rodButtonV9.temporalWeight", rodButtonV9.temporalWeight.toString())
        put("rodButtonV9.spatialWeight", rodButtonV9.spatialWeight.toString())
        put("rodButtonV9.trackingWeight", rodButtonV9.trackingWeight.toString())
        put("rodButtonV9.maxTargetJump", rodButtonV9.maxTargetJump.toString())
        put("rodButtonV9.targetLostTimeout", rodButtonV9.targetLostTimeout.toString())
        put("rodButtonV9.recoveryExpansion", rodButtonV9.recoveryExpansion.toString())
        put("rodButtonV9.showDetectionDebug", rodButtonV9.showDetectionDebug.toString())
        put("rodButtonV9.initialRoiX", rodButtonV9.initialRoiX.toString())
        put("rodButtonV9.initialRoiY", rodButtonV9.initialRoiY.toString())
        put("rodButtonV9.roiWidth", rodButtonV9.roiWidth.toString())
        put("rodButtonV9.roiHeight", rodButtonV9.roiHeight.toString())
        put("rodButtonV9.maxMovePerFrame", rodButtonV9.maxMovePerFrame.toString())
        put("rodButtonV9.deadZone", rodButtonV9.deadZone.toString())
        put("rodButtonV9.smoothing", rodButtonV9.smoothing.toString())
        put("rodButtonV9.minSizeNormalized", rodButtonV9.minSizeNormalized.toString())
        put("rodButtonV9.maxSizeNormalized", rodButtonV9.maxSizeNormalized.toString())
        put("rodButtonV9.maxCandidateJump", rodButtonV9.maxCandidateJump.toString())
        put("rodButtonV9.searchStepPx", rodButtonV9.searchStepPx.toString())
        put("rodButtonV9.ringSamples", rodButtonV9.ringSamples.toString())
        put("rodButtonV9.proposalFloor", rodButtonV9.proposalFloor.toString())
        put("rodButtonV9.candidateFloor", rodButtonV9.candidateFloor.toString())
        put("rodButtonV9.boundaryTolerance", rodButtonV9.boundaryTolerance.toString())
        put("rodButtonV9.minEdgeMagnitude", rodButtonV9.minEdgeMagnitude.toString())
        put("rodButtonV9.minBoundaryDelta", rodButtonV9.minBoundaryDelta.toString())
        put("rodButtonV9.historyFrames", rodButtonV9.historyFrames.toString())
        put("rodButtonV9.minTemporalStability", rodButtonV9.minTemporalStability.toString())
        put("rodButtonV9.textRejectionFraction", rodButtonV9.textRejectionFraction.toString())
        put("rodButtonV9.maxInteriorTexture", rodButtonV9.maxInteriorTexture.toString())
        put("rodButtonV9.minBoundaryClosure", rodButtonV9.minBoundaryClosure.toString())
        put("rodButtonV9.minBoundaryAlign", rodButtonV9.minBoundaryAlign.toString())
        put("rodButtonV9.maxAspectRatio", rodButtonV9.maxAspectRatio.toString())
        put("rodButtonV9.maxProfileRoughness", rodButtonV9.maxProfileRoughness.toString())
        put("rodButtonV9.regionStrengthWeight", rodButtonV9.regionStrengthWeight.toString())
        put("rodButtonV9.roundnessWeight", rodButtonV9.roundnessWeight.toString())
        put("rodButtonV9.templateWeight", rodButtonV9.templateWeight.toString())
        put("rodButtonV9.auxiliaryDiscWeight", rodButtonV9.auxiliaryDiscWeight.toString())
        put("rodButtonV9.changeTol", rodButtonV9.changeTol.toString())
        put("rodButtonV9.stableTol", rodButtonV9.stableTol.toString())
        put("rodButtonV9.useShapeBoxes", rodButtonV9.useShapeBoxes.toString())
        put("rodButtonV9.useAuxiliaryDarkDisc", rodButtonV9.useAuxiliaryDarkDisc.toString())
        put("rodButtonV9.useTemplate", rodButtonV9.useTemplate.toString())
        put("rodButtonV9.targetConfirmMs", rodButtonV9.targetConfirmMs.toString())
        put("rodButtonV9.confirmWindowMs", rodButtonV9.confirmWindowMs.toString())
        put("rodButtonV9.lostGraceMs", rodButtonV9.lostGraceMs.toString())
        put("rodButtonV9.confidenceDecaySec", rodButtonV9.confidenceDecaySec.toString())
        put("rodButtonV9.saveDiagnosticFrames", rodButtonV9.saveDiagnosticFrames.toString())
        put("rodButtonV9.diagnosticMinIntervalMs", rodButtonV9.diagnosticMinIntervalMs.toString())
        put("rodButtonV9.diagnosticMaxFiles", rodButtonV9.diagnosticMaxFiles.toString())
        put("state.waitingForWaterMs", state.waitingForWaterMs.toString())
        put("safety.minGlobalConfidence", safety.minGlobalConfidence.toString())
        put("safety.minActionConfidence", safety.minActionConfidence.toString())
        put("safety.maxFrameAgeMs", safety.maxFrameAgeMs.toString())
        put("safety.minInputGapMs", safety.minInputGapMs.toString())
        put("safety.maxTapMs", safety.maxTapMs.toString())
        put("safety.maxHoldLeaseMs", safety.maxHoldLeaseMs.toString())
        put("safety.holdQuantumMs", safety.holdQuantumMs.toString())
        put("safety.maxManualHoldMs", safety.maxManualHoldMs.toString())
        put("safety.watchdogMs", safety.watchdogMs.toString())
    }

    fun withOverrides(map: Map<String, String>): AppConfig {
        fun i(key: String, cur: Int) = map[key]?.toIntOrNull() ?: cur
        fun l(key: String, cur: Long) = map[key]?.toLongOrNull() ?: cur
        fun f(key: String, cur: Float) = map[key]?.toFloatOrNull() ?: cur
        return copy(
            capture = capture.copy(
                processingWidth = i("capture.processingWidth", capture.processingWidth),
                targetFps = i("capture.targetFps", capture.targetFps),
                bufferSlots = i("capture.bufferSlots", capture.bufferSlots),
                maxQueueLatencyMs = i("capture.maxQueueLatencyMs", capture.maxQueueLatencyMs),
                streamTimeoutMs = l("capture.streamTimeoutMs", capture.streamTimeoutMs),
                firstFrameTimeoutMs = l("capture.firstFrameTimeoutMs", capture.firstFrameTimeoutMs),
            ),
            vision = vision.copy(
                rodPriorCx = f("vision.rodPriorCx", vision.rodPriorCx),
                rodPriorCy = f("vision.rodPriorCy", vision.rodPriorCy),
                rodSearchX0 = f("vision.rodSearchX0", vision.rodSearchX0),
                rodSearchX1 = f("vision.rodSearchX1", vision.rodSearchX1),
                rodSearchY0 = f("vision.rodSearchY0", vision.rodSearchY0),
                rodSearchY1 = f("vision.rodSearchY1", vision.rodSearchY1),
                shakeSearchX0 = f("vision.shakeSearchX0", vision.shakeSearchX0),
                shakeSearchX1 = f("vision.shakeSearchX1", vision.shakeSearchX1),
                shakeSearchY0 = f("vision.shakeSearchY0", vision.shakeSearchY0),
                shakeSearchY1 = f("vision.shakeSearchY1", vision.shakeSearchY1),
                barSearchY0 = f("vision.barSearchY0", vision.barSearchY0),
                barSearchY1 = f("vision.barSearchY1", vision.barSearchY1),
                blockWhiteMinGray = i("vision.blockWhiteMinGray", vision.blockWhiteMinGray),
                fishNeedleAbovePx = i("vision.fishNeedleAbovePx", vision.fishNeedleAbovePx),
                progressFillMinGray = i("vision.progressFillMinGray", vision.progressFillMinGray),
            ),
            tracking = tracking.copy(
                fishAlpha = f("tracking.fishAlpha", tracking.fishAlpha),
                fishBeta = f("tracking.fishBeta", tracking.fishBeta),
                fishJumpResyncNorm = f("tracking.fishJumpResyncNorm", tracking.fishJumpResyncNorm),
                fishMaxLostMs = l("tracking.fishMaxLostMs", tracking.fishMaxLostMs),
                blockAlpha = f("tracking.blockAlpha", tracking.blockAlpha),
            ),
            control = control.copy(
                deadband = f("control.deadband", control.deadband),
                tapBand = f("control.tapBand", control.tapBand),
                holdBand = f("control.holdBand", control.holdBand),
                kP = f("control.kP", control.kP),
                kFF = f("control.kFF", control.kFF),
                kDrift = f("control.kDrift", control.kDrift),
                lookaheadSec = f("control.lookaheadSec", control.lookaheadSec),
                minHoldMs = i("control.minHoldMs", control.minHoldMs),
                minReleaseMs = i("control.minReleaseMs", control.minReleaseMs),
                minTapGapMs = i("control.minTapGapMs", control.minTapGapMs),
                tapDurMs = i("control.tapDurMs", control.tapDurMs),
                maxHoldMs = i("control.maxHoldMs", control.maxHoldMs),
                tapHoldPeriodMs = i("control.tapHoldPeriodMs", control.tapHoldPeriodMs),
                tapHoldDurMs = i("control.tapHoldDurMs", control.tapHoldDurMs),
                minConfidence = f("control.minConfidence", control.minConfidence),
            ),
            shake = shake.copy(
                confirmFrames = i("shake.confirmFrames", shake.confirmFrames),
                lostFrames = i("shake.lostFrames", shake.lostFrames),
                tapCooldownMs = l("shake.tapCooldownMs", shake.tapCooldownMs),
                tapDurMs = i("shake.tapDurMs", shake.tapDurMs),
                minConfidence = f("shake.minConfidence", shake.minConfidence),
            ),
            cast = cast.copy(
                holdMs = l("cast.holdMs", cast.holdMs),
                minConfidence = f("cast.minConfidence", cast.minConfidence),
                postCastSettleMs = l("cast.postCastSettleMs", cast.postCastSettleMs),
                pressCooldownMs = l("cast.pressCooldownMs", cast.pressCooldownMs),
            ),
            rod = rod.copy(
                confirmFrames = i("rod.confirmFrames", rod.confirmFrames),
                confidenceThreshold = f("rod.confidenceThreshold", rod.confidenceThreshold),
                stableToleranceF = f("rod.stableToleranceF", rod.stableToleranceF),
                confirmWindowMs = l("rod.confirmWindowMs", rod.confirmWindowMs),
            ),
            rodV7 = rodV7.copy(
                maxRefinedCandidates = i("rodV7.maxRefinedCandidates", rodV7.maxRefinedCandidates),
                wideSearchStepPx = i("rodV7.wideSearchStepPx", rodV7.wideSearchStepPx),
                localSearchStepPx = i("rodV7.localSearchStepPx", rodV7.localSearchStepPx),
                interiorMaxGray = i("rodV7.interiorMaxGray", rodV7.interiorMaxGray),
                roiScale = f("rodV7.roiScale", rodV7.roiScale),
                lostTimeoutMs = l("rodV7.lostTimeoutMs", rodV7.lostTimeoutMs),
                retryTimeoutMs = l("rodV7.retryTimeoutMs", rodV7.retryTimeoutMs),
                calibrationFrames = i("rodV7.calibrationFrames", rodV7.calibrationFrames),
                targetConfirmMs = f("rodV7.targetConfirmMs", rodV7.targetConfirmMs),
                adaptiveTuning = map["rodV7.adaptiveTuning"]?.toBooleanStrictOrNull() ?: rodV7.adaptiveTuning,
            ),
            rodButtonV9 = rodButtonV9.copy(
                rodButtonDetectionEnabled = map["rodButtonV9.rodButtonDetectionEnabled"]
                    ?.toBooleanStrictOrNull() ?: rodButtonV9.rodButtonDetectionEnabled,
                minimumConfidence = f("rodButtonV9.minimumConfidence", rodButtonV9.minimumConfidence),
                confirmationFrames = i("rodButtonV9.confirmationFrames", rodButtonV9.confirmationFrames),
                maxCandidates = i("rodButtonV9.maxCandidates", rodButtonV9.maxCandidates),
                visualMatchWeight = f("rodButtonV9.visualMatchWeight", rodButtonV9.visualMatchWeight),
                contrastWeight = f("rodButtonV9.contrastWeight", rodButtonV9.contrastWeight),
                edgeWeight = f("rodButtonV9.edgeWeight", rodButtonV9.edgeWeight),
                temporalWeight = f("rodButtonV9.temporalWeight", rodButtonV9.temporalWeight),
                spatialWeight = f("rodButtonV9.spatialWeight", rodButtonV9.spatialWeight),
                trackingWeight = f("rodButtonV9.trackingWeight", rodButtonV9.trackingWeight),
                maxTargetJump = f("rodButtonV9.maxTargetJump", rodButtonV9.maxTargetJump),
                targetLostTimeout = l("rodButtonV9.targetLostTimeout", rodButtonV9.targetLostTimeout),
                recoveryExpansion = f("rodButtonV9.recoveryExpansion", rodButtonV9.recoveryExpansion),
                showDetectionDebug = map["rodButtonV9.showDetectionDebug"]
                    ?.toBooleanStrictOrNull() ?: rodButtonV9.showDetectionDebug,
                initialRoiX = f("rodButtonV9.initialRoiX", rodButtonV9.initialRoiX),
                initialRoiY = f("rodButtonV9.initialRoiY", rodButtonV9.initialRoiY),
                roiWidth = f("rodButtonV9.roiWidth", rodButtonV9.roiWidth),
                roiHeight = f("rodButtonV9.roiHeight", rodButtonV9.roiHeight),
                maxMovePerFrame = f("rodButtonV9.maxMovePerFrame", rodButtonV9.maxMovePerFrame),
                deadZone = f("rodButtonV9.deadZone", rodButtonV9.deadZone),
                smoothing = f("rodButtonV9.smoothing", rodButtonV9.smoothing),
                minSizeNormalized = f("rodButtonV9.minSizeNormalized", rodButtonV9.minSizeNormalized),
                maxSizeNormalized = f("rodButtonV9.maxSizeNormalized", rodButtonV9.maxSizeNormalized),
                maxCandidateJump = f("rodButtonV9.maxCandidateJump", rodButtonV9.maxCandidateJump),
                searchStepPx = i("rodButtonV9.searchStepPx", rodButtonV9.searchStepPx),
                ringSamples = i("rodButtonV9.ringSamples", rodButtonV9.ringSamples),
                proposalFloor = f("rodButtonV9.proposalFloor", rodButtonV9.proposalFloor),
                candidateFloor = f("rodButtonV9.candidateFloor", rodButtonV9.candidateFloor),
                boundaryTolerance = f("rodButtonV9.boundaryTolerance", rodButtonV9.boundaryTolerance),
                minEdgeMagnitude = f("rodButtonV9.minEdgeMagnitude", rodButtonV9.minEdgeMagnitude),
                minBoundaryDelta = f("rodButtonV9.minBoundaryDelta", rodButtonV9.minBoundaryDelta),
                historyFrames = i("rodButtonV9.historyFrames", rodButtonV9.historyFrames),
                minTemporalStability = f("rodButtonV9.minTemporalStability", rodButtonV9.minTemporalStability),
                minBoundaryClosure = f("rodButtonV9.minBoundaryClosure", rodButtonV9.minBoundaryClosure),
                minBoundaryAlign = f("rodButtonV9.minBoundaryAlign", rodButtonV9.minBoundaryAlign),
                maxAspectRatio = f("rodButtonV9.maxAspectRatio", rodButtonV9.maxAspectRatio),
                maxProfileRoughness = f("rodButtonV9.maxProfileRoughness", rodButtonV9.maxProfileRoughness),
                regionStrengthWeight = f("rodButtonV9.regionStrengthWeight", rodButtonV9.regionStrengthWeight),
                roundnessWeight = f("rodButtonV9.roundnessWeight", rodButtonV9.roundnessWeight),
                templateWeight = f("rodButtonV9.templateWeight", rodButtonV9.templateWeight),
                auxiliaryDiscWeight = f("rodButtonV9.auxiliaryDiscWeight", rodButtonV9.auxiliaryDiscWeight),
                changeTol = f("rodButtonV9.changeTol", rodButtonV9.changeTol),
                stableTol = f("rodButtonV9.stableTol", rodButtonV9.stableTol),
                textRejectionFraction = f("rodButtonV9.textRejectionFraction", rodButtonV9.textRejectionFraction),
                maxInteriorTexture = f("rodButtonV9.maxInteriorTexture", rodButtonV9.maxInteriorTexture),
                useShapeBoxes = map["rodButtonV9.useShapeBoxes"]
                    ?.toBooleanStrictOrNull() ?: rodButtonV9.useShapeBoxes,
                useAuxiliaryDarkDisc = map["rodButtonV9.useAuxiliaryDarkDisc"]
                    ?.toBooleanStrictOrNull() ?: rodButtonV9.useAuxiliaryDarkDisc,
                useTemplate = map["rodButtonV9.useTemplate"]
                    ?.toBooleanStrictOrNull() ?: rodButtonV9.useTemplate,
                targetConfirmMs = f("rodButtonV9.targetConfirmMs", rodButtonV9.targetConfirmMs),
                confirmWindowMs = l("rodButtonV9.confirmWindowMs", rodButtonV9.confirmWindowMs),
                lostGraceMs = l("rodButtonV9.lostGraceMs", rodButtonV9.lostGraceMs),
                confidenceDecaySec = f("rodButtonV9.confidenceDecaySec", rodButtonV9.confidenceDecaySec),
                saveDiagnosticFrames = map["rodButtonV9.saveDiagnosticFrames"]
                    ?.toBooleanStrictOrNull() ?: rodButtonV9.saveDiagnosticFrames,
                diagnosticMinIntervalMs = l("rodButtonV9.diagnosticMinIntervalMs", rodButtonV9.diagnosticMinIntervalMs),
                diagnosticMaxFiles = i("rodButtonV9.diagnosticMaxFiles", rodButtonV9.diagnosticMaxFiles),
            ),
            rodDetector = map["rodDetector"]
                ?.let { runCatching { RodDetectorKind.valueOf(it.trim().uppercase()) }.getOrNull() }
                ?: rodDetector,
            rodV8 = rodV8.copy(
                initialRoiX = f("rodV8.initialRoiX", rodV8.initialRoiX),
                initialRoiY = f("rodV8.initialRoiY", rodV8.initialRoiY),
                roiWidth = f("rodV8.roiWidth", rodV8.roiWidth),
                roiHeight = f("rodV8.roiHeight", rodV8.roiHeight),
                maxMovePerFrame = f("rodV8.maxMovePerFrame", rodV8.maxMovePerFrame),
                deadZone = f("rodV8.deadZone", rodV8.deadZone),
                smoothing = f("rodV8.smoothing", rodV8.smoothing),
                minimumConfidence = f("rodV8.minimumConfidence", rodV8.minimumConfidence),
                confirmationFrames = i("rodV8.confirmationFrames", rodV8.confirmationFrames),
                recoveryExpansion = f("rodV8.recoveryExpansion", rodV8.recoveryExpansion),
                recoveryTimeout = l("rodV8.recoveryTimeout", rodV8.recoveryTimeout),
                lostGraceMs = l("rodV8.lostGraceMs", rodV8.lostGraceMs),
                searchStepPx = i("rodV8.searchStepPx", rodV8.searchStepPx),
                maxCandidateJump = f("rodV8.maxCandidateJump", rodV8.maxCandidateJump),
            ),
            state = state.copy(
                waitingForWaterMs = l("state.waitingForWaterMs", state.waitingForWaterMs),
            ),
            safety = safety.copy(
                minGlobalConfidence = f("safety.minGlobalConfidence", safety.minGlobalConfidence),
                minActionConfidence = f("safety.minActionConfidence", safety.minActionConfidence),
                maxFrameAgeMs = l("safety.maxFrameAgeMs", safety.maxFrameAgeMs),
                minInputGapMs = l("safety.minInputGapMs", safety.minInputGapMs),
                maxTapMs = l("safety.maxTapMs", safety.maxTapMs),
                maxHoldLeaseMs = l("safety.maxHoldLeaseMs", safety.maxHoldLeaseMs),
                holdQuantumMs = l("safety.holdQuantumMs", safety.holdQuantumMs),
                maxManualHoldMs = l("safety.maxManualHoldMs", safety.maxManualHoldMs),
                watchdogMs = l("safety.watchdogMs", safety.watchdogMs),
            ),
        )
    }
}
