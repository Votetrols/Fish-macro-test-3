package com.fischa.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.fischa.core.debug.RenderModel

/** Optional non-touchable, read-only overlay with detector boxes and safety diagnostics. */
class DebugOverlay(private val context: Context) {
    private val windowManager = context.getSystemService(WindowManager::class.java)
        ?: context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var model: RenderModel? = null

    private val view = object : View(context) {
        override fun onDraw(canvas: Canvas) {
            // Draw in the SAME coordinate space as capture/touch: the real display size published
            // by the capture session (spec §3). The overlay window is anchored at (0,0) and laid
            // out without inset limits, so using the real size keeps boxes aligned with the game
            // even if the window itself is clipped by system bars.
            val geometry = InputGeometry.geometry
            val w = geometry?.width?.toFloat() ?: width.toFloat()
            val h = geometry?.height?.toFloat() ?: height.toFloat()
            model?.let { drawModel(canvas, it, w, h) }
        }
    }
    private val boxPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = false }
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 24f
        isAntiAlias = false
        setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }
    private val smallTextPaint = Paint(textPaint).apply { textSize = 19f; color = Color.LTGRAY }
    private val fillPaint = Paint().apply { style = Paint.Style.FILL }
    private val centerPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f; isAntiAlias = false }
    private var params: WindowManager.LayoutParams? = null

    fun enable() {
        if (params != null) return
        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0; y = 0
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = if (android.os.Build.VERSION.SDK_INT >= 30)
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            if (android.os.Build.VERSION.SDK_INT >= 30) fitInsetsTypes = 0
        }
        windowManager.addView(view, layoutParams)
        params = layoutParams
    }

    fun disable() {
        params?.let { runCatching { windowManager.removeViewImmediate(view) } }
        params = null
    }

    fun setModel(snapshot: RenderModel?) { model = snapshot }
    fun invalidate() { if (params != null) view.invalidate() }

    private fun drawModel(canvas: Canvas, m: RenderModel, width: Float, height: Float) {
        var y = 32f
        val lineHeight = 25f
        fun line(text: String, paint: Paint = smallTextPaint) {
            canvas.drawText(text, 12f, y, paint)
            y += lineHeight
        }
        val robloxPaint = Paint(textPaint).apply { color = if (m.robloxDetected) Color.GREEN else Color.RED }
        line("Roblox: ${if (m.robloxDetected) "YES" else "NO"} | package=${m.foregroundPackage}", robloxPaint)
        line("Window=${m.foregroundWindow}")
        line("State=${m.state} | FPS=${"%.1f".format(m.fps)} | frame=${m.frameAgeMs}ms", textPaint)
        line("Rod: confirmed=${m.rodConfirmed} conf=${"%.2f".format(m.confRod)} castAuthorized=${m.castAuthorized} (V6 compat)")
        // ---- V9 §8 / V8 §16: the moving window is the main detector, so the overlay speaks its
        // language. V9 adds the visual-identification debug (all candidates, chosen one, score,
        // lastKnownTarget, recovery stage) — see `SHOW_DETECTION_DEBUG` below.
        val isV9 = m.rodDetector == "V9"
        val isV8 = m.rodDetector == "V8" || isV9
        val v8Color = when {
            m.rodV8TargetNotFound -> LOST_COLOR
            m.rodV8Recovering -> CANDIDATE_COLOR
            m.rodV8TargetFound -> TRACKING_COLOR
            m.rodState == "TARGET_LOST" -> LOST_COLOR
            else -> SEARCH_COLOR
        }
        // ---- V7 §5: detection stack, in the exact vocabulary of the spec -----------------
        val stateColor = if (isV8) v8Color else when (m.rodState) {
            "SEARCHING_ROD" -> SEARCH_COLOR
            "CANDIDATE_FOUND", "CONFIRMING_ROD" -> CANDIDATE_COLOR
            "ROD_CONFIRMED" -> CONFIRMED_COLOR
            "TRACKING_ROD" -> TRACKING_COLOR
            "ROD_LOST" -> LOST_COLOR
            "LOCAL_RETRY" -> CANDIDATE_COLOR
            "AUTO_CALIBRATION" -> SEARCH_COLOR
            else -> Color.LTGRAY
        }
        val searchText = when {
            isV8 && m.rodV8Recovering -> "RECOVERY"
            isV8 -> "WINDOW"
            m.rodTracking -> "LOCAL"
            m.rodState == "AUTO_CALIBRATION" -> "CALIB"
            else -> "ACTIVE"
        }
        val candidateText = if (isV8) {
            when {
                m.rodV8TargetFound -> "CONFIRMED"
                m.rodV8CandidateNorm != null -> "FOUND"
                else -> "NONE"
            }
        } else {
            when {
                m.rodState == "ROD_CONFIRMED" || m.rodState == "TRACKING_ROD" -> "CONFIRMED"
                m.rodCandidates > 0 -> "FOUND"
                else -> "NONE"
            }
        }
        val roiText = m.rodRoiBox?.let {
            "(${(it[0] * width).toInt()},${(it[1] * height).toInt()}," +
                "${((it[2] - it[0]) * width).toInt()},${((it[3] - it[1]) * height).toInt()})"
        } ?: "(-)"
        val fmt = "STATE=%s FPS=%.0f SEARCH=%s CANDIDATE=%s ROD_SCORE=%.2f ROD_CONFIDENCE=%.2f ROI=%s TRACKING=%s CONFIRM=%d/%d CANDIDATES=%d"
        line(
            fmt.format(
                m.rodState, m.fps, searchText, candidateText, m.rodScore, m.confRod, roiText,
                if (m.rodTracking) "ACTIVE" else "IDLE", m.rodStreak, m.rodRequiredFrames, m.rodCandidates,
            ),
            Paint(textPaint).apply { color = stateColor },
        )
        val layers = "VISION=${m.layerVision} DETECTION=${m.layerDetection} DECISION=${m.layerDecision} REAL_INPUT=${m.layerInput}"
        line(layers, Paint(textPaint).apply { color = if (m.layerInput == "DISABLED") Color.RED else Color.GREEN })
        if (m.rodState == "ROD_LOST" || m.rodState == "LOCAL_RETRY" || m.rodTracking) {
            line("ROD: lost=${"%.0f".format(m.rodLostMs)}ms reason=${m.rodReason}", smallTextPaint)
        } else {
            line("ROD: reason=${m.rodReason}", smallTextPaint)
        }
        if (isV8) {
            val wnd = pxBox(m.rodV8WindowBox, width, height)
            val cand = pxPoint(m.rodV8CandidateNorm, width, height)
            val prev = pxPoint(m.rodV8PreviousNorm, width, height)
            line(
                "%s: window=%s state=%s conf=%.2f candidate=%s prev=%s recovery=%s etapa=%d expand=%s"
                    .format(
                        if (isV9) "V9" else "V8",
                        wnd, m.rodState, m.rodV8CandidateConfidence, cand, prev,
                        if (m.rodV8Recovering) "YES" else "NO",
                        m.rodV8RecoveryStage,
                        if (m.rodV8WindowExpanded) "YES" else "NO",
                    ),
                Paint(smallTextPaint).apply { color = v8Color },
            )
        }
        if (isV9) {
            // ---- V9 §8: candidatos, escolhido, confiança, lastKnownTarget, estágio de recovery --
            val lastKnown = pxPoint(m.rodV9LastKnownNorm, width, height)
            val chosen = pxPoint(m.rodV9ChosenNorm, width, height)
            line(
                "V9 DET=%s SHOW_DEBUG=%s cands=%d chosen=%s score=%.2f lastKnown=%s msSince=%.0f"
                    .format(
                        m.rodV9DetectorState,
                        if (m.rodV9ShowDetectionDebug) "true" else "false",
                        (m.rodV9CandidatesNorm?.size ?: 0) / 2,
                        chosen, m.rodV9ChosenScore, lastKnown,
                        if (m.rodV9MsSinceConfirmed == Long.MAX_VALUE) -1f else m.rodV9MsSinceConfirmed.toFloat(),
                    ),
                Paint(smallTextPaint).apply { color = CHOSEN_COLOR },
            )
            if (m.rodV9DebugText.isNotEmpty()) line(m.rodV9DebugText, smallTextPaint)
        }
        if (m.rodCalibration.isNotEmpty()) line("CALIB: ${m.rodCalibration}", smallTextPaint)
        if (m.rodCandidateDetail.isNotEmpty()) line("CAND: ${m.rodCandidateDetail}", smallTextPaint)
        line("Fish=${"%.3f".format(m.fishCx)} Player=${"%.3f".format(m.playerCx)} Error=${"%+.3f".format(m.error)}")
        line("Confidence: global=${"%.2f".format(m.confGlobal)} bar=${"%.2f".format(m.confBar)} fish=${"%.2f".format(m.confFish)} player=${"%.2f".format(m.confPlayer)}")
        line("Progress=${"%.2f".format(m.progress)} rate=${"%+.2f".format(m.progressRate)} | action=${m.action}")
        val safetyText = if (m.inputAuthorized) "Safety: PASS" else "Safety: BLOCKED ${m.safetyBlockedReason}"
        val safetyPaint = Paint(textPaint).apply { color = if (m.inputAuthorized) Color.GREEN else Color.RED }
        line("Input=${if (m.realInputEnabled) "ENABLED" else "DISABLED"} | $safetyText", safetyPaint)
        if (m.emergency) line("EMERGENCY STOP LATCHED", Paint(textPaint).apply { color = Color.RED })

        m.barBox?.let { drawBox(canvas, it, width, height, Color.CYAN) }
        m.blockBox?.let { drawBox(canvas, it, width, height, Color.WHITE) }
        m.fishBox?.let { drawBox(canvas, it, width, height, Color.YELLOW) }
        m.progressBox?.let { drawBox(canvas, it, width, height, Color.GREEN) }
        m.shakeBox?.let { drawBox(canvas, it, width, height, Color.MAGENTA) }
        // ---- V7: the boxes that accompany the *candidate*, not a fixed coordinate --------
        val activeColor = when (m.rodState) {
            "SEARCHING_ROD" -> SEARCH_COLOR
            "CANDIDATE_FOUND", "CONFIRMING_ROD" -> CANDIDATE_COLOR
            "ROD_CONFIRMED" -> CONFIRMED_COLOR
            "TRACKING_ROD" -> TRACKING_COLOR
            "ROD_LOST", "LOCAL_RETRY" -> LOST_COLOR
            else -> Color.LTGRAY
        }
        if (isV8) {
            // the moving detection window: yellow when idle/searching, orange while recovering
            // (bigger and re-anchored), cyan while it is following a confirmed target
            val windowColor = when (m.rodState) {
                "TRACKING" -> TRACKING_COLOR       // ciano  — seguindo o alvo
                "RECOVERING" -> CANDIDATE_COLOR    // laranja — busca ampliada
                "TARGET_LOST" -> LOST_COLOR        // vermelho — alvo ausente (grace)
                else -> SEARCH_COLOR               // amarelo — ainda procurando na janela
            }
            m.rodV8WindowBox?.let { drawBox(canvas, it, width, height, windowColor, strokeWidth = 3f) }
            // previous confirmed position of the target (where the window is heading)
            m.rodV8PreviousNorm?.let { c -> drawCross(canvas, c, width, height, Color.GRAY, 7f) }
            // candidate seen inside the window on this frame
            m.rodV8CandidateNorm?.let { c -> drawCross(canvas, c, width, height, CANDIDATE_COLOR, 9f) }
            if (isV9) drawV9Debug(canvas, m, width, height)
        } else {
            // wide search region (thin)
            m.rodSearchBox?.let { drawBox(canvas, it, width, height, SEARCH_COLOR, strokeWidth = 2f) }
            // dynamic ROI around the detected button
            m.rodRoiBox?.let { drawBox(canvas, it, width, height, TRACKING_COLOR, strokeWidth = 2f) }
        }
        // the detected candidate (thicker, coloured by state) — replaces the old fixed red square
        m.rodBox?.let { drawBox(canvas, it, width, height, activeColor, strokeWidth = 4f) }
        // button centre cross
        m.rodCenterNorm?.let { c ->
            val cx = c[0] * width
            val cy = c[1] * height
            centerPaint.color = activeColor
            canvas.drawLine(cx - 12f, cy, cx + 12f, cy, centerPaint)
            canvas.drawLine(cx, cy - 12f, cx, cy + 12f, centerPaint)
        }
        m.barBox?.let { bar ->
            val left = bar[0] * width
            val right = bar[2] * width
            fillPaint.color = Color.argb(160, 0, 220, 120)
            canvas.drawRect(left, 4f, left + (right - left) * m.progress.coerceIn(0f, 1f), 12f, fillPaint)
        }
    }

    /**
     * V9 §8 — desenho específico da identificação visual:
     *
     *  * ROI (janela) — já desenhada pelo ramo comum, colorida pelo estado;
     *  * **todos** os candidatos (laranja, com o score ao lado) quando `SHOW_DETECTION_DEBUG`;
     *  * o candidato **escolhido** (magenta, com raio);
     *  * o alvo **confirmado** (verde, com cruz e círculo) — só quando existe de verdade;
     *  * `lastKnownTarget` (cinza) — a memória usada pela recuperação.
     */
    private fun drawV9Debug(canvas: Canvas, m: RenderModel, width: Float, height: Float) {
        val showDebug = m.rodV9ShowDetectionDebug
        val cands = m.rodV9CandidatesNorm
        if (showDebug && cands != null && cands.size >= 2) {
            val scores = m.rodV9CandidateScores
            val radii = m.rodV9CandidateRadiiNorm
            var i = 0
            while (i + 1 < cands.size) {
                val cx = cands[i] * width
                val cy = cands[i + 1] * height
                val r = ((radii?.getOrNull(i / 2) ?: 0f) * width).coerceAtLeast(6f)
                boxPaint.color = CANDIDATE_COLOR
                boxPaint.strokeWidth = 2f
                canvas.drawRect(cx - r, cy - r, cx + r, cy + r, boxPaint)
                drawCross(canvas, floatArrayOf(cands[i], cands[i + 1]), width, height, CANDIDATE_COLOR, 6f)
                if (scores != null && i / 2 < scores.size) {
                    canvas.drawText("%.2f".format(scores[i / 2]), cx + r + 4f, cy, smallTextPaint)
                }
                i += 2
            }
        }
        // lastKnownTarget: a memória que a recuperação usa (não é uma detecção do frame)
        m.rodV9LastKnownNorm?.let { c -> drawCross(canvas, c, width, height, Color.GRAY, 10f) }
        if (showDebug) {
            m.rodV9ChosenNorm?.let { c ->
                val r = (m.rodV9ChosenRadiusNorm * width).coerceAtLeast(8f)
                val cx = c[0] * width
                val cy = c[1] * height
                boxPaint.color = CHOSEN_COLOR
                boxPaint.strokeWidth = 3f
                canvas.drawRect(cx - r, cy - r, cx + r, cy + r, boxPaint)
                centerPaint.color = CHOSEN_COLOR
                canvas.drawLine(cx - 14f, cy, cx + 14f, cy, centerPaint)
                canvas.drawLine(cx, cy - 14f, cx, cy + 14f, centerPaint)
                canvas.drawText("escolhido %.2f".format(m.rodV9ChosenScore), cx + r + 4f, cy - 4f, smallTextPaint)
            }
        }
        // alvo confirmado: círculo + cruz grossa (verde) — só existe quando targetFound
        if (m.rodV8TargetFound && m.rodCenterNorm != null) {
            val cx = m.rodCenterNorm[0] * width
            val cy = m.rodCenterNorm[1] * height
            centerPaint.color = CONFIRMED_COLOR
            centerPaint.strokeWidth = 4f
            canvas.drawCircle(cx, cy, 22f, centerPaint)
            canvas.drawLine(cx - 18f, cy, cx + 18f, cy, centerPaint)
            canvas.drawLine(cx, cy - 18f, cx, cy + 18f, centerPaint)
            centerPaint.strokeWidth = 3f
            canvas.drawText("ALVO V9", cx + 26f, cy + 6f, smallTextPaint)
        }
    }

    private fun pxBox(norm: FloatArray?, width: Float, height: Float): String {
        if (norm == null || norm.size < 4) return "(-)"
        return "(${(norm[0] * width).toInt()},${(norm[1] * height).toInt()}," +
            "${((norm[2] - norm[0]) * width).toInt()},${((norm[3] - norm[1]) * height).toInt()})"
    }

    private fun pxPoint(norm: FloatArray?, width: Float, height: Float): String {
        if (norm == null || norm.size < 2) return "(-)"
        return "(${(norm[0] * width).toInt()},${(norm[1] * height).toInt()})"
    }

    private fun drawCross(
        canvas: Canvas,
        norm: FloatArray,
        width: Float,
        height: Float,
        color: Int,
        arm: Float,
    ) {
        if (norm.size < 2) return
        val cx = norm[0] * width
        val cy = norm[1] * height
        centerPaint.color = color
        canvas.drawLine(cx - arm, cy, cx + arm, cy, centerPaint)
        canvas.drawLine(cx, cy - arm, cx, cy + arm, centerPaint)
    }

    private fun drawBox(
        canvas: Canvas,
        norm: FloatArray,
        width: Float,
        height: Float,
        color: Int,
        strokeWidth: Float = 3f,
    ) {
        if (norm.size < 4) return
        boxPaint.color = color
        boxPaint.strokeWidth = strokeWidth
        canvas.drawRect(norm[0] * width, norm[1] * height, norm[2] * width, norm[3] * height, boxPaint)
        boxPaint.strokeWidth = 3f
    }

    private companion object {
        /** V7 §5: colours only differentiate the detection states. */
        const val SEARCH_COLOR = 0xFFFFD400.toInt()    // amarelo  — SEARCH
        const val CANDIDATE_COLOR = 0xFFFF9800.toInt() // laranja  — CANDIDATE
        const val CONFIRMED_COLOR = 0xFF00E676.toInt() // verde    — CONFIRMED
        const val TRACKING_COLOR = 0xFF00E5FF.toInt()  // ciano    — TRACKING
        const val LOST_COLOR = 0xFFFF1744.toInt()      // vermelho — LOST
        /** V9 §8 — cor do candidato escolhido pelo detector visual */
        const val CHOSEN_COLOR = 0xFFFF00E5.toInt()    // magenta  — candidato escolhido (V9)
    }
}
