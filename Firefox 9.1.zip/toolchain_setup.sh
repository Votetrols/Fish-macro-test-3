#!/usr/bin/env bash
set -uo pipefail
ROOT=/home/user/.cache/toolchain
mkdir -p "$ROOT" && cd "$ROOT"
export JAVA_HOME="$ROOT/jdk17"
export ANDROID_HOME="$ROOT/android-sdk"
export GRADLE_USER_HOME=/home/user/.cache/gradle-home

echo "== JDK 17 =="
if [ ! -x "$JAVA_HOME/bin/java" ]; then
  curl -sSL -o jdk17.tar.gz "https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse?project=jdk"
  mkdir -p "$ROOT/jdk17tmp" && tar -xzf jdk17.tar.gz -C "$ROOT/jdk17tmp" --strip-components=1
  mv "$ROOT/jdk17tmp" "$JAVA_HOME"
  rm -f jdk17.tar.gz
fi
"$JAVA_HOME/bin/java" -version 2>&1 | head -2

echo "== cmdline-tools =="
mkdir -p "$ANDROID_HOME/cmdline-tools"
if [ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  curl -sSL -o cmdtools.zip "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
  unzip -q -o cmdtools.zip -d "$ANDROID_HOME/cmdline-tools"
  rm -rf "$ANDROID_HOME/cmdline-tools/latest"
  mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest" 2>/dev/null || true
  rm -f cmdtools.zip
fi
export PATH="$JAVA_HOME/bin:$PATH"
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKM" --sdk_root="$ANDROID_HOME" --licenses >/dev/null 2>&1
"$SDKM" --sdk_root="$ANDROID_HOME" "platform-tools" "platforms;android-35" "build-tools;35.0.0" 2>&1 | tail -4
echo "== DONE =="
ls "$ANDROID_HOME"
