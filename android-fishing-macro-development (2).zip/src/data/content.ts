// ------------------------------------------------------------------
// Fisch Vision Macro — Documento de Arquitetura (Fase 0)
// Todo o conteúdo técnico da proposta vive aqui.
// ------------------------------------------------------------------

export type Tone = "cyan" | "amber" | "red" | "emerald" | "slate";

export const TONE: Record<Tone, { stroke: string; text: string; soft: string; chip: string }> = {
  cyan: { stroke: "#22d3ee", text: "text-cyan-300", soft: "bg-cyan-400/10 border-cyan-400/30", chip: "border-cyan-400/30 bg-cyan-400/10 text-cyan-300" },
  amber: { stroke: "#fbbf24", text: "text-amber-300", soft: "bg-amber-400/10 border-amber-400/30", chip: "border-amber-400/30 bg-amber-400/10 text-amber-300" },
  red: { stroke: "#fb7185", text: "text-rose-300", soft: "bg-rose-400/10 border-rose-400/30", chip: "border-rose-400/30 bg-rose-400/10 text-rose-300" },
  emerald: { stroke: "#34d399", text: "text-emerald-300", soft: "bg-emerald-400/10 border-emerald-400/30", chip: "border-emerald-400/30 bg-emerald-400/10 text-emerald-300" },
  slate: { stroke: "#94a3b8", text: "text-slate-300", soft: "bg-slate-400/10 border-slate-400/30", chip: "border-slate-400/30 bg-slate-400/10 text-slate-300" },
};

// ------------------------------------------------------------------
// Hero
// ------------------------------------------------------------------

export const HERO_CHIPS = ["KOTLIN 2.0", "MIN SDK 26", "TARGET SDK 35", "FOREGROUND SERVICE", "ACESSIBILIDADE", "SEM ROOT"];

export const TICKER_ITEMS = [
  "MEDIAPROJECTION + IMAGEREADER",
  "ROI CONFIGURÁVEL",
  "DETECÇÃO POR SEGMENTAÇÃO DE COR",
  "EMA + PREDIÇÃO DE POSIÇÃO",
  "CONTROLADOR P COM ZONA MORTA",
  "DISPATCHGESTURE / ACESSIBILIDADE",
  "MÁQUINA DE ESTADOS EXPLÍCITA",
  "WATCHDOG + FAIL-SAFE",
  "MODO SIMULAÇÃO",
  "LOGS EXPORTÁVEIS",
];

// ------------------------------------------------------------------
// 01 — Arquitetura (módulos)
// ------------------------------------------------------------------

export interface ModuleInfo {
  pkg: string;
  name: string;
  responsibility: string;
  types: string[];
}

export const MODULES: ModuleInfo[] = [
  {
    pkg: "app",
    name: "Núcleo do aplicativo",
    responsibility: "Application class, injeção manual de dependências (ServiceLocator) e tema. Zero lógica de macro aqui.",
    types: ["FischVisionApp", "ServiceLocator"],
  },
  {
    pkg: "ui",
    name: "Interface (Compose)",
    responsibility: "Telas Home, Configurações, Debug e Calibração. Apenas observa estados via Flow — nunca executa o macro.",
    types: ["MainActivity", "HomeViewModel", "DebugScreen"],
  },
  {
    pkg: "service",
    name: "Foreground Service",
    responsibility: "Dono do ciclo de vida do macro. Orquestra o MacroEngine, mantém a notificação persistente e o watchdog.",
    types: ["MacroForegroundService", "MacroEngine", "Watchdog"],
  },
  {
    pkg: "capture",
    name: "Captura de tela",
    responsibility: "Consentimento MediaProjection, VirtualDisplay, ImageReader em HandlerThread e FrameBus (último frame sempre vence).",
    types: ["ScreenCaptureManager", "FrameBus", "CaptureConfig"],
  },
  {
    pkg: "vision",
    name: "Pipeline de visão",
    responsibility: "Converte frames RGBA_8888 em medições: recorte da ROI, máscaras de cor, varreduras. Kotlin puro, sem JNI.",
    types: ["VisionPipeline", "RoiManager", "FrameMetrics"],
  },
  {
    pkg: "detector",
    name: "Detectores",
    responsibility: "Barra de pesca, peixe, indicador do jogador e estado do minigame. Todos retornam confidence ∈ [0,1].",
    types: ["FishingBarDetector", "FishDetector", "PlayerIndicatorDetector", "FishingStateDetector"],
  },
  {
    pkg: "tracker",
    name: "Rastreamento",
    responsibility: "EMA de posição e velocidade, histórico em buffer circular (sem alocação por frame) e predição com clamp.",
    types: ["TargetTracker", "TrackedTarget", "PredictionConfig"],
  },
  {
    pkg: "controller",
    name: "Controlador",
    responsibility: "Zona morta, histerese, tempos mínimos de hold/release e limitador de taxa de comandos. Saída: PRESS/HOLD/RELEASE/NO_ACTION.",
    types: ["FishingController", "ControlCommand", "ControlConfig"],
  },
  {
    pkg: "input",
    name: "Injeção de toque",
    responsibility: "Interface InputController desacoplada da decisão. Implementação real via AccessibilityService.dispatchGesture.",
    types: ["InputController", "AccessibilityInputController", "MacroAccessibilityService"],
  },
  {
    pkg: "overlay",
    name: "Overlay / HUD",
    responsibility: "HUD de status (WindowManager) e visualização de debug com marcações. Nunca bloqueia o botão de parada.",
    types: ["OverlayManager", "DebugOverlayView"],
  },
  {
    pkg: "settings",
    name: "Configurações",
    responsibility: "DataStore tipado + perfis de calibração versionados (faixas HSV, thresholds, tamanhos esperados). Restaurar padrões.",
    types: ["SettingsRepository", "ColorProfile", "CalibrationProfile"],
  },
  {
    pkg: "debug",
    name: "Simulação",
    responsibility: "Modo simulação com frames gravados: mostra detecção, predição e decisão sem enviar nenhum gesto ao jogo.",
    types: ["SimulationMode", "RecordedFrameSource", "FrameSource"],
  },
  {
    pkg: "logging",
    name: "Logs & telemetria",
    responsibility: "Buffer em anel na memória + flush para arquivo. Métricas de FPS, latência por estágio e exportação de sessão.",
    types: ["MacroLogger", "SessionLog", "TelemetryEvent"],
  },
];

export const LOOP_STAGES = [
  { step: "01", label: "Frame RGBA_8888", spec: "≤ 960×540 · 10 fps" },
  { step: "02", label: "Recorte da ROI", spec: "O(1) · sem cópia" },
  { step: "03", label: "Detecções", spec: "barra + peixe + indicador" },
  { step: "04", label: "Estado do jogo", spec: "multi-sinal" },
  { step: "05", label: "Tracking + predição", spec: "EMA · x̂ = x + v·t" },
  { step: "06", label: "Decisão", spec: "P + zona morta" },
  { step: "07", label: "Gesto", spec: "dispatchGesture" },
];

// ------------------------------------------------------------------
// 01 — Máquina de estados (geometria do SVG)
// ------------------------------------------------------------------

export interface SmNode {
  id: string;
  label: string;
  x: number;
  y: number;
  w: number;
  tone: Tone;
  desc: string;
}

export const SM_H = 52;

export const SM_NODES: SmNode[] = [
  { id: "IDLE", label: "IDLE", x: 30, y: 120, w: 130, tone: "slate", desc: "Macro ligado, aguardando início. Nenhuma captura ativa, nenhum gesto em voo, consumo ~0." },
  { id: "WAITING", label: "WAITING_FOR_FISHING_UI", x: 210, y: 120, w: 230, tone: "cyan", desc: "Captura ativa. Varredura em frequência reduzida procurando a UI de pesca dentro da ROI." },
  { id: "DETECTING", label: "DETECTING", x: 490, y: 120, w: 140, tone: "amber", desc: "UI candidata encontrada. Confirmando barra + peixe + indicador simultâneos com continuidade temporal." },
  { id: "TRACKING", label: "TRACKING", x: 680, y: 120, w: 140, tone: "cyan", desc: "Alvos confirmados. EMA inicializada; velocidade e histórico sendo calculados. Ainda sem gestos." },
  { id: "CONTROLLING", label: "CONTROLLING", x: 870, y: 120, w: 170, tone: "emerald", desc: "Ciclo ativo: predição → decisão → gesto via Acessibilidade, com rate limiting e watchdog por ciclo." },
  { id: "LOST", label: "LOST_DETECTION", x: 380, y: 300, w: 175, tone: "amber", desc: "Confiança abaixo do limiar por N frames. Comandos suspensos na hora; última pose válida usada por ~300 ms no máximo." },
  { id: "FAILED", label: "FISHING_FAILED", x: 620, y: 300, w: 175, tone: "red", desc: "Sequência perdida (progresso esvaziado). Entradas liberadas imediatamente e contador de erros +1." },
  { id: "SUCCESS", label: "FISHING_SUCCESS", x: 870, y: 300, w: 190, tone: "emerald", desc: "Progresso completado. Gesto liberado, contador de pescas +1, telemetria da sessão registrada." },
  { id: "PAUSED", label: "PAUSED", x: 210, y: 300, w: 120, tone: "slate", desc: "Pausa manual. Captura congelada, entradas liberadas, estado preservado para retomar." },
  { id: "STOPPED", label: "STOPPED", x: 30, y: 470, w: 130, tone: "slate", desc: "Desligamento total: captura, serviço, overlay e todos os recursos liberados." },
  { id: "ERROR", label: "ERROR", x: 210, y: 470, w: 120, tone: "red", desc: "Falha crítica tratada (permissão revogada, projeção morta, OOM). Log completo + mensagem compreensível ao usuário." },
];

export interface SmEdge {
  id: string;
  from: string;
  to: string;
  d: string;
  tone: Tone;
  dashed?: boolean;
  label?: string;
  lx?: number;
  ly?: number;
}

export const SM_EDGES: SmEdge[] = [
  { id: "e1", from: "IDLE", to: "WAITING", d: "M160 146 L204 146", tone: "cyan", label: "iniciar", lx: 182, ly: 136 },
  { id: "e2", from: "WAITING", to: "DETECTING", d: "M440 146 L486 146", tone: "cyan", label: "UI detectada", lx: 463, ly: 136 },
  { id: "e3", from: "DETECTING", to: "TRACKING", d: "M630 146 L676 146", tone: "cyan", label: "3 alvos ok", lx: 653, ly: 136 },
  { id: "e4", from: "TRACKING", to: "CONTROLLING", d: "M820 146 L866 146", tone: "cyan", label: "conf ≥ limiar", lx: 843, ly: 136 },
  { id: "e5", from: "CONTROLLING", to: "SUCCESS", d: "M960 172 L960 294", tone: "emerald", label: "progresso 100%", lx: 968, ly: 240 },
  { id: "e6", from: "CONTROLLING", to: "FAILED", d: "M915 172 C915 222 707 232 707 296", tone: "red", label: "falha", lx: 806, ly: 208 },
  { id: "e7", from: "FAILED", to: "WAITING", d: "M707 352 L707 440 L238 440 L238 178", tone: "cyan", label: "nova tentativa", lx: 448, ly: 432 },
  { id: "e8", from: "CONTROLLING", to: "LOST", d: "M890 172 C890 252 630 240 560 296", tone: "amber", dashed: true, label: "perda de detecção", lx: 738, ly: 226 },
  { id: "e9", from: "LOST", to: "DETECTING", d: "M452 300 C452 240 558 240 558 178", tone: "amber", dashed: true, label: "reacquire", lx: 480, ly: 238 },
  { id: "e10", from: "LOST", to: "WAITING", d: "M380 318 C320 318 325 244 325 178", tone: "amber", dashed: true, label: "timeout", lx: 292, ly: 246 },
  { id: "e11", from: "SUCCESS", to: "WAITING", d: "M1000 352 L1000 412 L269 412 L269 178", tone: "emerald", label: "próximo ciclo", lx: 560, ly: 404 },
  { id: "e12", from: "WAITING", to: "PAUSED", d: "M300 172 C296 224 284 244 282 296", tone: "slate", dashed: true },
  { id: "e13", from: "PAUSED", to: "WAITING", d: "M312 296 C316 248 330 226 332 178", tone: "slate", dashed: true, label: "retomar", lx: 344, ly: 242 },
  { id: "e14", from: "LOST", to: "ERROR", d: "M467 352 C467 420 272 412 272 466", tone: "red", dashed: true, label: "erro crítico*", lx: 492, ly: 408 },
  { id: "e15", from: "ERROR", to: "STOPPED", d: "M210 496 L166 496", tone: "red", label: "encerrar", lx: 188, ly: 488 },
  { id: "e16", from: "STOPPED", to: "IDLE", d: "M95 470 L95 178", tone: "slate", dashed: true, label: "reset", lx: 103, ly: 330 },
];

export interface SmTransition {
  from: string;
  to: string;
  event: string;
}

export const SM_TRANSITIONS: SmTransition[] = [
  { from: "IDLE", to: "WAITING_FOR_FISHING_UI", event: " usuário inicia o Macro" },
  { from: "WAITING_FOR_FISHING_UI", to: "DETECTING", event: "assinatura visual da UI de pesca encontrada" },
  { from: "DETECTING", to: "TRACKING", event: "barra + peixe + indicador válidos em frames consecutivos" },
  { from: "TRACKING", to: "CONTROLLING", event: "confidence ≥ threshold configurável" },
  { from: "CONTROLLING", to: "FISHING_SUCCESS", event: "barra de progresso completada" },
  { from: "CONTROLLING", to: "FISHING_FAILED", event: "progresso esvaziado / animação de falha detectada" },
  { from: "CONTROLLING", to: "LOST_DETECTION", event: "confidence < threshold por N frames" },
  { from: "LOST_DETECTION", to: "DETECTING", event: "reacquire dentro da janela curta" },
  { from: "LOST_DETECTION", to: "WAITING_FOR_FISHING_UI", event: "timeout de perda (configurável)" },
  { from: "FISHING_SUCCESS", to: "WAITING_FOR_FISHING_UI", event: "aguarda próxima pescaria" },
  { from: "FISHING_FAILED", to: "WAITING_FOR_FISHING_UI", event: "aguarda próxima pescaria" },
  { from: "qualquer estado", to: "ERROR", event: "exceção crítica tratada ou permissão revogada" },
  { from: "ERROR", to: "STOPPED", event: "liberação total de recursos + log" },
  { from: "STOPPED", to: "IDLE", event: "pronto para novo ciclo" },
];

// ------------------------------------------------------------------
// 02 — Limitações reais do Android
// ------------------------------------------------------------------

export interface Limitation {
  title: string;
  severity: "BLOQUEANTE" | "RESTRIÇÃO" | "ATENÇÃO" | "RISCO EXTERNO";
  body: string;
  consequence: string;
}

export const LIMITATIONS: Limitation[] = [
  {
    title: "Segundo plano real: impossível",
    severity: "BLOQUEANTE",
    body: "Não existe API pública para capturar pixels de outro app minimizado nem para tocar nele em background. MediaProjection captura o que está na tela: com o Roblox minimizado, capturamos o launcher ou a tela de bloqueio.",
    consequence: "Alternativa implementada: Roblox em primeiro plano + macro como Foreground Service + tela mantida ligada (overlay com FLAG_KEEP_SCREEN_ON). É o mais próximo de 'background' que o Android permite legítimamente.",
  },
  {
    title: "MediaProjection: consentimento por sessão",
    severity: "RESTRIÇÃO",
    body: "O token (resultCode + Intent) é de uso único e não sobrevive à morte do processo nem a reboots. No Android 14 (API 34) o consentimento é por sessão, o callback da projeção é obrigatório e há captura parcial de tela opcional.",
    consequence: "Cada sessão de pesca exige um toque no diálogo do sistema. O app deixa isso explícito no fluxo de início — sem fingir persistência.",
  },
  {
    title: "Injeção de toque sem root",
    severity: "RESTRIÇÃO",
    body: "INJECT_EVENTS é protegido por assinatura do sistema. O único canal legítimo é AccessibilityService.dispatchGesture (API 24+): assíncrono, gestos de até 60 s e até 10 traços por descrição, latência variável (dezenas de ms).",
    consequence: "Hold contínuo é montado como cadeia de gestos com willContinue(). O serviço precisa ser ativado manualmente pelo usuário nas Configurações — não há como conceder por código.",
  },
  {
    title: "Telas protegidas (FLAG_SECURE)",
    severity: "ATENÇÃO",
    body: "Janelas com FLAG_SECURE capturam preto. O Roblox não usa a flag hoje, mas isso é verificação empírica por versão, não garantia.",
    consequence: "O pipeline valida 'frame preto constante' e reporta ERROR explicável em vez de sair tocando às cegas.",
  },
  {
    title: "Fabricantes que matam serviços",
    severity: "ATENÇÃO",
    body: "MIUI, ColorOS, OneUI e afins aplicam agendamento agressivo de bateria e podem encerrar Foreground Services em sessões longas.",
    consequence: "Guia por fabricante dentro do app + intents para 'sem restrição de bateria' e autostart. Watchdog detecta morte silenciosa.",
  },
  {
    title: "Termos de Serviço do Roblox",
    severity: "RISCO EXTERNO",
    body: "Automação de gameplay viola os ToS do Roblox e pode resultar em banimento da conta. Isso independe de qualquer decisão técnica.",
    consequence: "Risco assumido pelo usuário. O Modo Simulação existe para desenvolver e calibrar sem interagir com o jogo.",
  },
];

export interface AndroidVersion {
  api: string;
  name: string;
  impact: string;
}

export const ANDROID_VERSIONS: AndroidVersion[] = [
  { api: "API 26+", name: "Android 8", impact: "Piso do projeto (minSdk 26): dispatchGesture, canais de notificação e FGS modernos disponíveis." },
  { api: "API 31", name: "Android 12", impact: "FGS não pode mais iniciar do background; trampolim de notificação proibido — start deve ocorrer com o app visível." },
  { api: "API 33", name: "Android 13", impact: "POST_NOTIFICATIONS vira permissão de runtime — necessária para a notificação persistente com botão PARAR." },
  { api: "API 34", name: "Android 14", impact: "Tipo de FGS obrigatório: FOREGROUND_SERVICE_MEDIA_PROJECTION + mediaProjection no manifest. Callback da projeção obrigatório. Consentimento por sessão; captura parcial disponível." },
  { api: "API 35", name: "Android 15", impact: "Alvo do projeto (targetSdk 35): restrições a FGS iniciados em BOOT_COMPLETED e regras mais rígidas de overlay/janelas." },
  { api: "API 36", name: "Android 16", impact: "Monitorado: enforcement contínuo de tipos de FGS e políticas de energia. Validado na Fase 13 antes de elevar o target." },
];

export interface PermissionRow {
  permission: string;
  how: string;
  why: string;
}

export const PERMISSIONS: PermissionRow[] = [
  { permission: "MediaProjection (consentimento)", how: "Diálogo do sistema, a cada sessão", why: "Ler os frames da tela — sem isso não há visão computacional." },
  { permission: "AccessibilityService", how: "Ativação manual nas Configurações", why: "Único canal sem root para injetar toque/segurar a tela no jogo." },
  { permission: "SYSTEM_ALERT_WINDOW", how: "Tela de permissão do sistema", why: "Overlay de status/debug e manter a tela acordada por cima do jogo." },
  { permission: "POST_NOTIFICATIONS (13+)", how: "Runtime, no primeiro start", why: "Notificação persistente obrigatória do Foreground Service, com ação PARAR." },
  { permission: "Bateria sem restrição (opcional)", how: "Intent para configurações", why: "Reduz morte do serviço por OEMs agressivos em sessões longas." },
];

// ------------------------------------------------------------------
// 03 — Captura
// ------------------------------------------------------------------

export const PIPELINE_STAGES = [
  { name: "Roblox visível", spec: "janela em foreground", detail: "Pré-condição dura: o pacote com.roblox.client precisa estar na janela ativa (verificado via eventos do próprio AccessibilityService)." },
  { name: "MediaProjection", spec: "consentimento do sistema", detail: "Token de uso único obtido via createScreenCaptureIntent(). Registrado callback onStop antes de qualquer VirtualDisplay (exigência Android 14+)." },
  { name: "VirtualDisplay", spec: "superfície virtual", detail: "Display espelhado em resolução reduzida apontando para o ImageReader — não para a tela física." },
  { name: "ImageReader", spec: "RGBA_8888 · maxImages 2", detail: "acquireLatestImage() sempre: frames velhos são descartados, nunca enfileirados. Callback em HandlerThread dedicado." },
  { name: "FrameBus", spec: "conflated · latest-wins", detail: "SharedFlow com conflation: o consumidor sempre recebe o frame mais recente. FPS de processamento < FPS de captura, sem fila crescente." },
  { name: "Motor de visão", spec: "Dispatchers.Default", detail: "Amostragem controlada: processa 1 em N frames conforme processingFps configurado. Zero trabalho na UI thread." },
];

export const CAPTURE_DEFAULTS = [
  { k: "captureWidth", v: "960", note: "paisagem · retrato: 720" },
  { k: "captureHeight", v: "540", note: "fallback 480p sob thermal" },
  { k: "captureFps", v: "10", note: "captura ≠ exibição" },
  { k: "processingFps", v: "10–15", note: "amostragem de frames" },
  { k: "maxImages", v: "2", note: "sempre acquireLatest" },
  { k: "latência-alvo", v: "≤ 100 ms", note: "fim-a-fim por decisão" },
];

// ------------------------------------------------------------------
// 04 — Visão
// ------------------------------------------------------------------

export const DETECTORS = [
  {
    name: "FishingBarDetector",
    returns: "FishingBarDetection { left, top, right, bottom, confidence }",
    body: "Procura um retângulo longo e horizontal por segmentação cromática + validação geométrica (razão de aspecto, área, posição relativa em % da tela — nunca coordenadas absolutas) + continuidade temporal.",
  },
  {
    name: "FishDetector",
    returns: "FishDetection { centerX, centerY, width, height, confidence, timestamp }",
    body: "Busca o blob do peixe apenas dentro da barra: faixa de cor calibrável, centro de massa do componente conectado, rejeição de blobs fora da faixa de tamanho esperada.",
  },
  {
    name: "PlayerIndicatorDetector",
    returns: "IndicatorDetection { centerX, centerY, width, height, confidence, timestamp }",
    body: "Detector independente do peixe: localiza o bloco do jogador (alto contraste/brilho) dentro da barra, com a mesma máquina de validação geométrica.",
  },
  {
    name: "FishingStateDetector",
    returns: "NO_FISHING · FISHING_ACTIVE · FISHING_SUCCESS · FISHING_FAILED · UNKNOWN",
    body: "Decisão multi-sinal: presença simultânea de barra, indicador e textura de progresso. Nunca um único pixel ou cor isolada — histerese temporal evita piscar de estado.",
  },
];

export const CALIBRATION_POINTS = [
  "Faixas HSV (hMin/hMax · sMin · vMin) por alvo: barra, peixe, indicador",
  "Tamanhos esperados em % da tela (min/max) — independente de resolução",
  "Thresholds de confidence por detector + threshold global do estado",
  "ROI padrão: FULL_SCREEN · CUSTOM_REGION · AUTO_REGION",
  "Perfis versionados: atualização visual do jogo = novo perfil, sem rebuild",
];

// ------------------------------------------------------------------
// 05 — Controle
// ------------------------------------------------------------------

export const CONTROL_FORMULAS = [
  { tag: "EMA", code: "x̂ₙ = α·xₙ + (1−α)·x̂ₙ₋₁", note: "α ≈ 0.35 · custo O(1), sem alocação" },
  { tag: "VELOCIDADE", code: "vₙ = EMA( (xₙ − xₙ₋₁) / Δt )", note: "suavizada por EMA própria" },
  { tag: "PREDIÇÃO", code: "x_pred = x̂ + v · t_pred", note: "|v·t| limitado a 12% da barra" },
  { tag: "ERRO", code: "e = x̂_peixe − x̂_indicador", note: "sinal define pressionar ou soltar" },
  { tag: "DECISÃO", code: "|e| > deadZone ? PRESS/HOLD : NO_ACTION", note: "histerese anti-chattering" },
];

export const CONTROL_PARAMS = [
  { k: "deadZone", v: "± 3–6 px", note: "erro tolerável sem ação" },
  { k: "minimumHoldTime", v: "60 ms", note: "evita toques fantasmas" },
  { k: "minimumReleaseTime", v: "60 ms", note: "evita PRESS/RELEASE em alta frequência" },
  { k: "maximumHoldTime", v: "900 ms", note: "fail-safe de gesto preso" },
  { k: "maxCommandRate", v: "20 Hz", note: "teto de comandos por segundo" },
  { k: "predictionTime", v: "40–80 ms", note: "compensa latência do gesto" },
  { k: "controlGain (Kp)", v: "calibrável", note: "proporcional simples e estável" },
  { k: "lostDetectionTimeout", v: "300 ms", note: "última pose válida; depois, NO_ACTION" },
];

// ------------------------------------------------------------------
// 06 — Input
// ------------------------------------------------------------------

export const GESTURE_SEQUENCE = [
  {
    phase: "PRESS",
    code: "stroke(p0 → p0, duração≈40ms, willContinue=true)",
    body: "Toque inicial curto em ponto neutro configurável (padrão: centro inferior da barra, longe de botões do jogo).",
  },
  {
    phase: "HOLD",
    code: "continueStroke(..., 100–200ms, willContinue=true)",
    body: "Enquanto o controlador pedir HOLD, despacha continuações em cadeia (cada uma no callback da anterior). Assim se constrói 'manter pressionado' dentro do limite de 60 s por gesto.",
  },
  {
    phase: "RELEASE",
    code: "continueStroke(p0 → p0, ~20ms, willContinue=false)",
    body: "Encerramento explícito. RELEASE também é forçado pelo watchdog: visão perdida, projeção morta, pausa ou stop sempre soltam o dedo virtual.",
  },
];

export const INPUT_CHECKS = [
  "Serviço de acessibilidade habilitado? Se não, UI guia a ativação e o app opera apenas em MODO SIMULAÇÃO.",
  "Roblox em foreground? Verificado via TYPE_WINDOW_STATE_CHANGED do próprio serviço (pacote com.roblox.client) — sem permissão extra.",
  "dispatchGesture retornou falso ou onCancelled? Conta como falha, registra e reavalia antes de novo comando.",
  "Medição contínua de latência de gesto alimenta o predictionTime (compensação adaptativa).",
];

// ------------------------------------------------------------------
// 07 — Estrutura de pastas
// ------------------------------------------------------------------

export interface TreeEntry {
  path: string;
  depth: number;
  kind: "root" | "dir" | "file";
  note?: string;
}

export const FILE_TREE: TreeEntry[] = [
  { path: "app/", depth: 0, kind: "root", note: "módulo Gradle único" },
  { path: "build.gradle.kts", depth: 1, kind: "file", note: "AGP 8.5 · Kotlin 2.0 · SDK 26→35" },
  { path: "src/main/AndroidManifest.xml", depth: 1, kind: "file", note: "FGS mediaProjection · acessibilidade" },
  { path: "src/main/java/com/fischvision/macro/", depth: 1, kind: "dir" },
  { path: "app/", depth: 2, kind: "dir", note: "FischVisionApp · ServiceLocator" },
  { path: "ui/", depth: 2, kind: "dir", note: "MainActivity · telas Compose" },
  { path: "service/", depth: 2, kind: "dir", note: "MacroForegroundService · MacroEngine" },
  { path: "capture/", depth: 2, kind: "dir", note: "ScreenCaptureManager · FrameBus" },
  { path: "vision/", depth: 2, kind: "dir", note: "VisionPipeline · RoiManager" },
  { path: "detector/", depth: 2, kind: "dir", note: "4 detectores · contratos de detecção" },
  { path: "tracker/", depth: 2, kind: "dir", note: "TargetTracker · EMA · predição" },
  { path: "controller/", depth: 2, kind: "dir", note: "FishingController · ControlConfig" },
  { path: "input/", depth: 2, kind: "dir", note: "InputController · MacroAccessibilityService" },
  { path: "overlay/", depth: 2, kind: "dir", note: "OverlayManager · DebugOverlayView" },
  { path: "settings/", depth: 2, kind: "dir", note: "DataStore · perfis de calibração" },
  { path: "debug/", depth: 2, kind: "dir", note: "SimulationMode · frames gravados" },
  { path: "logging/", depth: 2, kind: "dir", note: "MacroLogger · exportação" },
  { path: "src/main/res/xml/macro_accessibility_config.xml", depth: 1, kind: "file", note: "canPerformGestures · flags" },
  { path: "src/test/", depth: 1, kind: "dir", note: "unitários: detectores, tracker, controller" },
  { path: "src/androidTest/", depth: 1, kind: "dir", note: "integração: gestos + serviço em device" },
];

// ------------------------------------------------------------------
// 08 — Dependências
// ------------------------------------------------------------------

export interface DepRow {
  name: string;
  version: string;
  why: string;
}

export const DEPS_RUNTIME: DepRow[] = [
  { name: "Kotlin + AGP", version: "2.0.x · 8.5.x", why: "Toolchain base; paridade verificada na Fase 1 antes de fixar." },
  { name: "androidx.lifecycle (service, runtime-ktx, process)", version: "2.8.x", why: "Escopo de coroutines supervisionado atrelado ao ciclo de vida do serviço." },
  { name: "kotlinx-coroutines-android", version: "1.9.x", why: "Todo o pipeline é assíncrono: FrameBus conflated, Dispatchers dedicados, supervisão." },
  { name: "Jetpack Compose BOM + Material 3", version: "2024.12.x", why: "UI declarativa reativa; roda com folga no minSdk 26." },
  { name: "DataStore Preferences", version: "1.1.x", why: "Configurações tipadas e perfis de calibração sem SQL nem SharedPreferences legado." },
  { name: "kotlinx-serialization-json", version: "1.7.x", why: "Serialização versionada dos perfis de cor/threshold (importar/exportar calibração)." },
];

export const DEPS_TEST: DepRow[] = [
  { name: "JUnit 4", version: "4.13.x", why: "Base dos testes unitários de detectores, tracker e controlador." },
  { name: "kotlinx-coroutines-test", version: "1.9.x", why: "Testes determinísticos do pipeline assíncrono e das máquinas de estado." },
  { name: "Robolectric", version: "4.13.x", why: "Frames sintéticos RGBA em JVM — testa visão computacional sem device." },
  { name: "Turbine", version: "1.1.x", why: "Asserções sobre StateFlow/SharedFlow (estados do macro e FrameBus)." },
];

export const EXCLUDED_DEPS = [
  { name: "OpenCV", why: "14–40 MB por ABI e inicialização JNI que falha em aparelhos diversos. Segmentação de cor + componentes conectados em Kotlin puro resolve o caso; decisão revisitada na Fase 13 com dados reais." },
  { name: "Hilt / Dagger", why: "Custo de kapt/ksp desproporcional para um app deste porte; injeção manual via ServiceLocator é explícita e suficiente." },
  { name: "WorkManager", why: "Não existe trabalho deferível aqui — o Foreground Service cobre toda a execução contínua." },
  { name: "Firebase / Analytics", why: "Telemetria 100% local (logging/). Privacidade e menos superfície de falha." },
];

// ------------------------------------------------------------------
// 09 — Riscos
// ------------------------------------------------------------------

export interface Risk {
  title: string;
  level: "ALTA" | "MÉDIA" | "BAIXA";
  mitigation: string;
}

export const RISKS: Risk[] = [
  { title: "Update visual do Fisch invalida perfis de cor", level: "ALTA", mitigation: "Perfis de calibração externalizados e versionados + modo de recalibração guiada com captura de amostra. Nenhum valor visual fica hardcoded." },
  { title: "Banimento da conta (ToS Roblox)", level: "ALTA", mitigation: "Fora do controle técnico — declarado em texto claro no app. Modo Simulação para desenvolver sem interagir com o jogo." },
  { title: "Latência variável do dispatchGesture", level: "MÉDIA", mitigation: "Medição contínua de latência alimentando o predictionTime; clamp de predição e rate limiting absorvem jitter." },
  { title: "OEM encerra o Foreground Service", level: "MÉDIA", mitigation: "Guia por fabricante, intent de bateria irrestrita e watchdog que detecta morte silenciosa e encerra em estado seguro." },
  { title: "Resoluções e proporções de tela diversas", level: "MÉDIA", mitigation: "Tudo ancorado em % de tela e tamanhos relativos; captura normalizada para resolução fixa antes da visão." },
  { title: "Falsos positivos do detector", level: "MÉDIA", mitigation: "Confidence + continuidade temporal + máquina de estados: um frame estranho nunca dispara gesto." },
  { title: "Bateria e tela ligada por horas", level: "MÉDIA", mitigation: "FPS conservador, ROI reduzida, recomendação de carregador e overlay escuro." },
  { title: "Consentimento repetido a cada sessão (UX)", level: "BAIXA", mitigation: "Fluxo de início com um diálogo só e estado visual claro (captura ativa / aguardando consentimento)." },
];

// ------------------------------------------------------------------
// 10 — Fases
// ------------------------------------------------------------------

export interface Phase {
  n: string;
  title: string;
  scope: string[];
  gate: string;
}

export const PHASES: Phase[] = [
  { n: "01", title: "Arquitetura + projeto compilável", scope: ["Gradle/AGP/Kotlin/SDK fixados", "Pacotes e interfaces do núcleo", "App 'hello' com tema e navegação"], gate: "build verde + instala no device" },
  { n: "02", title: "Captura de tela", scope: ["Consent flow MediaProjection", "FGS tipo mediaProjection + ImageReader", "Contagem de frames na UI"], gate: "10 fps estáveis por 10 min" },
  { n: "03", title: "Visualização da captura", scope: ["Preview do frame no modo debug", "Métricas: capture FPS, memória", "Validação em 2+ aparelhos"], gate: "sem leak de Image/Bitmap" },
  { n: "04", title: "Detecção da barra", scope: ["Calibração com frames reais gravados", "FishingBarDetector + confidence", "Testes com frames sintéticos"], gate: "≥ 95% de acerto nos frames de teste" },
  { n: "05", title: "Detecção do peixe", scope: ["FishDetector dentro da barra", "Rejeição de blobs inválidos"], gate: "zero falso positivo no corpus" },
  { n: "06", title: "Detecção do indicador", scope: ["PlayerIndicatorDetector independente", "Validação geométrica"], gate: "acerto ≥ peixe no mesmo corpus" },
  { n: "07", title: "Tracking", scope: ["EMA posição + velocidade", "Buffer circular sem alocação", "Predição com clamp"], gate: "testes de ruído < deadZone" },
  { n: "08", title: "Controlador", scope: ["Zona morta + histerese", "Tempos mínimos e teto de taxa"], gate: "sem chattering em banco de testes" },
  { n: "09", title: "Input", scope: ["MacroAccessibilityService + config XML", "Cadeia PRESS/HOLD/RELEASE", "Verificação de foreground"], gate: "gesto visível em app de teste" },
  { n: "10", title: "Foreground Service", scope: ["Orquestração total do MacroEngine", "Notificação com PARAR", "Watchdog + fail-safe de release"], gate: "Activity fechada ≠ macro parado" },
  { n: "11", title: "Overlay", scope: ["HUD de status sobre o jogo", "Debug anotado (ROI, caixas, predição)"], gate: "overlay nunca bloqueia PARAR" },
  { n: "12", title: "Integração completa", scope: ["Máquina de estados fim-a-fim", "Modo Simulação + tolerância a perda", "Logs de sessão exportáveis"], gate: "ciclo completo real no device" },
  { n: "13", title: "Testes + otimização", scope: ["Suíte unitária + Robolectric", "Perfis por aparelho · bateria", "Redução de alocações"], gate: "critérios de aceitação 19/19" },
];

// ------------------------------------------------------------------
// Critérios de aceitação
// ------------------------------------------------------------------

export const ACCEPTANCE = [
  "Compilar sem erros",
  "Instalar em Android real",
  "Solicitar permissões corretamente",
  "Iniciar / parar captura",
  "Processar frames",
  "Detectar a interface de pesca",
  "Detectar o peixe",
  "Detectar o indicador",
  "Calcular posição relativa",
  "Fazer tracking",
  "Controlar via camada de input disponível",
  "Timeout de segurança ativo",
  "Modo DEBUG funcional",
  "Foreground Service quando necessário",
  "Independência da Activity",
  "UI sem travamentos",
  "Recursos liberados corretamente",
  "Logs úteis e exportáveis",
  "Modo de simulação",
];

export const SDK_TABLE = [
  { k: "minSdk", v: "26", note: "Android 8.0 · cobre ~95% dos aparelhos ativos e todas as APIs de gesto necessárias" },
  { k: "targetSdk", v: "35", note: "Android 15 · obriga conformidade com tipos de FGS — já tratada por design" },
  { k: "compileSdk", v: "35", note: "API 36 (Android 16) avaliada na Fase 13 antes de elevar o target" },
  { k: "JDK / toolchain", v: "17", note: "exigência do AGP 8.5+ · Gradle 8.7+ · Kotlin 2.0" },
];

export const PRIORIDADES = ["CORREÇÃO", "ESTABILIDADE", "COMPATIBILIDADE", "PERFORMANCE", "INTERFACE"];
