import { useState } from "react";
import Nav from "./components/Nav";
import ExecutionView from "./phase1/ExecutionView";
import Hero from "./components/Hero";
import Architecture from "./components/Architecture";
import Limitations from "./components/Limitations";
import Capture from "./components/Capture";
import Vision from "./components/Vision";
import Control from "./components/Control";
import Input from "./components/Input";
import Structure from "./components/Structure";
import Dependencies from "./components/Dependencies";
import Risks from "./components/Risks";
import Phases from "./components/Phases";
import Footer from "./components/Footer";
import Phase1 from "./phase1/Phase1";

type View = "arch" | "phase1" | "exec";

function Divider() {
  return (
    <div className="mx-auto w-full max-w-6xl px-5 sm:px-8">
      <div className="hairline" />
    </div>
  );
}

function ArchView() {
  return (
    <main>
      <Hero />
      <Architecture />
      <Divider />
      <Limitations />
      <Divider />
      <Capture />
      <Divider />
      <Vision />
      <Divider />
      <Control />
      <Divider />
      <Input />
      <Divider />
      <Structure />
      <Divider />
      <Dependencies />
      <Divider />
      <Risks />
      <Divider />
      <Phases />
      <Footer />
    </main>
  );
}

export default function App() {
  const [view, setView] = useState<View>("exec");

  return (
    <div className="grain relative min-h-screen bg-abyss text-slate-200">
      <Nav view={view} onChange={setView} />
      {view === "exec" ? (
        <ExecutionView onOpenPhase1={() => setView("phase1")} />
      ) : view === "phase1" ? (
        <Phase1 onOpenArch={() => setView("arch")} />
      ) : (
        <ArchView />
      )}
    </div>
  );
}
