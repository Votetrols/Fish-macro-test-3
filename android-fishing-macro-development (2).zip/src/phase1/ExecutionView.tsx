import { Reveal } from "../components/ui";
import { ArrowLeft, FileSearch, Gavel, ShieldAlert, Workflow } from "lucide-react";

const PHASES = [
  { n: "F1", title: "Fundação", impl: "11 estados · 14 eventos · FrameBus conflated · contratos", tests: "35 casos (compartilhados)", gate: "BLOCKED·exec", tone: "cyan" },
  { n: "F1.1", title: "Verificação de ambiente", impl: "auditoria estática executada + relatório", tests: "toolchain: ausente", gate: "BLOCKED·toolchain", tone: "amber" },
  { n: "F2", title: "Captura real", impl: "MediaProjection + VirtualDisplay + ImageReader + payload com release idempotente + FGS funcional", tests: "7 casos", gate: "BLOCKED·exec", tone: "cyan" },
  { n: "F3", title: "Visão e detecção", impl: "ROI relativa · HSV calibrável · blobs BFS · dois estágios barra→peixe/indicador", tests: "12 casos", gate: "BLOCKED·exec", tone: "cyan" },
  { n: "F4", title: "Tracking e decisão", impl: "EMA pos/vel · associação anti-teleporte · zona morta + histerese + tetos + fail-safe", tests: "17 casos", gate: "BLOCKED·exec", tone: "cyan" },
  { n: "F5", title: "Input real", impl: "dispatchGesture real · cadeia willContinue cancelável (documentando ausência de cancel API) · gates+limites", tests: "5 casos (suíte F6)", gate: "BLOCKED·exec", tone: "cyan" },
  { n: "F6", title: "Integração completa", impl: "MacroEngine orquestra tudo sob a FSM · overlay real com controles · hose cut em PAUSED/STOPPED/ERROR", tests: "10 casos", gate: "BLOCKED·exec", tone: "cyan" },
  { n: "F7", title: "Auditoria final", impl: "varredura real de código + FINAL_AUDIT.md", tests: "executada (estática)", gate: "EXECUTADA", tone: "emerald" },
] as const;

const AUDIT_SCANS = [
  ["TODOs críticos disfarçados", "0", "único TODO é dívida documentada (built-in Kotlin AGP 9→10)"],
  ["stubs/UnsupportedOperationException", "0", "—"],
  ["assertTrue(true)", "0 em código", "2 ocorrências em docs citando a proibição"],
  ["fakes em produção (app/src/main)", "0", "todos os fakes confinados a app/src/test"],
  ["APIs inventadas", "0", "apenas plataforma documentada: MediaProjection · ImageReader · GestureDescription · WindowManager"],
  ["release/lifecycle", "pass estática", "payload em finally · escopo cancelado · overlay destruído · release idempotente"],
];

export default function ExecutionView({ onOpenPhase1 }: { onOpenPhase1: () => void }) {
  return (
    <div className="mx-auto w-full max-w-6xl px-5 pb-20 pt-32 sm:px-8">
      <button
        onClick={onOpenPhase1}
        className="mono mb-8 flex items-center gap-2 text-[10px] tracking-[0.18em] text-slate-500 transition-colors hover:text-cyan-300"
      >
        <ArrowLeft size={12} /> CÓDIGO + GATES (FASE 1)
      </button>

      <Reveal>
        <div className="flex flex-wrap items-center gap-3">
          <span className="mono-tag rounded-full border border-cyan-400/30 bg-cyan-400/10 px-3 py-1.5 text-cyan-300">
            EXECUÇÃO SEQUENCIAL F1 → F7
          </span>
          <span className="mono-tag flex items-center gap-2 rounded-full border border-amber-400/40 bg-amber-400/10 px-3 py-1.5 text-amber-300">
            <ShieldAlert size={11} /> VEREDITO FINAL: BLOCKED (EXECUÇÃO LOCAL PENDENTE)
          </span>
        </div>
      </Reveal>
      <Reveal delay={0.06}>
        <h1 className="mt-5 text-4xl font-bold leading-[1.02] tracking-tight text-slate-50 sm:text-6xl">
          Sete fases, nenhuma simulada.
          <br />
          <span className="text-glow bg-gradient-to-r from-cyan-300 to-teal-300 bg-clip-text text-transparent">
            Toda a cadeia existe em código real.
          </span>
        </h1>
      </Reveal>
      <Reveal delay={0.12}>
        <p className="mt-5 max-w-3xl text-[14px] leading-relaxed text-slate-400">
          Captura → Visão → Detecção → Tracking → Decisão → Input → Integração: tudo escrito contra
          APIs oficiais da plataforma, com 57 casos de teste e fakes confinados ao test source set.
          Os gates executáveis (build/testes/lint/device) permanecem <span className="text-amber-300">BLOCKED</span>
          &nbsp;pela ausência de toolchain Android neste ambiente — e nada foi marcado como
          PASS sem execução. Essa é a diferença entre um projeto e uma promessa.
        </p>
      </Reveal>

      {/* phase table */}
      <div className="mt-12 space-y-2">
        {PHASES.map((p, i) => (
          <Reveal key={p.n} delay={Math.min(i * 0.04, 0.25)}>
            <div className="panel flex flex-col gap-2 p-4 sm:flex-row sm:items-center sm:gap-5 sm:p-5">
              <span className="mono w-12 shrink-0 text-lg font-bold text-cyan-300">{p.n}</span>
              <div className="min-w-0 flex-1">
                <div className="text-[14px] font-semibold text-slate-100">{p.title}</div>
                <div className="mt-1 text-[11.5px] leading-relaxed text-slate-400">{p.impl}</div>
                <div className="mono mt-1 text-[9px] tracking-wide text-slate-600">TESTES: {p.tests}</div>
              </div>
              <span
                className={`mono shrink-0 rounded-full border px-3 py-1 text-[8.5px] tracking-[0.12em] ${
                  p.tone === "emerald"
                    ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-300"
                    : p.tone === "amber"
                      ? "border-amber-400/40 bg-amber-400/10 text-amber-300"
                      : "border-cyan-400/30 bg-cyan-400/10 text-cyan-300"
                }`}
              >
                {p.gate}
              </span>
            </div>
          </Reveal>
        ))}
      </div>

      {/* audit scans */}
      <Reveal className="mt-12">
        <div className="mono-tag mb-4 flex items-center gap-2 text-slate-400">
          <FileSearch size={13} className="text-cyan-300" />
          VERIFICAÇÃO DE CÓDIGO — EXECUTADA DE VERDADE (F7)
        </div>
        <div className="panel overflow-hidden">
          {AUDIT_SCANS.map(([k, v, note]) => (
            <div key={k as string} className="grid gap-1 border-b border-white/[0.05] px-5 py-3.5 last:border-0 sm:grid-cols-[280px_140px_1fr] sm:items-center sm:gap-4">
              <span className="mono text-[11px] text-slate-300">{k}</span>
              <span className="mono text-[11px] font-semibold text-emerald-300">{v}</span>
              <span className="text-[11px] text-slate-500">{note}</span>
            </div>
          ))}
        </div>
      </Reveal>

      {/* final verdict */}
      <Reveal className="mt-12">
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="rounded-2xl border border-amber-400/30 bg-amber-400/[0.06] p-6 text-center">
            <Gavel className="mx-auto text-amber-300" size={20} />
            <div className="mono mt-3 text-[11px] tracking-[0.22em] text-amber-200">CRITÉRIO FINAL</div>
            <div className="mono mt-1 text-3xl font-bold tracking-tight text-amber-300">BLOCKED</div>
            <p className="mx-auto mt-2 max-w-xs text-[11.5px] leading-relaxed text-amber-100/70">
              APK, SHA-256 e métricas de estabilidade não existem aqui — logo não são exibidos.
              APPROVED exige build/testes/lint/device verdes, localmente.
            </p>
          </div>
          <div className="rounded-2xl border border-cyan-400/25 bg-cyan-400/[0.05] p-6 text-center">
            <Workflow className="mx-auto text-cyan-300" size={20} />
            <div className="mono mt-3 text-[11px] tracking-[0.22em] text-cyan-200">O QUE JÁ É VERDADE</div>
            <p className="mx-auto mt-2 max-w-xs text-[12px] leading-relaxed text-cyan-100/80">
              60 artefatos Android reais versionados · 57 casos de teste JVM · zero APIs inventadas ·
              zero fakes em produção · fail-safe em todas as saídas · auditoria estática executada.
            </p>
          </div>
        </div>
      </Reveal>
    </div>
  );
}
