import { useState } from "react";
import { Reveal } from "../components/ui";
import FileBrowser from "./FileBrowser";
import { FILE_META, GATES, REPORT, RUNBOOK, STACK_AUDIT, TEST_MATRIX } from "./data";
import {
  AlertOctagon, ArrowLeft, BadgeCheck, BookOpenCheck, Boxes, FlaskConical,
  ListChecks, PackageCheck, ShieldQuestion, TerminalSquare, FileStack, CircleDot,
} from "lucide-react";

// ------------------------------------------------------------------
// Espelho TypeScript 1:1 da tabela de transições de MacroStateMachine.kt
// (demonstração interativa — NÃO substitui ./gradlew test)
// ------------------------------------------------------------------

type S =
  | "IDLE" | "WAITING_FOR_FISHING_UI" | "DETECTING" | "TRACKING" | "CONTROLLING"
  | "LOST_DETECTION" | "FISHING_FAILED" | "FISHING_SUCCESS" | "PAUSED" | "STOPPED" | "ERROR";
type E =
  | "Start" | "Pause" | "Resume" | "Stop" | "FrameAvailable" | "DetectionFound"
  | "DetectionLost" | "ControlRequested" | "FishingSuccess" | "FishingFailed"
  | "FatalError" | "ProjectionStopped" | "AccessibilityUnavailable";

const EVENTS: E[] = [
  "Start", "Pause", "Resume", "Stop", "FrameAvailable", "DetectionFound", "DetectionLost",
  "ControlRequested", "FishingSuccess", "FishingFailed", "ProjectionStopped", "AccessibilityUnavailable", "FatalError",
];

function reduce(from: S, ev: E, pausedFrom: S | null): { to: S; ok: boolean } {
  switch (ev) {
    case "Start":
      return ["IDLE", "STOPPED", "ERROR"].includes(from)
        ? { to: "WAITING_FOR_FISHING_UI", ok: true } : { to: from, ok: false };
    case "Pause":
      return ["WAITING_FOR_FISHING_UI", "DETECTING", "TRACKING", "CONTROLLING", "LOST_DETECTION"].includes(from)
        ? { to: "PAUSED", ok: true } : { to: from, ok: false };
    case "Resume":
      return from === "PAUSED"
        ? { to: pausedFrom ?? "WAITING_FOR_FISHING_UI", ok: true } : { to: from, ok: false };
    case "Stop":
      return from === "STOPPED" ? { to: from, ok: false } : { to: "STOPPED", ok: true };
    case "FatalError":
      return { to: "ERROR", ok: true };
    case "FrameAvailable":
      return ["WAITING_FOR_FISHING_UI", "DETECTING", "TRACKING", "CONTROLLING"].includes(from)
        ? { to: from, ok: true } : { to: from, ok: false };
    case "DetectionFound":
      if (from === "WAITING_FOR_FISHING_UI" || from === "LOST_DETECTION") return { to: "DETECTING", ok: true };
      if (from === "DETECTING") return { to: "TRACKING", ok: true };
      return { to: from, ok: false };
    case "DetectionLost":
      if (from === "CONTROLLING" || from === "TRACKING") return { to: "LOST_DETECTION", ok: true };
      if (from === "FISHING_SUCCESS" || from === "FISHING_FAILED") return { to: "WAITING_FOR_FISHING_UI", ok: true };
      return { to: from, ok: false };
    case "ControlRequested":
      return from === "TRACKING" || from === "CONTROLLING" ? { to: "CONTROLLING", ok: true } : { to: from, ok: false };
    case "FishingSuccess":
      return from === "CONTROLLING" ? { to: "FISHING_SUCCESS", ok: true } : { to: from, ok: false };
    case "FishingFailed":
      return from === "CONTROLLING" ? { to: "FISHING_FAILED", ok: true } : { to: from, ok: false };
    case "ProjectionStopped":
      return ["WAITING_FOR_FISHING_UI", "DETECTING", "TRACKING", "CONTROLLING", "LOST_DETECTION", "PAUSED"].includes(from)
        ? { to: "IDLE", ok: true } : { to: from, ok: false };
    case "AccessibilityUnavailable":
      return ["TRACKING", "CONTROLLING", "LOST_DETECTION"].includes(from)
        ? { to: "ERROR", ok: true } : { to: from, ok: true };
  }
}

function FsmBench() {
  const [state, setState] = useState<S>("IDLE");
  const [pausedFrom, setPausedFrom] = useState<S | null>(null);
  const [log, setLog] = useState<{ ok: boolean; text: string }[]>([]);

  const fire = (ev: E) => {
    const r = reduce(state, ev, pausedFrom);
    if (ev === "Pause" && r.ok && r.to === "PAUSED") setPausedFrom(state);
    if (ev === "Resume" && r.ok) setPausedFrom(null);
    setLog((l) => [{ ok: r.ok, text: `${r.ok ? "ACEITA " : "REJEITADA "}  ${state} + ${ev} → ${r.to}` }, ...l].slice(0, 9));
    if (r.ok) setState(r.to);
  };

  return (
    <div className="panel h-full overflow-hidden">
      <div className="mono-tag flex items-center gap-2 border-b border-white/[0.07] px-5 py-3.5 text-slate-300">
        <CircleDot size={13} className="text-cyan-300" />
        TESTBENCH FSM — ESPELHO TS 1:1 DE MacroStateMachine.kt
      </div>
      <div className="p-5">
        <div className="flex items-end justify-between gap-4">
          <div>
            <div className="mono text-[9px] tracking-[0.2em] text-slate-500">ESTADO ATUAL</div>
            <div className="mono mt-1 text-3xl font-bold text-cyan-200">{state}</div>
            {pausedFrom && <div className="mono mt-1 text-[9.5px] text-slate-500">pausedFrom = {pausedFrom}</div>}
          </div>
          <div className="mono rounded border border-slate-400/20 bg-slate-400/5 px-2.5 py-1 text-[8.5px] tracking-[0.12em] text-slate-500">
            LÓGICA KOTLIN PORTADA 1:1 · VALIDAÇÃO REAL VIA ./gradlew test
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-1.5">
          {EVENTS.map((ev) => (
            <button
              key={ev}
              onClick={() => fire(ev)}
              className="mono rounded-md border border-cyan-400/25 bg-cyan-400/[0.06] px-2.5 py-1.5 text-[9px] tracking-wide text-cyan-200 transition-colors hover:bg-cyan-400/15"
            >
              {ev}
            </button>
          ))}
        </div>

        <div className="mono mt-4 min-h-[150px] rounded-lg border border-white/[0.07] bg-black/40 p-3 text-[10px] leading-[1.7]">
          {log.length === 0 && <span className="text-slate-600">// despache eventos para exercitar a máquina</span>}
          {log.map((l, i) => (
            <div key={i} className={l.ok ? "text-emerald-300/90" : "text-amber-300/90"}>
              {l.text}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------

const GATE_STYLE: Record<string, { chip: string; label: string }> = {
  DONE: { chip: "border-emerald-400/40 bg-emerald-400/10 text-emerald-300", label: "CUMPRIDO" },
  WRITTEN: { chip: "border-cyan-400/40 bg-cyan-400/10 text-cyan-300", label: "ESCRITO" },
  BLOCKED: { chip: "border-amber-400/40 bg-amber-400/10 text-amber-300", label: "BLOQUEADO" },
};

export default function Phase1({ onOpenArch }: { onOpenArch: () => void }) {
  return (
    <div className="relative">
      {/* hero band */}
      <div className="border-b border-white/[0.06] bg-gradient-to-b from-cyan-400/[0.06] to-transparent">
        <div className="mx-auto w-full max-w-6xl px-5 pb-12 pt-32 sm:px-8">
          <button
            onClick={onOpenArch}
            className="mono mb-8 flex items-center gap-2 text-[10px] tracking-[0.18em] text-slate-500 transition-colors hover:text-cyan-300"
          >
            <ArrowLeft size={12} /> DOCUMENTO DE ARQUITETURA (FASE 0)
          </button>

          <Reveal>
            <div className="flex flex-wrap items-center gap-3">
              <span className="mono-tag rounded-full border border-cyan-400/30 bg-cyan-400/10 px-3 py-1.5 text-cyan-300">
                FASE 1 — ANDROID COMPILÁVEL / SKELETON REAL
              </span>
              <span className="mono-tag flex items-center gap-2 rounded-full border border-rose-400/40 bg-rose-400/10 px-3 py-1.5 text-rose-300">
                <AlertOctagon size={11} />
                STATUS FINAL: BLOCKED — VERIFICAÇÃO LOCAL PENDENTE
              </span>
            </div>
          </Reveal>
          <Reveal delay={0.06}>
            <h1 className="mt-5 text-4xl font-bold leading-[1.02] tracking-tight text-slate-50 sm:text-6xl">
              O projeto agora existe.
              <br />
              <span className="text-glow bg-gradient-to-r from-cyan-300 to-teal-300 bg-clip-text text-transparent">
                A prova de compilação é sua.
              </span>
            </h1>
          </Reveal>
          <Reveal delay={0.12}>
            <p className="mt-5 max-w-3xl text-[14.5px] leading-relaxed text-slate-400">
              Escrevemos o esqueleto Android completo — {FILE_META.length} artefatos reais, zero código fingido.
              Porém este ambiente de construção <span className="text-slate-200">não possui toolchain Android
              (JDK/SDK/Gradle/device)</span>: os gates executáveis (sincronizar, compilar, testar, lintar, instalar)
              estão <span className="text-amber-300">BLOCKED por regra</span> — e nenhum resultado foi simulado.
              O runbook abaixo executa a verificação na sua máquina em minutos.
            </p>
          </Reveal>
          <Reveal delay={0.18}>
            <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                [`${FILE_META.length}`, "ARTEFATOS ANDROID NAVEGÁVEIS"],
                ["35", "CASOS DE TESTE ESCRITOS"],
                ["0", "GESTOS / CAPTURA / AUTOMAÇÃO"],
                ["0", "RESULTADOS FABRICADOS"],
              ].map(([v, l]) => (
                <div key={l} className="panel p-4">
                  <div className="mono text-2xl font-bold text-cyan-300">{v}</div>
                  <div className="mono mt-1 text-[8.5px] tracking-[0.14em] text-slate-500">{l}</div>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </div>

      <div className="mx-auto w-full max-w-6xl space-y-16 px-5 py-14 sm:px-8">
        {/* stack audit */}
        <Reveal>
          <section id="stack">
            <div className="mono-tag mb-4 flex items-center gap-2 text-slate-400">
              <ShieldQuestion size={13} className="text-cyan-300" />
              AUDITORIA DE STACK — NENHUMA VERSÃO TROCADA SILENCIOSAMENTE
            </div>
            <div className="panel overflow-hidden">
              {STACK_AUDIT.map((r) => (
                <div key={r.item} className="grid gap-1 border-b border-white/[0.05] px-5 py-3.5 last:border-0 sm:grid-cols-[190px_130px_1fr] sm:gap-4">
                  <div>
                    <div className="mono text-[11.5px] font-semibold text-slate-200">{r.item}</div>
                    <div className="mono text-[9px] text-slate-500">pedido: {r.requested}</div>
                  </div>
                  <div className="mono text-[9.5px] tracking-wide text-slate-300">{r.found}</div>
                  <div>
                    <div className={`mono text-[9.5px] tracking-wide ${r.ok ? "text-emerald-300" : "text-amber-300"}`}>
                      {r.decision}
                    </div>
                    <div className="mono mt-0.5 text-[8.5px] leading-relaxed text-slate-600">{r.source}</div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </Reveal>

        {/* gates */}
        <Reveal>
          <section id="gate">
            <div className="mono-tag mb-4 flex items-center gap-2 text-slate-400">
              <ListChecks size={13} className="text-cyan-300" />
              GATE DE APROVAÇÃO — CRITÉRIOS A–O APLICADOS SEM MAQUIAGEM
            </div>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {GATES.map((g) => {
                const st = GATE_STYLE[g.status];
                return (
                  <div key={g.id} className="panel p-4">
                    <div className="flex items-center justify-between gap-2">
                      <span className="mono text-[12px] font-bold text-slate-200">{g.id}</span>
                      <span className={`mono rounded-full border px-2 py-0.5 text-[8px] tracking-[0.14em] ${st.chip}`}>
                        {st.label}
                      </span>
                    </div>
                    <div className="mt-1.5 text-[12px] text-slate-300">{g.label}</div>
                    <div className="mono mt-1 text-[9px] leading-relaxed text-slate-500">{g.note}</div>
                  </div>
                );
              })}
            </div>
          </section>
        </Reveal>

        {/* fsm bench + tests */}
        <Reveal>
          <section>
            <div className="mono-tag mb-4 flex items-center gap-2 text-slate-400">
              <FlaskConical size={13} className="text-cyan-300" />
              MÁQUINA DE ESTADOS + MAPA DE TESTES
            </div>
            <div className="grid gap-3 lg:grid-cols-2">
              <FsmBench />
              <div className="panel h-full overflow-hidden">
                <div className="mono-tag flex items-center gap-2 border-b border-white/[0.07] px-5 py-3.5 text-slate-300">
                  <BookOpenCheck size={13} className="text-emerald-300" />
                  35 CASOS — COMPORTAMENTO REAL, SEM assertTrue(true)
                </div>
                <div className="divide-y divide-white/[0.05]">
                  {TEST_MATRIX.map((t) => (
                    <div key={t.file} className="px-5 py-4">
                      <div className="flex items-center justify-between gap-2">
                        <span className="mono text-[11px] font-semibold text-slate-200">{t.file}</span>
                        <span className="mono rounded border border-emerald-400/30 bg-emerald-400/10 px-2 py-0.5 text-[9px] text-emerald-300">
                          {t.cases} CASOS
                        </span>
                      </div>
                      <p className="mt-1.5 text-[11px] leading-relaxed text-slate-400">{t.covers}</p>
                      <span className="mono mt-2 inline-block rounded border border-white/[0.08] bg-white/[0.03] px-1.5 py-0.5 text-[8.5px] text-slate-500">
                        cobre {t.rule}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>
        </Reveal>

        {/* code browser */}
        <Reveal>
          <section id="code">
            <div className="mono-tag mb-4 flex items-center gap-2 text-slate-400">
              <FileStack size={13} className="text-cyan-300" />
              TODO O CÓDIGO-FONTE — TAMBÉM PRESENTE NO REPOSITÓRIO EM android/
            </div>
            <FileBrowser />
            <p className="mono mt-3 text-[9px] leading-relaxed tracking-[0.06em] text-slate-600">
              AUSENTES DE PROPÓSITO E DOCUMENTADOS: gradle-wrapper.jar · gradlew · gradlew.bat (binários/gerados —
              comando de geração no runbook abaixo). .gitignore presente no repositório, fora da visualização.
            </p>
          </section>
        </Reveal>

        {/* runbook */}
        <Reveal>
          <section>
            <div className="mono-tag mb-4 flex items-center gap-2 text-slate-400">
              <TerminalSquare size={13} className="text-cyan-300" />
              RUNBOOK DE VERIFICAÇÃO LOCAL — OS GATES SE PROVAM AQUI
            </div>
            <div className="panel overflow-hidden">
              {RUNBOOK.map((r, i) => (
                <div key={r.cmd} className="flex flex-col gap-1 border-b border-white/[0.05] px-5 py-3.5 last:border-0 sm:flex-row sm:items-center sm:gap-5">
                  <span className="mono shrink-0 text-[10px] text-slate-600">0{i + 1}</span>
                  <code className="mono rounded border border-white/[0.08] bg-black/40 px-2.5 py-1 text-[10.5px] text-teal-200">
                    {r.cmd}
                  </code>
                  <span className="text-[11px] text-slate-500">{r.why}</span>
                </div>
              ))}
            </div>
          </section>
        </Reveal>

        {/* report */}
        <Reveal>
          <section id="report">
            <div className="mono-tag mb-4 flex items-center gap-2 text-slate-400">
              <PackageCheck size={13} className="text-cyan-300" />
              RELATÓRIO FINAL OBRIGATÓRIO — 16 CAMPOS
            </div>
            <div className="panel overflow-hidden">
              {REPORT.map((r) => (
                <div
                  key={r.k}
                  className={`grid gap-1 border-b border-white/[0.05] px-5 py-4 last:border-0 sm:grid-cols-[230px_1fr] sm:gap-6 ${
                    (r as { highlight?: boolean }).highlight ? "bg-amber-400/[0.05]" : ""
                  }`}
                >
                  <span className="mono text-[10px] tracking-[0.12em] text-cyan-300/90">{r.k}</span>
                  <p className="text-[12px] leading-relaxed text-slate-300/90">{r.v}</p>
                </div>
              ))}
            </div>

            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <div className="rounded-2xl border border-amber-400/30 bg-amber-400/[0.06] p-6 text-center">
                <AlertOctagon className="mx-auto text-amber-300" size={20} />
                <div className="mono mt-3 text-[11px] tracking-[0.22em] text-amber-200">VEREDITO HONESTO</div>
                <div className="mono mt-1 text-3xl font-bold tracking-tight text-amber-300">BLOCKED</div>
                <p className="mx-auto mt-2 max-w-xs text-[11.5px] leading-relaxed text-amber-100/70">
                  Não há toolchain Android neste ambiente. APPROVED exige executar o runbook —
                  e mentir sobre isso violaria a regra nº 1 do projeto.
                </p>
              </div>
              <div className="rounded-2xl border border-emerald-400/25 bg-emerald-400/[0.05] p-6 text-center">
                <BadgeCheck className="mx-auto text-emerald-300" size={20} />
                <div className="mono mt-3 text-[11px] tracking-[0.22em] text-emerald-200">CAMINHO PARA APPROVED</div>
                <p className="mx-auto mt-2 max-w-xs text-[12px] leading-relaxed text-emerald-100/70">
                  ./gradlew clean → test → lint → assembleDebug → installDebug verdes em device real.
                  Com os gates A–O assim executados, a Fase 1 vira <span className="mono">APPROVED</span> e a
                  Fase 2 (MediaProjection) é destravada.
                </p>
                <div className="mono mt-3 flex items-center justify-center gap-2 text-[9px] tracking-[0.16em] text-emerald-300/60">
                  <Boxes size={11} /> 13 FASES · GATE POR FASE · ZERO ESCOPO AVANÇADO
                </div>
              </div>
            </div>
          </section>
        </Reveal>
      </div>
    </div>
  );
}
