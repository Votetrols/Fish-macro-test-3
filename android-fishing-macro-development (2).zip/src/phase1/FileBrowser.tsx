import { useMemo, useState } from "react";
import { FILE_META } from "./data";
import { Check, Copy, FileCode2, FolderOpen } from "lucide-react";

// Lê o conteúdo real dos arquivos do projeto Android (fonte única da verdade).
const raw = import.meta.glob("../../android/**/*", {
  eager: true,
  query: "?raw",
  import: "default",
}) as Record<string, string>;

const CONTENTS: Record<string, string> = Object.fromEntries(
  Object.entries(raw).map(([k, v]) => [k.replace(/^(\.\.\/)+/, ""), v]),
);

const STATUS_STYLE: Record<string, string> = {
  SOURCE: "border-cyan-400/30 bg-cyan-400/10 text-cyan-300",
  "SOURCE+TEST": "border-emerald-400/30 bg-emerald-400/10 text-emerald-300",
  CONTRACT: "border-slate-400/30 bg-slate-400/10 text-slate-300",
  "CONTRACT+TEST": "border-slate-400/30 bg-slate-400/10 text-slate-200",
  SCAFFOLD: "border-amber-400/30 bg-amber-400/10 text-amber-300",
  "UNIT-TEST": "border-emerald-400/30 bg-emerald-400/10 text-emerald-300",
  INSTRUMENTED: "border-amber-400/30 bg-amber-400/10 text-amber-300",
  DOC: "border-teal-400/30 bg-teal-400/10 text-teal-300",
};

function short(p: string) {
  return p.replace("app/src/main/java/com/fischvision/macro/", "…/macro/")
    .replace("app/src/test/java/com/fischvision/macro/", "…/test/")
    .replace("app/src/androidTest/java/com/fischvision/macro/", "…/androidTest/");
}

export default function FileBrowser() {
  const groups = useMemo(() => [...new Set(FILE_META.map((f) => f.group))], []);
  const [group, setGroup] = useState<string>("Core");
  const [selected, setSelected] = useState<string>(
    "app/src/main/java/com/fischvision/macro/core/MacroStateMachine.kt",
  );
  const [copied, setCopied] = useState(false);

  const files = FILE_META.filter((f) => f.group === group);
  const meta = FILE_META.find((f) => f.path === selected);
  const content = CONTENTS[`android/${selected}`] ?? "(conteúdo não disponível)";
  const lines = content.split("\n");

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="panel overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/[0.07] px-5 py-3.5">
        <span className="mono-tag flex items-center gap-2 text-slate-300">
          <FolderOpen size={13} className="text-cyan-300" />
          NAVEGADOR DE CÓDIGO — {FILE_META.length} ARQUIVOS REAIS DO PROJETO ANDROID
        </span>
        <span className="mono text-[9px] tracking-[0.14em] text-slate-500">
          CONTEÚDO LIDO DIRETAMENTE DOS ARQUIVOS — NENHUMA CÓPIA REESCRITA
        </span>
      </div>

      {/* group filter */}
      <div className="flex flex-wrap gap-1.5 border-b border-white/[0.07] px-4 py-3">
        {groups.map((g) => (
          <button
            key={g}
            onClick={() => setGroup(g)}
            className={`mono rounded-md border px-2.5 py-1 text-[9.5px] tracking-[0.12em] transition-colors ${
              group === g
                ? "border-cyan-400/50 bg-cyan-400/15 text-cyan-200"
                : "border-white/[0.08] bg-white/[0.02] text-slate-500 hover:text-slate-300"
            }`}
          >
            {g.toUpperCase()}
          </button>
        ))}
      </div>

      <div className="grid lg:grid-cols-[300px_1fr]">
        {/* file list */}
        <div className="max-h-[520px] overflow-y-auto border-b border-white/[0.07] p-2 lg:border-b-0 lg:border-r">
          {files.map((f) => (
            <button
              key={f.path}
              onClick={() => setSelected(f.path)}
              className={`mono flex w-full items-center gap-2 rounded-md px-2.5 py-[7px] text-left text-[10.5px] transition-colors ${
                selected === f.path ? "bg-cyan-400/10 text-cyan-200" : "text-slate-400 hover:bg-white/[0.04]"
              }`}
            >
              <FileCode2 size={11} className="shrink-0 opacity-60" />
              <span className="truncate">{short(f.path)}</span>
            </button>
          ))}
        </div>

        {/* content */}
        <div className="min-w-0">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.07] bg-white/[0.02] px-4 py-2.5">
            <span className="mono truncate text-[10px] text-slate-300">{`android/${selected}`}</span>
            <div className="flex items-center gap-2">
              {meta && (
                <span className={`mono rounded border px-2 py-0.5 text-[8.5px] tracking-[0.14em] ${STATUS_STYLE[meta.status] ?? STATUS_STYLE.SOURCE}`}>
                  {meta.status}
                </span>
              )}
              <button
                onClick={copy}
                className="mono flex items-center gap-1.5 rounded border border-white/[0.1] bg-white/[0.04] px-2 py-0.5 text-[8.5px] tracking-[0.14em] text-slate-300 hover:bg-white/[0.08]"
              >
                {copied ? <Check size={10} className="text-emerald-300" /> : <Copy size={10} />}
                {copied ? "COPIADO" : "COPIAR"}
              </button>
            </div>
          </div>
          <div className="max-h-[520px] overflow-auto">
            <pre className="mono flex min-w-max px-0 py-3 text-[10.5px] leading-[1.65] text-slate-300/90">
              <span className="sticky left-0 select-none border-r border-white/[0.07] bg-[#070d1a] px-3 text-right text-slate-600">
                {lines.map((_, i) => (
                  <span key={i} className="block">{i + 1}</span>
                ))}
              </span>
              <code className="block px-4">{content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}
