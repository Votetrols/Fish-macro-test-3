import { useState } from "react";
import { Section, Reveal } from "./ui";
import { FILE_TREE, MODULES } from "../data/content";
import { FileCode2, FileCog, Folder, FolderOpen, TestTube2 } from "lucide-react";

export default function Structure() {
  const modByPkg = Object.fromEntries(MODULES.map((m) => [`${m.pkg}/`, m]));
  const [sel, setSel] = useState<string>("service/");

  const entry = FILE_TREE.find((e) => e.path === sel);
  const mod = modByPkg[sel];

  return (
    <Section
      id="structure"
      index="07"
      eyebrow="ESTRUTURA DE PASTAS"
      title="Um módulo, fronteiras claras: a árvore é o contrato."
      lede="Pacote por responsabilidade, sem vazamento de camadas — captura nunca importa controller, UI nunca importa capture. Clique nos diretórios para inspecionar o conteúdo."
    >
      <Reveal>
        <div className="panel grid overflow-hidden lg:grid-cols-[1.25fr_1fr]">
          {/* tree */}
          <div className="max-h-[520px] overflow-y-auto p-4 sm:p-5">
            {FILE_TREE.map((e) => {
              const active = sel === e.path;
              const isDir = e.kind === "dir";
              const isTest = e.path.includes("test");
              return (
                <button
                  key={e.path}
                  onClick={() => setSel(e.path)}
                  className={`mono flex w-full items-center gap-2 rounded-md px-2 py-[7px] text-left text-[11.5px] transition-colors ${
                    active ? "bg-cyan-400/10 text-cyan-200" : "text-slate-300/85 hover:bg-white/[0.04]"
                  }`}
                  style={{ paddingLeft: `${e.depth * 22 + 8}px` }}
                >
                  {e.kind === "root" ? (
                    <FolderOpen size={13} className="shrink-0 text-slate-500" />
                  ) : isDir ? (
                    active ? (
                      <FolderOpen size={13} className={`shrink-0 ${isTest ? "text-amber-300" : "text-cyan-300"}`} />
                    ) : (
                      <Folder size={13} className={`shrink-0 ${isTest ? "text-amber-300/60" : "text-cyan-300/60"}`} />
                    )
                  ) : isTest ? (
                    <TestTube2 size={13} className="shrink-0 text-amber-300/70" />
                  ) : (
                    <FileCode2 size={12} className="shrink-0 text-slate-500" />
                  )}
                  <span className={e.kind === "file" ? "text-slate-400" : ""}>{e.path}</span>
                </button>
              );
            })}
          </div>

          {/* inspector */}
          <div className="border-t border-white/[0.07] bg-white/[0.02] p-5 sm:p-6 lg:border-l lg:border-t-0">
            <div className="mono-tag text-slate-500">INSPETOR</div>
            <div className="mono mt-2 flex items-center gap-2 text-[13px] font-semibold text-cyan-200">
              <FileCog size={14} className="text-cyan-300" />
              {entry?.path}
            </div>
            {mod ? (
              <>
                <p className="mt-3 text-[12.5px] leading-relaxed text-slate-400">{mod.responsibility}</p>
                <div className="mt-4 flex flex-wrap gap-1.5">
                  {mod.types.map((t) => (
                    <span key={t} className="mono rounded border border-teal-400/25 bg-teal-400/10 px-2 py-0.5 text-[10px] text-teal-200">
                      {t}.kt
                    </span>
                  ))}
                </div>
              </>
            ) : (
              <p className="mt-3 text-[12.5px] leading-relaxed text-slate-400">
                {entry?.note ?? "Artefato de suporte do projeto."}
              </p>
            )}
            <div className="mono mt-6 rounded-lg border border-white/[0.07] bg-black/30 p-3.5 text-[9.5px] leading-relaxed tracking-[0.05em] text-slate-500">
              REGRA DE DEPENDÊNCIA: ui → service → (capture, vision, detector, tracker, controller, input) → settings/logging.
              NUNCA AO CONTRÁRIO. debug/ injeta RecordedFrameSource no lugar de capture/ no modo simulação.
            </div>
          </div>
        </div>
      </Reveal>
    </Section>
  );
}
