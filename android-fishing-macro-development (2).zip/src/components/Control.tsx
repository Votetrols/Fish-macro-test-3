import { Section, Reveal } from "./ui";
import { CONTROL_FORMULAS, CONTROL_PARAMS } from "../data/content";
import { Activity, Sigma, Waves } from "lucide-react";

const TIMELINE = `erro │        fora da zona morta
  e  │  ·······┬───────────────┬·······  ← +deadZone (histerese de saída)
     │         │ ▂▃▅█▇▅▃▂      │
  0  ├─────────┼───────────────┼──────────
     │         │               │
 cmd │ NO_ACT  │ PRESS→HOLD────│ RELEASE→NO_ACTION
     └─────────┴───────────────┴───────────→ t
        minHold 60ms · maxCommandRate 20Hz · watchdog solta tudo se a visão some`;

export default function Control() {
  return (
    <Section
      id="control"
      index="05"
      eyebrow="ESTRATÉGIA DE CONTROLE"
      title="EMA para o ruído, proporção para a decisão, histerese para a sanidade."
      lede="EMA venceu o Kalman Filter no custo-benefício: O(1) por frame, zero alocação e estável o bastante para sinal a 10–15 Hz. O controlador proporcional com zona morta decide entre PRESS, HOLD, RELEASE e NO_ACTION — sempre com freio de taxa."
    >
      {/* tracker */}
      <Reveal>
        <div className="panel p-5 sm:p-7">
          <div className="mono-tag flex items-center gap-2 text-slate-300">
            <Waves size={13} className="text-cyan-300" />
            TargetTracker — NUNCA SÓ O ÚLTIMO FRAME
          </div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
            {CONTROL_FORMULAS.map((f) => (
              <div key={f.tag} className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-4">
                <span className="mono-tag text-cyan-300/90">{f.tag}</span>
                <div className="mono mt-2.5 whitespace-nowrap text-[11.5px] font-semibold tracking-wide text-slate-100">
                  {f.code}
                </div>
                <p className="mt-2 text-[10.5px] leading-snug text-slate-500">{f.note}</p>
              </div>
            ))}
          </div>
          <p className="mt-5 text-[12.5px] leading-relaxed text-slate-400">
            Histórico em buffer circular de tamanho fixo (previousPosition, currentPosition, velocity, direction,
            timestamp) — o tracker não aloca nada por frame. A predição compensa a latência medida do gesto e é
            limitada para nunca projetar além de 12% da barra: previsão demais vira oscilação.
          </p>
        </div>
      </Reveal>

      {/* anti-chattering */}
      <div className="mt-6 grid gap-3 lg:grid-cols-5">
        <Reveal className="lg:col-span-3">
          <div className="panel h-full p-5 sm:p-7">
            <div className="mono-tag flex items-center gap-2 text-slate-300">
              <Activity size={13} className="text-emerald-300" />
              ANTI-CHATTERING — O COMPORTAMENTO PROIBIDO E A CURA
            </div>
            <pre className="mono mt-4 overflow-x-auto rounded-lg border border-white/[0.07] bg-black/40 p-4 text-[9.5px] leading-[1.7] text-slate-400">
              {TIMELINE}
            </pre>
            <p className="mt-4 text-[12.5px] leading-relaxed text-slate-400">
              Sem histerese e tempos mínimos, o controlador vibra entre PRESS e RELEASE na borda da zona morta e o
              indicador entra em oscilação. O FishingController impõe cadência máxima e tempos mínimos de
              permanência em cada comando — decidido por configuração, não por mágica.
            </p>
          </div>
        </Reveal>

        {/* params */}
        <Reveal className="lg:col-span-2" delay={0.08}>
          <div className="panel h-full overflow-hidden">
            <div className="mono-tag flex items-center gap-2 border-b border-white/[0.07] px-5 py-3.5 text-slate-300">
              <Sigma size={13} className="text-cyan-300" />
              PARÂMETROS — TODOS CONFIGURÁVEIS
            </div>
            <div className="divide-y divide-white/[0.05]">
              {CONTROL_PARAMS.map((p) => (
                <div key={p.k} className="flex items-center justify-between gap-3 px-5 py-2.5">
                  <div>
                    <span className="mono text-[11px] text-slate-200">{p.k}</span>
                    <div className="text-[10px] leading-snug text-slate-500">{p.note}</div>
                  </div>
                  <span className="mono shrink-0 rounded border border-cyan-400/25 bg-cyan-400/10 px-2 py-0.5 text-[10.5px] font-semibold text-cyan-200">
                    {p.v}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>

      {/* fail-safe strip */}
      <Reveal className="mt-6">
        <div className="rounded-2xl border border-amber-400/25 bg-amber-400/[0.06] p-5">
          <p className="text-[13px] leading-relaxed text-amber-100/90">
            <span className="mono mr-2 rounded border border-amber-400/40 bg-amber-400/15 px-2 py-0.5 text-[10px] tracking-[0.14em] text-amber-300">
              REGRA DE OURO
            </span>
            Visão perdida = dedo virtual solto. O watchdog corta qualquer HOLD após{" "}
            <span className="mono text-amber-200">lostDetectionTimeout</span> sem detecção válida — o macro jamais
            continua pressionando às cegas, mesmo com detector maluco, frame impossível ou captura congelada.
          </p>
        </div>
      </Reveal>
    </Section>
  );
}
