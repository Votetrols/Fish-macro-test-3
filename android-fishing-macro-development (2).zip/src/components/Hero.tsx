import { motion } from "framer-motion";
import { ChevronDown, Cpu, Hand, MonitorSmartphone, ShieldCheck } from "lucide-react";
import { HERO_CHIPS, TICKER_ITEMS } from "../data/content";

const FACTS = [
  {
    icon: MonitorSmartphone,
    title: "Roblox em primeiro plano",
    body: "Não existe API pública para capturar ou tocar um app minimizado. O macro opera sobre o jogo visível — essa é a verdade técnica, não uma limitação do projeto.",
  },
  {
    icon: ShieldCheck,
    title: "Consentimento por sessão",
    body: "MediaProjection exige o diálogo do sistema a cada sessão de captura (Android 14+). O token é de uso único — sem persistência falsa.",
  },
  {
    icon: Hand,
    title: "Toque via Acessibilidade",
    body: "Sem root, dispatchGesture é o único canal legítimo de injeção de toque. Ativação manual pelo usuário, gestos assíncronos.",
  },
  {
    icon: Cpu,
    title: "Visão nativa em Kotlin",
    body: "Segmentação de cor e componentes conectados sem OpenCV na v1. Zero JNI, zero dependência pesada — calibrável por perfis.",
  },
];

const fade = (d: number) => ({
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.9, delay: d, ease: [0.22, 1, 0.36, 1] as const },
});

export default function Hero() {
  return (
    <div id="top" className="relative overflow-hidden">
      {/* background */}
      <div className="absolute inset-0">
        <img
          src="/images/abyss.jpg"
          alt=""
          className="h-full w-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#04070e]/70 via-[#04070e]/40 to-[#04070e]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_120%,rgba(34,211,238,0.14),transparent_55%)]" />
      </div>

      {/* sonar rings */}
      <div className="pointer-events-none absolute left-1/2 top-[58%] -translate-x-1/2 -translate-y-1/2">
        {[0, 1.7, 3.4].map((d) => (
          <div
            key={d}
            className="sonar-ring absolute -inset-24 sm:-inset-40"
            style={{ animationDelay: `${d}s` }}
          />
        ))}
      </div>

      {/* scan beam */}
      <div className="pointer-events-none absolute inset-x-0 h-40 bg-gradient-to-b from-transparent via-cyan-400/[0.05] to-transparent scan-beam" />

      <div className="relative mx-auto flex min-h-[100svh] w-full max-w-6xl flex-col justify-end px-5 pb-10 pt-32 sm:px-8">
        <motion.div {...fade(0.1)} className="flex flex-wrap items-center gap-3">
          <span className="mono-tag rounded-full border border-cyan-400/30 bg-cyan-400/10 px-3 py-1.5 text-cyan-300">
            DOCUMENTO DE ARQUITETURA · FASE 0
          </span>
          <span className="mono-tag text-slate-400">RESPOSTA TÉCNICA — SEM CÓDIGO AINDA, POR DESIGN</span>
        </motion.div>

        <motion.h1
          {...fade(0.2)}
          className="mt-6 text-[13vw] font-bold leading-[0.88] tracking-[-0.03em] text-slate-50 sm:text-[92px] lg:text-[120px]"
        >
          FISCH
          <br />
          <span className="text-glow bg-gradient-to-r from-cyan-300 via-teal-200 to-cyan-400 bg-clip-text text-transparent">
            VISION MACRO
          </span>
        </motion.h1>

        <motion.p {...fade(0.32)} className="mt-6 max-w-2xl text-[15px] leading-relaxed text-slate-300/90 sm:text-base">
          Macro Android por visão computacional para o minigame de pesca do Fisch (Roblox).
          Captura de tela em tempo real, detecção por segmentação de cor, rastreamento preditivo
          e toque sintético via Acessibilidade — em Kotlin, modular, com máquina de estados
          explícita e fail-safe em cada camada.
        </motion.p>

        <motion.div {...fade(0.42)} className="mt-7 flex flex-wrap gap-2">
          {HERO_CHIPS.map((c) => (
            <span key={c} className="mono rounded-md border border-white/10 bg-white/[0.04] px-3 py-1.5 text-[10px] tracking-[0.18em] text-slate-300">
              {c}
            </span>
          ))}
        </motion.div>

        {/* facts */}
        <div className="mt-14 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {FACTS.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 26 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.55 + i * 0.09, ease: [0.22, 1, 0.36, 1] }}
              className="panel panel-hover p-5"
            >
              <f.icon size={18} className="text-cyan-300" />
              <h3 className="mt-3 text-[13.5px] font-semibold leading-snug text-slate-100">{f.title}</h3>
              <p className="mt-2 text-[12px] leading-relaxed text-slate-400">{f.body}</p>
            </motion.div>
          ))}
        </div>

        <motion.div {...fade(0.9)} className="mt-10 flex items-center gap-2 text-slate-500">
          <ChevronDown size={14} className="animate-bounce" />
          <span className="mono text-[10px] tracking-[0.24em]">ROLE PARA A PROPOSTA COMPLETA — 10 SEÇÕES</span>
        </motion.div>
      </div>

      {/* ticker */}
      <div className="relative border-y border-white/[0.07] bg-[#04070e]/70 py-3 backdrop-blur">
        <div className="ticker-track flex w-max gap-10 whitespace-nowrap">
          {[...TICKER_ITEMS, ...TICKER_ITEMS].map((t, i) => (
            <span key={i} className="mono flex items-center gap-10 text-[10px] tracking-[0.22em] text-slate-500">
              {t}
              <span className="text-cyan-500">◆</span>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
