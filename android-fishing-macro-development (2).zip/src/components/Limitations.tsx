import { Section, Reveal } from "./ui";
import { ANDROID_VERSIONS, LIMITATIONS, PERMISSIONS } from "../data/content";
import { AlertTriangle, Ban, OctagonAlert, ShieldAlert, KeyRound } from "lucide-react";

const SEV_STYLE: Record<string, { chip: string; icon: typeof AlertTriangle }> = {
  BLOQUEANTE: { chip: "border-rose-400/40 bg-rose-400/10 text-rose-300", icon: Ban },
  "RESTRIÇÃO": { chip: "border-amber-400/40 bg-amber-400/10 text-amber-300", icon: OctagonAlert },
  "ATENÇÃO": { chip: "border-cyan-400/40 bg-cyan-400/10 text-cyan-300", icon: AlertTriangle },
  "RISCO EXTERNO": { chip: "border-slate-400/40 bg-slate-400/10 text-slate-300", icon: ShieldAlert },
};

export default function Limitations() {
  return (
    <Section
      id="limits"
      index="02"
      eyebrow="LIMITAÇÕES REAIS DO ANDROID"
      title="O que o Android permite — e o que nenhuma API pública faz por você."
      lede="Antes de qualquer linha de código, o levantamento honesto. Cada restrição abaixo tem uma consequência arquitetural explícita; nenhuma capacidade inexistente foi presumida ou será prometida."
    >
      {/* limitation cards */}
      <div className="grid gap-3 md:grid-cols-2">
        {LIMITATIONS.map((l, i) => {
          const sev = SEV_STYLE[l.severity];
          return (
            <Reveal key={l.title} delay={(i % 2) * 0.06}>
              <div className="panel panel-hover flex h-full flex-col p-5">
                <div className="flex items-center justify-between gap-3">
                  <h3 className="text-[14.5px] font-semibold leading-snug text-slate-100">{l.title}</h3>
                  <span className={`mono flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[9px] tracking-[0.14em] ${sev.chip}`}>
                    <sev.icon size={11} />
                    {l.severity}
                  </span>
                </div>
                <p className="mt-2.5 text-[12.5px] leading-relaxed text-slate-400">{l.body}</p>
                <div className="mt-4 rounded-xl border border-white/[0.07] bg-white/[0.02] p-3.5">
                  <span className="mono-tag text-teal-300/90">→ CONSEQUÊNCIA NO PROJETO</span>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-slate-300/80">{l.consequence}</p>
                </div>
              </div>
            </Reveal>
          );
        })}
      </div>

      {/* version matrix */}
      <Reveal className="mt-10">
        <div className="mono-tag mb-4 text-slate-400">MATRIZ DE VERSÕES — ANDROID 12 → 16</div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {ANDROID_VERSIONS.map((v) => (
            <div key={v.api} className="panel panel-hover p-4">
              <div className="flex items-baseline justify-between">
                <span className="mono text-[13px] font-semibold text-cyan-300">{v.api}</span>
                <span className="mono text-[10px] tracking-[0.16em] text-slate-500">{v.name.toUpperCase()}</span>
              </div>
              <p className="mt-2 text-[11.5px] leading-relaxed text-slate-400">{v.impact}</p>
            </div>
          ))}
        </div>
      </Reveal>

      {/* permissions */}
      <Reveal className="mt-10">
        <div className="panel overflow-hidden">
          <div className="flex items-center gap-2.5 border-b border-white/[0.07] px-5 py-3.5">
            <KeyRound size={14} className="text-cyan-300" />
            <span className="mono-tag text-slate-300">MODELO DE PERMISSÕES — SÓ O ESTRITAMENTE NECESSÁRIO, CADA UMA JUSTIFICADA NA UI</span>
          </div>
          <div className="divide-y divide-white/[0.05]">
            {PERMISSIONS.map((p) => (
              <div key={p.permission} className="grid gap-1 px-5 py-3.5 sm:grid-cols-[260px_200px_1fr] sm:items-center sm:gap-4">
                <span className="mono text-[11.5px] font-medium text-slate-200">{p.permission}</span>
                <span className="mono text-[10px] tracking-wide text-amber-300/80">{p.how}</span>
                <span className="text-[12px] leading-relaxed text-slate-400">{p.why}</span>
              </div>
            ))}
          </div>
          <div className="border-t border-white/[0.07] bg-white/[0.02] px-5 py-3">
            <p className="mono text-[9.5px] tracking-[0.1em] text-slate-500">
              TODOS OS QUATRO ESTADOS TRATADOS: CONCEDIDA · NEGADA · REVOGADA EM RUNTIME · SERVIÇO INDISPONÍVEL — COM MENSAGEM COMPREENSÍVEL E CAMINHO DE CORREÇÃO.
            </p>
          </div>
        </div>
      </Reveal>
    </Section>
  );
}
