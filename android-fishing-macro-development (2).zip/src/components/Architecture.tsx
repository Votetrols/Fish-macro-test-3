import { Section, Reveal, Chip } from "./ui";
import { LOOP_STAGES, MODULES, SDK_TABLE } from "../data/content";
import StateMachine from "./StateMachine";
import {
  Boxes, Camera, Eye, GitBranch, Layers, Move3d, ScanSearch, Hand, MonitorPlay,
  Settings2, Bug, FileText, AppWindow, Gauge, ArrowRight, Workflow, ShieldCheck, PlugZap,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

const MODULE_ICONS: Record<string, LucideIcon> = {
  app: AppWindow,
  ui: Layers,
  service: ShieldCheck,
  capture: Camera,
  vision: Eye,
  detector: ScanSearch,
  tracker: Move3d,
  controller: Gauge,
  input: Hand,
  overlay: MonitorPlay,
  settings: Settings2,
  debug: Bug,
  logging: FileText,
};

const PRINCIPLES = [
  { icon: Workflow, title: "Núcleo independente do framework", body: "O motor do macro é Kotlin puro (coroutines + Flow). Android entra apenas nas bordas: serviço, captura, gestos." },
  { icon: PlugZap, title: "Interfaces em cada fronteira", body: "FrameSource, InputController, Detector — tudo atrás de contrato. Permite trocar captura real por frames gravados (simulação) sem tocar no resto." },
  { icon: GitBranch, title: "Máquina de estados explícita", body: "Nenhum booleano solto. Todo comportamento nasce de uma transição declarada — e toda transição é logável." },
  { icon: Boxes, title: "MVVM só onde faz sentido", body: "ViewModels na UI. O processamento pesado vive no Service, sob supervisão de coroutines — a Activity é descartável." },
];

export default function Architecture() {
  return (
    <Section
      id="arch"
      index="01"
      eyebrow="ARQUITETURA ESCOLHIDA"
      title="Núcleo puro em Kotlin. Android nas bordas. Estados sempre explícitos."
      lede="Um único módulo Gradle com separação estrita por pacotes (modularização física fica para quando o projeto crescer). O motor roda em um Foreground Service e conversa com a UI por StateFlow — fechar a Activity nunca derruba o macro."
    >
      {/* principles */}
      <div className="grid gap-3 sm:grid-cols-2">
        {PRINCIPLES.map((p, i) => (
          <Reveal key={p.title} delay={i * 0.06}>
            <div className="panel panel-hover h-full p-5">
              <p.icon size={17} className="text-cyan-300" />
              <h3 className="mt-3 text-[14px] font-semibold text-slate-100">{p.title}</h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-400">{p.body}</p>
            </div>
          </Reveal>
        ))}
      </div>

      {/* sdk table */}
      <Reveal className="mt-6">
        <div className="panel grid gap-px overflow-hidden rounded-2xl sm:grid-cols-2 lg:grid-cols-4">
          {SDK_TABLE.map((r) => (
            <div key={r.k} className="bg-white/[0.02] p-4">
              <div className="mono text-[10px] tracking-[0.18em] text-slate-500">{r.k.toUpperCase()}</div>
              <div className="mono mt-1 text-xl font-semibold text-cyan-300">{r.v}</div>
              <div className="mt-1.5 text-[11px] leading-snug text-slate-400">{r.note}</div>
            </div>
          ))}
        </div>
      </Reveal>

      {/* data loop */}
      <Reveal className="mt-10">
        <div className="mb-4 flex items-center gap-3">
          <span className="mono-tag text-slate-400">O CICLO POR FRAME — ORÇAMENTO DE LATÊNCIA ≤ 100 MS</span>
        </div>
        <div className="flex items-stretch gap-2 overflow-x-auto pb-2">
          {LOOP_STAGES.map((s, i) => (
            <div key={s.step} className="flex shrink-0 items-center gap-2">
              <div className="panel px-3.5 py-3 text-center">
                <div className="mono text-[9px] tracking-[0.2em] text-cyan-400/80">{s.step}</div>
                <div className="mt-1 whitespace-nowrap text-[12px] font-semibold text-slate-200">{s.label}</div>
                <div className="mono mt-1 whitespace-nowrap text-[9px] tracking-wide text-slate-500">{s.spec}</div>
              </div>
              {i < LOOP_STAGES.length - 1 && <ArrowRight size={13} className="shrink-0 text-cyan-500/60" />}
            </div>
          ))}
        </div>
      </Reveal>

      {/* modules */}
      <Reveal className="mt-10">
        <div className="mb-4 flex items-center justify-between">
          <span className="mono-tag text-slate-400">13 PACOTES — RESPONSABILIDADE ÚNICA</span>
          <Chip>com.fischvision.macro.*</Chip>
        </div>
      </Reveal>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {MODULES.map((m, i) => {
          const Icon = MODULE_ICONS[m.pkg] ?? Boxes;
          return (
            <Reveal key={m.pkg} delay={(i % 3) * 0.05}>
              <div className="panel panel-hover group h-full p-5">
                <div className="flex items-center justify-between">
                  <Icon size={17} className="text-cyan-300/90" />
                  <span className="mono text-[10px] tracking-[0.14em] text-slate-500 group-hover:text-cyan-400/80">/{m.pkg}</span>
                </div>
                <h3 className="mt-3 text-[14px] font-semibold text-slate-100">{m.name}</h3>
                <p className="mt-1.5 min-h-[54px] text-[12px] leading-relaxed text-slate-400">{m.responsibility}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {m.types.map((t) => (
                    <span key={t} className="mono rounded border border-white/[0.09] bg-white/[0.04] px-1.5 py-0.5 text-[9.5px] text-slate-400">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </Reveal>
          );
        })}
      </div>

      {/* state machine */}
      <Reveal className="mt-12">
        <StateMachine />
      </Reveal>
    </Section>
  );
}
