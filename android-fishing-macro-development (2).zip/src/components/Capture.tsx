import { Section, Reveal } from "./ui";
import { CAPTURE_DEFAULTS, PIPELINE_STAGES } from "../data/content";
import { Camera, RotateCcw, ShieldAlert, TimerReset } from "lucide-react";

const RESILIENCE = [
  { icon: RotateCcw, title: "Captura congelada → RESET", body: "Watchdog mede intervalo entre frames; acima de 3× o esperado, o VirtualDisplay é recriado sem derrubar o serviço." },
  { icon: ShieldAlert, title: "Projeção morta → ERROR legível", body: "onStop da MediaProjection e SecurityException encerram o pipeline em estado seguro, com mensagem clara e caminho para novo consentimento." },
  { icon: TimerReset, title: "Degradação térmica → fallback", body: "Sob pressão térmica ou memória baixa, a captura desce para 480p/5 fps em vez de falhar — decisão sempre logada." },
];

export default function Capture() {
  return (
    <Section
      id="capture"
      index="03"
      eyebrow="ESTRATÉGIA DE CAPTURA"
      title="MediaProjection + ImageReader. Último frame sempre vence; fila nunca cresce."
      lede="Nada de screenshots síncronos. Um VirtualDisplay em resolução reduzida alimenta um ImageReader RGBA_8888 em thread dedicada, e o FrameBus entrega apenas o frame mais recente ao motor — captura assíncrona de ponta a ponta."
    >
      {/* pipeline */}
      <Reveal>
        <div className="panel p-5 sm:p-7">
          <div className="mono-tag mb-6 flex items-center gap-2 text-slate-400">
            <Camera size={13} className="text-cyan-300" />
            FLUXO DE CAPTURA — PIPELINE ASSÍNCRONO
          </div>

          <div className="hidden items-start gap-0 lg:flex">
            {PIPELINE_STAGES.map((s, i) => (
              <div key={s.name} className="flex flex-1 items-start last:flex-none">
                <div className="w-full">
                  <div className="mono text-[9px] tracking-[0.2em] text-cyan-400/70">0{i + 1}</div>
                  <div className="mt-1.5 text-[12.5px] font-semibold text-slate-200">{s.name}</div>
                  <div className="mono mt-1 text-[9px] tracking-wide text-slate-500">{s.spec}</div>
                </div>
                {i < PIPELINE_STAGES.length - 1 && (
                  <div className="relative mx-3 mt-4 h-px w-full min-w-6 flex-1 bg-white/10">
                    <span
                      className="packet absolute -top-[3px] h-[7px] w-[7px] rounded-full bg-cyan-300 shadow-[0_0_10px_rgba(34,211,238,0.8)]"
                      style={{ animationDelay: `${i * 0.42}s` }}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="grid gap-4 lg:hidden">
            {PIPELINE_STAGES.map((s, i) => (
              <div key={s.name} className="flex gap-4">
                <span className="mono mt-0.5 text-[10px] text-cyan-400/70">0{i + 1}</span>
                <div>
                  <div className="text-[13px] font-semibold text-slate-200">{s.name}</div>
                  <div className="mono text-[9.5px] tracking-wide text-slate-500">{s.spec}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-7 grid gap-3 border-t border-white/[0.07] pt-6 sm:grid-cols-2 lg:grid-cols-3">
            {PIPELINE_STAGES.map((s) => (
              <div key={s.name} className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-3.5">
                <span className="mono-tag text-cyan-300/90">{s.name.toUpperCase()}</span>
                <p className="mt-1.5 text-[11.5px] leading-relaxed text-slate-400">{s.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </Reveal>

      {/* ScreenCaptureManager contract */}
      <Reveal className="mt-6">
        <div className="panel overflow-hidden">
          <div className="mono-tag border-b border-white/[0.07] px-5 py-3.5 text-slate-300">
            CONTRATO — ScreenCaptureManager
          </div>
          <div className="grid gap-px sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["requestConsent()", "Único ponto que fala com MediaProjectionManager.createScreenCaptureIntent()"],
              ["start(config)", "Cria VirtualDisplay + ImageReader; devolve Flow<Frame>"],
              ["stop() · release()", "Fecha Image, ImageReader, VirtualDisplay e projeção — idempotente"],
              ["health: StateFlow", "FPS real, frames descartados, erros e estado do consentimento"],
            ].map(([k, v]) => (
              <div key={k} className="bg-white/[0.02] p-4">
                <div className="mono text-[11px] font-semibold text-teal-300">{k}</div>
                <p className="mt-1.5 text-[11.5px] leading-relaxed text-slate-400">{v}</p>
              </div>
            ))}
          </div>
        </div>
      </Reveal>

      {/* defaults + resilience */}
      <div className="mt-6 grid gap-3 lg:grid-cols-5">
        <Reveal className="lg:col-span-2">
          <div className="panel h-full p-5">
            <div className="mono-tag text-slate-400">PADRÕES CONSERVADORES — BAIXO/MÉDIO DESEMPENHO</div>
            <div className="mt-4 divide-y divide-white/[0.05]">
              {CAPTURE_DEFAULTS.map((d) => (
                <div key={d.k} className="flex items-center justify-between gap-3 py-2.5">
                  <span className="mono text-[11px] text-slate-300">{d.k}</span>
                  <div className="text-right">
                    <span className="mono text-[12px] font-semibold text-cyan-300">{d.v}</span>
                    <div className="mono text-[9px] tracking-wide text-slate-500">{d.note}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
        <div className="grid gap-3 lg:col-span-3">
          {RESILIENCE.map((r, i) => (
            <Reveal key={r.title} delay={i * 0.06}>
              <div className="panel panel-hover flex items-start gap-4 p-5">
                <span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-amber-400/30 bg-amber-400/10">
                  <r.icon size={15} className="text-amber-300" />
                </span>
                <div>
                  <h3 className="text-[13.5px] font-semibold text-slate-100">{r.title}</h3>
                  <p className="mt-1 text-[12px] leading-relaxed text-slate-400">{r.body}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </Section>
  );
}
