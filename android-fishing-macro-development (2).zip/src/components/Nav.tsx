import { motion, useScroll, useSpring } from "framer-motion";
import { Fish, CircleDot } from "lucide-react";

const ARCH_LINKS: [string, string][] = [
  ["arch", "01·ARQ"],
  ["limits", "02·LIM"],
  ["capture", "03·CAP"],
  ["vision", "04·VIS"],
  ["control", "05·CTL"],
  ["input", "06·INP"],
  ["structure", "07·DIR"],
  ["deps", "08·DEP"],
  ["risks", "09·RSK"],
  ["phases", "10·FASES"],
];

const PHASE1_LINKS: [string, string][] = [
  ["stack", "STACK"],
  ["gate", "GATE"],
  ["code", "CÓDIGO"],
  ["report", "RELATÓRIO"],
];

export default function Nav({
  view,
  onChange,
}: {
  view: "arch" | "phase1" | "exec";
  onChange: (v: "arch" | "phase1" | "exec") => void;
}) {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 28, mass: 0.4 });
  const links =
    view === "arch" ? ARCH_LINKS : view === "exec" ? [] : PHASE1_LINKS;

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <div className="border-b border-white/[0.06] bg-[#04070e]/80 backdrop-blur-xl">
        <div className="mx-auto flex h-14 w-full max-w-6xl items-center justify-between gap-4 px-5 sm:px-8">
          <div className="flex items-center gap-2.5">
            <span className="grid h-7 w-7 place-items-center rounded-md border border-cyan-400/40 bg-cyan-400/10">
              <Fish size={14} className="text-cyan-300" />
            </span>
            <span className="mono hidden text-[11px] font-semibold tracking-[0.22em] text-slate-200 xs:inline sm:inline">
              FVM
            </span>

            {/* view switch */}
            <div className="ml-2 flex overflow-hidden rounded-full border border-white/[0.1]">
              {(
                [
                  ["exec", "F1→F7 · EXEC"],
                  ["phase1", "F1 · CÓDIGO"],
                  ["arch", "F0 · ARQ"],
                ] as const
              ).map(([v, label]) => (
                <button
                  key={v}
                  onClick={() => onChange(v)}
                  className={`mono px-3 py-1.5 text-[8.5px] tracking-[0.14em] transition-colors ${
                    view === v ? "bg-cyan-400/20 text-cyan-100" : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <nav className="hidden items-center gap-4 lg:flex">
            {links.map(([href, label]) => (
              <a
                key={href}
                href={`#${href}`}
                className="mono text-[10px] tracking-[0.14em] text-slate-500 transition-colors hover:text-cyan-300"
              >
                {label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            {view === "phase1" ? (
              <span className="mono inline-flex items-center gap-2 rounded-full border border-amber-400/30 bg-amber-400/10 px-3 py-1 text-[9px] tracking-[0.12em] text-amber-300">
                <CircleDot size={10} className="blink" />
                F1: BLOCKED·VERIF. LOCAL
              </span>
            ) : view === "exec" ? (
              <span className="mono inline-flex items-center gap-2 rounded-full border border-amber-400/30 bg-amber-400/10 px-3 py-1 text-[9px] tracking-[0.12em] text-amber-300">
                <CircleDot size={10} className="blink" />
                FINAL: BLOCKED
              </span>
            ) : (
              <span className="mono hidden items-center gap-2 rounded-full border border-amber-400/30 bg-amber-400/10 px-3 py-1 text-[9px] tracking-[0.12em] text-amber-300 sm:inline-flex">
                <CircleDot size={10} className="blink" />
                F0: APROVADA
              </span>
            )}
          </div>
        </div>

        <div className="flex gap-4 overflow-x-auto px-5 pb-2 lg:hidden">
          {links.map(([href, label]) => (
            <a key={href} href={`#${href}`} className="mono shrink-0 text-[10px] tracking-[0.14em] text-slate-500">
              {label}
            </a>
          ))}
        </div>
      </div>
      <motion.div style={{ scaleX }} className="h-px origin-left bg-gradient-to-r from-cyan-400 via-teal-300 to-cyan-500" />
    </header>
  );
}
