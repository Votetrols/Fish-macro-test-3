import { Reveal } from "./ui";
import { ACCEPTANCE, PRIORIDADES } from "../data/content";
import { ArrowRight, Fish, Square } from "lucide-react";

export default function Footer() {
  return (
    <footer id="approval" className="relative scroll-mt-24 overflow-hidden border-t border-white/[0.07]">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_50%_-20%,rgba(34,211,238,0.12),transparent_55%)]" />

      <div className="relative mx-auto w-full max-w-6xl px-5 py-20 sm:px-8 sm:py-24">
        {/* acceptance */}
        <Reveal>
          <div className="mono-tag text-slate-400">CRITÉRIOS DE ACEITAÇÃO — CHECKLIST FINAL DO PROJETO</div>
        </Reveal>
        <Reveal delay={0.05}>
          <div className="panel mt-4 grid gap-px overflow-hidden rounded-2xl sm:grid-cols-2 lg:grid-cols-3">
            {ACCEPTANCE.map((a) => (
              <div key={a} className="flex items-center gap-3 bg-white/[0.02] px-4 py-3">
                <Square size={12} className="shrink-0 text-slate-600" />
                <span className="text-[12px] text-slate-300/90">{a}</span>
              </div>
            ))}
            <div className="flex items-center gap-3 bg-amber-400/[0.06] px-4 py-3">
              <span className="blink h-2 w-2 shrink-0 rounded-full bg-amber-300" />
              <span className="mono text-[10px] tracking-[0.14em] text-amber-200/90">0/19 — TUDO COMEÇA NA FASE 1</span>
            </div>
          </div>
        </Reveal>

        {/* CTA */}
        <Reveal className="mt-16">
          <div className="relative overflow-hidden rounded-3xl border border-cyan-400/25 bg-gradient-to-b from-cyan-400/[0.09] to-transparent p-8 text-center sm:p-14">
            <div className="mono-tag text-cyan-300">DECISÃO PENDENTE</div>
            <h2 className="mx-auto mt-4 max-w-2xl text-3xl font-bold leading-tight tracking-tight text-slate-50 sm:text-5xl">
              Arquitetura aprovada?
              <br />
              <span className="text-glow bg-gradient-to-r from-cyan-300 to-teal-300 bg-clip-text text-transparent">
                Então a Fase 1 começa.
              </span>
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-[13.5px] leading-relaxed text-slate-400">
              Este documento contém deliberadamente zero linhas de código (regras 32 e 34): nenhuma
              capacidade foi simulada, nenhuma API foi inventada e nada ficou marcado como "implement later".
              O próximo artefato é o projeto Android compilável — Gradle, pacotes e interfaces —
              entregue na ordem das treze fases acima.
            </p>
            <div className="mt-8 inline-flex items-center gap-3 rounded-full border border-cyan-400/40 bg-cyan-400/15 px-7 py-3.5">
              <span className="mono text-[12px] font-semibold tracking-[0.2em] text-cyan-100">
                APROVAR → INICIAR FASE 1
              </span>
              <ArrowRight size={16} className="text-cyan-200" />
            </div>
            <div className="mono mt-6 flex flex-wrap items-center justify-center gap-x-2 gap-y-1 text-[9.5px] tracking-[0.18em] text-slate-500">
              {PRIORIDADES.map((p, i) => (
                <span key={p} className="flex items-center gap-2">
                  <span className={i === 0 ? "text-cyan-300" : ""}>{p}</span>
                  {i < PRIORIDADES.length - 1 && <span className="text-slate-600">&gt;</span>}
                </span>
              ))}
            </div>
          </div>
        </Reveal>

        {/* bottom bar */}
        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/[0.06] pt-6 sm:flex-row">
          <div className="flex items-center gap-2.5">
            <Fish size={14} className="text-cyan-300" />
            <span className="mono text-[10px] tracking-[0.2em] text-slate-400">
              FISCH VISION MACRO · DOCUMENTO DE ARQUITETURA — FASE 0
            </span>
          </div>
          <span className="mono text-[9px] tracking-[0.14em] text-slate-600">
            AUTOMAÇÃO DE GAMEPLAY VIOLA OS TERMOS DO ROBLOX — RISCO DO USUÁRIO · MODO SIMULAÇÃO DISPONÍVEL
          </span>
        </div>
      </div>
    </footer>
  );
}
