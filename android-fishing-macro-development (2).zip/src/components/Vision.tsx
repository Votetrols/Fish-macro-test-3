import { useEffect, useRef, useState } from "react";
import { Section, Reveal } from "./ui";
import { CALIBRATION_POINTS, DETECTORS } from "../data/content";
import { Fish, ScanLine, SlidersHorizontal, BoxSelect, Target, Crosshair, CheckCheck } from "lucide-react";

// ------------------------------------------------------------------
// Simulação visual: peixe oscila, indicador persegue com atraso,
// caixas de detecção acompanham. Demonstra ROI + predição + debug.
// ------------------------------------------------------------------

const TRACK = { left: 14, width: 72, centerY: 74 }; // % da tela
const CAPTURE_W = 960;

interface Readout {
  fishX: number;
  indX: number;
  err: number;
  cmd: "HOLD" | "RELEASE" | "NO_ACTION";
  conf: number;
}

function VisionSim() {
  const [readout, setReadout] = useState<Readout>({ fishX: 480, indX: 480, err: 0, cmd: "NO_ACTION", conf: 0.94 });
  const fishBox = useRef<HTMLDivElement>(null);
  const indBox = useRef<HTMLDivElement>(null);
  const predLine = useRef<HTMLDivElement>(null);
  const state = useRef({ t: 0, ind: 0.5 });

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    let lastRead = 0;

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const s = state.current;
      s.t += dt;

      // peixe: soma de senoides → movimento "vivo"
      let f = 0.5 + 0.32 * Math.sin(s.t * 0.85) + 0.11 * Math.sin(s.t * 2.15 + 1.3);
      f = Math.max(0.03, Math.min(0.97, f));
      const vPrev = 0.32 * 0.85 * Math.cos(s.t * 0.85) * 0.2;
      const pred = Math.max(0.03, Math.min(0.97, f + vPrev * 0.35));

      // indicador: controlador proporcional com limite de velocidade
      const err = f - s.ind;
      const step = Math.max(-1.6 * dt, Math.min(1.6 * dt, err * 5.2 * dt));
      s.ind += step;

      // posições em %
      const fishLeft = TRACK.left + f * TRACK.width;
      const indLeft = TRACK.left + s.ind * TRACK.width;
      const predLeft = TRACK.left + pred * TRACK.width;

      if (fishBox.current) fishBox.current.style.left = `${fishLeft}%`;
      if (indBox.current) indBox.current.style.left = `${indLeft}%`;
      if (predLine.current) predLine.current.style.left = `${predLeft}%`;

      if (now - lastRead > 200) {
        lastRead = now;
        const fishPx = Math.round((fishLeft / 100) * CAPTURE_W);
        const indPx = Math.round((indLeft / 100) * CAPTURE_W);
        const errPx = fishPx - indPx;
        const cmd: Readout["cmd"] = Math.abs(errPx) < 8 ? "NO_ACTION" : errPx > 0 ? "HOLD" : "RELEASE";
        setReadout({
          fishX: fishPx,
          indX: indPx,
          err: errPx,
          cmd,
          conf: 0.9 + 0.07 * Math.abs(Math.sin(s.t * 1.7)),
        });
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div className="panel overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.07] px-5 py-3">
        <span className="mono-tag flex items-center gap-2 text-slate-300">
          <ScanLine size={13} className="text-cyan-300" />
          VISUALIZAÇÃO DO MODO DEBUG — SIMULAÇÃO EM TEMPO REAL
        </span>
        <span className="mono rounded border border-amber-400/30 bg-amber-400/10 px-2 py-0.5 text-[9px] tracking-[0.14em] text-amber-300">
          MOCKUP ILUSTRATIVO · NÃO É CAPTURA DO JOGO
        </span>
      </div>

      {/* screen */}
      <div className="relative m-4 overflow-hidden rounded-xl border border-white/10 bg-gradient-to-b from-[#062433] via-[#041521] to-[#030a12] sm:m-6" style={{ aspectRatio: "19.5 / 9" }}>
        {/* ambiente */}
        <div className="absolute -left-10 top-8 h-40 w-40 rounded-full bg-cyan-500/10 blur-3xl" />
        <div className="absolute right-10 top-2 h-32 w-52 rounded-full bg-teal-400/10 blur-3xl" />
        <div className="drift absolute left-[16%] top-[16%] text-cyan-200/15"><Fish size={30} /></div>
        <div className="drift absolute right-[22%] top-[30%] text-cyan-200/10" style={{ animationDelay: "1.8s" }}><Fish size={22} /></div>

        {/* ROI */}
        <div className="absolute inset-x-[7%] bottom-[5%] top-[52%] rounded-lg border border-dashed border-cyan-400/40">
          <span className="mono absolute -top-2 left-3 bg-[#04121d] px-1.5 text-[8.5px] tracking-[0.18em] text-cyan-300/90">
            ROI · AUTO_REGION
          </span>
        </div>

        {/* barra de pesca */}
        <div
          className="absolute rounded-full border border-slate-500/50 bg-slate-800/80 shadow-[inset_0_1px_0_rgba(255,255,255,0.08)]"
          style={{ left: `${TRACK.left}%`, width: `${TRACK.width}%`, top: `${TRACK.centerY}%`, height: "10px", transform: "translateY(-50%)" }}
        />
        <span
          className="mono absolute text-[8.5px] tracking-[0.18em] text-slate-400"
          style={{ left: `${TRACK.left}%`, top: `calc(${TRACK.centerY}% + 16px)` }}
        >
          BARRA
        </span>

        {/* indicador do jogador + caixa */}
        <div
          ref={indBox}
          className="absolute h-[15%] w-[4%] will-change-[left]"
          style={{ top: `${TRACK.centerY}%`, transform: "translate(-50%,-50%)", left: "50%" }}
        >
          <div className="h-full w-full rounded-[3px] border border-white/80 bg-white/25" />
          <div className="bbox -inset-1.5 text-white/90"><span /><span /><span /><span /></div>
          <span className="mono absolute -top-4 left-1/2 -translate-x-1/2 whitespace-nowrap text-[8px] tracking-[0.16em] text-white">
            INDICADOR
          </span>
        </div>

        {/* peixe + caixa */}
        <div
          ref={fishBox}
          className="absolute flex w-[9%] will-change-[left]"
          style={{ top: `${TRACK.centerY}%`, transform: "translate(-50%,-50%)", left: "50%", aspectRatio: "1/1" }}
        >
          <div className="grid h-full w-full place-items-center rounded-md border border-cyan-300/70 bg-cyan-400/25">
            <Fish size={13} className="text-cyan-200" />
          </div>
          <div className="bbox absolute -inset-1.5 text-cyan-300"><span /><span /><span /><span /></div>
          <span className="mono absolute -bottom-4 left-1/2 -translate-x-1/2 whitespace-nowrap text-[8px] tracking-[0.16em] text-cyan-300">
            PEIXE
          </span>
        </div>

        {/* linha de predição */}
        <div
          ref={predLine}
          className="absolute w-px will-change-[left]"
          style={{ top: `${TRACK.centerY - 9}%`, height: "18%", left: "50%", background: "repeating-linear-gradient(to bottom, rgba(45,212,191,0.9) 0 3px, transparent 3px 6px)" }}
        >
          <span className="mono absolute -top-4 left-1/2 -translate-x-1/2 whitespace-nowrap text-[8px] tracking-[0.16em] text-teal-300">
            PREVISÃO
          </span>
        </div>

        {/* HUD */}
        <div className="mono absolute left-3 top-3 flex flex-col gap-1 text-[8.5px] tracking-[0.14em] text-slate-400">
          <span className="flex items-center gap-1.5"><span className="blink inline-block h-1.5 w-1.5 rounded-full bg-emerald-400" /> MACRO: ON</span>
          <span>ESTADO: TRACKING · FPS 12 · CONF {readout.conf.toFixed(2)}</span>
        </div>
        <div className="mono absolute right-3 top-3 rounded border border-white/10 bg-black/30 px-2 py-1 text-[9px] tracking-[0.16em] text-slate-300">
          CMD&nbsp;
          <span className={readout.cmd === "HOLD" ? "text-emerald-300" : readout.cmd === "RELEASE" ? "text-amber-300" : "text-slate-400"}>
            {readout.cmd}
          </span>
        </div>
      </div>

      {/* readouts */}
      <div className="grid grid-cols-3 gap-px border-t border-white/[0.07] sm:grid-cols-6">
        {[
          ["PEIXE X", `${readout.fishX} px`],
          ["INDICADOR X", `${readout.indX} px`],
          ["ERRO", `${readout.err > 0 ? "+" : ""}${readout.err} px`],
          ["COMANDO", readout.cmd],
          ["CONFIDENCE", readout.conf.toFixed(2)],
          ["VELOCIDADE", `${(Math.abs(readout.err) * 0.9 + 12).toFixed(0)} px/s`],
        ].map(([k, v]) => (
          <div key={k} className="bg-white/[0.02] px-4 py-3">
            <div className="mono text-[8.5px] tracking-[0.18em] text-slate-500">{k}</div>
            <div className="mono mt-0.5 text-[12px] font-semibold text-cyan-200">{v}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ------------------------------------------------------------------

const DET_ICONS = [BoxSelect, Fish, Crosshair, Target];

export default function Vision() {
  return (
    <Section
      id="vision"
      index="04"
      eyebrow="ESTRATÉGIA DE VISÃO COMPUTACIONAL"
      title="Segmentação de cor calibrável dentro de uma ROI — nunca coordenadas fixas."
      lede="Quatro detectores independentes trabalham sobre a Região de Interesse. Todos devolvem confidence ∈ [0,1]; abaixo do threshold configurável, a detecção é inválida e a máquina de estados lida com a perda."
    >
      <Reveal>
        <VisionSim />
      </Reveal>

      {/* detectors */}
      <div className="mt-6 grid gap-3 md:grid-cols-2">
        {DETECTORS.map((d, i) => {
          const Icon = DET_ICONS[i];
          return (
            <Reveal key={d.name} delay={(i % 2) * 0.06}>
              <div className="panel panel-hover h-full p-5">
                <div className="flex items-center gap-2.5">
                  <Icon size={16} className="text-cyan-300" />
                  <h3 className="mono text-[13px] font-semibold text-slate-100">{d.name}</h3>
                </div>
                <div className="mono mt-3 overflow-x-auto rounded-lg border border-teal-400/20 bg-teal-400/5 px-3 py-2 text-[10px] leading-relaxed text-teal-200/90">
                  {d.returns}
                </div>
                <p className="mt-3 text-[12.5px] leading-relaxed text-slate-400">{d.body}</p>
              </div>
            </Reveal>
          );
        })}
      </div>

      {/* calibration */}
      <Reveal className="mt-6">
        <div className="panel grid gap-6 p-5 sm:p-7 lg:grid-cols-[1.2fr_1fr]">
          <div>
            <div className="mono-tag flex items-center gap-2 text-slate-300">
              <SlidersHorizontal size={13} className="text-cyan-300" />
              CAMADA DE CALIBRAÇÃO — REGRA 33 HONRADA
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-slate-400">
              Não sabemos — e não fingimos saber — como a UI do Fisch está desenhada em cada resolução.
              Por isso todos os parâmetros visuais vivem em perfis de configuração, editáveis no app com
              frames reais capturados como referência. Trocou o jogo de skin ou atualizou? Novo perfil, sem rebuild.
            </p>
            <ul className="mt-4 space-y-2">
              {CALIBRATION_POINTS.map((c) => (
                <li key={c} className="flex items-start gap-2.5 text-[12.5px] leading-relaxed text-slate-300/85">
                  <CheckCheck size={13} className="mt-0.5 shrink-0 text-teal-300" />
                  <span className="mono text-[11.5px]">{c}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-5">
            <div className="mono-tag text-slate-400">POR QUE NÃO OpenCV NA V1?</div>
            <p className="mt-3 text-[12.5px] leading-relaxed text-slate-400">
              O problema é segmentação de cor + componentes conectados em áreas pequenas — retrabalho
              de 2–4 KB de pixels por frame a 10 Hz. Kotlin puro sobre IntArray resolve com custo
              irrisório e zero JNI. OpenCV entra <span className="text-slate-200">somente</span> se a calibração
              com frames reais provar necessidade (formas complexas, iluminação hostil) — decisão revisitada na Fase 13.
            </p>
            <div className="mono mt-4 rounded-lg border border-white/[0.08] bg-black/30 p-3 text-[10px] leading-relaxed text-slate-500">
              frame → ROI → máscara HSV → varredura/labeling → geometria → confidence → estado
            </div>
          </div>
        </div>
      </Reveal>
    </Section>
  );
}
