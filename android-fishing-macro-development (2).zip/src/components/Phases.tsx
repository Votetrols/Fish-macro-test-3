import { Section, Reveal } from "./ui";
import { PHASES } from "../data/content";
import { CheckCircle2, CircleDashed, GitCommitVertical } from "lucide-react";

export default function Phases() {
  return (
    <Section
      id="phases"
      index="10"
      eyebrow="PLANO DE IMPLEMENTAÇÃO"
      title="Treze fases, um gate por fase: compilar, testar, corrigir, avançar."
      lede="Nada será implementado 'tudo de uma vez'. Cada fase entrega algo verificável em aparelho real e só é encerrada com build verde — a Fase 1 começa no instante em que esta arquitetura for aprovada."
    >
      <div className="relative">
        <div className="absolute bottom-4 left-[21px] top-4 w-px bg-gradient-to-b from-cyan-400/50 via-cyan-400/15 to-transparent sm:left-[25px]" />
        <div className="space-y-3">
          {PHASES.map((p, i) => (
            <Reveal key={p.n} delay={Math.min(i * 0.04, 0.3)}>
              <div className="group relative flex gap-4 sm:gap-6">
                <div className="relative z-10 mt-1 grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-white/[0.1] bg-[#070d1a] sm:h-[52px] sm:w-[52px]">
                  <span className="mono text-[12px] font-semibold text-cyan-300">{p.n}</span>
                  {i === 0 && (
                    <span className="absolute -right-1 -top-1 grid h-4 w-4 place-items-center rounded-full border border-amber-400/50 bg-[#04070e]">
                      <span className="blink h-1.5 w-1.5 rounded-full bg-amber-300" />
                    </span>
                  )}
                </div>
                <div className="panel panel-hover w-full p-4 sm:p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3 className="text-[14.5px] font-semibold text-slate-100">
                      FASE {p.n} — {p.title}
                    </h3>
                    <span className="mono flex items-center gap-1.5 rounded-full border border-slate-400/20 bg-slate-400/5 px-2.5 py-1 text-[9px] tracking-[0.14em] text-slate-400">
                      <CircleDashed size={10} />
                      {i === 0 ? "PRÓXIMA — AGUARDA APROVAÇÃO" : "PENDENTE"}
                    </span>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {p.scope.map((s) => (
                      <span key={s} className="mono rounded border border-white/[0.08] bg-white/[0.03] px-2 py-1 text-[10px] text-slate-400">
                        {s}
                      </span>
                    ))}
                  </div>
                  <div className="mono mt-3 flex items-center gap-2 text-[9.5px] tracking-[0.1em] text-teal-300/80">
                    <GitCommitVertical size={12} />
                    GATE → {p.gate.toUpperCase()}
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-8">
          <div className="ml-[60px] flex items-center gap-3 sm:ml-[76px]">
            <CheckCircle2 size={18} className="text-emerald-300" />
            <p className="text-[13px] text-slate-300">
              <span className="mono-tag mr-2 text-emerald-300">DONE</span>
              Critérios de aceitação 19/19 — só então o projeto é considerado concluído.
            </p>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}
