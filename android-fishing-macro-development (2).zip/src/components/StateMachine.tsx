import { useMemo, useState } from "react";
import { SM_EDGES, SM_H, SM_NODES, SM_TRANSITIONS, TONE } from "../data/content";
import { ArrowLeftRight, MousePointerClick } from "lucide-react";

const NODE_H = SM_H;

export default function StateMachine() {
  const [selected, setSelected] = useState<string>("CONTROLLING");
  const nodeMap = useMemo(() => Object.fromEntries(SM_NODES.map((n) => [n.id, n])), []);
  const currentsNode = nodeMap[selected];

  const related = (from: string, to: string) => from === selected || to === selected;

  const inbound = SM_TRANSITIONS.filter((t) => t.to === currentsNode.label || t.to === selected);
  const outbound = SM_TRANSITIONS.filter((t) => (t.from === currentsNode.label || t.from === selected) && t.to !== selected);

  return (
    <div className="panel overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/[0.07] px-5 py-3.5">
        <div className="flex items-center gap-2.5">
          <ArrowLeftRight size={14} className="text-cyan-300" />
          <span className="mono-tag text-slate-300">MÁQUINA DE ESTADOS EXPLÍCITA — 11 ESTADOS</span>
        </div>
        <div className="flex items-center gap-2 text-slate-500">
          <MousePointerClick size={12} />
          <span className="mono text-[9.5px] tracking-[0.16em]">TOQUE EM UM ESTADO</span>
        </div>
      </div>

      <div className="overflow-x-auto">
        <svg viewBox="0 0 1100 560" className="min-w-[760px] w-full" role="img" aria-label="Máquina de estados do macro">
          <defs>
            {(Object.keys(TONE) as (keyof typeof TONE)[]).map((t) => (
              <marker
                key={t}
                id={`arr-${t}`}
                viewBox="0 0 10 10"
                refX="8.5"
                refY="5"
                markerWidth="5.5"
                markerHeight="5.5"
                orient="auto-start-reverse"
              >
                <path d="M0 0 L10 5 L0 10 z" fill={TONE[t].stroke} />
              </marker>
            ))}
          </defs>

          {/* edges */}
          {SM_EDGES.map((e) => {
            const active = related(e.from, e.to);
            const tone = TONE[e.tone];
            return (
              <g key={e.id} opacity={active ? 1 : 0.14} style={{ transition: "opacity .3s" }}>
                <path
                  d={e.d}
                  fill="none"
                  stroke={tone.stroke}
                  strokeWidth={active ? 2 : 1.3}
                  strokeLinejoin="round"
                  markerEnd={`url(#arr-${e.tone})`}
                  className={active && !e.dashed ? "edge-flow" : undefined}
                  strokeDasharray={e.dashed ? "5 6" : undefined}
                />
                {e.label && (
                  <text
                    x={e.lx}
                    y={e.ly}
                    textAnchor="middle"
                    fontSize="9.5"
                    fontFamily="IBM Plex Mono, monospace"
                    letterSpacing="0.08em"
                    fill={active ? tone.stroke : "#475569"}
                  >
                    {e.label}
                  </text>
                )}
              </g>
            );
          })}

          {/* nodes */}
          {SM_NODES.map((n) => {
            const isSel = selected === n.id;
            const tone = TONE[n.tone];
            const isNeighbor = SM_EDGES.some((e) => related(e.from, e.to) && (e.from === n.id || e.to === n.id));
            const dim = !isSel && !isNeighbor;
            return (
              <g
                key={n.id}
                onClick={() => setSelected(n.id)}
                className="cursor-pointer"
                opacity={dim ? 0.35 : 1}
                style={{ transition: "opacity .3s" }}
              >
                {isSel && (
                  <rect
                    x={n.x - 6}
                    y={n.y - 6}
                    width={n.w + 12}
                    height={NODE_H + 12}
                    rx={14}
                    fill="none"
                    stroke={tone.stroke}
                    strokeOpacity={0.35}
                    strokeWidth={1}
                  />
                )}
                <rect
                  x={n.x}
                  y={n.y}
                  width={n.w}
                  height={NODE_H}
                  rx={10}
                  fill={isSel ? "rgba(34,211,238,0.06)" : "#0a1220"}
                  stroke={tone.stroke}
                  strokeOpacity={isSel ? 0.9 : 0.45}
                  strokeWidth={isSel ? 1.8 : 1.2}
                />
                <circle cx={n.x + 13} cy={n.y + NODE_H / 2} r={3.2} fill={tone.stroke} className={isSel ? "blink" : undefined} />
                <text
                  x={n.x + 22}
                  y={n.y + NODE_H / 2 + 3.5}
                  fontSize={n.label.length > 14 ? 9.5 : 10.5}
                  fontFamily="IBM Plex Mono, monospace"
                  fontWeight={600}
                  letterSpacing="0.04em"
                  fill={isSel ? tone.stroke : "#cbd5e1"}
                >
                  {n.label}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      {/* detail panel */}
      <div className="grid gap-5 border-t border-white/[0.07] px-5 py-5 md:grid-cols-[1fr_1fr]">
        <div>
          <div className="mono-tag text-cyan-300">{currentsNode.label}</div>
          <p className="mt-2 text-[13px] leading-relaxed text-slate-400">{currentsNode.desc}</p>
          <p className="mono mt-4 text-[9.5px] leading-relaxed tracking-[0.06em] text-slate-600">
            * TRANSIÇÃO PARA ERROR EXISTE A PARTIR DE QUALQUER ESTADO EM EXCEÇÃO CRÍTICA
            TRATADA — REPRESENTADA NO DIAGRAMA POR UMA ARESTA EXEMPLO.
          </p>
        </div>
        <div className="space-y-2">
          {outbound.slice(0, 3).map((t, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="mono-tag w-14 shrink-0 text-emerald-300/80">SAÍDA</span>
              <span className="mono rounded-md border border-white/[0.08] bg-white/[0.03] px-2.5 py-1 text-[10px] text-slate-300">
                → {t.to} <span className="text-slate-500">· {t.event.trim()}</span>
              </span>
            </div>
          ))}
          {inbound.slice(0, 3).map((t, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="mono-tag w-14 shrink-0 text-slate-500">ENTRADA</span>
              <span className="mono rounded-md border border-white/[0.08] bg-white/[0.03] px-2.5 py-1 text-[10px] text-slate-300">
                {t.from} → <span className="text-slate-500">{t.event.trim()}</span>
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* legend */}
      <div className="flex flex-wrap gap-4 border-t border-white/[0.07] px-5 py-3">
        {[
          ["#22d3ee", "fluxo principal"],
          ["#fbbf24", "recuperação / perda"],
          ["#fb7185", "erro / falha"],
          ["#94a3b8", "manual / sistema"],
        ].map(([c, l]) => (
          <span key={l} className="mono flex items-center gap-2 text-[9.5px] tracking-[0.12em] text-slate-500">
            <span className="inline-block h-px w-6" style={{ background: c }} />
            {l.toUpperCase()}
          </span>
        ))}
      </div>
    </div>
  );
}
