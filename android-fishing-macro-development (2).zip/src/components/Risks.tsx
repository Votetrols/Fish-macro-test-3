import { Section, Reveal } from "./ui";
import { RISKS } from "../data/content";
import { ShieldAlert } from "lucide-react";

const LEVEL_STYLE: Record<string, string> = {
  ALTA: "border-rose-400/40 bg-rose-400/10 text-rose-300",
  "MÉDIA": "border-amber-400/40 bg-amber-400/10 text-amber-300",
  BAIXA: "border-cyan-400/40 bg-cyan-400/10 text-cyan-300",
};

export default function Risks() {
  return (
    <Section
      id="risks"
      index="09"
      eyebrow="RISCOS TÉCNICOS"
      title="Os oito modos de falha mapeados antes do primeiro build."
      lede="Cada risco tem mitigação arquitetural concreta — ou é declarado como fora do controle técnico. Nada de 'resolvemos depois'."
    >
      <div className="grid gap-3 md:grid-cols-2">
        {RISKS.map((r, i) => (
          <Reveal key={r.title} delay={(i % 2) * 0.05}>
            <div className="panel panel-hover h-full p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <ShieldAlert size={16} className="mt-0.5 shrink-0 text-slate-500" />
                  <h3 className="text-[13.5px] font-semibold leading-snug text-slate-100">{r.title}</h3>
                </div>
                <span className={`mono shrink-0 rounded-full border px-2.5 py-1 text-[9px] tracking-[0.16em] ${LEVEL_STYLE[r.level]}`}>
                  {r.level}
                </span>
              </div>
              <p className="mt-3 pl-7 text-[12px] leading-relaxed text-slate-400">
                <span className="mono-tag mr-2 text-teal-300/80">MITIGAÇÃO</span>
                {r.mitigation}
              </p>
            </div>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
