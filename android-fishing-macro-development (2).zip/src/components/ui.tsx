import { motion } from "framer-motion";
import type { ReactNode } from "react";

export function Reveal({
  children,
  delay = 0,
  className,
  y = 26,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  y?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.75, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export function Section({
  id,
  index,
  eyebrow,
  title,
  lede,
  children,
}: {
  id: string;
  index: string;
  eyebrow: string;
  title: string;
  lede?: string;
  children: ReactNode;
}) {
  return (
    <section id={id} className="relative scroll-mt-24 py-20 sm:py-28">
      <div className="pointer-events-none absolute -top-6 right-0 hidden select-none lg:block">
        <span className="ghost-num text-[180px]">{index}</span>
      </div>
      <div className="mx-auto w-full max-w-6xl px-5 sm:px-8">
        <Reveal>
          <div className="mb-3 flex items-center gap-3">
            <span className="mono-tag rounded-full border border-cyan-400/30 bg-cyan-400/10 px-3 py-1 text-cyan-300">
              {index}
            </span>
            <span className="mono-tag text-slate-400">{eyebrow}</span>
          </div>
        </Reveal>
        <Reveal delay={0.05}>
          <h2 className="max-w-3xl text-3xl font-bold leading-[1.05] tracking-tight text-slate-100 sm:text-5xl">
            {title}
          </h2>
        </Reveal>
        {lede && (
          <Reveal delay={0.1}>
            <p className="mt-4 max-w-2xl text-[15px] leading-relaxed text-slate-400">{lede}</p>
          </Reveal>
        )}
        <div className="mt-10">{children}</div>
      </div>
    </section>
  );
}

export function Chip({ children, tone = "text-slate-300 border-slate-400/20 bg-slate-400/5" }: { children: ReactNode; tone?: string }) {
  return (
    <span className={`mono inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-[10.5px] tracking-wide ${tone}`}>
      {children}
    </span>
  );
}

export function Label({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <span className={`mono-tag ${className}`}>{children}</span>;
}
