import { Section, Reveal } from "./ui";
import { GESTURE_SEQUENCE, INPUT_CHECKS } from "../data/content";
import { ArrowRight, BadgeCheck, Ban, Hand, ScanSearch } from "lucide-react";

const PHASE_TONE: Record<string, string> = {
  PRESS: "border-emerald-400/30 bg-emerald-400/10 text-emerald-300",
  HOLD: "border-cyan-400/30 bg-cyan-400/10 text-cyan-300",
  RELEASE: "border-amber-400/30 bg-amber-400/10 text-amber-300",
};

const NOT_FAKING = [
  { what: "InputManager.injectInputEvent", why: "Exige a permissão INJECT_EVENTS, protegida por assinatura do sistema. Inacessível a apps comuns sem root — não será usada, nem sugerida." },
  { what: "Root / shell (input tap · input swipe)", why: "Fora do escopo: quebra garantia, SafetyNet/Play Integrity e o requisito de instalação limpa em aparelho real." },
  { what: "\"Funciona em segundo plano\"", why: "Mentira técnica. Gesto e captura exigem o Roblox visível; o app dirá isso na cara, na tela inicial." },
];

export default function Input() {
  return (
    <Section
      id="input"
      index="06"
      eyebrow="ESTRATÉGIA DE INPUT"
      title="dispatchGesture ou nada: a única via legítima sem root."
      lede="A decisão (controller/) nunca toca no Android. Ela emite comandos para uma InputController, cuja implementação real usa AccessibilityService.dispatchGesture — declarada, configurada e verificada em runtime, sem fingir capacidades que o serviço não tem."
    >
      {/* gesture sequence */}
      <Reveal>
        <div className="panel p-5 sm:p-7">
          <div className="mono-tag mb-5 flex items-center gap-2 text-slate-300">
            <Hand size={13} className="text-cyan-300" />
            COMO SE CONSTRÓI "SEGURAR A TELA" COM GESTOS ASSÍNCRONOS
          </div>
          <div className="grid gap-3 lg:grid-cols-[1fr_auto_1fr_auto_1fr] lg:items-stretch">
            {GESTURE_SEQUENCE.map((g, i) => (
              <div key={g.phase} className="contents">
                <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-4">
                  <span className={`mono inline-flex rounded-full border px-2.5 py-1 text-[9.5px] tracking-[0.16em] ${PHASE_TONE[g.phase]}`}>
                    {String(i + 1).padStart(2, "0")} · {g.phase}
                  </span>
                  <div className="mono mt-3 overflow-x-auto whitespace-nowrap rounded-lg border border-white/[0.08] bg-black/40 px-3 py-2 text-[10px] text-teal-200/90">
                    {g.code}
                  </div>
                  <p className="mt-3 text-[12px] leading-relaxed text-slate-400">{g.body}</p>
                </div>
                {i < GESTURE_SEQUENCE.length - 1 && (
                  <div className="hidden items-center lg:flex">
                    <ArrowRight size={15} className="text-cyan-500/60" />
                  </div>
                )}
              </div>
            ))}
          </div>
          <p className="mono mt-5 text-[9.5px] leading-relaxed tracking-[0.08em] text-slate-500">
            LIMITES RESPEITADOS: GESTO ≤ 60 S POR DESCRIÇÃO · ≤ 10 TRAÇOS · CALLBACKS onCompleted/onCancelled TRATADOS ·
            UMA SEQUÊNCIA POR VEZ, SEMPRE COM RELEASE COMPENSATÓRIO EM QUALQUER SAÍDA ANÔMALA.
          </p>
        </div>
      </Reveal>

      <div className="mt-6 grid gap-3 lg:grid-cols-2">
        {/* checks */}
        <Reveal>
          <div className="panel h-full p-5 sm:p-6">
            <div className="mono-tag flex items-center gap-2 text-slate-300">
              <ScanSearch size={13} className="text-cyan-300" />
              VERIFICAÇÕES ANTES DE CADA CICLO
            </div>
            <ul className="mt-4 space-y-3">
              {INPUT_CHECKS.map((c) => (
                <li key={c} className="flex items-start gap-2.5 text-[12.5px] leading-relaxed text-slate-300/85">
                  <BadgeCheck size={14} className="mt-0.5 shrink-0 text-teal-300" />
                  {c}
                </li>
              ))}
            </ul>
            <div className="mono mt-5 rounded-lg border border-white/[0.08] bg-white/[0.03] p-3.5 text-[10px] leading-relaxed text-slate-400">
              <span className="text-slate-200">Manifest + config garantidos:</span> serviço declarado com
              BIND_ACCESSIBILITY_SERVICE, XML com canPerformGestures, flags de janela e feedback desligado —
              e tratamento explícito para serviço desativado pelo sistema a qualquer momento.
            </div>
          </div>
        </Reveal>

        {/* not faking */}
        <Reveal delay={0.08}>
          <div className="panel h-full p-5 sm:p-6">
            <div className="mono-tag flex items-center gap-2 text-slate-300">
              <Ban size={13} className="text-rose-300" />
              O QUE NÃO SERÁ FINGIDO — REGRA 32 APLICADA AO TOQUE
            </div>
            <div className="mt-4 space-y-3">
              {NOT_FAKING.map((n) => (
                <div key={n.what} className="rounded-xl border border-rose-400/15 bg-rose-400/[0.04] p-4">
                  <div className="mono text-[11px] font-semibold text-rose-200/90">{n.what}</div>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-slate-400">{n.why}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 rounded-xl border border-cyan-400/20 bg-cyan-400/[0.05] p-4">
              <p className="text-[12px] leading-relaxed text-slate-300/90">
                <span className="mono mr-1.5 rounded border border-cyan-400/40 bg-cyan-400/15 px-1.5 py-0.5 text-[9px] tracking-[0.12em] text-cyan-200">
                  FALLBACK
                </span>
                Se a Acessibilidade estiver desativada, o app roda em SIMULATION MODE: detecção, predição e decisão
                visíveis no debug, sem enviar um único toque.
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}
