import { Section, Reveal } from "./ui";
import { DEPS_RUNTIME, DEPS_TEST, EXCLUDED_DEPS } from "../data/content";
import { FlaskConical, Package, PackageX } from "lucide-react";

function DepTable({
  title,
  icon: Icon,
  rows,
  foot,
}: {
  title: string;
  icon: typeof Package;
  rows: { name: string; version: string; why: string }[];
  foot?: string;
}) {
  return (
    <div className="panel h-full overflow-hidden">
      <div className="mono-tag flex items-center gap-2 border-b border-white/[0.07] px-5 py-3.5 text-slate-300">
        <Icon size={13} className="text-cyan-300" />
        {title}
      </div>
      <div className="divide-y divide-white/[0.05]">
        {rows.map((d) => (
          <div key={d.name} className="px-5 py-3.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="mono text-[11.5px] font-semibold text-slate-200">{d.name}</span>
              <span className="mono rounded border border-white/[0.1] bg-white/[0.04] px-2 py-0.5 text-[9.5px] tracking-wide text-slate-400">
                {d.version}
              </span>
            </div>
            <p className="mt-1.5 text-[11.5px] leading-relaxed text-slate-400">{d.why}</p>
          </div>
        ))}
      </div>
      {foot && (
        <div className="border-t border-white/[0.07] bg-white/[0.02] px-5 py-3">
          <p className="mono text-[9px] leading-relaxed tracking-[0.06em] text-slate-500">{foot}</p>
        </div>
      )}
    </div>
  );
}

export default function Dependencies() {
  return (
    <Section
      id="deps"
      index="08"
      eyebrow="DEPENDÊNCIAS"
      title="Poucas, estáveis, justificadas — e uma lista do que ficou de fora."
      lede="Cada biblioteca entra com motivo declarado e versão fixada na Fase 1, após verificação cruzada de compatibilidade (AGP × Kotlin × Compose BOM). Nenhuma dependência abandonada, nenhuma 'por via das dúvidas'."
    >
      <div className="grid gap-3 lg:grid-cols-2">
        <Reveal>
          <DepTable
            title="RUNTIME — 6 DEPENDÊNCIAS"
            icon={Package}
            rows={DEPS_RUNTIME}
            foot="VERSÕES EXATAS FIXADAS NA FASE 1 COM LOCKFILE (gradle.versions.toml) — SEM RANGES DINÂMICOS."
          />
        </Reveal>
        <Reveal delay={0.08}>
          <DepTable
            title="TESTES — 4 DEPENDÊNCIAS"
            icon={FlaskConical}
            rows={DEPS_TEST}
            foot="ROBOLECTRICAL PERMITE TESTAR OS DETECTORES COM FRAMES SINTÉTICOS RGBA EM JVM — CI SEM DEVICE."
          />
        </Reveal>
      </div>

      <Reveal className="mt-6">
        <div className="panel overflow-hidden">
          <div className="mono-tag flex items-center gap-2 border-b border-white/[0.07] px-5 py-3.5 text-slate-300">
            <PackageX size={13} className="text-rose-300" />
            EXCLUÍDAS DE PROPÓSITO — E POR QUÊ
          </div>
          <div className="grid gap-px sm:grid-cols-2">
            {EXCLUDED_DEPS.map((x) => (
              <div key={x.name} className="bg-white/[0.02] p-5">
                <span className="mono text-[11.5px] font-semibold text-rose-200/90 line-through decoration-rose-400/50">
                  {x.name}
                </span>
                <p className="mt-2 text-[11.5px] leading-relaxed text-slate-400">{x.why}</p>
              </div>
            ))}
          </div>
        </div>
      </Reveal>
    </Section>
  );
}
