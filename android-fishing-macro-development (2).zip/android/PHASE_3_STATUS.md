# Phase 3 Status — Visão e Detecção

## Implementado

- `[IMPLEMENTED / TESTADO POR CÓDIGO (JVM, pendente execução local)]`
  - `RoiManager` — FULL/CUSTOM/AUTO ancorados em fração de tela; validação na construção; independente de resolução/rotação.
  - `ColorProfile` + `rgbToHsv` — faixas HSV circulares; **perfis padrão declarados NÃO CALIBRADOS** (calibração com frames reais é pré-requisito da Fase 6.1).
  - `BlobDetector` — segmentação + componentes conectados (BFS 4-conexo), portões geométricos (aspecto/área/células mínimas), confidence heurística documentada em [0,1].
  - `FishingUiDetectors` — dois estágios: barra na ROI → peixe e indicador dentro da barra. Satisfaz o contrato `Detector` da Fase 1.
  - `RealVisionProcessor` — satisfaz `VisionProcessor`, mede latência e alimenta `FrameMetrics` (fps/processamento/sem-detecção). Sem decisão de controle nesta camada.
- Frames inválidos (payload opaco, ROI degenerada) → lista vazia tipada, zero crash.

## Testes (escritos; execução local BLOCKED)

`VisionPipelineTest.kt` — 12 casos: HSV âncora · ROI/rotation/fração · ROI inválida · detecção válida (3 tipos) · escopo dentro da barra · ausência de detecção · blob mínimo descartado · múltiplas detecções · frame inválido sem crash · ROI auto · métricas/timestamp do processor. Cobre a checklist da Fase 3 (válida/ausente/baixa/inválida/múltiplas/ROI/rotação/frame inválido).

## Não coberto nesta fase

Calibração cromática real (requer frames do jogo — Fase 6.1) · medidas de CPU/RAM em device (BLOCKED) · resize/normalização nativa (pipeline opera no payload RGBA direto por amostragem — decisão de custo documentada).

## Gate Fase 3

**BLOCKED (execução)** — lógica real e coberta por testes escritos; suíte não executada aqui.
Não há regressão introduzida: contratos da Fase 1 e regressão Fase 2 preservados nos arquivos de teste.
