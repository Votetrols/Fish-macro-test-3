# Phase 4 Status — Tracking e Decisão

## Implementado

- `EmaTargetTracker` — EMA posição/velocidade, associação nearest-neighbor com teto de salto (multi-objeto/anti-teleporte), rejeição de timestamps fora de ordem, timeout de perda, predição com lead limitado, reset.
- `FishingControllerImpl` + `ControlConfig` — zona morta + histerese (exit < enter), minHold anti-chatter, minRelease + teto de taxa, maxHold fail-safe, fail-safe de visão (confidence baixa / alvo nulo → RELEASE; dt inválido → NONE), relógio injetável.
- A camada produz SOMENTE comandos abstratos (NONE/PRESS/HOLD/RELEASE) — zero contato com Android/gestos; contratos da Fase 1 intactos.
- Durante perda de tracking NENHUM comando é produzido (alinha fail-safe da Fase 4).

## Testes (escritos; execução local BLOCKED)

`TrackerControllerTest.kt` — 17 casos cobrindo a matriz exigida: estável, movimento (velocidade), ruído (EMA), perda temporária, perda prolongada, multi-objeto, baixa confidence, frames fora de ordem, timestamps inválidos, maxHold, minHold, minRelease, config inválida.

## Gate Fase 4

**BLOCKED (execução)** — sem regressão sobre Fases 1–3 (arquivos anteriores não alterados).
