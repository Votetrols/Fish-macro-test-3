# Phase 5 Status — Input Real

## Implementado

- `[IMPLEMENTED / DEVICE BLOCKED]` `MacroAccessibilityService` funcional: instância real, `dispatchGesture` com `GestureDescription`/`StrokeDescription` reais, **cadeia willContinue cancelável** (decisão decorrente de fato da API: dispatchGesture não tem cancel; stroke único longo não pode ser solto), callbacks de completed/cancelled tratados, SecurityException/IllegalStateException capturadas, foreground package rastreado, `canPerformGestures=true` com justificativa (XML editado nesta fase, não antes).
- `[IMPLEMENTED / NÃO TESTADO EM DEVICE]` `AccessibilityInputController`: gates rígidos (só CONTROLLING + trackingOk + confidence≥mínima), limites configuráveis (intervalo mínimo, janela 60s, maxHold, ponto de toque em fração de frame), releaseAll que NÃO passa por gate, `GestureDispatcher` seam p/ produção↔testes.

## Latência de soltura documentada

`endHold` é efetivo na próxima fronteira de segmento: pior caso ≈ 120 ms
(SEGMENT_MS). Compensado pelo fail-safe da Fase 4 (RELEASE proativo) e failsafe
do watchdog (Fase 6). Não existe forma oficial mais rápida: registrado.

## Testes

Primeiro fake (regra da fase) ✔ escrito na suíte de integração da Fase 6
(`IntegrationFlowTest` com GestureDispatcher falso dentro do conjunto de
bloqueio). Device: `[BLOCKED]`.

## Gate Fase 5

**BLOCKED (execução)** — código real; gestos exigem device para validação física.
