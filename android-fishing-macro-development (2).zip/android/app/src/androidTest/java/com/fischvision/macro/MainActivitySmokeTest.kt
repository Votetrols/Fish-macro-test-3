package com.fischvision.macro

import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Smoke test de instrumentação: valida que a Activity é lançável pelo sistema.
 * Só executa em device/emulador (androidTest) — não roda na JVM.
 *
 * NOTA DE STATUS: não executado neste ambiente (sem device); ver
 * PHASE_1_STATUS.md > Install.
 */
@RunWith(AndroidJUnit4::class)
class MainActivitySmokeTest {

    @get:Rule
    val activityRule = ActivityScenarioRule(MainActivity::class.java)

    @Test
    fun activity_lanca_e_expoe_estado_inicial() {
        activityRule.scenario.onActivity { activity ->
            assertNotNull(activity)
            assertEquals("com.fischvision.macro", activity.packageName)
        }
    }
}
