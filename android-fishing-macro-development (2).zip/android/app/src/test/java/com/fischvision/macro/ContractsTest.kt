package com.fischvision.macro

import com.fischvision.macro.controller.ControlCommand
import com.fischvision.macro.controller.Controller
import com.fischvision.macro.detector.Detection
import com.fischvision.macro.input.InputCommand
import com.fischvision.macro.input.InputController
import com.fischvision.macro.settings.MacroSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * Test implementation only — recebe e registra comandos sem tocar no Android.
 * Prova o desacoplamento das camadas: controller emite intenção; input a recebe.
 */
class FakeInputController : InputController {

    val received = mutableListOf<InputCommand>()
    var releaseAllCalls = 0
        private set

    override val isAvailable: Boolean = true

    override fun execute(command: InputCommand): Boolean {
        received += command
        return true
    }

    override fun releaseAll() {
        releaseAllCalls++
    }
}

/**
 * Test implementation only — tabela de decisão fixa (regra 22.3):
 * NÃO é o controlador da Fase 8; apenas torna o contrato exercitável.
 */
class ScriptedFakeController(private val deadZonePx: Float) : Controller {

    val emitted = mutableListOf<ControlCommand>()

    override fun update(
        targetPositionX: Float?,
        indicatorPositionX: Float?,
        confidence: Float,
        deltaTimeNanos: Long,
    ): ControlCommand {
        val command = when {
            targetPositionX == null || indicatorPositionX == null || confidence <= 0f ->
                ControlCommand.NONE
            targetPositionX - indicatorPositionX > deadZonePx ->
                ControlCommand(ControlCommand.Type.PRESS, reason = "alvo à direita do indicador")
            targetPositionX - indicatorPositionX < -deadZonePx ->
                ControlCommand(ControlCommand.Type.RELEASE, reason = "alvo à esquerda do indicador")
            else -> ControlCommand.NONE
        }
        emitted += command
        return command
    }

    override fun reset() {
        emitted.clear()
    }
}

class ContractsTest {

    // ------------------------------------------------------------ settings

    @Test
    fun `settings defaults sao os documentados`() {
        val s = MacroSettings.DEFAULT
        assertEquals(960, s.captureWidth)
        assertEquals(540, s.captureHeight)
        assertEquals(10, s.targetFps)
        assertFalse(s.debugEnabled)
        assertFalse(s.controllerEnabled)
    }

    @Test
    fun `settings defaults permanecem conservadores`() {
        val s = MacroSettings.DEFAULT
        assertTrue("resolução de captura deve ficar em nível conservador", s.captureWidth <= 1280)
        assertTrue("fps alvo conservador para aparelhos médios/baixos", s.targetFps in 5..30)
    }

    // ------------------------------------------------------------ detection

    @Test
    fun `detection valida confidence entre 0 e 1`() {
        try {
            Detection(
                type = Detection.Type.FISH,
                left = 0f, top = 0f, right = 10f, bottom = 10f,
                confidence = 1.5f, timestampNanos = 0L,
            )
            fail("confidence > 1 deveria lançar IllegalArgumentException")
        } catch (_: IllegalArgumentException) {
            // esperado
        }
    }

    @Test
    fun `detection valida bounding box`() {
        try {
            Detection(
                type = Detection.Type.FISHING_BAR,
                left = 100f, top = 0f, right = 10f, bottom = 10f,
                confidence = 0.5f, timestampNanos = 0L,
            )
            fail("bounding box invertida deveria lançar IllegalArgumentException")
        } catch (_: IllegalArgumentException) {
            // esperado
        }
    }

    // ------------------------------------------------- controller (fake)

    @Test
    fun `fake controller mapeia erro positivo para PRESS`() {
        val controller = ScriptedFakeController(deadZonePx = 5f)
        val cmd = controller.update(
            targetPositionX = 120f,
            indicatorPositionX = 100f,
            confidence = 0.9f,
            deltaTimeNanos = 100_000_000L,
        )
        assertEquals(ControlCommand.Type.PRESS, cmd.type)
        assertEquals(1, controller.emitted.size)
    }

    @Test
    fun `fake controller mapeia erro negativo para RELEASE e zona morta para NONE`() {
        val controller = ScriptedFakeController(deadZonePx = 5f)
        assertEquals(
            ControlCommand.Type.RELEASE,
            controller.update(80f, 100f, 0.9f, 1L).type,
        )
        assertEquals(
            ControlCommand.Type.NONE,
            controller.update(102f, 100f, 0.9f, 1L).type,
        )
    }

    @Test
    fun `fake controller nao decide sem alvos validos`() {
        val controller = ScriptedFakeController(deadZonePx = 5f)
        assertEquals(ControlCommand.Type.NONE, controller.update(null, 100f, 0.9f, 1L).type)
        assertEquals(ControlCommand.Type.NONE, controller.update(100f, null, 0.9f, 1L).type)
        assertEquals(ControlCommand.Type.NONE, controller.update(100f, 100f, 0.0f, 1L).type)
    }

    // ------------------------------------------------------------ input (fake)

    @Test
    fun `fake input recebe comandos na ordem e releaseAll e contabilizado`() {
        val input = FakeInputController()
        assertTrue(input.isAvailable)

        val commands = listOf(
            InputCommand(InputCommand.Action.HOLD_START, x = 480f, y = 900f),
            InputCommand(InputCommand.Action.HOLD_END, x = 480f, y = 900f),
            InputCommand(InputCommand.Action.TAP, x = 480f, y = 900f, durationMillis = 40L),
        )
        commands.forEach { assertTrue(input.execute(it)) }
        input.releaseAll()

        assertEquals(commands, input.received)
        assertEquals(1, input.releaseAllCalls)
    }

    // ------------------------------------------------------------ frame payload

    @Test
    fun `frame carrega metadados sem representacao de pixels inventada`() {
        val frame = FakeFrameSource.frame(42L)
        assertEquals(42L, frame.timestampNanos)
        assertEquals(960, frame.width)
        assertEquals(540, frame.height)
        assertEquals(NoopPayload.sizeBytes(), frame.payload.sizeBytes())
    }
}
