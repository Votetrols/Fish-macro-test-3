package com.fischvision.macro

import com.fischvision.macro.capture.CaptureMetrics
import com.fischvision.macro.capture.FrameBus
import com.fischvision.macro.capture.RgbaFramePayload
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Payload de pixels sintético — Test implementation only.
 * Prova o contrato [RgbaFramePayload] sem android.media.Image.
 */
class CountingRgbaPayload(
    private val w: Int = 4,
    private val h: Int = 4,
) : RgbaFramePayload {

    var releaseCalls = 0
        private set

    override val pixelWidth: Int get() = w
    override val pixelHeight: Int get() = h

    override fun argbAt(x: Int, y: Int): Int? =
        if (x in 0 until w && y in 0 until h) 0xFF102030.toInt() else null

    override fun sizeBytes(): Long = w.toLong() * h * 4L

    override fun release() {
        releaseCalls++
    }
}

class CaptureInfraTest {

    // ----------------------------------------------------------- payload

    @Test
    fun `payload libera recurso e conta releases`() {
        val p = CountingRgbaPayload()
        p.release()
        p.release()
        assertTrue(p.releaseCalls >= 1)
    }

    @Test
    fun `payload retorna cor dentro dos limites e null fora`() {
        val p = CountingRgbaPayload(4, 4)
        assertNotNull(p.argbAt(0, 0))
        assertNotNull(p.argbAt(3, 3))
        assertEquals(null, p.argbAt(-1, 0))
        assertEquals(null, p.argbAt(4, 0))
    }

    // ----------------------------------------------------------- métricas

    @Test
    fun `capture metrics conta frames e janela de fps`() {
        val m = CaptureMetrics()
        m.onFrame(1_000_000_000L)
        m.onFrame(1_100_000_000L)
        m.onFrame(1_200_000_000L)
        val snap = m.snapshot()
        assertEquals(3L, snap.framesPublished)
        assertEquals(3L, snap.fpsInCurrentWindow)
    }

    @Test
    fun `capture metrics reinicia janela apos um segundo`() {
        val m = CaptureMetrics()
        m.onFrame(0L)
        m.onFrame(500_000_000L)
        m.onFrame(2_000_000_000L)
        val snap = m.snapshot()
        assertEquals(3L, snap.framesPublished)
        assertEquals(1L, snap.fpsInCurrentWindow)
    }

    @Test
    fun `frames invalidos sao contabilizados separadamente`() {
        val m = CaptureMetrics()
        m.onFrame(0L)
        m.onInvalidFrame()
        m.onInvalidFrame()
        val snap = m.snapshot()
        assertEquals(1L, snap.framesPublished)
        assertEquals(2L, snap.framesInvalidDropped)
    }

    // ------------------------------------- regressão de backpressure (Fase 1)

    @Test
    fun `REGRESSAO frame bus continua latest wins apos fase 2`() = runTest {
        val bus = FrameBus()
        repeat(100) { seq ->
            assertTrue(bus.tryPublish(FakeFrameSource.frame(seq.toLong())))
        }
        assertEquals(1, bus.frames.replayCache.size)
        assertEquals(99L, bus.latest?.timestampNanos)
        val latest = withTimeout(1_000) { bus.frames.first() as com.fischvision.macro.capture.Frame }
        assertEquals(99L, latest.timestampNanos)
    }

    @Test
    fun `payload de captura respeita contrato de release idempotente da fase 1`() {
        val p1 = CountingRgbaPayload()
        p1.release()
        p1.release()
        // consumidor nunca deve duplicar fechamento fatal: idempotência é contrato
        assertFalse(p1.releaseCalls == 0)
    }
}
