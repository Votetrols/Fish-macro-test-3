package com.fischvision.macro

import com.fischvision.macro.capture.Frame
import com.fischvision.macro.capture.FrameBus
import com.fischvision.macro.capture.FramePayload
import com.fischvision.macro.capture.FrameSource
import com.fischvision.macro.capture.PixelFormat
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.take
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Test implementation only — fonte sintética de frames para os testes.
 * NÃO é captura: não usa MediaProjection nem pixels reais.
 */
class FakeFrameSource(private val frameCount: Int) : FrameSource {

    var started = false
        private set
    var stopped = false
        private set

    override suspend fun start() {
        started = true
    }

    override fun frames(): Flow<Frame> = flow {
        repeat(frameCount) { seq -> emit(frame(seq.toLong())) }
    }

    override suspend fun stop() {
        stopped = true
    }

    companion object {
        fun frame(seq: Long): Frame = Frame(
            timestampNanos = seq,
            width = 960,
            height = 540,
            rotationDegrees = 0,
            pixelFormat = PixelFormat.RGBA_8888,
            payload = NoopPayload,
        )
    }
}

object NoopPayload : FramePayload {
    override fun sizeBytes(): Long = 0L
    override fun release() = Unit
}

@OptIn(ExperimentalCoroutinesApi::class)
class FrameBusTest {

    @Test
    fun `novo assinante recebe o frame mais recente`() = runTest {
        val bus = FrameBus()
        repeat(5) { assertTrue(bus.tryPublish(FakeFrameSource.frame(it.toLong()))) }

        val latest = withTimeout(1_000) { bus.frames.first() }
        assertEquals(4L, latest.timestampNanos)
    }

    @Test
    fun `barramento nunca acumula frames sem limite`() = runTest {
        val bus = FrameBus()
        repeat(10_000) { bus.tryPublish(FakeFrameSource.frame(it.toLong())) }

        // replay = 1: sem consumidor, só o último frame existe.
        assertEquals(1, bus.frames.replayCache.size)
        assertEquals(9_999L, bus.latest?.timestampNanos)
    }

    @Test
    fun `consumidor lento e conflado para o mais novo`() = runTest {
        val bus = FrameBus()
        val seen = mutableListOf<Long>()

        val job = launch {
            bus.frames.take(3).collect { frame ->
                seen += frame.timestampNanos
                delay(1_000) // consumidor deliberadamente lento
            }
        }
        runCurrent()

        repeat(3) { bus.tryPublish(FakeFrameSource.frame(it.toLong())) }
        runCurrent()
        bus.tryPublish(FakeFrameSource.frame(99L))
        advanceUntilIdle()
        job.join()

        assertEquals(3, seen.size)
        assertEquals(99L, seen.last())
        // frames intermediários foram descartados, não enfileirados.
        assertFalse(seen.contains(0L))
    }

    @Test
    fun `cancelamento do coletor encerra a entrega`() = runTest {
        val bus = FrameBus()
        var count = 0
        val job = launch { bus.frames.collect { count++ } }
        runCurrent()

        bus.tryPublish(FakeFrameSource.frame(1L))
        runCurrent()
        job.cancelAndJoin()

        bus.tryPublish(FakeFrameSource.frame(2L))
        advanceUntilIdle()

        assertEquals(1, count)
    }

    @Test
    fun `fake frame source emite sequencia programada e completa`() = runTest {
        val source = FakeFrameSource(frameCount = 3)
        source.start()

        val collected = mutableListOf<Frame>()
        source.frames().toList(collected)

        assertTrue(source.started)
        assertEquals(3, collected.size)
        assertEquals(listOf(0L, 1L, 2L), collected.map { it.timestampNanos })
    }

    @Test
    fun `fake frame source registra stop`() = runTest {
        val source = FakeFrameSource(frameCount = 1)
        source.stop()
        assertTrue(source.stopped)
        assertFalse(source.started)
    }
}
