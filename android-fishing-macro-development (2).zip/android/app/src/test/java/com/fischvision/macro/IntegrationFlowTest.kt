package com.fischvision.macro

import com.fischvision.macro.capture.Frame
import com.fischvision.macro.capture.FrameBus
import com.fischvision.macro.controller.FishingControllerImpl
import com.fischvision.macro.core.MacroState
import com.fischvision.macro.core.MacroStateMachine
import com.fischvision.macro.detector.Detection
import com.fischvision.macro.input.AccessibilityInputController
import com.fischvision.macro.input.GestureDispatcher
import com.fischvision.macro.input.InputCommand
import com.fischvision.macro.input.InputGateContext
import com.fischvision.macro.input.InputLimits
import com.fischvision.macro.service.MacroEngine
import com.fischvision.macro.tracker.EmaTargetTracker
import com.fischvision.macro.vision.VisionProcessor
import com.fischvision.macro.vision.VisionResult
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// ------------------------------------------------------------------ fakes

/** Test implementation only — visão com roteiro (não é o pipeline real). */
private class ScriptedVisionProcessor(
    private val script: List<List<Detection>>,
    private val sharedClock: ManualClock,
) : VisionProcessor {
    private var idx = 0
    override suspend fun process(frame: Frame): VisionResult {
        sharedClock.now = frame.timestampNanos // relógio compartilhado alinhado ao roteiro
        val detections = script.getOrElse(idx) { emptyList() }
        idx++
        return VisionResult(frame.timestampNanos, detections, 1L)
    }
}

private class ManualClock(var now: Long = 0L)

private class FakeDispatcher : GestureDispatcher {
    val events = mutableListOf<String>()
    override fun tap(x: Float, y: Float): Boolean = true.also { events += "tap@$x,$y" }
    override fun holdStart(x: Float, y: Float, maxDurationMillis: Long): Boolean =
        true.also { events += "holdStart($maxDurationMillis)" }
    override fun holdEnd(): Boolean = true.also { events += "holdEnd" }
}

private fun idet(type: Detection.Type, x: Float, y: Float, ts: Long, conf: Float) =
    Detection(type, x - 4f, y - 4f, x + 4f, y + 4f, conf, ts)

private fun scene(ts: Long, fishX: Float, indX: Float, conf: Float = 0.9f): List<Detection> = listOf(
    idet(Detection.Type.FISHING_BAR, 160f, 60f, ts, conf).let {
        Detection(Detection.Type.FISHING_BAR, 10f, 50f, 310f, 70f, conf, ts)
    },
    idet(Detection.Type.FISH, fishX, 60f, ts, conf),
    idet(Detection.Type.PLAYER_INDICATOR, indX, 60f, ts, conf),
)

private fun scriptFrom(build: (Int) -> List<Detection>, frames: Int): List<List<Detection>> =
    (0 until frames).map { build(it * 100_000_000L) }

@OptIn(ExperimentalCoroutinesApi::class)
class IntegrationFlowTest {

    private data class Rig(
        val engine: MacroEngine,
        val fsm: MacroStateMachine,
        val dispatcher: FakeDispatcher,
    )

    private fun rigger(
        script: List<List<Detection>>,
        frames: Int,
        scope: kotlinx.coroutines.CoroutineScope,
    ): Pair<Rig, FakeFrameSource> {
        val mc = ManualClock()
        val fsm = MacroStateMachine()
        val dispatcher = FakeDispatcher()
        val engine = MacroEngine(
            scope = scope,
            fsm = fsm,
            bus = FrameBus(),
            vision = ScriptedVisionProcessor(script, mc),
            fishTracker = EmaTargetTracker(),
            indicatorTracker = EmaTargetTracker(),
            controller = FishingControllerImpl { mc.now },
            input = AccessibilityInputController(
                dispatcher = dispatcher,
                gate = {
                    InputGateContext(
                        macroState = fsm.state,
                        trackingOk = true,
                        confidence = 0.9f,
                        frameWidth = 960,
                        frameHeight = 540,
                    )
                },
                clock = { mc.now },
            ),
            clock = { mc.now },
            resetController = {},
        )
        return Rig(engine, fsm, dispatcher) to FakeFrameSource(frames)
    }

    @Test
    fun `cadeia completa chega a CONTROLLING e engaja hold`() = runTest {
        val (rig, source) = rigger(
            scriptFrom({ ts -> scene(ts, fishX = 220f, indX = 150f) }, frames = 6),
            frames = 6,
            scope = this,
        )
        assertTrue(rig.engine.start(source))
        advanceUntilIdle()
        assertEquals(MacroState.CONTROLLING, rig.fsm.state)
        assertTrue(rig.dispatcher.events.any { it.startsWith("holdStart") })
        assertTrue(rig.engine.telemetry.framesProcessed > 0)
    }

    @Test
    fun `perda de alvos solta hold e nao emite mais comandos`() = runTest {
        val script = scriptFrom({ ts ->
            if (ts < 300_000_000L) scene(ts, fishX = 220f, indX = 150f) else emptyList()
        }, frames = 8)
        val (rig, source) = rigger(script, frames = 8, scope = this)
        rig.engine.start(source)
        advanceUntilIdle()

        assertEquals(MacroState.LOST_DETECTION, rig.fsm.state)
        assertTrue(rig.dispatcher.events.any { it == "holdEnd" })
        val holdsAfterLoss = rig.dispatcher.events.count { it.startsWith("holdStart") }
        assertEquals(1, holdsAfterLoss) // engajou uma vez antes da perda; nunca mais
        assertFalse(rig.engine.telemetry.trackingOk)
    }

    @Test
    fun `stop antes de processar nao emite nenhum comando`() = runTest {
        val (rig, source) = rigger(
            scriptFrom({ ts -> scene(ts, fishX = 220f, indX = 150f) }, frames = 6),
            frames = 6,
            scope = this,
        )
        rig.engine.start(source)
        rig.engine.stop()
        advanceUntilIdle()
        assertEquals(MacroState.STOPPED, rig.fsm.state)
        assertTrue(rig.dispatcher.events.none { it.startsWith("holdStart") })
    }

    @Test
    fun `stop libera hold em andamento (fail safe)`() = runTest {
        val (rig, source) = rigger(
            scriptFrom({ ts -> scene(ts, fishX = 220f, indX = 150f) }, frames = 6),
            frames = 6,
            scope = this,
        )
        rig.engine.start(source)
        advanceUntilIdle() // completa a coleta dos 6 frames
        rig.engine.stop()
        assertEquals(MacroState.STOPPED, rig.fsm.state)
        assertTrue(rig.dispatcher.events.contains("holdEnd"))
    }

    @Test
    fun `pause congela o processamento sem soltar estado invalido`() = runTest {
        val (rig, source) = rigger(
            scriptFrom({ ts -> scene(ts, fishX = 220f, indX = 150f) }, frames = 6),
            frames = 6,
            scope = this,
        )
        rig.engine.start(source)
        rig.engine.pause()
        advanceUntilIdle()
        assertEquals(MacroState.PAUSED, rig.fsm.state)
        assertTrue(rig.dispatcher.events.none { it.startsWith("holdStart") })
        rig.engine.resume()
        assertEquals(MacroState.WAITING_FOR_FISHING_UI, rig.fsm.state)
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class InputGatingTest {

    private class Ctx(
        var state: MacroState = MacroState.CONTROLLING,
        var trackingOk: Boolean = true,
        var conf: Float = 0.9f,
    )

    private fun controllerOf(clock: ManualClock, ctx: Ctx, dispatcher: FakeDispatcher, limits: InputLimits = InputLimits()) =
        AccessibilityInputController(
            dispatcher = dispatcher,
            gate = { InputGateContext(ctx.state, ctx.trackingOk, ctx.conf, 960, 540) },
            limits = limits,
            clock = { clock.now },
        )

    @Test
    fun `comandos bloqueados fora de CONTROLLING`() = runTest {
        val ctx = Ctx(state = MacroState.PAUSED)
        val d = FakeDispatcher()
        val c = controllerOf(ManualClock(), ctx, d)
        assertFalse(c.execute(InputCommand(InputCommand.Action.HOLD_START)))
        assertTrue(d.events.isEmpty())
    }

    @Test
    fun `comandos bloqueados com tracking perdido e confidence baixa`() = runTest {
        val d = FakeDispatcher()
        val clock = ManualClock()
        val c = controllerOf(clock, Ctx(trackingOk = false), d)
        assertFalse(c.execute(InputCommand(InputCommand.Action.HOLD_START)))
        val c2 = controllerOf(clock, Ctx(conf = 0.05f), d)
        assertFalse(c2.execute(InputCommand(InputCommand.Action.HOLD_START)))
        assertTrue(d.events.isEmpty())
    }

    @Test
    fun `limites de taxa sao aplicados`() = runTest {
        val clock = ManualClock()
        val d = FakeDispatcher()
        val c = controllerOf(clock, Ctx(), d, InputLimits(minIntervalMillis = 50, maxCommandsPerMinute = 3))
        assertTrue(c.execute(InputCommand(InputCommand.Action.HOLD_START)))
        clock.now += 60_000_000L
        assertTrue(c.execute(InputCommand(InputCommand.Action.HOLD_END)))
        clock.now += 60_000_000L
        assertTrue(c.execute(InputCommand(InputCommand.Action.TAP)))
        clock.now += 60_000_000L
        assertFalse("quarta execução dentro da janela de 1min/3 deve bloquear", c.execute(InputCommand(InputCommand.Action.TAP)))
    }

    @Test
    fun `intervalo minimo suprime comandos imediatos`() = runTest {
        val clock = ManualClock()
        val d = FakeDispatcher()
        val c = controllerOf(clock, Ctx(), d)
        assertTrue(c.execute(InputCommand(InputCommand.Action.TAP)))
        clock.now += 10_000_000L // 10ms < minInterval 50ms
        assertFalse(c.execute(InputCommand(InputCommand.Action.TAP)))
    }

    @Test
    fun `releaseAll funciona mesmo com gate fechado`() = runTest {
        val ctx = Ctx(state = MacroState.ERROR)
        val d = FakeDispatcher()
        val c = controllerOf(ManualClock(), ctx, d)
        c.releaseAll()
        assertTrue(d.events.contains("holdEnd"))
        assertFalse("ERROR bloqueia execute mas nao releaseAll", c.execute(InputCommand(InputCommand.Action.HOLD_START)))
    }
}
