package com.fischvision.macro

import com.fischvision.macro.core.MacroError
import com.fischvision.macro.core.MacroEvent
import com.fischvision.macro.core.MacroState
import com.fischvision.macro.core.MacroStateMachine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * Cobertura da máquina de estados — regras das seções 22.1 e 23 do plano.
 * A máquina é Kotlin/JVM puro: estes testes rodam sem device.
 */
class MacroStateMachineTest {

    private lateinit var machine: MacroStateMachine

    @Before
    fun setUp() {
        machine = MacroStateMachine()
    }

    // --------------------------------------------------------------- fluxo

    @Test
    fun `idle mais start leva a waiting for fishing ui`() {
        val t = machine.dispatch(MacroEvent.Start)
        assertTrue(t.accepted)
        assertEquals(MacroState.WAITING_FOR_FISHING_UI, machine.state)
    }

    @Test
    fun `cadeia principal completa ate controlling`() {
        driveToControlling()
        assertEquals(MacroState.CONTROLLING, machine.state)
    }

    @Test
    fun `pause salva origem e resume retorna ao estado anterior seguro`() {
        driveToControlling()
        machine.dispatch(MacroEvent.Pause)
        assertEquals(MacroState.PAUSED, machine.state)
        assertEquals(MacroState.CONTROLLING, machine.pausedFrom)

        val t = machine.dispatch(MacroEvent.Resume)
        assertTrue(t.accepted)
        assertEquals(MacroState.CONTROLLING, machine.state)
    }

    @Test
    fun `resume fora de paused e rejeitado`() {
        val t = machine.dispatch(MacroEvent.Resume)
        assertFalse(t.accepted)
        assertEquals(MacroState.IDLE, machine.state)
    }

    @Test
    fun `detection lost em controlling leva a lost detection e found reacquire`() {
        driveToControlling()
        machine.dispatch(MacroEvent.DetectionLost)
        assertEquals(MacroState.LOST_DETECTION, machine.state)

        machine.dispatch(MacroEvent.DetectionFound)
        assertEquals(MacroState.DETECTING, machine.state)
    }

    @Test
    fun `success e failed retornam a waiting quando a UI desaparece`() {
        driveToControlling()
        machine.dispatch(MacroEvent.FishingSuccess)
        assertEquals(MacroState.FISHING_SUCCESS, machine.state)
        machine.dispatch(MacroEvent.DetectionLost)
        assertEquals(MacroState.WAITING_FOR_FISHING_UI, machine.state)

        driveToControlling()
        machine.dispatch(MacroEvent.FishingFailed)
        assertEquals(MacroState.FISHING_FAILED, machine.state)
        machine.dispatch(MacroEvent.DetectionLost)
        assertEquals(MacroState.WAITING_FOR_FISHING_UI, machine.state)
    }

    // --------------------------------------------- segurança (seção 23)

    @Test
    fun `fatal error de qualquer estado termina em ERROR`() {
        val checkpoints: List<MacroStateMachine.() -> Unit> = listOf(
            { },                               // IDLE
            { dispatch(MacroEvent.Start) },    // WAITING
            { dispatch(MacroEvent.Start); dispatch(MacroEvent.DetectionFound) },
            { driveTo(MacroState.TRACKING) },
            { driveTo(MacroState.CONTROLLING) },
            { driveTo(MacroState.CONTROLLING); dispatch(MacroEvent.Pause) },
        )
        checkpoints.forEach { drive ->
            machine.reset()
            machine.drive()
            machine.dispatch(MacroEvent.FatalError(MacroError(MacroError.Type.UNKNOWN, "boom")))
            assertEquals(MacroState.ERROR, machine.state)
            assertNotNull(machine.lastError)
        }
    }

    @Test
    fun `apos stop nenhum evento de processamento e aceito`() {
        driveToControlling()
        machine.dispatch(MacroEvent.Stop)
        assertEquals(MacroState.STOPPED, machine.state)

        // "Nenhum processamento futuro deve produzir comando de input":
        // sem transição válida, não existe caminho de volta a CONTROLLING.
        listOf(
            MacroEvent.FrameAvailable(1L),
            MacroEvent.DetectionFound,
            MacroEvent.ControlRequested,
            MacroEvent.FishingSuccess,
            MacroEvent.Resume,
        ).forEach { event ->
            val t = machine.dispatch(event)
            assertFalse("evento $event não deveria ser aceito em STOPPED", t.accepted)
            assertEquals(MacroState.STOPPED, machine.state)
        }
    }

    @Test
    fun `stopped mais start abre sessao nova sem restaurar intermediarios`() {
        driveToControlling()
        machine.dispatch(MacroEvent.Stop)

        val t = machine.dispatch(MacroEvent.Start)
        assertTrue(t.accepted)
        assertEquals(MacroState.WAITING_FOR_FISHING_UI, machine.state)
    }

    @Test
    fun `projection stopped desarma estados de captura para IDLE`() {
        listOf(
            MacroState.WAITING_FOR_FISHING_UI,
            MacroState.DETECTING,
            MacroState.TRACKING,
            MacroState.CONTROLLING,
        ).forEach { target ->
            machine.reset()
            driveTo(target)
            machine.dispatch(MacroEvent.ProjectionStopped)
            assertEquals(
                "a partir de $target a máquina não pode continuar como se capturasse",
                MacroState.IDLE,
                machine.state,
            )
        }
    }

    @Test
    fun `projection stopped apos IDLE e rejeitado`() {
        val t = machine.dispatch(MacroEvent.ProjectionStopped)
        assertFalse(t.accepted)
        assertEquals(MacroState.IDLE, machine.state)
    }

    @Test
    fun `accessibility unavailable leva a ERROR somente em estados dependentes de input`() {
        driveTo(MacroState.CONTROLLING)
        machine.dispatch(MacroEvent.AccessibilityUnavailable)
        assertEquals(MacroState.ERROR, machine.state)
        assertEquals(MacroError.Type.ACCESSIBILITY_UNAVAILABLE, machine.lastError?.type)

        machine.reset()
        driveTo(MacroState.WAITING_FOR_FISHING_UI)
        val t = machine.dispatch(MacroEvent.AccessibilityUnavailable)
        assertTrue(t.accepted)
        assertEquals(MacroState.WAITING_FOR_FISHING_UI, machine.state)
    }

    // ---------------------------------------------------- transições inválidas

    @Test
    fun `transicoes invalidas preservam o estado`() {
        val cases = listOf(
            Triple(MacroState.IDLE, MacroEvent.DetectionFound, MacroState.IDLE),
            Triple(MacroState.IDLE, MacroEvent.ControlRequested, MacroState.IDLE),
            Triple(MacroState.WAITING_FOR_FISHING_UI, MacroEvent.ControlRequested, MacroState.WAITING_FOR_FISHING_UI),
            Triple(MacroState.WAITING_FOR_FISHING_UI, MacroEvent.FishingSuccess, MacroState.WAITING_FOR_FISHING_UI),
            Triple(MacroState.TRACKING, MacroEvent.FishingSuccess, MacroState.TRACKING),
            Triple(MacroState.DETECTING, MacroEvent.Resume, MacroState.DETECTING),
        )
        cases.forEach { (state, event, expected) ->
            machine.reset()
            driveTo(state)
            val t = machine.dispatch(event)
            assertFalse("$state + $event deveria ser rejeitado", t.accepted)
            assertEquals(expected, machine.state)
        }
    }

    @Test
    fun `historico registra aceitas e rejeitadas`() {
        machine.dispatch(MacroEvent.DetectionFound) // inválida em IDLE
        machine.dispatch(MacroEvent.Start)          // válida
        assertEquals(2, machine.history.size)
        assertFalse(machine.history[0].accepted)
        assertTrue(machine.history[1].accepted)
    }

    // ---------------------------------------------------------------- helper

    private fun driveTo(target: MacroState) {
        when (target) {
            MacroState.WAITING_FOR_FISHING_UI ->
                machine.dispatch(MacroEvent.Start)
            MacroState.DETECTING -> {
                driveTo(MacroState.WAITING_FOR_FISHING_UI)
                machine.dispatch(MacroEvent.DetectionFound)
            }
            MacroState.TRACKING -> {
                driveTo(MacroState.DETECTING)
                machine.dispatch(MacroEvent.DetectionFound)
            }
            MacroState.CONTROLLING -> {
                driveTo(MacroState.TRACKING)
                machine.dispatch(MacroEvent.ControlRequested)
            }
            else -> error("driveTo não suporta $target neste teste")
        }
        assertEquals(target, machine.state)
    }

    private fun driveToControlling() = driveTo(MacroState.CONTROLLING)
}
