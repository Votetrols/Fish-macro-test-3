package com.fischvision.macro

import com.fischvision.macro.controller.ControlCommand
import com.fischvision.macro.controller.ControlConfig
import com.fischvision.macro.controller.FishingControllerImpl
import com.fischvision.macro.detector.Detection
import com.fischvision.macro.tracker.EmaTargetTracker
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private fun det(x: Float, y: Float, ts: Long, conf: Float = 0.9f, type: Detection.Type = Detection.Type.FISH) =
    Detection(type, x - 4f, y - 4f, x + 4f, y + 4f, conf, ts)

private const val S = 1_000_000_000L

class TrackerTest {

    @Test
    fun `primeira deteccao nao gera resultado (acquiring) e segunda gera`() {
        val t = EmaTargetTracker()
        assertNull(t.update(det(100f, 50f, 0L)))
        assertEquals(EmaTargetTracker.TrackingState.ACQUIRING, t.state)
        assertNotNull(t.update(det(102f, 50f, 100_000_000L)))
        assertEquals(EmaTargetTracker.TrackingState.TRACKING, t.state)
    }

    @Test
    fun `ema suaviza ruido em torno do alvo estavel`() {
        val t = EmaTargetTracker()
        var ts = 0L
        val jitter = listOf(100f, 104f, 97f, 103f, 99f, 101f)
        var last = 0f
        jitter.forEach { x ->
            ts += 50_000_000L
            last = t.update(det(x, 50f, ts))?.centerX ?: last
        }
        assertTrue("suavizado deve ficar próximo de 100, obteve $last", kotlin.math.abs(last - 100f) < 3.5f)
    }

    @Test
    fun `velocidade e estimada em px por segundo na direcao do movimento`() {
        val t = EmaTargetTracker()
        t.update(det(0f, 0f, 0L))
        var r = t.update(det(10f, 0f, 100_000_000L)) // 100 px/s
        r = t.update(det(20f, 0f, 200_000_000L))
        r = t.update(det(30f, 0f, 300_000_000L))
        assertNotNull(r)
        assertTrue("velocityX deveria ser positiva", r!!.velocityXPxPerSec > 0f)
        assertTrue("velocityX deveria estar na ordem de 100px/s", r.velocityXPxPerSec > 40f && r.velocityXPxPerSec < 160f)
    }

    @Test
    fun `associacao escolhe o candidato mais proximo (multi objeto)`() {
        val t = EmaTargetTracker()
        t.update(det(100f, 50f, 0L))
        t.update(det(104f, 50f, 100_000_000L))
        val candidates = listOf(
            det(108f, 50f, 200_000_000L), // próximo
            det(170f, 50f, 200_000_000L), // isca distante
        )
        val chosen = t.associate(candidates)
        assertNotNull(chosen)
        assertEquals(108f, chosen!!.centerX, 0.5f)
    }

    @Test
    fun `teleporte alem do salto maximo e rejeitado`() {
        val t = EmaTargetTracker(maxAssociationDistancePx = 50f)
        t.update(det(100f, 50f, 0L))
        t.update(det(102f, 50f, 100_000_000L))
        val chosen = t.associate(listOf(det(300f, 50f, 200_000_000L)))
        assertNull(chosen)
    }

    @Test
    fun `timestamps fora de ordem e duplicados sao rejeitados`() {
        val t = EmaTargetTracker()
        t.update(det(100f, 50f, 1_000L))
        assertNull(t.update(det(110f, 50f, 500L)))   // fora de ordem
        assertNull(t.update(det(120f, 50f, 1_000L)))  // duplicado
        assertNotNull(t.update(det(130f, 50f, 2_000L)))
    }

    @Test
    fun `perda prolongada marca lost e temporaria nao`() {
        val t = EmaTargetTracker(lostTimeoutNanos = 300_000_000L)
        t.update(det(100f, 50f, 0L))
        t.update(det(102f, 50f, 100_000_000L))
        assertFalse(t.isLost(350_000_000L))
        assertTrue(t.isLost(400_000_001L))
        t.onMissedFrame(); t.onMissedFrame()
        assertEquals(2, t.missedFrames)
    }

    @Test
    fun `reset limpa todo o historico`() {
        val t = EmaTargetTracker()
        t.update(det(100f, 50f, 0L))
        t.reset()
        assertEquals(EmaTargetTracker.TrackingState.IDLE, t.state)
        assertEquals(0, t.missedFrames)
    }
}

class ControllerTest {

    private class ManualClock(var now: Long = 0L)

    private fun controllerWith(clock: ManualClock, config: ControlConfig = ControlConfig()) =
        FishingControllerImpl(config) { clock.now }

    @Test
    fun `dentro da zona morta nao acontece nada`() {
        val c = controllerWith(ManualClock())
        val cmd = c.update(102f, 100f, 0.9f, 100_000_000L)
        assertEquals(ControlCommand.Type.NONE, cmd.type)
        assertFalse(c.isHolding)
    }

    @Test
    fun `erro acima da zona morta inicia PRESS com teto de duracao`() {
        val c = controllerWith(ManualClock())
        val cmd = c.update(150f, 100f, 0.9f, 100_000_000L)
        assertEquals(ControlCommand.Type.PRESS, cmd.type)
        assertTrue(cmd.maxDurationMillis > 0)
        assertTrue(c.isHolding)
    }

    @Test
    fun `segurando mantem HOLD ate o erro ser eliminado`() {
        val clock = ManualClock()
        val c = controllerWith(clock)
        c.update(150f, 100f, 0.9f, 100_000_000L)           // PRESS
        clock.now += 70_000_000L                            // 70ms (> minHold 60ms)
        val hold = c.update(148f, 120f, 0.9f, 70_000_000L)
        assertEquals(ControlCommand.Type.HOLD, hold.type)
        clock.now += 30_000_000L
        val release = c.update(102f, 100f, 0.9f, 30_000_000L) // erro 2px < exitDz
        assertEquals(ControlCommand.Type.RELEASE, release.type)
        assertFalse(c.isHolding)
    }

    @Test
    fun `erro eliminado antes do minHold nao solta (anti chatter)`() {
        val clock = ManualClock()
        val c = controllerWith(clock)
        c.update(150f, 100f, 0.9f, 100_000_000L)
        clock.now += 20_000_000L                             // 20ms < minHold(60)
        val cmd = c.update(101f, 100f, 0.9f, 20_000_000L)
        assertEquals(ControlCommand.Type.HOLD, cmd.type)
        assertTrue(cmd.reason.contains("minHold"))
        assertTrue(c.isHolding)
    }

    @Test
    fun `maxHold forca release (seguranca)`() {
        val clock = ManualClock()
        val c = controllerWith(clock)
        c.update(150f, 100f, 0.9f, 100_000_000L)
        clock.now += 1_000_000_000L // 1s > maxHold 900ms
        val cmd = c.update(150f, 100f, 0.9f, 1_000_000_000L)
        assertEquals(ControlCommand.Type.RELEASE, cmd.type)
        assertTrue(cmd.reason.contains("maxHold"))
    }

    @Test
    fun `confidence baixa durante hold solta imediatamente`() {
        val clock = ManualClock()
        val c = controllerWith(clock)
        c.update(150f, 100f, 0.9f, 100_000_000L)
        clock.now += 50_000_000L
        val cmd = c.update(150f, 100f, 0.1f, 50_000_000L)
        assertEquals(ControlCommand.Type.RELEASE, cmd.type)
    }

    @Test
    fun `alvos nulos durante hold soltam (fail safe)`() {
        val clock = ManualClock()
        val c = controllerWith(clock)
        c.update(150f, 100f, 0.9f, 100_000_000L)
        val cmd = c.update(null, 100f, 0.9f, 50_000_000L)
        assertEquals(ControlCommand.Type.RELEASE, cmd.type)
    }

    @Test
    fun `dt invalido nao muda estado nem comanda`() {
        val c = controllerWith(ManualClock())
        assertEquals(ControlCommand.Type.NONE, c.update(150f, 100f, 0.9f, 0L).type)
        assertEquals(ControlCommand.Type.NONE, c.update(150f, 100f, 0.9f, -1L).type)
        assertFalse(c.isHolding)
    }

    @Test
    fun `min release barra re engajamento imediato`() {
        val clock = ManualClock()
        val c = controllerWith(clock)
        c.update(150f, 100f, 0.9f, 100_000_000L)              // PRESS @0
        clock.now += 1_000_000_000L
        c.update(150f, 100f, 0.9f, 1_000_000_000L)            // RELEASE @1s (maxHold)
        clock.now += 20_000_000L                                // +20ms < minRelease(60ms)
        val cmd = c.update(160f, 100f, 0.9f, 20_000_000L)
        assertEquals(ControlCommand.Type.NONE, cmd.type)
        assertFalse(c.isHolding)
    }

    @Test
    fun `config invalida e rejeitada`() {
        try {
            ControlConfig(deadZonePx = 0f)
            error("deadZone 0 deveria falhar")
        } catch (_: IllegalArgumentException) {
            // esperado
        }
    }
}
