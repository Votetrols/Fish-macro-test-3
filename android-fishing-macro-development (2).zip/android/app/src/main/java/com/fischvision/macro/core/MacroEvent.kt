package com.fischvision.macro.core

/**
 * Eventos mínimos da máquina de estados (conjunto fechado — sealed).
 *
 * Observação de design da Fase 1: [FrameAvailable] transporta apenas o
 * timestamp do frame. O roteamento real de pixels chega na Fase 2 com o
 * FrameBus alimentado pela captura; hoje o evento é aceito apenas nos estados
 * em que a captura ESTARIA ativa (ack preservador de estado) e rejeitado nos
 * demais — comportamento verificável, não simulação de captura.
 */
sealed interface MacroEvent {

    data object Start : MacroEvent
    data object Pause : MacroEvent
    data object Resume : MacroEvent
    data object Stop : MacroEvent

    /** Ack de frame disponível. Payload chega via FrameBus na Fase 2. */
    data class FrameAvailable(val frameTimestampNanos: Long) : MacroEvent

    /** UI de pesca detectada / alvos confirmados (semântica depende do estado). */
    data object DetectionFound : MacroEvent
    data object DetectionLost : MacroEvent

    /** Controlador habilitado para atuar sobre o indicador. */
    data object ControlRequested : MacroEvent

    data object FishingSuccess : MacroEvent
    data object FishingFailed : MacroEvent

    /** Falha crítica sempre acompanhada de um [MacroError]. */
    data class FatalError(val error: MacroError) : MacroEvent

    /** MediaProjection encerrada/revogada — captura não está mais ativa. */
    data object ProjectionStopped : MacroEvent

    /** Camada de input indisponível (serviço de acessibilidade desligado). */
    data object AccessibilityUnavailable : MacroEvent
}
