package com.fischvision.macro.overlay

/**
 * Estado exibido pelo HUD/overlay (Fase 11).
 */
data class OverlayState(
    val macroEnabled: Boolean,
    val stateName: String,
    val fps: Double,
    val confidence: Float,
)

/**
 * Fronteira do overlay/HUD (WindowManager na Fase 11).
 *
 * Fase 1: CONTRATO apenas.
 *  - NÃO solicita SYSTEM_ALERT_WINDOW (permissão deliberadamente ausente do
 *    manifest desta fase);
 *  - NÃO existe overlay falso;
 *  - implementação real só chega com a Fase 11, e nunca pode bloquear o
 *    botão de parada (regra de segurança da arquitetura).
 *
 * @status CONTRACT_ONLY
 */
interface OverlayManager {
    val isShowing: Boolean

    fun show()
    fun hide()
    fun update(state: OverlayState)
}
