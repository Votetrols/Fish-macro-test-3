package com.fischvision.macro.tracker

import com.fischvision.macro.detector.Detection
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Rastreador real — Fase 4.
 *
 * Algoritmo:
 *  - smoothing: EMA de posição (alphaPosition) — custo O(1), zero alocação;
 *  - velocidade: derivada (Δ/Δt) suavizada por EMA própria (alphaVelocity);
 *  - associação multi-objeto: candidato mais próximo da posição suavizada
 *    atual, limitado por [maxAssociationDistancePx] — saltos maiores são
 *    rejeitados como falso alvo (anti-teleporte);
 *  - robustez temporal: amostras com timestamp fora de ordem/duplicado são
 *    rejeitadas sem corromper o estado;
 *  - perda: [onMissedFrame] contabiliza falhas; [isLost] marca perda após
 *    [lostTimeoutNanos] sem amostra válida.
 *
 * Não produz comando algum — e a Fase 4 proíbe comando durante perda:
 * o macro só pode comandar com um TrackingResult fresco.
 *
 * @status IMPLEMENTED / testes JVM escritos (execução local pendente)
 */
class EmaTargetTracker(
    private val alphaPosition: Float = 0.35f,
    private val alphaVelocity: Float = 0.25f,
    private val maxAssociationDistancePx: Float = 180f,
    private val lostTimeoutNanos: Long = 300_000_000L,
) : Tracker {

    enum class TrackingState { IDLE, ACQUIRING, TRACKING, LOST }

    private var hasPosition = false
    private var smoothedX = 0f
    private var smoothedY = 0f
    private var rawX = 0f
    private var rawY = 0f
    private var velX = 0f
    private var velY = 0f
    private var lastTimestampNanos = 0L
    private var samples = 0
    private var lastConfidence = 0f

    var missedFrames = 0
        private set

    val state: TrackingState
        get() = when {
            !hasPosition -> TrackingState.IDLE
            samples < 2 -> TrackingState.ACQUIRING
            else -> TrackingState.TRACKING
        }

    /**
     * Seleciona o melhor candidato para ESTE alvo. Regra: maior confidence se
     * ainda não há posição; senão, o mais próximo dentro do salto máximo.
     */
    fun associate(candidates: List<Detection>): Detection? {
        if (candidates.isEmpty()) return null
        if (!hasPosition) return candidates.maxByOrNull { it.confidence }
        val nearest = candidates.minByOrNull { cand ->
            val dx = cand.centerX - smoothedX
            val dy = cand.centerY - smoothedY
            dx * dx + dy * dy
        } ?: return null
        val dx = nearest.centerX - smoothedX
        val dy = nearest.centerY - smoothedY
        return if (sqrt(dx * dx + dy * dy) <= maxAssociationDistancePx) nearest else null
    }

    override fun update(detection: Detection): TrackingResult? {
        if (!hasPosition) {
            smoothedX = detection.centerX
            smoothedY = detection.centerY
            rawX = detection.centerX
            rawY = detection.centerY
            lastTimestampNanos = detection.timestampNanos
            lastConfidence = detection.confidence
            hasPosition = true
            samples = 1
            missedFrames = 0
            return null // ACQUIRING: ainda não há velocidade confiável
        }

        val dt = detection.timestampNanos - lastTimestampNanos
        if (dt <= 0L) {
            // timestamps fora de ordem/duplicados: amostra rejeitada, estado intacto
            return null
        }

        val dtSec = dt / 1_000_000_000f
        val instVelX = (detection.centerX - rawX) / dtSec
        val instVelY = (detection.centerY - rawY) / dtSec

        velX = alphaVelocity * instVelX + (1f - alphaVelocity) * velX
        velY = alphaVelocity * instVelY + (1f - alphaVelocity) * velY

        smoothedX = alphaPosition * detection.centerX + (1f - alphaPosition) * smoothedX
        smoothedY = alphaPosition * detection.centerY + (1f - alphaPosition) * smoothedY

        rawX = detection.centerX
        rawY = detection.centerY
        lastTimestampNanos = detection.timestampNanos
        lastConfidence = detection.confidence
        samples++
        missedFrames = 0

        return current(detection.timestampNanos)
    }

    /** Sem detecção neste frame: contabilizado para o timeout de perda. */
    fun onMissedFrame() {
        missedFrames++
    }

    fun isLost(nowNanos: Long): Boolean =
        hasPosition && nowNanos - lastTimestampNanos > lostTimeoutNanos

    /** Posição prevista simples: x̂ + v·lead, com lead limitado (anti-overshoot). */
    fun predictedX(leadNanos: Long): Float {
        val capped = leadNanos.coerceAtMost(120_000_000L)
        return smoothedX + velX * (capped / 1_000_000_000f)
    }

    fun current(timestampNanos: Long): TrackingResult = TrackingResult(
        centerX = smoothedX,
        centerY = smoothedY,
        velocityXPxPerSec = velX,
        velocityYPxPerSec = velY,
        confidence = lastConfidence,
        timestampNanos = timestampNanos,
    )

    override fun reset() {
        hasPosition = false
        velX = 0f
        velY = 0f
        samples = 0
        missedFrames = 0
        lastConfidence = 0f
    }
}
