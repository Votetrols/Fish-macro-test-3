package com.fischvision.macro.core

/**
 * Estados do macro — exatamente os definidos na arquitetura aprovada (Fase 0).
 *
 * @status IMPLEMENTED (enum completo; a lógica de transição vive em
 * [MacroStateMachine] e é coberta por MacroStateMachineTest).
 */
enum class MacroState {
    IDLE,
    WAITING_FOR_FISHING_UI,
    DETECTING,
    TRACKING,
    CONTROLLING,
    LOST_DETECTION,
    FISHING_FAILED,
    FISHING_SUCCESS,
    PAUSED,
    STOPPED,
    ERROR,
}
