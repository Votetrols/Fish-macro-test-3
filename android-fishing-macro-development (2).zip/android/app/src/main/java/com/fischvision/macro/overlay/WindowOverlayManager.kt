package com.fischvision.macro.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.fischvision.macro.debug.DebugLogger

/**
 * Overlay real via WindowManager — Fase 6.
 *
 * Regras reais respeitadas:
 *  - exige SYSTEM_ALERT_WINDOW concedida (Settings.canDrawOverlays) — sem ela,
 *    show() retorna false com log, NUNCA lança nem mostra nada;
 *  - TYPE_APPLICATION_OVERLAY (tipo correto p/ API 26+);
 *  - show/hide/update idempotentes; hide libera a view;
 *  - HUD pequeno no topo: não cobre área de decisão nem impede parar o macro
 *    (botão de parada do jogo/overlay externo permanece acessível);
 *  - callbacks de controle NÃO vivem aqui: Start/Pause/Resume/Stop são
 *    encaminhados ao [ControlCallbacks] injetado (overlay obedece ao pipeline,
 *    nunca o contrário — regra da Fase 6).
 */
class WindowOverlayManager(
    private val appContext: Context,
    private val controls: ControlCallbacks? = null,
) : OverlayManager {

    interface ControlCallbacks {
        fun onStart()
        fun onPause()
        fun onResume()
        fun onStop()
    }

    private var windowManager: WindowManager? = null
    private var view: LinearLayout? = null
    private var lines: Array<TextView>? = null

    override val isShowing: Boolean get() = view != null

    override fun show() {
        if (view != null) return
        if (!Settings.canDrawOverlays(appContext)) {
            DebugLogger.w(DebugLogger.Category.SERVICE, "overlay recusado: SYSTEM_ALERT_WINDOW não concedida")
            return
        }
        val wm = appContext.getSystemService(WindowManager::class.java) ?: run {
            DebugLogger.e(DebugLogger.Category.SERVICE, "WindowManager indisponível")
            return
        }
        windowManager = wm

        val container = LinearLayout(appContext).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xB304070E.toInt())
            setPadding(18, 12, 18, 12)
        }
        val labels = Array(LINE_COUNT) { i ->
            TextView(appContext).apply {
                textSize = 10f
                typeface = Typeface.MONOSPACE
                setTextColor(if (i == 0) 0xFF22D3EE.toInt() else 0xFFE2E8F0.toInt())
            }.also { container.addView(it) }
        }
        lines = labels

        // controles de segurança: SEMPRE acessíveis e delegados ao pipeline
        controls?.let { cb ->
            val row = LinearLayout(appContext)
            listOf(
                "▶" to { cb.onStart() },
                "⏸" to { cb.onPause() },
                "↻" to { cb.onResume() },
                "■" to { cb.onStop() },
            ).forEach { (label, action) ->
                row.addView(
                    android.widget.Button(appContext).apply {
                        text = label
                        textSize = 12f
                        setOnClickListener { action() }
                    },
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f),
                )
            }
            container.addView(row)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // SEM FLAG_NOT_FOCUSABLE: os botões de parada precisam receber toque.
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16
            y = 16
        }

        try {
            wm.addView(container, params)
            view = container
        } catch (e: Exception) {
            DebugLogger.e(DebugLogger.Category.SERVICE, "addView do overlay falhou", e)
            view = null
        }
    }

    override fun hide() {
        val v = view ?: return
        try {
            windowManager?.removeView(v)
        } catch (e: Exception) {
            DebugLogger.w(DebugLogger.Category.SERVICE, "removeView do overlay falhou", e)
        }
        view = null
        windowManager = null
    }

    override fun update(state: OverlayState) {
        val l = lines ?: return
        l[0].text = if (state.macroEnabled) "MACRO: ON" else "MACRO: OFF"
        l[1].text = "ESTADO: ${state.stateName}"
        l[2].text = "FPS: %.1f  CONF: %.2f".format(state.fps, state.confidence)
    }

    fun destroy() = hide()

    private companion object {
        const val LINE_COUNT = 3
    }
}
