package com.fischvision.macro.core

/**
 * Resultado de uma tentativa de transição. Sempre retornado por
 * [MacroStateMachine.dispatch] — a máquina nunca lança exceção para eventos
 * inválidos: ela os rejeita de forma registrável e mantém o estado atual.
 */
data class Transition(
    val from: MacroState,
    val event: MacroEvent,
    val to: MacroState,
    val accepted: Boolean,
    val note: String = "",
)

/**
 * Máquina de estados determinística do macro.
 *
 * Regras duras (também cobertas por MacroStateMachineTest):
 *  - IDLE + Start              -> WAITING_FOR_FISHING_UI
 *  - PAUSED + Resume           -> estado anterior seguro (registrado no Pause)
 *  - QUALQUER + FatalError     -> ERROR   (lastError sempre preenchido)
 *  - QUALQUER + Stop           -> STOPPED (exceto STOPPED, que é idempotente-inválido)
 *  - STOPPED nunca retorna a estados intermediários da sessão anterior;
 *    STOPPED + Start abre sessão NOVA em WAITING_FOR_FISHING_UI.
 *  - ProjectionStopped desarma a captura: estados de captura -> IDLE.
 *  - AccessibilityUnavailable em estados que dependem de input -> ERROR;
 *    nos demais, o estado é preservado (serviço pode voltar depois).
 *
 * Puro Kotlin/JVM: sem dependência de Android para rodar sob testes unitários.
 *
 * @status IMPLEMENTED + UNIT TEST
 */
class MacroStateMachine(initialState: MacroState = MacroState.IDLE) {

    var state: MacroState = initialState
        private set

    /** Estado salvo quando entramos em PAUSED (alvo seguro do Resume). */
    var pausedFrom: MacroState? = null
        private set

    var lastError: MacroError? = null
        private set

    private val _history = ArrayDeque<Transition>()
    val history: List<Transition> get() = _history.toList()

    fun dispatch(event: MacroEvent): Transition {
        val from = state
        val transition = reduce(from, event)

        if (transition.accepted) {
            when (event) {
                is MacroEvent.Pause -> if (transition.to == MacroState.PAUSED) pausedFrom = from
                is MacroEvent.Resume -> pausedFrom = null
                is MacroEvent.FatalError ->
                    lastError = event.error.copy(atState = from)
                is MacroEvent.AccessibilityUnavailable ->
                    if (transition.to == MacroState.ERROR) lastError = MacroError(
                        type = MacroError.Type.ACCESSIBILITY_UNAVAILABLE,
                        message = "Serviço de acessibilidade indisponível durante estado dependente de input.",
                        atState = from,
                    )
                else -> Unit
            }
            state = transition.to
        }

        _history.addLast(transition)
        while (_history.size > HISTORY_LIMIT) _history.removeFirst()
        return transition
    }

    /** Retorna a máquina ao estado inicial. Uso: testes e reset explícito. */
    fun reset() {
        state = MacroState.IDLE
        pausedFrom = null
        lastError = null
    }

    private fun reduce(from: MacroState, event: MacroEvent): Transition = when (event) {

        MacroEvent.Start -> when (from) {
            MacroState.IDLE, MacroState.STOPPED, MacroState.ERROR ->
                accept(from, event, MacroState.WAITING_FOR_FISHING_UI,
                    "nova sessão; STOPPED/ERROR jamais restauram estados intermediários")
            else -> reject(from, event)
        }

        MacroEvent.Pause -> when (from) {
            MacroState.WAITING_FOR_FISHING_UI, MacroState.DETECTING,
            MacroState.TRACKING, MacroState.CONTROLLING, MacroState.LOST_DETECTION ->
                accept(from, event, MacroState.PAUSED, "origem salva para Resume")
            else -> reject(from, event)
        }

        MacroEvent.Resume ->
            if (from == MacroState.PAUSED)
                accept(from, event, pausedFrom ?: MacroState.WAITING_FOR_FISHING_UI,
                    "retorna ao estado anterior seguro")
            else reject(from, event)

        MacroEvent.Stop ->
            if (from == MacroState.STOPPED) reject(from, event, "já está em STOPPED")
            else accept(from, event, MacroState.STOPPED)

        is MacroEvent.FatalError ->
            accept(from, event, MacroState.ERROR, "qualquer estado -> ERROR")

        is MacroEvent.FrameAvailable -> when (from) {
            MacroState.WAITING_FOR_FISHING_UI, MacroState.DETECTING,
            MacroState.TRACKING, MacroState.CONTROLLING ->
                accept(from, event, from,
                    "ack preservador de estado; roteamento de pixels chega na Fase 2")
            else -> reject(from, event, "captura inativa neste estado")
        }

        MacroEvent.DetectionFound -> when (from) {
            MacroState.WAITING_FOR_FISHING_UI ->
                accept(from, event, MacroState.DETECTING, "UI candidata localizada")
            MacroState.DETECTING ->
                accept(from, event, MacroState.TRACKING, "barra+peixe+indicador confirmados")
            MacroState.LOST_DETECTION ->
                accept(from, event, MacroState.DETECTING, "reacquire dentro da janela")
            else -> reject(from, event)
        }

        MacroEvent.DetectionLost -> when (from) {
            MacroState.CONTROLLING, MacroState.TRACKING ->
                accept(from, event, MacroState.LOST_DETECTION, "confidence abaixo do limiar")
            MacroState.FISHING_SUCCESS, MacroState.FISHING_FAILED ->
                accept(from, event, MacroState.WAITING_FOR_FISHING_UI,
                    "rodada encerrada; aguarda próxima UI de pesca")
            else -> reject(from, event)
        }

        MacroEvent.ControlRequested -> when (from) {
            MacroState.TRACKING ->
                accept(from, event, MacroState.CONTROLLING, "confidence >= threshold")
            MacroState.CONTROLLING ->
                accept(from, event, MacroState.CONTROLLING, "reconfirmação de controle")
            else -> reject(from, event)
        }

        MacroEvent.FishingSuccess ->
            if (from == MacroState.CONTROLLING)
                accept(from, event, MacroState.FISHING_SUCCESS, "progresso completado")
            else reject(from, event)

        MacroEvent.FishingFailed ->
            if (from == MacroState.CONTROLLING)
                accept(from, event, MacroState.FISHING_FAILED, "progresso esvaziado")
            else reject(from, event)

        MacroEvent.ProjectionStopped -> when (from) {
            MacroState.WAITING_FOR_FISHING_UI, MacroState.DETECTING, MacroState.TRACKING,
            MacroState.CONTROLLING, MacroState.LOST_DETECTION, MacroState.PAUSED ->
                accept(from, event, MacroState.IDLE,
                    "captura não está ativa; macro desarma em vez de fingir captura")
            else -> reject(from, event)
        }

        MacroEvent.AccessibilityUnavailable -> when (from) {
            MacroState.TRACKING, MacroState.CONTROLLING, MacroState.LOST_DETECTION ->
                accept(from, event, MacroState.ERROR,
                    "estado dependente de input sem camada de input")
            else ->
                accept(from, event, from,
                    "fora dos estados de input; estado preservado, pode recuperar depois")
        }
    }

    private fun accept(from: MacroState, event: MacroEvent, to: MacroState, note: String = "") =
        Transition(from, event, to, accepted = true, note = note)

    private fun reject(from: MacroState, event: MacroEvent, note: String = "transição inválida") =
        Transition(from, event, to = from, accepted = false, note = note)

    private companion object {
        const val HISTORY_LIMIT = 64
    }
}
