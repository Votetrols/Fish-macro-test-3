package com.fischvision.macro.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.fischvision.macro.debug.DebugLogger

/**
 * Serviço de acessibilidade — Fase 5: FUNCIONAL (gestos reais).
 *
 * Decisões técnicas reais (sem APIs inventadas):
 *  - `dispatchGesture` NÃO possui API de cancelamento. Um "hold" longo em um
 *    único stroke não pode ser solto sob demanda — por isso o hold usa a
 *    CADEIA documentada: strokes curtos (SEGMENT_MS) com willContinue=true,
 *    continuados a cada callback enquanto o hold estiver ativo, e encerrados
 *    com um stroke final willContinue=false. Latência máxima de soltura =
 *    SEGMENT_MS (documentada no PHASE_5_STATUS).
 *  - Limites do framework respeitados: gesto ≤ MAX_GESTURE_MS por descrição
 *    (margem de segurança abaixo dos 60s teóricos) e callbacks tratados.
 *  - O pacote em foreground é rastreado via TYPE_WINDOW_STATE_CHANGED
 *    (sem permissão extra) para que a camada de input verifique onde o toque cai.
 *
 * @status IMPLEMENTED / gestos NÃO TESTADOS EM DEVICE (BLOCKED env)
 */
class MacroAccessibilityService : AccessibilityService() {

    companion object {
        private const val SEGMENT_MS = 120L
        private const val MAX_GESTURE_MS = 55_000L
        private const val TAP_CLAMP_MIN_MS = 10L

        @Volatile
        private var activeInstance: MacroAccessibilityService? = null

        val isConnected: Boolean get() = activeInstance != null

        /** Ponto de entrada da camada de input (Fase 5/6). */
        fun dispatch(request: GestureRequest): Boolean =
            activeInstance?.performRequest(request) ?: false

        /** Fail-safe artesanal: encerra qualquer hold encadeado. */
        fun releaseAll(): Boolean = activeInstance?.endHold() ?: false

        /** Pacote atualmente em foreground, se conhecido (null = desconhecido). */
        val foregroundPackage: CharSequence? get() = activeInstance?.lastForegroundPackage
    }

    sealed interface GestureRequest {
        data class Tap(val x: Float, val y: Float, val durationMillis: Long = 50L) : GestureRequest
        data class HoldStart(val x: Float, val y: Float, val maxDurationMillis: Long) : GestureRequest
        data object HoldEnd : GestureRequest
    }

    @Volatile
    private var holdActive = false

    @Volatile
    private var holdDeadlineNanos = 0L

    @Volatile
    private var holdX = 0f

    @Volatile
    private var holdY = 0f

    @Volatile
    private var lastForegroundPackage: CharSequence? = null

    // ----------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeInstance = this
        DebugLogger.i(DebugLogger.Category.SERVICE, "MacroAccessibilityService conectado (Fase 5: gestos habilitados)")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Não automatizamos por eventos; apenas rastreamos foreground (janela ativa).
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            lastForegroundPackage = event.packageName
        }
    }

    override fun onInterrupt() {
        holdActive = false
        DebugLogger.w(DebugLogger.Category.INPUT, "onInterrupt — hold cancelado")
    }

    override fun onDestroy() {
        holdActive = false
        if (activeInstance === this) activeInstance = null
        DebugLogger.i(DebugLogger.Category.SERVICE, "MacroAccessibilityService.onDestroy")
        super.onDestroy()
    }

    // ------------------------------------------------------------- gestos

    private fun performRequest(request: GestureRequest): Boolean = when (request) {
        is GestureRequest.Tap -> {
            val duration = request.durationMillis.coerceIn(TAP_CLAMP_MIN_MS, MAX_GESTURE_MS)
            dispatchStroke(request.x, request.y, duration, willContinue = false) { }
        }
        is GestureRequest.HoldStart -> {
            holdX = request.x
            holdY = request.y
            holdDeadlineNanos = System.nanoTime() + request.maxDurationMillis.coerceIn(1L, MAX_GESTURE_MS) * 1_000_000L
            holdActive = true
            dispatchStroke(request.x, request.y, SEGMENT_MS, willContinue = true) { completed ->
                if (completed) continueHoldChain() else holdActive = false
            }
        }
        GestureRequest.HoldEnd -> endHold()
    }

    private fun continueHoldChain() {
        if (!holdActive) return
        if (System.nanoTime() >= holdDeadlineNanos) {
            // deadline atingido: encerra a cadeia com stroke final (willContinue=false)
            holdActive = false
            dispatchStroke(holdX, holdY, TAP_CLAMP_MIN_MS, willContinue = false) { }
            return
        }
        dispatchStroke(holdX, holdY, SEGMENT_MS, willContinue = true) { completed ->
            if (completed) continueHoldChain() else holdActive = false
        }
    }

    private fun endHold(): Boolean {
        if (!holdActive) return true // nada a liberar — fail-safe idempotente
        holdActive = false
        return dispatchStroke(holdX, holdY, TAP_CLAMP_MIN_MS, willContinue = false) { }
    }

    private fun dispatchStroke(
        x: Float,
        y: Float,
        durationMillis: Long,
        willContinue: Boolean,
        onResult: (completed: Boolean) -> Unit,
    ): Boolean {
        val path = Path().apply {
            moveTo(x, y)
            lineTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMillis, willContinue)
        val description = GestureDescription.Builder().addStroke(stroke).build()
        return try {
            dispatchGesture(
                description,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        onResult(true)
                    }
                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        DebugLogger.w(DebugLogger.Category.INPUT, "gesto cancelado pelo sistema")
                        onResult(false)
                    }
                },
                null, // callbacks na thread principal (documentado)
            )
        } catch (e: SecurityException) {
            DebugLogger.e(DebugLogger.Category.INPUT, "dispatchGesture sem permissão (serviço desligado?)", e)
            false
        } catch (e: IllegalStateException) {
            DebugLogger.e(DebugLogger.Category.INPUT, "dispatchGesture em estado ilegal", e)
            false
        }
    }
}
