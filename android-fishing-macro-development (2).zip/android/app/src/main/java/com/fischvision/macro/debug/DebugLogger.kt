package com.fischvision.macro.debug

import android.util.Log

/**
 * Logger real sobre android.util.Log (Logcat), com categorias fixas.
 *
 * Regras:
 *  - sem dados sensíveis (nunca logar payloads de frame, coordenadas
 *    pessoais fora do contexto de debug, ou conteúdo de intents);
 *  - DebugLogger.d/v servem a diagnóstico; em release futuro, minLevel sobe;
 *  - buffer em anel + exportação de sessão chegam na Fase 12/20 (logging/).
 */
object DebugLogger {

    enum class Category(val label: String) {
        STATE("STATE"),
        CAPTURE("CAPTURE"),
        VISION("VISION"),
        DETECTOR("DETECTOR"),
        TRACKER("TRACKER"),
        CONTROLLER("CONTROLLER"),
        INPUT("INPUT"),
        SERVICE("SERVICE"),
        ERROR("ERROR"),
    }

    private const val PREFIX = "FVM"

    /** Piso de severidade emitida. DEBUG em builds de desenvolvimento. */
    @Volatile
    var minLevel: Int = Log.DEBUG

    fun v(category: Category, message: String) {
        if (Log.VERBOSE >= minLevel) Log.v(tagOf(category), message)
    }

    fun d(category: Category, message: String) {
        if (Log.DEBUG >= minLevel) Log.d(tagOf(category), message)
    }

    fun i(category: Category, message: String) {
        if (Log.INFO >= minLevel) Log.i(tagOf(category), message)
    }

    fun w(category: Category, message: String, throwable: Throwable? = null) {
        if (Log.WARN >= minLevel) Log.w(tagOf(category), message, throwable)
    }

    fun e(category: Category, message: String, throwable: Throwable? = null) {
        // Erros sempre são emitidos, independentemente do minLevel.
        Log.e(tagOf(category), message, throwable)
    }

    private fun tagOf(category: Category): String = "$PREFIX/${category.label}"
}
