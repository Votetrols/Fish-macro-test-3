package com.fischvision.macro.capture

import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * Barramento de frames com conflação estrita — "latest wins".
 *
 * POLÍTICA DE BUFFER (regra 9 da Fase 1), definida e testável em FrameBusTest:
 *  - replay = 1 ............ um novo assinante recebe imediatamente o frame mais
 *                            recente (o motor nunca precisa esperar o próximo);
 *  - extraBufferCapacity = 1 pequena margem para um consumidor em andamento;
 *  - onBufferOverflow = DROP_OLDEST — capacidade total é 2 frames, SEMPRE.
 *    Consumidor lento pula frames intermediários em vez de acumular: é a
 *    propriedade que impede fila crescente e latência de processamento velho.
 *
 * LIFECYCLE/CANCELLATION:
 *  - SharedFlow não tem "close": o ciclo de vida é o do escopo que coleta
 *    [frames]. Cancelar o Job do consumidor encerra a entrega para ele;
 *    o barramento continua válido para outros/publicações futuras.
 *  - publish() suspende apenas se a configuração mudar; com a política acima,
 *    tryPublish() nunca falha por buffer (sempre há DROP_OLDEST).
 *  - No shutdown real (Fase 10), o MacroEngine cancela o escopo do serviço
 *    inteiro — o barramento não retém referências de Android.
 *
 * @status IMPLEMENTED + UNIT TEST (infraestrutura da Fase 1, sem captura real)
 */
class FrameBus(
    replay: Int = 1,
    extraBufferCapacity: Int = 1,
) {
    private val _frames = MutableSharedFlow<Frame>(
        replay = replay,
        extraBufferCapacity = extraBufferCapacity,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )

    /** Fluxo somente-leitura para consumidores (motor de visão, debug). */
    val frames: SharedFlow<Frame> = _frames.asSharedFlow()

    /** Quantidade de coletores ativos (diagnóstico/métricas, Fase 18). */
    val subscriberCount: StateFlow<Int> get() = _frames.subscriptionCount

    /** Frame mais recente sem suspensão (para o overlay/debug futuro). */
    val latest: Frame? get() = _frames.replayCache.lastOrNull()

    suspend fun publish(frame: Frame) = _frames.emit(frame)

    /** Publicação não-suspensiva; retorna false apenas em configuração incomum. */
    fun tryPublish(frame: Frame): Boolean = _frames.tryEmit(frame)
}
