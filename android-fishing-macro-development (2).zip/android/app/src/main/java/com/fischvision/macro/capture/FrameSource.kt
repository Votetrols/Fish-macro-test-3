package com.fischvision.macro.capture

import kotlinx.coroutines.flow.Flow

/**
 * Produtor de frames, agnóstico à tecnologia de captura.
 *
 * Implementações previstas (nenhuma existe na Fase 1, exceto em testes):
 *  - ScreenCaptureManager (Fase 2)  — MediaProjection + VirtualDisplay + ImageReader
 *  - RecordedFrameSource (debug)    — replay de frames gravados (modo simulação)
 *  - FakeFrameSource (test/)        — fonte sintética. "Test implementation only."
 *
 * @status CONTRACT_ONLY — MediaProjection NÃO é implementado na Fase 1.
 */
interface FrameSource {

    /** Prepara a fonte (consentimentos, buffers). Suspensiva e idempotente. */
    suspend fun start()

    /**
     * Canal frio de frames. O fluxo:
     *  - emite enquanto a fonte estiver ativa;
     *  - COMPLETA normalmente quando a fonte encerra;
     *  - falha com a exceção de causa (ex.: SecurityException da projeção)
     *    em encerramentos anormais — nunca engole erro.
     */
    fun frames(): Flow<Frame>

    /** Encerra a fonte e libera recursos. Suspensiva e idempotente. */
    suspend fun stop()
}
