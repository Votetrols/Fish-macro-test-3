package com.fischvision.macro.core

/**
 * Erros do macro, tipados. Nenhum componente deve "crashear" em silêncio:
 * falhas críticas viram [MacroEvent.FatalError] com uma instância desta classe.
 */
data class MacroError(
    val type: Type,
    val message: String,
    val cause: Throwable? = null,
    /** Estado em que a máquina se encontrava quando o erro ocorreu. */
    val atState: MacroState? = null,
) {
    enum class Type {
        PROJECTION_STOPPED,
        ACCESSIBILITY_UNAVAILABLE,
        CAPTURE_FAILED,
        VISION_FAILED,
        INPUT_FAILED,
        OVERLAY_FAILED,
        UNKNOWN,
    }
}
