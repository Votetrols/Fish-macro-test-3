package com.fischvision.macro.capture

/**
 * Contrato de frame — Fase 1.
 *
 * NÃO depende de MediaProjection: qualquer produtor (captura real na Fase 2,
 * frames gravados no modo simulação, fontes de teste) entrega o mesmo tipo.
 *
 * A representação de pixels NÃO é definida nesta fase (regra 7/regra 32):
 * o payload é um handle opaco do produtor. Na Fase 2, a implementação real
 * carregará o plane RGBA_8888 vindo do ImageReader sem mudar este contrato.
 *
 * @status CONTRACT_ONLY
 */
enum class PixelFormat {
    /** Formato que o ImageReader/VirtualDisplay entregará na Fase 2. */
    RGBA_8888,
    UNKNOWN,
}

/**
 * Handle opaco do produtor do frame. Dono do ciclo de vida do recurso
 * (ex.: Image do ImageReader na Fase 2): quem consome NUNCA libera,
 * quem produz chama [release] após o consumo.
 */
interface FramePayload {
    /** Tamanho lógico do payload em bytes, ou -1 quando opaco/desconhecido. */
    fun sizeBytes(): Long

    /** Libera o recurso subjacente. Deve ser idempotente. */
    fun release()
}

/**
 * Um frame lógico. Imutável; metadados suficientes para as fases futuras
 * (normalização de resolução, rotação de sensor, carimbo temporal).
 */
data class Frame(
    val timestampNanos: Long,
    val width: Int,
    val height: Int,
    /** Rotação do display, em graus (0/90/180/270), conforme Surface.rotation. */
    val rotationDegrees: Int,
    val pixelFormat: PixelFormat,
    val payload: FramePayload,
)
