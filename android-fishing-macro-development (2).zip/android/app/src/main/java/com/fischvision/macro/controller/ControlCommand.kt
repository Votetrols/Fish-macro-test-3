package com.fischvision.macro.controller

/**
 * INTENÇÃO de controle — nunca um gesto Android.
 *
 * O Controller (camada lógica) emite isto; quem converte para
 * GestureDescription é a camada de input, outro pacote, outra fase.
 *
 * @status CONTRACT_ONLY + testado via implementação fake em ContractsTest.
 */
data class ControlCommand(
    val type: Type,
    /** Orçamento máximo do comando (0 = sem teto); usado pelo anti-chattering. */
    val maxDurationMillis: Long = 0L,
    /** Rastreabilidade de decisão para os logs da Fase 20. */
    val reason: String = "",
) {
    enum class Type {
        NONE,
        PRESS,
        HOLD,
        RELEASE,
    }

    companion object {
        val NONE: ControlCommand = ControlCommand(Type.NONE)
    }
}
