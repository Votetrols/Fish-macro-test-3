package com.fischvision.macro.detector

/**
 * Uma detecção em coordenadas do frame de captura.
 *
 * Invariantes garantidas no construtor (testadas em ContractsTest):
 *  - confidence ∈ [0,1]  (abaixo do threshold configurável, o chamador deve
 *    descartar — regra 7 da arquitetura);
 *  - bounding box bem formada (right >= left, bottom >= top).
 *
 * @status CONTRACT_ONLY — nenhum detector real existe na Fase 1.
 */
data class Detection(
    val type: Type,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val confidence: Float,
    val timestampNanos: Long,
) {
    enum class Type {
        FISHING_BAR,
        FISH,
        PLAYER_INDICATOR,
        UNKNOWN,
    }

    init {
        require(confidence in 0f..1f) {
            "confidence fora de [0,1]: $confidence"
        }
        require(right >= left && bottom >= top) {
            "bounding box inválida: ($left,$top,$right,$bottom)"
        }
    }

    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f
    val width: Float get() = right - left
    val height: Float get() = bottom - top
}
