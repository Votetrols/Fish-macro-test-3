package com.fischvision.macro.input

import com.fischvision.macro.core.MacroState
import com.fischvision.macro.debug.DebugLogger

/**
 * Seam de despacho: produção delega a MacroAccessibilityService.dispatch;
 * testes usam implementação falsa de device. A camada de gating (abaixo) é
 * 100% testável em JVM por isso — sem fingir gestos.
 */
interface GestureDispatcher {
    fun tap(x: Float, y: Float): Boolean
    fun holdStart(x: Float, y: Float, maxDurationMillis: Long): Boolean
    fun holdEnd(): Boolean
}

/** Limites configuráveis de segurança de entrada (Fase 5, §LIMITES). */
data class InputLimits(
    val minIntervalMillis: Long = 50,
    val maxCommandsPerMinute: Int = 300,
    val maxHoldMillis: Long = 900,
    val minConfidence: Float = 0.35f,
    /** Ponto neutro do toque em FRAÇÃO do frame (não em pixels fixos). */
    val touchXPct: Float = 0.5f,
    val touchYPct: Float = 0.85f,
) {
    init {
        require(minIntervalMillis >= 0) { "minInterval inválido" }
        require(maxCommandsPerMinute in 1..1200) { "maxCommandsPerMinute fora de [1,1200]" }
        require(maxHoldMillis in 1..55_000) { "maxHold fora de [1,55000]" }
        require(minConfidence in 0f..1f) { "minConfidence fora de [0,1]" }
        require(touchXPct in 0f..1f && touchYPct in 0f..1f) { "ponto de toque fora de [0,1]" }
    }
}

/** Contexto que autoriza (ou bloqueia) a injeção de um comando. */
data class InputGateContext(
    val macroState: MacroState,
    val trackingOk: Boolean,
    val confidence: Float,
    val frameWidth: Int,
    val frameHeight: Int,
)

/**
 * InputController real com portões rígidos — Fase 5 (§FAIL SAFE):
 * NÃO envia comandos fora de CONTROLLING, sem tracking, com confidence
 * insuficiente ou estourando os limites de taxa. releaseAll() sempre tenta
 * soltar (idempotente) mesmo com gate fechado — segurança antes de tudo.
 */
class AccessibilityInputController(
    private val dispatcher: GestureDispatcher,
    private val gate: () -> InputGateContext,
    private val limits: InputLimits = InputLimits(),
    private val clock: () -> Long = { System.nanoTime() },
) : InputController {

    private var lastCommandAtNanos = Long.MIN_VALUE
    private val commandWindow = ArrayDeque<Long>()
    private var holding = false

    var lastDispatchOk = true
        private set

    /** Reflete o último resultado real do dispatcher (não um otimismo). */
    override val isAvailable: Boolean get() = lastDispatchOk

    override fun execute(command: InputCommand): Boolean {
        val ctx = gate()

        if (ctx.macroState != MacroState.CONTROLLING) {
            DebugLogger.w(DebugLogger.Category.INPUT, "comando bloqueado fora de CONTROLLING (${ctx.macroState})")
            return false
        }
        if (!ctx.trackingOk) {
            DebugLogger.w(DebugLogger.Category.INPUT, "comando bloqueado: tracking perdido")
            return false
        }
        if (ctx.confidence < limits.minConfidence) {
            DebugLogger.w(DebugLogger.Category.INPUT, "comando bloqueado: confidence ${ctx.confidence}")
            return false
        }
        if (!rateAllows()) {
            DebugLogger.w(DebugLogger.Category.INPUT, "comando bloqueado: limite de taxa")
            return false
        }

        val px = limits.touchXPct * ctx.frameWidth
        val py = limits.touchYPct * ctx.frameHeight

        val ok = when (command.action) {
            InputCommand.Action.TAP -> dispatcher.tap(px, py)
            InputCommand.Action.HOLD_START -> {
                if (holding) true
                else dispatcher.holdStart(
                    px, py,
                    command.durationMillis.coerceIn(1L, limits.maxHoldMillis),
                ).also { if (it) holding = true }
            }
            InputCommand.Action.HOLD_END -> dispatcher.holdEnd().also { holding = false }
        }

        lastDispatchOk = ok
        if (ok) recordCommand()
        return ok
    }

    override fun releaseAll() {
        // nunca passa pelo gate: stop/pause/erro sempre soltam o dedo virtual
        val ok = dispatcher.holdEnd()
        holding = false
        lastDispatchOk = ok
    }

    private fun rateAllows(): Boolean {
        val now = clock()
        if (now - lastCommandAtNanos < limits.minIntervalMillis * 1_000_000L) return false
        while (commandWindow.isNotEmpty() && now - commandWindow.first() > 60_000_000_000L) {
            commandWindow.removeFirst()
        }
        return commandWindow.size < limits.maxCommandsPerMinute
    }

    private fun recordCommand() {
        lastCommandAtNanos = clock()
        commandWindow.addLast(lastCommandAtNanos)
    }
}
