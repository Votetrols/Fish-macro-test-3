package com.fischvision.macro.settings

/**
 * Configuração do macro — estrutura + defaults.
 *
 * ATENÇÃO (regra 19): estes são DEFAULTS CONSERVADORES de ponto de partida.
 * NÃO são valores validados em aparelho e NÃO devem ser tratados como ideais;
 * a validação acontece com frames reais (Fases 2–13) e os valores se tornarão
 * editáveis na tela de configurações (DataStore).
 *
 * @status IMPLEMENTED + UNIT TEST (defaults cobertos em ContractsTest)
 */
data class MacroSettings(
    /** Largura do buffer de captura (paisagem). Reduz carga de CPU/memória. */
    val captureWidth: Int = 960,
    /** Altura do buffer de captura (paisagem). */
    val captureHeight: Int = 540,
    /** Alvo de frames por segundo da captura. Conservador para médio/baixo. */
    val targetFps: Int = 10,
    /** HUD de debug desligado por padrão (overlay ainda nem existe na Fase 1). */
    val debugEnabled: Boolean = false,
    /** Controller desligado por padrão: nenhum comando sai sem opt-in. */
    val controllerEnabled: Boolean = false,
) {
    companion object {
        val DEFAULT: MacroSettings = MacroSettings()
    }
}
