package com.fischvision.macro.controller

/**
 * Controlador lógico (zona morta + histerese + rate limiting — Fase 8).
 *
 * Restrições obrigatórias de camada (arquitetura aprovada):
 *  - NÃO conhece AccessibilityService;
 *  - NÃO conhece GestureDescription;
 *  - NÃO toca na tela. Produz apenas [ControlCommand].
 *
 * NÃO existe implementação de produção na Fase 1. ScriptedFakeController
 * existe apenas no test source set.
 *
 * @status CONTRACT_ONLY
 */
interface Controller {
    /**
     * Atualiza o controle com as medições do ciclo.
     *
     * @param targetPositionX posição X do alvo (peixe/predição), null se ausente
     * @param indicatorPositionX posição X do indicador do jogador, null se ausente
     * @param confidence confiança agregada do ciclo ∈ [0,1]
     * @param deltaTimeNanos tempo desde o último update
     */
    fun update(
        targetPositionX: Float?,
        indicatorPositionX: Float?,
        confidence: Float,
        deltaTimeNanos: Long,
    ): ControlCommand

    /** Zera histerese/timers internos (perda de detecção, pausa, reset). */
    fun reset()
}
