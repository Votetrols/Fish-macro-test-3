package com.fischvision.macro.vision

import com.fischvision.macro.capture.Frame

/**
 * Fronteira do pipeline de visão: recebe um [Frame] e devolve medições.
 *
 * NÃO EXISTE implementação de produção na Fase 1 (regra 10). A única
 * implementação permitida agora é a de testes:
 * FakeVisionProcessor — "Test implementation only" (test source set).
 *
 * @status CONTRACT_ONLY
 */
interface VisionProcessor {
    /**
     * Processa um frame. Contratos das implementações futuras:
     *  - chamada na thread do chamador — quem orquestra decide o Dispatcher;
     *  - NUNCA altera o estado externo de forma oculta;
     *  - resultado vazio deve distinguir-se de falha por exceção tipada.
     */
    suspend fun process(frame: Frame): VisionResult
}
