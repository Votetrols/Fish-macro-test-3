package com.fischvision.macro.input

/**
 * Comando físico de entrada — a menor unidade que a camada Android entende.
 *
 * Já modela o padrão da Fase 9 (cadeia de gestos com willContinue):
 *  - HOLD_START abre a cadeia; HOLD_END a fecha; TAP é atômico.
 *
 * @status CONTRACT_ONLY
 */
data class InputCommand(
    val action: Action,
    /** Ponto neutro alvo do toque, em coordenadas de tela física. */
    val x: Float = 0f,
    val y: Float = 0f,
    val durationMillis: Long = 0L,
) {
    enum class Action {
        TAP,
        HOLD_START,
        HOLD_END,
    }
}
