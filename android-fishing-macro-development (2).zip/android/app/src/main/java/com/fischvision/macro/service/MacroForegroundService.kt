package com.fischvision.macro.service

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import com.fischvision.macro.accessibility.MacroAccessibilityService
import com.fischvision.macro.capture.FrameBus
import com.fischvision.macro.capture.MediaProjectionFrameSource
import com.fischvision.macro.controller.FishingControllerImpl
import com.fischvision.macro.core.MacroStateMachine
import com.fischvision.macro.debug.DebugLogger
import com.fischvision.macro.input.AccessibilityInputController
import com.fischvision.macro.input.GestureDispatcher
import com.fischvision.macro.input.InputGateContext
import com.fischvision.macro.overlay.OverlayState
import com.fischvision.macro.overlay.WindowOverlayManager
import com.fischvision.macro.settings.MacroSettings
import com.fischvision.macro.tracker.EmaTargetTracker
import com.fischvision.macro.vision.RealVisionProcessor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Foreground Service — Fase 6: orquestração completa do pipeline.
 *
 * Consentimento MediaProjection → FGS tipado + notificação real →
 * MediaProjectionFrameSource → MacroEngine → (vision→trackers→controller→
 * AccessibilityInputController→MacroAccessibilityService) → Overlay HUD.
 *
 * Fail-safe artesanal em cada saída: pause/stop/destroy soltam o hold via
 * engine, parada fecha fonte+escopo+overlay, e a máquina de estados pertence
 * ao serviço — fechar a Activity nunca derruba o macro.
 */
class MacroForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val stateMachine = MacroStateMachine()
    val frameBus = FrameBus()

    private var engine: MacroEngine? = null
    private var overlay: WindowOverlayManager? = null

    override fun onCreate() {
        super.onCreate()
        DebugLogger.i(DebugLogger.Category.SERVICE, "MacroForegroundService.onCreate (Fase 6)")
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_CAPTURE -> startCaptureFlow(intent)
            ACTION_PAUSE -> engine?.pause()
            ACTION_RESUME -> engine?.resume()
            ACTION_STOP -> stopCaptureFlow("ACTION_STOP recebida")
            else -> {
                DebugLogger.w(DebugLogger.Category.SERVICE, "intent sem ação conhecida; encerrando")
                stopSelf(startId)
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopCaptureFlow("onDestroy")
        serviceScope.cancel()
        DebugLogger.i(DebugLogger.Category.SERVICE, "MacroForegroundService.onDestroy — tudo liberado")
        super.onDestroy()
    }

    // --------------------------------------------------------------- start

    private fun startCaptureFlow(intent: Intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                buildNotification("Macro ativo — captura + visão + controle"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION,
            )
        } else {
            @Suppress("DEPRECATION")
            startForeground(NOTIFICATION_ID, buildNotification("Macro ativo"))
        }

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val consentData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_CONSENT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_CONSENT_DATA)
        }

        if (resultCode != Activity.RESULT_OK || consentData == null) {
            DebugLogger.e(DebugLogger.Category.CAPTURE, "start sem consentimento válido")
            stateMachine.dispatch(com.fischvision.macro.core.MacroEvent.FatalError(
                com.fischvision.macro.core.MacroError(
                    com.fischvision.macro.core.MacroError.Type.PROJECTION_STOPPED,
                    "captura iniciada sem consentimento válido",
                ),
            ))
            stopSelf()
            return
        }

        if (engine?.isRunning == true) {
            DebugLogger.w(DebugLogger.Category.SERVICE, "engine já ativa — instância única preservada")
            return
        }

        val source = MediaProjectionFrameSource(
            appContext = applicationContext,
            resultCode = resultCode,
            consentData = consentData,
            settings = MacroSettings.DEFAULT,
        )

        val vision = RealVisionProcessor()
        val fishTracker = EmaTargetTracker()
        val indicatorTracker = EmaTargetTracker()
        val controller = FishingControllerImpl()

        val dispatcher = object : GestureDispatcher {
            override fun tap(x: Float, y: Float): Boolean =
                MacroAccessibilityService.dispatch(MacroAccessibilityService.GestureRequest.Tap(x, y))

            override fun holdStart(x: Float, y: Float, maxDurationMillis: Long): Boolean =
                MacroAccessibilityService.dispatch(
                    MacroAccessibilityService.GestureRequest.HoldStart(x, y, maxDurationMillis),
                )

            override fun holdEnd(): Boolean = MacroAccessibilityService.releaseAll()
        }

        val eng = MacroEngine(
            scope = serviceScope,
            fsm = stateMachine,
            bus = frameBus,
            vision = vision,
            fishTracker = fishTracker,
            indicatorTracker = indicatorTracker,
            controller = controller,
            input = AccessibilityInputController(
                dispatcher = dispatcher,
                gate = {
                    InputGateContext(
                        macroState = stateMachine.state,
                        trackingOk = engine?.telemetry?.trackingOk == true,
                        confidence = engine?.telemetry?.confidence ?: 0f,
                        frameWidth = engine?.telemetry?.frameWidth ?: MacroSettings.DEFAULT.captureWidth,
                        frameHeight = engine?.telemetry?.frameHeight ?: MacroSettings.DEFAULT.captureHeight,
                    )
                },
            ),
            sink = LogSink { level, category, message, throwable ->
                val cat = runCatching { DebugLogger.Category.valueOf(category) }
                    .getOrDefault(DebugLogger.Category.SERVICE)
                when {
                    level >= 6 -> DebugLogger.e(cat, message, throwable)
                    level == 5 -> DebugLogger.w(cat, message, throwable)
                    else -> DebugLogger.d(cat, message)
                }
            },
            resetController = { controller.reset() },
        )
        engine = eng

        maybeCreateOverlay()
        if (eng.start(source)) {
            startTelemetryLoop()
        } else {
            stopCaptureFlow("engine recusou start (ver Logcat)")
        }
    }

    // ---------------------------------------------------------------- stop

    private fun stopCaptureFlow(reason: String) {
        DebugLogger.i(DebugLogger.Category.SERVICE, "parando: $reason")
        engine?.stop()
        engine = null
        overlay?.destroy()
        overlay = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    // ------------------------------------------------------------- overlay

    private fun maybeCreateOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            DebugLogger.d(DebugLogger.Category.SERVICE, "overlay ausente: permissão não concedida (ok nesta fase)")
            return
        }
        val mgr = WindowOverlayManager(
            appContext = applicationContext,
            controls = object : WindowOverlayManager.ControlCallbacks {
                override fun onStart() { /* engine já é iniciada pelo fluxo de consentimento */ }
                override fun onPause() { startService(controlIntent(ACTION_PAUSE)) }
                override fun onResume() { startService(controlIntent(ACTION_RESUME)) }
                override fun onStop() { startService(controlIntent(ACTION_STOP)) }
            },
        )
        mgr.show()
        overlay = mgr
    }

    private fun controlIntent(action: String) = Intent(this, MacroForegroundService::class.java).apply {
        this.action = action
    }

    private fun startTelemetryLoop() {
        serviceScope.launch {
            var lastFrames = 0L
            while (isActive) {
                delay(500)
                val t = engine?.telemetry ?: break
                val fps = (t.framesProcessed - lastFrames) / 0.5
                lastFrames = t.framesProcessed
                overlay?.update(
                    OverlayState(
                        macroEnabled = engine?.isRunning == true,
                        stateName = stateMachine.state.name,
                        fps = fps.toDouble().coerceAtLeast(0.0),
                        confidence = t.confidence,
                    ),
                )
            }
        }
    }

    // ---------------------------------------------------------- notificação

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Fisch Vision Macro — captura",
                NotificationManager.IMPORTANCE_LOW,
            ).apply { description = "Ativa enquanto o macro executa." }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Fisch Vision Macro")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Fisch Vision Macro")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true)
                .build()
        }
    }

    companion object {
        const val ACTION_START_CAPTURE = "com.fischvision.macro.action.START_CAPTURE"
        const val ACTION_PAUSE = "com.fischvision.macro.action.PAUSE"
        const val ACTION_RESUME = "com.fischvision.macro.action.RESUME"
        const val ACTION_STOP = "com.fischvision.macro.action.STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_CONSENT_DATA = "extra_consent_data"
        private const val CHANNEL_ID = "fvm_capture"
        private const val NOTIFICATION_ID = 41
    }
}
