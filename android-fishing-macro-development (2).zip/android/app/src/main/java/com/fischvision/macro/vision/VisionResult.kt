package com.fischvision.macro.vision

import com.fischvision.macro.detector.Detection

/**
 * Resultado de uma passada do pipeline de visão sobre um frame.
 *
 * @status CONTRACT_ONLY — a visão computacional NÃO é implementada na Fase 1
 * (sem HSV, sem OpenCV, sem processamento de bitmap). Na Fase 4+, as
 * implementações reais preencherão [detections] a partir da ROI calibrada.
 */
data class VisionResult(
    val frameTimestampNanos: Long,
    /** Pode ser vazio: ausência de detecção é um resultado legítimo. */
    val detections: List<Detection>,
    /** Tempo de processamento da passada, para as métricas da Fase 18. */
    val processingTimeNanos: Long,
)
