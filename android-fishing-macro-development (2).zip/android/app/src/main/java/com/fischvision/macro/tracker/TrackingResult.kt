package com.fischvision.macro.tracker

/**
 * Saída de rastreamento de um alvo (peixe ou indicador).
 *
 * Campos já dimensionados para a Fase 7 (EMA + velocidade) sem fingir
 * implementação agora.
 *
 * @status CONTRACT_ONLY — EMA e predição só chegam na Fase 7.
 */
data class TrackingResult(
    val centerX: Float,
    val centerY: Float,
    /** Velocidade estimada em pixels/segundo. Na Fase 1 ninguém a produz. */
    val velocityXPxPerSec: Float,
    val velocityYPxPerSec: Float,
    val confidence: Float,
    val timestampNanos: Long,
)
