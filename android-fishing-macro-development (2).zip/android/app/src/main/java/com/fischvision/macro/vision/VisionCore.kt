package com.fischvision.macro.vision

import java.util.concurrent.atomic.AtomicLong

/**
 * Retângulo inteiro com bordas EXCLUSIVAS em right/bottom (width = right-left).
 */
data class IntRect(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
) {
    init {
        require(right > left && bottom > top) { "IntRect degenerado: ($left,$top,$right,$bottom)" }
    }
    val width: Int get() = right - left
    val height: Int get() = bottom - top
    val area: Int get() = width * height
    fun contains(x: Int, y: Int): Boolean = x in left until right && y in top until bottom
}

enum class RoiMode { FULL_SCREEN, CUSTOM_REGION, AUTO_REGION }

/**
 * Região de Interesse ancorada em FRAÇÕES da tela — independe de resolução e
 * proporção; a rotação entra apenas via dimensões já transpostas do frame.
 *
 * AUTO_REGION é uma heurística inicial NÃO CALIBRADA (faixa inferior central,
 * onde o minigame costuma renderizar a barra) — ajustável por configuração;
 * nunca por coordenada fixa em pixels.
 */
class RoiManager(
    val mode: RoiMode = RoiMode.AUTO_REGION,
    val customLeftPct: Float = 0.10f,
    val customTopPct: Float = 0.55f,
    val customRightPct: Float = 0.90f,
    val customBottomPct: Float = 0.92f,
    val autoLeftPct: Float = 0.08f,
    val autoTopPct: Float = 0.52f,
    val autoRightPct: Float = 0.92f,
    val autoBottomPct: Float = 0.94f,
) {
    init {
        fun valid(l: Float, t: Float, r: Float, b: Float) =
            l in 0f..1f && t in 0f..1f && r in 0f..1f && b in 0f..1f && r > l && b > t
        require(valid(customLeftPct, customTopPct, customRightPct, customBottomPct)) { "custom ROI inválida" }
        require(valid(autoLeftPct, autoTopPct, autoRightPct, autoBottomPct)) { "auto ROI inválida" }
    }

    fun resolve(frameWidth: Int, frameHeight: Int, rotationDegrees: Int = 0): IntRect {
        return when (mode) {
            RoiMode.FULL_SCREEN -> IntRect(0, 0, frameWidth, frameHeight)
            RoiMode.CUSTOM_REGION -> fromPcts(
                customLeftPct, customTopPct, customRightPct, customBottomPct, frameWidth, frameHeight,
            )
            RoiMode.AUTO_REGION -> fromPcts(
                autoLeftPct, autoTopPct, autoRightPct, autoBottomPct, frameWidth, frameHeight,
            )
        }
    }

    private fun fromPcts(l: Float, t: Float, r: Float, b: Float, w: Int, h: Int): IntRect =
        IntRect(
            left = (l * w).toInt().coerceIn(0, w - 1),
            top = (t * h).toInt().coerceIn(0, h - 1),
            right = (r * w).toInt().coerceIn(1, w),
            bottom = (b * h).toInt().coerceIn(1, h),
        )
}

/**
 * Faixa cromática HSV calibrável por alvo.
 *
 * OS PERFIS PADRÃO ABAIXO NÃO SÃO CALIBRADOS — são pontos de partida
 * heurísticos até a coleta de frames reais do jogo (regra: não presumir o
 * visual do Fisch). A calibração final vem das amostras do modo debug.
 */
data class ColorProfile(
    val name: String,
    val hueCenter: Float,          // 0..360
    val hueTolerance: Float,       // 0..180
    val minSaturation: Float,      // 0..1 (0 aceita acromáticos)
    val minValue: Float,           // 0..1
    val maxValue: Float = 1f,
) {
    init {
        require(hueCenter in 0f..360f) { "hueCenter fora de [0,360]" }
        require(hueTolerance in 0f..180f) { "hueTolerance fora de [0,180]" }
        require(minSaturation in 0f..1f && minValue in 0f..1f && maxValue in 0f..1f) { "faixas s/v inválidas" }
        require(maxValue >= minValue) { "maxValue < minValue" }
    }

    fun matches(r: Int, g: Int, b: Int): Boolean {
        val hsv = FloatArray(3)
        rgbToHsv(r, g, b, hsv)
        if (hsv[1] < minSaturation) return false
        if (hsv[2] < minValue || hsv[2] > maxValue) return false
        if (hueTolerance >= 180f) return true
        val dh = Math.abs(hsv[0] - hueCenter)
        val circular = if (dh > 180f) 360f - dh else dh
        return circular <= hueTolerance
    }
}

/** Conversão RGB(0..255) → HSV(h:0..360, s:0..1, v:0..1). Algoritmo padrão. */
fun rgbToHsv(r: Int, g: Int, b: Int, out: FloatArray) {
    val rf = r / 255f
    val gf = g / 255f
    val bf = b / 255f
    val max = maxOf(rf, gf, bf)
    val min = minOf(rf, gf, bf)
    val delta = max - min

    var h = 0f
    if (delta > 0f) {
        h = when (max) {
            rf -> 60f * (((gf - bf) / delta) % 6f)
            gf -> 60f * (((bf - rf) / delta) + 2f)
            else -> 60f * (((rf - gf) / delta) + 4f)
        }
        if (h < 0f) h += 360f
    }
    val s = if (max == 0f) 0f else delta / max
    out[0] = h
    out[1] = s
    out[2] = max
}

object ColorProfiles {
    /** Trilho/quadro da barra: acromático escuro-médio. NÃO CALIBRADO. */
    val BAR = ColorProfile("bar", hueCenter = 0f, hueTolerance = 180f, minSaturation = 0f, minValue = 0.18f, maxValue = 0.55f)

    /** Peixe/marcador cromático. NÃO CALIBRADO. */
    val FISH = ColorProfile("fish", hueCenter = 195f, hueTolerance = 45f, minSaturation = 0.45f, minValue = 0.45f)

    /** Indicador do jogador: alto brilho acromático. NÃO CALIBRADO. */
    val INDICATOR = ColorProfile("indicator", hueCenter = 0f, hueTolerance = 180f, minSaturation = 0f, minValue = 0.78f)
}

/**
 * Métricas do pipeline de visão — puro Kotlin, thread-safe.
 */
class FrameMetrics {
    private val processed = AtomicLong(0)
    private val noDetections = AtomicLong(0)
    private val totalNanos = AtomicLong(0)
    private val windowStart = AtomicLong(0)
    private val windowFrames = AtomicLong(0)

    fun record(processingNanos: Long, detectionCount: Int, nowNanos: Long) {
        processed.incrementAndGet()
        totalNanos.addAndGet(processingNanos)
        if (detectionCount == 0) noDetections.incrementAndGet()
        val w = windowStart.get()
        if (w == 0L || nowNanos - w >= 1_000_000_000L) {
            windowStart.set(nowNanos)
            windowFrames.set(1)
        } else {
            windowFrames.incrementAndGet()
        }
    }

    data class Snapshot(
        val framesProcessed: Long,
        val framesWithoutDetection: Long,
        val avgProcessingMillis: Double,
        val processingFpsWindow: Long,
    )

    fun snapshot(): Snapshot {
        val n = processed.get()
        val avg = if (n == 0L) 0.0 else totalNanos.get().toDouble() / n / 1_000_000.0
        return Snapshot(n, noDetections.get(), avg, windowFrames.get())
    }
}
