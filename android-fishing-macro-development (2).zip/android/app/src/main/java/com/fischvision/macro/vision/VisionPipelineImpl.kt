package com.fischvision.macro.vision

import com.fischvision.macro.capture.Frame
import com.fischvision.macro.capture.RgbaFramePayload
import com.fischvision.macro.detector.Detection
import com.fischvision.macro.detector.Detector

/**
 * Detector genérico por segmentação cromática + componentes conectados.
 *
 * Funcionamento (100% Kotlin, sem nativos, determinístico):
 *  1. amostra a ROI em grade de [sampleStep]² (2 = ¼ do custo por célula);
 *  2. máscara booleana por [ColorProfile.matches];
 *  3. BFS 4-conexo rotula componentes; cada componente vira candidato;
 *  4. portões geométricos: células mínimas, razão de aspecto ∈ faixa, fração
 *     de área do bbox relativa à região analisada ∈ faixa;
 *  5. confidence heurística CALIBRÁVEL = fill*0.55 + aspectScore*0.25 + sizeScore*0.2
 *     (documentada, não "calibrada" — ajuste fino vem da coleta real).
 *
 * Nunca lança exceção por conteúdo de frame: pixels inválidos/ausentes apenas
 * reduzem a máscara. Frames sem [RgbaFramePayload] retornam lista vazia.
 */
class BlobDetector(
    private val profile: ColorProfile,
    private val target: Detection.Type,
    private val minAspect: Float,
    private val maxAspect: Float,
    private val minAreaFraction: Float,
    private val maxAreaFraction: Float,
    private val sampleStep: Int = 2,
    private val minCells: Int = 6,
) {
    fun detectIn(
        payload: RgbaFramePayload,
        roi: IntRect,
        timestampNanos: Long,
    ): List<Detection> {
        val step = sampleStep.coerceAtLeast(1)
        val gridW = (roi.width + step - 1) / step
        val gridH = (roi.height + step - 1) / step
        if (gridW <= 0 || gridH <= 0) return emptyList()

        val cells = gridW * gridH
        val mask = BooleanArray(cells)
        val visited = BooleanArray(cells)

        for (gy in 0 until gridH) {
            val py = roi.top + gy * step
            for (gx in 0 until gridW) {
                val px = roi.left + gx * step
                val argb = payload.argbAt(px, py) ?: continue
                val r = (argb shr 16) and 0xFF
                val g = (argb shr 8) and 0xFF
                val b = argb and 0xFF
                if (profile.matches(r, g, b)) mask[gy * gridW + gx] = true
            }
        }

        val out = mutableListOf<Detection>()
        val stack = IntArray(cells)
        val aspectCenter = (minAspect + maxAspect) / 2f
        val aspectHalf = ((maxAspect - minAspect) / 2f).coerceAtLeast(0.0001f)

        for (start in 0 until cells) {
            if (!mask[start] || visited[start]) continue

            var top = 0
            stack[top++] = start
            visited[start] = true
            var count = 0
            var minX = Int.MAX_VALUE
            var minY = Int.MAX_VALUE
            var maxX = Int.MIN_VALUE
            var maxY = Int.MIN_VALUE

            while (top > 0) {
                val idx = stack[--top]
                val cy = idx / gridW
                val cx = idx % gridW
                count++
                if (cx < minX) minX = cx
                if (cx > maxX) maxX = cx
                if (cy < minY) minY = cy
                if (cy > maxY) maxY = cy

                // 4-conexidade
                if (cx > 0) {
                    val n = idx - 1
                    if (mask[n] && !visited[n]) { visited[n] = true; stack[top++] = n }
                }
                if (cx < gridW - 1) {
                    val n = idx + 1
                    if (mask[n] && !visited[n]) { visited[n] = true; stack[top++] = n }
                }
                if (cy > 0) {
                    val n = idx - gridW
                    if (mask[n] && !visited[n]) { visited[n] = true; stack[top++] = n }
                }
                if (cy < gridH - 1) {
                    val n = idx + gridW
                    if (mask[n] && !visited[n]) { visited[n] = true; stack[top++] = n }
                }
            }

            if (count < minCells) continue

            val bboxW = (maxX - minX + 1) * step
            val bboxH = (maxY - minY + 1) * step
            val aspect = bboxW.toFloat() / bboxH.toFloat()
            if (aspect < minAspect || aspect > maxAspect) continue

            val areaFraction = (bboxW.toFloat() * bboxH) / roi.area
            if (areaFraction < minAreaFraction || areaFraction > maxAreaFraction) continue

            val cellsInBbox = (maxX - minX + 1) * (maxY - minY + 1)
            val fill = count.toFloat() / cellsInBbox
            val aspectScore = (1f - (aspect - aspectCenter) / aspectHalf / 2f).coerceIn(0f, 1f)
            val sizeScore = (1f - kotlin.math.abs(areaFraction - (minAreaFraction + maxAreaFraction) / 2f)).coerceIn(0f, 1f)
            val confidence = (fill * 0.55f + aspectScore * 0.25f + sizeScore * 0.20f).coerceIn(0f, 1f)

            out += Detection(
                type = target,
                left = (roi.left + minX * step).toFloat(),
                top = (roi.top + minY * step).toFloat(),
                right = (roi.left + (maxX + 1) * step).toFloat(),
                bottom = (roi.top + (maxY + 1) * step).toFloat(),
                confidence = confidence,
                timestampNanos = timestampNanos,
            )
        }
        return out
    }
}

/**
 * Detectores da UI de pesca em dois estágios:
 *  1. barra procurada na ROI;
 *  2. peixe e indicador procurados DENTRO da barra (se houver) — reduz
 *     falsos positivos e custo computacional.
 *
 * @status IMPLEMENTED / validado por testes JVM com frames sintéticos;
 * calibração cromática final pendente de frames reais do jogo.
 */
class FishingUiDetectors(
    private val roiManager: RoiManager = RoiManager(),
    barProfile: ColorProfile = ColorProfiles.BAR,
    fishProfile: ColorProfile = ColorProfiles.FISH,
    indicatorProfile: ColorProfile = ColorProfiles.INDICATOR,
) : Detector {

    private val barDetector = BlobDetector(
        profile = barProfile,
        target = Detection.Type.FISHING_BAR,
        minAspect = 3.5f,
        maxAspect = 40f,
        minAreaFraction = 0.02f,
        maxAreaFraction = 0.95f,
        sampleStep = 2,
    )
    private val fishDetector = BlobDetector(
        profile = fishProfile,
        target = Detection.Type.FISH,
        minAspect = 0.35f,
        maxAspect = 2.8f,
        minAreaFraction = 0.0005f,
        maxAreaFraction = 0.5f,
        sampleStep = 1,
        minCells = 4,
    )
    private val indicatorDetector = BlobDetector(
        profile = indicatorProfile,
        target = Detection.Type.PLAYER_INDICATOR,
        minAspect = 0.12f,
        maxAspect = 3.5f,
        minAreaFraction = 0.0005f,
        maxAreaFraction = 0.6f,
        sampleStep = 1,
        minCells = 4,
    )

    fun analyze(frame: Frame): List<Detection> {
        val payload = frame.payload as? RgbaFramePayload ?: return emptyList()
        val roi = safeRoi(frame)
        val out = mutableListOf<Detection>()

        val bar = barDetector.detectIn(payload, roi, frame.timestampNanos)
            .maxByOrNull { it.confidence }

        val searchRoi: IntRect = if (bar != null) {
            out += bar
            IntRect(
                left = bar.left.toInt().coerceIn(0, frame.width - 1),
                top = bar.top.toInt().coerceIn(0, frame.height - 1),
                right = (bar.right.toInt() + 1).coerceIn(1, frame.width),
                bottom = (bar.bottom.toInt() + 1).coerceIn(1, frame.height),
            )
        } else {
            roi
        }

        out += fishDetector.detectIn(payload, searchRoi, frame.timestampNanos)
        out += indicatorDetector.detectIn(payload, searchRoi, frame.timestampNanos)
        return out
    }

    private fun safeRoi(frame: Frame): IntRect =
        try {
            roiManager.resolve(frame.width, frame.height, frame.rotationDegrees)
        } catch (e: IllegalArgumentException) {
            IntRect(0, 0, frame.width.coerceAtLeast(1), frame.height.coerceAtLeast(1))
        }

    override fun detect(frame: Frame): List<Detection> = analyze(frame)
}

/**
 * VisionProcessor real: mede latência, delega aos detectores e registra
 * métricas. Não decide controle (camada errada) — só produz medições.
 */
class RealVisionProcessor(
    private val detectors: FishingUiDetectors = FishingUiDetectors(),
    val metrics: FrameMetrics = FrameMetrics(),
) : VisionProcessor {

    override suspend fun process(frame: Frame): VisionResult {
        val t0 = System.nanoTime()
        val detections = detectors.analyze(frame)
        val dt = System.nanoTime() - t0
        metrics.record(dt, detections.size, frame.timestampNanos)
        return VisionResult(
            frameTimestampNanos = frame.timestampNanos,
            detections = detections,
            processingTimeNanos = dt,
        )
    }
}
