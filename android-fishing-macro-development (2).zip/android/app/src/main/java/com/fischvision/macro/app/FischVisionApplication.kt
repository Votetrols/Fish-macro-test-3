package com.fischvision.macro.app

import android.app.Application
import com.fischvision.macro.debug.DebugLogger

/**
 * Application do Fisch Vision Macro.
 *
 * Fase 1: sem injeção de dependência pesada — o ServiceLocator manual da
 * arquitetura chega quando houver implementações reais para registrar
 * (Fase 2+). Manter este onCreate barato é requisito: ele atrasa o cold start.
 */
class FischVisionApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        DebugLogger.i(
            DebugLogger.Category.SERVICE,
            "FischVisionApplication.onCreate — build Fase 1 (skeleton).",
        )
    }
}
