package com.fischvision.macro.service

import com.fischvision.macro.capture.Frame
import com.fischvision.macro.capture.FrameBus
import com.fischvision.macro.capture.FrameSource
import com.fischvision.macro.controller.ControlCommand
import com.fischvision.macro.controller.Controller
import com.fischvision.macro.core.MacroError
import com.fischvision.macro.core.MacroEvent
import com.fischvision.macro.core.MacroState
import com.fischvision.macro.core.MacroStateMachine
import com.fischvision.macro.detector.Detection
import com.fischvision.macro.input.InputCommand
import com.fischvision.macro.input.InputController
import com.fischvision.macro.tracker.EmaTargetTracker
import com.fischvision.macro.tracker.TrackingResult
import com.fischvision.macro.vision.VisionProcessor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** Destino de logs do engine — produção liga ao DebugLogger; testes, ao NOOP. */
fun interface LogSink {
    fun log(level: Int, category: String, message: String, throwable: Throwable? = null)

    companion object {
        val NOOP = LogSink { _, _, _, _ -> }
    }
}

/**
 * Orquestrador do pipeline — Fase 6.
 *
 * Screen → FrameSource → (FrameBus) → VisionProcessor → trackers → controller
 * → InputController, tudo guiado pela MacroStateMachine. Puramente baseado nas
 * interfaces das Fases 1–5 → 100% testável em JVM; Android vive nas impls.
 *
 * Regras de segurança embutidas:
 *  - instância única: start() duplo é recusado (sem capturas/loops em dobro);
 *  - payload SEMPRE liberado (finally), mesmo em exceção;
 *  - perda de tracking ⇒ releaseAll + LOST_DETECTION, zero comando;
 *  - STOP/PAUSED/ERROR cortam o processamento no próximo frame ("hose cut");
 *  - Hold é mantido por comando, não por loop: dedup de ação evita spam.
 *
 * Detecção de SUCCESS/FAILED (sinais calibrados do progresso do jogo):
 * NOT_IMPLEMENTED — heurística depende de calibração real; documentado.
 */
class MacroEngine(
    private val scope: CoroutineScope,
    private val fsm: MacroStateMachine,
    private val bus: FrameBus,
    private val vision: VisionProcessor,
    private val fishTracker: EmaTargetTracker,
    private val indicatorTracker: EmaTargetTracker,
    private val controller: Controller,
    private val input: InputController,
    private val clock: () -> Long = { System.nanoTime() },
    private val sink: LogSink = LogSink.NOOP,
    private val minConfidence: Float = 0.35f,
    private val resetController: () -> Unit = {},
) {

    class Telemetry {
        @Volatile var trackingOk = false
        @Volatile var confidence = 0f
        @Volatile var frameWidth = 0
        @Volatile var frameHeight = 0
        @Volatile var framesProcessed = 0L
        @Volatile var commandsSent = 0L
        @Volatile var lastCommand: ControlCommand.Type = ControlCommand.Type.NONE
    }

    val telemetry = Telemetry()

    fun fsmState(): MacroState = fsm.state

    private var job: Job? = null
    private var lastControllerClockNanos = 0L
    private var lastInputHoldActive = false

    val isRunning: Boolean get() = job?.isActive == true

    fun start(source: FrameSource): Boolean {
        if (isRunning) {
            sink.log(4, "SERVICE", "engine já ativa — instância única preservada")
            return false
        }
        if (!fsm.dispatch(MacroEvent.Start).accepted) {
            sink.log(5, "STATE", "Start recusado a partir de ${fsm.state}")
            return false
        }
        // Herda o dispatcher do escopo injetado: produção usa Dispatchers.Default
        // no escopo do serviço; testes injetam o dispatcher do runTest (determinístico).
        job = scope.launch { runPipeline(source) }
        return true
    }

    fun pause() {
        if (fsm.dispatch(MacroEvent.Pause).accepted) {
            safeRelease("pause")
        }
    }

    fun resume() {
        fsm.dispatch(MacroEvent.Resume)
    }

    fun stop() {
        safeRelease("stop")
        fsm.dispatch(MacroEvent.Stop)
        job?.cancel()
        job = null
    }

    // ------------------------------------------------------------ pipeline

    private suspend fun runPipeline(source: FrameSource) {
        try {
            source.start()
        } catch (t: Throwable) {
            fsm.dispatch(
                MacroEvent.FatalError(
                    MacroError(MacroError.Type.CAPTURE_FAILED, t.message ?: "falha ao iniciar fonte", t),
                ),
            )
            return
        }
        try {
            source.frames().collect { frame ->
                try {
                    if (fsm.state == MacroState.STOPPED || fsm.state == MacroState.ERROR) return@collect
                    step(frame)
                } catch (t: Throwable) {
                    sink.log(6, "ERROR", "falha no passo do pipeline", t)
                    fsm.dispatch(
                        MacroEvent.FatalError(
                            MacroError(MacroError.Type.VISION_FAILED, t.message ?: "erro de pipeline", t),
                        ),
                    )
                    safeRelease("falha de pipeline")
                } finally {
                    // dono do release: SEMPRE o engine, em qualquer desfecho
                    frame.payload.release()
                }
            }
        } catch (t: Throwable) {
            sink.log(6, "ERROR", "fluxo de frames falhou", t)
            fsm.dispatch(
                MacroEvent.FatalError(
                    MacroError(MacroError.Type.CAPTURE_FAILED, t.message ?: "fluxo encerrou com erro", t),
                ),
            )
            safeRelease("fluxo com erro")
        }
    }

    private suspend fun step(frame: Frame) {
        fsm.dispatch(MacroEvent.FrameAvailable(frame.timestampNanos))
        // publica para consumidores auxiliares (HUD/overlay) sem bloquear o pipeline
        bus.tryPublish(frame)
        telemetry.framesProcessed++
        telemetry.frameWidth = frame.width
        telemetry.frameHeight = frame.height

        // Hose cut: pausado não processa (mas o payload já será liberado no finally)
        if (fsm.state == MacroState.PAUSED) return

        val visionResult = vision.process(frame)
        val detections = visionResult.detections

        val bar = detections.firstOrNull { it.type == Detection.Type.FISHING_BAR }
        val fish = fishTracker.associate(detections.filter { it.type == Detection.Type.FISH })
        val indicator = indicatorTracker.associate(detections.filter { it.type == Detection.Type.PLAYER_INDICATOR })

        if (bar == null || fish == null || indicator == null) {
            handleMissingTargets()
            return
        }

        val fishTrack: TrackingResult? = fishTracker.update(fish)
        val indicatorTrack: TrackingResult? = indicatorTracker.update(indicator)
        handleStateTransitions(barPresent = true, targetsPresent = fish != null && indicator != null)

        telemetry.confidence = minOf(fish.confidence, indicator.confidence)
        telemetry.trackingOk = fishTrack != null && indicatorTrack != null

        if (fsm.state == MacroState.TRACKING && telemetry.trackingOk && telemetry.confidence >= minConfidence) {
            fsm.dispatch(MacroEvent.ControlRequested)
        }

        if (fsm.state == MacroState.CONTROLLING) {
            controlCycle(fishTrack, indicatorTrack)
        }
    }

    private fun handleMissingTargets() {
        fishTracker.onMissedFrame()
        indicatorTracker.onMissedFrame()
        telemetry.trackingOk = false
        telemetry.confidence = 0f
        val state = fsm.state
        if (state == MacroState.CONTROLLING || state == MacroState.TRACKING) {
            fsm.dispatch(MacroEvent.DetectionLost)
            resetController()
            safeRelease("alvos ausentes")
        }
    }

    private fun handleStateTransitions(barPresent: Boolean, targetsPresent: Boolean) {
        when (fsm.state) {
            MacroState.WAITING_FOR_FISHING_UI ->
                if (barPresent) fsm.dispatch(MacroEvent.DetectionFound)
            MacroState.DETECTING ->
                if (targetsPresent) fsm.dispatch(MacroEvent.DetectionFound)
            MacroState.LOST_DETECTION ->
                if (targetsPresent) fsm.dispatch(MacroEvent.DetectionFound)
            else -> Unit
        }
    }

    // Sem detecção de SUCCESS/FAILED por enquanto: os sinais visuais do
    // progresso dependem de calibração com frames reais — NOT_IMPLEMENTED.

    private fun controlCycle(fishTrack: TrackingResult?, indicatorTrack: TrackingResult?) {
        val now = clock()
        if (fishTrack == null || indicatorTrack == null) return
        if (fishTracker.isLost(now)) {
            fsm.dispatch(MacroEvent.DetectionLost)
            resetController()
            safeRelease("tracking timeout")
            return
        }

        val dt = if (lastControllerClockNanos == 0L) 0L else now - lastControllerClockNanos
        lastControllerClockNanos = now

        val predictedX = fishTracker.predictedX(PREDICTION_LEAD_NANOS)
        val confidence = minOf(fishTrack.confidence, indicatorTrack.confidence)

        val command = controller.update(
            targetPositionX = predictedX,
            indicatorPositionX = indicatorTrack.centerX,
            confidence = confidence,
            deltaTimeNanos = if (dt == 0L) 1L else dt,
        )
        dispatchToInput(command)
    }

    private fun dispatchToInput(command: ControlCommand) {
        when (command.type) {
            ControlCommand.Type.PRESS, ControlCommand.Type.HOLD -> {
                if (!lastInputHoldActive) {
                    val ok = input.execute(
                        InputCommand(
                            action = InputCommand.Action.HOLD_START,
                            durationMillis = command.maxDurationMillis,
                        ),
                    )
                    if (ok) {
                        lastInputHoldActive = true
                        telemetry.commandsSent++
                    }
                }
            }
            ControlCommand.Type.RELEASE -> {
                if (lastInputHoldActive) {
                    input.execute(InputCommand(InputCommand.Action.HOLD_END))
                    telemetry.commandsSent++
                }
                lastInputHoldActive = false
            }
            ControlCommand.Type.NONE -> Unit
        }
        telemetry.lastCommand = command.type
    }

    private fun safeRelease(why: String) {
        sink.log(4, "INPUT", "releaseAll: $why")
        input.releaseAll()
        lastInputHoldActive = false
    }

    private companion object {
        const val PREDICTION_LEAD_NANOS = 60_000_000L
    }
}
