package com.fischvision.macro.input

/**
 * Fronteira entre a decisão lógica (controller/) e o Android (acessibilidade).
 *
 * A implementação real (AccessibilityInputController — Fase 9) despachará
 * GestureDescription no MacroAccessibilityService. Na Fase 1:
 *  - NÃO existe implementação de produção;
 *  - NENHUM gesto é enviado;
 *  - FakeInputController existe apenas em test/.
 *
 * @status CONTRACT_ONLY
 */
interface InputController {

    /** true quando a camada consegue entregar comandos (ex.: serviço ligado). */
    val isAvailable: Boolean

    /**
     * Executa um comando físico. Retorna true quando aceito pela camada.
     * Implementação real (Fase 9) despacha de forma assíncrona e reportará
     * callback de conclusão pelos canais de telemetria — esta assinatura
     * síncrona marca apenas aceitação imediata, não conclusão do gesto.
     */
    fun execute(command: InputCommand): Boolean

    /**
     * Fail-safe: libera QUALQUER pressão em andamento. Chamado por pausa,
     * stop, perda de detecção por timeout e pelo watchdog.
     */
    fun releaseAll()
}
