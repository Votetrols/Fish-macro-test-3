package com.fischvision.macro.detector

import com.fischvision.macro.capture.Frame

/**
 * Fronteira comum dos detectores (FishingBarDetector — Fase 4,
 * FishDetector — Fase 5, PlayerIndicatorDetector — Fase 6).
 *
 * NENHUMA implementação de produção existe na Fase 1 e nenhum resultado é
 * fabricado (regras 11/32).
 *
 * @status CONTRACT_ONLY
 */
interface Detector {
    /**
     * Analisa um frame e devolve as detecções encontradas (possivelmente
     * lista vazia). Deve ser determinístico para o mesmo frame e não pode
     * conhecer camadas acima (tracker/controller) nem Android (gestos, views).
     */
    fun detect(frame: Frame): List<Detection>
}
