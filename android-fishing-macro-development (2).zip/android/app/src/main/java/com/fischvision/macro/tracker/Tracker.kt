package com.fischvision.macro.tracker

import com.fischvision.macro.detector.Detection

/**
 * Rastreador de alvo: suaviza posições e estima velocidade a partir do
 * histórico de [Detection]s (buffer circular, sem alocação por frame — Fase 7).
 *
 * NÃO existe implementação de produção na Fase 1. Não há tracking falso.
 *
 * @status CONTRACT_ONLY
 */
interface Tracker {
    /**
     * Alimenta uma nova detecção. Retorna o [TrackingResult] quando há
     * histórico suficiente; `null` enquanto o alvo está sendo adquirido.
     */
    fun update(detection: Detection): TrackingResult?

    /** Descarta o histórico (perda longa de detecção / nova sessão). */
    fun reset()
}
