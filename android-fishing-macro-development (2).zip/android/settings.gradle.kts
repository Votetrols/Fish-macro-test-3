// ============================================================================
// Fisch Vision Macro — Fase 1 (skeleton compilável)
// Kotlin DSL, sem Groovy, sem módulos adicionais.
// ============================================================================

pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "fisch-vision-macro"
include(":app")
