# Phase 2 Status — Captura Real

## Implementado (fonte real escrita)

- `[IMPLEMENTED / NÃO TESTADO EM DEVICE]` `MediaProjectionFrameSource` — MediaProjection + VirtualDisplay + ImageReader (RGBA_8888, maxImages=2), capacidade 2 + DROP_OLDEST, acquireLatestImage, callback de projeção registrado antes do display (regra API 34+), recriação de pipeline na rotação (0/90/180/270), falhas tipadas (CaptureException) falhando o Flow — nunca engolindo erro.
- `[IMPLEMENTED / NÃO TESTADO EM DEVICE]` `ImageFramePayload` + `RgbaFramePayload` — acesso a pixels RGBA com strides reais, release idempotente e thread-safe.
- `[IMPLEMENTED / NÃO TESTADO EM DEVICE]` `MacroForegroundService` funcional: canal de notificação real, startForeground tipado, consentimento via extras, escopo supervisionado, parada segura completa (fonte, display, reader, projeção, escopo), falha fatal refletida na FSM (FatalError).
- `[IMPLEMENTED]` `CaptureMetrics` (puro) + POST_NOTIFICATIONS (runtime 33+) + fluxo de consentimento na MainActivity.
- `[IMPLEMENTED]` Testes JVM de infraestrutura: payload, métricas, regressão de backpressure do FrameBus (regra de não-regressão da Fase 1).

## Erros tratados (por código, validação em device pendente)

usuário nega consentimento · projeção morta/onStop · falha de VirtualDisplay · falha/OOM de ImageReader · frame sem planos · SecurityException · IllegalStateException · rotação dinâmica · release duplicado (idempotente)

## Testes

```
JVM: CaptureInfraTest — 7 casos escritos (payload/metrics/regressão)
Execução: [BLOCKED] toolchain ausente neste ambiente
Device (start/stop/frame/release/orientação/negativa): [BLOCKED] sem device
```

## Build / Lint / Install

`[BLOCKED]` — idem ambiente (ver PHASE_1_1_VERIFICATION.md). Nada simulado.

## Gate Fase 2

**BLOCKED (execução)** — código real escrito; validação de comportamento exige
device local + `./gradlew test`. Não há funcionalidade simulada nesta fase.
Validação lógica da Fase 3 (visão sobre o contrato real) não é impedida → continuo.
