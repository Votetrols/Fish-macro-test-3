# Phase 6 Status — Integração Completa

## Implementado

- `MacroEngine` (service/) — orquestra `FrameSource → VisionProcessor → trackers → controller → InputController` sob a FSM do serviço; instância única; release de payload em `finally` em qualquer desfecho; hose cut em PAUSED/STOPPED/ERROR; perda de alvos ⇒ `releaseAll` + LOST_DETECTION + reset do controller; dedup de HOLD (sem spam de HOLD_START); FAIL/FSM wiring; telemetria ao overlay.
- `MacroForegroundService` — composição de produção (source real + processador + trackers + controller + dispatcher↔AccessibilityService + overlay + loop de telemetria 2Hz); ACTION_PAUSE/RESUME/STOP; notificação persistente tipada mantida da Fase 2.
- `WindowOverlayManager` — overlay real (TYPE_APPLICATION_OVERLAY), resiliente à ausência de permissão, botões Start/Pause/Resume/Stop delegados ao serviço; `SYSTEM_ALERT_WINDOW` declarada nesta fase.
- MainActivity (Fase 2) já inicia o fluxo completo — a Activity continua descartável.
- Detecção de SUCCESS/FAILED: declarada **NOT_IMPLEMENTED** (sinais calibrados futuros) — nunca fingida.

## Coberturas de lifecycle/recursos (por código; device BLOCKED)

Activity destroyed → serviço segue; Service destroyed → release total; multi-start recusado; escopo cancelado; overlay liberado; payload sempre fechado; hold sempre solto em pause/stop/erro/perda.

## Testes (escritos; execução local BLOCKED)

`IntegrationFlowTest` (5 casos): cadeia completa até HOLD · perda solta e congela comandos · stop prévio emite zero · stop libera hold · pause retoma limpo.
`InputGatingTest` (5 casos — dívida Fase 5): bloqueios fora de CONTROLLING/tracking/conf · limites de taxa e intervalo · releaseAll imune a gate.

## Gate Fase 6

**BLOCKED (execução)** — sem regressão sobre Fases 1–5 (arquivos anteriores não editados exceto serviço/manifest por integração legítima desta fase).
