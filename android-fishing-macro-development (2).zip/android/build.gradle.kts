// ============================================================================
// Fisch Vision Macro — build raiz
// Versões fixas e explícitas (regra: nenhuma versão dinâmica).
// Auditoria de stack: ver PHASE_1_STATUS.md > "Stack Audit".
// ============================================================================

plugins {
    // AGP 9.3.0: dentro do range suportado pelo KGP 2.4.20 (8.5.2–9.3.1).
    id("com.android.application") version "9.3.0" apply false

    // KGP externo fixado em 2.4.20 (stack solicitada).
    // AGP 9 por padrão ativa "built-in Kotlin"; o opt-out documentado está em
    // gradle.properties (android.builtInKotlin=false / android.newDsl=false).
    id("org.jetbrains.kotlin.android") version "2.4.20" apply false
}
