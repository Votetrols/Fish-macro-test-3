# Fisch Vision Macro

Macro Android por **visão computacional** para o minigame de pesca do Fisch (Roblox) —
captura de tela em tempo real, detecção por segmentação de cor, rastreamento preditivo
e toque sintético via Acessibilidade. Kotlin, modular, máquina de estados explícita e
fail-safe em cada camada.

> **Estado atual: FASES 1–6 implementadas em código-fonte; execução/validação BLOCKED
> (sem toolchain no ambiente de origem).** Ver `FINAL_AUDIT.md` (veredito: BLOCKED)
> e os status por fase: `PHASE_1_1_VERIFICATION.md`, `PHASE_2_STATUS.md` … `PHASE_6_STATUS.md`.
> Captura, visão, tracking, controller, gestos e integração foram escritos contra
> APIs oficiais — mas só serão declarados funcionais após o runbook local passar.

---

## Arquitetura

Aprovada na Fase 0. A direção de dependência é sempre `UI → Core → Contracts → Implementations`:

```
MediaProjection (Fase 2)
   ↓
FrameSource → FrameBus → VisionProcessor → Detector → Tracker
                                                        ↓
                                              Controller → InputController
                                                        ↓
                                          AccessibilityService (Fase 9)
```

Pacotes (`com.fischvision.macro.*`): `app`, `core`, `capture`, `vision`, `detector`,
`tracker`, `controller`, `input`, `service`, `accessibility`, `overlay`, `settings`, `debug`.

## Stack (auditada — 2026)

| Componente | Versão | Nota |
|---|---|---|
| Kotlin (KGP) | 2.4.20 | estável atual; externo via opt-out do built-in Kotlin do AGP 9 |
| Android Gradle Plugin | 9.3.0 | dentro do range do KGP 2.4.20 (8.5.2–9.3.1) |
| Gradle | 9.5.0 | range KGP 7.6.3–9.7.0; mínimo AGP 9.x é 9.1.0 |
| JDK | 17 | mínimo exigido pelo AGP 9 |
| compileSdk / targetSdk | 37 | Android 17 estável (SDK Platform 37 necessária) |
| minSdk | 26 | cobre dispatchGesture e ~95% dos aparelhos ativos |

## Como compilar

Pré-requisitos: JDK 17, Android SDK Platform 37, Android Studio Rabbit 1 (2026.2.1+) ou Gradle 9.5.0 local.

```bash
# uma única vez, se o wrapper ainda não existir:
gradle wrapper --gradle-version 9.5.0 --distribution-type bin

./gradlew clean
./gradlew assembleDebug
```

## Como executar os testes

```bash
./gradlew test          # unitários JVM (núcleo puro, sem device)
./gradlew lint          # análise estática
./gradlew installDebug  # com device/emulador conectado
```

## O que a Fase 1 FAZ

- Compila e instala um app real com `MainActivity` funcional.
- Máquina de estados determinística completa (11 estados, 14 eventos), com testbench na tela.
- `FrameBus` real com política de conflação documentada e testada ("latest wins", DROP_OLDEST).
- Contratos reais de capture/vision/detector/tracker/controller/input/overlay.
- `MacroForegroundService` e `MacroAccessibilityService` declarados corretamente, com ciclo de vida seguro.
- `DebugLogger` real (Logcat) por categoria.
- Testes unitários com comportamento verificável (sem `assertTrue(true)`).

## O que a Fase 1 NÃO FAZ

- Não captura tela (MediaProjection é Fase 2).
- Não detecta barra/peixe/indicador (Fases 4–6).
- Não rastreia nem prediz (Fase 7).
- Não controla nem envia gestos (Fases 8–9).
- Não tem overlay, notificação de FGS ou automação do Fisch.

## Próximas fases

2. Captura de tela (consentimento MediaProjection + ImageReader)
3. Visualização da captura
4–6. Detectores
7. Tracking
8. Controlador
9. Input via Acessibilidade
10. Foreground Service (orquestração)
11. Overlay
12. Integração
13. Testes + otimização
