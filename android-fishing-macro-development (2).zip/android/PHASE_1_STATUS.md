# Phase 1 Status

> Gerado junto ao código-fonte. Convenção de status: `[IMPLEMENTED]`, `[TESTED]`,
> `[VERIFIED]`, `[SCAFFOLD_ONLY]`, `[CONTRACT_ONLY]`, `[NOT_IMPLEMENTED]`, `[BLOCKED]`.
> "VERIFIED/TESTED" exigem execução — e a execução local está BLOCKED neste ambiente
> (ver seção Build). Fonte escrita ≠ comportamento confirmado.

## Stack Audit (regra: não trocar versão silenciosamente)

| Solicitado | Realidade verificada (fonte oficial, 2026) | Decisão |
|---|---|---|
| Kotlin 2.4.20 | Existe — estável atual (kotlinlang.org) | MANTIDO |
| AGP 9.3.0 | Existe; range oficial do KGP 2.4.20 é 8.5.2–9.3.1 | MANTIDO |
| Gradle 9.5.0 | Dentro do range KGP 2.4.20 (7.6.3–9.7.0); AGP 9 exige ≥ 9.1 | MANTIDO |
| JDK 17 | Mínimo do AGP 9 | MANTIDO |
| compileSdk / targetSdk 37 | Android 17 estável (developer.android.com/about/versions/17) | MANTIDO (exige SDK Platform 37 local) |
| "Ativar Kotlin Android" | AGP 9 ativa Kotlin embutido por padrão | **AJUSTE REGISTRADO**: opt-out documentado `android.builtInKotlin=false` + `android.newDsl=false` para KGP externo 2.4.20 previsível; migrar antes do AGP 10 |

## Implemented (fonte real escrita; compilação pendente de execução local)

- `[IMPLEMENTED]` Gradle Kotlin DSL: `settings.gradle.kts`, `build.gradle.kts` raiz, `app/build.gradle.kts`, `gradle.properties`, `gradle-wrapper.properties` — versões fixas, sem ranges dinâmicos.
- `[IMPLEMENTED]` `AndroidManifest.xml` — permissões mínimas desta fase; FGS com tipo `mediaProjection`; AccessibilityService com `BIND_ACCESSIBILITY_SERVICE` + config XML.
- `[IMPLEMENTED]` `MainActivity` — testbench local da FSM (sem captura, sem permissões, sem gestos).
- `[IMPLEMENTED]` `FischVisionApplication`, `DebugLogger` (Logcat real, 9 categorias).
- `[IMPLEMENTED]` `MacroStateMachine` — 11 estados × 14 eventos, determinística, transições inválidas rejeitadas com registro.
- `[IMPLEMENTED]` `FrameBus` — conflação DROP_OLDEST documentada (replay 1 + buffer 1 = máx. 2 frames).
- `[IMPLEMENTED]` `MacroSettings` — defaults conservadores declarados como não validados.
- `[IMPLEMENTED]` `MacroAccessibilityService` — lifecycle estrutural, instanciável, sem gestos (eventos ignorados por design).

## Scaffold Only

- `[SCAFFOLD_ONLY]` `MacroForegroundService` — ciclo de vida seguro; não iniciado pela app; sem notificação; sem orquestração.
- `[SCAFFOLD_ONLY]` Gradle wrapper: `gradle-wrapper.properties` pronto; **jar + gradlew(.bat) não embutidos** (artefatos binários/gerados) — gerar com `gradle wrapper --gradle-version 9.5.0` ou via Android Studio.

## Contract Only / Not Implemented

- `[CONTRACT_ONLY]` `Frame`/`FramePayload`, `FrameSource`, `VisionProcessor`/`VisionResult`, `Detection` (com invariantes validadas no construtor), `Detector`, `Tracker`/`TrackingResult`, `Controller`/`ControlCommand`, `InputController`/`InputCommand`, `OverlayManager`.
- `[NOT_IMPLEMENTED]` MediaProjection/captura (Fase 2), visão computacional (4–6), tracking/EMA/predição (7), controlador real (8), `dispatchGesture` (9), notificação FGS (10), overlay real (11), integração (12), OpenCV (não planejado para a v1), DataStore da tela de configurações (12).

## Tests

Escritos (comportamento real, sem `assertTrue(true)`):

- `MacroStateMachineTest` — 16 casos: fluxos válidos, pausa/retomada, E os 3 testes de segurança obrigatórios (seção 23): FatalError→ERROR de múltiplos estados; Stop bloqueia qualquer processamento futuro; ProjectionStopped desarma para IDLE.
- `FrameBusTest` — 6 casos: frame mais recente, ausência de acúmulo (replayCache==1 após 10k frames), consumidor lento conflado, cancelamento, lifecycle da FakeFrameSource.
- `ContractsTest` — 12 casos: defaults de settings, invariantes de `Detection`, tabela do `ScriptedFakeController`, recepção de comandos pelo `FakeInputController`, metadados de `Frame`.
- `MainActivitySmokeTest` (androidTest) — 1 caso, requer device.

Execução local (comandos e resultados):

```
COMMAND...........: ./gradlew test / lint / assembleDebug / installDebug
RESULT............: NÃO EXECUTADO — [BLOCKED]
ROOT CAUSE........: este ambiente de produção não possui JDK/Android SDK/Gradle;
                    a única pipeline disponível aqui empacota a documentação web
FIX APPLIED.......: código-fonte escrito estritamente contra APIs verificadas;
                    fakes confinados ao test source set; núcleo 100% JVM-testável
RETEST RESULT.....: PENDENTE — executar localmente (runbook no README.md)
```

## Build

`[BLOCKED]` — ver tabela acima. Nenhum resultado foi fabricado; nenhum log de build foi simulado.

## Install

`[BLOCKED]` — sem device/emulador no ambiente. Critério de aceitação local: app instala,
abre mostrando `IDLE`, e o testbench despacha eventos sem crash.

## Known Limitations

- Wrapper jar/scripts ausentes (geração local documentada).
- UI mínima programática, sem tema Material/AppCompat (decisão de dependências mínimas).
- Ícone é o placeholder do framework (`sym_def_app_icon`) até os assets das fases de UI.
- `FrameAvailable` na FSM é ack preservador de estado (payload chega na Fase 2) — comportamento declarado, não fingimento de captura.
- Opt-out do built-in Kotlin do AGP 9 é temporário (removido no AGP 10).

## Phase 2 Prerequisites

1. `gradle wrapper --gradle-version 9.5.0` (ou abrir no Android Studio 2026.2.1+).
2. `./gradlew test lint assembleDebug installDebug` verdes em device real.
3. Aprovação formal da Fase 1 (gate A–O executado localmente).
4. Device Android 12+ com Roblox instalado para os primeiros frames.
5. Decisão registrada sobre escopo de resolução de captura (960×540 paisagem default).

## STATUS FINAL DA FASE 1

**BLOCKED** — fonte completa escrita e auditável; execução (gates A–F) exige toolchain
Android local ausente neste ambiente. Não é "APPROVED" por definição da regra 32.
