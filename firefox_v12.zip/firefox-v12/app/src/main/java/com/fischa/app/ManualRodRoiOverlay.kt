package com.fischa.app

import android.content.Context
import com.fischa.app.ui.DiagnosticsLog
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min

/**
 * Full-screen, touchable calibration overlay for the rod/cast button ROI.
 * The rectangle is moved by dragging its center; SAVE persists normalized coordinates.
 * It is intentionally only available during calibration, never while fishing.
 */
class ManualRodRoiOverlay(
    private val context: Context,
    private val initialX: Float,
    private val initialY: Float,
    private val initialW: Float,
    private val initialH: Float,
    private val onSave: (x: Float, y: Float, w: Float, h: Float) -> Unit,
    private val onCancel: () -> Unit,
) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    private var view: RoiView? = null
    private var params: WindowManager.LayoutParams? = null

    fun show() {
        if (view != null || wm == null) return
        val v = RoiView(context)
        view = v
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START }
        params = p
        runCatching { wm.addView(v, p) }.onFailure { view = null; params = null }
    }

    fun hide() {
        val v = view ?: return
        view = null
        params = null
        runCatching { wm?.removeViewImmediate(v) }
    }

    private inner class RoiView(context: Context) : View(context) {
        private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 5f
            color = Color.rgb(0, 230, 118)
        }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = 0x2200E676
        }
        private val panel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = 0xCC101010.toInt()
        }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 34f
        }
        private val button = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = 0xFF1B5E20.toInt()
        }
        private val cancelButton = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = 0xFF424242.toInt()
        }

        private enum class TouchMode { NONE, MOVE, RESIZE }

        private var rect = RectF()
        private var mode = TouchMode.NONE
        private var downX = 0f
        private var downY = 0f
        private var startL = 0f
        private var startT = 0f
        private var startW = 0f
        private var startH = 0f

        private fun nearResizeHandle(x: Float, y: Float): Boolean =
            kotlin.math.hypot(
                (x - rect.right).toDouble(),
                (y - rect.bottom).toDouble(),
            ) <= 64.0

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            if (width <= 0 || height <= 0) return
            if (rect.isEmpty) {
                // Config stores left/top + normalized width/height. Convert directly to pixels.
                val w = (width * initialW.coerceIn(0.08f, 0.55f)).coerceAtLeast(80f)
                val h = (height * initialH.coerceIn(0.08f, 0.55f)).coerceAtLeast(80f)
                val left = (initialX.coerceIn(0f, 1f) * width).coerceIn(0f, width - w)
                val top = (initialY.coerceIn(0f, 1f) * height).coerceIn(112f, height - h)
                rect.set(left, top, left + w, top + h)
            }

            c.drawRect(rect, fill)
            c.drawRect(rect, border)
            // Bottom-right handle makes the ROI resizable without changing its normalized contract.
            c.drawCircle(rect.right, rect.bottom, 22f, border)

            val panelH = 112f
            c.drawRect(0f, 0f, width.toFloat(), panelH, panel)
            text.textSize = 32f
            c.drawText("Mova o quadrado até o botão VARAR", 24f, 42f, text)
            text.textSize = 24f
            c.drawText("Arraste o centro; use o canto verde para redimensionar. SALVAR.", 24f, 78f, text)

            val save = RectF(width - 260f, 18f, width - 135f, 94f)
            val cancel = RectF(width - 120f, 18f, width - 20f, 94f)
            c.drawRoundRect(save, 14f, 14f, button)
            c.drawRoundRect(cancel, 14f, 14f, cancelButton)
            text.textSize = 23f
            c.drawText("SALVAR", save.left + 15f, save.centerY() + 8f, text)
            c.drawText("X", cancel.left + 38f, cancel.centerY() + 8f, text)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (width <= 0 || height <= 0) return true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startL = rect.left; startT = rect.top
                    startW = rect.width(); startH = rect.height()
                    val save = RectF(width - 260f, 18f, width - 135f, 94f)
                    val cancel = RectF(width - 120f, 18f, width - 20f, 94f)
                    if (save.contains(e.x, e.y)) {
                        persist()
                        return true
                    }
                    if (cancel.contains(e.x, e.y)) {
                        onCancel(); hide(); return true
                    }
                    mode = when {
                        nearResizeHandle(e.x, e.y) -> TouchMode.RESIZE
                        rect.contains(e.x, e.y) -> TouchMode.MOVE
                        else -> TouchMode.NONE
                    }
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    when (mode) {
                        TouchMode.MOVE -> {
                            val l = (startL + dx).coerceIn(0f, width - rect.width())
                            val t = (startT + dy).coerceIn(112f, height - rect.height())
                            rect.offsetTo(l, t)
                            invalidate()
                        }
                        TouchMode.RESIZE -> {
                            val minW = max(80f, width * 0.08f)
                            val minH = max(80f, height * 0.08f)
                            val newW = (startW + dx).coerceIn(minW, width - startL)
                            val newH = (startH + dy).coerceIn(minH, height - startT)
                            rect.set(startL, startT, startL + newW, startT + newH)
                            invalidate()
                        }
                        TouchMode.NONE -> Unit
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mode = TouchMode.NONE
                    return true
                }
            }
            return true
        }

        private fun persist() {
            val w = rect.width().coerceAtLeast(1f)
            val h = rect.height().coerceAtLeast(1f)
            val x = rect.left / width.toFloat()
            val y = rect.top / height.toFloat()
            val nw = w / width.toFloat()
            val nh = h / height.toFloat()
            // Persist only a complete normalized rectangle. The core also validates these bounds
            // before a session starts, so malformed preferences cannot silently expand the search.
            val valid = x.isFinite() && y.isFinite() && nw.isFinite() && nh.isFinite() &&
                x >= 0f && y >= 0f && nw in 0.02f..1f && nh in 0.02f..1f &&
                x + nw <= 1.0001f && y + nh <= 1.0001f
            if (!valid) {
                DiagnosticsLog.event("CALIBRATION", "ROI VARAR rejeitada: retângulo normalizado inválido")
                return
            }
            onSave(x.coerceIn(0f, 1f), y.coerceIn(0f, 1f), nw, nh)
            hide()
        }
    }
}
