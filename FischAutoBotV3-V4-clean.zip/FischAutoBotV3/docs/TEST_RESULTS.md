# Resultados de verificação — build Galaxy A22 (0.2.0-a22)

Ambiente: Linux x86_64, 2 vCPU / 2 GB RAM, JDK 17 (Temurin 17.0.20.1), Android SDK
(platforms;android-35, build-tools;35.0.0), Gradle 8.9 (wrapper), AGP 8.7.3, Kotlin 2.0.21.
**Nenhum dispositivo Android e nenhum Roblox foram usados.**

## Build (executado, não presumido)

```
./gradlew :app:assembleDebug        → BUILD SUCCESSFUL
app/build/outputs/apk/debug/app-debug.apk   3 386 602 bytes
aapt dump badging: package='com.fischa.app' versionCode='2' versionName='0.2.0-a22'
                   sdkVersion 26, targetSdkVersion 35, compileSdk 35
apksigner verify --print-certs: assinatura debug válida (CN=Android Debug)
sha256: 2f46197c338cb7d4f17d49f301d432731451fe08d864c821bcd22348fe43f2f8
```

Erro de compilação corrigido no caminho: `MainActivity.kt` — `Switch`/`SwitchCompat` (único erro
do módulo `app`; o `core` já compilava).

## Testes JUnit do core — `./gradlew :core:test` → 57 testes, 0 falhas

| Classe | Testes | Cobre (spec §15) |
|---|---|---|
| `CoordinateMapperTest` | 8 | coordenadas normalizadas; conversão captura → toque (A22 1600×720, 720×1600, A22 5G); rejeição de pontos inválidos; detecção de aspecto incompatível |
| `RobloxForegroundDetectorTest` | 12 | Roblox fullscreen sem root (cenário da falha real); Activity de outro app substitui; janela viva de outro app bloqueia; evento legado expirado; overlay/IME; acessibilidade indisponível; tela desligada |
| `InputSafetyGuardTest` | 5 | todas as condições de bloqueio: macro/realInput/captura/Roblox/foreground/overlay/estado/tracking/controller; **frame stale**; **confidence baixa**; coordenadas/duração inválidas; emergência; rate limit |
| `EmergencyStopAndInputGateTest` | 6 | Emergency Stop (latch único, listeners, clear); pipeline chama `cancelAll`+`releaseAll` na emergência e no disarm; com `realInput=OFF` o executor nunca recebe tap/hold; pipeline publica blockReason e frame age |
| `GestureLeaseTest` | 3 | tap / holdStart / holdExtend / holdRelease / cancelAll; expiração de lease e watchdog; hold infinito rejeitado |
| `ControllersTest` | 10 | controller P-D: deadband → nada; erro grande → HOLD_START/EXTEND/RELEASE; peixe à esquerda → só deriva; erro pequeno → tap curto; hold máximo finito; confiança baixa → release; CastController (START/EXTEND/RELEASE no centro detectado, release ao perder botão); ShakeController (centro detectado, segue quando move, nunca sem detecção) |
| `TrackersTest` | 6 | FishTracker (velocidade, predição, coasting em oclusão curta, *lost* após `fishMaxLostMs`, clamp); PlayerBarTracker (bordas, perda); BarTracker (histerese); ConfidenceTracker |
| `FishingStateMachineTest` | 2 | ciclo completo com confirmação visual e recuperação; timeout de confirmação não assume captura |
| `AppConfigTest` / `FrameBufferTest` | 3 / 2 | config round-trip e limites; buffer latest-only sem bloqueio do produtor |

## SelfTest do core — `./gradlew :core:selfTest` → `75 checks, 0 failures`

Harness determinístico já existente (config, geometria, trackers, controlador, guard, FSM,
simulação de malha fechada). Inalterado e passando após as modificações.

## O que NÃO foi executado (explicitamente)

* **ReplayMain** contra os 206 frames do vídeo de referência: o zip fornecido contém apenas
  `testdata/gt.csv` e `testdata/meta.txt`; a pasta `testdata/frames` **não veio no pacote**.
  Não há resultado de replay nesta rodada.
* **Testes instrumentados / em aparelho** (`GestureService`, `ScreenCaptureSource`,
  `GameAccessibilityService`, `DebugOverlay`, `MainActivity`): sem emulador/dispositivo neste
  ambiente. A lógica de plataforma foi revisada e compilada, mas só o teste no A22 valida:
  - cópia de pixels RGBA do `ImageReader` (ordem de bytes, `rowStride`);
  - precisão do toque (`[INPUT] TAP n=(…) px=(…)` no log vs. posição visual);
  - comportamento do `continueStroke` como hold contínuo no Roblox;
  - verificação de Activity do Roblox pelo `PackageManager` (classe esperada:
    `com.roblox.client.ActivityNativeMain` ou similar — aparece em `[SAFETY] activity changed:`).
* **Roblox/Fisch real**: não executado por decisão da especificação (§18).
