# Instalação e primeiro teste no Samsung Galaxy A22

APK: `app-debug.apk` (debug, assinado com chave debug, `com.fischa.app`, 0.2.0-a22).

## 1. Instalar

**Via cabo (recomendado para ver logs):**
1. Ajustes → Sobre o telefone → Informações do software → toque 7× em "Número da versão".
2. Ajustes → Opções do desenvolvedor → ative **Depuração USB**.
3. No PC: `adb install -r app-debug.apk`
4. Logs em tempo real: `adb logcat -s FischAuto Fisch/SAFETY Fisch/INPUT Fisch/DEBUG`

**Sem cabo:** copie o APK para o aparelho, abra pelo "Meus Arquivos", permita "Instalar apps
desconhecidos" para o Meus Arquivos quando pedido. Se já existir uma versão antiga assinada com
outra chave, desinstale-a antes.

## 2. Configurar (uma vez)

1. Abra **Fisch AutoBot V3** → aceite a permissão de notificações.
2. Toque em **Habilitar / revisar serviço de acessibilidade** → Apps instalados → **Fisch AutoBot
   Input** → ativar → confirmar. (One UI pode exigir "Permitir configurações restritas" em
   Ajustes → Apps → Fisch AutoBot V3 → ⋮ → *Permitir configurações restritas*, porque o APK é
   sideload.)
3. Ajustes → Apps → Fisch AutoBot V3 → Bateria → **Sem restrições** (evita o One UI matar o
   serviço em primeiro plano).
4. Recomendado: desligue o **Game Booster / Game Launcher** para o Roblox ou pelo menos a bolha
   de "Game Tools" flutuante (ela pode virar janela ativa e bloquear o input por
   `INCOMPATIBLE_OVERLAY`).
5. Mantenha o aparelho com **rotação automática** no modo em que vai jogar; mudar a orientação
   durante a sessão encerra o macro em estado seguro (precisa de novo START).

## 3. Sequência de teste sugerida (sem input real primeiro)

1. Na tela inicial do app deixe **"Autorizar gestos reais nesta sessão" DESLIGADO** (padrão).
   Ligue **Overlay de debug**.
2. Toque **START / solicitar captura de tela** → "Iniciar agora" na caixa do sistema (no Android
   14 escolha **Tela inteira**).
3. Vá para o Roblox e abra o Fisch. Olhe o overlay (ou volte ao app):
   - `Roblox: YES | package=com.roblox.client` e `Fonte: ACTIVE_WINDOW / ROOT / ACTIVITY`;
   - `Input autorizado: YES`, `Bloqueio: NONE` (com realInput OFF o overlay mostra
     `Safety: BLOCKED REAL_INPUT_DISABLED` — correto, é simulado);
   - FPS/proc ms/frame age (esperado no A22: 15–30 FPS, proc < 50 ms, frame age < 120 ms);
   - caixas: vermelha = botão da vara, magenta = Shake, ciano = barra, branca = bloco do jogador,
     amarela = peixe, verde = progresso.
4. Se `Roblox: NO`, anote **package / Fonte / Bloqueio** mostrados e envie o log
   (`adb logcat -s Fisch/SAFETY` ou o arquivo `Android/data/com.fischa.app/files/fisch-log.txt`
   — acessível via `adb shell run-as com.fischa.app cat files/fisch-log.txt`).
5. Só quando a detecção e as caixas estiverem corretas: STOP → ligue **Autorizar gestos reais
   nesta sessão** → START → confirme o diálogo. A entrada real continua passando por todas as
   verificações do SafetyGuard a cada gesto.

## 4. Parar / emergência

* Notificação "Fisch AutoBot V3 ativo" → **EMERGÊNCIA**: cancela e libera todos os gestos, trava
  o sistema (latch). Também há botão na tela inicial.
* Para voltar a usar depois de uma emergência (ou depois de a captura ser interrompida pelo
  sistema): toque **Limpar latch de emergência** e depois START novamente.
* **STOP** encerra a sessão sem travar o latch.

## 5. Parâmetros úteis (tela inicial → "Salvar parâmetros", aplicados no próximo START)

| Chave | Padrão | Quando mexer |
|---|---|---|
| `capture.processingWidth` | 640 | reduzir para 560 se `proc` > 60 ms constante |
| `capture.targetFps` | 30 | 24 para poupar bateria; a taxa já cai sozinha se o processamento não acompanhar |
| `safety.maxFrameAgeMs` | 180 | subir para 220 apenas se aparecer `FRAME_STALE` com frame age baixo |
| `cast.holdMs` | 3000 | duração do segurar no botão da vara |
| `control.kP / kFF / deadband` | 4.2 / 1.15 / 0.030 | ajuste fino do minigame |
