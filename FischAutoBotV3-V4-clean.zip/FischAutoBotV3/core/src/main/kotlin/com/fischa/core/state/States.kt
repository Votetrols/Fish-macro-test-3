package com.fischa.core.state

/** Explicit, evidence-driven states (spec §11). No implicit timers anywhere. */
enum class FishingState {
    IDLE,
    SEARCH_FISHING_BUTTON,
    CASTING,
    SEARCHING_SHAKE,
    PRESSING_SHAKE,
    FISHING_MINIGAME_DETECTED,
    TRACKING_FISH,
    CONTROLLING_PLAYER_BAR,
    CATCH_CONFIRMATION,
    RESET,

    // error / safety states
    VISION_LOST,
    CAPTURE_ERROR,
    ROBLOX_NOT_DETECTED,
    INVALID_STATE,
    EMERGENCY_STOP,
    ;

    val isError: Boolean
        get() = this == VISION_LOST || this == CAPTURE_ERROR || this == ROBLOX_NOT_DETECTED ||
                this == INVALID_STATE || this == EMERGENCY_STOP

    /** States where the macro may issue game input at all. */
    val actionable: Boolean
        get() = this == CASTING || this == PRESSING_SHAKE || this == FISHING_MINIGAME_DETECTED ||
            this == TRACKING_FISH || this == CONTROLLING_PLAYER_BAR

    /** States where the controller (minigame loop) runs. */
    val controlling: Boolean
        get() = this == FISHING_MINIGAME_DETECTED || this == TRACKING_FISH || this == CONTROLLING_PLAYER_BAR
}

/** Events that may drive transitions; every field is measured, never assumed. */
data class StateEvidence(
    val fishingButton: Boolean,
    val fishingButtonConf: Float,
    val shake: Boolean,
    val shakeConf: Float,
    /** shake box center moved by > threshold since our last tap attempt */
    val shakeMoved: Boolean,
    /** minigame bar detected in this frame */
    val bar: Boolean,
    val barConf: Float,
    /** progress bar present and increasing */
    val progressPresent: Boolean,
    val progressValue: Float,
    /** catch confirmation (fish name text) visible */
    val catchConfirm: Boolean,
    val catchConfirmConf: Float,
    /** Roblox foreground (activity) reported by the platform */
    val robloxForeground: Boolean,
    /** capture pipeline is producing frames */
    val captureHealthy: Boolean,
    /** aggregate vision trust */
    val globalConfidence: Float,
    /** tracking of fish/player usable */
    val trackingOk: Boolean,
    val frameDeltaMs: Float,
)

class StateChange(val from: FishingState, val to: FishingState, val reason: String, val timestampNs: Long)
