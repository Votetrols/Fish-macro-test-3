package com.fischa.core.pipeline

import com.fischa.core.control.ControlAction
import com.fischa.core.safety.RobloxForegroundStatus
import com.fischa.core.state.FishingState
import com.fischa.core.vision.DetSnapshot

/**
 * Platform signals for one captured frame. [currentTimeNs] must use the same monotonic clock
 * as [frameTimestampNs]; replay defaults to the frame timestamp, Android supplies now() so
 * stale frames are rejected before an input command.
 */
class PipelineInput(
    var frameTimestampNs: Long = 0L,
    var currentTimeNs: Long = frameTimestampNs,
    var captureHealthy: Boolean = false,
    var robloxDetected: Boolean = false,
    var inputAuthorized: Boolean = false,
    var overlaySuspected: Boolean = false,
    var macroEnabled: Boolean = false,
    /** Explicit, session-scoped user opt-in. False in all defaults and replay runs. */
    var realInputEnabled: Boolean = false,
    var foregroundPackage: String = RobloxForegroundStatus.UNKNOWN,
    var foregroundActivityWindow: String = RobloxForegroundStatus.UNKNOWN,
    var foregroundBlockReason: String = "FOREGROUND_UNKNOWN",
    var foregroundTimestampMs: Long = 0L,
)

class PipelineOutput {
    // detection snapshots (owned instances — read before next call or copy)
    val fishingButton = DetSnapshot()
    val shake = DetSnapshot()
    val bar = DetSnapshot()
    val player = DetSnapshot()
    val fish = DetSnapshot()
    val progress = DetSnapshot()
    val catchConfirm = DetSnapshot()

    var state: FishingState = FishingState.IDLE
    var stateReason: String = ""

    var fishXNorm = 0f
    var playerXNorm = 0f
    var errorNorm = 0f
    var fishVel = 0f
    var playerVel = 0f
    var desiredVel = 0f
    var progressValue = 0f
    var progressRate = 0f
    var globalConfidence = 0f
    var frameAgeMs = Long.MAX_VALUE

    /** the control action the controller *intends*; executed only if safety allows */
    var intendedAction: ControlAction = ControlAction.NONE
    var tapDurationMs = 0
    var holdActive = false
    var decisionReason = ""

    var inputIssued = false
    var inputDeniedReason = ""
    var inputAuthorized = false
    var realInputEnabled = false
    var robloxDetected = false
    var foregroundPackage: String = RobloxForegroundStatus.UNKNOWN
    var foregroundActivityWindow: String = RobloxForegroundStatus.UNKNOWN
    var foregroundBlockReason: String = "FOREGROUND_UNKNOWN"
    var emergencyLatched = false
    var armed = false
    var shakeSessionTaps = 0
    var shakeSession = 0
    var castPhase = ""

    // pixel-space helpers for the harness/tests (processing coordinates)
    val barRectPx = FloatArray(4)
    var barLocked = false
    var blockCenterPx = -1f
    var fishCenterPx = -1f
}
