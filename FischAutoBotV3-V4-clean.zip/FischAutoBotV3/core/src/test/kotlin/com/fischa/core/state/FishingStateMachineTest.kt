package com.fischa.core.state

import com.fischa.core.config.AppConfig
import org.junit.Assert.*
import org.junit.Test

class FishingStateMachineTest {
    private fun evidence(now: Long, block: Evidence.() -> Unit = {}) = Evidence().apply {
        robloxForeground = true
        captureHealthy = true
        globalConf = .9f
        nowNs = now
        block()
    }

    @Test fun fullCycleRequiresVisualCatchConfirmationAndRecovery() {
        val machine = FishingStateMachine(AppConfig.StateTiming())
        machine.armed = true
        var time = 0L
        fun step(block: Evidence.() -> Unit = {}) {
            machine.update(evidence(time, block))
            time += 33_000_000L
        }
        step { fishingButton = true }
        step { fishingButton = true }
        assertEquals(FishingState.CASTING, machine.state)
        step { shake = true; shakeConf = .9f }
        assertEquals(FishingState.SEARCHING_SHAKE, machine.state)
        step { shake = true; shakeConf = .9f }
        assertEquals(FishingState.PRESSING_SHAKE, machine.state)
        repeat(3) { step { bar = true; barConf = .9f } }
        assertEquals(FishingState.FISHING_MINIGAME_DETECTED, machine.state)
        step { bar = true; barConf = .9f; fishOk = true; playerOk = true }
        assertEquals(FishingState.TRACKING_FISH, machine.state)
        step { bar = true; barConf = .9f; fishOk = true; playerOk = true }
        assertEquals(FishingState.CONTROLLING_PLAYER_BAR, machine.state)
        repeat(7) { step { bar = true; barConf = .9f; progress = .9f; fishOk = true; playerOk = true } }
        repeat(6) { step { progress = .9f } }
        assertEquals(FishingState.CATCH_CONFIRMATION, machine.state)
        step { catchConfirm = true; catchConfirmConf = .9f }
        assertEquals(FishingState.RESET, machine.state)
        repeat(40) {
            if (machine.state != FishingState.SEARCH_FISHING_BUTTON) step { fishingButton = true }
        }
        assertEquals(FishingState.SEARCH_FISHING_BUTTON, machine.state)
    }

    @Test fun confirmationTimeoutDoesNotAssumeCatchOrImmediatelyRecast() {
        val timing = AppConfig.StateTiming(confirmWindowMs = 200, catchMinProgress = .3f)
        val machine = FishingStateMachine(timing)
        machine.armed = true
        var time = 0L
        fun step(block: Evidence.() -> Unit = {}) {
            machine.update(evidence(time, block))
            time += 33_000_000L
        }
        step { fishingButton = true }; step { fishingButton = true }
        step { shake = true; shakeConf = .9f }; step { shake = true; shakeConf = .9f }
        repeat(3) { step { bar = true; barConf = .9f } }
        step { bar = true; barConf = .9f; fishOk = true; playerOk = true }
        step { bar = true; barConf = .9f; fishOk = true; playerOk = true }
        repeat(7) { step { bar = true; barConf = .9f; progress = .8f; fishOk = true; playerOk = true } }
        repeat(6) { step { progress = .8f } }
        assertEquals(FishingState.CATCH_CONFIRMATION, machine.state)
        repeat(8) { step() }
        assertEquals(FishingState.VISION_LOST, machine.state)
    }
}
