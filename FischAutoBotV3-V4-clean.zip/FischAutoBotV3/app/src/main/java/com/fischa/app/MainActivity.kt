package com.fischa.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings as AndroidSettings
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.fischa.core.config.AppConfig

/** UI actions are explicit; no real input is authorized by default. */
class MainActivity : Activity() {
    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var realInputSwitch: Switch
    private lateinit var verboseSwitch: CheckBox
    private lateinit var debugSwitch: CheckBox
    private val fields = linkedMapOf<String, android.widget.EditText>()
    private val handler = Handler(Looper.getMainLooper())
    private var pendingRealInput = false
    private var overlayEnabled = false

    private val refresh = object : Runnable {
        override fun run() {
            val s = FischEngineService.status
            statusView.text = buildString {
                val live = GameAccessibilityService.latestForegroundStatus()
                val acc = if (GameAccessibilityService.instance != null) "ON" else "OFF"
                append("Acessibilidade: $acc | Roblox: ${if (s.running) s.robloxDetected else live.robloxDetected} | package: ${if (s.running) s.foregroundPackage else live.foregroundPackage}\n")
                append("Fonte: ${if (s.running) s.evidenceSource else live.evidenceSource} | Input autorizado: ${if (s.inputAuthorized) "YES" else "NO"} | realInput: ${if (s.realInputEnabled) "ON" else "OFF"}\n")
                append("Janela/activity: ${if (s.running) s.foregroundActivityWindow else live.foregroundActivityWindow}\n")
                append("Bloqueio: ${if (s.running) s.foregroundBlockReason else live.blockReason} | idade status: ${if (s.foregroundAgeMs == Long.MAX_VALUE) "-" else s.foregroundAgeMs.toString()} ms\n")
                append("Captura: ${s.running} | estado: ${s.state} | FPS: ${"%.1f".format(s.fps)} | proc: ${"%.1f".format(s.procMs)} ms | frame age: ${s.frameAgeMs} ms\n")
                append("Barra: ${s.barLocked} | confiança global: ${"%.2f".format(s.globalConf)} | descartados: ${s.droppedFrames} | gated: ${s.gatedFrames}\n")
                if (s.geometry.isNotEmpty()) append("Geometria: ${s.geometry}\n")
                if (s.emergency) append("EMERGENCY STOP LATCHED — limpe explicitamente antes de iniciar\n")
                if (s.denyReason.isNotEmpty()) append("Safety/Input: ${s.denyReason}\n")
                append(s.message)
            }
            logView.text = s.lastLogLine.ifEmpty { "Aguardando diagnóstico [SAFETY]." }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val padding = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }
        setContentView(ScrollView(this).apply { addView(root) })
        root.setOnApplyWindowInsetsListener { view, insets ->
            @Suppress("DEPRECATION")
            view.setPadding(
                padding + insets.systemWindowInsetLeft,
                padding + insets.systemWindowInsetTop,
                padding + insets.systemWindowInsetRight,
                padding + insets.systemWindowInsetBottom,
            )
            insets
        }
        fun text(value: String, size: Float = 16f) = TextView(this).apply {
            text = value
            textSize = size
            root.addView(this)
        }
        fun button(value: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = value; setOnClickListener { action() } })
        }

        text("Fisch AutoBot V3", 26f)
        text("Firefox é a base. Comece em SIMULADO. Input real fica OFF até você ativá-lo explicitamente. Use apenas onde automação seja permitida.")
        statusView = text("Aguardando início")
        button("Habilitar / revisar serviço de acessibilidade") {
            startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        realInputSwitch = Switch(this).apply {
            text = "Autorizar gestos reais nesta sessão (OFF por padrão)"
            isChecked = false
        }
        root.addView(realInputSwitch)
        debugSwitch = CheckBox(this).apply {
            text = "Overlay de debug (não-touchable)"
            isChecked = getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).getBoolean("overlay", false)
            overlayEnabled = isChecked
            setOnCheckedChangeListener { _, enabled ->
                overlayEnabled = enabled
                getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).edit().putBoolean("overlay", enabled).apply()
                startService(Intent(this@MainActivity, FischEngineService::class.java)
                    .setAction(FischEngineService.ACTION_DEBUG_OVERLAY)
                    .putExtra(FischEngineService.EXTRA_DEBUG_ENABLED, enabled))
            }
        }
        root.addView(debugSwitch)
        verboseSwitch = CheckBox(this).apply {
            text = "Log verboso (DEBUG por frame; só para diagnóstico)"
            isChecked = getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).getBoolean("verbose", false)
            setOnCheckedChangeListener { _, enabled ->
                getSharedPreferences("fisch-ui", Context.MODE_PRIVATE).edit().putBoolean("verbose", enabled).apply()
            }
        }
        root.addView(verboseSwitch)
        button("START / solicitar captura de tela") { begin() }
        button("STOP") {
            startService(Intent(this, FischEngineService::class.java).setAction(FischEngineService.ACTION_STOP))
        }
        button("EMERGENCY STOP — cancelar e liberar") {
            startService(Intent(this, FischEngineService::class.java).setAction(FischEngineService.ACTION_EMERGENCY))
        }
        button("Limpar latch de emergência (ação manual; não inicia o macro)") {
            startService(Intent(this, FischEngineService::class.java).setAction(FischEngineService.ACTION_CLEAR_EMERGENCY))
        }
        button("Configurações") { startActivity(Intent(this, SettingsActivity::class.java)) }

        text("Parâmetros core (aplicados no próximo Start)", 20f)
        val config = FischEngineService.loadConfig(this)
        fun field(label: String, key: String, value: String) {
            text(label)
            val edit = android.widget.EditText(this).apply {
                setText(value)
                inputType = android.text.InputType.TYPE_CLASS_TEXT
            }
            fields[key] = edit
            root.addView(edit)
        }
        field("Largura de processamento (A22: 640)", "capture.processingWidth", config.capture.processingWidth.toString())
        field("FPS alvo de captura (A22: 24–30)", "capture.targetFps", config.capture.targetFps.toString())
        field("Kp", "control.kP", config.control.kP.toString())
        field("Kff", "control.kFF", config.control.kFF.toString())
        field("Deadband", "control.deadband", config.control.deadband.toString())
        field("Carga do cast (ms)", "cast.holdMs", config.cast.holdMs.toString())
        field("Hold quantum (30–100 ms)", "safety.holdQuantumMs", config.safety.holdQuantumMs.toString())
        field("Frame age máximo (ms)", "safety.maxFrameAgeMs", config.safety.maxFrameAgeMs.toString())
        button("Salvar parâmetros") { saveConfig() }

        text("Último log do motor", 20f)
        logView = TextView(this).apply {
            textSize = 11f
            movementMethod = ScrollingMovementMethod()
            setPadding(0, padding, 0, 0)
        }
        root.addView(logView)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun saveConfig(): Boolean = try {
        val base = AppConfig().toMap().toMutableMap()
        fields.forEach { (key, edit) -> base[key] = edit.text.toString().trim() }
        val parsed = AppConfig().withOverrides(base).validate()
        val valid = parsed.toMap()
        fields.forEach { (key, edit) ->
            val entered = edit.text.toString().trim().toDoubleOrNull()
                ?: throw IllegalArgumentException("$key precisa ser numérico")
            val applied = valid[key]?.toDoubleOrNull()
                ?: throw IllegalArgumentException("$key não foi reconhecido")
            require(kotlin.math.abs(entered - applied) < 1e-6 || entered == applied) {
                "Valor inválido para $key: ${edit.text}"
            }
        }
        getSharedPreferences("fisch-config", Context.MODE_PRIVATE).edit().apply {
            valid.forEach { (key, value) -> putString(key, value) }
        }.apply()
        Toast.makeText(this, "Configurações salvas; reinicie o motor", Toast.LENGTH_SHORT).show()
        true
    } catch (e: Exception) {
        Toast.makeText(this, "Valor inválido: ${e.message}", Toast.LENGTH_LONG).show()
        false
    }

    private fun begin() {
        if (FischEngineService.status.running) {
            Toast.makeText(this, "Pare a sessão antes de iniciar outra", Toast.LENGTH_SHORT).show()
            return
        }
        if (GameAccessibilityService.instance == null) {
            Toast.makeText(this, "Ative o serviço de acessibilidade primeiro", Toast.LENGTH_LONG).show()
            startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if (!saveConfig()) return
        pendingRealInput = realInputSwitch.isChecked
        if (pendingRealInput) {
            android.app.AlertDialog.Builder(this)
                .setTitle("Confirmar input real")
                .setMessage("Build Galaxy A22 — não testada por nós no Roblox real. Você autoriza gestos reais apenas nesta sessão? O SafetyGuard continua bloqueando fora do Roblox, em frames antigos e com confiança baixa. EMERGÊNCIA fica na notificação.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Autorizar sessão") { _, _ -> requestProjection() }
                .show()
        } else {
            requestProjection()
        }
    }

    private fun requestProjection() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        val intent = if (Build.VERSION.SDK_INT >= 34) {
            manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else manager.createScreenCaptureIntent()
        startActivityForResult(intent, REQUEST_PROJECTION)
    }

    @Deprecated("Activity result retained to keep the capture flow dependency-light")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PROJECTION) return
        if (resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, FischEngineService::class.java)
                    .setAction(FischEngineService.ACTION_START)
                    .putExtra(FischEngineService.EXTRA_RESULT_CODE, resultCode)
                    .putExtra(FischEngineService.EXTRA_RESULT_DATA, data)
                    .putExtra(FischEngineService.EXTRA_REAL_INPUT, pendingRealInput),
            )
            realInputSwitch.isChecked = false
        } else {
            Toast.makeText(this, "Permissão de captura negada", Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        private const val REQUEST_PROJECTION = 77
    }
}
