#!/usr/bin/env bash
# Installs the Android SDK under /home/user/.cache/toolchain (a snapshot-excluded path).
set -uo pipefail
ROOT=/home/user/.cache/toolchain
JAVA_HOME="$ROOT/jdk17"
ANDROID_HOME="$ROOT/android-sdk"
mkdir -p "$ANDROID_HOME/cmdline-tools"
cd "$ROOT"

if [ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  echo "== downloading cmdline-tools =="
  curl -sSL -o cmdtools.zip "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
  unzip -q -o cmdtools.zip -d "$ANDROID_HOME/cmdline-tools"
  mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest" 2>/dev/null || true
  rm -f cmdtools.zip
fi

export JAVA_HOME ANDROID_HOME
export PATH="$JAVA_HOME/bin:$PATH"
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"

echo "== licenses =="
yes | "$SDKM" --sdk_root="$ANDROID_HOME" --licenses >/dev/null 2>&1

echo "== packages =="
"$SDKM" --sdk_root="$ANDROID_HOME" "platform-tools" "platforms;android-35" "build-tools;35.0.0" 2>&1 | tail -6

echo "== DONE =="
ls "$ANDROID_HOME"
