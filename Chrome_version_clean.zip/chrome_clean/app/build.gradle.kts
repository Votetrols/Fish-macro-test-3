plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "br.dev.fischvision"
    compileSdk = 35
    defaultConfig { applicationId = "br.dev.fischvision"; minSdk = 28; targetSdk = 35; versionCode = 1; versionName = "0.1.0-test"; testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner" }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildTypes { release { isMinifyEnabled = false } }
    packaging { jniLibs.useLegacyPackaging = true }
    testOptions { unitTests.isReturnDefaultValues = true }
}
dependencies {
    implementation("org.opencv:opencv:4.10.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    testImplementation("junit:junit:4.13.2")
}
