package br.dev.fischvision.vision

import android.content.Context
import android.graphics.BitmapFactory
import br.dev.fischvision.config.VisionProfile as V
import br.dev.fischvision.model.*
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc

/** Multiscale edge templates. No location is a click target until an actual match exists. */
open class TemplateDetector(
    c: Context,
    override val kind: Kind,
    asset: String,
    private val threshold: Float,
    private val expand: Float = 1f,
) : Detector, AutoCloseable {
    private val original = Mat()
    private val result = Mat()
    private val templates = mutableListOf<Mat>()
    private var lastHeight = 0

    init {
        val b = c.assets.open(asset).use { BitmapFactory.decodeStream(it) }
        val raw = Mat()
        Utils.bitmapToMat(b, raw)
        Imgproc.cvtColor(raw, original, Imgproc.COLOR_RGBA2GRAY)
        Imgproc.Canny(original, original, 50.0, 130.0)
        raw.release()
        b.recycle()
    }

    override fun detect(f: VisionFrame, context: Map<Kind, Detection>): Detection {
        if (lastHeight != minOf(f.width, f.height)) {
            templates.forEach { it.release() }
            templates.clear()
            lastHeight = minOf(f.width, f.height)
            for (scale in V.templateScales) {
                val m = Mat()
                val s = lastHeight / V.referenceShortSide * scale
                Imgproc.resize(
                    original,
                    m,
                    Size(
                        (original.cols() * s).coerceAtLeast(8.0),
                        (original.rows() * s).coerceAtLeast(8.0),
                    ),
                    0.0,
                    0.0,
                    Imgproc.INTER_NEAREST,
                )
                templates.add(m)
            }
        }
        var score = 0.0
        var box: Box? = null
        // Full image search: anchors are not restricted to the recorded location.
        for (template in templates) {
            if (template.cols() >= f.width || template.rows() >= f.height) continue
            Imgproc.matchTemplate(f.edges, template, result, Imgproc.TM_CCOEFF_NORMED)
            val mm = Core.minMaxLoc(result)
            if (mm.maxVal > score) {
                score = mm.maxVal
                box =
                    Box(
                        mm.maxLoc.x.toFloat(),
                        mm.maxLoc.y.toFloat(),
                        (mm.maxLoc.x + template.cols()).toFloat(),
                        (mm.maxLoc.y + template.rows()).toFloat(),
                    )
            }
        }
        if (score < threshold || box == null) return Detection.missing(kind, f.timestamp)
        val b = box
        val cx = b.center.x
        val cy = b.center.y
        val w = b.width * expand
        val h = if (kind == Kind.SHAKE) w else b.height * expand
        val bounds =
            Box(
                (cx - w / 2).coerceAtLeast(0f),
                (cy - h / 2).coerceAtLeast(0f),
                (cx + w / 2).coerceAtMost(f.width.toFloat()),
                (cy + h / 2).coerceAtMost(f.height.toFloat()),
            )
        // Match score is a heuristic, not a calibrated probability.
        return Detection(
            kind,
            bounds,
            (.70f + (score.toFloat() - threshold) * .8f).coerceAtMost(.98f),
            f.timestamp,
        )
    }

    override fun close() {
        original.release()
        result.release()
        templates.forEach { it.release() }
    }
}

class FishingButtonDetector(c: Context, threshold: Float) :
    TemplateDetector(c, Kind.ROD, "rod.png", threshold, 1.45f)

class ShakeDetector(c: Context, threshold: Float) :
    TemplateDetector(c, Kind.SHAKE, "shake.png", threshold, 1.4f)

class RobloxDetector(c: Context) : TemplateDetector(c, Kind.ROBLOX, "roblox.png", .66f)
