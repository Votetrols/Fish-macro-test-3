package br.dev.fischvision.engine

import android.content.Context
import android.os.SystemClock
import br.dev.fischvision.capture.*
import br.dev.fischvision.config.Settings
import br.dev.fischvision.control.*
import br.dev.fischvision.model.*
import br.dev.fischvision.safety.*
import br.dev.fischvision.state.FishingStateMachine
import br.dev.fischvision.tracking.*
import br.dev.fischvision.ui.Logs
import br.dev.fischvision.vision.VisionPipeline
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class FishingEngine(c: Context, private val cfg: Settings) : AutoCloseable {
    private val vision = VisionPipeline(c, cfg)
    private val calibration = br.dev.fischvision.config.Calibration()
    private val fishTracker = FishTracker(cfg.trackingGraceMs)
    private val playerTracker = PlayerBarTracker(cfg.trackingGraceMs)
    private val barTracker = BarTracker()
    private val progress = ProgressTracker()
    private val machine = FishingStateMachine(cfg)
    private val input = InputController(cfg)
    private val buffer = FrameBuffer()
    private val executor = Executors.newSingleThreadExecutor()
    private val scheduled = AtomicBoolean(false)
    @Volatile private var closed = false
    @Volatile private var latestTimestamp = 0L
    private var lastFrame = 0L
    private var fps = 0f
    private var lastLog = 0L
    private val pendingAck =
        java.util.concurrent.ConcurrentLinkedQueue<Pair<Decision, Observation>>()

    init {
        machine.start(SystemClock.elapsedRealtime())
        EmergencyStop.arm()
    }

    @Synchronized
    fun offer(frame: CapturedFrame) {
        if (closed) {
            frame.close()
            return
        }
        latestTimestamp = frame.timestamp
        buffer.offer(frame)
        schedule()
    }

    private fun schedule() {
        if (closed || !scheduled.compareAndSet(false, true)) return
        try {
            executor.execute {
                try {
                    while (!closed) {
                        val frame = buffer.take() ?: break
                        try {
                            process(frame)
                        } catch (e: Exception) {
                            fail("Engine: ${e.message}")
                        } finally {
                            frame.close()
                        }
                    }
                } finally {
                    scheduled.set(false)
                    if (!closed && buffer.hasPending()) schedule()
                }
            }
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            scheduled.set(false)
        }
    }

    private fun process(frame: CapturedFrame) {
        if (EmergencyStop.active) {
            input.stop()
            return
        }
        while (true) {
            val ack = pendingAck.poll() ?: break
            machine.acknowledge(ack.first, ack.second)
        }
        val foreground = GestureService.instance?.foregroundRoblox() == true
        if (!foreground) {
            input.release()
            machine.fault(State.ROBLOX_NOT_DETECTED, frame.timestamp)
            Runtime.snapshot =
                Runtime.snapshot.copy(
                    state = machine.state,
                    roblox = false,
                    capture = true,
                    message = "Roblox fora do primeiro plano",
                    observation = null,
                )
            return
        }
        if (machine.state == State.RESET) {
            vision.reset()
            fishTracker.reset()
            playerTracker.reset()
            barTracker.reset()
            progress.reset()
        }
        val o = vision.analyze(frame.bitmap, frame.timestamp, machine.state)
        if (closed || EmergencyStop.active) return
        val visual = o[Kind.ROBLOX].confidence >= cfg.minConfidence
        if (!visual) {
            input.release()
            machine.fault(State.ROBLOX_NOT_DETECTED, frame.timestamp)
        }
        val bar = o[Kind.BAR].box
        if (bar != null && barTracker.changed(bar)) {
            fishTracker.reset()
            playerTracker.reset()
        }
        val fish = bar?.let { fishTracker.update(o[Kind.FISH], it, o.timestamp) }
        val player = bar?.let { playerTracker.update(o[Kind.PLAYER], it, o.timestamp) }
        progress.update(o[Kind.PROGRESS])
        val d =
            if (visual) machine.step(o, fish, player, progress.trend) else Decision(Action.RELEASE)
        val age = SystemClock.elapsedRealtime() - o.timestamp
        val confidence =
            if (machine.state == State.CASTING) o[Kind.ROBLOX].confidence else d.confidence
        input.update(
            SafetyContext(
                cfg.realInput,
                true,
                foreground && visual,
                EmergencyStop.active,
                machine.state,
                age,
                confidence,
                fish != null && player != null,
                calibration.inspect(frame, o) &&
                    (d.point == null ||
                        (d.point.x in 0f..o.width.toFloat() && d.point.y in 0f..o.height.toFloat())),
            ),
            o.timestamp,
        )
        input.execute(
            d,
            frame.displayWidth.toFloat() / o.width,
            frame.displayHeight.toFloat() / o.height,
        ) { ok ->
            if (ok && !closed)
                pendingAck.add(d to o.copy(timestamp = SystemClock.elapsedRealtime()))
        }
        if (lastFrame > 0)
            fps = .85f * fps + .15f * (1000f / (frame.timestamp - lastFrame).coerceAtLeast(1))
        lastFrame = frame.timestamp
        if (closed) return
        Runtime.snapshot =
            Snapshot(
                machine.state,
                fps,
                age,
                o,
                fish,
                player,
                d,
                progress.trend,
                true,
                foreground && visual,
                !cfg.realInput,
                if (age > cfg.maxFrameAgeMs) "Latência alta: input bloqueado" else "Motor ativo",
            )
        if (o.timestamp - lastLog > 1000) {
            lastLog = o.timestamp
            Logs.event(
                "DETECTION",
                "summary",
                o.detections.mapKeys { it.key.name }.mapValues { it.value.confidence },
            )
            Logs.event(
                "TRACKING",
                "normalized",
                mapOf(
                    "fish" to (fish?.position ?: -1),
                    "player" to (player?.position ?: -1),
                    "fps" to fps,
                    "ageMs" to age,
                ),
            )
            Logs.event(
                "CONTROL",
                d.reason,
                mapOf("action" to d.action, "error" to d.error, "progressTrend" to progress.trend),
            )
        }
    }

    fun fail(message: String) {
        Logs.event("ERROR", message)
        EmergencyStop.trigger()
        input.stop()
        Runtime.snapshot =
            Runtime.snapshot.copy(state = State.CAPTURE_ERROR, message = message, capture = false)
        Runtime.stop?.invoke()
    }

    @Synchronized
    override fun close() {
        if (closed) return
        closed = true
        input.stop()
        buffer.close()
        executor.execute { vision.close() }
        executor.shutdown()
    }
}
