package br.dev.fischvision.config

import android.content.Context

data class Settings(
    val realInput: Boolean=false, val debug: Boolean=true,
    val fps: Int=24, val processingWidth: Int=1066,
    val minConfidence: Float=.70f, val maxFrameAgeMs: Long=180,
    val castMs: Long=3000, val tapMs: Long=35, val holdQuantumMs: Long=65,
    val kp: Float=4f, val kd: Float=.65f, val deadband: Float=.018f,
    val anticipationMs: Long=65, val hysteresis: Float=.045f,
    val initialDrift: Float=-.32f, val trackingGraceMs: Long=140,
    val ocrIntervalMs: Long=240, val templateThreshold: Float=.68f
) {
    fun validate(): Settings { require(fps in 10..45); require(processingWidth in 640..1600); require(minConfidence in .5f.. .98f); require(kp in .1f..15f && kd in 0f..4f); require(deadband in .002f.. .15f); require(holdQuantumMs in 30..100); require(castMs in 500..5000); return this }
    fun save(c: Context) { c.getSharedPreferences("settings",0).edit().putBoolean("debug",debug).putInt("fps",fps).putInt("width",processingWidth).putFloat("kp",kp).putFloat("kd",kd).putFloat("confidence",minConfidence).putFloat("deadband",deadband).putLong("cast",castMs).putLong("hold",holdQuantumMs).apply() }
    companion object { fun load(c: Context): Settings { val p=c.getSharedPreferences("settings",0); return Settings(debug=p.getBoolean("debug",true),fps=p.getInt("fps",24),processingWidth=p.getInt("width",1066),kp=p.getFloat("kp",4f),kd=p.getFloat("kd",.65f),minConfidence=p.getFloat("confidence",.70f),deadband=p.getFloat("deadband",.018f),castMs=p.getLong("cast",3000),holdQuantumMs=p.getLong("hold",65)).validate() } }
}
