package br.dev.fischvision.config

import br.dev.fischvision.capture.CapturedFrame
import br.dev.fischvision.model.Observation
import br.dev.fischvision.ui.Logs
import kotlin.math.abs

/** A run is calibrated to full-display capture, not to reference-video coordinates. */
class Calibration {
    private var display: Triple<Int, Int, Int>? = null

    fun inspect(frame: CapturedFrame, observation: Observation): Boolean {
        val current = Triple(frame.displayWidth, frame.displayHeight, frame.rotation)
        if (display == null) {
            display = current
            Logs.event(
                "CAPTURE",
                "automatic geometry calibration",
                mapOf(
                    "displayWidth" to frame.displayWidth,
                    "displayHeight" to frame.displayHeight,
                    "processingWidth" to observation.width,
                    "processingHeight" to observation.height,
                    "rotation" to frame.rotation,
                ),
            )
        }
        if (current != display || observation.width <= 0 || observation.height <= 0) return false
        val nativeAspect = frame.displayWidth.toFloat() / frame.displayHeight
        val processingAspect = observation.width.toFloat() / observation.height
        return abs(nativeAspect - processingAspect) / nativeAspect < .005f
    }
}
