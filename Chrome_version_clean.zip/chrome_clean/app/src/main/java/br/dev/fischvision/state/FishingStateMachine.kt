package br.dev.fischvision.state

import br.dev.fischvision.config.Settings
import br.dev.fischvision.control.*
import br.dev.fischvision.model.*
import br.dev.fischvision.ui.Logs

class FishingStateMachine(private val cfg: Settings) {
    var state = State.IDLE
        private set

    private var entered = 0L
    private var missingBarSince = 0L
    private var catchSeen = false
    private var catchAbsentSince = 0L
    private var castSent = false
    private var castStarted = 0L
    private val shake = ShakeController()
    private val controller = FishingController(cfg)
    private var recovery = State.SEARCH_FISHING_BUTTON

    fun start(t: Long) {
        shake.reset()
        controller.reset()
        catchSeen = false
        transition(State.SEARCH_FISHING_BUTTON, t)
    }

    fun transition(s: State, t: Long) {
        if (s != state) {
            Logs.event("STATE", "$state -> $s")
            state = s
            entered = t
        }
    }

    fun fault(s: State, t: Long) {
        if (state !in setOf(State.VISION_LOST, State.ROBLOX_NOT_DETECTED)) recovery = state
        transition(s, t)
    }

    fun acknowledge(d: Decision, o: Observation) {
        when (state) {
            State.CASTING ->
                if (d.action == Action.HOLD && !castSent) {
                    castSent = true
                    castStarted = o.timestamp
                }
            State.PRESSING_SHAKE -> {
                o[Kind.SHAKE].box?.let(shake::acknowledge)
                transition(State.SEARCHING_SHAKE, o.timestamp)
            }
            else -> {}
        }
    }

    fun step(o: Observation, fish: Track?, player: Track?, trend: Float): Decision {
        val t = o.timestamp
        fun valid(k: Kind) = o[k].detected && o[k].confidence >= cfg.minConfidence
        val bar = valid(Kind.BAR) && valid(Kind.PROGRESS)
        val release = Decision(Action.RELEASE)
        when (state) {
            State.IDLE,
            State.EMERGENCY_STOP,
            State.CAPTURE_ERROR,
            State.INVALID_STATE -> return release
            State.ROBLOX_NOT_DETECTED -> {
                transition(
                    if (
                        recovery in
                            setOf(
                                State.TRACKING_FISH,
                                State.CONTROLLING_PLAYER_BAR,
                                State.CATCH_CONFIRMATION,
                            )
                    )
                        State.CATCH_CONFIRMATION
                    else if (recovery == State.SEARCH_FISHING_BUTTON) State.SEARCH_FISHING_BUTTON
                    else State.SEARCHING_SHAKE,
                    t,
                )
                return release
            }
            State.SEARCH_FISHING_BUTTON -> {
                if (bar) {
                    transition(State.FISHING_MINIGAME_DETECTED, t)
                    return release
                }
                if (valid(Kind.SHAKE)) {
                    transition(State.SEARCHING_SHAKE, t)
                    return release
                }
                if (valid(Kind.ROD)) {
                    castSent = false
                    transition(State.CASTING, t)
                }
            }
            State.CASTING -> {
                if (bar) {
                    transition(State.FISHING_MINIGAME_DETECTED, t)
                    return release
                }
                if (valid(Kind.SHAKE)) {
                    transition(State.SEARCHING_SHAKE, t)
                    return release
                }
                if (!castSent && valid(Kind.ROD))
                    return Decision(
                        Action.HOLD,
                        o[Kind.ROD].box!!.center,
                        cfg.castMs,
                        o[Kind.ROD].confidence,
                        reason = "cast",
                    )
                if (castSent && t - castStarted >= cfg.castMs) {
                    transition(State.SEARCHING_SHAKE, t)
                    return release
                }
            }
            State.SEARCHING_SHAKE,
            State.PRESSING_SHAKE -> {
                if (bar) {
                    shake.reset()
                    controller.reset()
                    transition(State.FISHING_MINIGAME_DETECTED, t)
                    return release
                }
                val point = shake.decide(o[Kind.SHAKE])
                if (valid(Kind.SHAKE) && point != null) {
                    transition(State.PRESSING_SHAKE, t)
                    return Decision(
                        Action.TAP,
                        point,
                        cfg.tapMs,
                        o[Kind.SHAKE].confidence,
                        reason = "new visual Shake",
                    )
                }
            }
            State.FISHING_MINIGAME_DETECTED -> {
                transition(State.TRACKING_FISH, t)
                return release
            }
            State.TRACKING_FISH,
            State.CONTROLLING_PLAYER_BAR,
            State.VISION_LOST -> {
                if (!bar) {
                    if (missingBarSince == 0L) missingBarSince = t
                    if (t - missingBarSince >= 220) {
                        catchSeen = false
                        catchAbsentSince = 0
                        transition(State.CATCH_CONFIRMATION, t)
                    }
                    return release
                }
                missingBarSince = 0
                if (
                    fish == null ||
                        player == null ||
                        fish.confidence < cfg.minConfidence ||
                        player.confidence < cfg.minConfidence
                ) {
                    transition(State.VISION_LOST, t)
                    return release
                }
                transition(State.CONTROLLING_PLAYER_BAR, t)
                return controller.decide(fish, player, o[Kind.BAR].box!!, t, trend)
            }
            State.CATCH_CONFIRMATION -> {
                if (bar) {
                    transition(State.TRACKING_FISH, t)
                    return release
                }
                if (valid(Kind.CATCH)) {
                    catchSeen = true
                    catchAbsentSince = 0
                } else if (catchSeen) {
                    if (catchAbsentSince == 0L) catchAbsentSince = t
                    if (t - catchAbsentSince >= 600 && valid(Kind.ROD)) transition(State.RESET, t)
                }
                // Disappearance alone never means success. No automatic recast on unconfirmed loss.
            }
            State.RESET -> {
                shake.reset()
                controller.reset()
                castSent = false
                catchSeen = false
                transition(State.SEARCH_FISHING_BUTTON, t)
            }
        }
        return Decision(Action.NONE)
    }
}
