package br.dev.fischvision.vision

import android.content.Context
import android.graphics.Bitmap
import br.dev.fischvision.config.Settings
import br.dev.fischvision.model.*
import br.dev.fischvision.tracking.ConfidenceTracker

class VisionPipeline(c: Context, private val cfg: Settings) : AutoCloseable {
    private val frame = VisionFrame()
    private val rod = FishingButtonDetector(c, cfg.templateThreshold)
    private val shake = ShakeDetector(c, cfg.templateThreshold)
    private val roblox = RobloxDetector(c)
    private val bar = FishingBarDetector()
    private val fish = FishDetector()
    private val player = PlayerBarDetector()
    private val progress = ProgressDetector()
    private val catch = CatchConfirmationDetector()
    private val votes =
        Kind.entries.associateWith {
            ConfidenceTracker(
                if (it == Kind.FISH || it == Kind.PLAYER) 1 else 2,
                if (it == Kind.CATCH) 750 else if (it == Kind.SHAKE) 550 else 220,
            )
        }
    private var lastOcr = 0L
    private var lastShakeOcr = 0L
    private var catchCache = Detection.missing(Kind.CATCH, 0)
    private var lastBarSeen = 0L

    fun reset() {
        votes.values.forEach { it.reset() }
        player.reset()
        lastBarSeen = 0
        catchCache = Detection.missing(Kind.CATCH, 0)
    }

    fun analyze(bitmap: Bitmap, t: Long, state: State): Observation {
        frame.load(bitmap, t)
        val result = mutableMapOf<Kind, Detection>()
        fun run(d: Detector) {
            result[d.kind] = votes.getValue(d.kind).accept(d.detect(frame, result))
        }
        run(roblox)
        if (result.getValue(Kind.ROBLOX).confidence < cfg.minConfidence)
            return Observation(t, frame.width, frame.height, result)
        // Rail detector must remain ungated for cross-validation against progress.
        val rawBar = bar.detect(frame, result)
        result[Kind.BAR] = rawBar
        val rawProgress = progress.detect(frame, result)
        if (!rawProgress.detected) result[Kind.BAR] = Detection.missing(Kind.BAR, t)
        else result[Kind.BAR] = votes.getValue(Kind.BAR).accept(rawBar)
        result[Kind.PROGRESS] = votes.getValue(Kind.PROGRESS).accept(rawProgress)
        if (result.getValue(Kind.BAR).detected) {
            lastBarSeen = t
            run(fish)
            run(player)
        } else {
            if (t - lastBarSeen > 1500) player.reset()
            var shakeResult = shake.detect(frame, result)
            if (
                !shakeResult.detected &&
                    state != State.CATCH_CONFIRMATION &&
                    t - lastShakeOcr >= cfg.ocrIntervalMs
            ) {
                lastShakeOcr = t
                shakeResult = catch.detectShake(bitmap, frame)
            }
            result[Kind.SHAKE] = votes.getValue(Kind.SHAKE).accept(shakeResult)
            if (state !in setOf(State.SEARCHING_SHAKE, State.PRESSING_SHAKE)) run(rod)
            if (state == State.CATCH_CONFIRMATION && t - lastOcr >= cfg.ocrIntervalMs) {
                lastOcr = t
                catchCache = votes.getValue(Kind.CATCH).accept(catch.detect(bitmap, frame))
            }
        }
        if (t - catchCache.timestamp < cfg.ocrIntervalMs + 80) result[Kind.CATCH] = catchCache
        return Observation(t, frame.width, frame.height, result)
    }

    override fun close() {
        frame.close()
        rod.close()
        shake.close()
        roblox.close()
        bar.close()
        progress.close()
        catch.close()
    }
}
