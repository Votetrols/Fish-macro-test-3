package br.dev.fischvision.ui

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.Button
import br.dev.fischvision.config.Settings
import br.dev.fischvision.engine.Runtime
import br.dev.fischvision.model.*
import br.dev.fischvision.safety.EmergencyStop

class DebugOverlay(private val service: AccessibilityService) {
    private val wm = service.getSystemService(WindowManager::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private val canvas = OverlayView(service)
    private val stop =
        Button(service).apply {
            text = "PARAR"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(155, 25, 32))
            setOnClickListener { EmergencyStop.trigger() }
        }
    private var attached = false

    companion object {
        @Volatile
        var stopBounds: Box? = null
            private set

        fun blocks(p: br.dev.fischvision.model.Point): Boolean =
            stopBounds?.let {
                p.x >= it.left && p.x <= it.right && p.y >= it.top && p.y <= it.bottom
            } ?: false
    }

    private val refresh =
        object : Runnable {
            override fun run() {
                if (!attached) return
                canvas.show = Settings.load(service).debug && Runtime.snapshot.capture
                canvas.invalidate()
                stop.visibility = if (Runtime.snapshot.capture) View.VISIBLE else View.GONE
                val pos = IntArray(2)
                stop.getLocationOnScreen(pos)
                stopBounds =
                    if (stop.visibility == View.VISIBLE)
                        Box(
                            pos[0].toFloat(),
                            pos[1].toFloat(),
                            (pos[0] + stop.width).toFloat(),
                            (pos[1] + stop.height).toFloat(),
                        )
                    else null
                handler.postDelayed(this, 100)
            }
        }

    fun attach() {
        if (attached) return
        val flags =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        wm.addView(
            canvas,
            WindowManager.LayoutParams(
                -1,
                -1,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                flags,
                PixelFormat.TRANSLUCENT,
            ),
        )
        val dp = service.resources.displayMetrics.density
        val p =
            WindowManager.LayoutParams(
                (88 * dp).toInt(),
                (42 * dp).toInt(),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT,
            )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        wm.addView(stop, p)
        attached = true
        handler.post(refresh)
    }

    fun detach() {
        if (!attached) return
        attached = false
        stopBounds = null
        handler.removeCallbacks(refresh)
        wm.removeView(canvas)
        wm.removeView(stop)
    }

    private class OverlayView(c: Context) : View(c) {
        var show = false
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(c: Canvas) {
            if (!show) return
            val s = Runtime.snapshot
            val o = s.observation ?: return
            val sx = width.toFloat() / o.width
            val sy = height.toFloat() / o.height
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f
            for ((kind, d) in o.detections) {
                val b = d.box ?: continue
                // Red annotations do not resemble the blue-gray fish indicator.
                paint.color = Color.RED
                c.drawRect(
                    b.left * sx - 3,
                    b.top * sy - 3,
                    b.right * sx + 3,
                    b.bottom * sy + 3,
                    paint,
                )
                if (kind == Kind.FISH || kind == Kind.PLAYER)
                    c.drawLine(
                        b.center.x * sx,
                        b.top * sy - 12,
                        b.center.x * sx,
                        b.top * sy - 4,
                        paint,
                    )
            }
            paint.style = Paint.Style.FILL
            paint.textSize =
                android.util.TypedValue.applyDimension(
                        android.util.TypedValue.COMPLEX_UNIT_SP,
                        13f,
                        resources.displayMetrics,
                    )
                    .coerceAtMost(height * .025f)
            paint.color = Color.WHITE
            paint.setShadowLayer(3f, 1f, 1f, Color.BLACK)
            val lines =
                listOf(
                    "${s.state} • ${if(s.simulated) "SIM" else "REAL"}",
                    "FPS %.1f | latência %dms".format(s.fps, s.latencyMs),
                    "Fish %.3f v=%+.2f a=%+.2f"
                        .format(
                            s.fish?.position ?: -1f,
                            s.fish?.velocity ?: 0f,
                            s.fish?.acceleration ?: 0f,
                        ),
                    "Player %.3f v=%+.2f"
                        .format(s.player?.position ?: -1f, s.player?.velocity ?: 0f),
                    "Erro %+.3f conf %.2f".format(s.decision.error, s.decision.confidence),
                    "${s.decision.action} | progresso %.0f%% Δ%+.2f"
                        .format((o[Kind.PROGRESS].value ?: 0f) * 100, s.progressTrend),
                )
            lines.forEachIndexed { i, text ->
                c.drawText(text, width * .025f, height * .27f + i * paint.textSize * 1.25f, paint)
            }
            paint.clearShadowLayer()
        }
    }
}
