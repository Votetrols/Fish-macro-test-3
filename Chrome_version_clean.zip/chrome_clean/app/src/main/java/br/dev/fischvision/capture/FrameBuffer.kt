package br.dev.fischvision.capture

import android.graphics.Bitmap

/** One owner per frame. Latest-only queue: superseded frames are immediately recycled. */
class CapturedFrame(
    val bitmap: Bitmap,
    val timestamp: Long,
    val displayWidth: Int,
    val displayHeight: Int,
    val rotation: Int,
    private val dispose: (Bitmap) -> Unit = { it.recycle() },
) : AutoCloseable {
    private val closed = java.util.concurrent.atomic.AtomicBoolean(false)

    override fun close() {
        if (closed.compareAndSet(false, true)) dispose(bitmap)
    }
}

class FrameBuffer : AutoCloseable {
    private var latest: CapturedFrame? = null

    @Synchronized
    fun offer(f: CapturedFrame) {
        latest?.close()
        latest = f
    }

    @Synchronized
    fun take(): CapturedFrame? {
        val f = latest
        latest = null
        return f
    }

    @Synchronized fun hasPending() = latest != null

    @Synchronized
    override fun close() {
        latest?.close()
        latest = null
    }
}
