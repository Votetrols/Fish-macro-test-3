package br.dev.fischvision.capture

import android.graphics.Bitmap
import java.util.ArrayDeque

/** Capture, pending frame and worker each own at most one bitmap. */
class BitmapPool(private val capacity: Int = 3) : AutoCloseable {
    private val available = ArrayDeque<Bitmap>()
    private var closed = false

    @Synchronized
    fun acquire(width: Int, height: Int): Bitmap {
        check(!closed)
        while (available.isNotEmpty()) {
            val bitmap = available.removeFirst()
            if (bitmap.width == width && bitmap.height == height) return bitmap
            bitmap.recycle()
        }
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    }

    @Synchronized
    fun release(bitmap: Bitmap) {
        if (closed || available.size >= capacity) bitmap.recycle() else available.addLast(bitmap)
    }

    @Synchronized
    override fun close() {
        closed = true
        while (available.isNotEmpty()) available.removeFirst().recycle()
    }
}
