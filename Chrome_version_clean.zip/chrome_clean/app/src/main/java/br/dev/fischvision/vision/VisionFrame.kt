package br.dev.fischvision.vision

import android.graphics.Bitmap
import br.dev.fischvision.model.*
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc

class VisionFrame : AutoCloseable {
    val rgba = Mat()
    val gray = Mat()
    val edges = Mat()
    var timestamp = 0L
        private set

    val width
        get() = gray.cols()

    val height
        get() = gray.rows()

    fun load(bitmap: Bitmap, t: Long) {
        timestamp = t
        Utils.bitmapToMat(bitmap, rgba)
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        Imgproc.Canny(gray, edges, 50.0, 130.0)
    }

    override fun close() {
        rgba.release()
        gray.release()
        edges.release()
    }
}

fun Rect.box() = Box(x.toFloat(), y.toFloat(), (x + width).toFloat(), (y + height).toFloat())

fun Box.rect(w: Int, h: Int): Rect {
    val x = left.toInt().coerceIn(0, w - 1)
    val y = top.toInt().coerceIn(0, h - 1)
    return Rect(
        x,
        y,
        (right.toInt() - x).coerceIn(1, w - x),
        (bottom.toInt() - y).coerceIn(1, h - y),
    )
}

interface Detector {
    val kind: Kind

    fun detect(f: VisionFrame, context: Map<Kind, Detection>): Detection
}
