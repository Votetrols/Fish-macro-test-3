package br.dev.fischvision.control

import br.dev.fischvision.config.Settings
import br.dev.fischvision.model.*
import kotlin.math.*

/**
 * PD + short-horizon feed-forward, learned released drift, Schmitt trigger. Units: bar widths/s.
 */
class FishingController(private val cfg: Settings) {
    private var held = false
    private var lastChange = 0L
    private var drift = cfg.initialDrift

    fun reset() {
        held = false
        lastChange = 0
        drift = cfg.initialDrift
    }

    fun decide(f: Track?, p: Track?, bar: Box, now: Long, progressTrend: Float): Decision {
        if (
            f == null ||
                p == null ||
                min(f.confidence, p.confidence) < cfg.minConfidence ||
                max(f.ageMs, p.ageMs) > cfg.trackingGraceMs
        ) {
            held = false
            return Decision(Action.RELEASE, reason = "tracking confidence")
        }
        if (!held && p.ageMs == 0L && p.position > p.width / 2 + .03f && p.velocity < 0)
            drift = .95f * drift + .05f * p.velocity
        val error = f.position - p.position
        val horizon = cfg.anticipationMs / 1000f
        val target =
            (f.position + f.velocity * horizon + f.acceleration * horizon * horizon * .15f)
                .coerceIn(p.width / 2, 1 - p.width / 2)
        val predictiveError = target - p.position
        val desiredVelocity = f.velocity + cfg.kp * predictiveError
        val score = desiredVelocity - cfg.kd * p.velocity - drift * .5f
        val band = cfg.hysteresis * (if (progressTrend < -.03f) .8f else 1f)
        var next = if (held) score > -band else score > band
        if (p.position >= 1 - p.width / 2 - .006f && error < cfg.deadband) next = false
        if (p.position <= p.width / 2 + .006f && error > cfg.deadband) next = true
        if (abs(error) < cfg.deadband && abs(f.velocity) < .03f && abs(p.velocity) < .03f)
            next = score > band
        if (next != held && now - lastChange < cfg.tapMs) next = held
        if (next != held) lastChange = now
        held = next
        // Tap on a detected safe interior point, never a hardcoded screen coordinate.
        val point = Point(bar.center.x, bar.center.y)
        val action =
            if (!held) Action.RELEASE
            else if (abs(error) < cfg.deadband * 2 && abs(f.velocity) < .15f) Action.TAP
            else Action.HOLD
        return Decision(
            action,
            point,
            if (action == Action.TAP) cfg.tapMs else cfg.holdQuantumMs,
            min(f.confidence, p.confidence),
            error,
            "PD drift=%.3f score=%.3f".format(drift, score),
        )
    }
}

class ShakeController {
    private var clicked: Box? = null
    private var absentSince = 0L

    fun reset() {
        clicked = null
        absentSince = 0
    }

    fun decide(d: Detection): Point? {
        if (!d.detected) {
            if (absentSince == 0L) absentSince = d.timestamp
            if (d.timestamp - absentSince > 100) clicked = null
            return null
        }
        absentSince = 0
        val b = d.box!!
        if (clicked?.iou(b)?.let { it > .35f } == true) return null
        return b.center
    }

    fun acknowledge(b: Box) {
        clicked = b
    }
}
