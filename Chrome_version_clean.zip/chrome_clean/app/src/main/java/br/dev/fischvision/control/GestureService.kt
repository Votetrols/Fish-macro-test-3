package br.dev.fischvision.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import br.dev.fischvision.model.Point
import br.dev.fischvision.safety.EmergencyStop
import br.dev.fischvision.ui.DebugOverlay
import br.dev.fischvision.ui.Logs

/** All gesture mutation on main looper. Continued strokes have bounded 65 ms segments. */
class GestureService : AccessibilityService() {
    private val main = Handler(Looper.getMainLooper())
    private var stroke: GestureDescription.StrokeDescription? = null
    private var inFlight = false
    private var finish = false
    private var target: Point? = null
    private var until = 0L
    private var quantum = 65L
    private var permit: (() -> Boolean)? = null
    private var completion: ((Boolean) -> Unit)? = null
    private var overlay: DebugOverlay? = null

    companion object {
        @Volatile
        var instance: GestureService? = null
            private set
    }

    override fun onServiceConnected() {
        instance = this
        overlay = DebugOverlay(this)
        overlay?.attach()
        Logs.event("INPUT", "Accessibility connected")
    }

    fun foregroundRoblox(): Boolean =
        try {
            val root = rootInActiveWindow
            val active = root?.packageName?.toString() == "com.roblox.client"
            // A system sheet above the game invalidates input, even if Roblox retains an
            // application window.
            active && windows.none { it.type == AccessibilityWindowInfo.TYPE_SYSTEM && it.isActive }
        } catch (_: Exception) {
            false
        }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!foregroundRoblox()) release()
    }

    override fun onInterrupt() {
        EmergencyStop.trigger()
        release()
    }

    override fun onDestroy() {
        EmergencyStop.trigger()
        release()
        overlay?.detach()
        instance = null
        super.onDestroy()
    }

    fun request(
        p: Point,
        duration: Long,
        segmentMs: Long,
        authorize: () -> Boolean,
        onFinished: ((Boolean) -> Unit)? = null,
    ): Boolean {
        check(Looper.myLooper() == Looper.getMainLooper())
        if (!authorize() || !foregroundRoblox()) {
            release()
            return false
        }
        if (target != null || inFlight) {
            if (onFinished != null) return false
            // Do not migrate a held finger to another target.
            if (
                target?.let {
                    kotlin.math.abs(it.x - p.x) > 8 || kotlin.math.abs(it.y - p.y) > 8
                } == true
            )
                return false
            until = maxOf(until, SystemClock.elapsedRealtime() + duration)
            permit = authorize
            return true
        }
        completion = onFinished
        target = p
        until = SystemClock.elapsedRealtime() + duration
        quantum = segmentMs.coerceIn(30, 100)
        permit = authorize
        finish = false
        return send()
    }

    fun release() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post { release() }
            return
        }
        finish = true
        until = 0
        if (!inFlight && stroke != null) send() else if (!inFlight) clear()
    }

    private fun clear(success: Boolean = false) {
        val callback = completion
        completion = null
        stroke = null
        target = null
        permit = null
        finish = false
        inFlight = false
        callback?.invoke(success)
    }

    private fun send(): Boolean {
        val p = target ?: return false
        val authorized =
            !finish && !EmergencyStop.active && foregroundRoblox() && permit?.invoke() == true
        val remaining = until - SystemClock.elapsedRealtime()
        val keep = authorized && remaining > quantum
        val duration = if (!authorized) 1L else remaining.coerceIn(1, quantum)
        if (stroke == null && !authorized) {
            clear()
            return false
        }
        val path = Path().apply { moveTo(p.x, p.y) }
        val next =
            try {
                stroke?.continueStroke(path, 0, duration, keep)
                    ?: GestureDescription.StrokeDescription(path, 0, duration, keep)
            } catch (e: Exception) {
                Logs.event("ERROR", "Continuation: $e")
                clear()
                return false
            }
        inFlight = true
        val accepted =
            dispatchGesture(
                GestureDescription.Builder().addStroke(next).build(),
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        inFlight = false
                        if (keep) {
                            stroke = next
                            send()
                        } else clear(!finish && !EmergencyStop.active)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        Logs.event("INPUT", "gesture cancelled by Android")
                        clear()
                    }
                },
                main,
            )
        if (!accepted) {
            Logs.event("ERROR", "dispatchGesture rejected")
            clear()
        }
        return accepted
    }
}
