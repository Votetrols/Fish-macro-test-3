package br.dev.fischvision.vision

import br.dev.fischvision.config.VisionProfile as V
import br.dev.fischvision.model.*
import kotlin.math.*
import org.opencv.core.*

class PlayerBarDetector : Detector {
    override val kind = Kind.PLAYER
    private var learnedWidth = 0
    private var columns = FloatArray(0)
    private var pixels = ByteArray(0)

    fun reset() {
        learnedWidth = 0
    }

    override fun detect(f: VisionFrame, context: Map<Kind, Detection>): Detection {
        val b = context[Kind.BAR]?.box ?: return Detection.missing(kind, f.timestamp)
        val r = b.rect(f.width, f.height)
        val roi = f.gray.submat(r)
        val n = r.width * r.height
        if (pixels.size < n) pixels = ByteArray(n)
        roi.get(0, 0, pixels)
        roi.release()
        if (columns.size < r.width) columns = FloatArray(r.width)
        val ya = (r.height * .15).toInt()
        val yb = (r.height * .85).toInt().coerceAtLeast(ya + 1)
        for (x in 0 until r.width) {
            var sum = 0f
            for (y in ya until yb) sum += (pixels[y * r.width + x].toInt() and 255)
            columns[x] = sum / (yb - ya)
        }
        // Close narrow arrow/fish gaps in the bright rectangle without changing its learned width.
        val bright = BooleanArray(r.width) { columns[it] > V.playerLuma }
        var start = -1
        val segments = mutableListOf<Pair<Int, Int>>()
        var gap = 0
        for (x in 0 until r.width) {
            if (bright[x]) {
                if (start < 0) start = x
                gap = 0
            } else if (start >= 0) {
                gap++
                if (gap > max(3, r.height / 2)) {
                    segments.add(start to (x - gap + 1))
                    start = -1
                    gap = 0
                }
            }
        }
        if (start >= 0) segments.add(start to (r.width - gap))
        val brightRun =
            segments
                .filter { (a, z) -> z - a > r.height * 1.6 && z - a < r.width * .75 }
                .maxByOrNull { it.second - it.first }
        if (brightRun != null) {
            val (a, z) = brightRun
            val w = z - a
            if (learnedWidth == 0) learnedWidth = w
            if (abs(w - learnedWidth) < max(4f, learnedWidth * .15f)) {
                // Measurement only; do not derive width from rod or total track width.
                learnedWidth = (.9f * learnedWidth + .1f * w).toInt()
                return Detection(
                    kind,
                    Box((r.x + a).toFloat(), b.top, (r.x + z).toFloat(), b.bottom),
                    .90f,
                    f.timestamp,
                )
            }
        }
        // Desaturated/ochre animation: look for a bounded brighter plateau of learned pixel width.
        val w = learnedWidth
        if (w < 1 || w >= r.width) return Detection.missing(kind, f.timestamp)
        var best = -1
        var score = 0f
        for (a in 0..r.width - w) {
            var sum = 0f
            for (x in a until a + w) sum += columns[x]
            val avg = sum / w
            val left = if (a > 3) columns[a - 3] else 0f
            val right = if (a + w + 3 < r.width) columns[a + w + 3] else 0f
            val contrast = avg - max(left, right)
            if (avg in 45f..210f && contrast > score && contrast > V.minPlayerContrast) {
                score = contrast
                best = a
            }
        }
        return if (best < 0) Detection.missing(kind, f.timestamp)
        else
            Detection(
                kind,
                Box((r.x + best).toFloat(), b.top, (r.x + best + w).toFloat(), b.bottom),
                .73f,
                f.timestamp,
            )
    }
}
