package br.dev.fischvision.tracking

import br.dev.fischvision.model.*
import kotlin.math.*

open class MotionTracker(private val graceMs: Long) {
    private var last: Track? = null
    private var lastTime = 0L

    fun reset() {
        last = null
        lastTime = 0
    }

    fun update(d: Detection, bar: Box, now: Long): Track? {
        val old = last?.takeIf { now - lastTime <= graceMs }
        if (!d.detected || d.confidence < .5f) {
            if (old == null) return null
            val age = now - lastTime
            if (age > graceMs) return null
            return old.copy(
                position = (old.position + old.velocity * age / 1000f).coerceIn(0f, 1f),
                confidence = old.confidence * (1 - age.toFloat() / graceMs),
                ageMs = age,
            )
        }
        val x = bar.normalizeX(d.box!!.center.x)
        val dt = ((now - lastTime) / 1000f).coerceIn(.008f, .3f)
        val raw = if (old == null) 0f else ((x - old.position) / dt).coerceIn(-5f, 5f)
        val abrupt = old != null && (raw * old.velocity < 0 || abs(raw - old.velocity) > .7f)
        val v = if (old == null) 0f else if (abrupt) raw else .7f * raw + .3f * old.velocity
        val a = if (old == null) 0f else ((v - old.velocity) / dt).coerceIn(-25f, 25f)
        val result = Track(x, v, a, d.confidence, 0, d.box.width / bar.width)
        last = result
        lastTime = now
        return result
    }
}

class FishTracker(graceMs: Long) : MotionTracker(graceMs)

class PlayerBarTracker(graceMs: Long) : MotionTracker(graceMs)

class BarTracker {
    private var last: Box? = null

    fun changed(b: Box): Boolean {
        val old = last
        last = b
        return old != null && (old.iou(b) < .7f || abs(old.width - b.width) > old.width * .08f)
    }

    fun reset() {
        last = null
    }
}

class ConfidenceTracker(private val hitsRequired: Int = 2, private val maxGapMs: Long = 200) {
    private var previous: Detection? = null
    private var hits = 0

    fun reset() {
        previous = null
        hits = 0
    }

    fun accept(d: Detection): Detection {
        val p = previous
        if (!d.detected) {
            if (p != null && d.timestamp - p.timestamp > maxGapMs) reset()
            return d
        }
        hits =
            if (p != null && d.timestamp - p.timestamp <= maxGapMs && p.box!!.iou(d.box!!) > .35f)
                hits + 1
            else 1
        previous = d
        return if (hits >= hitsRequired) d else d.copy(confidence = d.confidence * .65f)
    }
}

class ProgressTracker {
    private var last: Detection? = null
    var trend = 0f
        private set

    fun reset() {
        last = null
        trend = 0f
    }

    fun update(d: Detection) {
        val p = last
        if (d.value != null && d.confidence > .6f) {
            if (p?.value != null && d.timestamp > p.timestamp)
                trend =
                    .7f * trend + .3f * ((d.value - p.value) * 1000 / (d.timestamp - p.timestamp))
            last = d
        }
    }
}
