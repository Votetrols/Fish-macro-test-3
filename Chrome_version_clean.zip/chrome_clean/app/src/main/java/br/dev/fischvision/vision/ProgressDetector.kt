package br.dev.fischvision.vision

import br.dev.fischvision.config.VisionProfile as V
import br.dev.fischvision.model.*
import kotlin.math.*
import org.opencv.core.*
import org.opencv.imgproc.Imgproc

class ProgressDetector : Detector, AutoCloseable {
    override val kind = Kind.PROGRESS
    private val mask = Mat()
    private val hierarchy = Mat()
    private var pixels = ByteArray(0)

    override fun detect(f: VisionFrame, context: Map<Kind, Detection>): Detection {
        val bar = context[Kind.BAR]?.box ?: return Detection.missing(kind, f.timestamp)
        val region =
            Box(bar.left, bar.bottom + bar.height * .25f, bar.right, bar.bottom + bar.height * 2.3f)
                .rect(f.width, f.height)
        val roi = f.gray.submat(region)
        val light = Mat()
        Imgproc.threshold(roi, mask, V.darkLuma, 255.0, Imgproc.THRESH_BINARY_INV)
        Imgproc.threshold(roi, light, V.brightLuma, 255.0, Imgproc.THRESH_BINARY)
        Core.bitwise_or(mask, light, mask)
        light.release()
        val k =
            Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(max(3.0, f.width / 213.0), 1.0))
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_CLOSE, k)
        k.release()
        val contours = mutableListOf<MatOfPoint>()
        Imgproc.findContours(
            mask,
            contours,
            hierarchy,
            Imgproc.RETR_LIST,
            Imgproc.CHAIN_APPROX_SIMPLE,
        )
        val candidates =
            contours
                .map { Imgproc.boundingRect(it) }
                .filter {
                    it.width > bar.width * .25 &&
                        it.width < bar.width * .95 &&
                        it.height >= 2 &&
                        it.height < bar.height * .65f &&
                        it.width.toFloat() / it.height > 12 &&
                        abs(region.x + it.x + it.width / 2f - bar.center.x) < bar.width * .14f
                }
        val r = candidates.maxByOrNull { it.width }
        contours.forEach { it.release() }
        if (r == null) {
            roi.release()
            return Detection.missing(kind, f.timestamp)
        }
        val sub = roi.submat(r)
        val n = r.width * r.height
        if (pixels.size < n) pixels = ByteArray(n)
        sub.get(0, 0, pixels)
        val mid = r.height / 2
        var filled = 0
        var darkRun = 0
        for (x in 1 until r.width - 1) {
            if ((pixels[mid * r.width + x].toInt() and 255) > 175) {
                if (darkRun > 2) break
                filled = x
                darkRun = 0
            } else darkRun++
        }
        sub.release()
        roi.release()
        return Detection(
            kind,
            Box(
                (region.x + r.x).toFloat(),
                (region.y + r.y).toFloat(),
                (region.x + r.x + r.width).toFloat(),
                (region.y + r.y + r.height).toFloat(),
            ),
            .87f,
            f.timestamp,
            (filled.toFloat() / (r.width - 2)).coerceIn(0f, 1f),
        )
    }

    override fun close() {
        mask.release()
        hierarchy.release()
    }
}
