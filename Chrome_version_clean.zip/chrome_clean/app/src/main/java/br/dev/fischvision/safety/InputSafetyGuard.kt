package br.dev.fischvision.safety

import br.dev.fischvision.model.*

data class SafetyContext(
    val enabled: Boolean,
    val capture: Boolean,
    val roblox: Boolean,
    val emergency: Boolean,
    val state: State,
    val frameAgeMs: Long,
    val confidence: Float,
    val tracking: Boolean,
    val geometryValid: Boolean,
)

class InputSafetyGuard(private val minimum: Float, private val maxAge: Long) {
    fun denial(c: SafetyContext, d: Decision): String? {
        if (d.action == Action.RELEASE || d.action == Action.NONE) return null
        if (!c.enabled) return "disabled"
        if (c.emergency) return "emergency"
        if (!c.capture) return "capture stopped"
        if (!c.roblox) return "Roblox not foreground"
        if (!c.geometryValid) return "capture/display mismatch"
        if (c.frameAgeMs !in 0..maxAge) return "stale frame"
        if (c.confidence !in minimum..1f || d.confidence !in minimum..1f) return "low confidence"
        if (c.state !in setOf(State.CASTING, State.PRESSING_SHAKE, State.CONTROLLING_PLAYER_BAR))
            return "invalid state"
        if (c.state == State.CONTROLLING_PLAYER_BAR && !c.tracking) return "tracking lost"
        if (d.durationMs !in 1..5000 || !d.error.isFinite()) return "invalid command"
        if (
            d.point == null ||
                !d.point.x.isFinite() ||
                !d.point.y.isFinite() ||
                d.point.x < 0 ||
                d.point.y < 0
        )
            return "invalid point"
        return null
    }
}

object EmergencyStop {
    @Volatile
    var active = true
        private set

    @Volatile var release: (() -> Unit)? = null

    fun trigger() {
        active = true
        release?.invoke()
    }

    fun arm() {
        active = false
    }
}
