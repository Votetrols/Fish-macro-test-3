package br.dev.fischvision.ui

import android.content.Context
import java.io.File
import java.util.ArrayDeque

/** Bounded JSONL journal. No screenshots, accessibility text or credentials are stored. */
object Logs {
    private val lines = ArrayDeque<String>()
    private var file: File? = null

    @Synchronized
    fun init(c: Context) {
        file = File(c.filesDir, "events.jsonl")
    }

    private fun quoted(s: String): String = buildString {
        append('"')
        for (ch in s) when (ch) {
            '"' -> append("\\\"")
            '\\' -> append("\\\\")
            '\n' -> append("\\n")
            '\r' -> append("\\r")
            '\t' -> append("\\t")
            else -> if (ch.code < 32) append("\\u%04x".format(ch.code)) else append(ch)
        }
        append('"')
    }

    @Synchronized
    fun event(category: String, message: String, fields: Map<String, Any> = emptyMap()) {
        val values =
            linkedMapOf<String, Any>(
                "monotonicMs" to System.nanoTime() / 1_000_000,
                "category" to category,
                "message" to message,
            )
        values.putAll(fields)
        val line =
            values.entries.joinToString(",", "{", "}") { (k, v) ->
                quoted(k) +
                    ":" +
                    when (v) {
                        is Number -> if (v.toDouble().isFinite()) v.toString() else "null"
                        is Boolean -> v.toString()
                        else -> quoted(v.toString())
                    }
            }
        lines.addLast(line)
        while (lines.size > 180) lines.removeFirst()
        runCatching { android.util.Log.i("Fisch/$category", message) }
        runCatching {
            file?.let {
                if (it.length() > 2_000_000) {
                    val old = File(it.parentFile, "events.previous.jsonl")
                    old.delete()
                    it.renameTo(old)
                }
                it.appendText(line + "\n")
            }
        }
    }

    @Synchronized fun text() = lines.joinToString("\n")

    @Synchronized fun export(): String = file?.takeIf { it.exists() }?.readText() ?: text()
}
