package br.dev.fischvision.vision

import br.dev.fischvision.config.VisionProfile as V
import br.dev.fischvision.model.*
import kotlin.math.*
import org.opencv.core.*

class FishDetector : Detector {
    override val kind = Kind.FISH
    private var pixels = ByteArray(0)

    override fun detect(f: VisionFrame, context: Map<Kind, Detection>): Detection {
        val bar = context[Kind.BAR]?.box ?: return Detection.missing(kind, f.timestamp)
        val b = Box(bar.left, bar.top - bar.height * .65f, bar.right, bar.bottom + bar.height * .4f)
        val r = b.rect(f.width, f.height)
        val roi = f.rgba.submat(r)
        val n = r.width * r.height * 4
        if (pixels.size < n) pixels = ByteArray(n)
        roi.get(0, 0, pixels)
        roi.release()
        var best = -1
        var score = 0f
        for (x in 0 until r.width) {
            var hits = 0
            var above = 0
            for (y in 0 until r.height) {
                val i = (y * r.width + x) * 4
                val red = pixels[i].toInt() and 255
                val green = pixels[i + 1].toInt() and 255
                val blue = pixels[i + 2].toInt() and 255
                val blueGray =
                    blue > red + V.fishBlueOverRed &&
                        green > red + V.fishGreenOverRed &&
                        blue in 65..235 &&
                        green > 50
                if (blueGray) {
                    hits++
                    if (y + r.y < bar.top) above++
                }
            }
            val s = hits.toFloat() / r.height
            if (s > score && above >= max(2, (bar.height * .15).toInt())) {
                score = s
                best = x
            }
        }
        if (best < 0 || score < V.fishMinVerticalSupport)
            return Detection.missing(kind, f.timestamp)
        // Indicator line, including extension above the rail, disambiguates player arrows.
        val x = (r.x + best).toFloat()
        val half = max(1f, bar.height * .12f)
        return Detection(
            kind,
            Box(x - half, bar.top - bar.height * .45f, x + half, bar.bottom + bar.height * .3f),
            (.66f + score * .29f).coerceAtMost(.95f),
            f.timestamp,
        )
    }
}
