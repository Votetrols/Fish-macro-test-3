package br.dev.fischvision.control

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import br.dev.fischvision.config.Settings
import br.dev.fischvision.model.*
import br.dev.fischvision.safety.*
import br.dev.fischvision.ui.Logs

class InputController(private val cfg: Settings) {
    private val main = Handler(Looper.getMainLooper())
    private val guard = InputSafetyGuard(cfg.minConfidence, cfg.maxFrameAgeMs)
    @Volatile private var context: SafetyContext? = null
    @Volatile private var frameTime = 0L
    @Volatile private var stopped = false
    private var active = Decision(Action.NONE)
    private var lastLogged = ""
    private var tapPending = false
    private var lastDenial = ""
    private var lastDenialTime = 0L

    private fun logDenial(reason: String) {
        val now = SystemClock.elapsedRealtime()
        if (reason != lastDenial || now - lastDenialTime > 1000) {
            Logs.event("INPUT", "BLOCKED: $reason")
            lastDenial = reason
            lastDenialTime = now
        }
    }

    fun update(c: SafetyContext, frameTimestamp: Long) {
        context = c
        frameTime = frameTimestamp
    }

    private fun allowed(d: Decision): Boolean {
        val c = context ?: return false
        return !stopped &&
            !EmergencyStop.active &&
            guard.denial(
                c.copy(
                    frameAgeMs = SystemClock.elapsedRealtime() - frameTime,
                    roblox = c.roblox && GestureService.instance?.foregroundRoblox() == true,
                    emergency = EmergencyStop.active,
                ),
                d,
            ) == null
    }

    fun execute(d: Decision, scaleX: Float, scaleY: Float, acknowledge: (Boolean) -> Unit) {
        if (d.action == Action.NONE) return
        main.post {
            if (d.action == Action.RELEASE) {
                GestureService.instance?.release()
                active = d
                acknowledge(true)
                return@post
            }
            val c = context
            // Simulation is logged, never dispatches. Guard checks still run except user real-input
            // opt-in.
            val denial =
                if (c == null) "no context"
                else
                    guard.denial(
                        c.copy(
                            enabled = !stopped,
                            frameAgeMs = SystemClock.elapsedRealtime() - frameTime,
                        ),
                        d,
                    )
            if (denial != null || stopped || EmergencyStop.active) {
                logDenial(denial ?: "stopped/emergency")
                GestureService.instance?.release()
                acknowledge(false)
                return@post
            }
            if (!cfg.realInput) {
                if (lastLogged != d.action.name) {
                    Logs.event("CONTROL", "SIMULATED ${d.action}")
                    lastLogged = d.action.name
                }
                acknowledge(true)
                return@post
            }
            if (!allowed(d)) {
                GestureService.instance?.release()
                acknowledge(false)
                return@post
            }
            val p = d.point!!
            val mapped = Point(p.x * scaleX, p.y * scaleY)
            if (br.dev.fischvision.ui.DebugOverlay.blocks(mapped)) {
                GestureService.instance?.release()
                Logs.event("INPUT", "target blocked by emergency button")
                acknowledge(false)
                return@post
            }
            val leaseMs =
                if (d.action == Action.HOLD && d.durationMs <= cfg.holdQuantumMs)
                    cfg.holdQuantumMs * 2
                else d.durationMs
            if (d.action == Action.TAP && active.action == Action.HOLD) {
                GestureService.instance?.release()
                active = Decision(Action.RELEASE)
                acknowledge(false)
                return@post
            }
            if (d.action == Action.TAP && tapPending) return@post
            if (d.action == Action.TAP) tapPending = true
            val accepted =
                GestureService.instance?.request(
                    mapped,
                    leaseMs,
                    cfg.holdQuantumMs,
                    { allowed(d) },
                    if (d.action == Action.TAP)
                        ({ success ->
                            tapPending = false
                            acknowledge(success && !stopped)
                        })
                    else null,
                ) == true
            if (!accepted) tapPending = false
            if (accepted && (active.action != d.action || d.action == Action.TAP))
                Logs.event(
                    "INPUT",
                    d.action.name,
                    mapOf("x" to mapped.x, "y" to mapped.y, "durationMs" to d.durationMs),
                )
            active = d
            if (d.action != Action.TAP || !accepted) acknowledge(accepted)
        }
    }

    fun release() {
        main.post { GestureService.instance?.release() }
    }

    fun stop() {
        stopped = true
        context = null
        release()
    }
}
