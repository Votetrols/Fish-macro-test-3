package br.dev.fischvision.vision

import br.dev.fischvision.config.VisionProfile as V
import br.dev.fischvision.model.*
import kotlin.math.*
import org.opencv.core.*
import org.opencv.imgproc.Imgproc

class FishingBarDetector : Detector, AutoCloseable {
    override val kind = Kind.BAR
    private val mask = Mat()
    private val joined = Mat()
    private val hierarchy = Mat()
    private var kernel = Mat()
    private var kernelWidth = 0

    override fun detect(f: VisionFrame, context: Map<Kind, Detection>): Detection {
        val y = (f.height * V.railRoiTop).toInt()
        val roi = f.gray.submat(Rect(0, y, f.width, (f.height * V.railRoiHeight).toInt()))
        Imgproc.threshold(roi, mask, V.darkLuma, 255.0, Imgproc.THRESH_BINARY_INV)
        // Include the white player at an endpoint: closing dark pixels alone truncates the rail.
        val bright = Mat()
        Imgproc.threshold(roi, bright, V.brightLuma, 255.0, Imgproc.THRESH_BINARY)
        Core.bitwise_or(mask, bright, mask)
        bright.release()
        val kw = (f.width * V.railClosingFraction).toInt().coerceAtLeast(3) or 1
        if (kw != kernelWidth) {
            kernel.release()
            kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(kw.toDouble(), 1.0))
            kernelWidth = kw
        }
        Imgproc.morphologyEx(mask, joined, Imgproc.MORPH_CLOSE, kernel)
        val contours = mutableListOf<MatOfPoint>()
        Imgproc.findContours(
            joined,
            contours,
            hierarchy,
            Imgproc.RETR_EXTERNAL,
            Imgproc.CHAIN_APPROX_SIMPLE,
        )
        var best: Box? = null
        var bestScore = 0f
        contours.forEach { c ->
            val r = Imgproc.boundingRect(c)
            val aspect = r.width.toFloat() / r.height
            if (
                r.width > f.width * V.minRailWidth &&
                    r.width < f.width * V.maxRailWidth &&
                    r.height > f.height * V.minRailHeight &&
                    r.height < f.height * V.maxRailHeight &&
                    aspect in V.minRailAspect..V.maxRailAspect
            ) {
                val b =
                    Box(
                        r.x.toFloat(),
                        (r.y + y).toFloat(),
                        (r.x + r.width).toFloat(),
                        (r.y + y + r.height).toFloat(),
                    )
                val centered = 1 - abs(b.center.x / f.width - .5f)
                val fill = (Imgproc.contourArea(c) / (r.width * r.height)).toFloat()
                val score = .55f + .20f * fill + .10f * centered
                if (score > bestScore) {
                    best = b
                    bestScore = score
                }
            }
            c.release()
        }
        roi.release()
        return if (best == null) Detection.missing(kind, f.timestamp)
        else Detection(kind, best, bestScore, f.timestamp)
    }

    override fun close() {
        mask.release()
        joined.release()
        hierarchy.release()
        kernel.release()
    }
}
