package br.dev.fischvision.capture

import android.content.Context
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.SystemClock
import android.view.WindowManager
import br.dev.fischvision.config.Settings
import br.dev.fischvision.ui.Logs
import kotlin.math.roundToInt

/**
 * Projection is single-use. Orientation changes intentionally stop the run and request new consent.
 */
class ScreenCapture(
    private val c: Context,
    private val projection: MediaProjection,
    private val handler: Handler,
    private val cfg: Settings,
    private val onFrame: (CapturedFrame) -> Unit,
    private val onError: (String) -> Unit,
) : AutoCloseable {
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var closed = false
    private var last = 0L
    private var raw: Bitmap? = null
    private val pool = BitmapPool()
    private val wm = c.getSystemService(WindowManager::class.java)

    @Suppress("DEPRECATION")
    private fun dimensions(): Triple<Int, Int, Int> {
        val m = android.util.DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return Triple(m.widthPixels, m.heightPixels, wm.defaultDisplay.rotation)
    }

    private val initial = dimensions()
    private val callback =
        object : MediaProjection.Callback() {
            override fun onStop() {
                if (!closed) onError("MediaProjection revoked")
            }

            override fun onCapturedContentResize(width: Int, height: Int) {
                if (width != initial.first || height != initial.second)
                    onError(
                        "Capture is not full display or orientation changed; restart with entire screen"
                    )
            }

            override fun onCapturedContentVisibilityChanged(isVisible: Boolean) {
                if (!isVisible) onError("Captured content hidden")
            }
        }

    fun start() {
        val (w, h, _) = initial
        projection.registerCallback(callback, handler)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener(
            { source ->
                val image =
                    try {
                        source.acquireLatestImage()
                    } catch (e: Exception) {
                        onError(e.toString())
                        null
                    } ?: return@setOnImageAvailableListener
                try {
                    val now = SystemClock.elapsedRealtime()
                    if (closed || now - last < 1000 / cfg.fps) return@setOnImageAvailableListener
                    if (dimensions() != initial) {
                        onError("Display changed; restart capture")
                        return@setOnImageAvailableListener
                    }
                    last = now
                    val plane = image.planes[0]
                    val padded = plane.rowStride / plane.pixelStride
                    if (raw?.width != padded || raw?.height != h) {
                        raw?.recycle()
                        raw = Bitmap.createBitmap(padded, h, Bitmap.Config.ARGB_8888)
                    }
                    plane.buffer.rewind()
                    raw!!.copyPixelsFromBuffer(plane.buffer)
                    val scale = minOf(1f, cfg.processingWidth.toFloat() / w)
                    val bitmap = pool.acquire((w * scale).roundToInt(), (h * scale).roundToInt())
                    Canvas(bitmap)
                        .drawBitmap(
                            raw!!,
                            Rect(0, 0, w, h),
                            Rect(0, 0, bitmap.width, bitmap.height),
                            null,
                        )
                    val imageAge =
                        ((System.nanoTime() - image.timestamp) / 1_000_000).coerceAtLeast(0)
                    // Image timestamp is in the monotonic nanoTime clock; translate to
                    // elapsedRealtime.
                    onFrame(
                        CapturedFrame(bitmap, now - imageAge, w, h, initial.third, pool::release)
                    )
                } catch (e: Exception) {
                    onError("Frame: ${e.message}")
                } finally {
                    image.close()
                }
            },
            handler,
        )
        display =
            projection.createVirtualDisplay(
                "FischVision",
                w,
                h,
                c.resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader!!.surface,
                null,
                handler,
            )
        Logs.event(
            "CAPTURE",
            "started",
            mapOf("width" to w, "height" to h, "rotation" to initial.third),
        )
    }

    override fun close() {
        if (closed) return
        closed = true
        reader?.setOnImageAvailableListener(null, null)
        display?.release()
        reader?.close()
        projection.unregisterCallback(callback)
        projection.stop()
        raw?.recycle()
        raw = null
        pool.close()
    }
}
