package br.dev.fischvision.vision

import android.graphics.Bitmap
import br.dev.fischvision.model.*
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.opencv.core.*

/** Event-language confirmation. Never accepts a fish name floating in the world. */
class CatchConfirmationDetector : AutoCloseable {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    fun detectShake(bitmap: Bitmap, f: VisionFrame): Detection {
        val text = Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap, 0)))
        val line =
            text.textBlocks
                .flatMap { it.lines }
                .firstOrNull { it.text.trim().uppercase().replace(" ", "").trim('!') == "SHAKE" }
                ?: return Detection.missing(Kind.SHAKE, f.timestamp)
        val rect = line.boundingBox ?: return Detection.missing(Kind.SHAKE, f.timestamp)
        val cx = rect.exactCenterX()
        val cy = rect.exactCenterY()
        val radius = rect.width() * .72f
        if (rect.width() < f.width * .015f || rect.width() > f.width * .20f)
            return Detection.missing(Kind.SHAKE, f.timestamp)
        return Detection(
            Kind.SHAKE,
            Box(
                (cx - radius).coerceAtLeast(0f),
                (cy - radius).coerceAtLeast(0f),
                (cx + radius).coerceAtMost(f.width.toFloat()),
                (cy + radius).coerceAtMost(f.height.toFloat()),
            ),
            .90f,
            f.timestamp,
        )
    }

    fun detect(bitmap: Bitmap, f: VisionFrame): Detection {
        val text = Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap, 0)))
        val lines = text.textBlocks.flatMap { it.lines }
        val line =
            lines.firstOrNull {
                it.text.contains("you just caught", true) ||
                    it.text.contains("você acabou de", true) ||
                    it.text.contains("voce acabou de", true)
            } ?: return Detection.missing(Kind.CATCH, f.timestamp)
        val rect = line.boundingBox ?: return Detection.missing(Kind.CATCH, f.timestamp)
        val message = line.text
        if (message.length < 19) return Detection.missing(Kind.CATCH, f.timestamp)
        // Visual object/illustration evidence above the toast: necessary but not semantic
        // classification.
        val region =
            Box(
                    rect.left.toFloat(),
                    (rect.top - f.height * .22f).coerceAtLeast(0f),
                    rect.right.toFloat(),
                    rect.top.toFloat(),
                )
                .rect(f.width, f.height)
        val roi = f.gray.submat(region)
        val mean = MatOfDouble()
        val std = MatOfDouble()
        Core.meanStdDev(roi, mean, std)
        val textured = std.toArray()[0] > 14
        roi.release()
        mean.release()
        std.release()
        return if (!textured) Detection.missing(Kind.CATCH, f.timestamp)
        else
            Detection(
                Kind.CATCH,
                Box(
                    rect.left.toFloat(),
                    rect.top.toFloat(),
                    rect.right.toFloat(),
                    rect.bottom.toFloat(),
                ),
                .86f,
                f.timestamp,
                text = message,
            )
    }

    override fun close() {
        recognizer.close()
    }
}
