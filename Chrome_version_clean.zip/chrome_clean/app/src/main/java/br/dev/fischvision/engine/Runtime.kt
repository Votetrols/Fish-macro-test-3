package br.dev.fischvision.engine

import br.dev.fischvision.model.Snapshot

object Runtime {
    @Volatile var snapshot = Snapshot()
    @Volatile var stop: (() -> Unit)? = null
}
