package br.dev.fischvision.model

import kotlin.math.*

data class Point(val x: Float, val y: Float)

data class Box(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width
        get() = right - left

    val height
        get() = bottom - top

    val center
        get() = Point((left + right) / 2, (top + bottom) / 2)

    fun normalizeX(x: Float) = ((x - left) / width).coerceIn(0f, 1f)

    fun iou(b: Box): Float {
        val a =
            max(0f, min(right, b.right) - max(left, b.left)) *
                max(0f, min(bottom, b.bottom) - max(top, b.top))
        return a / max(1f, width * height + b.width * b.height - a)
    }
}

enum class Kind {
    ROD,
    SHAKE,
    BAR,
    FISH,
    PLAYER,
    PROGRESS,
    CATCH,
    ROBLOX,
}

data class Detection(
    val kind: Kind,
    val box: Box?,
    val confidence: Float,
    val timestamp: Long,
    val value: Float? = null,
    val text: String? = null,
) {
    val detected
        get() = box != null && confidence > 0f

    companion object {
        fun missing(k: Kind, t: Long) = Detection(k, null, 0f, t)
    }
}

data class Observation(
    val timestamp: Long,
    val width: Int,
    val height: Int,
    val detections: Map<Kind, Detection>,
) {
    operator fun get(k: Kind) = detections[k] ?: Detection.missing(k, timestamp)
}

data class Track(
    val position: Float,
    val velocity: Float,
    val acceleration: Float,
    val confidence: Float,
    val ageMs: Long,
    val width: Float = 0f,
) {
    val direction
        get() =
            when {
                velocity > .01f -> 1
                velocity < -.01f -> -1
                else -> 0
            }
}

enum class Action {
    NONE,
    TAP,
    HOLD,
    RELEASE,
}

data class Decision(
    val action: Action,
    val point: Point? = null,
    val durationMs: Long = 0,
    val confidence: Float = 0f,
    val error: Float = 0f,
    val reason: String = "",
)

enum class State {
    IDLE,
    SEARCH_FISHING_BUTTON,
    CASTING,
    SEARCHING_SHAKE,
    PRESSING_SHAKE,
    FISHING_MINIGAME_DETECTED,
    TRACKING_FISH,
    CONTROLLING_PLAYER_BAR,
    CATCH_CONFIRMATION,
    RESET,
    VISION_LOST,
    CAPTURE_ERROR,
    ROBLOX_NOT_DETECTED,
    INVALID_STATE,
    EMERGENCY_STOP,
}

data class Snapshot(
    val state: State = State.IDLE,
    val fps: Float = 0f,
    val latencyMs: Long = 0,
    val observation: Observation? = null,
    val fish: Track? = null,
    val player: Track? = null,
    val decision: Decision = Decision(Action.NONE),
    val progressTrend: Float = 0f,
    val capture: Boolean = false,
    val roblox: Boolean = false,
    val simulated: Boolean = true,
    val message: String = "Parado",
)
