package br.dev.fischvision.config

/**
 * Appearance priors, NOT touch coordinates. Tune this profile when the game changes its UI.
 * Reference short side is only the scale of the bundled image assets, not a device requirement.
 */
object VisionProfile {
    const val referenceShortSide = 480.0
    val templateScales = listOf(.70, .85, 1.0, 1.15, 1.32)
    const val railRoiTop = .50
    const val railRoiHeight = .46
    const val darkLuma = 45.0
    const val brightLuma = 180.0
    const val playerLuma = 175
    const val railClosingFraction = .14
    const val minRailWidth = .20
    const val maxRailWidth = .86
    const val minRailHeight = .014
    const val maxRailHeight = .075
    const val minRailAspect = 7f
    const val maxRailAspect = 60f
    const val fishBlueOverRed = 9
    const val fishGreenOverRed = 3
    const val fishMinVerticalSupport = .53f
    const val minPlayerContrast = 18
}
