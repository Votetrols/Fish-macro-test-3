package br.dev.fischvision.capture

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.*
import br.dev.fischvision.config.Settings
import br.dev.fischvision.control.GestureService
import br.dev.fischvision.engine.*
import br.dev.fischvision.model.*
import br.dev.fischvision.safety.EmergencyStop
import br.dev.fischvision.ui.Logs
import br.dev.fischvision.ui.MainActivity
import org.opencv.android.OpenCVLoader

class CaptureService : Service() {
    private var capture: ScreenCapture? = null
    private var engine: FishingEngine? = null
    private var thread: HandlerThread? = null
    private val main = Handler(Looper.getMainLooper())
    private var closing = false

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        Logs.init(this)
        Runtime.stop = { main.post { stopRun(false) } }
        EmergencyStop.release = {
            GestureService.instance?.release()
            main.post { stopRun(true) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            EmergencyStop.trigger()
            stopRun(true)
            return START_NOT_STICKY
        }
        if (capture != null || intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                "capture",
                "Captura e parada de emergência",
                NotificationManager.IMPORTANCE_LOW,
            )
        )
        val stop =
            PendingIntent.getService(
                this,
                2,
                Intent(this, javaClass).setAction("STOP"),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
        val open =
            PendingIntent.getActivity(
                this,
                1,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE,
            )
        val notification =
            Notification.Builder(this, "capture")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Fisch Vision — captura ativa")
                .setContentText("Toque em PARAR para liberar gestos e encerrar")
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(Notification.Action.Builder(null, "PARAR", stop).build())
                .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(10, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(10, notification)
        try {
            check(OpenCVLoader.initLocal()) { "OpenCV initialization failed" }
            val data =
                if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra("projection", Intent::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra<Intent>("projection")
            requireNotNull(data) { "Missing projection consent" }
            val cfg = Settings.load(this).copy(realInput = intent.getBooleanExtra("real", false))
            engine = FishingEngine(this, cfg)
            thread = HandlerThread("FrameCapture").apply { start() }
            val handler = Handler(thread!!.looper)
            val projection =
                getSystemService(MediaProjectionManager::class.java)
                    .getMediaProjection(Activity.RESULT_OK, data)
            capture =
                ScreenCapture(
                    this,
                    projection,
                    handler,
                    cfg,
                    { engine?.offer(it) ?: it.close() },
                    { message -> main.post { engine?.fail(message) } },
                )
            capture!!.start()
            Runtime.snapshot =
                Snapshot(
                    capture = true,
                    simulated = !cfg.realInput,
                    message = "Abra o Roblox; captura da tela inteira necessária",
                )
        } catch (e: Exception) {
            Logs.event("ERROR", "Start: $e")
            Runtime.snapshot = Snapshot(state = State.CAPTURE_ERROR, message = e.toString())
            stopRun(false)
        }
        return START_NOT_STICKY
    }

    private fun stopRun(emergency: Boolean) {
        if (closing) return
        closing = true
        GestureService.instance?.release()
        engine?.close()
        engine = null
        val c = capture
        capture = null
        val h = thread
        if (h != null)
            Handler(h.looper).post {
                c?.close()
                h.quitSafely()
            }
        else c?.close()
        thread = null
        Runtime.snapshot =
            Runtime.snapshot.copy(
                capture = false,
                state = if (emergency) State.EMERGENCY_STOP else Runtime.snapshot.state,
                message = if (emergency) "Parada de emergência" else Runtime.snapshot.message,
            )
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopRun(false)
        Runtime.stop = null
        EmergencyStop.release = { GestureService.instance?.release() }
        super.onDestroy()
    }
}
