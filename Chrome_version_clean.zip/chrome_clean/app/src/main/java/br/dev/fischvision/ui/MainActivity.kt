package br.dev.fischvision.ui

import android.Manifest
import android.app.*
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings as AndroidSettings
import android.widget.*
import br.dev.fischvision.capture.CaptureService
import br.dev.fischvision.config.Settings
import br.dev.fischvision.control.GestureService
import br.dev.fischvision.engine.Runtime
import br.dev.fischvision.safety.EmergencyStop

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var real: Switch
    private lateinit var debug: Switch
    private val fields = linkedMapOf<String, EditText>()
    private val handler = Handler(Looper.getMainLooper())
    private var pendingReal = false
    private val refresh =
        object : Runnable {
            override fun run() {
                val s = Runtime.snapshot
                status.text =
                    "Captura: ${s.capture} | Roblox: ${s.roblox}\nEstado: ${s.state}\nModo: ${if(s.simulated) "simulado" else "real"} | FPS %.1f | %d ms\n${s.message}"
                        .format(s.fps, s.latencyMs)
                log.text = Logs.text().takeLast(9000)
                handler.postDelayed(this, 700)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Logs.init(this)
        val layout =
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(24, 24, 24, 24)
            }
        setContentView(ScrollView(this).apply { addView(layout) })
        layout.setOnApplyWindowInsetsListener { view, insets ->
            @Suppress("DEPRECATION")
            view.setPadding(
                24 + insets.systemWindowInsetLeft,
                24 + insets.systemWindowInsetTop,
                24 + insets.systemWindowInsetRight,
                24 + insets.systemWindowInsetBottom,
            )
            insets
        }
        fun text(t: String, size: Float = 16f) =
            TextView(this).apply {
                text = t
                textSize = size
                layout.addView(this)
            }
        fun button(t: String, action: () -> Unit) {
            layout.addView(
                Button(this).apply {
                    text = t
                    setOnClickListener { action() }
                }
            )
        }
        text("Fisch Vision", 26f)
        text(
            "Projeto de teste • visão local • sem root\nComece em SIMULADO. Use tela inteira na captura. Não use em contas ou jogos onde automação seja proibida."
        )
        status = text("Parado")
        button("1. Habilitar acessibilidade") {
            startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        real =
            Switch(this).apply {
                text = "Permitir toques reais nesta execução"
                isChecked = false
            }
        layout.addView(real)
        val cfg = Settings.load(this)
        debug =
            Switch(this).apply {
                text = "Debug visual"
                isChecked = cfg.debug
                setOnCheckedChangeListener { _, v ->
                    Settings.load(this@MainActivity).copy(debug = v).save(this@MainActivity)
                }
            }
        layout.addView(debug)
        button("START / Solicitar captura") { begin() }
        button("STOP") {
            EmergencyStop.trigger()
            startService(Intent(this, CaptureService::class.java).setAction("STOP"))
        }
        button("EMERGENCY STOP — liberar e parar") {
            EmergencyStop.trigger()
            startService(Intent(this, CaptureService::class.java).setAction("STOP"))
        }
        text("Configurações (aplicadas no próximo Start)", 20f)
        fun field(name: String, value: Any) {
            text(name)
            val e =
                EditText(this).apply {
                    setText(value.toString())
                    inputType =
                        android.text.InputType.TYPE_CLASS_NUMBER or
                            android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                }
            fields[name] = e
            layout.addView(e)
        }
        field("FPS (10–45)", cfg.fps)
        field("Largura de processamento (640–1600)", cfg.processingWidth)
        field("Kp", cfg.kp)
        field("Kd", cfg.kd)
        field("Confiança mínima (0.50–0.98)", cfg.minConfidence)
        field("Deadband", cfg.deadband)
        field("Carga da vara ms (500–5000)", cfg.castMs)
        field("Segmento hold ms (30–100)", cfg.holdQuantumMs)
        button("Salvar configurações") { save() }
        button("Exportar logs JSONL") {
            startActivityForResult(
                Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    type = "application/json"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    putExtra(Intent.EXTRA_TITLE, "fisch-events.jsonl")
                },
                3,
            )
        }
        text("Logs", 20f)
        log = text("", 11f)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
    }

    private fun save(): Boolean =
        try {
            val v = fields.values.map { it.text.toString() }
            Settings.load(this)
                .copy(
                    debug = debug.isChecked,
                    fps = v[0].toInt(),
                    processingWidth = v[1].toInt(),
                    kp = v[2].toFloat(),
                    kd = v[3].toFloat(),
                    minConfidence = v[4].toFloat(),
                    deadband = v[5].toFloat(),
                    castMs = v[6].toLong(),
                    holdQuantumMs = v[7].toLong(),
                )
                .validate()
                .save(this)
            Toast.makeText(this, "Configurações salvas", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            Toast.makeText(this, "Valor inválido: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }

    private fun begin() {
        if (Runtime.snapshot.capture) {
            Toast.makeText(this, "Pare a execução atual primeiro", Toast.LENGTH_SHORT).show()
            return
        }
        if (GestureService.instance == null) {
            Toast.makeText(this, "Habilite o serviço de acessibilidade primeiro", Toast.LENGTH_LONG)
                .show()
            return
        }
        if (!save()) return
        pendingReal = real.isChecked
        if (pendingReal)
            AlertDialog.Builder(this)
                .setTitle("Autorizar gestos reais?")
                .setMessage(
                    "Ainda não validado no Roblox. Use PARAR na sobreposição ou na notificação. Gestos são limitados a quadros recentes, jogo em primeiro plano e confiança suficiente."
                )
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Autorizar") { _, _ -> consent() }
                .show()
        else consent()
    }

    private fun consent() {
        val m = getSystemService(MediaProjectionManager::class.java)
        val i =
            if (Build.VERSION.SDK_INT >= 34)
                m.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
            else m.createScreenCaptureIntent()
        startActivityForResult(i, 1)
    }

    @Deprecated("Activity API kept deliberately minimal")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CaptureService::class.java)
                    .putExtra("projection", data)
                    .putExtra("real", pendingReal)
            )
            real.isChecked = false
        }
        if (requestCode == 3 && resultCode == RESULT_OK)
            data?.data?.let { uri ->
                contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
                    it.write(Logs.export())
                }
            }
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }
}
