package br.dev.fischvision

import br.dev.fischvision.config.Settings
import br.dev.fischvision.control.*
import br.dev.fischvision.model.*
import br.dev.fischvision.safety.*
import br.dev.fischvision.state.FishingStateMachine
import br.dev.fischvision.tracking.*
import org.junit.Assert.*
import org.junit.Test

class CoreTests {
    private val cfg = Settings()
    private val bar = Box(100f, 300f, 500f, 320f)

    private fun det(k: Kind, t: Long, b: Box = bar, v: Float? = null) = Detection(k, b, .95f, t, v)

    private fun obs(t: Long, vararg kinds: Kind) =
        Observation(t, 1000, 500, kinds.associateWith { det(it, t) })

    private fun ctx() =
        SafetyContext(true, true, true, false, State.CONTROLLING_PLAYER_BAR, 20, .95f, true, true)

    private val hold = Decision(Action.HOLD, Point(200f, 310f), 65, .95f)

    @Test
    fun guardRejectsEveryUnsafeCondition() {
        val g = InputSafetyGuard(.7f, 180)
        val c = ctx()
        assertNull(g.denial(c, hold))
        listOf(
                c.copy(enabled = false),
                c.copy(capture = false),
                c.copy(roblox = false),
                c.copy(emergency = true),
                c.copy(state = State.IDLE),
                c.copy(frameAgeMs = 181),
                c.copy(frameAgeMs = -1),
                c.copy(confidence = .69f),
                c.copy(tracking = false),
                c.copy(geometryValid = false),
            )
            .forEach { assertNotNull(g.denial(it, hold)) }
        assertNotNull(g.denial(c, hold.copy(point = Point(Float.NaN, 1f))))
        assertNotNull(g.denial(c, hold.copy(confidence = .3f)))
    }

    @Test
    fun releaseAlwaysAllowedEvenDuringEmergency() {
        assertNull(
            InputSafetyGuard(.7f, 180)
                .denial(ctx().copy(enabled = false, emergency = true), Decision(Action.RELEASE))
        )
    }

    @Test
    fun tracksReverseWithoutLongFilterLag() {
        val f = FishTracker(140)
        fun at(x: Float, t: Long) =
            f.update(det(Kind.FISH, t, Box(x - 1, 300f, x + 1, 320f)), bar, t)!!
        at(250f, 1000)
        assertTrue(at(270f, 1050).velocity > 0)
        assertTrue(at(250f, 1100).velocity < 0)
    }

    @Test
    fun missingTrackExpiresAndDoesNotClaimFreshness() {
        val f = FishTracker(140)
        f.update(det(Kind.FISH, 1000), bar, 1000)
        val p = f.update(Detection.missing(Kind.FISH, 1060), bar, 1060)!!
        assertEquals(60L, p.ageMs)
        assertTrue(p.confidence < .95f)
        assertNull(f.update(Detection.missing(Kind.FISH, 1200), bar, 1200))
    }

    @Test
    fun reacquiredTrackHasNoAncientVelocity() {
        val f = FishTracker(140)
        f.update(det(Kind.FISH, 1000), bar, 1000)
        val t = f.update(det(Kind.FISH, 2000, Box(450f, 300f, 454f, 320f)), bar, 2000)!!
        assertEquals(0f, t.velocity, .0001f)
    }

    @Test
    fun positionsAreBarRelativeNotScreenRelative() {
        assertEquals(.25f, bar.normalizeX(200f), .0001f)
        assertEquals(.25f, Box(0f, 0f, 1000f, 20f).normalizeX(250f), .0001f)
    }

    @Test
    fun controllerFailsSafeWithoutTracks() {
        assertEquals(
            Action.RELEASE,
            FishingController(cfg).decide(null, null, bar, 1000, 0f).action,
        )
    }

    @Test
    fun controllerUsesVelocityNotOnlySignOfError() {
        val p = Track(.5f, 1.5f, 0f, .95f, 0, .3f)
        val f = Track(.53f, -1f, 0f, .95f, 0)
        assertEquals(Action.RELEASE, FishingController(cfg).decide(f, p, bar, 1000, 0f).action)
        val forward =
            FishingController(cfg)
                .decide(
                    f.copy(position = .75f, velocity = .3f),
                    p.copy(velocity = -.2f),
                    bar,
                    1000,
                    0f,
                )
        assertEquals(Action.HOLD, forward.action)
    }

    @Test
    fun controllerDoesNotPushPastRightLimit() {
        val p = Track(.85f, .1f, 0f, .95f, 0, .3f)
        val f = Track(.85f, 0f, 0f, .95f, 0)
        assertEquals(Action.RELEASE, FishingController(cfg).decide(f, p, bar, 1000, 0f).action)
    }

    @Test
    fun shakeRequiresVisualChangeNotClickCountOrTimer() {
        val s = ShakeController()
        val d = det(Kind.SHAKE, 1000)
        assertNotNull(s.decide(d))
        s.acknowledge(bar)
        assertNull(s.decide(d.copy(timestamp = 5000)))
        assertNotNull(s.decide(d.copy(box = Box(600f, 50f, 660f, 110f))))
        s.decide(Detection.missing(Kind.SHAKE, 5100))
        s.decide(Detection.missing(Kind.SHAKE, 5300))
        assertNotNull(s.decide(d.copy(timestamp = 5400)))
    }

    @Test
    fun temporalVoteRequiresConsistentLocation() {
        val v = ConfidenceTracker()
        assertTrue(v.accept(det(Kind.ROD, 1000)).confidence < .7f)
        assertTrue(v.accept(det(Kind.ROD, 1040)).confidence > .7f)
        assertTrue(v.accept(det(Kind.ROD, 1080, Box(600f, 50f, 660f, 110f))).confidence < .7f)
    }

    @Test
    fun noShakeTimeoutOrAutomaticRecast() {
        val m = FishingStateMachine(cfg)
        m.start(1000)
        m.transition(State.SEARCHING_SHAKE, 1100)
        assertEquals(Action.NONE, m.step(obs(1_000_000), null, null, 0f).action)
        assertEquals(State.SEARCHING_SHAKE, m.state)
    }

    @Test
    fun unconfirmedDisappearanceNeverCountsAsCatch() {
        val m = FishingStateMachine(cfg)
        m.start(1000)
        m.transition(State.TRACKING_FISH, 1000)
        m.step(obs(1100), null, null, 0f)
        m.step(obs(1400), null, null, 0f)
        assertEquals(State.CATCH_CONFIRMATION, m.state)
        m.step(obs(100000, Kind.ROD), null, null, 0f)
        assertEquals(State.CATCH_CONFIRMATION, m.state)
    }

    @Test
    fun confirmedCatchMustDisappearBeforeRecast() {
        val m = FishingStateMachine(cfg)
        m.start(1000)
        m.transition(State.CATCH_CONFIRMATION, 1100)
        m.step(obs(1200, Kind.CATCH), null, null, 0f)
        m.step(obs(1900, Kind.CATCH, Kind.ROD), null, null, 0f)
        assertEquals(State.CATCH_CONFIRMATION, m.state)
        m.step(obs(2000, Kind.ROD), null, null, 0f)
        m.step(obs(2700, Kind.ROD), null, null, 0f)
        assertEquals(State.RESET, m.state)
        m.step(obs(2800, Kind.ROD), null, null, 0f)
        assertEquals(State.SEARCH_FISHING_BUTTON, m.state)
    }

    @Test
    fun initialForegroundLossDoesNotSkipRodSearch() {
        val m = FishingStateMachine(cfg)
        m.start(1000)
        m.fault(State.ROBLOX_NOT_DETECTED, 1100)
        m.step(obs(1200), null, null, 0f)
        assertEquals(State.SEARCH_FISHING_BUTTON, m.state)
    }

    @Test
    fun castRequiresAcknowledgement() {
        val m = FishingStateMachine(cfg)
        m.start(1000)
        m.step(obs(1040, Kind.ROD), null, null, 0f)
        val d = m.step(obs(1080, Kind.ROD), null, null, 0f)
        assertEquals(Action.HOLD, d.action)
        m.step(obs(5000), null, null, 0f)
        assertEquals(State.CASTING, m.state)
        m.acknowledge(d, obs(5100, Kind.ROD))
        m.step(obs(5150), null, null, 0f)
        assertEquals(State.CASTING, m.state)
        m.step(obs(8200), null, null, 0f)
        assertEquals(State.SEARCHING_SHAKE, m.state)
    }

    @Test
    fun progressTrendRespondsToLoss() {
        val t = ProgressTracker()
        t.update(det(Kind.PROGRESS, 1000, v = .5f))
        t.update(det(Kind.PROGRESS, 1100, v = .4f))
        assertTrue(t.trend < 0)
    }

    @Test
    fun emergencyIsLatchedUntilExplicitArm() {
        EmergencyStop.arm()
        EmergencyStop.trigger()
        assertTrue(EmergencyStop.active)
        EmergencyStop.arm()
        assertFalse(EmergencyStop.active)
    }

    @Test
    fun guardRejectsNaNConfidenceAndInvalidDurations() {
        val g = InputSafetyGuard(.7f, 180)
        assertNotNull(g.denial(ctx(), hold.copy(confidence = Float.NaN)))
        assertNotNull(g.denial(ctx().copy(confidence = Float.NaN), hold))
        assertNotNull(g.denial(ctx(), hold.copy(durationMs = 0)))
        assertNotNull(g.denial(ctx(), hold.copy(point = Point(-1f, 20f))))
    }

    @Test
    fun minigameEvidenceTakesPriorityOverShake() {
        val m = FishingStateMachine(cfg)
        m.start(1000)
        m.transition(State.SEARCHING_SHAKE, 1100)
        val d = m.step(obs(1200, Kind.BAR, Kind.PROGRESS, Kind.SHAKE), null, null, 0f)
        assertEquals(Action.RELEASE, d.action)
        assertEquals(State.FISHING_MINIGAME_DETECTED, m.state)
    }
}
