# Fisch Vision — Android

**Versão 0.1.0-test · projeto novo · modo simulado por padrão**

Aplicativo Kotlin com captura MediaProjection, visão OpenCV + OCR local, tracking temporal,
máquina de estados, controlador preditivo PD e gestos de acessibilidade protegidos.
Implementação preparada para **testes iterativos no aparelho**, não um macro já validado em produção.

## O que foi entregue

- Projeto Android importável, Gradle Wrapper, código-fonte e testes unitários.
- Captura de tela inteira em foreground service, timestamps monotônicos, buffer latest-only e pool de bitmaps.
- Detectores independentes de vara, Shake, barra, peixe, jogador, progresso e confirmação.
- Tracking de posição, velocidade, aceleração aproximada, largura e confiança.
- Controle normalizado, previsão curta, compensação de deriva, histerese e limites.
- Máquina de estados para lançamento → Shakes visuais → minigame → confirmação → reinício.
- Input simulado/real, tap, hold por continuação, release e emergência.
- UI nativa em português, configurações, overlay, logs JSONL e exportação.
- Documentação do vídeo, arquitetura, segurança, limitações e roteiro de testes.

**Não foram executados testes no Roblox real, testes em aparelho ou ensaios de captura/gestos em emulador.**
Compilar e passar em testes unitários não demonstra que os detectores ou gestos funcionarão no seu telefone.

## Requisitos e compilação

- Android Studio compatível com AGP 8.7.3; JDK 17.
- Android SDK 35; Gradle 8.9; Kotlin 2.0.21.
- Android **9 / API 28 ou superior**. A compatibilidade declarada não substitui testes por fabricante.
- Dependências: OpenCV 4.10.0 e ML Kit Text Recognition 16.0.1 (modelo latino embarcado).
- Internet apenas para obter SDK/dependências durante o build; não existe backend do aplicativo.

Abra esta pasta como projeto no Android Studio. Deixe o IDE criar `local.properties` com seu SDK.
Ou configure `ANDROID_HOME` e execute:

```sh
./gradlew :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
# Windows: gradlew.bat :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.
Um APK debug universal é fornecido separadamente. Ele é assinado para desenvolvimento, não para publicação.

## Primeiro teste: SEM toques reais

1. Instale o APK ou compile e instale pelo Android Studio.
2. Abra o app e habilite **Fisch Vision** nas configurações de acessibilidade.
3. Mantenha **“Permitir toques reais nesta execução” desmarcado**.
4. Salve as configurações e toque em **START / Solicitar captura**.
5. Autorize **tela inteira**, não uma janela do Roblox. O mapeamento de input é de tela inteira.
6. Abra o Roblox/Fisch com a vara equipada e o personagem já posicionado para pescar.
7. Faça uma pesca manual enquanto observamos boxes, estados, posições, progresso e ações simuladas.
8. Exporte os logs. Compartilhe a gravação de tela e os dados descritos em `docs/TESTES_NO_APARELHO.md`.

O motor não equipa automaticamente a vara no inventário, não caminha e não escolhe o local da pesca.
Se a interface da vara não corresponder ao detector, não há fallback para clicar em uma coordenada fixa.

## Antes de qualquer input real

Leia `docs/SEGURANCA_E_LIMITACOES.md`. Pare a execução simulada antes de iniciar outra.
Cada execução real exige marcar a opção e confirmar o aviso. Essa autorização **não é persistida**.
Não ligue input real enquanto houver identificação errada de elementos, latência alta ou instabilidade de captura.
Automação pode contrariar regras do jogo/plataforma e resultar em restrições de conta; o app não contorna anticheat.

**PARAR** está disponível na sobreposição, na notificação e na tela do aplicativo.
Mudança de orientação encerra a execução e exige novo Start/consentimento; não reutilizamos coordenadas antigas.
Após perda de uma captura sem confirmação, o motor permanece esperando evidência; não relança às cegas.

## Configurações

Na interface: FPS solicitado, largura máxima de processamento, Kp, Kd, confiança mínima, deadband,
tempo de carga da vara e duração dos segmentos de hold. Debug pode ser desligado durante a execução;
as demais alterações se aplicam no próximo Start.

`config/Settings.kt` centraliza os parâmetros de controle/temporização (inclusive antecipação, tap,
histerese e validade de frames). `config/VisionProfile.kt` centraliza os principais limiares e priors de aparência.
Os demais coeficientes locais de validação geométrica são heurísticas explícitas dos detectores.
São **priors de aparência**, não posições absolutas de clique. Um novo tema/UI poderá exigir ajuste do perfil.

Padrões conservadores: 24 FPS solicitados, até 1066 px de largura de processamento, idade máxima de frame
180 ms, carga de 3000 ms, tap de 35 ms e segmentos de hold de 65 ms. São parâmetros de captura/atuador,
não uma sequência temporizada de pesca. FPS efetivo depende do aparelho; o vídeo fornecido não é uma medição do app.

## Documentos

- [Análise visual da referência](docs/ANALISE_VIDEO.md)
- [Arquitetura e fases](docs/ARQUITETURA.md)
- [Segurança e limitações conhecidas](docs/SEGURANCA_E_LIMITACOES.md)
- [Verificações executadas e evidências](docs/VERIFICACOES.md)
- [Roteiro para nossos testes no aparelho](docs/TESTES_NO_APARELHO.md)
- [Origem dos assets e dependências](docs/ORIGEM_E_DEPENDENCIAS.md)

O próximo passo é **observar o modo simulado no seu Android**. Não é prudente começar avaliando taxa de captura real.
