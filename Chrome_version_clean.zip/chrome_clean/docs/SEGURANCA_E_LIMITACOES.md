# Segurança e limitações conhecidas

## Antes de autorizar gestos

Esta versão é uma implementação para teste, **não foi validada no Roblox real** e não promete captura
bem-sucedida, ausência de falsos positivos ou suporte comprovado a todas as varas/aparelhos.
Use apenas onde automação for permitida. Não há bypass de anticheat, root, exploração do Roblox ou leitura da memória do jogo.

## Fail-safe implementado

Input exige simultaneamente:

- execução explicitamente habilitada e autorização de input real para a sessão;
- captura ativa, geometria de tela inteira consistente e frame recente;
- pacote ativo `com.roblox.client`, sem janela de sistema ativa, **e** logo visual;
- estado que permita aquele input;
- confiança suficiente, comandos finitos e duração válida;
- tracking válido para controle do minigame;
- emergência desarmada e ponto fora do botão de emergência.

Release nunca é bloqueado pelo guard. Uma janela fechada, notificação ativa ou perda de visão não autoriza
cliques de recuperação. O worker de visão não precisa responder para interromper a renovação de um hold:
o próprio callback dos segmentos verifica a validade temporal e o primeiro plano.

O latch de emergência encerra a captura/controlador e solicita release. Só um novo Start o rearma.
O serviço de acessibilidade, por si só, não começa a pescar.

## Limite importante do Android

`AccessibilityService.dispatchGesture` não é um driver de toque em tempo real e não oferece uma API
pública simples de “cancelar agora qualquer dedo” com latência garantida.

O projeto usa segmentos de hold curtos (65 ms por padrão, configuráveis entre 30–100 ms) e termina uma
continuação no mesmo ponto. Um segmento já enviado pode terminar antes do release ser processado;
a latência também depende dos callbacks/agendamento do sistema. **Não prometemos release instantâneo ou
limite rígido de latência de parede.** Desativação do serviço/interferência do usuário pode cancelar gestos.
Não usamos um tap em outra parte da tela para tentar cancelar um gesto, pois isso criaria input não autorizado.

Após `onCancelled`, o estado físico é considerado encerrado pelo Android. Rejeições de continuação são
registradas; comportamento de cada fabricante precisa ser observado antes de permitir holds longos.

## Limitações de visão — explícitas

1. **Uma referência, uma aparência principal.** Templates vieram do vídeo fornecido. Busca é multiescala e
   sem posição fixa, mas mudanças de ícone, UI, contraste, idioma ou escala extrema podem exigir novos assets/perfil.
2. **Várias varas:** largura do trilho é medida; velocidade é estimada; largura do jogador não é redimensionada
   por vara. Isso é suporte arquitetural, não comprovação empírica com diferentes varas.
3. **Peixe:** detector atual prioriza a linha vertical azul-acinzentada observada. Um tema que mostre somente
   um símbolo sem essa linha pode não ser reconhecido. A resposta é soltar, não estimar uma posição para clicar.
4. **Confirmação:** OCR exige a frase de captura em inglês ou uma forma portuguesa suportada. A região da
   ilustração é verificada por textura/contraste, **não por um classificador semântico de imagem de peixe**.
   A mensagem “You just caught…” é a evidência principal. Outro idioma/diagramação poderá impedir reinício.
5. **SHAKE:** template isolado mostrou cobertura limitada na sondagem. O fallback de OCR foi integrado e
   compilado, mas sua cobertura/latência em Android ainda não foi medida. O reconhecedor não usa áudio.
6. **Mesmo Shake na mesma posição:** após conclusão de um tap, aguardamos deslocamento ou desaparecimento
   visual. Um botão que não muda após input aceito, ou um novo botão idêntico exatamente na mesma posição sem
   qualquer intervalo visível, pode manter o motor esperando. Não fazemos cliques repetidos cegos para contornar isso.
7. **Scores não calibrados:** confiança 0,9 não significa 90% de acerto. Limiares precisam ser confrontados com logs e vídeo.
8. **Priorização espacial:** trilho/progresso são procurados na parte inferior, conforme referência. Não é um
   detector universal de interfaces arbitrariamente reorganizadas. Botões são procurados globalmente.
9. **Sombras, animações e oclusões:** fallback do jogador e perda temporal são limitados. Se a evidência não
   sustenta uma posição, input é interrompido, mesmo que isso faça perder um peixe.

## Captura, overlay e desempenho

- Apenas tela inteira, display principal. Captura de janela/app isolado e multiwindow não são suportados para input real.
- Orientação/tamanho alterado: sessão encerrada, novo consentimento exigido. Isso é uma escolha de segurança,
  não rotação transparente durante um hold. Diferentes resoluções são escaladas/mapeadas na nova sessão.
- Os priors foram derivados de gameplay em paisagem. Retrato/telas dobráveis precisam de teste e possível ajuste de perfil.
- Overlay pode aparecer na própria captura dependendo do Android. Anotações vermelhas foram escolhidas para
  não imitar o indicador azul do peixe, e texto fica fora da região inferior. Ainda assim, compare debug ligado/desligado.
- O botão PARAR é um overlay interativo. Se cobrir um alvo, o input é bloqueado. Não clique às cegas para ultrapassá-lo;
  pare, resolva manualmente a interface e reinicie a sessão.
- 24 FPS é frequência **solicitada**, não promessa de processamento. Busca de templates e OCR podem reduzir FPS.
  O guard não é afrouxado automaticamente para esconder latência. OCR aquecendo pode atrasar o primeiro reconhecimento.
- Perfil de CPU, bateria, temperatura e memória no aparelho ainda não foi medido. Há pool/buffer limitado/Mats
  reutilizados, mas permanecem pequenas alocações por observação e trabalho nativo do OCR/OpenCV.
- Bibliotecas nativas embarcadas exigem verificar dispositivos Android com páginas de memória de 16 KB;
  não foi validada aqui essa compatibilidade nem política de publicação no Google Play.

## Recuperação conservadora

Um minigame que termina sem mensagem reconhecida permanece em `CATCH_CONFIRMATION`. Interrupção durante
lançamento pode voltar à busca de Shake em vez de relançar automaticamente. Esse comportamento evita ações
baseadas em suposições, mas exige Stop/Start manual se não aparecer nova evidência.

O app não controla inventário, caminhada, escolha de vara, reconexão, menus, prompts de compra ou respawn.

## Dados e permissões

Captura e acessibilidade são capacidades sensíveis. A projeção contém a tela inteira enquanto ativa;
fora do primeiro plano do Roblox, o worker não executa OCR/visão. A árvore de acessibilidade é usada para
identificar o pacote da janela, não para ler chat/inventário. Frames ficam em memória e não são gravados.
Logs ficam no armazenamento privado (rotação a ~2 MB por arquivo) e só são exportados por ação do usuário.
Não existe serviço remoto, telemetria própria nem envio de screenshots no código.
