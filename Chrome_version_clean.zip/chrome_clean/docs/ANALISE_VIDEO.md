# Análise visual da referência — sem áudio

Fonte obrigatória:
https://github.com/Votetrols/Fish-macro-test-3/blob/2b8567560056217ec48abb8db8353230c10ff282/Roblox_2026-10-06-13-57-21.mp4

O arquivo foi obtido diretamente do commit acima. Nenhuma faixa de áudio foi usada.
Decodificação: **626 quadros**, imagem **1066 × 480**; FPS médio informado pelo OpenCV ~15,0043.
O último timestamp de apresentação lido foi **41,3314 s**. O vídeo tem intervalos variáveis entre quadros:
**não usar índice/FPS como se fosse timestamp exato**.

## Método de análise

Inspeção visual por quadros distribuídos do início ao final, folhas de contato, ampliações de elementos
relevantes e amostragem adicional das transições. Para as sondagens numéricas, todos os 626 quadros foram
decodificados sequencialmente. Isso não é anotação manual de cada quadro nem medição de precisão de um detector.
Buscas por tempo com OpenCV podem retornar quadros deslocados: os intervalos da descrição visual abaixo são
aproximados. O CSV de propostas usa timestamps de apresentação obtidos na leitura sequencial.

## Sequência observada

| Trecho aproximado | Evidência visual | Consequência de implementação |
|---|---|---|
| Início até ~3 s | Vara equipada; inventário inferior; botão circular com ícone de vara perto do pulo | Template de bordas do ícone, busca multiescala; não clicar no slot do inventário |
| ~3–6,5 s | Personagem faz lançamento; aparece indicador vertical de força | Carga de ~3 s é parâmetro fornecido pelo usuário, não duração inferida com precisão deste vídeo |
| ~6,5–19 s | Botões circulares “SHAKE” em várias regiões; anéis vazios de animação aparecem em posições anteriores | Texto/bordas são evidência; anel vazio não é botão; confirmação temporal e fallback OCR |
| ~19–30,5 s | Trilho horizontal escuro, jogador claro com setas, indicador azul-acinzentado e progresso abaixo | Detectores separados; geometria conjunta; tracking temporal |
| ~25,5–26,5 s | Área do jogador fica escurecida/ocre em alguns quadros | Não depender exclusivamente de branco; largura previamente medida e platô de contraste |
| ~30,5–35 s | Trilho desaparece; mensagem “You just caught a Big Log…” e objeto/ilustração central; inventário volta | Confirmação por linguagem de evento + evidência visual local; não tratar desaparecimento como sucesso |
| Final | Barras de sistema e depois cortina de notificações ocupam a tela | Bloquear input quando Roblox não for janela ativa; logo visual também deixa de ser válido |

## Elementos e proporções observadas

As coordenadas abaixo são **medições da referência**, não destinos de input no aplicativo.

- No exemplo ampliado de minigame, o trilho fica aproximadamente em x=333…734 e y=390…410.
  Sua largura é da ordem de 400 px (cerca de 37,5% da imagem), mas ela **não é constante no código**.
- O jogador tem aproximadamente 120 px nesse exemplo, com setas internas. A linha do peixe pode cortar
  sua aparência clara. A largura é aprendida a partir do retângulo e não derivada da vara.
- O indicador do peixe é azul-acinzentado e se prolonga acima/abaixo do trilho; aparece também um pequeno
  símbolo de peixe. O detector atual prioriza a linha estendida, que é menos ambígua que as setas do jogador.
- O progresso é bem mais fino e estreito que o trilho. Seu contorno não é uniformemente branco:
  o centro pode ficar escuro. A detecção combina interior escuro com preenchimento claro.
- “Blue Tang”, “Angelfish” e “Clownfish” aparecem no **cenário**. Não são confirmações de captura.
- A captura específica mostrada é **Big Log**, não um peixe comum. O ciclo deve aceitar a mensagem de
  recompensa observada sem exigir que o nome pertença a uma lista de espécies.
- Posição do peixe/jogador muda de direção e há períodos de relativa estabilidade. Este vídeo não permite
  identificar com confiança ganhos físicos universais nem demonstrar desempenho com outras varas.

## Revisões motivadas pela referência

1. **Barra truncada na extremidade:** uma máscara apenas de pixels escuros perde o início do trilho quando
   o jogador chega à esquerda. Incluímos pixels claros antes do fechamento morfológico horizontal.
2. **Progresso com contorno escuro:** limiar só de branco fragmentava a detecção. Passamos a combinar regiões
   claras/escuras, dimensões, posição relativa ao trilho e centralização.
3. **SHAKE muda na rasterização/escala:** um único template não cobre bem todos os quadros. Mantemos template
   como caminho rápido e OCR local do texto exato como fallback. OCR Android ainda não foi executado aqui.
4. **Jogador nem sempre branco:** fallback de contraste usa a largura aprendida, sem reescalá-la pela vara.
5. **Notificações:** primeiro plano do pacote + logo visual são necessários; nenhum deles sozinho autoriza input.

## Quadros de apoio

![Shake móvel](evidence/shake.png)
![Trilho, jogador, peixe e progresso](evidence/minigame.png)
![Jogador temporariamente escurecido](evidence/player-escurecido.png)
![Confirmação Big Log](evidence/confirmacao.png)

A visibilidade de uma ilustração foi analisada no vídeo. O código não contém um classificador semântico
universal de “imagem de peixe”; a limitação correspondente está documentada separadamente.
