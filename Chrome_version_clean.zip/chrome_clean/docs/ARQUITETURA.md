# Arquitetura e fases

## Fluxo

```
MediaProjection / ImageReader
    → BitmapPool + FrameBuffer latest-only
    → VisionPipeline / detectores
    → ConfidenceTracker + FishTracker + PlayerBarTracker + BarTracker
    → FishingStateMachine + FishingController
    → Decision
    → InputSafetyGuard
    → InputController
    → GestureService / dispatchGesture
```

Nenhum detector conhece `dispatchGesture`. O controlador recebe medidas normalizadas e devolve uma
`Decision`; não lê pixels. O atuador mapeia o ponto observado para o display e só o executa com autorização.

## Módulos

| Pacote | Responsabilidade |
|---|---|
| `capture` | Foreground service, consentimento MediaProjection, ImageReader, conversão, buffer e pool |
| `vision` | OpenCV, templates multiescala, segmentação, geometria, OCR local |
| `tracking` | Movimento, confiança temporal, mudança de geometria, tendência de progresso |
| `config` | Settings, priors visuais e calibração de geometria |
| `state` | Transições e contexto do ciclo |
| `control` | Controlador PD/predição, Shake, autorização e adaptação para gestos Android |
| `safety` | Gate independente e latch de emergência |
| `engine` | Orquestração em worker único, snapshots e integração |
| `ui` | Tela nativa, overlay de acessibilidade, exportação e logs |
| `model` | Box, Point, Detection, Observation, Track, Decision, State e Snapshot |

## Captura e ownership

- Token MediaProjection usado uma única vez, callback registrado antes do VirtualDisplay.
- A captura é da tela inteira. Mudança de tamanho/orientação interrompe a sessão em vez de remapear um
  dedo pressionado com dados antigos. Novo Start cria projeção e calibração novas.
- Thread de captura separada do worker de visão. Sem fila crescente: apenas o frame pendente mais recente.
- Bitmaps de saída voltam ao pool após o consumidor terminar. Um bitmap nunca é alterado enquanto o OCR
  ou a visão o utiliza. Buffer bruto e Mats principais são reutilizados.
- Timestamp da imagem convertido para a base `elapsedRealtime`. FPS e latência de processamento são exibidos.
- OCR é síncrono no worker, **não na UI**. Se atrasar, a captura continua substituindo o frame pendente e a
  autorização de gestos expira independentemente do worker.

## Visão

- `FishingButtonDetector`: bordas do ícone da vara, vários fatores de escala, busca pela tela.
- `ShakeDetector`: bordas da palavra; fallback OCR do texto exato `SHAKE`. Não detecta só círculos.
- `FishingBarDetector`: máscara escuro/claro e fechamento; priors relativos de altura/aspecto/largura.
- `ProgressDetector`: interior claro/escuro abaixo do trilho, geometria fina, alinhamento e fração preenchida.
- `PlayerBarDetector`: perfil de luminância por coluna, fechamento de pequenas interrupções e largura aprendida;
  fallback para platô de contraste durante escurecimento. Não usa uma tabela de larguras por vara.
- `FishDetector`: suporte vertical azul-acinzentado, incluindo prolongamento fora do trilho.
- `CatchConfirmationDetector`: OCR de frase de captura e textura na região acima da mensagem; detector auxiliar
  de Shake compartilha o mesmo reconhecedor local. A evidência de imagem é fraca/geométrica, não semântica.
- `RobloxDetector`: logo por template, combinado com pacote da janela ativa na camada de integração.

As confidências são **scores heurísticos**, não probabilidades calibradas. Evidências de barra e progresso são
cruzadas. Detecções de botões e barra exigem repetição; peixe/jogador são validados no contexto geométrico e
pelo tracker de movimento, sem exigir sobreposição de uma linha estreita entre frames rápidos.

## Tracking e controle

Posição de objetos: `(centerX - bar.left) / bar.width`. Derivadas são por segundo nessa unidade.
O tracker reage mais rapidamente a reversões e saltos; previsões de perda são curtas e a confiança decai.
Após gap maior que a tolerância, a velocidade é reinicializada em vez de usar uma medida antiga.

O controlador combina:

- erro entre centros e erro previsto em horizonte curto;
- velocidade e aceleração aproximada do peixe;
- velocidade do jogador e deriva aprendida durante release;
- alvo limitado ao intervalo alcançável pelo centro do jogador;
- Schmitt trigger/histerese, deadband e intervalo mínimo de mudança;
- confiança/idade dos tracks e tendência de progresso.

A tendência de progresso só modula cautelosamente a histerese; ela não substitui a posição visual.
Tap é usado para pequenas compensações, hold para deslocamento sustentado e release para deriva à esquerda.
O estado físico real não é identificado universalmente: ganhos iniciais precisarão de ajuste no aparelho.

## Estados

`IDLE → SEARCH_FISHING_BUTTON → CASTING → SEARCHING_SHAKE ↔ PRESSING_SHAKE`

`→ FISHING_MINIGAME_DETECTED → TRACKING_FISH → CONTROLLING_PLAYER_BAR`

`→ CATCH_CONFIRMATION → RESET → SEARCH_FISHING_BUTTON`

- Evidência de minigame tem precedência sobre Shake.
- O Shake não tem contador máximo nem prazo para aparecer.
- O próximo Shake exige mudança visual de caixa ou desaparecimento/reaparecimento, não uma lista de posições.
- `VISION_LOST`: libera o input e tenta recuperar o tracking.
- `ROBLOX_NOT_DETECTED`: bloqueia input. Recupera para um estado conservador, nunca presume uma captura.
- `CAPTURE_ERROR`, `INVALID_STATE`, `EMERGENCY_STOP`: não autorizam novos gestos.
- Fim de minigame exige desaparecimento persistente, e sucesso exige mensagem posterior.
- Reinício exige que a mensagem tenha sido vista, desapareça e que o botão da vara reapareça.
- Captura perdida sem confirmação não resulta em recast automático: operador decide como recuperar.

## Gestos

Tudo que altera um gesto roda no main looper. Holds utilizam `StrokeDescription.continueStroke`.
A cada segmento é reavaliado: emergência, pacote, contexto e idade do último frame.
O ponto de um dedo ativo não migra silenciosamente para outro alvo. Tap de Shake é reconhecido pela máquina
somente depois do callback de conclusão; rejeição/cancelamento não confirma o clique.

O lançamento tem duração configurada (~3 s), mas é continuamente interrompível por perda de contexto.
No minigame, holds têm leases curtos renovados por decisões frescas. Release fecha a continuação existente
no mesmo ponto; não usa clique em uma posição fictícia como mecanismo de cancelamento.

## Organização por fases

1. **Fundação:** projeto, captura, buffer, UI, logs, guard e emergência.
2. **Visão:** contratos e detectores baseados na referência.
3. **Tracking:** derivadas, perda temporária e confiança.
4. **Controle simulado:** produção de decisões, sem dispatch por padrão.
5. **Input controlado:** acessibilidade e autorizações independentes.
6. **Ciclo:** integração visual e confirmação antes de reinício.

São camadas do código entregue, não afirmações de que essas fases passaram por validação no jogo.
