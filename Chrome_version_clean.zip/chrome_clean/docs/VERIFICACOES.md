# Verificações — o que foi e o que não foi feito

## Executado no ambiente de desenvolvimento

- Download e inspeção visual do vídeo indicado, do início ao fim por amostragem e ampliações, sem áudio.
- Decodificação sequencial dos 626 quadros para sondagem offline de propostas geométricas.
- Revisões de lifecycle, ownership de frames, estados, freshness, mapeamento e continuação de gestos.
- Build debug com JDK 17, Gradle 8.9, AGP 8.7.3 e SDK 35.
- **20 testes unitários locais, 0 falhas, 0 erros.**
- **Android Lint: 0 erros, 12 avisos** de UI/localização/preferência por widgets compatíveis. Avisos não foram
  mascarados com uma baseline. O relatório textual está em `evidence/lint-results-debug.txt`.
- APK debug assinado e verificado com a ferramenta de assinatura do SDK.

Comando principal:

```sh
./gradlew :app:assembleDebug :app:testDebugUnitTest :app:lintDebug --no-daemon --console=plain
```

Evidências: `evidence/build.log`, `evidence/unit-tests.xml`, `evidence/lint-results-debug.txt` e
`evidence/apk-signature.txt`. O ZIP não contém caches, SDK, JDK, keystores ou caminhos locais do ambiente.

## Escopo dos testes unitários

Guard de input e condições inseguras; release em emergência; NaN/duração inválida;
normalização; reversão de velocidade; perda/expiração/reaquisição de tracking;
controlador considerando velocidade e limite direito; Shake condicionado a mudança visual;
confiança temporal; ausência de timeout para Shake; confirmação antes de reinício;
recuperação conservadora de primeiro plano; ACK do lançamento;
tendência de progresso; latch de emergência; precedência do minigame sobre Shake.

Usam medidas/observações sintéticas. **Não executam MediaProjection, OpenCV Android, OCR Android,
acessibilidade real nem a física do Roblox.**

## Sondagem offline — não confundir com benchmark

`tools/offline_probe.py` é um espelho diagnóstico parcial em Python/OpenCV das propostas de trilho,
progresso, linha do peixe e templates. Ele **não é o pipeline Kotlin completo**, não executa OCR do ML Kit,
não roda máquina de estados/controlador e não demonstra funcionamento de input.

Resultado da última sondagem do vídeo:

| Proposta | Quantidade | Intervalo de timestamps de apresentação |
|---|---:|---|
| Trilho geométrico | 174 quadros | 19,209–30,018 s |
| Progresso associado | 173 quadros | 19,209–30,018 s |
| Linha do peixe associada | 173 quadros | 19,209–30,018 s |

Essas contagens são **ocorrências de propostas**, não recall, precisão ou acerto de centros.
Não existe ground truth completo anotado. Uma proposta incorreta também entraria nessa contagem.

Templates foram sondados a cada 3 quadros, em cinco escalas, com limiar de 0,68: 98 amostras de vara,
17 de Shake e 183 de logo. O limiar do logo em produção é ligeiramente diferente (0,66).
A baixa cobertura do template de Shake motivou o fallback de OCR; **esse fallback ainda não foi medido no Android**.
Há um quadro com trilho parcial e sem progresso no espelho; a política é não controlar sem evidência conjunta.

CSV: `evidence/offline-proposals.csv`. Usa `CAP_PROP_POS_MSEC`, não índice/FPS, porque a referência tem
cadência variável. FPS solicitado pelo aplicativo não foi medido por essa análise.

Reprodução opcional:

```sh
python -m pip install -r tools/requirements.txt
python tools/offline_probe.py caminho/Roblox_2026-10-06-13-57-21.mp4 --output propostas.csv
```

## Não executado / sem resultado inventado

- Instalação ou execução deste APK em Android físico/emulador.
- Teste de captura MediaProjection, permissões, overlay, OCR ou gestos no aparelho.
- Teste de pesca automatizada, taxa de captura ou duração de ciclo real.
- Teste de diferentes varas, versões do jogo, temas ou fabricantes.
- Benchmark de consumo, bateria, FPS ou latência no Android.
- Compatibilidade nativa com páginas de memória de 16 KB.

**Conclusão:** fonte compilável e regras internas verificadas, pronto para começar os testes conjuntos
em modo simulado. Não é uma certificação de que o macro funciona no Roblox real.

### Observação sobre o ambiente de build

O ambiente tinha aproximadamente 2 GB de RAM. O build foi limitado a dois workers, heap de 768 MB e
metaspace de 384 MB. A última execução terminou com sucesso, mas o Gradle avisou que descartaria o daemon
por pressão de metaspace após o build. Em uma máquina de desenvolvimento com mais memória, pode-se
ampliar esses limites em `gradle.properties`; isso não altera o motor Android.
