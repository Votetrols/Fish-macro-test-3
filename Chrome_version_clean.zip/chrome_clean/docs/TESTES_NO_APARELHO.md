# Roteiro de teste conjunto — ainda não executado

Este documento é um plano para o usuário e o assistente seguirem posteriormente.
Não é um relatório de testes realizados.

## Informações que precisamos

- Modelo do aparelho, versão Android, resolução e orientação.
- Nome da vara, tamanho/escala da UI e idioma do jogo.
- Versão instalada (`0.1.0-test`), parâmetros do app e modo simulado/real.
- Gravação visual com overlay e logs JSONL exportados.
- Descrição do primeiro instante em que observação/ação divergiu do jogo.

Evite compartilhar notificações, credenciais ou conversas privadas na gravação.

## A. Captura e parada — sem input real

1. Habilitar acessibilidade, iniciar captura da tela inteira em modo simulado e abrir o Roblox.
2. Verificar status de captura, pacote, FPS e latência. Permanecer parado por alguns segundos.
3. Abrir notificações e trocar de app: nenhuma ação real deve ocorrer; status Roblox deve ficar falso.
4. Voltar, parar por overlay, por notificação e pelo app em sessões separadas.
5. Girar a tela: deve haver encerramento seguro e pedido de novo Start, não toque remapeado.
6. Se o fabricante exigir autorizar “configurações restritas” para app instalado de arquivo, faça isso
   conscientemente pelas opções oficiais do Android. O aplicativo não contorna essa proteção.

## B. Detectores em ciclo manual

Com modo simulado ativo, o usuário pesca manualmente.

| Elemento | O que conferir |
|---|---|
| Vara | Box no ícone correto, não no pulo/inventário/cenário |
| Shake | Identificação em várias posições; não aceitar anéis vazios; comparar template/OCR nos logs |
| Trilho | Extremos reais inclusive quando jogador chega à esquerda/direita |
| Jogador | Centro e largura estáveis; não confundir setas com peixe; observar fase escurecida |
| Peixe | Linha correta, reversões e pausas; não seguir contorno do overlay |
| Progresso | Fração coerente e tendência com sinal correto; sem saltos falsos ao mudar o fundo |
| Captura | Reconhecer frase posterior ao minigame; nomes no cenário nunca confirmam sucesso |

Repetir inicialmente com debug ligado e depois desligado, usando a gravação para comparar.
Não medir taxa de captura automática antes de corrigir detecções incorretas.

## C. Controlador simulado

Conferir se o erro e as velocidades correspondem visualmente aos movimentos. Observar:
- antecipação curta sem perseguir uma posição antiga;
- release quando jogador já se move rapidamente para a direita e peixe retorna;
- pequenos taps para compensação, sem alternância desnecessária;
- respeito aos limites e liberação imediata de intenção em tracking insuficiente.

Ações simuladas **não causam** o movimento observado: o usuário ainda controla o jogo.
Logo, essa etapa não mede a dinâmica de malha fechada do macro.

## D. Input real controlado — somente após nossa revisão

Em uma sessão separada e autorizada, validar em pequenos passos:
1. Tap de Shake e callback de conclusão.
2. Lançamento de duração configurada, com PARAR ao alcance.
3. Release/continuação de holds sob perda de captura, notificações e Stop.
4. Pequeno trecho de minigame antes de liberar um ciclo inteiro.
5. Um ciclo completo, confirmando mensagem e somente então reinício.

Não usar automação onde for proibida. Não executar esta fase sozinho apenas porque o APK instala.

## E. Variações e ajuste

Depois de uma base estável, experimentar varas e resoluções distintas e registrar medidas separadas.
Ajustar primeiro visão/latência, depois Kp/Kd e somente depois antecipação/histerese.
Não reduzir confiança mínima para compensar um detector claramente errado.

## Critérios de interrupção

- Box errado ou múltiplos alvos ambíguos.
- Toque real em modo simulado ou fora do Roblox: interromper e tratar como defeito crítico.
- Hold não liberado ao parar, input após frame expirar, ou toque na UI de sistema.
- Progresso/peixe ausente com HOLD persistente.
- Reinício sem confirmação visual.
- Frames muito antigos, aquecimento significativo ou callbacks de gesto repetidamente cancelados.

Forneça primeiro logs + vídeo do defeito. Corrigimos e repetimos a etapa afetada antes de avançar.
