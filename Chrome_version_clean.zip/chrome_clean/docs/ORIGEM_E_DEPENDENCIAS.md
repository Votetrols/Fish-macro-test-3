# Origem e dependências

## Referência

Vídeo fornecido pelo usuário, no commit:
`2b8567560056217ec48abb8db8353230c10ff282` de `Votetrols/Fish-macro-test-3`.

SHA-256 do MP4 baixado:
`dfcad0d932af8096abaf7e78d94cd1194b3cb00083d0ae96a0a6037253764a5c`.

O áudio foi ignorado. Não foram importados fontes, arquitetura ou detectores do repositório de origem.
Somente o vídeo indicado foi baixado para análise deste projeto novo.

Assets em `app/src/main/assets` são pequenos recortes da referência:
- `rod.png`: ícone da vara (recorte do quadro inicial).
- `roblox.png`: logo para confirmação visual de contexto (quadro inicial).
- `shake.png`: texto do botão em um quadro solicitado perto de 7,2 s.

Coordenadas de recorte pertencem ao preparo dos assets, **não ao sistema de input**.
Quadros de evidência foram incluídos para documentação técnica. Nomes/logos/imagens do jogo continuam
pertencendo aos respectivos titulares; não se presume uma licença de redistribuição comercial desses materiais.

## Dependências de build/runtime

| Componente | Versão | Uso |
|---|---|---|
| Android Gradle Plugin | 8.7.3 | Build Android |
| Gradle Wrapper | 8.9 | Build reproduzível por versão + checksum da distribuição |
| Kotlin | 2.0.21 | Implementação |
| OpenCV Android | 4.10.0 | Visão nativa (Apache 2.0; observar avisos upstream) |
| ML Kit Text Recognition Latin | 16.0.1 | OCR embarcado; termos do SDK Google |
| JUnit | 4.13.2 | Testes unitários locais |

JDK 17 e SDK Android 35 são necessários, mas não são distribuídos no ZIP.
OpenCV e ML Kit incluem bibliotecas nativas, por isso o APK universal é relativamente grande.

A formatação foi aplicada com ktfmt 0.54 durante o desenvolvimento; não é dependência do app.
A sondagem opcional Python requer `opencv-python` e `numpy`; não participa da execução Android.
