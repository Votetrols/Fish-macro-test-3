#!/usr/bin/env python3
"""OpenCV Python diagnostic mirror of rail/progress and template proposals.
Not the Android runtime, not a closed-loop test, not a precision benchmark.
Run: python tools/offline_probe.py reference.mp4 --output metrics.csv
"""
import argparse,csv,time
from pathlib import Path
import cv2
import numpy as np

def rail(gray):
 h,w=gray.shape;y=int(h*.50);roi=gray[y:y+int(h*.46)]
 mask=cv2.threshold(roi,45,255,cv2.THRESH_BINARY_INV)[1] | cv2.threshold(roi,180,255,cv2.THRESH_BINARY)[1]
 mask=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_RECT,(int(w*.14)|1,1)))
 contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
 candidates=[]
 for c in contours:
  x,yy,rw,rh=cv2.boundingRect(c)
  if w*.2<rw<w*.86 and h*.014<rh<h*.075 and 7<rw/rh<60:
   score=.55+.20*cv2.contourArea(c)/(rw*rh)+.10*(1-abs((x+rw/2)/w-.5))
   candidates.append((score,(x,yy+y,rw,rh)))
 return max(candidates,default=(0,None))[1]

def progress(gray,bar):
 if bar is None:return None
 x,y,w,h=bar;top=int(y+h+h*.25);bottom=min(gray.shape[0],int(y+h+h*2.3));roi=gray[top:bottom,x:x+w]
 mask=((roi<=45)|(roi>180)).astype(np.uint8)*255
 k=cv2.getStructuringElement(cv2.MORPH_RECT,(max(3,int(gray.shape[1]/213)),1))
 mask=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,k)
 cs,_=cv2.findContours(mask,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
 boxes=[cv2.boundingRect(c) for c in cs]
 boxes=[(a,b,c,d) for a,b,c,d in boxes if w*.25<c<w*.95 and 2<=d<h*.65 and c/d>12 and abs(a+c/2-w/2)<w*.14]
 if not boxes:return None
 a,b,c,d=max(boxes,key=lambda b:b[2]);pixels=roi[b:b+d,a:a+c];filled=0;dark=0
 for xx in range(1,c-1):
  if pixels[d//2,xx]>175:
   if dark>2:break
   filled=xx;dark=0
  else:dark+=1
 return (x+a,top+b,c,d,filled/(c-2))

def fish(image,bar):
 if bar is None:return None
 x,y,w,h=bar;top=max(0,int(y-h*.65));bottom=min(image.shape[0],int(y+h+h*.4))
 roi=image[top:bottom,x:x+w].astype(np.int16);b,g,r=cv2.split(roi)
 mask=(b>r+9)&(g>r+3)&(b>=65)&(b<=235)&(g>50)
 scores=mask.mean(axis=0);above=mask[:y-top].sum(axis=0);scores[above<max(2,int(h*.15))]=0
 best=int(scores.argmax());return (x+best,float(scores[best])) if scores[best]>=.53 else None

def main():
 a=argparse.ArgumentParser();a.add_argument('video');a.add_argument('--output',default='metrics.csv');args=a.parse_args()
 cap=cv2.VideoCapture(args.video);fps=cap.get(cv2.CAP_PROP_FPS)
 templates={};assets=Path(__file__).resolve().parents[1]/'app/src/main/assets'
 for name in ['rod','shake','roblox']:
  templates[name]=cv2.Canny(cv2.imread(str(assets/(name+'.png')),0),50,130)
 records=[];i=0;start=time.perf_counter()
 while True:
  ok,im=cap.read()
  if not ok:break
  g=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY);b=rail(g);p=progress(g,b);f=fish(im,b) if p else None
  record=dict(frame=i,time=round(cap.get(cv2.CAP_PROP_POS_MSEC)/1000,3),bar=bool(b),progress=bool(p),fish=bool(f),progress_value=round(p[-1],3) if p else '',fish_x=f[0] if f else '')
  if i%3==0:
   edges=cv2.Canny(g,50,130)
   for name,t in templates.items():
    best=0
    for scale in [.7,.85,1,1.15,1.32]:
     tt=cv2.resize(t,None,fx=scale*g.shape[0]/480,fy=scale*g.shape[0]/480,interpolation=cv2.INTER_NEAREST)
     score=cv2.minMaxLoc(cv2.matchTemplate(edges,tt,cv2.TM_CCOEFF_NORMED))[1];best=max(best,score)
    record[name+'_score']=round(best,3)
  records.append(record);i+=1
 keys=['frame','time','bar','progress','fish','progress_value','fish_x','rod_score','shake_score','roblox_score']
 with open(args.output,'w') as out:
  writer=csv.DictWriter(out,keys);writer.writeheader();writer.writerows(records)
 print(f'Decoded {i} frames, fps metadata={fps:.6f}, elapsed={time.perf_counter()-start:.1f}s')
 for name in ['bar','progress','fish']:
  r=[r for r in records if r[name]];print(name,len(r),'range', (r[0]['time'],r[-1]['time']) if r else None)
 for name in templates:
  rows=[r for r in records if r.get(name+'_score',0)>=.68];print(name,'sampled matches',len(rows),'range',(rows[0]['time'],rows[-1]['time']) if rows else None)
if __name__=='__main__':main()
