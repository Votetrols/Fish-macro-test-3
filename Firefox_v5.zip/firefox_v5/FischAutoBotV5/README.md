# Fisch AutoBot — macro de pesca para Roblox Fisch (Android, visão computacional)

Implementação completa em Kotlin do ciclo de pesca (captura → visão → rastreamento →
máquina de estados → controle em malha fechada → entrada), guiada por **detecção visual**,
sem coordenadas, tempos, larguras de barra ou resoluções fixas no comportamento.

## Status (build 0.3.0-a22 — V5 — alvo: Samsung Galaxy A22)

- ✅ **APK debug compilado com Gradle/AGP** (`./gradlew :app:assembleDebug`):
  `app/build/outputs/apk/debug/app-debug.apk`, `com.fischa.app`, versionCode 3, minSdk 26,
  targetSdk 35. Detalhes e hashes em [`docs/TEST_RESULTS.md`](docs/TEST_RESULTS.md).
- ✅ **V5 — crash pós-MediaProjection corrigido**: a sessão `MediaProjection` agora é criada
  na Activity **antes** do `startForeground(mediaProjection)` do serviço (exigência do
  Android 14), com handoff via `ProjectionHolder` e todo o caminho de start à prova de
  exceções (spec §13). Detalhes em [`docs/CHANGES_V5.md`](docs/CHANGES_V5.md).
- ✅ **V5 — START só liga a infraestrutura**: estado inicial `WAITING_FOR_ROD`; o ciclo só
  começa com o **botão da vara confirmado visualmente** (frames estáveis + confiança +
  autorização do InputSafetyGuard); após cada captura volta a `WAITING_FOR_ROD`. Sem gatilhos
  por timer. `realInput` segue **OFF por padrão**.
- ✅ **Core puro-JVM** (`core/`): `./gradlew :core:test` → **77 testes, 0 falhas**;
  `./gradlew :core:selfTest` → **97/97 checks**.
- ⚠️ **Não testado em aparelho nem no Roblox** (spec §25). O replay do vídeo não pôde ser
  executado nesta rodada (frames ausentes no pacote).
- 📄 O que mudou na V5: [`docs/CHANGES_V5.md`](docs/CHANGES_V5.md). O que mudou na V4/A22:
  [`docs/CHANGES_A22.md`](docs/CHANGES_A22.md). Instalação e roteiro de teste:
  [`docs/INSTALL_A22.md`](docs/INSTALL_A22.md). Limitações: [`docs/LIMITATIONS.md`](docs/LIMITATIONS.md).
  Análise do vídeo de referência: [`docs/VIDEO_ANALYSIS.md`](docs/VIDEO_ANALYSIS.md).

Mapeamento da FSM V5 (WAITING_FOR_ROD → CASTING → WAITING_FOR_WATER → SHAKE → MINIGAME →
CATCH_CONFIRMATION → WAITING_FOR_ROD) para os estados implementados: `IDLE` (parado) →
`WAITING_FOR_ROD` (observando; a vara confirmada é a única saída) → `CASTING` →
`WAITING_FOR_WATER` (espera evidência visual pós-cast) → `SEARCHING_SHAKE` ⇄ `PRESSING_SHAKE`
→ `FISHING_MINIGAME_DETECTED/TRACKING_FISH/CONTROLLING_PLAYER_BAR` → `CATCH_CONFIRMATION` →
`RESET` → `WAITING_FOR_ROD` → …; erros → `VISION_LOST/CAPTURE_ERROR/ROBLOX_NOT_DETECTED/
INVALID_STATE/EMERGENCY_STOP`.

## Arquitetura

```
core/  (kotlin-jvm, sem dependências Android)
  config/     AppConfig — todo tunable centralizado; toMap()/withOverrides() flat
  common/     RectF, CoordinateMapper (CAPTURE→NORMALIZED→DEVICE, única camada), clamp/lerp
  vision/     VisionFrame (buffers reusados, gray lazY), DiscMatcher,
              7 detectores (BotãoVara, Shake, BarraPesca, Bloco/Jogador, Peixe,
              Progresso, Confirmacao) + TemporalDetector (on/off frames + EMA conf)
  tracking/   AlphaBeta, FishTracker (baixa latência), PlayerBarTracker,
              BarTracker (prévia suavizada p/ ROI), ProgressTracker, ConfidenceTracker,
              RodConfirmTracker (confirmação temporal do botão da vara — gatilho V5)
  control/    FishingController (P-D + feedforward + termo de deriva; taps curtos /
              hold / soltar), ShakeController, CastController, InputExecutor (interface)
  safety/     InputSafetyGuard (porta única de toda entrada real), EmergencyStop (latch)
  state/      FishingStateMachine (IDLE→WAITING_FOR_ROD→CASTING→WAITING_FOR_WATER→
              SEARCHING_SHAKE⇄PRESSING_SHAKE→FISHING_MINIGAME_DETECTED→TRACKING_FISH→
              CONTROLLING_PLAYER_BAR→CATCH_CONFIRMATION→RESET→WAITING_FOR_ROD;
              erros: VISION_LOST, CAPTURE_ERROR, ROBLOX_NOT_DETECTED, INVALID_STATE,
              EMERGENCY_STOP)
  log/        ThrottledLog + Tags ([CAPTURE][DETECTION][TRACKING][CONTROL][STATE][INPUT][ERROR])
  debug/      RenderModel — snapshot p/ overlay
  pipeline/   VisionPipeline — liga tudo: visão→tracking→estados→decisão→gate→executor
  tools/      SelfTest, ReplayMain (harnesses executáveis neste ambiente)
app/  (android, camada fina)
  ScreenGeometry/InputGeometry  tamanho REAL do display; publica o CoordinateMapper da sessão
  ScreenCaptureSource  MediaProjection → VirtualDisplay já no tamanho de processamento (640×288
                       no A22 paisagem) → VisionFrame (latest-only, gate de FPS, taxa adaptativa)
  GameAccessibilityService  único caminho p/ gestos + detector de Roblox (janelas vivas +
                       Activity verificada via PackageManager + refresh periódico 500 ms)
  AndroidInputExecutor  implementa InputExecutor do core (+ holdStillActive)
  FischEngineService  foreground service, loop de frames, armed/stop/emergência
  DebugOverlay  HUD (FPS, estado, caixas, err/vel/conf/progresso) via TYPE_ACCESSIBILITY_OVERLAY
  MainActivity / SettingsActivity  UI mínima; config por key=value (formato do harness)
```

Decisões de design (por quê):

1. **Core determinístico e portátil** — o mesmo código roda no celular e no replay do vídeo.
   Nada de `android.*` no core; entrada sai só por `InputExecutor`.
2. **Barra de pesca = âncora do bloco branco** (não varredura de "linha escura"): a água à
   noite tem o mesmo cinza da barra; o que a desambigua é o bloco branco/tingido dentro dela
   + o fundo mais claro abaixo. Ver `FishingBarDetector` e `VIDEO_ANALYSIS.md`.
3. **Tudo normalizado pela barra**: `normalizedX = (objX − barLeft)/barWidth`, com a barra
   medida (nunca assumida) por frame e suavizada; suporta varas/larguras diferentes (spec §23).
4. **Bloco do jogador com tamanho fixo medido** (não redimensionado pela vara, spec §11);
   controle P-D + feedforward de velocidade do peixe + termo de tendência de deriva
   (esquerda), com deadband → tap curto, banda média → hold, fora dela → soltar.
5. **`Shake`: enquanto o prompt existir, pode pressionar; sem timeout artificial** (spec §9);
   desaparecimento do prompt → início do minigame (detectado, não cronometrado).
6. **Segurança acima de tudo**: `InputSafetyGuard` decide cada gesto (confiança global,
   foreground, captura saudável, overlay suspeito, rate-limit, watchdog de hold).
   `EmergencyStop` com latch libera tudo e só destrava manualmente.
7. **Overlay/notificação do sistema cobre o jogo** → pipeline pausa via
   `overlaySuspected`/`ROBLOX_NOT_DETECTED` (o vídeo mostra a sombra da notification shade
   em f_0571-0626 — foi o gatilho medido para esse caminho).

## Como rodar

### Harnesses (este ambiente, sem Android)

```bash
export PATH=$PWD/../tools/kotlinc/bin:$PATH   # kotlinc 1.9.24
cd core; find src/main/kotlin -name '*.kt' > /tmp/srcs.txt
kotlinc -nowarn @/tmp/srcs.txt -d ../build/core.jar
java -cp ../build/core.jar:<kotlin-stdlib> com.fischa.core.tools.SelfTest
java -cp ../build/core.jar:<kotlin-stdlib> com.fischa.core.tools.ReplayMain ../testdata/frames
```

`testdata/frames` contém os 206 frames JPEG extraídos do vídeo, `gt.csv`
(geometria do bloco por frame, px do vídeo) e `meta.txt` (janela do minigame).

### Android

1. JDK 17 + Android SDK (platforms;android-35, build-tools;35.0.0); crie `local.properties` com
   `sdk.dir=/caminho/do/sdk` e rode `./gradlew :app:assembleDebug` (wrapper Gradle 8.9 incluso).
2. Instalar, abrir o app → **Ativar acessibilidade** ("Fisch AutoBot Input") → **Iniciar**
   (permitir gravação de tela). O Roblox precisa estar em primeiro plano.
3. Overlay de debug e edição de config (`key=value`, mesmas chaves do replay) na tela inicial.

## Segurança de uso

- Uma instância só de Macro; use em conta alt, não na principal (ToS do Roblox pode punir
  automação — risco por sua conta).
- Botão **EMERGÊNCIA** na notificação: cancela gestos pendentes, destrava holds e faz o
  pipeline parar de emitir; para retomar: Start de novo.
- O serviço para tudo se a captura morrer, o Roblox sair do foreground, ou confiança global
  cair abaixo do mínimo por > watchdog.
