# Resultados de verificação — V5 (0.3.0-a22) — build Galaxy A22

Ambiente: Linux x86_64, 2 vCPU / 2 GB RAM, JDK 17 (Temurin 17.0.20.1), Android SDK
(platforms;android-35, build-tools;35.0.0, platform-tools), Gradle 8.9 (wrapper), AGP 8.7.3,
Kotlin 2.0.21. **Nenhum dispositivo Android e nenhum Roblox foram usados.**

Base: FischAutoBotV3-V4 (0.2.0-a22). A V5 **não recriou o projeto** — alterações cirúrgicas
sobre a V4 (ver `docs/CHANGES_V5.md`).

## Build (executado, não presumido)

```
./gradlew :core:test :core:selfTest :app:assembleDebug --rerun-tasks   → BUILD SUCCESSFUL
app/build/outputs/apk/debug/app-debug.apk   3 399 978 bytes
aapt dump badging: package='com.fischa.app' versionCode='3' versionName='0.3.0-a22'
                   sdkVersion 26, targetSdkVersion 35, compileSdk 35
manifest (aapt dump xmltree): FischEngineService foregroundServiceType=0x20 (mediaProjection),
                   exported=false; permissões: FOREGROUND_SERVICE,
                   FOREGROUND_SERVICE_MEDIA_PROJECTION, POST_NOTIFICATIONS, QUERY_ALL_PACKAGES
apksigner verify --print-certs: assinatura debug válida (CN=Android Debug)
                   SHA-256: df27616e92d3d640bb98b36e25882df948edd5f6fcd875178125359fd7da8245
sha256 (apk): be1f5c024492976841dc1b27f67a293b02e97387d3ca3f63ec233669ece5c4b2
dex: ProjectionHolder e RodConfirmTracker presentes; 11 classes*.dex (multidex)
```

Erros de compilação corrigidos no caminho: literal hexadecimal inválido e classe de teste
aninhada sem `inner` (apenas no código de teste novo); vírgula trailing inválida em `when`
(em `FischEngineService.stopEngine`).

## Testes JUnit do core — `./gradlew :core:test` → **77 testes, 0 falhas, 0 erros**

| Classe | Testes | Cobre |
|---|---|---|
| `CoordinateMapperTest` | 8 | coordenadas normalizadas; conversão captura → toque (A22 1600×720, 720×1600, A22 5G); rejeição de pontos inválidos; detecção de aspecto incompatível (preservado) |
| `RobloxForegroundDetectorTest` | 12 | Roblox fullscreen sem root; Activity de outro app substitui; janela viva de outro app bloqueia; evento legado expirado; overlay/IME; acessibilidade indisponível; tela desligada (preservado) |
| `InputSafetyGuardTest` | 5 | todas as condições de bloqueio: macro/realInput/captura/Roblox/foreground/overlay/estado/tracking/controller; frame stale; confiança baixa; coordenadas/duração inválidas; emergência; rate limit (preservado) |
| `EmergencyStopAndInputGateTest` | 6 | Emergency Stop (latch único, listeners, clear); pipeline chama `cancelAll`+`releaseAll` na emergência e no disarm; com `realInput=OFF` o executor nunca recebe tap/hold; pipeline publica blockReason e frame age (preservado) |
| `GestureLeaseTest` | 3 | tap / holdStart / holdExtend / holdRelease / cancelAll; expiração de lease e watchdog; hold infinito rejeitado (preservado) |
| `ControllersTest` | 10 | controller P-D: deadband → nada; erro grande → HOLD_START/EXTEND/RELEASE; peixe à esquerda → só deriva; erro pequeno → tap curto; hold máximo finito; confiança baixa → release; CastController (START/EXTEND/RELEASE no centro detectado, release ao perder botão); ShakeController (preservado) |
| `TrackersTest` | 6 | FishTracker, PlayerBarTracker, BarTracker, ConfidenceTracker (preservado) |
| `FishingStateMachineTest` | 5 | ciclo completo V5 (WAITING_FOR_ROD → CASTING → WAITING_FOR_WATER → SHAKE → MINIGAME → CATCH → RESET → WAITING_FOR_ROD); timeout de confirmação não assume captura; **novos:** WAITING_FOR_ROD só sai com vara confirmada + autorizada; novo ciclo exige nova confirmação; WAITING_FOR_WATER devolve a WAITING_FOR_ROD no timeout |
| `AppConfigTest` / `FrameBufferTest` | 3 / 2 | config round-trip (inclui as novas chaves `rod.*` e `state.waitingForWaterMs`) e limites; buffer latest-only (preservado) |
| **`RodConfirmTrackerTest`** | **7** | **novo (V5 §5):** frames consecutivos, frame único nunca basta, confiança abaixo do threshold nunca confirma, posição instável reinicia a sequência, janela de confirmação, desaparecimento/reset, coordenadas inválidas |
| **`StartSemanticsV5Test`** | **10** | **novo (V5 §22, pipeline com frames sintéticos):** 1. START não executa input; 2. estado inicial = WAITING_FOR_ROD; 3. vara não detectada → zero input; 4. confiança baixa → zero input; 5. vara confirmada → CAST permitido (HOLD_START emitido); 6. Roblox ausente → bloqueado; 7. realInput OFF → bloqueado (ROD_DETECTED/WOULD_CAST, sem gesto); 8. Emergency Stop → bloqueado; 9. captura inválida → bloqueado; 10. frame stale → bloqueado; + extra: cast → WAITING_FOR_WATER após o release |

## SelfTest do core — `./gradlew :core:selfTest` → **97 checks, 0 failures**

Harness determinístico (config, geometria, trackers, controlador, guard, FSM, gate da vara,
simulação de malha fechada). Era 75 checks na V4; ganhou a seção `testRodConfirmationGate`
(RodConfirmTracker + `InputSafetyGuard.evaluateCastGate`) e os fluxos atualizados para V5.

## O que NÃO foi executado (explicitamente)

* **ReplayMain** contra os 206 frames do vídeo de referência: o zip da V4 contém apenas
  `testdata/gt.csv` e `testdata/meta.txt`; a pasta `testdata/frames` **não veio no pacote**.
  Não há resultado de replay nesta rodada (inalterado da V4).
* **Testes instrumentados / em aparelho** (`GestureService`, `ScreenCaptureSource`,
  `GameAccessibilityService`, `DebugOverlay`, `MainActivity`, `ProjectionHolder`,
  `FischEngineService.onStartCommand`): sem emulador/dispositivo neste ambiente. A lógica de
  plataforma foi revisada e compilada, mas só o teste no A22 valida:
  - **a correção do crash pós-MediaProjection** (ordem: `getMediaProjection` na Activity →
    `startForeground(mediaProjection)` no serviço → captura). No logcat, após "Iniciar agora",
    deve aparecer `[CAPTURE] display …` e **nenhum crash**; se ainda crash, o log `[CAPTURE]`
    registra a exceção exata (nada é mascarado);
  - cópia de pixels RGBA do `ImageReader` (ordem de bytes, `rowStride`);
  - precisão do toque (`[INPUT] TAP n=(…) px=(…)` no log vs. posição visual);
  - comportamento do `continueStroke` como hold contínuo no Roblox;
  - verificação de Activity do Roblox pelo `PackageManager` (`[SAFETY] activity changed:`);
  - o gatilho visual da vara no Fisch real (`ROD_CONFIDENCE` / `ROD_CONFIRMED` no log §20).
* **Roblox/Fisch real**: não executado por decisão da especificação (§25).
