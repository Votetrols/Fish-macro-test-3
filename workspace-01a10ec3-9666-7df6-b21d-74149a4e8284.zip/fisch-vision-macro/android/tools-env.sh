# Ambiente de build local (não versionado): JDK 17 + Android SDK + Gradle wrapper.
export JAVA_HOME=/home/user/.cache/toolchain/jdk17
export ANDROID_HOME=/home/user/.cache/toolchain/android-sdk
export ANDROID_SDK_ROOT=$ANDROID_HOME
export PATH=$JAVA_HOME/bin:$ANDROID_HOME/platform-tools:$PATH
