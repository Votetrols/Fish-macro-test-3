# Fase 7 — evidência de validação do pipeline de visão

> Gerado automaticamente por `Phase7ValidationReportTest` (JVM, sem device).
> Os frames são CENAS SINTÉTICAS que reproduzem os estados descritos do
> minigame — o vídeo `1000032864.mp4` não foi disponibilizado. Ver PHASE_7_STATUS.md.

| estado | MAIN BAR (norm) | ZONE (norm) | FISH (norm) | FISH IN ZONE | TRACK |
|---|---|---|---|---|---|
| 01_zona_esquerda_peixe_dentro | 0.0→1.0 | 0.05→0.3 | 0.161 | YES | VALID |

**01_zona_esquerda_peixe_dentro** — zona deslocada à esquerda (branca), marcador dentro dela

```
FISCH DEBUG
FRAME 1   T 0 ms   FPS 30.0
MAIN BAR: X 0.09 → 0.76 (ROI)  CONF 0.97
  PIXELS L 192 R 614 T 367 B 403
ZONE: X 0.05 → 0.3  CENTER 0.18  CONF 0.94
  PIXELS L 214 R 318  TONE WHITE
FISH: X 0.16  CONF 0.62
  Pixel X: 260   Normalized X: 0.161
  LINE 1.0  ICON 1.0
PROGRESS: X 222 → 584  FILL 1.0  CONF 0.93
FISH IN ZONE: YES   MARGIN 0.015
TRACK: ACQUIRING   LOST-FRAMES 0
  BAR : ACQUIRING X 403 AGE 0 CONF 0.97
  ZONE: ACQUIRING X 266 AGE 0 CONF 0.94
  FISH: ACQUIRING X 260 AGE 0 CONF 0.62
FSM: TRACKING
INPUT: DISABLED
VISION 2.0 ms   ROI 634x162
```

| 02_zona_centro_branca | 0.0→1.0 | 0.33→0.63 | 0.472 | YES | VALID |

**02_zona_centro_branca** — zona no centro (branca), marcador dentro

```
FISCH DEBUG
FRAME 2   T 0 ms   FPS 30.0
MAIN BAR: X 0.09 → 0.76 (ROI)  CONF 0.97
  PIXELS L 192 R 614 T 367 B 403
ZONE: X 0.33 → 0.63  CENTER 0.48  CONF 0.98
  PIXELS L 332 R 458  TONE WHITE
FISH: X 0.47  CONF 0.62
  Pixel X: 391   Normalized X: 0.472
  LINE 1.0  ICON 1.0
PROGRESS: X 222 → 584  FILL 1.0  CONF 0.93
FISH IN ZONE: YES   MARGIN 0.015
TRACK: VALID   LOST-FRAMES 0
  BAR : VALID X 403 AGE 1 CONF 0.97
  ZONE: VALID X 330 AGE 1 CONF 0.98
  FISH: VALID X 325 AGE 1 CONF 0.62
FSM: TRACKING
INPUT: DISABLED
VISION 2.0 ms   ROI 634x162
```

| 03_zona_centro_laranja | 0.0→1.0 | 0.33→0.63 | 0.472 | YES | VALID |

**03_zona_centro_laranja** — mesma zona, agora ALARANJADA (mudança visual do §39)

```
FISCH DEBUG
FRAME 3   T 0 ms   FPS 30.0
MAIN BAR: X 0.09 → 0.76 (ROI)  CONF 0.97
  PIXELS L 192 R 614 T 367 B 403
ZONE: X 0.33 → 0.63  CENTER 0.48  CONF 0.98
  PIXELS L 332 R 458  TONE ORANGE
FISH: X 0.47  CONF 0.62
  Pixel X: 391   Normalized X: 0.472
  LINE 1.0  ICON 1.0
PROGRESS: X 222 → 584  FILL 1.0  CONF 0.93
FISH IN ZONE: YES   MARGIN 0.015
TRACK: TRACKING   LOST-FRAMES 0
  BAR : TRACKING X 403 AGE 2 CONF 0.97
  ZONE: TRACKING X 362 AGE 2 CONF 0.98
  FISH: TRACKING X 358 AGE 2 CONF 0.62
FSM: TRACKING
INPUT: DISABLED
VISION 1.4 ms   ROI 634x162
```

| 04_zona_direita_peixe_fora | 0.0→1.0 | 0.66→0.92 | 0.301 | NO | VALID |

**04_zona_direita_peixe_fora** — zona à direita, marcador FORA da zona

```
FISCH DEBUG
FRAME 4   T 0 ms   FPS 30.0
MAIN BAR: X 0.09 → 0.76 (ROI)  CONF 0.97
  PIXELS L 192 R 614 T 367 B 403
ZONE: X 0.66 → 0.92  CENTER 0.79  CONF 0.95
  PIXELS L 470 R 580  TONE WHITE
FISH: X 0.3  CONF 0.82
  Pixel X: 319   Normalized X: 0.301
  LINE 1.0  ICON 1.0
PROGRESS: X 222 → 584  FILL 1.0  CONF 0.93
FISH IN ZONE: NO   MARGIN 0.015
TRACK: TRACKING   LOST-FRAMES 0
  BAR : TRACKING X 403 AGE 3 CONF 0.97
  ZONE: TRACKING X 443 AGE 3 CONF 0.95
  FISH: TRACKING X 338 AGE 3 CONF 0.82
FSM: TRACKING
INPUT: DISABLED
VISION 0.9 ms   ROI 634x162
```

| 05_marcador_sem_icone | 0.0→1.0 | 0.35→0.65 | 0.472 | YES | VALID |

**05_marcador_sem_icone** — marcador parcialmente visível (sem ícone de peixe)

```
FISCH DEBUG
FRAME 5   T 0 ms   FPS 30.0
MAIN BAR: X 0.09 → 0.76 (ROI)  CONF 0.97
  PIXELS L 192 R 614 T 367 B 403
ZONE: X 0.35 → 0.65  CENTER 0.5  CONF 0.98
  PIXELS L 340 R 466  TONE WHITE
FISH: X 0.47  CONF 0.46
  Pixel X: 391   Normalized X: 0.472
  LINE 1.0  ICON 0.18
PROGRESS: X 222 → 584  FILL 1.0  CONF 0.93
FISH IN ZONE: YES   MARGIN 0.015
TRACK: TRACKING   LOST-FRAMES 0
  BAR : TRACKING X 403 AGE 4 CONF 0.97
  ZONE: TRACKING X 423 AGE 4 CONF 0.98
  FISH: TRACKING X 364 AGE 4 CONF 0.46
FSM: TRACKING
INPUT: DISABLED
VISION 0.9 ms   ROI 634x162
```

