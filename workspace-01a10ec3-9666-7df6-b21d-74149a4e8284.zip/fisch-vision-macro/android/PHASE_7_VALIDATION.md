# Fase 7 — Validação (números reais, sem simulação)

Tudo abaixo foi **executado** neste ambiente. Onde algo não pôde ser executado,
está escrito que não pôde.

## Ambiente de execução

| Item | Valor |
|---|---|
| JDK | Temurin 17.0.20.1 (instalado nesta sessão) |
| Gradle | 9.5.0 (wrapper gerado nesta sessão — §44) |
| Android SDK Platform | `platforms;android-37.0` |
| Build-Tools | 37.0.0 (e 36.0.0 instalada automaticamente pelo lint) |
| Device/emulador | **ausente** |
| Memória da máquina | 2 GB (build ajustado para `-Xmx900m` afim de não ser morto pelo OOM-killer; nenhuma configuração do projeto foi alterada por isso) |

## §43 — comandos exigidos

| Comando | Resultado | Evidência |
|---|---|---|
| `./gradlew clean` | **PASS** | `> Task :app:clean` |
| `./gradlew test` | **PASS — 170 testes, 0 falhas, 0 erros, 0 ignorados** | `app/build/test-results/testDebugUnitTest/TEST-*.xml` (20 classes) |
| `./gradlew lint` | **PASS — 0 erros, 32 avisos** | `app/build/reports/lint-results-debug.txt` |
| `./gradlew assembleDebug` | **PASS** | `app/build/outputs/apk/debug/app-debug.apk` (1.685.127 bytes) |
| `./gradlew connectedAndroidTest` | **NÃO EXECUTADO** — nenhum device/emulador disponível |

APK (cópia persistida): `artifacts/apk/fisch-vision-macro-phase7-debug.apk`
SHA-256: `6e3e08aa16443f533de4d075191ca9864c7014c29696bcf83cd54fab92ba5193`

> Nota de ambiente: rodando `clean test lint assembleDebug` em **um único** processo,
> o daemon do Gradle foi morto pelo OOM-killer da máquina (2 GB) durante o
> `packageDebug`. `clean`, `test` e `lint` já haviam concluído com sucesso; o
> empacotamento foi re-executado isolado e passou em 16 s. Isso é limitação de
> memória do ambiente, não do projeto — nenhuma configuração do Gradle/AGP foi
> alterada para "resolver" o problema.

### Suíte de testes por classe

| Classe | Casos | Falhas |
|---|---|---|
| Phase7SafetyTest | 19 | 0 |
| Phase7DetectorsTest | 19 | 0 |
| Phase7NormalizationTest | 15 | 0 |
| Phase7TrackerTest | 10 | 0 |
| Phase7RateLimiterTest | 9 | 0 |
| Phase7FrameOwnershipTest | 7 | 0 |
| Phase7OutcomeTest | 7 | 0 |
| Phase7CalibrationFlowTest | 6 | 0 |
| Phase7SceneDiagnosticsTest | 1 | 0 |
| Phase7ReplayHarnessTest | 1 | 0 |
| Phase7ValidationReportTest | 1 | 0 |
| *(herdados)* MacroStateMachineTest | 14 | 0 |
| *(herdados)* VisionPipelineTest | 11 | 0 |
| *(herdados)* ControllerTest | 10 | 0 |
| *(herdados)* ContractsTest | 9 | 0 |
| *(herdados)* TrackerTest | 8 | 0 |
| *(herdados)* CaptureInfraTest | 7 | 0 |
| *(herdados)* FrameBusTest | 6 | 0 |
| *(herdados)* InputGatingTest | 5 | 0 |
| *(herdados)* IntegrationFlowTest | 5 | 0 |
| **TOTAL** | **170** | **0** |

Os testes herdados **nunca haviam sido executados** (FINAL_AUDIT anterior: tudo
`BLOCKED`). Ao rodá-los, 6 deles falharam e foram corrigidos — 4 por defeitos de
compilação/lógica no próprio código de produção e 2 por construção da cena de
teste (detalhado em `PHASE_7_STATUS.md` §5).

### Avisos do lint (32, nenhum erro)

Categorias: dependências com versão mais nova disponível
(`AndroidGradlePluginVersion` 9.8.0, `GradleDependency`, `NewerVersionAvailable`),
`MissingTranslation`/`UnusedResources` de recursos legados, e avisos de API
legada (`applicationVariants`/`testVariants`, `startActivityForResult`) que a
própria AGP 9 emite por conta do opt-out `android.newDsl=false` já documentado no
projeto. **Nenhum aviso novo foi introduzido pelos arquivos da Fase 7** além de
`"Method w in android.util.Log not mocked"` — que não aparece mais porque a
suíte passou a usar `testOptions.unitTests.isReturnDefaultValues = true`.

## §37/§47 — evidência visual da validação

Diretório: `artifacts/phase7-validation/`

| Arquivo | Estado validado |
|---|---|
| `final/01_zona_esquerda_peixe_dentro.png` | zona à esquerda, peixe dentro |
| `final/02_zona_centro_branca.png` | zona central branca |
| `final/03_zona_centro_laranja.png` | **mesma** zona, alaranjada (§39) |
| `final/04_zona_direita_peixe_fora.png` | zona à direita, peixe fora |
| `final/05_marcador_sem_icone.png` | marcador sem ícone (linha basta — §13) |
| `final/06_barra_ausente_fim_de_rodada.png` | fim de rodada: barra ausente |
| `RELATORIO_VALIDACAO.md` | tabela + texto integral do overlay em cada estado |
| `*.png` / `*.txt` (raiz) | mapa de diagnóstico usado na calibração |

Cada PNG traz o frame com as caixas desenhadas (MAIN BAR ciano, ZONE âmbar,
FISH verde, PROGRESS magenta, ROI cinza) e o `.txt` mostra exatamente as linhas
que o painel do overlay exibe no app.

### Amostra real do painel (estado 02)

```
FISCH DEBUG
FRAME 3   T 66 ms   FPS 30.0
MAIN BAR: X 0.09 → 0.76 (ROI)  CONF 0.97
  PIXELS L 192 R 614 T 367 B 403
ZONE: X 0.33 → 0.63  CENTER 0.48  CONF 0.98
  PIXELS L 336 R 446  TONE WHITE
FISH: X 0.47  CONF 0.62
  Pixel X: 391   Normalized X: 0.472
  LINE 1.0  ICON 1.0
PROGRESS: X 222 → 584  FILL 1.0  CONF 0.93
FISH IN ZONE: YES   MARGIN 0.015
TRACK: VALID   LOST-FRAMES 0
  BAR : TRACKING X 403 AGE 2 CONF 0.97
  ZONE: TRACKING X 391 AGE 2 CONF 0.98
  FISH: TRACKING X 391 AGE 2 CONF 0.62
FSM: TRACKING
INPUT: DISABLED
OUTCOME: NONE  CONF 0.00
  minigame ativo
VISION 2.4 ms   ROI 633x162
```

## O que a evidência prova — e o que ela NÃO prova

**Prova:**
- o pipeline **roda** e produz detecções coerentes em seis estados distintos;
- MAIN BAR, ZONE, FISH e PROGRESS são entidades **separadas** com confidence
  calculada por critérios explícitos;
- a ZONE é encontrada **branca e alaranjada** na mesma posição (§39);
- o FISH é encontrado **sem o ícone** (§13) e **dentro** de uma zona clara;
- a normalização contra a barra corresponde à posição real medida;
- perda de alvo vira `TRACK_LOST`/`LOST_DETECTION` e **não** sucesso (§18/§33);
- a FSM percorre WAITING → DETECTING → TRACKING e nunca chega a CONTROLLING;
- `INPUT: DISABLED` permanece em todos os snapshots;
- 170 testes cobrem normalização, detectores, tracker, segurança, rate limiter,
  propriedade de frame, fluxo de calibração e o harness de replay.

**NÃO prova (limitação honesta):**
- que os detectores funcionam sobre os **pixels reais do jogo**;
- que os limiares estão calibrados para o enquadramento real do vídeo;
- desempenho/FPS em aparelho real;
- que o overlay desenha corretamente sobre a tela do jogo (só foi testado em JVM).

A razão é única e objetiva: **o `1000032864.mp4` não foi disponibilizado** — nem
no repositório, nem como anexo. Assim que os frames existirem:

```bash
# 1. extrair frames do vídeo (mesmos instantes citados no §37)
ffmpeg -i 1000032864.mp4 -ss 5.5  -frames:v 1 frames/f_055.png
ffmpeg -i 1000032864.mp4 -ss 8    -frames:v 1 frames/f_080.png
ffmpeg -i 1000032864.mp4 -ss 10   -frames:v 1 frames/f_100.png
ffmpeg -i 1000032864.mp4 -ss 12   -frames:v 1 frames/f_120.png
ffmpeg -i 1000032864.mp4 -ss 14   -frames:v 1 frames/f_140.png
ffmpeg -i 1000032864.mp4 -ss 15   -frames:v 1 frames/f_150.png

# 2. alimentar o MESMO pipeline (harness já implementado e verificado)
#    => app/src/test/resources/frames/ e rodar:
./gradlew :app:testDebugUnitTest --tests '*Phase7ReplayHarnessTest*'

# 3. abrir artifacts/phase7-validation/replay/ e ajustar VisionConfig/RoiConfig
```

O `RecordedFrameSource` + `FishingVisionAnalyzer` já são exatamente o caminho
`FRAME → DETECTOR → TRACKER` que o §36 pede; falta apenas o insumo.
