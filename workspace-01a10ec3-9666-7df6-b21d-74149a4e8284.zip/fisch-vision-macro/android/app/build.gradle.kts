// ============================================================================
// Fisch Vision Macro — módulo :app
// Stack da Fase 1 (auditada 2026):
//   AGP 9.3.0 · KGP 2.4.20 · Gradle 9.5.0 · JDK 17 · SDK 37/37/26
// UI: Views simples (sem Compose nesta fase, conforme especificação).
// Dependências: mínimas e justificadas (ver PHASE_1_STATUS.md > Dependências).
// ============================================================================

import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fischvision.macro"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.fischvision.macro"
        minSdk = 26
        targetSdk = 37
        versionCode = 1
        versionName = "0.1.0-phase1"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            // Fase 1: sem ofuscação; release ainda não é distribuído.
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    testOptions {
        unitTests {
            // Fase 7: o núcleo puro (core/vision/tracker/controller/input) é
            // exercitado em JVM, mas o DebugLogger escreve em android.util.Log —
            // classe de plataforma que no teste unitário é um stub. Devolver
            // valores padrão permite que a suíte rode sem device sem que o
            // código de produção precise de um seam artificial só para teste.
            isReturnDefaultValues = true
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    // Pipeline assíncrono (FrameBus/contratos coroutines) — arquitetura aprovada.
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    // Testes unitários JVM (core/ é Kotlin puro, sem dependência de Android).
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.10.2")

    // Smoke test de instrumentação da MainActivity (executa somente em device).
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
}
