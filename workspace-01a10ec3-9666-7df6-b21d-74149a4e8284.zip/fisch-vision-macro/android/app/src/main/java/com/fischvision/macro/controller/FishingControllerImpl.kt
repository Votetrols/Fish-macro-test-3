package com.fischvision.macro.controller

import kotlin.math.abs

/**
 * Configuração do controlador — tudo calibrável, defaults conservadores
 * declarados NÃO VALIDADOS em aparelho.
 */
data class ControlConfig(
    val deadZonePx: Float = 6f,
    /** Histerese: sair do erro exige margem menor (anti-ziguezague). */
    val exitDeadZonePx: Float = deadZonePx * 0.6f,
    val minHoldMillis: Long = 60,
    val minReleaseMillis: Long = 60,
    val maxHoldMillis: Long = 900,
    val maxCommandRateHz: Int = 20,
    val minConfidence: Float = 0.35f,
) {
    init {
        require(deadZonePx > 0f) { "deadZone deve ser positiva" }
        require(exitDeadZonePx in 0f..deadZonePx) { "exitDeadZone fora de (0, deadZone]" }
        require(minHoldMillis >= 0 && minReleaseMillis >= 0 && maxHoldMillis > 0) { "tempos inválidos" }
        require(maxCommandRateHz in 1..60) { "taxa de comandos fora de [1,60]" }
        require(minConfidence in 0f..1f) { "minConfidence fora de [0,1]" }
    }
}

/**
 * Controlador real — Fase 4.
 *
 * Modelo de ação: PRESS inicia o engajamento, HOLD mantém, RELEASE solta.
 * A polaridade física (segurar sobe/desce o indicador) é CALIBRAÇÃO do jogo,
 * não decisão desta camada: aqui o que existe é engajar/desengajar com
 * histerese, tetos de tempo e limite de taxa.
 *
 * FAIL-SAFE (ordem de prioridade):
 *  1. dt inválido / timestamps fora de ordem ....... NONE (sem mudança de estado)
 *  2. alvos nulos ou confidence < mínima ........... RELEASE se segurando; senão NONE
 *  3. maxHold atingido ............................. RELEASE (nunca prende indefinidamente)
 *  4. erro eliminado (histerese) ................... RELEASE
 *  5. taxa mínima entre trocas de comando ......... suprime transições cedo demais
 *
 * Relógio injetável (clock) → testes determinísticos sem Thread.sleep.
 *
 * @status IMPLEMENTED / testes JVM escritos (execução local pendente)
 */
class FishingControllerImpl(
    private val config: ControlConfig = ControlConfig(),
    private val clock: () -> Long = { System.nanoTime() },
) : Controller {

    private var holding = false
    private var holdStartedAtNanos = 0L

    /**
     * FASE 7 — CORREÇÃO DE DEFEITO: a sentinela `Long.MIN_VALUE` fazia
     * `now - lastTransitionAtNanos` ESTOURAR (wrap-around) e retornar um valor
     * negativo, então `rateAllows` reprovava a PRIMEIRA transição do processo —
     * o controlador nunca emitia PRESS inicial até o primeiro reset.
     * Agora o estado é explícito e a aritmética é sempre com valores reais.
     */
    private var hasTransition = false
    private var lastTransitionAtNanos = 0L

    val isHolding: Boolean get() = holding

    override fun update(
        targetPositionX: Float?,
        indicatorPositionX: Float?,
        confidence: Float,
        deltaTimeNanos: Long,
    ): ControlCommand {
        val now = clock()

        // 1 — tempo inválido: nada muda, nada comanda.
        if (deltaTimeNanos <= 0L) return ControlCommand(ControlCommand.Type.NONE, reason = "deltaTime inválido")

        // 2 — fail-safe de visão.
        if (targetPositionX == null || indicatorPositionX == null || confidence < config.minConfidence) {
            return if (holding) transitionToRelease(now, "confidence < mínimo ou alvo ausente")
            else ControlCommand(ControlCommand.Type.NONE, reason = "sem alvos confiáveis")
        }

        val error = targetPositionX - indicatorPositionX
        val absError = abs(error)

        return if (!holding) {
            when {
                absError <= config.deadZonePx ->
                    ControlCommand(ControlCommand.Type.NONE, reason = "dentro da zona morta (${absError.round1()}px)")
                !rateAllows(now) ->
                    ControlCommand(ControlCommand.Type.NONE, reason = "respeitando minRelease entre comandos")
                else -> {
                    holding = true
                    holdStartedAtNanos = now
                    markTransition(now)
                    ControlCommand(
                        ControlCommand.Type.PRESS,
                        maxDurationMillis = config.maxHoldMillis,
                        reason = "erro ${error.round1()}px acima da zona morta",
                    )
                }
            }
        } else {
            val heldFor = now - holdStartedAtNanos
            val minHoldNanos = config.minHoldMillis * 1_000_000L
            when {
                heldFor >= config.maxHoldMillis * 1_000_000L ->
                    transitionToRelease(now, "maxHold atingido — fail-safe")
                absError <= config.exitDeadZonePx && heldFor >= minHoldNanos ->
                    transitionToRelease(now, "erro eliminado (${absError.round1()}px)")
                absError <= config.exitDeadZonePx ->
                    ControlCommand(ControlCommand.Type.HOLD, maxDurationMillis = config.maxHoldMillis, reason = "minHold em vigor (anti-chatter)")
                else ->
                    ControlCommand(ControlCommand.Type.HOLD, maxDurationMillis = config.maxHoldMillis, reason = "mantendo (heldFor=${heldFor / 1_000_000}ms)")
            }
        }
    }

    override fun reset() {
        holding = false
        hasTransition = false
        lastTransitionAtNanos = 0L
        holdStartedAtNanos = 0L
    }

    private fun transitionToRelease(now: Long, why: String): ControlCommand {
        holding = false
        markTransition(now)
        return ControlCommand(ControlCommand.Type.RELEASE, reason = why)
    }

    private fun markTransition(now: Long) {
        lastTransitionAtNanos = now
        hasTransition = true
    }

    private fun rateAllows(now: Long): Boolean {
        if (!hasTransition) return true
        val minIntervalNanos = 1_000_000_000L / config.maxCommandRateHz
        val minReleaseNanos = config.minReleaseMillis * 1_000_000L
        val floor = maxOf(minIntervalNanos, minReleaseNanos)
        return now - lastTransitionAtNanos >= floor
    }

    private fun Float.round1(): String = "%.1f".format(this)
}
