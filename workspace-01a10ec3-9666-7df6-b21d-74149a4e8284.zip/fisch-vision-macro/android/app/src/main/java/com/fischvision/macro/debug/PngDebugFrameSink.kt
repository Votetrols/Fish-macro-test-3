package com.fischvision.macro.debug

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import com.fischvision.macro.capture.Frame
import com.fischvision.macro.capture.RgbaFramePayload
import java.io.File
import java.io.FileOutputStream

/**
 * Gravação de frames de debug (§24) — DESLIGADA por padrão em [DebugCaptureConfig].
 *
 * Quando habilitada, salvamos o frame REAL da captura com as caixas de detecção
 * desenhadas por cima + o texto do debug. É a evidência que permite comparar o
 * que o detector viu com o que está no vídeo, exatamente o objetivo da fase.
 *
 * Nunca cria vídeo contínuo; quem decide os frames é [DebugCapturePolicy]
 * (eventos + amostragem a cada N frames, com teto por sessão).
 */
class PngDebugFrameSink(
    appContext: Context,
    directoryName: String = "phase7-debug",
) : DebugFrameSink {

    private val directory: File = File(appContext.filesDir, directoryName)

    var lastSavedPath: String? = null
        private set

    override fun save(snapshot: VisionDebugSnapshot, frame: Frame) {
        val payload = frame.payload as? RgbaFramePayload ?: return
        if (!directory.exists() && !directory.mkdirs()) return

        val width = payload.pixelWidth
        val height = payload.pixelHeight
        if (width <= 0 || height <= 0) return

        val pixels = IntArray(width * height)
        for (y in 0 until height) {
            for (x in 0 until width) {
                pixels[y * width + x] = payload.argbAt(x, y) ?: Color.BLACK
            }
        }
        val bitmap = Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
        drawAnnotations(bitmap, snapshot)

        val file = File(directory, "frame_%06d.png".format(snapshot.frameIndex))
        try {
            FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.PNG, 90, out) }
            lastSavedPath = file.absolutePath
            DebugLogger.d(DebugLogger.Category.VISION, "frame de debug salvo: ${file.name}")
        } catch (e: Exception) {
            DebugLogger.w(DebugLogger.Category.VISION, "falha ao salvar frame de debug", e)
        } finally {
            bitmap.recycle()
        }
    }

    private fun drawAnnotations(bitmap: Bitmap, snapshot: VisionDebugSnapshot) {
        val canvas = Canvas(bitmap)
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 14f
            typeface = Typeface.MONOSPACE
        }
        snapshot.mainBar?.takeIf { it.valid }?.let {
            stroke.color = Color.parseColor("#22D3EE")
            canvas.drawRect(it.left, it.top, it.right, it.bottom, stroke)
            canvas.drawText("MAIN BAR", it.left, (it.top - 3f).coerceAtLeast(12f), text)
        }
        snapshot.zone?.takeIf { it.valid }?.let {
            stroke.color = Color.parseColor("#FBBF24")
            canvas.drawRect(it.left, it.top, it.right, it.bottom, stroke)
            canvas.drawText("ZONE", it.left, (it.bottom + 12f).coerceAtMost(bitmap.height - 2f), text)
        }
        snapshot.fish?.takeIf { it.valid }?.let {
            stroke.color = Color.parseColor("#34D399")
            canvas.drawRect(
                it.boundingBox.left.toFloat(),
                it.boundingBox.top.toFloat(),
                it.boundingBox.right.toFloat(),
                it.boundingBox.bottom.toFloat(),
                stroke,
            )
            canvas.drawText("FISH", it.centerX, (it.boundingBox.top - 3f).coerceAtLeast(12f), text)
        }
        snapshot.progress.takeIf { it.valid }?.let {
            stroke.color = Color.parseColor("#E879F9")
            canvas.drawRect(it.left, it.top, it.right, it.bottom, stroke)
            canvas.drawText("PROGRESS", it.left, (it.bottom + 12f).coerceAtMost(bitmap.height - 2f), text)
        }
    }
}
