package com.fischvision.macro.service

import com.fischvision.macro.capture.CaptureEvent
import com.fischvision.macro.capture.CaptureEventSource
import com.fischvision.macro.capture.Frame
import com.fischvision.macro.capture.FrameBus
import com.fischvision.macro.capture.FrameSource
import com.fischvision.macro.core.MacroError
import com.fischvision.macro.core.MacroEvent
import com.fischvision.macro.core.MacroState
import com.fischvision.macro.core.MacroStateMachine
import com.fischvision.macro.debug.DebugCaptureConfig
import com.fischvision.macro.debug.DebugCapturePolicy
import com.fischvision.macro.debug.DebugFrameSink
import com.fischvision.macro.debug.EventLogger
import com.fischvision.macro.debug.MacroEventKind
import com.fischvision.macro.debug.VisionDebugSnapshot
import com.fischvision.macro.input.InputSafetyGuard
import com.fischvision.macro.input.InputWiring
import com.fischvision.macro.settings.MacroSettings
import com.fischvision.macro.tracker.EntityTracker
import com.fischvision.macro.tracker.TrackObservation
import com.fischvision.macro.tracker.TrackState
import com.fischvision.macro.vision.detect.FishingVisionAnalyzer
import com.fischvision.macro.vision.detect.FishingVisionFrame
import com.fischvision.macro.vision.detect.VisionConfig
import com.fischvision.macro.vision.outcome.MinigameOutcomeDetector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

/**
 * Pipeline de CALIBRAÇÃO da Fase 7 (§6/§25) — o substituto honesto do pipeline
 * de controle enquanto INPUT = DISABLED.
 *
 *     MediaProjection → FrameSource → Frame → ROI → visão (4 detectores)
 *        → tracker (MAIN_BAR/ZONE/FISH) → normalização → debug overlay
 *
 * O QUE ELE NÃO FAZ (por decisão da fase, não por falta de tempo):
 *  - NÃO instancia nem chama [com.fischvision.macro.input.InputController];
 *  - NÃO despacha `ControlRequested` nem qualquer evento que autorize input;
 *  - NÃO altera os detectores para "ajudar" o controle.
 *
 * Ele compartilha a MESMA máquina de estados do serviço: WAITING_FOR_FISHING_UI
 * → DETECTING → TRACKING → (LOST_DETECTION ↔ TRACKING). `CONTROLLING` nunca é
 * alcançado nessa fase, porque isso exigiria input habilitado.
 *
 * Observação de custo: um frame é processado UMA vez; a amostragem da ROI e a
 * máscara estrutural são reutilizadas pelos quatro detectores (§40).
 */
class CalibrationEngine(
    private val scope: CoroutineScope,
    private val fsm: MacroStateMachine,
    private val bus: FrameBus,
    private val settings: MacroSettings = MacroSettings.DEFAULT,
    private val analyzer: FishingVisionAnalyzer = FishingVisionAnalyzer(
        config = VisionConfig.DEFAULT,
        roiConfig = settings.roiConfig(),
        zoneMarginNormalized = settings.zoneEdgeMarginPercent,
    ),
    private val clock: () -> Long = { System.nanoTime() },
    private val sink: LogSink = LogSink.NOOP,
    /** Recebe cada snapshot (o overlay desenha a partir dele). */
    private val onSnapshot: (VisionDebugSnapshot) -> Unit = {},
    /** Pacote em foreground (vem do AccessibilityService; null = desconhecido). */
    private val foregroundPackage: () -> String? = { null },
    private val debugFrameSink: DebugFrameSink? = null,
    private val capturePolicy: DebugCapturePolicy = DebugCapturePolicy(
        DebugCaptureConfig(
            enabled = settings.debugFrameCaptureEnabled,
            everyNFrames = settings.debugFrameCaptureEveryNFrames,
            maxFramesPerSession = settings.debugFrameCaptureMax,
        ),
    ),
) {

    private val barTracker = EntityTracker(
        name = VisionDebugSnapshot.TRACK_MAIN_BAR,
        maxLostFrames = settings.maxLostFrames,
    )
    private val zoneTracker = EntityTracker(
        name = VisionDebugSnapshot.TRACK_ZONE,
        maxLostFrames = settings.maxLostFrames,
    )
    private val fishTracker = EntityTracker(
        name = VisionDebugSnapshot.TRACK_FISH,
        maxLostFrames = settings.maxLostFrames,
    )
    private val outcomeDetector = MinigameOutcomeDetector(minAbsentFrames = settings.maxLostFrames + 2)
    private val eventLogger = EventLogger(
        sink = { kind, message -> sink.log(4, "VISION", "$kind $message") },
        minIntervalMillisPerEvent = 1_000L,
        maxEventsPerSecond = 6,
        clock = clock,
    )
    private val safetyGuard = InputSafetyGuard(settings.targetAppPackage)

    class Telemetry {
        @Volatile var framesProcessed = 0L
        @Volatile var frameIndex = 0L
        @Volatile var fps = 0.0
        @Volatile var lastSnapshot: VisionDebugSnapshot? = null
        @Volatile var projectionActive = false
        @Volatile var inputStateLabel = InputSafetyGuard.DISABLED_LABEL
    }

    val telemetry = Telemetry()

    private var job: Job? = null
    private var eventsJob: Job? = null
    private var windowStartNanos = 0L
    private var windowFrames = 0L

    val isRunning: Boolean get() = job?.isActive == true

    fun start(source: FrameSource): Boolean {
        if (isRunning) {
            sink.log(4, "SERVICE", "calibração já ativa — instância única preservada")
            return false
        }
        if (!fsm.dispatch(MacroEvent.Start).accepted) {
            sink.log(5, "STATE", "Start recusado em ${fsm.state}")
            return false
        }
        telemetry.projectionActive = true
        job = scope.launch { runPipeline(source) }
        eventLogger.emit(MacroEventKind.CALIBRATION_STATE, "iniciado (INPUT=DISABLED)")
        return true
    }

    fun pause() {
        if (fsm.dispatch(MacroEvent.Pause).accepted) log("calibração pausada")
    }

    fun resume() {
        fsm.dispatch(MacroEvent.Resume)
    }

    fun stop() {
        job?.cancel()
        job = null
        eventsJob?.cancel()
        eventsJob = null
        fsm.dispatch(MacroEvent.Stop)
    }

    fun latestSnapshot(): VisionDebugSnapshot? = telemetry.lastSnapshot

    // ------------------------------------------------------------- pipeline

    private suspend fun runPipeline(source: FrameSource) {
        try {
            source.start()
        } catch (t: Throwable) {
            telemetry.projectionActive = false
            fsm.dispatch(
                MacroEvent.FatalError(MacroError(MacroError.Type.CAPTURE_FAILED, t.message ?: "fonte não iniciou", t)),
            )
            sink.log(6, "ERROR", "falha ao iniciar a fonte de captura")
            return
        }

        // Ciclo de parada (§29): a projeção terminou ⇒ o pipeline desarma e o
        // estado volta ao seguro. Nenhum input existe nesta fase para soltar,
        // mas a cadeia é a mesma usada pelo pipeline de controle.
        eventsJob = (source as? CaptureEventSource)?.let { eventSource ->
            scope.launch {
                eventSource.captureEvents().collect { event -> handleCaptureEvent(event) }
            }
        }

        try {
            source.frames().collect { frame ->
                try {
                    if (fsm.state == MacroState.STOPPED || fsm.state == MacroState.ERROR) return@collect
                    step(frame)
                } catch (t: Throwable) {
                    sink.log(6, "ERROR", "falha no passo de visão: ${t.message}")
                    fsm.dispatch(MacroEvent.FatalError(MacroError(MacroError.Type.VISION_FAILED, t.message ?: "erro", t)))
                } finally {
                    // Dono do release: SEMPRE o engine (§30).
                    frame.payload.release()
                }
            }
            if (fsm.state != MacroState.STOPPED && fsm.state != MacroState.ERROR) {
                sink.log(4, "SERVICE", "fluxo de frames encerrado sem evento de parada da projeção")
            }
        } catch (t: Throwable) {
            sink.log(6, "ERROR", "fluxo de frames falhou: ${t.message}")
            fsm.dispatch(MacroEvent.FatalError(MacroError(MacroError.Type.CAPTURE_FAILED, t.message ?: "captura falhou", t)))
        } finally {
            telemetry.projectionActive = false
            eventsJob?.cancel()
            eventsJob = null
        }
    }

    private fun handleCaptureEvent(event: CaptureEvent) {
        when (event) {
            CaptureEvent.ProjectionStopped -> {
                telemetry.projectionActive = false
                log("marcação de parada da projeção recebida")
                fsm.dispatch(MacroEvent.ProjectionStopped)
                eventLogger.emit(MacroEventKind.CALIBRATION_STATE, "projeção encerrada → estado seguro (${fsm.state})")
            }
            is CaptureEvent.Failure -> {
                telemetry.projectionActive = false
                fsm.dispatch(MacroEvent.FatalError(MacroError(MacroError.Type.CAPTURE_FAILED, event.message)))
                eventLogger.emit(MacroEventKind.ERROR, event.message)
            }
        }
    }

    private fun step(frame: Frame) {
        val frameIndex = ++telemetry.frameIndex
        fsm.dispatch(MacroEvent.FrameAvailable(frame.timestampNanos))
        if (fsm.state == MacroState.PAUSED) return

        // Publica para consumidores auxiliares com janela de vida de 1 frame (§30).
        bus.publishShared(frame)
        telemetry.framesProcessed++
        updateFps(frame.timestampNanos)

        val vision = analyzer.analyze(frame, frameIndex)
        val progressFill = vision.progress.fillFraction

        val timestamp = vision.timestampNanos
        val barObs = vision.mainBar?.takeIf { it.valid }
            ?.let { TrackObservation(it.centerX, it.centerY, it.confidence, timestamp) }
        val zoneObs = vision.zone?.takeIf { it.valid }
            ?.let { TrackObservation(it.centerX, it.centerY, it.confidence, timestamp) }
        val fishObs = vision.fish?.takeIf { it.valid }
            ?.let { TrackObservation(it.centerX, it.centerY, it.confidence, timestamp) }

        val barAccepted = barTracker.observe(frameIndex, timestamp, barObs)
        val zoneAccepted = zoneTracker.observe(frameIndex, timestamp, zoneObs)
        val fishAccepted = fishTracker.observe(frameIndex, timestamp, fishObs)

        publishAcquisitionEvents()
        driveFsm()

        val outcome = outcomeDetector.observe(
            barPresent = barTracker.valid && barAccepted,
            zonePresent = zoneTracker.valid && zoneAccepted,
            progressFill = progressFill,
            sample = analyzer.currentSample,
        )
        if (outcome.isCandidate) {
            eventLogger.emitOnChange(
                kind = if (outcome.signal == MinigameOutcomeDetector.Signal.SUCCESS_CANDIDATE) MacroEventKind.SUCCESS else MacroEventKind.FAILED,
                currentState = outcome.signal.name,
                message = "conf ${"%.2f".format(outcome.confidence)} · ${outcome.reason}",
            )
            fsm.dispatch(
                MacroEvent.OutcomeObserved(
                    success = outcome.signal == MinigameOutcomeDetector.Signal.SUCCESS_CANDIDATE,
                    confidence = outcome.confidence,
                ),
            )
        }

        val snapshot = buildSnapshot(vision, outcome)
        telemetry.lastSnapshot = snapshot
        onSnapshot(snapshot)

        val eventFrame = outcome.isCandidate || barTracker.state == TrackState.LOST
        if (capturePolicy.shouldCapture(frameIndex, eventFrame)) {
            debugFrameSink?.save(snapshot, frame)
            capturePolicy.onSaved()
        }
    }

    private fun publishAcquisitionEvents() {
        eventLogger.emitOnChange(
            MacroEventKind.BAR_ACQUIRED,
            barTracker.state.name,
            "barra conf ${"%.2f".format(barTracker.confidence)}",
        )
        eventLogger.emitOnChange(
            MacroEventKind.ZONE_ACQUIRED,
            zoneTracker.state.name,
            "zona conf ${"%.2f".format(zoneTracker.confidence)}",
        )
        eventLogger.emitOnChange(
            MacroEventKind.FISH_ACQUIRED,
            fishTracker.state.name,
            "marcador conf ${"%.2f".format(fishTracker.confidence)}",
        )
        if (barTracker.lost || fishTracker.lost || zoneTracker.lost) {
            eventLogger.emitOnChange(
                MacroEventKind.TRACK_LOST,
                "LOST",
                "bar=${barTracker.state} zone=${zoneTracker.state} fish=${fishTracker.state}",
            )
        } else {
            eventLogger.emitOnChange(MacroEventKind.TRACK_LOST, "OK", "")
        }
    }

    /**
     * Conduz a FSM EXISTENTE (nenhum estado novo):
     *  - barra presente ..................... WAITING_FOR_FISHING_UI → DETECTING;
     *  - barra + zona + marcador consistentes  DETECTING → TRACKING;
     *  - QUALQUER entidade além de [MacroSettings.maxLostFrames] sem ser vista
     *    ..................................... TRACKING → LOST_DETECTION (§18);
     *  - alvos de volta dentro da janela ...... LOST_DETECTION → DETECTING (reacquire).
     *
     * A perda conta para as três entidades — e não só para a barra — porque a
     * zona e o marcador também são necessários para qualquer decisão: se um
     * deles desapareceu de verdade, o macro não tem o que observar. Perdas
     * curtas continuam sem mudar o estado (§18).
     *
     * Nunca há ControlRequested: a fase não abre caminho de input.
     */
    private fun driveFsm() {
        val barReady = barTracker.valid
        val targetsReady = zoneTracker.valid && fishTracker.valid
        val anyLost = barTracker.lost || zoneTracker.lost || fishTracker.lost
        when (fsm.state) {
            MacroState.WAITING_FOR_FISHING_UI -> if (barReady) fsm.dispatch(MacroEvent.DetectionFound)
            MacroState.DETECTING -> if (targetsReady) fsm.dispatch(MacroEvent.DetectionFound)
            MacroState.LOST_DETECTION -> if (targetsReady) fsm.dispatch(MacroEvent.DetectionFound)
            MacroState.TRACKING -> if (anyLost) fsm.dispatch(MacroEvent.DetectionLost)
            else -> Unit
        }
    }

    private fun buildSnapshot(vision: FishingVisionFrame, outcome: MinigameOutcomeDetector.Outcome): VisionDebugSnapshot {
        val trackingValid = barTracker.valid && zoneTracker.valid && fishTracker.valid
        val safetyContext = InputWiring.safetyContext(
            settings = settings,
            foregroundPackage = foregroundPackage(),
            trackingValid = trackingValid,
            confidence = vision.overallConfidence,
            fsmState = fsm.state,
            projectionActive = telemetry.projectionActive,
            calibrationMode = settings.calibrationMode,
        )
        val decision = safetyGuard.evaluate(safetyContext)
        val inputLabel = InputWiring.hudInputState(settings, decision)
        telemetry.inputStateLabel = inputLabel

        return VisionDebugSnapshot(
            frameIndex = telemetry.frameIndex,
            timestampMillis = vision.timestampNanos / 1_000_000L,
            fps = telemetry.fps,
            frameWidth = vision.frameWidth,
            frameHeight = vision.frameHeight,
            roi = vision.roi,
            mainBar = vision.mainBar,
            zone = vision.zone,
            fish = vision.fish,
            progress = vision.progress,
            fishInsideZone = vision.fishInsideZone,
            zoneMarginNormalized = vision.zoneMarginNormalized,
            tracks = listOf(barTracker.snapshot(), zoneTracker.snapshot(), fishTracker.snapshot()),
            fsmState = fsm.state.name,
            inputState = inputLabel,
            outcome = outcome,
            processingMillis = vision.processingNanos / 1_000_000.0,
            lostFrames = maxOf(barTracker.missedFrames, zoneTracker.missedFrames, fishTracker.missedFrames),
        )
    }

    private fun updateFps(timestampNanos: Long) {
        if (windowStartNanos == 0L) {
            windowStartNanos = timestampNanos
            windowFrames = 1
            return
        }
        windowFrames++
        val elapsed = timestampNanos - windowStartNanos
        if (elapsed >= 1_000_000_000L) {
            telemetry.fps = windowFrames * 1_000_000_000.0 / elapsed
            windowStartNanos = timestampNanos
            windowFrames = 0
        }
    }

    private fun log(message: String) {
        sink.log(4, "VISION", message)
    }

    /** Eventos suprimidos pelo limitador de logs (§41) — diagnóstico. */
    fun suppressedLogEvents(): Int = eventLogger.suppressed
}
