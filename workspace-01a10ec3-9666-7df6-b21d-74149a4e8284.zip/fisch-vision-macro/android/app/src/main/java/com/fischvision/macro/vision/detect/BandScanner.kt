package com.fischvision.macro.vision.detect

import com.fischvision.macro.vision.RoiSample

/**
 * Varredura de FAIXAS HORIZONTAIS dentro da ROI.
 *
 * Base comum dos detectores de barra principal e de barra de progresso (§8/§16):
 * ambos procuram um "slab" horizontal contínuo, diferenciado do fundo, e ambos
 * precisam rejeitar objetos verticais, objetos pequenos e estruturas parciais.
 * Em vez de duplicar a lógica, os dois usam esta varredura com PORTÕES e SCORES
 * diferentes — o que é justamente o critério que distingue MAIN_BAR de
 * PROGRESS_BAR.
 *
 * Usa buffers reutilizados por instância (nenhuma alocação por frame).
 */
/**
 * Componente compartilhado pelos detectores de faixa horizontal (barra principal
 * e barra de progresso). Público porque é Injetado nos construtores dos dois
 * detectores — a alternativa (internal) só criaria atrito de visibilidade.
 */
class BandScanner(private val config: VisionConfig) {

    /** Uma faixa horizontal candidata, em coordenadas de CÉLULA da amostra. */
    data class Band(
        val topCell: Int,
        val bottomCell: Int,
        val leftCell: Int,
        val rightCell: Int,
        /** Fração de células estruturadas dentro da caixa (0..1). */
        val fill: Float,
        /** Fração mínima linha-a-linha da faixa (robustez vertical). */
        val rowFill: Float,
    ) {
        val heightCells: Int get() = bottomCell - topCell
        val widthCells: Int get() = rightCell - leftCell
    }

    private var maskEpoch = Long.MIN_VALUE
    private var structured = BooleanArray(0)
    private var rowFill = FloatArray(0)
    private var columnCount = IntArray(0)
    private var filledColumns = BooleanArray(0)

    /** Limiar de contraste derivado da cena (absoluto vs. ruído do fundo). */
    fun contrastThreshold(sample: RoiSample): Float =
        maxOf(config.minAbsoluteContrast, config.contrastSpreadFactor * sample.backgroundSpread)

    /**
     * Constrói a máscara estrutural só UMA vez por frame, mesmo que barra
     * principal e barra de progresso peçam a mesma coisa (§40: nada de processar
     * a mesma ROI duas vezes).
     *
     * CORREÇÃO DE DEFEITO (Fase 7): a versão inicial usava o `timestampNanos`
     * como chave do cache. Dois frames DIFERENTES podem carregar o mesmo
     * timestamp (fonte de replay, frame repetido, duas cenas no mesmo teste) e a
     * máscara do frame anterior era reaproveitada — gerando detecção fantasma.
     * A chave agora é uma ÉPOCA explícita, incrementada pelo analisador a cada
     * frame analisado: nunca colide por coincidência de tempo.
     */
    fun ensureMask(sample: RoiSample, threshold: Float, epoch: Long): Boolean {
        if (maskEpoch == epoch) return true
        val ok = buildStructureMask(sample, threshold)
        if (ok) maskEpoch = epoch
        return ok
    }

    /**
     * Marca as células "estruturadas" = diferentes do fundo da ROI.
     *
     * Este é o coração do requisito §5: a segmentação NÃO é "pixel branco" nem
     * "pixel laranja". É contraste local contra uma estatística robusta da
     * cena, o que funciona para barra clara, escura, branca ou alaranjada.
     */
    fun buildStructureMask(sample: RoiSample, threshold: Float): Boolean {
        val cells = sample.cellCount
        if (cells <= 0) return false
        if (structured.size < cells) {
            structured = BooleanArray(cells)
            rowFill = FloatArray(sample.height)
            columnCount = IntArray(sample.width)
        }
        val bg = sample.backgroundLuma
        var any = false
        for (i in 0 until cells) {
            val v = sample.lumaAt(i % sample.width, i / sample.width)
            if (v == RoiSample.INVALID) {
                structured[i] = false
                continue
            }
            val structuredCell = kotlin.math.abs(v - bg) >= threshold
            structured[i] = structuredCell
            if (structuredCell) any = true
        }
        return any
    }

    /**
     * Encontra todas as faixas horizontais candidatas com os portões informados.
     *
     * @param minHeightPercentOfRoi altura mínima da faixa (fração da altura da ROI)
     * @param maxHeightPercentOfRoi altura máxima
     * @param minWidthPercentOfRoi  largura mínima do trecho contínuo
     * @param minAspect             aspecto mínimo (largura/altura)
     * @param maxAspect             aspecto máximo
     */
    fun findBands(
        sample: RoiSample,
        minHeightPercentOfRoi: Float,
        maxHeightPercentOfRoi: Float,
        minWidthPercentOfRoi: Float,
        minAspect: Float,
        maxAspect: Float,
        /** Restringe a busca a um intervalo de linhas (células); default = ROI inteira. */
        rowFromCell: Int = 0,
        rowToCell: Int = sample.height,
    ): List<Band> {
        if (sample.width <= 1 || sample.height <= 1) return emptyList()
        val roiHeightPx = sample.roiBottom - sample.roiTop
        val roiWidthPx = sample.roiRight - sample.roiLeft
        val minHeightPx = minHeightPercentOfRoi * roiHeightPx
        val maxHeightPx = maxHeightPercentOfRoi * roiHeightPx
        val minWidthPx = minWidthPercentOfRoi * roiWidthPx

        // 1) fração estruturada por linha
        for (y in 0 until sample.height) {
            var count = 0
            val base = y * sample.width
            for (x in 0 until sample.width) if (structured[base + x]) count++
            rowFill[y] = count.toFloat() / sample.width
        }

        // 2) agrupa linhas consecutivas que passam no portão
        val bands = ArrayList<Band>(4)
        var y = rowFromCell.coerceIn(0, sample.height - 1)
        val limit = rowToCell.coerceIn(y + 1, sample.height)
        while (y < limit) {
            if (rowFill[y] < config.barRowFillMin) {
                y++
                continue
            }
            var top = y
            var minRowFill = rowFill[y]
            while (y < limit && rowFill[y] >= config.barRowFillMin) {
                if (rowFill[y] < minRowFill) minRowFill = rowFill[y]
                y++
            }
            val bottom = y
            val heightPx = (bottom - top) * sample.step
            if (heightPx < minHeightPx || heightPx > maxHeightPx) continue

            // 3) extensão horizontal: colunas com preenchimento vertical suficiente
            for (x in 0 until sample.width) columnCount[x] = 0
            for (yy in top until bottom) {
                val base = yy * sample.width
                for (x in 0 until sample.width) if (structured[base + x]) columnCount[x]++
            }
            val heightCells = bottom - top
            if (filledColumns.size < sample.width) filledColumns = BooleanArray(sample.width)
            for (x in 0 until sample.width) {
                filledColumns[x] = columnCount[x].toFloat() / heightCells >= config.barColumnFillMin
            }

            // Extensão horizontal COM TOLERÂNCIA A BURACOS: um marcador vertical
            // (linha do peixe, com contorno escuro) atravessa a barra e divide a
            // faixa em dois trechos. Sem ponte, o detector escolheria só metade
            // da barra — foi exatamente o que o diagnóstico da fase mostrou.
            var bestStart = -1
            var bestLen = 0
            var x = 0
            while (x < sample.width) {
                if (!filledColumns[x]) {
                    x++
                    continue
                }
                val runStart = x
                var lastFilled = x
                var scans = x
                while (scans < sample.width) {
                    if (filledColumns[scans]) {
                        lastFilled = scans
                        scans++
                        continue
                    }
                    var lookahead = scans
                    var gap = 0
                    while (lookahead < sample.width && !filledColumns[lookahead]) {
                        gap++
                        lookahead++
                    }
                    if (lookahead < sample.width && gap <= config.barGapToleranceCells) {
                        scans = lookahead
                    } else {
                        break
                    }
                }
                val len = lastFilled - runStart + 1
                if (len > bestLen) {
                    bestLen = len
                    bestStart = runStart
                }
                x = lastFilled + 1
            }
            if (bestStart < 0) continue

            val widthPx = bestLen * sample.step
            if (widthPx < minWidthPx) continue
            val aspect = if (heightPx <= 0f) 0f else widthPx.toFloat() / heightPx.toFloat()
            if (aspect < minAspect || aspect > maxAspect) continue

            // 4) densidade real dentro da caixa escolhida
            var inside = 0
            for (yy in top until bottom) {
                val base = yy * sample.width
                for (xx in bestStart until bestStart + bestLen) if (structured[base + xx]) inside++
            }
            val boxArea = bestLen * heightCells
            val fill = if (boxArea == 0) 0f else inside.toFloat() / boxArea

            bands.add(
                Band(
                    topCell = top,
                    bottomCell = bottom,
                    leftCell = bestStart,
                    rightCell = bestStart + bestLen,
                    fill = fill,
                    rowFill = minRowFill,
                ),
            )
        }
        return bands
    }

    /** Célula estruturada (para os detectores verificarem detalhes internos). */
    fun isStructured(sample: RoiSample, cellX: Int, cellY: Int): Boolean {
        if (cellX < 0 || cellY < 0 || cellX >= sample.width || cellY >= sample.height) return false
        return structured[cellY * sample.width + cellX]
    }

    /**
     * Evidência AUXILIAR dos marcadores triangulares das extremidades (§9):
     * verifica se há contraste vertical imediatamente ANTES do início e DEPOIS
     * do fim do trecho contínuo — nos dois lados. Nunca é obrigatório.
     */
    fun endMarkerEvidence(sample: RoiSample, band: Band, threshold: Float): Boolean {
        val interior = interiorMeanLuma(sample, band)
        if (interior.isNaN()) return false
        val leftOk = columnDiffersFromInterior(sample, band.leftCell, band, threshold, interior) ||
            columnDiffersFromInterior(sample, band.leftCell - 1, band, threshold, interior)
        val rightOk = columnDiffersFromInterior(sample, band.rightCell - 1, band, threshold, interior) ||
            columnDiffersFromInterior(sample, band.rightCell, band, threshold, interior)
        return leftOk && rightOk
    }

    private fun interiorMeanLuma(sample: RoiSample, band: Band): Float {
        var sum = 0f
        var n = 0
        for (y in band.topCell until band.bottomCell) {
            for (x in band.leftCell until band.rightCell) {
                val v = sample.lumaAt(x, y)
                if (v == RoiSample.INVALID) continue
                sum += v
                n++
            }
        }
        return if (n == 0) Float.NaN else sum / n
    }

    /**
     * Marcador de extremidade = coluna que se DISTINGUE do interior da faixa
     * (mais clara/escura que o trilho) e também do fundo da cena. Exigir as duas
     * coisas evita que o simples contorno da barra seja contado como marcador.
     */
    private fun columnDiffersFromInterior(
        sample: RoiSample,
        cellX: Int,
        band: Band,
        threshold: Float,
        interiorMean: Float,
    ): Boolean {
        if (cellX < 0 || cellX >= sample.width) return false
        var differing = 0
        var rows = 0
        for (y in band.topCell until band.bottomCell) {
            val v = sample.lumaAt(cellX, y)
            if (v == RoiSample.INVALID) continue
            rows++
            val fromInterior = kotlin.math.abs(v - interiorMean) >= threshold * 0.5f
            val fromBackground = kotlin.math.abs(v - sample.backgroundLuma) >= threshold * 0.75f
            if (fromInterior && fromBackground) differing++
        }
        if (rows == 0) return false
        return differing.toFloat() / rows >= 0.5f
    }
}
