package com.fischvision.macro.vision.outcome

import com.fischvision.macro.vision.RoiSample

/**
 * Infraestrutura de SUCCESS/FAILED da Fase 7 (§33) — SEM OCR.
 *
 * A ordem de prioridade definida na especificação é respeitada:
 *
 *  1. MUDANÇA DA UI — [UiChangeTracker] mede a variação da cena da ROI entre
 *     frames (estatística de luminância + densidade de bordas). Uma mudança
 *     grande enquanto o minigame estava ativo é o primeiro sinal;
 *  2. DESAPARECIMENTO DA MAIN_BAR — sinal principal: a barra estava rastreada e
 *     deixa de existir;
 *  3. MUDANÇA DA REGIÃO DO MINIGAME — a própria ROI muda de "assinatura";
 *  4. ELEMENTOS DE RESULTADO — aparecimento de blocos claros grandes na região
 *     onde a barra estava (tela de recompensa/"caught!"), medido por contraste;
 *  5. OCR — NÃO implementado nesta fase, e nenhuma biblioteca pesada foi
 *     adicionada por causa disso.
 *
 * IMPORTANTE: este detector NÃO declara sucesso por "perdeu o tracking". Uma
 * perda de poucos frames é TRACK_LOST (§18), não fim de minigame: só a perda
 * SUSTENTADA conta, e o resultado sai como CANDIDATO com confidence explícita.
 * Nenhum input depende disto nesta fase (INPUT = DISABLED).
 */
class MinigameOutcomeDetector(
    /** Frames mínimos de ausência da barra para considerar fim de minigame. */
    private val minAbsentFrames: Int = 10,
    /** Limiar de mudança de UI (0..1) para o sinal "cena mudou". */
    private val uiChangeThreshold: Float = 0.35f,
    /** Confidence mínima para publicar um candidato. */
    private val minConfidence: Float = 0.45f,
) {

    enum class Signal { NONE, SUCCESS_CANDIDATE, FAILED_CANDIDATE, UNKNOWN }

    data class Outcome(
        val signal: Signal,
        val confidence: Float,
        val barAbsentFrames: Int,
        val uiChange: Float,
        val resultElements: Float,
        val reason: String,
    ) {
        val isCandidate: Boolean
            get() = signal == Signal.SUCCESS_CANDIDATE || signal == Signal.FAILED_CANDIDATE
    }

    private val uiChange = UiChangeTracker()
    private var absentFrames = 0
    private var lastProgressFill: Float? = null
    private var wasTracking = false

    /**
     * @param barPresent barra principal detectada neste frame
     * @param zonePresent zona detectada neste frame
     * @param progressFill fração preenchida da barra de progresso (se conhecida)
     * @param sample amostra da ROI do frame (para mudança de UI / elementos)
     */
    fun observe(
        barPresent: Boolean,
        zonePresent: Boolean,
        progressFill: Float?,
        sample: RoiSample?,
        roiPresent: Boolean = true,
    ): Outcome {
        val change = sample?.let { uiChange.update(it) } ?: 0f
        val elements = sample?.let { resultElementsScore(it) } ?: 0f

        if (barPresent) {
            absentFrames = 0
            wasTracking = true
            progressFill?.let { lastProgressFill = it }
            return Outcome(Signal.NONE, 0f, 0, change, elements, "minigame ativo")
        }

        if (!wasTracking) {
            return Outcome(Signal.NONE, 0f, 0, change, elements, "nenhum minigame observado ainda")
        }

        absentFrames++
        if (absentFrames < minAbsentFrames) {
            return Outcome(Signal.NONE, 0f, absentFrames, change, elements, "ausência curta (tolera perda de tracking)")
        }

        // A partir daqui temos fim de minigame — SUCCESS × FAILED sem OCR.
        val fill = lastProgressFill
        val uiScore = (change / uiChangeThreshold.coerceAtLeast(0.01f)).coerceIn(0f, 1f)
        val fillEvidence = when {
            fill == null -> 0f
            fill >= 0.85f -> 1f
            fill <= 0.15f -> 0f
            else -> (fill - 0.15f) / 0.7f
        }
        val changeEvidence = when {
            fill == null -> uiScore * 0.5f
            else -> (fill - 0.15f).coerceAtLeast(0f) / 0.85f
        }
        val confidence = (fillEvidence * 0.45f + changeEvidence * 0.35f + elements * 0.20f).coerceIn(0f, 1f)

        // Sem evidência de progresso e sem mudança de UI: não há como decidir.
        if (confidence < minConfidence) {
            return Outcome(Signal.UNKNOWN, confidence, absentFrames, change, elements, "fim sem sinal de resultado confiável")
        }
        // Não presumir polaridade: preenchimento alto ⇒ SUCCESS; esvaziado ⇒ FAILED.
        val signal = if (fillEvidence >= 0.5f) Signal.SUCCESS_CANDIDATE else Signal.FAILED_CANDIDATE
        return Outcome(
            signal = signal,
            confidence = confidence,
            barAbsentFrames = absentFrames,
            uiChange = change,
            resultElements = elements,
            reason = if (signal == Signal.SUCCESS_CANDIDATE) {
                "barra ausente + progresso preenchido"
            } else {
                "barra ausente + progresso não concluído"
            },
        )
    }

    fun reset() {
        uiChange.reset()
        absentFrames = 0
        lastProgressFill = null
        wasTracking = false
    }

    /**
     * "Elementos de resultado" (§33, item 4): proporção de células de alto
     * contraste na metade inferior da ROI — telas de resultado/recompensa tendem
     * a ser blocos claros onde antes estava a barra.
     */
    private fun resultElementsScore(sample: RoiSample): Float {
        if (sample.height < 4 || sample.width < 4) return 0f
        val from = (sample.height * 0.35f).toInt()
        var bright = 0
        var total = 0
        for (y in from until sample.height) {
            for (x in 0 until sample.width) {
                val v = sample.lumaAt(x, y)
                if (v == RoiSample.INVALID) continue
                total++
                if (v >= sample.backgroundLuma + 60f) bright++
            }
        }
        if (total == 0) return 0f
        return (bright.toFloat() / total * 3f).coerceIn(0f, 1f)
    }
}

/**
 * Mede "a UI mudou?" por assinatura estatística da ROI:
 * média de luminância + densidade de bordas (gradiente horizontal médio).
 * Robusto a elementos animados pequenos porque usa a ROI inteira.
 */
class UiChangeTracker(private val smoothing: Float = 0.5f) {
    private var meanLuma = Float.NaN
    private var edgeDensity = Float.NaN

    fun update(sample: RoiSample): Float {
        if (sample.cellCount <= 0) return 0f
        var sum = 0f
        var edges = 0f
        var n = 0
        for (y in 0 until sample.height) {
            var previous = RoiSample.INVALID
            for (x in 0 until sample.width) {
                val v = sample.lumaAt(x, y)
                if (v == RoiSample.INVALID) continue
                sum += v
                n++
                if (previous != RoiSample.INVALID && kotlin.math.abs(v - previous) >= 24) edges++
                previous = v
            }
        }
        if (n == 0) return 0f
        val newMean = sum / n
        val newEdges = edges / n

        if (meanLuma.isNaN() || edgeDensity.isNaN()) {
            meanLuma = newMean
            edgeDensity = newEdges
            return 0f
        }
        val dMean = kotlin.math.abs(newMean - meanLuma)
        val dEdge = kotlin.math.abs(newEdges - edgeDensity)
        meanLuma = (1f - smoothing) * meanLuma + smoothing * newMean
        edgeDensity = (1f - smoothing) * edgeDensity + smoothing * newEdges
        // Luminância: 60 níveis ≈ "a cena virou outra"; bordas: 0.15 de densidade.
        return ((dMean / 60f) * 0.7f + (dEdge / 0.15f) * 0.3f).coerceIn(0f, 1f)
    }

    fun reset() {
        meanLuma = Float.NaN
        edgeDensity = Float.NaN
    }
}
