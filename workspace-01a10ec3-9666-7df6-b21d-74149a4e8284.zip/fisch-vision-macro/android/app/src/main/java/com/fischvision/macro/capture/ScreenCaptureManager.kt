package com.fischvision.macro.capture

import android.content.Context
import android.graphics.PixelFormat as AndroidPixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import android.view.WindowManager
import com.fischvision.macro.settings.MacroSettings
import com.fischvision.macro.debug.DebugLogger
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.channels.SendChannel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow

/**
 * Falha tipada de captura. O [FrameSource] falha o Flow com esta exceção em
 * encerramentos anormais — nunca engole erro (contrato da Fase 1).
 */
class CaptureException(
    val type: Type,
    message: String,
    cause: Throwable? = null,
) : Exception(message, cause) {
    enum class Type {
        PROJECTION_UNAVAILABLE,     // token revogado/expirado
        VIRTUAL_DISPLAY_FAILED,
        IMAGE_READER_FAILED,
        SECURITY_ERROR,
        ILLEGAL_STATE,
    }
}

/**
 * Payload com acesso a pixels RGBA_8888. O contrato [FramePayload] da Fase 1
 * permanece opaco por design; ESTA interface é a extensão concreta usada pela
 * visão (Fase 3) sem amarrar o contrato ao android.media.Image.
 */
interface RgbaFramePayload : FramePayload {
    /** Cor ARGB empacotada do pixel (x,y) ou null se fora do buffer. */
    fun argbAt(x: Int, y: Int): Int?
    val pixelWidth: Int
    val pixelHeight: Int
}

/**
 * Payload real: envolve um [Image] do ImageReader.
 * [release] fecha o Image — idempotente e thread-safe. O consumidor
 * (macro engine) é o dono do release, conforme contrato da Fase 1.
 */
class ImageFramePayload private constructor(
    private val image: Image?,
    override val pixelWidth: Int,
    override val pixelHeight: Int,
    private val rowStride: Int,
    private val pixelStride: Int,
) : RgbaFramePayload {

    @Volatile
    private var released = false

    companion object {
        val EMPTY = ImageFramePayload(null, 0, 0, 0, 0)

        fun of(image: Image): ImageFramePayload {
            val plane = image.planes[0]
            return ImageFramePayload(
                image = image,
                pixelWidth = image.width,
                pixelHeight = image.height,
                rowStride = plane.rowStride,
                pixelStride = plane.pixelStride,
            )
        }
    }

    override fun argbAt(x: Int, y: Int): Int? {
        val img = image ?: return null
        if (released || x < 0 || y < 0 || x >= pixelWidth || y >= pixelHeight) return null
        return try {
            val buf = img.planes[0].buffer
            val base = y * rowStride + x * pixelStride
            // RGBA_8888: ordem R,G,B,A por pixel.
            val r = buf.get(base).toInt() and 0xFF
            val g = buf.get(base + 1).toInt() and 0xFF
            val b = buf.get(base + 2).toInt() and 0xFF
            val a = buf.get(base + 3).toInt() and 0xFF
            (a shl 24) or (r shl 16) or (g shl 8) or b
        } catch (e: Exception) {
            // buffer realocado/inválido: trata como pixel ausente, nunca crasha a visão
            null
        }
    }

    override fun sizeBytes(): Long = pixelWidth.toLong() * pixelHeight * 4L

    @Synchronized
    override fun release() {
        if (!released) {
            released = true
            try {
                image?.close()
            } catch (e: Exception) {
                DebugLogger.w(DebugLogger.Category.CAPTURE, "falha ao fechar Image", e)
            }
        }
    }

    val isReleased: Boolean get() = released
}

/** Erros mapeados da tentativa de iniciar captura. */
sealed interface CaptureStartError {
    val message: String
    data class ProjectionDenied(override val message: String) : CaptureStartError
    data class Failure(override val message: String, val cause: Throwable? = null) : CaptureStartError
}

/**
 * Métricas de captura — puro Kotlin (unit-testável sem device).
 */
class CaptureMetrics {
    private val startedFrames = AtomicLong(0)
    private val droppedInvalid = AtomicLong(0)
    private val windowNanos = AtomicLong(0)
    private val windowCount = AtomicLong(0)

    fun onFrame(nowNanos: Long) {
        startedFrames.incrementAndGet()
        val w = windowNanos.get()
        if (w == 0L || nowNanos - w >= 1_000_000_000L) {
            windowNanos.set(nowNanos)
            windowCount.set(1)
        } else {
            windowCount.incrementAndGet()
        }
    }

    fun onInvalidFrame() = droppedInvalid.incrementAndGet()

    data class Snapshot(
        val framesPublished: Long,
        val framesInvalidDropped: Long,
        val fpsInCurrentWindow: Long,
    )

    fun snapshot(): Snapshot = Snapshot(
        framesPublished = startedFrames.get(),
        framesInvalidDropped = droppedInvalid.get(),
        fpsInCurrentWindow = windowCount.get(),
    )
}

/**
 * FrameSource real baseado em MediaProjection — Fase 2.
 *
 * Política de backpressure: capacidade fixa de 2 frames no canal interno com
 * DROP_OLDEST (latest-wins), espelhando o FrameBus. acquireLatestImage()
 * descarta frames velhos na fonte: fila nunca cresce.
 *
 * Orientação: suporta 0/90/180/270 via [DisplayManager.DisplayListener];
 * ao trocar rotação, o VirtualDisplay+ImageReader são recriados com as
 * dimensões transpostas e os frames carregam rotationDegrees real.
 *
 * Erros: projeção parada, falha de VirtualDisplay/ImageReader, SecurityException
 * e OOM falham o Flow com [CaptureException] tipada.
 *
 * CICLO DE PARADA (Fase 7, §29) — corrigido nesta fase:
 *  - [MediaProjection.Callback.onStop] é o ponto ÚNICO de encerramento: libera
 *    VirtualDisplay + ImageReader, FECHA o canal de frames (o Flow completa,
 *    o consumidor não fica pendurado) e publica [CaptureEvent.ProjectionStopped];
 *  - a projeção é zerada antes, para que [releaseAll] não chame `stop()` de novo
 *    dentro do próprio callback (o que geraria recursão/erro de estado);
 *  - quem decide liberar o dedo virtual é a FSM, ao receber o evento.
 *
 * @status IMPLEMENTED (fonte real) / NÃO TESTADO EM DISPOSITIVO (BLOCKED env).
 */
class MediaProjectionFrameSource(
    private val appContext: Context,
    private val resultCode: Int,
    private val consentData: android.content.Intent,
    private val settings: MacroSettings = MacroSettings.DEFAULT,
) : FrameSource, CaptureEventSource {

    private val _captureEvents = MutableSharedFlow<CaptureEvent>(
        replay = 0,
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )

    /** Eventos de ciclo de vida (parada da projeção, falhas de sessão). */
    val events: SharedFlow<CaptureEvent> = _captureEvents.asSharedFlow()

    /** Canal do fluxo de frames em curso — fechado por [onProjectionStopped]. */
    @Volatile
    private var frameChannel: SendChannel<Frame>? = null

    /** Encerramento já em andamento (idempotência do callback da projeção). */
    @Volatile
    private var stopping = false

    @Volatile
    private var projection: MediaProjection? = null

    @Volatile
    private var virtualDisplay: VirtualDisplay? = null

    @Volatile
    private var imageReader: ImageReader? = null

    @Volatile
    private var handlerThread: HandlerThread? = null

    @Volatile
    private var displayManager: DisplayManager? = null

    @Volatile
    private var displayListener: DisplayManager.DisplayListener? = null

    /** -1 = ainda não medido; usado para detectar troca de rotação. */
    @Volatile
    private var currentRotation: Int = -1

    val metrics = CaptureMetrics()

    override suspend fun start() {
        if (resultCode != android.app.Activity.RESULT_OK) {
            throw CaptureException(
                CaptureException.Type.PROJECTION_UNAVAILABLE,
                "consentimento de captura ausente/negado (resultCode=$resultCode)",
            )
        }
        try {
            val mgr = appContext.getSystemService(MediaProjectionManager::class.java)
                ?: throw CaptureException(
                    CaptureException.Type.PROJECTION_UNAVAILABLE,
                    "MediaProjectionManager indisponível",
                )
            val mp = mgr.getMediaProjection(resultCode, consentData)
                ?: throw CaptureException(
                    CaptureException.Type.PROJECTION_UNAVAILABLE,
                    "getMediaProjection retornou null (token inválido/expirado)",
                )
            projection = mp

            val thread = HandlerThread("fvm-capture").apply { start() }
            handlerThread = thread

            // Android 14+: callback deve existir antes de usar a projeção.
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    DebugLogger.i(DebugLogger.Category.CAPTURE, "MediaProjection.onStop — encerrando captura")
                    onProjectionStopped()
                }
            }, Handler(thread.looper))

            stopping = false
            currentRotation = readRotation()
            createPipeline(mp, Handler(thread.looper), currentRotation)
            watchRotation(mp, Handler(thread.looper))
        } catch (e: SecurityException) {
            releaseAll()
            throw CaptureException(CaptureException.Type.SECURITY_ERROR, "permissão revogada", e)
        } catch (e: IllegalStateException) {
            releaseAll()
            throw CaptureException(CaptureException.Type.ILLEGAL_STATE, "estado ilegal ao iniciar", e)
        }
    }

    private fun createPipeline(mp: MediaProjection, handler: Handler, rotationDegrees: Int) {
        val landscape = rotationDegrees == Surface.ROTATION_90 || rotationDegrees == Surface.ROTATION_270
        val width = if (landscape) settings.captureWidth else settings.captureHeight
        val height = if (landscape) settings.captureHeight else settings.captureWidth

        val reader = try {
            ImageReader.newInstance(width, height, AndroidPixelFormat.RGBA_8888, MAX_IMAGES)
        } catch (oom: OutOfMemoryError) {
            throw CaptureException(CaptureException.Type.IMAGE_READER_FAILED, "OOM criando ImageReader", oom)
        }
        imageReader = reader

        val vd = try {
            mp.createVirtualDisplay(
                "fvm-capture",
                width,
                height,
                appContext.resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface,
                null,
                handler,
            )
        } catch (e: Exception) {
            reader.close()
            throw CaptureException(CaptureException.Type.VIRTUAL_DISPLAY_FAILED, "createVirtualDisplay falhou", e)
        } ?: run {
            reader.close()
            throw CaptureException(CaptureException.Type.VIRTUAL_DISPLAY_FAILED, "VirtualDisplay nulo")
        }
        virtualDisplay = vd
    }

    private fun watchRotation(mp: MediaProjection, handler: Handler) {
        if (Build.VERSION.SDK_INT < 35) return // DisplayListener direto na criação não é obrigatório aqui
        val dm = appContext.getSystemService(DisplayManager::class.java) ?: return
        displayManager = dm
        val listener = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) = Unit
            override fun onDisplayRemoved(displayId: Int) = Unit
            override fun onDisplayChanged(displayId: Int) {
                val r = readRotation()
                if (r != currentRotation) {
                    currentRotation = r
                    DebugLogger.i(DebugLogger.Category.CAPTURE, "rotação -> $r; recriando pipeline")
                    try {
                        virtualDisplay?.release()
                        imageReader?.close()
                        createPipeline(mp, handler, r)
                    } catch (e: CaptureException) {
                        DebugLogger.e(DebugLogger.Category.CAPTURE, "falha ao recriar pipeline", e)
                    }
                }
            }
        }
        displayListener = listener
        try {
            dm.registerDisplayListener(listener, handler)
        } catch (e: Exception) {
            DebugLogger.w(DebugLogger.Category.CAPTURE, "registerDisplayListener falhou", e)
        }
    }

    private fun readRotation(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            appContext.display?.rotation ?: Surface.ROTATION_0
        } else {
            @Suppress("DEPRECATION")
            (appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager)
                .defaultDisplay.rotation
        }
    }

    override fun frames(): Flow<Frame> = callbackFlow {
        // Capacidade 2 + DROP_OLDEST: latest-wins desde a fonte; fila nunca cresce.
        // NOTA (Fase 7): `callbackFlow` do kotlinx-coroutines 1.10 NÃO possui os
        // parâmetros `capacity`/`onBufferOverflow` — a política de buffer entra
        // pelo operador `.buffer(...)` aplicado ao fluxo retornado (abaixo).
        val reader = imageReader
            ?: throw CaptureException(CaptureException.Type.ILLEGAL_STATE, "start() não foi chamado")

        val listener = ImageReader.OnImageAvailableListener { r ->
            val image = try {
                r.acquireLatestImage()
            } catch (e: Exception) {
                metrics.onInvalidFrame()
                null
            } ?: return@OnImageAvailableListener

            if (image.planes.isEmpty()) {
                metrics.onInvalidFrame()
                image.close()
                return@OnImageAvailableListener
            }
            val frame = Frame(
                timestampNanos = image.timestamp,
                width = image.width,
                height = image.height,
                rotationDegrees = currentRotation,
                pixelFormat = PixelFormat.RGBA_8888,
                payload = ImageFramePayload.of(image),
            )
            metrics.onFrame(frame.timestampNanos)
            trySend(frame)
        }

        reader.setOnImageAvailableListener(listener, handlerThread?.let { Handler(it.looper) })
        frameChannel = channel

        awaitClose {
            frameChannel = null
            try {
                reader.setOnImageAvailableListener(null, null)
            } catch (_: Exception) {
                // reader já encerrado: encerramento idempotente por design
            }
        }
    }.buffer(capacity = 2, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    override suspend fun stop() {
        releaseAll()
    }

    fun isCapturing(): Boolean = virtualDisplay != null

    private fun releaseAll() {
        disposeCapturePipeline()
        try {
            projection?.stop()
        } catch (_: Exception) {
            // projeção já encerrada: parada idempotente por design
        }
        projection = null
    }

    /**
     * Libera display/reader/thread mas NÃO toca na projeção — usado tanto por
     * [releaseAll] quanto pelo callback de parada (onde chamar `stop()` de novo
     * seria incorreto, pois a projeção já está parando).
     */
    private fun disposeCapturePipeline() {
        try {
            displayListener?.let { displayManager?.unregisterDisplayListener(it) }
        } catch (_: Exception) {
        }
        displayListener = null
        displayManager = null
        try {
            virtualDisplay?.release()
        } catch (_: Exception) {
        }
        virtualDisplay = null
        try {
            imageReader?.close()
        } catch (_: Exception) {
        }
        imageReader = null
        handlerThread?.quitSafely()
        handlerThread = null
    }

    /**
     * CICLO DE PARADA (§29): onStop → libera pipeline → fecha o fluxo de frames
     * → publica ProjectionStopped. Idempotente.
     */
    private fun onProjectionStopped() {
        if (stopping) return
        stopping = true
        projection = null
        disposeCapturePipeline()
        frameChannel?.close()
        frameChannel = null
        _captureEvents.tryEmit(CaptureEvent.ProjectionStopped)
    }

    override fun captureEvents(): Flow<CaptureEvent> = events

    private companion object {
        const val MAX_IMAGES = 2
    }
}
