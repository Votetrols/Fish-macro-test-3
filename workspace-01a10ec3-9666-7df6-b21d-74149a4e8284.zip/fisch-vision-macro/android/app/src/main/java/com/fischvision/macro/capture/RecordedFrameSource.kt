package com.fischvision.macro.capture

import java.io.File
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Payload RGBA a partir de pixels já decodificados (arquivo/imagem).
 *
 * Mesmo contrato de [RgbaFramePayload] usado pela captura real — é isto que
 * permite rodar o MESMO pipeline de visão sobre frames gravados (§36).
 */
class IntArrayRgbaPayload(
    private val pixels: IntArray,
    override val pixelWidth: Int,
    override val pixelHeight: Int,
) : RgbaFramePayload {

    init {
        require(pixels.size >= pixelWidth * pixelHeight) { "buffer menor que ${pixelWidth}x$pixelHeight" }
    }

    @Volatile
    private var released = false

    override fun argbAt(x: Int, y: Int): Int? {
        if (released || x < 0 || y < 0 || x >= pixelWidth || y >= pixelHeight) return null
        return pixels[y * pixelWidth + x]
    }

    override fun sizeBytes(): Long = pixelWidth.toLong() * pixelHeight * 4L

    override fun release() {
        released = true
    }
}

/** Imagem decodificada em memória (independente de Android). */
data class DecodedFrame(val pixels: IntArray, val width: Int, val height: Int)

/** Tradutor arquivo → pixels. Android usa Bitmap; testes JVM usam ImageIO. */
interface RecordedFrameDecoder {
    fun decode(file: File): DecodedFrame?
}

/**
 * Fonte de frames GRAVADOS (§36) — o mesmo pipeline de visão roda sem Roblox.
 *
 * Serve para três coisas concretas:
 *  1. desenvolver e validar detector/tracker antes de qualquer automação;
 *  2. reproduzir um problema relatado com os frames exatos que o causaram;
 *  3. rodar o harness de validação (`RecordedFrameReplayTest`) sobre frames
 *     extraídos do vídeo de referência.
 *
 * O decodificador entra por injeção: em produção usa-se [AndroidBitmapDecoder]
 * (BitmapFactory); nos testes JVM, um decodificador ImageIO. Nenhuma biblioteca
 * nova foi adicionada para isto.
 */
class RecordedFrameSource(
    private val directory: File,
    private val decoder: RecordedFrameDecoder,
    /** Cadência de reprodução (frames por segundo) usada só para o delay. */
    private val playbackFps: Int = 30,
    /** Repetir a sequência ao terminar (útil para deixar o overlay "vivo"). */
    private val loop: Boolean = false,
    private val onFrameIssued: (File) -> Unit = {},
) : FrameSource {

    @Volatile
    private var stopped = false

    var frameFiles: List<File> = emptyList()
        private set

    override suspend fun start() {
        frameFiles = directory.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() in SUPPORTED_EXTENSIONS }
            ?.sortedBy { it.name }
            ?: emptyList()
    }

    override fun frames(): Flow<Frame> = flow {
        val delayMillis = (1_000L / playbackFps.coerceAtLeast(1)).coerceAtLeast(1L)
        do {
            for ((index, file) in frameFiles.withIndex()) {
                if (stopped) return@flow
                val decoded = decoder.decode(file) ?: continue
                onFrameIssued(file)
                val timestampNanos = index * (1_000_000_000L / playbackFps.coerceAtLeast(1))
                emit(
                    Frame(
                        timestampNanos = timestampNanos,
                        width = decoded.width,
                        height = decoded.height,
                        rotationDegrees = 0,
                        pixelFormat = PixelFormat.RGBA_8888,
                        payload = IntArrayRgbaPayload(decoded.pixels, decoded.width, decoded.height),
                    ),
                )
                delay(delayMillis)
            }
        } while (loop && !stopped)
    }

    override suspend fun stop() {
        stopped = true
    }

    private companion object {
        val SUPPORTED_EXTENSIONS = setOf("png", "jpg", "jpeg", "webp", "bmp")
    }
}
