package com.fischvision.macro.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import com.fischvision.macro.debug.DebugLogger
import com.fischvision.macro.debug.VisionDebugSnapshot

/**
 * Overlay de calibração da Fase 7 (§20/§25) — OBRIGATÓRIO nesta fase.
 *
 * Decisões de segurança do overlay:
 *  - DUAS janelas: uma de desenho em tela cheia com FLAG_NOT_TOUCHABLE (nunca
 *    rouba toque do jogo ou do usuário) e uma pequena faixa de controle com o
 *    botão de PARADA, sempre acessível (regra de fail-safe da arquitetura);
 *  - exige SYSTEM_ALERT_WINDOW; sem permissão, `show()` registra e retorna sem
 *    lançar — o pipeline de visão continua funcionando, apenas sem desenho;
 *  - `render(snapshot)` é barato: só atualiza a view imediatamente invalidada;
 *  - nenhum estado de decisão vive aqui: o overlay OBSERVA.
 *
 * Implementa [OverlayManager] (contrato existente desde a Fase 1/6) e
 * adiciona [render] — nenhum contrato anterior foi alterado.
 */
class VisionDebugOverlay(
    private val appContext: Context,
    private val callbacks: ControlCallbacks? = null,
) : OverlayManager {

    interface ControlCallbacks {
        fun onStop()
        fun onToggleVisuals(): Boolean
    }

    private var windowManager: WindowManager? = null
    private var debugView: DebugOverlayView? = null
    private var controlsView: LinearLayout? = null
    private var visualsEnabled = true

    override val isShowing: Boolean get() = debugView != null

    override fun show() {
        if (debugView != null) return
        if (!Settings.canDrawOverlays(appContext)) {
            DebugLogger.w(
                DebugLogger.Category.SERVICE,
                "overlay de calibração indisponível: SYSTEM_ALERT_WINDOW não concedida (visão segue ativa)",
            )
            return
        }
        val wm = appContext.getSystemService(WindowManager::class.java) ?: run {
            DebugLogger.e(DebugLogger.Category.SERVICE, "WindowManager indisponível")
            return
        }
        windowManager = wm

        val view = DebugOverlayView(appContext)
        val visualsParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // NUNCA intercepta toque: o jogo continua jogável e o usuário
            // consegue parar o macro pelo chip de controle.
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START }

        try {
            wm.addView(view, visualsParams)
            debugView = view
        } catch (e: Exception) {
            DebugLogger.e(DebugLogger.Category.SERVICE, "addView do overlay de debug falhou", e)
            debugView = null
            return
        }

        callbacks?.let { cb ->
            val row = LinearLayout(appContext).apply { setBackgroundColor(0xCC04070E.toInt()) }
            row.addView(
                Button(appContext).apply {
                    text = "■ STOP"
                    textSize = 11f
                    typeface = Typeface.MONOSPACE
                    setOnClickListener { cb.onStop() }
                },
            )
            row.addView(
                Button(appContext).apply {
                    text = "◐ VIEW"
                    textSize = 11f
                    typeface = Typeface.MONOSPACE
                    setOnClickListener {
                        visualsEnabled = cb.onToggleVisuals()
                        debugView?.visibility = if (visualsEnabled) android.view.View.VISIBLE else android.view.View.INVISIBLE
                    }
                },
            )
            val controlsParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = 12
                y = 12
            }
            try {
                wm.addView(row, controlsParams)
                controlsView = row
            } catch (e: Exception) {
                DebugLogger.w(DebugLogger.Category.SERVICE, "chip de controle do overlay falhou", e)
            }
        }
    }

    /** Atualiza o overlay com o snapshot do frame (chamado a cada frame analisado). */
    fun render(snapshot: VisionDebugSnapshot) {
        val view = debugView ?: return
        view.snapshot = snapshot
        view.invalidate()
    }

    override fun update(state: OverlayState) {
        // O painel da Fase 6 (status curto) não é usado aqui: o snapshot de visão
        // é mais informativo. Mantido por compatibilidade com o contrato.
    }

    override fun hide() {
        val wm = windowManager
        controlsView?.let { controls ->
            try {
                wm?.removeView(controls)
            } catch (e: Exception) {
                DebugLogger.w(DebugLogger.Category.SERVICE, "removeView do chip falhou", e)
            }
        }
        controlsView = null
        debugView?.let { view ->
            try {
                wm?.removeView(view)
            } catch (e: Exception) {
                DebugLogger.w(DebugLogger.Category.SERVICE, "removeView do overlay de debug falhou", e)
            }
        }
        debugView = null
        windowManager = null
    }

    fun destroy() = hide()
}
