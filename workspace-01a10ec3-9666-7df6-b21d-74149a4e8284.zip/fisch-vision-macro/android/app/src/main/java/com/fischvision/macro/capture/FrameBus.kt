package com.fischvision.macro.capture

import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * Barramento de frames com conflação estrita — "latest wins".
 *
 * POLÍTICA DE BUFFER (regra 9 da Fase 1), definida e testável em FrameBusTest:
 *  - replay = 1 ............ um novo assinante recebe imediatamente o frame mais
 *                            recente (o motor nunca precisa esperar o próximo);
 *  - extraBufferCapacity = 1 pequena margem para um consumidor em andamento;
 *  - onBufferOverflow = DROP_OLDEST — capacidade total é 2 frames, SEMPRE.
 *    Consumidor lento pula frames intermediários em vez de acumular: é a
 *    propriedade que impede fila crescente e latência de processamento velho.
 *
 * PROPRIEDADE DO PAYLOAD (Fase 7, §30) — o barramento NÃO é dono dos pixels:
 *  - [publishShared] retém UMA referência para a janela de vida do frame e
 *    devolve a referência do frame anterior (janela = 1 frame, coerente com a
 *    conflação). Se ninguém recebeu, a referência é devolvida na hora;
 *  - consumidores leem pixels SOMENTE por [withLatestFrame], que faz
 *    retain/release em volta do bloco. Se o payload já morreu, o bloco não é
 *    executado e o retorno é `false` — nunca "use-after-release";
 *  - o consumidor principal (visão) não lê pixels do barramento: ele publica
 *    apenas para consumidores auxiliares (HUD/debug), que trabalham com o
 *    [com.fischvision.macro.debug.VisionDebugSnapshot].
 *
 * LIFECYCLE/CANCELLATION:
 *  - SharedFlow não tem "close": o ciclo de vida é o do escopo que coleta
 *    [frames]. Cancelar o Job do consumidor encerra a entrega para ele;
 *    o barramento continua válido para outros/publicações futuras.
 *  - No shutdown real (Fase 10), o MacroEngine cancela o escopo do serviço
 *    inteiro — o barramento não retém referências de Android.
 */
class FrameBus(
    replay: Int = 1,
    extraBufferCapacity: Int = 1,
) {
    private val _frames = MutableSharedFlow<Frame>(
        replay = replay,
        extraBufferCapacity = extraBufferCapacity,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )

    private val inFlight = AtomicReference<RefCountedFramePayload?>(null)

    /** Fluxo somente-leitura para consumidores (motor de visão, debug). */
    val frames: SharedFlow<Frame> = _frames.asSharedFlow()

    /** Quantidade de coletores ativos (diagnóstico/métricas, Fase 18). */
    val subscriberCount: StateFlow<Int> get() = _frames.subscriptionCount

    /** Frame mais recente sem suspensão (para o overlay/debug futuro). */
    val latest: Frame? get() = _frames.replayCache.lastOrNull()

    suspend fun publish(frame: Frame) = _frames.emit(frame)

    /** Publicação não-suspensiva; retorna false apenas em configuração incomum. */
    fun tryPublish(frame: Frame): Boolean = _frames.tryEmit(frame)

    /**
     * Publica mantendo a posse do payload durante uma janela de 1 frame (§30).
     * Use esta sobrecarga quando o consumidor puder ler pixels do barramento.
     */
    fun publishShared(frame: Frame): Boolean {
        val payload = frame.payload
        val retained = if (payload is RefCountedFramePayload && payload.retain()) payload else null
        val previous = inFlight.getAndSet(retained)
        val emitted = _frames.tryEmit(frame)
        if (!emitted) {
            inFlight.compareAndSet(retained, null)
            retained?.release()
        }
        previous?.release()
        return emitted
    }

    /**
     * Executa [block] com o frame mais recente e uma referência VIVA.
     *
     * @return true quando o bloco rodou; false quando não havia frame ou quando
     *         o payload já havia sido liberado (nesse caso o bloco NÃO roda).
     */
    fun withLatestFrame(block: (Frame) -> Unit): Boolean {
        val frame = latest ?: return false
        val payload = frame.payload
        if (payload is RefCountedFramePayload) {
            if (!payload.retain()) return false
            try {
                block(frame)
            } finally {
                payload.release()
            }
        } else {
            block(frame)
        }
        return true
    }

    /** Referências vivas do frame em trânsito (diagnóstico/teste). */
    fun inFlightReferences(): Int = inFlight.get()?.refCount ?: 0
}
