package com.fischvision.macro.debug

/**
 * Política de gravação de frames de debug (Fase 7, §24).
 *
 * DECISÕES DA FASE, explicitamente:
 *  - `DEBUG_FRAME_CAPTURE = false` por padrão — nenhum vídeo contínuo;
 *  - quando habilitado, grava APENAS frames selecionados:
 *      · frames marcados como evento (aquisição/perda/sucesso), e
 *      · 1 frame a cada [DebugCaptureConfig.everyNFrames] frames;
 *  - teto absoluto de frames por sessão ([DebugCaptureConfig.maxFramesPerSession]),
 *    para nunca encher o armazenamento;
 *  - a escrita em disco é responsabilidade do sink ([DebugFrameSink]) — esta
 *    classe só DECIDE. É por isso que ela é Kotlin puro e testável.
 */
data class DebugCaptureConfig(
    val enabled: Boolean = false,
    val everyNFrames: Int = 30,
    val maxFramesPerSession: Int = 20,
) {
    init {
        require(everyNFrames >= 1) { "everyNFrames deve ser >= 1" }
        require(maxFramesPerSession >= 0) { "maxFramesPerSession não pode ser negativo" }
    }

    companion object {
        /** Padrão da fase: desligado. */
        val DEFAULT = DebugCaptureConfig()
    }
}

/**
 * Destino dos frames de debug (produção: PNG com anotações no diretório do app).
 * Recebe também o frame original porque a evidência útil é o frame REAL.
 */
fun interface DebugFrameSink {
    fun save(snapshot: VisionDebugSnapshot, frame: com.fischvision.macro.capture.Frame)
}

class DebugCapturePolicy(private val config: DebugCaptureConfig = DebugCaptureConfig.DEFAULT) {

    var savedFrames: Int = 0
        private set

    val enabled: Boolean get() = config.enabled

    /** Decide se ESTE frame deve ser salvo. */
    fun shouldCapture(frameIndex: Long, isEvent: Boolean): Boolean {
        if (!config.enabled) return false
        if (savedFrames >= config.maxFramesPerSession) return false
        if (isEvent) return true
        return frameIndex % config.everyNFrames == 0L
    }

    /** Registra que o frame foi efetivamente salvo. */
    fun onSaved() {
        savedFrames++
    }

    fun reset() {
        savedFrames = 0
    }
}
