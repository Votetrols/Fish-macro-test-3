package com.fischvision.macro.vision

import kotlin.math.abs

/**
 * Normalização de coordenadas para o intervalo da MAIN BAR (Fase 7, §15).
 *
 *     0.0 = borda esquerda da main bar
 *     1.0 = borda direita  da main bar
 *
 * Toda a lógica de decisão usa posição relativa; pixels só aparecem no debug
 * overlay (que mostra os dois, §22).
 *
 * REGRAS DE BORDA (exigidas pela especificação):
 *  - barra inválida (left >= right) → resultado INVÁLIDO (null), não 0;
 *  - largura zero → INVÁLIDO;
 *  - NaN / infinito → INVÁLIDO;
 *  - X fora dos limites → valor CLAMPADO em [0,1], mas o chamador sabe que
 *    houve clamp (`clamped = true`) e o valor cru continua acessível.
 *
 * Kotlin puro: sem dependência de Android, sem alocação por chamada.
 */
object Normalization {

    /** Resultado de uma normalização: sempre carrega a razão da invalidez. */
    data class NormalizedX(
        /** Valor normalizado clampado em [0,1]; null quando inválido. */
        val value: Float?,
        /** Valor cru (px - left) / (right - left), sem clamp; null quando inválido. */
        val raw: Float?,
        val clamped: Boolean,
        val valid: Boolean,
        val reason: String,
    ) {
        companion object {
            fun invalid(reason: String) = NormalizedX(null, null, false, false, reason)
        }
    }

    /**
     * Normaliza `px` no intervalo [left, right] da main bar.
     *
     * @param px posição em pixels do frame de captura
     * @param left borda esquerda da main bar (px)
     * @param right borda direita da main bar (px, exclusiva)
     */
    fun x(px: Float, left: Float, right: Float): NormalizedX {
        if (!px.isFinite() || !left.isFinite() || !right.isFinite()) {
            return NormalizedX.invalid("valor não finito (NaN/inf)")
        }
        val width = right - left
        if (width <= 0f) return NormalizedX.invalid("largura da barra inválida ($width)")
        val raw = (px - left) / width
        if (!raw.isFinite()) return NormalizedX.invalid("normalização não finita")
        val clampedValue = raw.coerceIn(0f, 1f)
        return NormalizedX(
            value = clampedValue,
            raw = raw,
            clamped = raw != clampedValue,
            valid = true,
            reason = if (raw != clampedValue) "fora dos limites da barra (clampado)" else "ok",
        )
    }

    /** Conveniência: normaliza e devolve só o valor (null quando inválido). */
    fun xOrNull(px: Float, left: Float, right: Float): Float? = x(px, left, right).value

    /**
     * Relação PEIXE ↔ ZONA (Fase 7, §14).
     *
     * Margem configurável (`marginNormalized`, em unidades normalizadas) para
     * compensar ruído de detecção — NUNCA um número mágico embutido.
     */
    fun zoneRelation(
        fishNormalizedX: Float?,
        zoneNormalizedLeft: Float?,
        zoneNormalizedRight: Float?,
        marginNormalized: Float,
    ): ZoneRelation {
        if (fishNormalizedX == null || zoneNormalizedLeft == null || zoneNormalizedRight == null) {
            return ZoneRelation(null, null, null, null, insideRaw = false, insideWithMargin = false, valid = false)
        }
        if (!fishNormalizedX.isFinite() || !zoneNormalizedLeft.isFinite() || !zoneNormalizedRight.isFinite()) {
            return ZoneRelation(null, null, null, null, insideRaw = false, insideWithMargin = false, valid = false)
        }
        val left = minOf(zoneNormalizedLeft, zoneNormalizedRight)
        val right = maxOf(zoneNormalizedLeft, zoneNormalizedRight)
        val margin = marginNormalized.coerceAtLeast(0f)
        val insideRaw = fishNormalizedX >= left && fishNormalizedX <= right
        val insideWithMargin = fishNormalizedX >= (left - margin) && fishNormalizedX <= (right + margin)
        return ZoneRelation(
            fishNormalizedX = fishNormalizedX,
            zoneNormalizedLeft = left,
            zoneNormalizedRight = right,
            zoneNormalizedCenter = (left + right) / 2f,
            insideRaw = insideRaw,
            insideWithMargin = insideWithMargin,
            valid = true,
        )
    }

    data class ZoneRelation(
        val fishNormalizedX: Float?,
        val zoneNormalizedLeft: Float?,
        val zoneNormalizedRight: Float?,
        val zoneNormalizedCenter: Float?,
        /** `zoneLeft <= fishX <= zoneRight` (condição estrita da especificação). */
        val insideRaw: Boolean,
        /** Idem, com a margem configurável aplicada (critério de trabalho). */
        val insideWithMargin: Boolean,
        val valid: Boolean,
    ) {
        /** Critério efetivo publicado no debug overlay (`FISH IN ZONE: YES/NO`). */
        val inside: Boolean get() = valid && insideWithMargin
        val distanceToCenter: Float?
            get() = if (fishNormalizedX == null || zoneNormalizedCenter == null) null
            else fishNormalizedX - zoneNormalizedCenter
    }

    /** Erro relativo em unidades normalizadas: target − indicator (Fase 7, §32). */
    fun error(targetNormalizedX: Float?, indicatorNormalizedX: Float?): Float? {
        if (targetNormalizedX == null || indicatorNormalizedX == null) return null
        if (!targetNormalizedX.isFinite() || !indicatorNormalizedX.isFinite()) return null
        return targetNormalizedX - indicatorNormalizedX
    }

    /** Formatação estável para o debug overlay (3 casas, nunca "NaN"). */
    fun format(value: Float?, digits: Int = 2): String {
        if (value == null || !value.isFinite()) return "--"
        val rounded = when (digits) {
            0 -> value.toInt().toFloat()
            1 -> kotlin.math.round(value * 10f) / 10f
            2 -> kotlin.math.round(value * 100f) / 100f
            else -> kotlin.math.round(value * 1000f) / 1000f
        }
        val absValue = abs(rounded)
        val text = absValue.toString()
        return if (rounded < 0f) "-$text" else text
    }
}
