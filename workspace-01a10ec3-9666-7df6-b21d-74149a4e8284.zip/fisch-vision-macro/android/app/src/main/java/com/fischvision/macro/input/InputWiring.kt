package com.fischvision.macro.input

import com.fischvision.macro.core.MacroState
import com.fischvision.macro.settings.MacroSettings

/**
 * Montagem do contexto de segurança a partir da configuração e do estado vivo
 * (Fase 7, §26/§27/§28).
 *
 * POR QUE ISTO EXISTE: `controllerEnabled` era apenas uma variável decorativa —
 * nada no caminho de execução a consultava. Aqui a configuração é CONVERTIDA em
 * contexto de segurança avaliado a cada tentativa de comando, e o serviço usa
 * ESTA função (não um `if` solto). Assim existe um único lugar para auditar:
 *
 *     settings.controllerEnabled == false  ⇒  SEGURANÇA BLOQUEIA  ⇒  nenhum gesto
 *
 * É Kotlin puro e por isso o teste correspondente roda em JVM, sem device.
 */
object InputWiring {

    /**
     * @param foregroundPackage pacote em foreground segundo o serviço de
     *        acessibilidade; `null` = desconhecido (tratado como NÃO autorizado)
     */
    fun safetyContext(
        settings: MacroSettings,
        foregroundPackage: String?,
        trackingValid: Boolean,
        confidence: Float,
        fsmState: MacroState,
        projectionActive: Boolean,
        /** Override usado somente pelo modo de calibração do serviço. */
        calibrationMode: Boolean = settings.calibrationMode,
    ): InputSafetyContext = InputSafetyContext(
        calibrationMode = calibrationMode,
        controllerEnabled = settings.controllerEnabled,
        inputEnabled = settings.inputEnabled,
        targetAppMatches = foregroundPackage != null && foregroundPackage == settings.targetAppPackage,
        foregroundPackage = foregroundPackage,
        expectedPackage = settings.targetAppPackage,
        trackingValid = trackingValid,
        confidence = confidence,
        minConfidence = settings.minConfidence,
        fsmAllowsInput = fsmAllowsInput(fsmState),
        fsmStateName = fsmState.name,
        projectionActive = projectionActive,
    )

    /**
     * A FSM só autoriza input em CONTROLLING — estado alcançado apenas quando um
     * controlador está de fato habilitado. Na Fase 7 (calibração) isso nunca
     * acontece: a máquina para em TRACKING e o input nunca é liberado.
     */
    fun fsmAllowsInput(state: MacroState): Boolean = state == MacroState.CONTROLLING

    /**
     * Texto do HUD (`INPUT: ...`).
     *
     * Em calibração a resposta é exatamente `DISABLED` (§21) — não
     * `BLOCKED (CALIBRATION MODE)` — porque a fase define INPUT = DISABLED como
     * estado esperado, e não como anomalia.
     */
    fun hudInputState(settings: MacroSettings, decision: SafetyDecision): String = when {
        settings.calibrationMode || !settings.inputEnabled -> InputSafetyGuard.DISABLED_LABEL
        decision is SafetyDecision.Block -> "BLOCKED (${decision.reason.label})"
        else -> "ENABLED"
    }
}
