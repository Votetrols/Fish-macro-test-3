package com.fischvision.macro.input

/**
 * CAMADA CENTRAL DE SEGURANÇA DE INPUT (Fase 7, §26).
 *
 * Nenhum gesto pode sair se QUALQUER uma das condições abaixo falhar:
 *
 *   1. calibrationMode == true                       → CALIBRATION_MODE
 *   2. controllerEnabled == false                    → CONTROLLER_DISABLED
 *   3. inputEnabled == false (trava da Fase 7)        → INPUT_DISABLED
 *   4. targetApp != expectedApp (app em foreground)   → WRONG_APP
 *   5. tracking inválido                              → TRACKING_INVALID
 *   6. confidence abaixo do limite                    → LOW_CONFIDENCE
 *   7. FSM fora do estado apropriado                  → FSM_STATE
 *   8. projeção encerrada                             → PROJECTION_STOPPED
 *
 * O ponto do requisito é este: MESMO QUE ALGUM MÓDULO CHAME O CONTROLLER POR
 * ENGANO, o comando é recusado — a decisão não depende da boa vontade do
 * chamador. Por isso a guarda fica ACIMA do [AccessibilityInputController] e
 * este a consulta antes de qualquer `dispatch`.
 *
 * A guarda NÃO bloqueia `releaseAll()`: soltar o dedo virtual é sempre
 * permitido (fail-safe). Quem decide isso é o controller, não a guarda.
 *
 * Kotlin puro: sem Android, 100% testável em JVM.
 */

enum class SafetyBlockReason(val label: String) {
    CALIBRATION_MODE("CALIBRATION MODE"),
    CONTROLLER_DISABLED("CONTROLLER DISABLED"),
    INPUT_DISABLED("INPUT DISABLED"),
    WRONG_APP("WRONG APP"),
    TRACKING_INVALID("TRACKING INVALID"),
    LOW_CONFIDENCE("LOW CONFIDENCE"),
    FSM_STATE("FSM STATE"),
    PROJECTION_STOPPED("PROJECTION STOPPED"),
}

/** Contexto avaliado a cada tentativa de comando. Todos os campos são explícitos. */
data class InputSafetyContext(
    val calibrationMode: Boolean,
    val controllerEnabled: Boolean,
    /** Trava adicional da Fase 7: input desligado por configuração. */
    val inputEnabled: Boolean,
    /** true quando o app em foreground é o app alvo esperado. */
    val targetAppMatches: Boolean,
    /** null = app em foreground desconhecido (nunca tratado como "ok por omissão"). */
    val foregroundPackage: String?,
    val expectedPackage: String,
    val trackingValid: Boolean,
    val confidence: Float,
    val minConfidence: Float,
    /** true quando a FSM está em estado que permitiria input (ex.: CONTROLLING). */
    val fsmAllowsInput: Boolean,
    val fsmStateName: String,
    val projectionActive: Boolean,
)

sealed interface SafetyDecision {
    data object Allow : SafetyDecision
    data class Block(val reason: SafetyBlockReason, val detail: String) : SafetyDecision
}

class InputSafetyGuard(
    private val expectedPackage: String = DEFAULT_EXPECTED_PACKAGE,
) {
    @Volatile
    var lastDecision: SafetyDecision = SafetyDecision.Allow
        private set

    /** Avalia o contexto. A ordem das checagens é a ordem de prioridade do §26. */
    fun evaluate(context: InputSafetyContext): SafetyDecision {
        val decision = when {
            context.calibrationMode ->
                SafetyDecision.Block(SafetyBlockReason.CALIBRATION_MODE, "modo de calibração exige INPUT = OFF")

            !context.controllerEnabled ->
                SafetyDecision.Block(SafetyBlockReason.CONTROLLER_DISABLED, "controllerEnabled = false")

            !context.inputEnabled ->
                SafetyDecision.Block(SafetyBlockReason.INPUT_DISABLED, "inputEnabled = false (fase de visão)")

            !context.targetAppMatches ->
                SafetyDecision.Block(
                    SafetyBlockReason.WRONG_APP,
                    "foreground=${context.foregroundPackage ?: "desconhecido"} esperado=${context.expectedPackage}",
                )

            !context.projectionActive ->
                SafetyDecision.Block(SafetyBlockReason.PROJECTION_STOPPED, "captura encerrada")

            !context.trackingValid ->
                SafetyDecision.Block(SafetyBlockReason.TRACKING_INVALID, "tracking não está VALID/TRACKING")

            context.confidence < context.minConfidence ->
                SafetyDecision.Block(
                    SafetyBlockReason.LOW_CONFIDENCE,
                    "confidence ${context.confidence} < ${context.minConfidence}",
                )

            !context.fsmAllowsInput ->
                SafetyDecision.Block(SafetyBlockReason.FSM_STATE, "FSM em ${context.fsmStateName}")

            else -> SafetyDecision.Allow
        }
        lastDecision = decision
        return decision
    }

    /** Texto curto e estável para o HUD (`INPUT: ...`). */
    fun describe(decision: SafetyDecision): String = when (decision) {
        SafetyDecision.Allow -> "ENABLED"
        is SafetyDecision.Block -> "BLOCKED (${decision.reason.label})"
    }

    companion object {
        /** Pacote do jogo alvo — configuração, não constante escondida no gate. */
        const val DEFAULT_EXPECTED_PACKAGE = "com.roblox.client"

        /**
         * Texto do HUD quando a fase está em modo de calibração.
         * A Fase 7 publica `INPUT = DISABLED` (§21) — e é o que a guarda
         * devolve enquanto `calibrationMode`/`inputEnabled` estiverem travados.
         */
        const val DISABLED_LABEL = "DISABLED"
    }
}
