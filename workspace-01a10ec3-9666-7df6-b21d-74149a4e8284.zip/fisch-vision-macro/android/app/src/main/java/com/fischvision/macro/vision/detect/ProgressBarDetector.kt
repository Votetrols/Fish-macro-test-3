package com.fischvision.macro.vision.detect

import com.fischvision.macro.vision.IntRect
import com.fischvision.macro.vision.RoiSample
import kotlin.math.abs
import kotlin.math.max

/**
 * Detector da BARRA DE PROGRESSO (Fase 7, §16) — sempre SEPARADA da principal.
 *
 * PROGRESS_BAR ≠ MAIN_BAR. O que separa os dois é geometria e posição, não cor:
 *
 *  - POSIÇÃO: a barra de progresso só é procurada ABAIXO da main bar, a uma
 *    distância dentro de [0.10, 3.0] × altura da main bar;
 *  - PROPORÇÃO: é mais FINA (altura ∈ [3%, 60%] da altura da main bar);
 *  - LARGURA: comparável ([35%, 130%] da largura da main bar);
 *  - ASPECTO: ≥ 6 (mais alongada que a principal).
 *
 * A seleção da MAIN_BAR no analisador usa a regra complementar: quando duas
 * faixas competem, vence a mais ESPESSA — por isso a barra de progresso, fina e
 * logo abaixo, não é eleita barra principal.
 *
 * Se nada confiável for encontrado, o resultado é [ProgressBarDetection.UNKNOWN]
 * — resposta explícita, jamais falso positivo nem exceção.
 */
class ProgressBarDetector(
    private val config: VisionConfig = VisionConfig.DEFAULT,
    private val scanner: BandScanner = BandScanner(config),
) {

    fun detect(sample: RoiSample, bar: MainBarDetection?, roi: IntRect, epoch: Long = 0L): ProgressBarDetection {
        if (bar == null || !bar.valid || bar.height <= 0f) return ProgressBarDetection.UNKNOWN
        if (sample.cellCount <= 0) return ProgressBarDetection.UNKNOWN

        val threshold = scanner.contrastThreshold(sample)
        if (!scanner.ensureMask(sample, threshold, epoch)) return ProgressBarDetection.UNKNOWN

        val step = sample.step
        val barBottomCell = cellOf(bar.bottom, sample.roiTop, step)
        val barHeightCells = max(1, ((bar.bottom - bar.top) / step).toInt())
        val minGapCells = max(1, (barHeightCells * config.progressMinGapPercentOfBarHeight).toInt())
        val maxGapCells = max(minGapCells + 1, (barHeightCells * config.progressMaxGapPercentOfBarHeight).toInt())

        val fromCell = (barBottomCell + minGapCells).coerceIn(0, sample.height - 1)
        val toCell = (barBottomCell + maxGapCells).coerceIn(fromCell + 1, sample.height)
        if (toCell - fromCell < 2) return ProgressBarDetection.UNKNOWN

        // Portões de largura/altura proporcionais à MAIN BAR (distinção explícita).
        val bands = scanner.findBands(
            sample = sample,
            minHeightPercentOfRoi = (config.progressMinHeightPercentOfBar * bar.height) / roi.height,
            maxHeightPercentOfRoi = (config.progressMaxHeightPercentOfBar * bar.height) / roi.height,
            minWidthPercentOfRoi = (config.progressMinWidthPercentOfBar * bar.width) / roi.width,
            minAspect = config.progressMinAspect,
            maxAspect = 80f,
            rowFromCell = fromCell,
            rowToCell = toCell,
        )
        if (bands.isEmpty()) return ProgressBarDetection.UNKNOWN

        var best: ProgressBarDetection? = null
        for (band in bands) {
            val detection = score(sample, bar, band, threshold) ?: continue
            if (detection.confidence < config.progressMinConfidence) continue
            if (best == null || detection.confidence > best.confidence) best = detection
        }
        return best ?: ProgressBarDetection.UNKNOWN
    }

    private fun score(
        sample: RoiSample,
        bar: MainBarDetection,
        band: BandScanner.Band,
        threshold: Float,
    ): ProgressBarDetection? {
        val left = sample.pixelX(band.leftCell).toFloat()
        val right = sample.pixelX(band.rightCell).toFloat()
        val top = sample.pixelY(band.topCell).toFloat()
        val bottom = sample.pixelY(band.bottomCell).toFloat()
        val widthPx = right - left
        val heightPx = bottom - top
        if (widthPx <= 0f || heightPx <= 0f) return null

        val widthFraction = widthPx / bar.width
        if (widthFraction < config.progressMinWidthPercentOfBar || widthFraction > config.progressMaxWidthPercentOfBar) return null
        val heightFraction = heightPx / bar.height
        if (heightFraction < config.progressMinHeightPercentOfBar || heightFraction > config.progressMaxHeightPercentOfBar) return null
        val gap = top - bar.bottom
        if (gap < 0f) return null

        val gapScore = (1f - (gap / (config.progressMaxGapPercentOfBarHeight * bar.height)).coerceIn(0f, 1f))
        val sizeScore = widthFraction.coerceIn(0f, 1f)
        val aspect = widthPx / heightPx
        val aspectScore = (aspect / 12f).coerceIn(0f, 1f)
        val fillScore = band.fill.coerceIn(0f, 1f)
        val confidence = (gapScore * 0.22f + sizeScore * 0.24f + aspectScore * 0.20f + fillScore * 0.34f)
            .coerceIn(0f, 1f)

        return ProgressBarDetection(
            left = left,
            top = top,
            right = right,
            bottom = bottom,
            confidence = confidence,
            valid = true,
            fillFraction = fillFraction(sample, band, threshold),
        )
    }

    /**
     * Fração preenchida: dentro da faixa, procura o trecho contíguo de colunas
     * que difere do próprio fundo da faixa. É o sinal usado pela infraestrutura
     * de SUCCESS (§33) — "progresso completado" sem depender de OCR.
     */
    private fun fillFraction(sample: RoiSample, band: BandScanner.Band, threshold: Float): Float? {
        val inset = 1
        val y0 = (band.topCell + inset).coerceAtMost(band.bottomCell - 1)
        val y1 = (band.bottomCell - inset).coerceAtLeast(y0 + 1)
        val columns = band.widthCells
        if (columns <= 2 || y1 <= y0) return null

        var sum = 0f
        var n = 0
        for (x in band.leftCell until band.rightCell) {
            for (y in y0 until y1) {
                val v = sample.lumaAt(x, y)
                if (v == RoiSample.INVALID) continue
                sum += v
                n++
            }
        }
        if (n == 0) return null
        val baseline = sum / n

        var filled = 0
        for (x in band.leftCell until band.rightCell) {
            var colSum = 0f
            var colN = 0
            for (y in y0 until y1) {
                val v = sample.lumaAt(x, y)
                if (v == RoiSample.INVALID) continue
                colSum += v
                colN++
            }
            if (colN == 0) continue
            if (abs(colSum / colN - baseline) >= threshold * 0.5f) filled++
        }
        return (filled.toFloat() / columns).coerceIn(0f, 1f)
    }

    private fun cellOf(px: Float, origin: Int, step: Int): Int = ((px - origin) / step).toInt()
}
