package com.fischvision.macro.capture

import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * PROPRIEDADE DO PAYLOAD DE FRAME (Fase 7, §30) — contrato explícito.
 *
 * O MODELO:
 *  - o PRODUTOR (ImageReader → [FrameSource]) cria o payload com
 *    [RefCountedFramePayload.of] e transfere UMA referência ao pipeline;
 *  - o PIPELINE (MacroEngine / CalibrationEngine) é o dono dessa referência e
 *    DEVE liberá-la exatamente uma vez, em `finally`, em qualquer desfecho;
 *  - consumidores auxiliares (FrameBus/overlay/debug) NÃO herdam a posse: eles
 *    chamam `retain()` enquanto forem usar os pixels e `release()` ao terminar
 *    (`FrameBus.withLatestFrame` faz isso por você);
 *  - o recurso real (`android.media.Image`) só é fechado quando a ÚLTIMA
 *    referência é devolvida — por isso não existe "use-after-release" nem
 *    "memory leak" por referência esquecida.
 *
 * GARANTIAS VERIFICÁVEIS (ver FrameOwnershipTest):
 *  1. `argbAt` devolve `null` — nunca lança — depois que a última referência
 *     foi liberada: ler um frame morto não corrompe nem derruba o pipeline;
 *  2. `retain()` em um payload já liberado devolve `false`: não há ressurreição
 *     silenciosa de recurso fechado;
 *  3. `release()` é idempotente e o delegate é fechado UMA única vez.
 */
class RefCountedFramePayload private constructor(
    private val delegate: RgbaFramePayload,
    initialReferences: Int,
) : RgbaFramePayload {

    private val references = AtomicInteger(initialReferences)
    private val delegateReleased = AtomicBoolean(false)

    /** Referências vivas; 0 = recurso liberado. */
    val refCount: Int get() = references.get()

    val isReleased: Boolean get() = references.get() <= 0

    /**
     * Adquire uma referência adicional para um consumidor legítimo.
     * @return false quando o payload já foi liberado (não ressuscita nada)
     */
    fun retain(): Boolean {
        while (true) {
            val current = references.get()
            if (current <= 0) return false
            if (references.compareAndSet(current, current + 1)) return true
        }
    }

    /** Devolve uma referência. Fecha o delegate quando chega a zero. */
    override fun release() {
        val remaining = references.decrementAndGet()
        if (remaining <= 0) releaseDelegateOnce()
    }

    override fun argbAt(x: Int, y: Int): Int? =
        if (references.get() <= 0) null else delegate.argbAt(x, y)

    override val pixelWidth: Int get() = delegate.pixelWidth
    override val pixelHeight: Int get() = delegate.pixelHeight

    override fun sizeBytes(): Long = delegate.sizeBytes()

    private fun releaseDelegateOnce() {
        if (delegateReleased.compareAndSet(false, true)) delegate.release()
    }

    companion object {
        /** Envolve um payload do produtor transferindo [initialReferences] referências. */
        fun of(delegate: RgbaFramePayload, initialReferences: Int = 1): RefCountedFramePayload {
            require(initialReferences >= 0) { "initialReferences negativo" }
            return RefCountedFramePayload(delegate, initialReferences)
        }

        /** Já é ref-contado? Então reaproveita (evita aninhar wrappers). */
        fun wrap(payload: FramePayload): RefCountedFramePayload = when (payload) {
            is RefCountedFramePayload -> payload
            is RgbaFramePayload -> of(payload)
            else -> throw IllegalArgumentException("payload sem acesso a pixels não pode ser ref-contado")
        }
    }
}
