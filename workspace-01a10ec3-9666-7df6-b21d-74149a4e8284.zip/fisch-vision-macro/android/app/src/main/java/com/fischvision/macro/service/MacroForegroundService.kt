package com.fischvision.macro.service

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import com.fischvision.macro.accessibility.MacroAccessibilityService
import com.fischvision.macro.capture.FrameBus
import com.fischvision.macro.capture.MediaProjectionFrameSource
import com.fischvision.macro.controller.FishingControllerImpl
import com.fischvision.macro.core.MacroError
import com.fischvision.macro.core.MacroEvent
import com.fischvision.macro.core.MacroStateMachine
import com.fischvision.macro.debug.DebugLogger
import com.fischvision.macro.debug.PngDebugFrameSink
import com.fischvision.macro.input.AccessibilityInputController
import com.fischvision.macro.input.GestureDispatcher
import com.fischvision.macro.input.InputGateContext
import com.fischvision.macro.input.InputSafetyGuard
import com.fischvision.macro.input.InputWiring
import com.fischvision.macro.overlay.OverlayState
import com.fischvision.macro.overlay.VisionDebugOverlay
import com.fischvision.macro.overlay.WindowOverlayManager
import com.fischvision.macro.settings.MacroSettings
import com.fischvision.macro.tracker.EmaTargetTracker
import com.fischvision.macro.vision.RealVisionProcessor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Foreground Service — orquestração.
 *
 * FASE 7 (§25): o serviço passa a ter DOIS caminhos explícitos:
 *
 *  1. CALIBRAÇÃO (`settings.calibrationMode == true` — padrão desta fase):
 *     captura → visão → tracking → overlay de debug, com INPUT travado por
 *     configuração E pela guarda central. Nenhum InputController é construído.
 *
 *  2. CONTROLE (fases futuras): exige `settings.inputEnabled == true`. Nesta
 *     fase o serviço RECUSA iniciá-lo, mesmo que `controllerEnabled` seja
 *     ligado por engano — é a trava literal do §0 ("INPUT = DISABLED durante
 *     toda esta fase").
 *
 * Fail-safe preservado: pause/stop/destroy soltam qualquer hold pelo engine,
 * a parada fecha fonte+escopo+overlay e a máquina de estados pertence ao
 * serviço (fechar a Activity nunca derruba o macro).
 */
class MacroForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val stateMachine = MacroStateMachine()
    val frameBus = FrameBus()

    private var engine: MacroEngine? = null
    private var calibration: CalibrationEngine? = null
    private var overlay: WindowOverlayManager? = null
    private var visionOverlay: VisionDebugOverlay? = null

    /** Configuração vigente (DataStore entra em fase posterior; aqui é constante). */
    private val settings: MacroSettings = MacroSettings.DEFAULT

    private val logSink = LogSink { level, category, message, throwable ->
        val cat = runCatching { DebugLogger.Category.valueOf(category) }
            .getOrDefault(DebugLogger.Category.SERVICE)
        when {
            level >= 6 -> DebugLogger.e(cat, message, throwable)
            level == 5 -> DebugLogger.w(cat, message, throwable)
            else -> DebugLogger.d(cat, message)
        }
    }

    override fun onCreate() {
        super.onCreate()
        DebugLogger.i(DebugLogger.Category.SERVICE, "MacroForegroundService.onCreate (Fase 7 — calibração)")
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_CAPTURE -> startCaptureFlow(intent)
            ACTION_PAUSE -> {
                engine?.pause()
                calibration?.pause()
            }
            ACTION_RESUME -> {
                engine?.resume()
                calibration?.resume()
            }
            ACTION_STOP -> stopCaptureFlow("ACTION_STOP recebida")
            else -> {
                DebugLogger.w(DebugLogger.Category.SERVICE, "intent sem ação conhecida; encerrando")
                stopSelf(startId)
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopCaptureFlow("onDestroy")
        serviceScope.cancel()
        DebugLogger.i(DebugLogger.Category.SERVICE, "MacroForegroundService.onDestroy — tudo liberado")
        super.onDestroy()
    }

    // --------------------------------------------------------------- start

    private fun startCaptureFlow(intent: Intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                buildNotification(
                    if (settings.calibrationMode) "Calibração de visão ativa — INPUT desabilitado"
                    else "Macro ativo",
                ),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION,
            )
        } else {
            @Suppress("DEPRECATION")
            startForeground(NOTIFICATION_ID, buildNotification("Macro ativo"))
        }

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val consentData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_CONSENT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_CONSENT_DATA)
        }

        if (resultCode != Activity.RESULT_OK || consentData == null) {
            DebugLogger.e(DebugLogger.Category.CAPTURE, "start sem consentimento válido")
            stateMachine.dispatch(
                MacroEvent.FatalError(
                    MacroError(MacroError.Type.PROJECTION_STOPPED, "captura iniciada sem consentimento válido"),
                ),
            )
            stopSelf()
            return
        }

        if (engine?.isRunning == true || calibration?.isRunning == true) {
            DebugLogger.w(DebugLogger.Category.SERVICE, "engine já ativa — instância única preservada")
            return
        }

        if (settings.calibrationMode || !settings.inputEnabled) {
            startCalibrationFlow(resultCode, consentData)
        } else {
            startControlFlow(resultCode, consentData)
        }
    }

    // ------------------------------------------------------- Fase 7: calibração

    private fun startCalibrationFlow(resultCode: Int, consentData: Intent) {
        DebugLogger.i(
            DebugLogger.Category.SERVICE,
            "modo CALIBRAÇÃO: CAPTURE/VISION/TRACKING/OVERLAY ON · INPUT = DISABLED (controllerEnabled=${settings.controllerEnabled}, inputEnabled=${settings.inputEnabled})",
        )
        val source = MediaProjectionFrameSource(
            appContext = applicationContext,
            resultCode = resultCode,
            consentData = consentData,
            settings = settings,
        )
        createVisionOverlay()
        val engine = CalibrationEngine(
            scope = serviceScope,
            fsm = stateMachine,
            bus = frameBus,
            settings = settings,
            sink = logSink,
            onSnapshot = { snapshot -> visionOverlay?.render(snapshot) },
            foregroundPackage = { MacroAccessibilityService.foregroundPackage?.toString() },
            debugFrameSink = if (settings.debugFrameCaptureEnabled) {
                PngDebugFrameSink(applicationContext)
            } else {
                null
            },
        )
        calibration = engine
        if (engine.start(source)) {
            startCalibrationTelemetryLoop()
        } else {
            stopCaptureFlow("calibração recusou start (ver Logcat)")
        }
    }

    private fun createVisionOverlay(): VisionDebugOverlay? {
        if (!settings.visionOverlayEnabled) return null
        if (!Settings.canDrawOverlays(this)) {
            DebugLogger.w(
                DebugLogger.Category.SERVICE,
                "overlay de calibração indisponível: conceda 'Sobrepor outros apps' para VER os retângulos",
            )
            return null
        }
        val mgr = VisionDebugOverlay(
            appContext = applicationContext,
            callbacks = object : VisionDebugOverlay.ControlCallbacks {
                override fun onStop() {
                    startService(controlIntent(ACTION_STOP))
                }

                override fun onToggleVisuals(): Boolean {
                    DebugLogger.d(DebugLogger.Category.SERVICE, "overlay: alternância solicitada pelo usuário")
                    return true
                }
            },
        )
        mgr.show()
        visionOverlay = if (mgr.isShowing) mgr else null
        return visionOverlay
    }

    private fun startCalibrationTelemetryLoop() {
        serviceScope.launch {
            while (isActive) {
                delay(500)
                val t = calibration?.telemetry ?: break
                DebugLogger.d(
                    DebugLogger.Category.VISION,
                    "calibração: frames=${t.framesProcessed} fps=${"%.1f".format(t.fps)} " +
                        "fsm=${stateMachine.state} input=${t.inputStateLabel}",
                )
            }
        }
    }

    // -------------------------------------------- Fase 5/6: controle (travado)

    private fun startControlFlow(resultCode: Int, consentData: Intent) {
        DebugLogger.i(DebugLogger.Category.SERVICE, "modo CONTROLE solicitado (inputEnabled=true)")
        val source = MediaProjectionFrameSource(
            appContext = applicationContext,
            resultCode = resultCode,
            consentData = consentData,
            settings = settings,
        )

        val vision = RealVisionProcessor()
        val fishTracker = EmaTargetTracker()
        val indicatorTracker = EmaTargetTracker()
        val controller = FishingControllerImpl()

        val dispatcher = object : GestureDispatcher {
            override fun tap(x: Float, y: Float): Boolean =
                MacroAccessibilityService.dispatch(MacroAccessibilityService.GestureRequest.Tap(x, y))

            override fun holdStart(x: Float, y: Float, maxDurationMillis: Long): Boolean =
                MacroAccessibilityService.dispatch(
                    MacroAccessibilityService.GestureRequest.HoldStart(x, y, maxDurationMillis),
                )

            override fun holdEnd(): Boolean = MacroAccessibilityService.releaseAll()
        }

        val eng = MacroEngine(
            scope = serviceScope,
            fsm = stateMachine,
            bus = frameBus,
            vision = vision,
            fishTracker = fishTracker,
            indicatorTracker = indicatorTracker,
            controller = controller,
            input = AccessibilityInputController(
                dispatcher = dispatcher,
                gate = {
                    InputGateContext(
                        macroState = stateMachine.state,
                        trackingOk = engine?.telemetry?.trackingOk == true,
                        confidence = engine?.telemetry?.confidence ?: 0f,
                        frameWidth = engine?.telemetry?.frameWidth ?: settings.captureWidth,
                        frameHeight = engine?.telemetry?.frameHeight ?: settings.captureHeight,
                    )
                },
                // GUARDA CENTRAL (§26): a configuração decide, não o chamador.
                safety = InputSafetyGuard(settings.targetAppPackage),
                safetyContext = {
                    InputWiring.safetyContext(
                        settings = settings,
                        foregroundPackage = MacroAccessibilityService.foregroundPackage?.toString(),
                        trackingValid = engine?.telemetry?.trackingOk == true,
                        confidence = engine?.telemetry?.confidence ?: 0f,
                        fsmState = stateMachine.state,
                        projectionActive = engine?.isRunning == true,
                    )
                },
            ),
            sink = logSink,
            resetController = { controller.reset() },
        )
        engine = eng

        maybeCreateLegacyOverlay()
        if (eng.start(source)) {
            startTelemetryLoop()
        } else {
            stopCaptureFlow("engine recusou start (ver Logcat)")
        }
    }

    // ---------------------------------------------------------------- stop

    private fun stopCaptureFlow(reason: String) {
        DebugLogger.i(DebugLogger.Category.SERVICE, "parando: $reason")
        engine?.stop()
        engine = null
        calibration?.stop()
        calibration = null
        overlay?.destroy()
        overlay = null
        visionOverlay?.destroy()
        visionOverlay = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    // ------------------------------------------------------------- overlay

    /** Overlay curto da Fase 6 — usado apenas no caminho de controle. */
    private fun maybeCreateLegacyOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            DebugLogger.d(DebugLogger.Category.SERVICE, "overlay ausente: permissão não concedida")
            return
        }
        val mgr = WindowOverlayManager(
            appContext = applicationContext,
            controls = object : WindowOverlayManager.ControlCallbacks {
                override fun onStart() { /* iniciado pelo fluxo de consentimento */ }
                override fun onPause() { startService(controlIntent(ACTION_PAUSE)) }
                override fun onResume() { startService(controlIntent(ACTION_RESUME)) }
                override fun onStop() { startService(controlIntent(ACTION_STOP)) }
            },
        )
        mgr.show()
        overlay = mgr
    }

    private fun controlIntent(action: String) = Intent(this, MacroForegroundService::class.java).apply {
        this.action = action
    }

    private fun startTelemetryLoop() {
        serviceScope.launch {
            var lastFrames = 0L
            while (isActive) {
                delay(500)
                val t = engine?.telemetry ?: break
                val fps = (t.framesProcessed - lastFrames) / 0.5
                lastFrames = t.framesProcessed
                overlay?.update(
                    OverlayState(
                        macroEnabled = engine?.isRunning == true,
                        stateName = stateMachine.state.name,
                        fps = fps.coerceAtLeast(0.0),
                        confidence = t.confidence,
                    ),
                )
            }
        }
    }

    // ---------------------------------------------------------- notificação

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Fisch Vision Macro — captura",
                NotificationManager.IMPORTANCE_LOW,
            ).apply { description = "Ativa enquanto o macro executa." }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Fisch Vision Macro")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Fisch Vision Macro")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true)
                .build()
        }
    }

    companion object {
        const val ACTION_START_CAPTURE = "com.fischvision.macro.action.START_CAPTURE"
        const val ACTION_PAUSE = "com.fischvision.macro.action.PAUSE"
        const val ACTION_RESUME = "com.fischvision.macro.action.RESUME"
        const val ACTION_STOP = "com.fischvision.macro.action.STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_CONSENT_DATA = "extra_consent_data"
        private const val CHANNEL_ID = "fvm_capture"
        private const val NOTIFICATION_ID = 41
    }
}
