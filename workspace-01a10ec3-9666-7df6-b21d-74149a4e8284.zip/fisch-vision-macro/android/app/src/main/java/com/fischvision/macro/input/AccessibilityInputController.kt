package com.fischvision.macro.input

import com.fischvision.macro.core.MacroState
import com.fischvision.macro.debug.DebugLogger

/**
 * Seam de despacho: produção delega a MacroAccessibilityService.dispatch;
 * testes usam implementação falsa de device. A camada de gating (abaixo) é
 * 100% testável em JVM por isso — sem fingir gestos.
 */
interface GestureDispatcher {
    fun tap(x: Float, y: Float): Boolean
    fun holdStart(x: Float, y: Float, maxDurationMillis: Long): Boolean
    fun holdEnd(): Boolean
}

/** Limites configuráveis de segurança de entrada. */
data class InputLimits(
    val minIntervalMillis: Long = 50,
    val maxCommandsPerMinute: Int = 300,
    val maxHoldMillis: Long = 900,
    val minConfidence: Float = 0.35f,
    /** Ponto neutro do toque em FRAÇÃO do frame (não em pixels fixos). */
    val touchXPct: Float = 0.5f,
    val touchYPct: Float = 0.85f,
) {
    init {
        require(minIntervalMillis >= 0) { "minInterval inválido" }
        require(maxCommandsPerMinute in 1..1200) { "maxCommandsPerMinute fora de [1,1200]" }
        require(maxHoldMillis in 1..55_000) { "maxHold fora de [1,55000]" }
        require(minConfidence in 0f..1f) { "minConfidence fora de [0,1]" }
        require(touchXPct in 0f..1f && touchYPct in 0f..1f) { "ponto de toque fora de [0,1]" }
    }
}

/** Contexto que autoriza (ou bloqueia) a injeção de um comando. */
data class InputGateContext(
    val macroState: MacroState,
    val trackingOk: Boolean,
    val confidence: Float,
    val frameWidth: Int,
    val frameHeight: Int,
)

/**
 * InputController real com portões rígidos.
 *
 * HISTÓRICO DE DEFEITO CORRIGIDO NA FASE 7 (§31):
 *  - [lastCommandAtNanos] começava em `Long.MIN_VALUE`. `now - Long.MIN_VALUE`
 *    estoura o Long (wrap-around) e o resultado fica NEGATIVO, então a
 *    comparação `now - last < minInterval` era verdadeira e o PRIMEIRO comando
 *    do processo era sempre recusado — inclusive depois de [reset].
 *    Agora o estado é explícito: `hasLastCommand` + `lastCommandAtNanos`
 *    válido, sem sentinela aritmética.
 *
 * FASE 7 (§26): além do portão de estado, o controller consulta a
 * [InputSafetyGuard] — camada central que recusa o comando mesmo que algum
 * módulo chame `execute` por engano. `releaseAll()` continua imune a tudo.
 */
class AccessibilityInputController(
    private val dispatcher: GestureDispatcher,
    private val gate: () -> InputGateContext,
    private val limits: InputLimits = InputLimits(),
    private val clock: () -> Long = { System.nanoTime() },
    /** Guarda central da Fase 7. `null` = comportamento da Fase 5/6 preservado. */
    private val safety: InputSafetyGuard? = null,
    private val safetyContext: (() -> InputSafetyContext)? = null,
    /** Observador das decisões (HUD/telemetria). Chamado a cada `execute`. */
    private val onDecision: ((SafetyDecision) -> Unit)? = null,
) : InputController {

    private var hasLastCommand = false
    private var lastCommandAtNanos = 0L
    private val commandWindow = ArrayDeque<Long>()
    private var holding = false

    var lastDispatchOk = true
        private set

    /** Última decisão da guarda central (HUD). */
    var lastSafetyDecision: SafetyDecision = SafetyDecision.Allow
        private set

    /** Reflete o último resultado real do dispatcher (não um otimismo). */
    override val isAvailable: Boolean get() = lastDispatchOk

    override fun execute(command: InputCommand): Boolean {
        // 0 — guarda central da Fase 7 (§26): nunca depende do chamador.
        val guard = safety
        val contextProvider = safetyContext
        if (guard != null && contextProvider != null) {
            val decision = guard.evaluate(contextProvider())
            lastSafetyDecision = decision
            onDecision?.invoke(decision)
            if (decision is SafetyDecision.Block) {
                DebugLogger.w(
                    DebugLogger.Category.INPUT,
                    "comando recusado pela guarda: ${decision.reason.label} (${decision.detail})",
                )
                return false
            }
        }

        val ctx = gate()

        if (ctx.macroState != MacroState.CONTROLLING) {
            DebugLogger.w(DebugLogger.Category.INPUT, "comando bloqueado fora de CONTROLLING (${ctx.macroState})")
            return false
        }
        if (!ctx.trackingOk) {
            DebugLogger.w(DebugLogger.Category.INPUT, "comando bloqueado: tracking perdido")
            return false
        }
        if (ctx.confidence < limits.minConfidence) {
            DebugLogger.w(DebugLogger.Category.INPUT, "comando bloqueado: confidence ${ctx.confidence}")
            return false
        }
        if (!rateAllows()) {
            DebugLogger.w(DebugLogger.Category.INPUT, "comando bloqueado: limite de taxa")
            return false
        }

        val px = limits.touchXPct * ctx.frameWidth
        val py = limits.touchYPct * ctx.frameHeight

        val ok = when (command.action) {
            InputCommand.Action.TAP -> dispatcher.tap(px, py)
            InputCommand.Action.HOLD_START -> {
                if (holding) true
                else dispatcher.holdStart(
                    px, py,
                    command.durationMillis.coerceIn(1L, limits.maxHoldMillis),
                ).also { if (it) holding = true }
            }
            InputCommand.Action.HOLD_END -> dispatcher.holdEnd().also { holding = false }
        }

        lastDispatchOk = ok
        if (ok) recordCommand()
        return ok
    }

    /**
     * Fail-safe: NUNCA passa por gate nem pela guarda — stop/pause/erro/perda
     * sempre soltam o dedo virtual. Não consome cota de taxa.
     */
    override fun releaseAll() {
        val ok = dispatcher.holdEnd()
        holding = false
        lastDispatchOk = ok
    }

    /** Zera o limitador de taxa (§31: precisa existir para o teste de reset). */
    fun resetRateLimiter() {
        hasLastCommand = false
        lastCommandAtNanos = 0L
        commandWindow.clear()
    }

    private fun rateAllows(): Boolean {
        val now = clock()
        if (hasLastCommand && now - lastCommandAtNanos < limits.minIntervalMillis * 1_000_000L) return false
        while (commandWindow.isNotEmpty() && now - commandWindow.first() > 60_000_000_000L) {
            commandWindow.removeFirst()
        }
        return commandWindow.size < limits.maxCommandsPerMinute
    }

    private fun recordCommand() {
        lastCommandAtNanos = clock()
        hasLastCommand = true
        commandWindow.addLast(lastCommandAtNanos)
    }
}
