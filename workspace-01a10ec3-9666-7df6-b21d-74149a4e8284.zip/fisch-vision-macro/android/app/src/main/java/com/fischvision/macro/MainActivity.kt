package com.fischvision.macro

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.fischvision.macro.core.MacroError
import com.fischvision.macro.core.MacroEvent
import com.fischvision.macro.core.MacroStateMachine
import com.fischvision.macro.core.Transition
import com.fischvision.macro.debug.DebugLogger
import com.fischvision.macro.settings.MacroSettings
import com.fischvision.macro.service.MacroForegroundService

/**
 * MainActivity.
 *
 * Fase 7 acrescenta a seção de CALIBRAÇÃO: o app inicia captura+visão+tracking+
 * overlay com INPUT DESABILITADO (§25). O texto de status e os botões existentes
 * do testbench da FSM continuam iguais — nada foi removido.
 *
 * Real nesta fase:
 *  - solicita POST_NOTIFICATIONS (33+) antes de iniciar o serviço;
 *  - solicita consentimento MediaProjection via diálogo do sistema;
 *  - inicia MacroForegroundService com o token de uso único;
 *  - para a captura explicitamente;
 *  - mantém o testbench local da máquina de estados.
 *
 * Não faz: envia gestos, automação do jogo, overlay (Fases 5/6/11).
 *
 * startActivityForResult é a API de plataforma (deprecada em favor do
 * Activity Result APIs do androidx.activity, dependência evitada nesta fase);
 * o uso é consciente e suprimido localmente — não é API inventada.
 */
class MainActivity : Activity() {

    private val stateMachine = MacroStateMachine()

    private lateinit var stateText: TextView
    private lateinit var transitionText: TextView
    private lateinit var historyText: TextView
    private lateinit var captureStatus: TextView
    private lateinit var calibrationStatus: TextView
    private var frameSeq = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DebugLogger.i(DebugLogger.Category.STATE, "MainActivity.onCreate — Fase 2 (captura)")
        setContentView(buildContent())
        render(null)
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    // ------------------------------------------------- captura (Fase 2)

    private fun requestCaptureConsent() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
            captureStatus.text = "permissão de notificação solicitada; toque novamente após conceder"
            return
        }
        val mgr = getSystemService(MediaProjectionManager::class.java)
        if (mgr == null) {
            captureStatus.text = "MediaProjectionManager indisponível"
            return
        }
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
        captureStatus.text = "aguardando consentimento do sistema…"
    }

    @Deprecated("API de plataforma; androidx Activity Result evitado nesta fase")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode != RESULT_OK || data == null) {
            captureStatus.text = "captura NEGADA pelo usuário (resultCode=$resultCode)"
            DebugLogger.w(DebugLogger.Category.CAPTURE, "consentimento negado")
            return
        }
        val intent = Intent(this, MacroForegroundService::class.java).apply {
            action = MacroForegroundService.ACTION_START_CAPTURE
            putExtra(MacroForegroundService.EXTRA_RESULT_CODE, resultCode)
            putExtra(MacroForegroundService.EXTRA_CONSENT_DATA, data)
        }
        startForegroundService(intent)
        captureStatus.text = "captura iniciada (foreground service ativo)"
        calibrationStatus.append("\n\n[${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())}] "
            + "calibração solicitada — INPUT = DISABLED")
    }

    private fun stopCapture() {
        startService(Intent(this, MacroForegroundService::class.java).apply {
            action = MacroForegroundService.ACTION_STOP
        })
        captureStatus.text = "parada solicitada ao serviço"
    }

    // ------------------------------------------------------------------ UI

    private fun buildContent(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
        }

        root.addView(header("FISCH VISION MACRO", 24f, ACCENT, bold = true))
        root.addView(mono("FASE 7 — VISÃO · TRACKING · DEBUG OVERLAY (INPUT DISABLED)", WARN, 11f))

        // ---- Fase 7: modo de calibração
        root.addView(sectionTitle("MODO CALIBRAÇÃO (FASE 7)"))
        calibrationStatus = mono(buildString {
            appendLine("CAPTURE = ON   VISION = ON   TRACKING = ON")
            appendLine("OVERLAY = ${if (MacroSettings.DEFAULT.visionOverlayEnabled) "ON" else "OFF"}   INPUT = DISABLED")
            appendLine("controllerEnabled = ${MacroSettings.DEFAULT.controllerEnabled}  ·  inputEnabled = ${MacroSettings.DEFAULT.inputEnabled}")
        }, TEXT, 10.5f).apply { setPadding(0, 0, 0, dp(6)) }
        root.addView(calibrationStatus)
        val calRow = LinearLayout(this)
        capRowHook(calRow)
        root.addView(calRow)
        root.addView(
            mono(
                "O overlay desenha MAIN BAR (ciano), ZONE (âmbar), FISH (verde) e PROGRESS\n" +
                    "(magenta) com os valores reais de confidence. A guarda central recusa\n" +
                    "QUALQUER gesto enquanto o modo de calibração estiver ativo.",
                DIM, 10f,
            ).apply { setLineSpacing(0f, 1.25f) }
        )

        // ---- seção captura
        root.addView(sectionTitle("CAPTURA"))
        captureStatus = mono("captura: inativa", TEXT, 11f).apply { setPadding(0, 0, 0, dp(6)) }
        root.addView(captureStatus)
        val capRow = LinearLayout(this)
        capRow.addView(simpleButton("INICIAR CAPTURA") { requestCaptureConsent() })
        capRow.addView(simpleButton("PARAR CAPTURA") { stopCapture() })
        root.addView(capRow)
        root.addView(
            mono(
                "Sem gestos, sem automação. O serviço publica frames no FrameBus e libera\n" +
                    "cada payload após o consumo. Recuse o diálogo para testar o caminho de negação.",
                DIM, 10f,
            ).apply { setLineSpacing(0f, 1.25f) }
        )

        // ---- testbench FSM
        root.addView(sectionTitle("TESTBENCH FSM (LOCAL)"))
        stateText = header("", 34f, Color.WHITE, bold = true)
        root.addView(stateText)
        transitionText = mono("", DIM, 11f)
        root.addView(transitionText)

        val events: List<Pair<String, () -> MacroEvent>> = listOf(
            "START" to { MacroEvent.Start },
            "PAUSE" to { MacroEvent.Pause },
            "RESUME" to { MacroEvent.Resume },
            "STOP" to { MacroEvent.Stop },
            "FRAME" to { MacroEvent.FrameAvailable(frameSeq++) },
            "FOUND" to { MacroEvent.DetectionFound },
            "LOST" to { MacroEvent.DetectionLost },
            "CONTROL" to { MacroEvent.ControlRequested },
            "SUCCESS" to { MacroEvent.FishingSuccess },
            "FAILED" to { MacroEvent.FishingFailed },
            "PROJ STOP" to { MacroEvent.ProjectionStopped },
            "FATAL" to {
                MacroEvent.FatalError(MacroError(MacroError.Type.UNKNOWN, "erro de teste da UI"))
            },
        )
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, 0) }
        var row = LinearLayout(this)
        events.forEachIndexed { index, (label, factory) ->
            if (index % 4 == 0) {
                row = LinearLayout(this@MainActivity)
                grid.addView(row, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            }
            val b = simpleButton(label) { onEvent(factory()) }
            b.textSize = 9f
            row.addView(b)
        }
        root.addView(grid)

        root.addView(sectionTitle("HISTÓRICO"))
        historyText = mono("", TEXT, 11f).apply { setLineSpacing(0f, 1.25f) }
        root.addView(historyText)

        root.addView(sectionTitle("STATUS DAS FASES"))
        root.addView(
            mono(
                buildString {
                    appendLine("F1 FUNDAÇÃO .............. SOURCE OK / EXEC BLOCKED(local)")
                    appendLine("F2 CAPTURA ............... IMPLEMENTED / DEVICE BLOCKED")
                    appendLine("F3+ VISÃO/INPUT/AUTOMAÇÃO .. NOT_IMPLEMENTED (fases futuras)")
                },
                DIM, 10.5f,
            ).apply { setLineSpacing(0f, 1.3f) }
        )

        return ScrollView(this).apply { addView(root) }
    }

    /** Botões do modo de calibração — captura + overlay + parada. */
    private fun capRowHook(row: LinearLayout) {
        row.addView(simpleButton("INICIAR CALIBRAÇÃO") { requestCaptureConsent() })
        row.addView(simpleButton("PARAR") { stopCapture() })
        row.addView(simpleButton("OVERLAY") { requestOverlayPermission() })
    }

    /** SYSTEM_ALERT_WINDOW é necessário para o overlay de debug; sem ela, a visão segue ativa. */
    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName"),
                ),
            )
            captureStatus.text = "conceda 'Sobrepor outros apps' e reinicie a calibração"
        } else {
            captureStatus.text = "permissão de overlay já concedida"
        }
    }

    private fun sectionTitle(text: String) =
        header(text, 12f, ACCENT, bold = false).apply { setPadding(0, dp(18), 0, dp(6)) }

    private fun simpleButton(label: String, onClick: () -> Unit): Button {
        val button = Button(this).apply {
            text = label
            textSize = 10f
            setTextColor(ACCENT)
            typeface = Typeface.MONOSPACE
            setOnClickListener { onClick() }
        }
        button.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(3), dp(3), dp(3), dp(3))
        }
        return button
    }

    private fun header(text: String, sp: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun mono(text: String, color: Int, sp: Float): TextView =
        TextView(this).apply {
            this.text = text
            textSize = sp
            typeface = Typeface.MONOSPACE
            setTextColor(color)
        }

    // ------------------------------------------------------ comportamento

    private fun onEvent(event: MacroEvent) {
        val transition = stateMachine.dispatch(event)
        DebugLogger.d(DebugLogger.Category.STATE, "${transition.from} + $event -> ${transition.to} (${transition.accepted})")
        render(transition)
    }

    private fun render(lastTransition: Transition?) {
        stateText.text = stateMachine.state.name
        transitionText.text = when {
            lastTransition == null -> "aguardando evento"
            lastTransition.accepted -> "ACEITA ${lastTransition.from} → ${lastTransition.to}"
            else -> "REJEITADA ${lastTransition.event} em ${lastTransition.from}"
        }
        historyText.text = stateMachine.history
            .takeLast(8)
            .reversed()
            .joinToString("\n") { t ->
                val mark = if (t.accepted) "[ok]" else "[--]"
                "$mark ${t.from.name} + ${t.event.javaClass.simpleName} → ${t.to.name}"
            }
            .ifEmpty { "(vazio)" }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private companion object {
        const val REQ_CAPTURE = 1001
        const val REQ_NOTIFICATIONS = 1002
        val ACCENT = Color.parseColor("#22D3EE")
        val TEXT = Color.parseColor("#E2E8F0")
        val DIM = Color.parseColor("#64748B")
        val WARN = Color.parseColor("#FBBF24")
    }
}
