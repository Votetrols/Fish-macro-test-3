package com.fischvision.macro.vision.detect

/**
 * Limiares do pipeline de visão da Fase 7 — TODOS explicitamente configuráveis.
 *
 * Regra da fase: nenhum "número mágico" embutido na lógica. Cada valor aqui é
 * um botão de calibração, com valor inicial derivado das observações do vídeo
 * de referência e da geometria esperada do minigame — NÃO validado em
 * dispositivo (ver PHASE_7_STATUS.md > Limitações).
 *
 * As frações são relativas (ROI, altura da barra, largura da barra), de modo
 * que a calibração continue válida se a captura mudar de 1920×1080 para
 * 960×540 — foi por isso que os limiares não foram escritos em pixels fixos.
 */
data class VisionConfig(
    // ---------------------------------------------------------------- geral
    /** Contraste mínimo absoluto (luma 0..255) para considerar uma célula "estruturada". */
    val minAbsoluteContrast: Float = 14f,
    /** Multiplicador do desvio robusto do fundo (acompanha cena clara/escura). */
    val contrastSpreadFactor: Float = 2.5f,
    /** Confiança mínima para uma detecção ser considerada válida. */
    val minConfidence: Float = 0.40f,
    /**
     * Passo de amostragem padrão da ROI. 2 = ¼ do custo por célula e continua
     * preciso no buffer de captura de 960×540 (barra de ~35 px de altura).
     */
    val sampleStep: Int = 2,

    // ------------------------------------------------------------ main bar
    /** Fração de colunas estruturadas para a linha pertencer à faixa da barra. */
    val barRowFillMin: Float = 0.50f,
    /** Fração mínima de linhas da faixa em que uma coluna deve estar estruturada. */
    val barColumnFillMin: Float = 0.60f,
    /**
     * Altura mínima da faixa como fração da altura da ROI.
     *
     * 0.10 (Fase 7, medido): separa MAIN_BAR de PROGRESS_BAR por PORTE, antes
     * mesmo da posição. A barra principal do vídeo tem ~70 px em 1080 (≈21% da
     * ROI do minigame); uma barra de progresso fina (12 px em 1080 ≈ 4%) fica de
     * fora. Sem este portão, uma cena sem barra principal elegia a barra de
     * progresso como MAIN_BAR.
     */
    val barMinHeightPercentOfRoi: Float = 0.10f,
    val barMaxHeightPercentOfRoi: Float = 0.55f,
    val barMinWidthPercentOfRoi: Float = 0.45f,
    /** Buraco máximo (em células) tolerado dentro de um trecho contínuo da barra. */
    val barGapToleranceCells: Int = 5,
    val barMinAspect: Float = 3.5f,
    val barMaxAspect: Float = 40f,
    /** Aspecto preferido (largura/altura) usado no score triangular. */
    val barPreferredAspect: Float = 9f,
    /** Largura de referência (fração da ROI) para o score de continuidade. */
    val barContinuityReference: Float = 0.60f,
    /** Posição vertical preferida do centro da barra dentro da ROI (0=topo, 1=base). */
    val barPreferredVerticalPosition: Float = 0.50f,
    val barVerticalTolerance: Float = 0.55f,
    val barMinConfidence: Float = 0.45f,
    /** Bônus de confidence quando os dois marcadores de extremidade aparecem (§9). */
    val barEndMarkerBonus: Float = 0.05f,

    // --------------------------------------------------------------- zone
    /** Inset vertical (fração da altura da barra) para ignorar as bordas. */
    val zoneInteriorInsetPercent: Float = 0.14f,
    /** Score mínimo por coluna para pertencer à zona. */
    val zoneColumnThreshold: Float = 0.55f,
    val zoneMinWidthPercentOfBar: Float = 0.05f,
    val zoneMaxWidthPercentOfBar: Float = 0.75f,
    /** Largura preferida da zona em fração da barra (score triangular). */
    val zonePreferredWidthPercentOfBar: Float = 0.30f,
    /** Cobertura vertical mínima da zona dentro do interior da barra. */
    val zoneMinVerticalCoverage: Float = 0.55f,
    val zoneMinConfidence: Float = 0.40f,
    /** Peso da cor quente (R−B) na assinatura da coluna: auxiliar, não único (§39). */
    val zoneWarmthWeight: Float = 1.4f,

    // --------------------------------------------------------------- fish
    /** Fração da altura da barra pesquisada ACIMA dela (ícone/linha do peixe). */
    val fishAboveBarSearchPercent: Float = 0.90f,
    /** Largura máxima do marcador em fração da largura da barra. */
    val fishMaxWidthPercentOfBar: Float = 0.05f,
    /** Limiar de saliência de faixa estreita para semear um candidato. */
    val fishNarrowBandThreshold: Float = 0.30f,
    /** Comprimento vertical mínimo (fração do intervalo pesquisado). */
    val fishMinVerticalContinuity: Float = 0.55f,
    val fishMinConfidence: Float = 0.40f,
    /** Penalidade quando o candidato está colado a uma "zona" larga (borda da zona). */
    val fishZoneEdgePenalty: Float = 0.35f,
    /**
     * Fração da largura da barra DESCARTADA em cada extremidade na busca do
     * marcador do peixe.
     *
     * Motivo medido: as tampas/marcadores das extremidades da barra são linhas
     * verticais claras, estreitas e isoladas — geometricamente idênticas ao
     * marcador do peixe. Sem esta exclusão o detector escolhia o marcador da
     * extremidade (evidência registrada no diagnóstico da fase). O marcador do
     * peixe vive no TRECHO ÚTIL da barra, então esta é uma restrição de região,
     * não um remendo: o valor é calibrável.
     */
    val fishEndExclusionPercentOfBar: Float = 0.04f,

    // ----------------------------------------------------------- progress
    /** Folga mínima/máxima entre a barra principal e a barra de progresso. */
    val progressMinGapPercentOfBarHeight: Float = 0.10f,
    val progressMaxGapPercentOfBarHeight: Float = 3.0f,
    val progressMinWidthPercentOfBar: Float = 0.35f,
    val progressMaxWidthPercentOfBar: Float = 1.30f,
    val progressMinHeightPercentOfBar: Float = 0.03f,
    val progressMaxHeightPercentOfBar: Float = 0.60f,
    val progressMinAspect: Float = 6f,
    val progressMinConfidence: Float = 0.35f,
) {
    init {
        require(sampleStep >= 1) { "sampleStep deve ser >= 1" }
        require(barMinAspect < barMaxAspect) { "faixa de aspecto inválida" }
        require(zoneMinWidthPercentOfBar < zoneMaxWidthPercentOfBar) { "faixa de largura da zona inválida" }
    }

    companion object {
        /** Configuração usada pela produção enquanto não há calibração de campo. */
        val DEFAULT = VisionConfig()
    }
}
