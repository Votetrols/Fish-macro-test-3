package com.fischvision.macro.vision.detect

import com.fischvision.macro.vision.IntRect
import com.fischvision.macro.vision.RoiSample
import kotlin.math.abs

/**
 * Detector da BARRA PRINCIPAL (Fase 7, §8) — sem cor como método único (§5).
 *
 * MÉTODO (todas as etapas usam geometria/posição/continuidade; cor é apenas
 * matéria-prima de contraste):
 *
 *  1. contraste: o limiar nasce da cena — `max(14, 2.5 × MAD(fundo))`. Uma cena
 *     escura ou ofuscada muda o limiar, não a detecção;
 *  2. máscara estrutural: célula "estruturada" = luminância diferente do fundo
 *     estimado da ROI (robusto a branco, cinza, laranja, claro ou escuro);
 *  3. linhas: agrupa linhas consecutivas com ≥50% de células estruturadas →
 *     FAIXAS candidatas;
 *  4. portões geométricos: altura dentro de [6%, 55%] da ROI, trecho contínuo
 *     ≥45% da largura da ROI, aspecto ∈ [3.5, 40];
 *  5. score explícito (continuidade 0.34 · aspecto 0.20 · posição vertical 0.14 ·
 *     bordas 0.16 · preenchimento 0.16) + bônus de 0.05 pelos marcadores de
 *     extremidade — que são evidência AUXILIAR, nunca obrigatória;
 *  6. rejeita: objeto pequeno, objeto vertical, barra fora da ROI, trecho sem
 *     continuidade e confidence abaixo de [VisionConfig.barMinConfidence].
 *
 * Determinístico, sem alocação por frame (buffers em [BandScanner]).
 */
class MainBarDetector(
    private val config: VisionConfig = VisionConfig.DEFAULT,
    /** Scanner compartilhado com os outros detectores (máscara construída 1×/frame). */
    private val scanner: BandScanner = BandScanner(config),
) {

    /**
     * Todas as faixas candidatas que passaram nos portões, ordenadas por
     * confidence (maior primeiro). O chamador decide qual é a MAIN_BAR — é
     * assim que a barra de progresso deixa de ser confundida com a principal.
     */
    fun detectCandidates(sample: RoiSample, roi: IntRect, epoch: Long = 0L): List<MainBarDetection> {
        if (sample.cellCount <= 0 || sample.framePixelsSampled <= 0) return emptyList()
        val threshold = scanner.contrastThreshold(sample)
        if (!scanner.ensureMask(sample, threshold, epoch)) return emptyList()

        val bands = scanner.findBands(
            sample = sample,
            minHeightPercentOfRoi = config.barMinHeightPercentOfRoi,
            maxHeightPercentOfRoi = config.barMaxHeightPercentOfRoi,
            minWidthPercentOfRoi = config.barMinWidthPercentOfRoi,
            minAspect = config.barMinAspect,
            maxAspect = config.barMaxAspect,
        )
        if (bands.isEmpty()) return emptyList()

        val out = ArrayList<MainBarDetection>(bands.size)
        for (band in bands) {
            val detection = score(sample, roi, band, threshold) ?: continue
            if (detection.confidence >= config.barMinConfidence) out.add(detection)
        }
        out.sortByDescending { it.confidence }
        return out
    }

    /** Melhor candidato, ou null quando nada passa nos portões. */
    fun detect(sample: RoiSample, roi: IntRect, epoch: Long = 0L): MainBarDetection? =
        detectCandidates(sample, roi, epoch).firstOrNull()

    private fun score(sample: RoiSample, roi: IntRect, band: BandScanner.Band, threshold: Float): MainBarDetection? {
        val left = sample.pixelX(band.leftCell).toFloat()
        val right = sample.pixelX(band.rightCell).toFloat()
        val top = sample.pixelY(band.topCell).toFloat()
        val bottom = sample.pixelY(band.bottomCell).toFloat()
        val widthPx = right - left
        val heightPx = bottom - top
        if (widthPx <= 0f || heightPx <= 0f) return null

        // Portão explícito de contenção: nada fora da ROI é aceito (§8).
        if (left < roi.left || right > roi.right || top < roi.top || bottom > roi.bottom) return null

        val aspect = widthPx / heightPx
        val continuity = (widthPx / (roi.width * config.barContinuityReference)).coerceIn(0f, 1f)
        val aspectScore = (1f - abs(aspect - config.barPreferredAspect) / config.barPreferredAspect).coerceIn(0f, 1f)
        val verticalPosition = (top + heightPx / 2f - roi.top) / roi.height.toFloat()
        val verticalScore = (1f - abs(verticalPosition - config.barPreferredVerticalPosition) /
            config.barVerticalTolerance).coerceIn(0f, 1f)
        val borderEdgeScore = borderEdgeScore(sample, band, threshold)
        val fillScore = band.fill.coerceIn(0f, 1f)
        val endMarkers = scanner.endMarkerEvidence(sample, band, threshold)

        var confidence = continuity * 0.34f +
            aspectScore * 0.20f +
            verticalScore * 0.14f +
            borderEdgeScore * 0.16f +
            fillScore * 0.16f
        if (endMarkers) confidence += config.barEndMarkerBonus
        confidence = confidence.coerceIn(0f, 1f)

        return MainBarDetection(
            left = left,
            top = top,
            right = right,
            bottom = bottom,
            confidence = confidence,
            valid = true,
            endMarkers = endMarkers,
            criteria = MainBarDetection.Criteria(
                continuity = continuity,
                aspectScore = aspectScore,
                verticalScore = verticalScore,
                borderEdgeScore = borderEdgeScore,
                fillScore = fillScore,
            ),
        )
    }

    /**
     * Força das bordas superior e inferior: a barra tem contorno (é um objeto
     * delimitado). Sem borda não é barra — é mancha.
     */
    private fun borderEdgeScore(sample: RoiSample, band: BandScanner.Band, threshold: Float): Float {
        val rows = ArrayList<Int>(sample.width)
        var sides = 0
        var total = 0f

        val insideTop = sample.rowMedianLuma(band.topCell, rows).also { rows.clear() }
        val outsideTop = if (band.topCell - 1 >= 0) sample.rowMedianLuma(band.topCell - 1, rows) else null
        if (outsideTop != null) {
            total += abs(insideTop - outsideTop)
            sides++
        }
        rows.clear()
        val insideBottom = sample.rowMedianLuma(band.bottomCell - 1, rows)
        val outsideBottom = if (band.bottomCell < sample.height) sample.rowMedianLuma(band.bottomCell, rows) else null
        if (outsideBottom != null) {
            total += abs(insideBottom - outsideBottom)
            sides++
        }
        if (sides == 0) return 0f
        val mean = total / sides
        return (mean / (threshold * 1.5f)).coerceIn(0f, 1f)
    }
}
