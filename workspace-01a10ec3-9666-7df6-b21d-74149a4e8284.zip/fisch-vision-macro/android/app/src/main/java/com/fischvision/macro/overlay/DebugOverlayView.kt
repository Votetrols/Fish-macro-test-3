package com.fischvision.macro.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import com.fischvision.macro.debug.DebugTextFormatter
import com.fischvision.macro.debug.VisionDebugSnapshot

/**
 * Desenho do overlay de debug (§20–§22).
 *
 * A view NÃO decide nada: ela recebe um [VisionDebugSnapshot] e desenha o que
 * está lá. As coordenadas das detecções vêm do frame de CAPTURA (por exemplo
 * 960×540) e são escaladas para a tela (por exemplo 1080×2400) por
 * `escala = largura_da_view / largura_do_frame`. É por isso que o overlay serve
 * para validar o detector visualmente: o retângulo cai exatamente onde a
 * estrutura foi detectada na imagem capturada.
 *
 * Cores por entidade (todas distintas para leitura rápida):
 *   MAIN BAR → ciano · ZONE → âmbar · FISH → verde · PROGRESS → magenta
 *   ROI → cinza tracejado
 */
class DebugOverlayView(context: Context) : View(context) {

    var snapshot: VisionDebugSnapshot? = null

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 26f
        typeface = Typeface.MONOSPACE
        setShadowLayer(4f, 1f, 1f, Color.BLACK)
    }
    private val panel = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC04070E.toInt() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val snap = snapshot ?: return
        val scaleX = if (snap.frameWidth > 0) width.toFloat() / snap.frameWidth else 1f
        val scaleY = if (snap.frameHeight > 0) height.toFloat() / snap.frameHeight else 1f

        fun sx(v: Float) = v * scaleX
        fun sy(v: Float) = v * scaleY

        // ROI configurada
        snap.roi?.let { roi ->
            stroke.color = Color.parseColor("#94A3B8")
            stroke.pathEffect = android.graphics.DashPathEffect(floatArrayOf(12f, 10f), 0f)
            canvas.drawRect(sx(roi.left.toFloat()), sy(roi.top.toFloat()), sx(roi.right.toFloat()), sy(roi.bottom.toFloat()), stroke)
            stroke.pathEffect = null
        }

        // MAIN BAR
        snap.mainBar?.takeIf { it.valid }?.let { bar ->
            stroke.color = CYAN
            canvas.drawRect(sx(bar.left), sy(bar.top), sx(bar.right), sy(bar.bottom), stroke)
            label(canvas, "MAIN BAR ${"%.2f".format(bar.confidence)}", sx(bar.left), sy(bar.top) - 8f, CYAN)
        }

        // ZONE
        snap.zone?.takeIf { it.valid }?.let { zone ->
            stroke.color = AMBER
            canvas.drawRect(sx(zone.left), sy(zone.top), sx(zone.right), sy(zone.bottom), stroke)
            label(canvas, "ZONE ${"%.2f".format(zone.confidence)}", sx(zone.left), sy(zone.bottom) + 34f, AMBER)
        }

        // FISH MARKER (linha vertical + caixa)
        snap.fish?.takeIf { it.valid }?.let { fish ->
            stroke.color = GREEN
            val left = sx(fish.boundingBox.left.toFloat())
            val right = sx(fish.boundingBox.right.toFloat())
            val top = sy(fish.boundingBox.top.toFloat())
            val bottom = sy(fish.boundingBox.bottom.toFloat())
            canvas.drawRect(left, top, right, bottom, stroke)
            canvas.drawLine(
                sx(fish.centerX), top - 60f,
                sx(fish.centerX), bottom + 20f,
                stroke,
            )
            label(canvas, "FISH ${"%.2f".format(fish.confidence)}", left, top - 8f, GREEN)
        }

        // PROGRESS BAR
        snap.progress.takeIf { it.valid }?.let { progress ->
            stroke.color = MAGENTA
            canvas.drawRect(sx(progress.left), sy(progress.top), sx(progress.right), sy(progress.bottom), stroke)
            val fillText = progress.fillFraction?.let { "FILL ${"%.2f".format(it)}" } ?: "FILL --"
            label(canvas, "PROGRESS $fillText", sx(progress.left), sy(progress.bottom) + 34f, MAGENTA)
        }

        drawTextPanel(canvas, snap)
    }

    private fun label(canvas: Canvas, textValue: String, x: Float, y: Float, color: Int) {
        text.color = color
        canvas.drawText(textValue, x.coerceAtLeast(4f), y.coerceIn(34f, height - 4f), text)
    }

    /** Painel textual com TODOS os valores reais (§21/§22/§23). */
    private fun drawTextPanel(canvas: Canvas, snap: VisionDebugSnapshot) {
        val lines = DebugTextFormatter.lines(snap)
        val lineHeight = 30f
        val padding = 14f
        var maxWidth = 0f
        for (line in lines) {
            val w = text.measureText(line)
            if (w > maxWidth) maxWidth = w
        }
        val panelHeight = lines.size * lineHeight + padding * 2
        canvas.drawRect(0f, 0f, maxWidth + padding * 2, panelHeight, panel)
        var y = padding + lineHeight - 8f
        lines.forEachIndexed { index, line ->
            text.color = if (index == 0) CYAN else Color.parseColor("#E2E8F0")
            canvas.drawText(line, padding, y, text)
            y += lineHeight
        }
    }

    private companion object {
        const val CYAN = 0xFF22D3EE.toInt()
        const val AMBER = 0xFFFBBF24.toInt()
        const val GREEN = 0xFF34D399.toInt()
        const val MAGENTA = 0xFFE879F9.toInt()
    }
}
