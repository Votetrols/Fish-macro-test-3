package com.fischvision.macro.vision.detect

import com.fischvision.macro.capture.Frame
import com.fischvision.macro.capture.RgbaFramePayload
import com.fischvision.macro.vision.IntRect
import com.fischvision.macro.vision.Normalization
import com.fischvision.macro.vision.RoiConfig
import com.fischvision.macro.vision.RoiSample

/**
 * Pipeline de visão da Fase 7 (§6), em ordem explícita:
 *
 *     ROI → amostragem → MAIN BAR → ZONA → PEIXE → PROGRESSO → normalização
 *
 * Este é o ponto onde os detectores se conhecem: a barra é encontrada primeiro
 * e os outros três trabalham DENTRO/DEPOIS dela, o que reduz falsos positivos e
 * custo (§40). Nada aqui emite comando: a saída é medição pura.
 *
 * Reuso e custo:
 *  - UMA amostragem da ROI por frame ([RoiSample], buffers reutilizados);
 *  - UMA máscara estrutural por frame ([BandScanner.ensureMask]);
 *  - nenhum `Bitmap` intermediário, nenhuma cópia da tela inteira.
 *
 * Não é thread-safe: um consumidor por instância (o pipeline de calibração).
 */
class FishingVisionAnalyzer(
    val config: VisionConfig = VisionConfig.DEFAULT,
    /** ROI configurável do minigame (§7). */
    private val roiConfig: RoiConfig = RoiConfig.MINIGAME_REFERENCE,
    /** Margem (unidades normalizadas) do critério PEIXE ∈ ZONA (§14). */
    private val zoneMarginNormalized: Float = 0.015f,
) {

    private val sample = RoiSample()

    /**
     * Época do frame analisado — chave do cache de máscara estrutural.
     * Incrementada a cada análise; ver BandScanner.ensureMask.
     */
    private var frameEpoch = 0L
    private val scanner = BandScanner(config)
    private val mainBarDetector = MainBarDetector(config, scanner)
    private val zoneDetector = InteractionZoneDetector(config)
    private val fishDetector = FishMarkerDetector(config)
    private val progressDetector = ProgressBarDetector(config, scanner)

    /** ROI configurada em pixels do último frame analisado. */
    var lastRoi: IntRect? = null
        private set

    /**
     * Amostra do ÚLTIMO frame analisado — buffers reutilizados.
     *
     * ATENÇÃO: o conteúdo é válido apenas até o próximo [analyze] do MESMO
     * analisador (é o que evita alocação por frame). Consumidores que precisem
     * guardar informação devem copiar os números (o debug overlay recebe o
     * [com.fischvision.macro.debug.VisionDebugSnapshot], não a amostra).
     */
    val currentSample: RoiSample get() = sample

    fun analyze(frame: Frame, frameIndex: Long): FishingVisionFrame {
        val startNanos = System.nanoTime()
        val payload = frame.payload as? RgbaFramePayload
        if (payload == null) {
            return emptyFrame(frame, frameIndex, 0L)
        }
        val result = analyzePayload(
            payload = payload,
            frameWidth = frame.width,
            frameHeight = frame.height,
            timestampNanos = frame.timestampNanos,
            frameIndex = frameIndex,
        )
        return result.copy(processingNanos = System.nanoTime() - startNanos)
    }

    fun analyzePayload(
        payload: RgbaFramePayload,
        frameWidth: Int,
        frameHeight: Int,
        timestampNanos: Long,
        frameIndex: Long = 0L,
    ): FishingVisionFrame {
        val startNanos = System.nanoTime()
        val epoch = ++frameEpoch
        val roi = try {
            roiConfig.resolve(frameWidth, frameHeight)
        } catch (e: IllegalArgumentException) {
            null
        } ?: return emptyFrame(frameWidth, frameHeight, timestampNanos, frameIndex, 0L)

        if (!sample.sample(payload, roi, config.sampleStep, timestampNanos)) {
            return emptyFrame(frameWidth, frameHeight, timestampNanos, frameIndex, System.nanoTime() - startNanos)
        }
        lastRoi = roi

        val mainBar = selectMainBar(mainBarDetector.detectCandidates(sample, roi, epoch))
        val zone = zoneDetector.detect(sample, mainBar)
        val fish = fishDetector.detect(sample, mainBar)
        val progress = progressDetector.detect(sample, mainBar, roi, epoch)

        val relation = Normalization.zoneRelation(
            fishNormalizedX = fish.takeIf { it.valid }?.normalizedX(mainBar),
            zoneNormalizedLeft = zone.takeIf { it.valid }?.normalizedLeft(mainBar),
            zoneNormalizedRight = zone.takeIf { it.valid }?.normalizedRight(mainBar),
            marginNormalized = zoneMarginNormalized,
        )

        return FishingVisionFrame(
            frameIndex = frameIndex,
            timestampNanos = timestampNanos,
            frameWidth = frameWidth,
            frameHeight = frameHeight,
            roi = roi,
            mainBar = mainBar,
            zone = zone.takeIf { it.valid },
            fish = fish.takeIf { it.valid },
            progress = progress,
            fishInsideZone = relation.inside,
            zoneMarginNormalized = zoneMarginNormalized,
            processingNanos = System.nanoTime() - startNanos,
        )
    }

    /**
     * Escolha da MAIN_BAR entre faixas candidatas (§8/§16).
     *
     * Regra: vence a de maior confidence; porém, se existir outra faixa com
     * ALTURA ≥ 15% maior cuja confidence está a menos de 0.15 da vencedora,
     * a mais espessa é promovida. É esta regra que impede a barra de progresso
     * (fina, logo abaixo) de ser eleita barra principal.
     */
    private fun selectMainBar(candidates: List<MainBarDetection>): MainBarDetection? {
        val provisional = candidates.firstOrNull() ?: return null
        var chosen = provisional
        for (candidate in candidates) {
            if (candidate === provisional) continue
            val thicker = candidate.height >= provisional.height * 1.15f
            val closeEnough = candidate.confidence >= provisional.confidence - 0.15f
            if (thicker && closeEnough && candidate.height > chosen.height) chosen = candidate
        }
        return chosen
    }

    private fun emptyFrame(
        frame: Frame,
        frameIndex: Long,
        nanos: Long,
    ): FishingVisionFrame = emptyFrame(frame.width, frame.height, frame.timestampNanos, frameIndex, nanos)

    private fun emptyFrame(
        width: Int,
        height: Int,
        timestampNanos: Long,
        frameIndex: Long,
        nanos: Long,
    ): FishingVisionFrame = FishingVisionFrame(
        frameIndex = frameIndex,
        timestampNanos = timestampNanos,
        frameWidth = width,
        frameHeight = height,
        roi = null,
        mainBar = null,
        zone = null,
        fish = null,
        progress = ProgressBarDetection.UNKNOWN,
        fishInsideZone = false,
        zoneMarginNormalized = zoneMarginNormalized,
        processingNanos = nanos,
    )

    /** ROI configurada em pixels para o frame informado (usada pelo overlay). */
    fun resolveRoi(frameWidth: Int, frameHeight: Int): IntRect? =
        try {
            roiConfig.resolve(frameWidth, frameHeight)
        } catch (e: IllegalArgumentException) {
            null
        }
}
