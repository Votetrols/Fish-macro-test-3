package com.fischvision.macro.tracker

/**
 * Observação genérica de uma entidade rastreada (posição + confiança).
 *
 * Existe porque a Fase 7 rastreia TRÊS entidades com tipos de detecção
 * diferentes (MAIN_BAR, INTERACTION_ZONE, FISH_MARKER) e o rastreador não deve
 * conhecer nenhum deles — só posição e confiança.
 */
data class TrackObservation(
    val centerX: Float,
    val centerY: Float,
    val confidence: Float,
    val timestampNanos: Long,
) {
    init {
        require(confidence in 0f..1f) { "confidence fora de [0,1]: $confidence" }
    }
}

/**
 * Estado de uma entidade rastreada (Fase 7, §17).
 *
 *  IDLE → ACQUIRING → VALID → TRACKING
 *                        ↑         │
 *                        └── LOST ←┘   (perda além de [maxLostFrames])
 *
 * `VALID` = posição confiável mas ainda com histórico curto;
 * `TRACKING` = histórico suficiente e atualizado neste frame;
 * `LOST` = sumiu por mais frames que a janela permitida (§18) — a partir daí
 * NENHUM input seria permitido (nas fases em que houver input).
 */
enum class TrackState { IDLE, ACQUIRING, VALID, TRACKING, LOST }

/** Fotografia do estado de rastreamento — usada pelo debug overlay (§21). */
data class EntityTrackSnapshot(
    val name: String,
    val state: TrackState,
    val centerX: Float,
    val centerY: Float,
    val confidence: Float,
    val age: Int,
    val lastSeenFrame: Long,
    val missedFrames: Int,
    val velocityXPxPerSec: Float,
) {
    val valid: Boolean get() = state == TrackState.VALID || state == TrackState.TRACKING
}

/**
 * Rastreador de UMA entidade (Fase 7, §17/§18).
 *
 * Diferente do [EmaTargetTracker] da Fase 4 (que modela um único alvo e
 * devolve TrackingResult), este rastreador expõe o ciclo VALID/TRACKING/LOST
 * com `age`, `lastSeenFrame`, `missedFrames` e RECUPERAÇÃO — exatamente o que
 * a fase pede para MAIN_BAR, ZONE e FISH.
 *
 * Algoritmo:
 *  - associação por proximidade: um candidato só é aceito se estiver a menos de
 *    [maxAssociationDistancePx] da posição suavizada (anti-teleporte);
 *  - suavização EMA de posição ([alphaPosition]) e velocidade por diferença;
 *  - aquisição exige [acquireFrames] frames coerentes — evita fixar alvo em
 *    ruído de um único frame;
 *  - ausência de detecção conta para [maxLostFrames]; ultrapassado o limite, o
 *    estado passa a LOST e a recuperação recomeça pela aquisição.
 *
 * Zero alocação por frame. Kotlin puro — testável em JVM.
 */
class EntityTracker(
    val name: String,
    /** Janela de tolerância de perda, em frames (§18). Configurável, não mágica. */
    private val maxLostFrames: Int = 8,
    private val maxAssociationDistancePx: Float = 220f,
    private val acquireFrames: Int = 2,
    private val alphaPosition: Float = 0.5f,
) {
    init {
        require(maxLostFrames >= 0) { "maxLostFrames negativo" }
        require(acquireFrames >= 1) { "acquireFrames deve ser >= 1" }
        require(alphaPosition in 0f..1f) { "alphaPosition fora de [0,1]" }
    }

    var state: TrackState = TrackState.IDLE
        private set

    var centerX: Float = 0f
        private set
    var centerY: Float = 0f
        private set
    var confidence: Float = 0f
        private set
    var velocityXPxPerSec: Float = 0f
        private set

    /** Frames consecutivos com atualização válida desde a aquisição. */
    var age: Int = 0
        private set

    /** Índice do último frame em que a entidade foi vista. */
    var lastSeenFrame: Long = -1L
        private set

    var missedFrames: Int = 0
        private set

    private var consecutiveMisses = 0
    private var acquisitionCount = 0
    private var lastTimestampNanos = 0L
    private var rawX = 0f
    private var rawY = 0f

    /** Entidade utilizável (posição fresca o suficiente). */
    val valid: Boolean get() = state == TrackState.VALID || state == TrackState.TRACKING

    val lost: Boolean get() = state == TrackState.LOST

    /**
     * Alimenta uma detecção. Retorna `true` quando a observação foi ACEITA
     * (seja para aquisição, seja para atualização), `false` quando rejeitada
     * por distância/timestamp — nesse caso o estado não é corrompido.
     */
    fun update(observation: TrackObservation, frameIndex: Long, timestampNanos: Long): Boolean {
        when (state) {
            TrackState.IDLE, TrackState.LOST -> {
                startAcquisition(observation, frameIndex, timestampNanos)
                return true
            }
            TrackState.ACQUIRING -> {
                if (!withinAssociationRange(observation)) {
                    // aquisição reiniciada a partir da nova observação confiável
                    startAcquisition(observation, frameIndex, timestampNanos)
                    return true
                }
                acquisitionCount++
                applyObservation(observation, frameIndex, timestampNanos)
                if (acquisitionCount >= acquireFrames) state = TrackState.VALID
                return true
            }
            TrackState.VALID, TrackState.TRACKING -> {
                if (!withinAssociationRange(observation)) {
                    // salto maior que o permitido: tratado como ausência, não como alvo
                    miss(frameIndex)
                    return false
                }
                applyObservation(observation, frameIndex, timestampNanos)
                state = TrackState.TRACKING
                return true
            }
        }
    }

    /** Frame sem detecção para esta entidade (§18). */
    fun miss(frameIndex: Long) {
        if (state == TrackState.IDLE) return
        missedFrames++
        consecutiveMisses++
        if (consecutiveMisses > maxLostFrames) {
            state = TrackState.LOST
        } else if (state == TrackState.ACQUIRING) {
            // aquisição interrompida volta ao início, sem virar LOST ainda
            acquisitionCount = 0
        }
        lastSeenFrame = if (lastSeenFrame < 0) frameIndex else lastSeenFrame
    }

    /** Observa o frame mesmo sem detecção: `observation == null` conta perda. */
    fun observe(frameIndex: Long, timestampNanos: Long, observation: TrackObservation?): Boolean =
        if (observation == null) {
            miss(frameIndex)
            false
        } else {
            update(observation, frameIndex, timestampNanos)
        }

    fun reset() {
        state = TrackState.IDLE
        centerX = 0f
        centerY = 0f
        confidence = 0f
        velocityXPxPerSec = 0f
        age = 0
        lastSeenFrame = -1L
        missedFrames = 0
        consecutiveMisses = 0
        acquisitionCount = 0
        lastTimestampNanos = 0L
    }

    fun snapshot(): EntityTrackSnapshot = EntityTrackSnapshot(
        name = name,
        state = state,
        centerX = centerX,
        centerY = centerY,
        confidence = confidence,
        age = age,
        lastSeenFrame = lastSeenFrame,
        missedFrames = missedFrames,
        velocityXPxPerSec = velocityXPxPerSec,
    )

    private fun startAcquisition(observation: TrackObservation, frameIndex: Long, timestampNanos: Long) {
        centerX = observation.centerX
        centerY = observation.centerY
        rawX = observation.centerX
        rawY = observation.centerY
        confidence = observation.confidence
        velocityXPxPerSec = 0f
        age = 0
        missedFrames = 0
        consecutiveMisses = 0
        acquisitionCount = 1
        lastSeenFrame = frameIndex
        lastTimestampNanos = timestampNanos
        state = if (acquireFrames <= 1) TrackState.VALID else TrackState.ACQUIRING
    }

    private fun applyObservation(observation: TrackObservation, frameIndex: Long, timestampNanos: Long) {
        val dt = timestampNanos - lastTimestampNanos
        if (dt > 0L) {
            val dtSec = dt / 1_000_000_000f
            val instantVelocity = (observation.centerX - rawX) / dtSec
            velocityXPxPerSec = 0.35f * instantVelocity + 0.65f * velocityXPxPerSec
        }
        centerX = alphaPosition * observation.centerX + (1f - alphaPosition) * centerX
        centerY = alphaPosition * observation.centerY + (1f - alphaPosition) * centerY
        rawX = observation.centerX
        rawY = observation.centerY
        confidence = observation.confidence
        age++
        missedFrames = 0
        consecutiveMisses = 0
        lastSeenFrame = frameIndex
        lastTimestampNanos = timestampNanos
    }

    private fun withinAssociationRange(observation: TrackObservation): Boolean {
        val dx = observation.centerX - centerX
        val dy = observation.centerY - centerY
        val distanceSquared = dx * dx + dy * dy
        return distanceSquared <= maxAssociationDistancePx * maxAssociationDistancePx
    }
}
