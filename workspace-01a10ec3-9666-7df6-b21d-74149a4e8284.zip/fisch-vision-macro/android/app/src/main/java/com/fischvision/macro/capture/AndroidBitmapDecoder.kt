package com.fischvision.macro.capture

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

/**
 * Decodificador de frames gravados usando apenas plataforma Android
 * (`BitmapFactory`) — nenhuma dependência nova foi adicionada para o replay
 * de frames da Fase 7 (§36).
 */
class AndroidBitmapDecoder : RecordedFrameDecoder {

    override fun decode(file: File): DecodedFrame? {
        val bitmap = try {
            BitmapFactory.decodeFile(file.absolutePath)
        } catch (e: Exception) {
            null
        } ?: return null
        val width = bitmap.width
        val height = bitmap.height
        if (width <= 0 || height <= 0) {
            bitmap.recycle()
            return null
        }
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        bitmap.recycle()
        return DecodedFrame(pixels, width, height)
    }
}
