package com.fischvision.macro.debug

import com.fischvision.macro.tracker.EntityTrackSnapshot
import com.fischvision.macro.tracker.TrackState
import com.fischvision.macro.vision.IntRect
import com.fischvision.macro.vision.Normalization
import com.fischvision.macro.vision.outcome.MinigameOutcomeDetector
import com.fischvision.macro.vision.detect.FishMarkerDetection
import com.fischvision.macro.vision.detect.InteractionZoneDetection
import com.fischvision.macro.vision.detect.MainBarDetection
import com.fischvision.macro.vision.detect.ProgressBarDetection

/**
 * Fotografia do estado completo de visão em um frame (Fase 7, §20–§23).
 *
 * É o ÚNICO objeto que o overlay de debug consome: ele já vem com coordenadas
 * de pixel, valores normalizados, confidences reais, estado de tracking, estado
 * da FSM, contadores de frame/tempo e o estado de INPUT. Nada é recalculado no
 * Android, nada é inventado — o texto do overlay é derivado daqui por
 * [DebugTextFormatter] (Kotlin puro, testável em JVM).
 */
data class VisionDebugSnapshot(
    val frameIndex: Long,
    val timestampMillis: Long,
    val fps: Double,
    val frameWidth: Int,
    val frameHeight: Int,
    val roi: IntRect?,
    val mainBar: MainBarDetection?,
    val zone: InteractionZoneDetection?,
    val fish: FishMarkerDetection?,
    val progress: ProgressBarDetection,
    val fishInsideZone: Boolean,
    val zoneMarginNormalized: Float,
    val tracks: List<EntityTrackSnapshot>,
    val fsmState: String,
    val inputState: String,
    val outcome: MinigameOutcomeDetector.Outcome?,
    val processingMillis: Double,
    val lostFrames: Int,
) {
    val mainBarTrack: EntityTrackSnapshot?
        get() = tracks.firstOrNull { it.name == TRACK_MAIN_BAR }
    val zoneTrack: EntityTrackSnapshot?
        get() = tracks.firstOrNull { it.name == TRACK_ZONE }
    val fishTrack: EntityTrackSnapshot?
        get() = tracks.firstOrNull { it.name == TRACK_FISH }

    /**
     * Estado de tracking publicado no HUD — prioriza a entidade mais crítica:
     * LOST > TRACKING > VALID > ACQUIRING > IDLE. Assim o painel nunca mostra
     * "IDLE" enquanto entidades estão sendo adquiridas.
     */
    val trackState: TrackState
        get() {
            val order = listOf(fishTrack, zoneTrack, mainBarTrack)
            val priorities = listOf(
                TrackState.LOST,
                TrackState.TRACKING,
                TrackState.VALID,
                TrackState.ACQUIRING,
            )
            priorities.forEach { wanted ->
                order.forEach { t ->
                    if (t != null && t.state == wanted) return wanted
                }
            }
            return TrackState.IDLE
        }

    fun trackSnapshot(name: String): EntityTrackSnapshot? = tracks.firstOrNull { it.name == name }

    companion object {
        const val TRACK_MAIN_BAR = "MAIN_BAR"
        const val TRACK_ZONE = "ZONE"
        const val TRACK_FISH = "FISH"
    }
}

/**
 * Formata o snapshot no texto do debug overlay (§21/§22/§23).
 *
 * IMPORTANTE: todos os números aqui vêm do snapshot. Esta classe não estima,
 * não suaviza e não arredonda "para parecer bonito" — se uma entidade não foi
 * detectada, o texto mostra `--` em vez de um valor fictício.
 *
 * Os valores normalizados são calculados contra as bordas da MAIN BAR com
 * [Normalization] (mesma classe usada pela lógica de decisão), portanto o que o
 * HUD mostra é exatamente o que o pipeline usou.
 */
object DebugTextFormatter {

    /** Largura das linhas no painel do overlay (View usa monoespaçada). */
    const val PANEL_TITLE = "FISCH DEBUG"

    fun lines(snapshot: VisionDebugSnapshot): List<String> {
        val bar = snapshot.mainBar
        val zone = snapshot.zone
        val fish = snapshot.fish
        val progress = snapshot.progress.takeIf { it.valid }
        val out = ArrayList<String>(24)

        out += PANEL_TITLE
        out += "FRAME ${snapshot.frameIndex}   T ${snapshot.timestampMillis} ms   FPS ${"%.1f".format(snapshot.fps)}"

        // ---------------- MAIN BAR
        //
        // A barra é mostrada em coordenadas da ROI (a referência 0→1 da própria
        // barra seria trivialmente 0→1). ZONE e FISH usam a referência da barra,
        // como manda o §15.
        val roiRef = snapshot.roi
        out += if (bar != null && bar.valid && roiRef != null) {
            val leftNorm = Normalization.xOrNull(bar.left, roiRef.left.toFloat(), roiRef.right.toFloat())
            val rightNorm = Normalization.xOrNull(bar.right, roiRef.left.toFloat(), roiRef.right.toFloat())
            "MAIN BAR: X ${Normalization.format(leftNorm)} → ${Normalization.format(rightNorm)} (ROI)  CONF ${Normalization.format(bar.confidence)}"
        } else if (bar != null && bar.valid) {
            "MAIN BAR: CONF ${Normalization.format(bar.confidence)}"
        } else {
            "MAIN BAR: NOT FOUND"
        }
        if (bar != null && bar.valid) {
            out += "  PIXELS L ${bar.left.toInt()} R ${bar.right.toInt()} T ${bar.top.toInt()} B ${bar.bottom.toInt()}"
        }

        // ---------------- ZONE
        out += if (zone != null && zone.valid) {
            val nl = zone.normalizedLeft(bar)
            val nr = zone.normalizedRight(bar)
            val nc = zone.normalizedCenter(bar)
            "ZONE: X ${Normalization.format(nl)} → ${Normalization.format(nr)}  CENTER ${Normalization.format(nc)}  CONF ${Normalization.format(zone.confidence)}"
        } else {
            "ZONE: NOT FOUND"
        }
        if (zone != null && zone.valid) {
            out += "  PIXELS L ${zone.left.toInt()} R ${zone.right.toInt()}  TONE ${toneLabel(zone)}"
        }

        // ---------------- FISH
        out += if (fish != null && fish.valid) {
            "FISH: X ${Normalization.format(fish.normalizedX(bar))}  CONF ${Normalization.format(fish.confidence)}"
        } else {
            "FISH: NOT FOUND"
        }
        if (fish != null && fish.valid) {
            out += "  Pixel X: ${fish.centerX.toInt()}   Normalized X: ${Normalization.format(fish.normalizedX(bar), 3)}"
            out += "  LINE ${Normalization.format(fish.lineEvidence)}  ICON ${Normalization.format(fish.iconEvidence)}"
        }

        // ---------------- PROGRESS (§16: UNKNOWN é resposta legítima)
        out += if (progress != null) {
            val fill = progress.fillFraction?.let { Normalization.format(it) } ?: "--"
            "PROGRESS: X ${progress.left.toInt()} → ${progress.right.toInt()}  FILL $fill  CONF ${Normalization.format(progress.confidence)}"
        } else {
            "PROGRESS: UNKNOWN"
        }

        // ---------------- relação peixe/zona
        out += "FISH IN ZONE: ${if (snapshot.fishInsideZone) "YES" else "NO"}   MARGIN ${Normalization.format(snapshot.zoneMarginNormalized, 3)}"

        // ---------------- tracking
        val barTrack = snapshot.mainBarTrack
        val zoneTrack = snapshot.zoneTrack
        val fishTrack = snapshot.fishTrack
        out += "TRACK: ${snapshot.trackState.name}   LOST-FRAMES ${snapshot.lostFrames}"
        out += trackLine("  BAR ", barTrack)
        out += trackLine("  ZONE", zoneTrack)
        out += trackLine("  FISH", fishTrack)

        // ---------------- FSM / input / outcome
        out += "FSM: ${snapshot.fsmState}"
        out += "INPUT: ${snapshot.inputState}"
        snapshot.outcome?.let { outcome ->
            out += "OUTCOME: ${outcome.signal.name}  CONF ${Normalization.format(outcome.confidence)}"
            out += "  ${outcome.reason}"
        }
        out += "VISION ${"%.1f".format(snapshot.processingMillis)} ms   ROI ${snapshot.roi?.let { "${it.width}x${it.height}" } ?: "--"}"
        return out
    }

    private fun toneLabel(zone: InteractionZoneDetection): String {
        val w = zone.warmthDominance
        return when {
            w >= 0.6f -> "ORANGE"
            w <= 0.25f -> "WHITE"
            else -> "MIXED"
        }
    }

    private fun trackLine(label: String, track: EntityTrackSnapshot?): String {
        if (track == null) return "$label: --"
        return "$label: ${track.state.name} X ${track.centerX.toInt()} AGE ${track.age} CONF ${Normalization.format(track.confidence)}"
    }
}
