package com.fischvision.macro.vision

import com.fischvision.macro.capture.RgbaFramePayload

/**
 * Amostragem da ROI com BUFFERS REUTILIZADOS (Fase 7, §40 — performance).
 *
 * Motivo: os quatro detectores da Fase 7 (barra, zona, peixe, progresso)
 * precisam das mesmas informações banais do mesmo frame. Sem esta classe, cada
 * detector faria sua própria varredura de pixels e chamaria `argbAt` milhares
 * de vezes por frame. Aqui a ROI é varrida UMA vez por frame para quatro
 * canais reaproveitados entre frames (nunca realocados se a ROI não crescer):
 *
 *  - [luma] .......... luminância 0..255 (77R+150G+29B)>>8
 *  - [warmth] ........ R − B (−255..255): separa zona alaranjada de zona branca
 *                      sem depender de um único perfil HSV (Fase 7, §5/§39)
 *  - [value] ......... máximo canal 0..255 (brilho puro, insensível a matiz)
 *
 * A classe não é thread-safe por design: UM consumidor (o pipeline de visão)
 * por instância. Documentado em PHASE_7_STATUS.md > Limitações.
 *
 * Kotlin puro — nenhuma dependência de Android.
 */
class RoiSample {
    var roiLeft: Int = 0
        private set
    var roiTop: Int = 0
        private set
    var roiRight: Int = 0
        private set
    var roiBottom: Int = 0
        private set

    /** Passo de amostragem em pixels (1 = pixel a pixel). */
    var step: Int = 1
        private set

    /** Largura/altura em CÉLULAS amostradas (não em pixels). */
    var width: Int = 0
        private set
    var height: Int = 0
        private set

    /** Timestamp do frame amostrado (para checagens de consistência). */
    var timestampNanos: Long = 0L
        private set

    /** Metadados de fundo estimados durante [sample] (estatística robusta). */
    var backgroundLuma: Float = 0f
        private set
    var backgroundSpread: Float = 0f
        private set
    var framePixelsSampled: Int = 0
        private set

    private var luma = IntArray(0)
    private var warmth = IntArray(0)
    private var value = IntArray(0)

    val cellCount: Int get() = width * height

    fun lumaAt(x: Int, y: Int): Int = luma[y * width + x]
    fun warmthAt(x: Int, y: Int): Int = warmth[y * width + x]
    fun valueAt(x: Int, y: Int): Int = value[y * width + x]

    /** Converte coordenada de célula → pixel absoluto do frame. */
    fun pixelX(cellX: Int): Int = roiLeft + cellX * step
    fun pixelY(cellY: Int): Int = roiTop + cellY * step
    fun cellToPixelX(cells: Float): Float = roiLeft + cells * step

    /**
     * Varre a ROI do payload para os buffers internos.
     *
     * @return true quando houve amostragem; false quando a ROI/step são
     *         degenerados ou o payload não entrega pixels (frame inválido).
     */
    fun sample(payload: RgbaFramePayload, roi: IntRect, step: Int = 1, timestampNanos: Long = 0L): Boolean {
        val s = step.coerceAtLeast(1)
        val w = (roi.width + s - 1) / s
        val h = (roi.height + s - 1) / s
        if (w <= 0 || h <= 0) return false

        ensureCapacity(w * h)
        this.step = s
        this.width = w
        this.height = h
        this.roiLeft = roi.left
        this.roiTop = roi.top
        this.roiRight = roi.right
        this.roiBottom = roi.bottom
        this.timestampNanos = timestampNanos

        var sampled = 0
        for (cy in 0 until h) {
            val py = roi.top + cy * s
            for (cx in 0 until w) {
                val px = roi.left + cx * s
                val idx = cy * w + cx
                val argb = payload.argbAt(px, py)
                if (argb == null) {
                    luma[idx] = INVALID
                    warmth[idx] = 0
                    value[idx] = INVALID
                    continue
                }
                val r = (argb shr 16) and 0xFF
                val g = (argb shr 8) and 0xFF
                val b = argb and 0xFF
                luma[idx] = (77 * r + 150 * g + 29 * b) shr 8
                warmth[idx] = r - b
                value[idx] = maxOf(r, g, b)
                sampled++
            }
        }
        framePixelsSampled = sampled
        if (sampled == 0) return false

        estimateBackground()
        return true
    }

    /**
     * Estatística de fundo: mediana (robusta a elementos do UI) das linhas
     * externas da ROI + desvio absoluto mediano para escalar contrastes.
     * Assim os limiares dos detectores acompanham cena clara/escura/brilhante.
     */
    private fun estimateBackground() {
        val rows = height
        val edgeRows = ((rows * 0.12f).toInt()).coerceAtLeast(1)
        val samples = ArrayList<Int>(edgeRows * 2 * width)
        for (y in 0 until rows) {
            if (y >= edgeRows && y < rows - edgeRows) continue
            for (x in 0 until width) {
                val v = luma[y * width + x]
                if (v != INVALID) samples.add(v)
            }
        }
        if (samples.isEmpty()) {
            for (i in 0 until cellCount) if (luma[i] != INVALID) samples.add(luma[i])
        }
        if (samples.isEmpty()) {
            backgroundLuma = 0f
            backgroundSpread = 0f
            return
        }
        samples.sort()
        val median = samples[samples.size / 2].toFloat()
        val deviations = ArrayList<Int>(samples.size)
        for (v in samples) deviations.add(kotlin.math.abs(v - median).toInt())
        deviations.sort()
        backgroundLuma = median
        backgroundSpread = deviations[deviations.size / 2].toFloat()
    }

    /** Mediana da luminância de uma linha amostrada (ignora inválidos). */
    fun rowMedianLuma(cy: Int, scratch: ArrayList<Int>): Float {
        scratch.clear()
        for (cx in 0 until width) {
            val v = luma[cy * width + cx]
            if (v != INVALID) scratch.add(v)
        }
        if (scratch.isEmpty()) return backgroundLuma
        scratch.sort()
        return scratch[scratch.size / 2].toFloat()
    }

    /** Mediana de um canal (luma/warmth/value) numa faixa de células. */
    fun median(scratch: ArrayList<Int>, channel: Int, x0: Int, x1: Int, y0: Int, y1: Int): Float {
        scratch.clear()
        for (y in y0 until y1) {
            for (x in x0 until x1) {
                val v = channelValue(channel, x, y)
                if (v != INVALID) scratch.add(v)
            }
        }
        if (scratch.isEmpty()) return 0f
        scratch.sort()
        return scratch[scratch.size / 2].toFloat()
    }

    fun channelValue(channel: Int, x: Int, y: Int): Int = when (channel) {
        CHANNEL_LUMA -> luma[y * width + x]
        CHANNEL_WARMTH -> warmth[y * width + x]
        else -> value[y * width + x]
    }

    private fun ensureCapacity(cells: Int) {
        if (luma.size < cells) {
            luma = IntArray(cells)
            warmth = IntArray(cells)
            value = IntArray(cells)
        }
    }

    companion object {
        const val CHANNEL_LUMA = 0
        const val CHANNEL_WARMTH = 1
        const val CHANNEL_VALUE = 2
        const val INVALID = -1
    }
}
