package com.fischvision.macro.capture

import kotlinx.coroutines.flow.Flow

/**
 * Eventos de ciclo de vida da CAPTURA (Fase 7, §29).
 *
 * O ciclo obrigatório é:
 *
 *     MediaProjection.onStop()
 *        ↓  (a fonte se encerra e libera o display/reader)
 *     ProjectionStopped
 *        ↓
 *     FSM (MacroStateMachine + MacroEvent.ProjectionStopped)
 *        ↓
 *     releaseAll() — nenhum dedo virtual fica preso
 *        ↓
 *     estado seguro (IDLE)
 *
 * O evento existe como contrato SEPARADO do fluxo de frames porque um frame é
 * dado e um encerramento é ciclo de vida: misturar os dois faria o pipeline
 * tratar "captura morreu" como "frame sem detecção".
 */
sealed interface CaptureEvent {

    /** A projeção foi encerrada (usuário, sistema ou revogação). Terminal. */
    data object ProjectionStopped : CaptureEvent

    /** Falha tipada de captura em runtime (não fatal para o app, fatal para a sessão). */
    data class Failure(val type: CaptureException.Type, val message: String) : CaptureEvent
}

/**
 * Fonte de frames que também publica eventos de ciclo de vida.
 *
 * Implementada por [MediaProjectionFrameSource]. Consumidores que só precisam de
 * frames continuam usando [FrameSource] — nada muda para eles (compatibilidade
 * preservada: nenhum contrato da Fase 1/2 foi alterado).
 */
interface CaptureEventSource {
    fun captureEvents(): Flow<CaptureEvent>
}
