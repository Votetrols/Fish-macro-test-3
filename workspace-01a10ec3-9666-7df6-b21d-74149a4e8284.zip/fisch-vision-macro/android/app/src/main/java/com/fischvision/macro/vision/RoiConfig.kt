package com.fischvision.macro.vision

/**
 * ROI do minigame ancorada em FRAÇÕES do frame (Fase 7, §7).
 *
 * Regra de projeto: nada de `barLeft = 380` / `barRight = 1240` permanentes.
 * Os quatro parâmetros abaixo são percentuais do frame capturado, portanto
 * valem para qualquer resolução/rotação — a origem dos números é apenas
 * calibração inicial (ver [MINIGAME_REFERENCE]).
 *
 * RELAÇÃO DE DEPENDÊNCIA: nenhuma classe Android. Testável em JVM.
 */
data class RoiConfig(
    /** Borda esquerda, fração da largura do frame (0..1). */
    val leftPercent: Float,
    /** Borda superior, fração da altura do frame (0..1). */
    val topPercent: Float,
    /** Largura, fração da largura do frame (> 0). */
    val widthPercent: Float,
    /** Altura, fração da altura do frame (> 0). */
    val heightPercent: Float,
) {
    init {
        require(leftPercent in 0f..1f) { "leftPercent fora de [0,1]: $leftPercent" }
        require(topPercent in 0f..1f) { "topPercent fora de [0,1]: $topPercent" }
        require(widthPercent > 0f) { "widthPercent deve ser > 0: $widthPercent" }
        require(heightPercent > 0f) { "heightPercent deve ser > 0: $heightPercent" }
        require(leftPercent + widthPercent <= 1.0001f) { "ROI ultrapassa a largura do frame" }
        require(topPercent + heightPercent <= 1.0001f) { "ROI ultrapassa a altura do frame" }
    }

    val rightPercent: Float get() = leftPercent + widthPercent
    val bottomPercent: Float get() = topPercent + heightPercent

    /** Converte a ROI para pixels do frame informado. */
    fun resolve(frameWidth: Int, frameHeight: Int): IntRect {
        val w = frameWidth.coerceAtLeast(1)
        val h = frameHeight.coerceAtLeast(1)
        val left = (leftPercent * w).toInt().coerceIn(0, w - 1)
        val top = (topPercent * h).toInt().coerceIn(0, h - 1)
        val right = (rightPercent * w).toInt().coerceIn(left + 1, w)
        val bottom = (bottomPercent * h).toInt().coerceIn(top + 1, h)
        return IntRect(left, top, right, bottom)
    }

    fun scaled(factor: Float): RoiConfig = RoiConfig(
        leftPercent = leftPercent,
        topPercent = topPercent,
        widthPercent = (widthPercent * factor).coerceAtMost(1f - leftPercent),
        heightPercent = (heightPercent * factor).coerceAtMost(1f - topPercent),
    )

    companion object {
        /**
         * Ponto de partida NÃO CALIBRADO EM DISPOSITIVO, derivado apenas das
         * observações geométricas do vídeo de referência:
         *
         *   barra principal ≈ X 380..1240  ·  Y 735..805  em 1920×1080
         *   → frações: X 0.198..0.646 · Y 0.680..0.745
         *
         * A ROI precisa cobrir, além da barra: o ícone/marcador do peixe ACIMA
         * da barra e a barra de progresso ABAIXO. Daí as margens assimétricas:
         *
         *   left   = 0.198 − 0.058 = 0.140   (margem 5.8% da largura)
         *   top    = 0.680 − 0.100 = 0.580   (margem 10% da altura p/ o ícone)
         *   width  = 0.646 − 0.198 + 2·0.106 = 0.660
         *   height = 0.745 − 0.680 + 0.100 + 0.135 = 0.300
         *
         * Qualquer diferença de enquadramento/escala do vídeo real é absorvida
         * por [com.fischvision.macro.settings.MacroSettings] (percentuais
         * editáveis) — nunca por coordenada absoluta no detector.
         */
        val MINIGAME_REFERENCE = RoiConfig(
            leftPercent = 0.140f,
            topPercent = 0.580f,
            widthPercent = 0.660f,
            heightPercent = 0.300f,
        )
    }
}
