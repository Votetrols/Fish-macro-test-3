package com.fischvision.macro.debug

/**
 * Logging por EVENTO (Fase 7, §41).
 *
 * Regra: o pipeline roda a ~30 fps e NÃO pode imprimir centenas de linhas por
 * segundo. Em vez de logar por frame, o sistema publica EVENTOS de transição
 * (BAR_ACQUIRED, ZONE_ACQUIRED, FISH_ACQUIRED, TRACK_LOST, SUCCESS, ERROR) com
 * supressão de repetições e teto por segundo.
 *
 * Kotlin puro — o destino (Logcat) entra por [Sink], o que torna o
 * comportamento verificável em teste JVM.
 */
object MacroEventKind {
    const val BAR_ACQUIRED = "BAR_ACQUIRED"
    const val ZONE_ACQUIRED = "ZONE_ACQUIRED"
    const val FISH_ACQUIRED = "FISH_ACQUIRED"
    const val TRACK_LOST = "TRACK_LOST"
    const val TRACK_RECOVERED = "TRACK_RECOVERED"
    const val SUCCESS = "SUCCESS"
    const val FAILED = "FAILED"
    const val PROGRESS_UNKNOWN = "PROGRESS_UNKNOWN"
    const val ERROR = "ERROR"
    const val CALIBRATION_STATE = "CALIBRATION_STATE"
}

/** Saída de log — produção liga ao [DebugLogger]; testes, a uma lista. */
fun interface EventSink {
    fun emit(kind: String, message: String)
}

class EventLogger(
    private val sink: EventSink,
    /** Janela mínima entre duas publicações do MESMO evento (ms). */
    private val minIntervalMillisPerEvent: Long = 1_000L,
    /** Teto global de eventos por segundo (proteção contra spam). */
    private val maxEventsPerSecond: Int = 8,
    private val clock: () -> Long = { System.nanoTime() },
) {
    private val lastEmitPerKind = HashMap<String, Long>(16)
    private var windowStartNanos = 0L
    private var windowCount = 0

    var suppressed = 0
        private set

    fun emit(kind: String, message: String) {
        val now = clock()
        val windowNanos = 1_000_000_000L
        if (windowStartNanos == 0L || now - windowStartNanos >= windowNanos) {
            windowStartNanos = now
            windowCount = 0
        }
        if (windowCount >= maxEventsPerSecond) {
            suppressed++
            return
        }
        val last = lastEmitPerKind[kind]
        val minIntervalNanos = minIntervalMillisPerEvent * 1_000_000L
        if (last != null && now - last < minIntervalNanos) {
            suppressed++
            return
        }
        lastEmitPerKind[kind] = now
        windowCount++
        sink.emit(kind, message)
    }

    /**
     * Publica apenas quando o estado muda — o padrão usado pelos eventos de
     * aquisição/perda (evita repetir BAR_ACQUIRED a cada frame).
     */
    fun emitOnChange(kind: String, currentState: String, message: String) {
        val key = "state:$kind"
        val previous = lastState[key]
        if (previous == currentState) {
            suppressed++
            return
        }
        lastState[key] = currentState
        emit(kind, message)
    }

    fun reset() {
        lastEmitPerKind.clear()
        lastState.clear()
        windowStartNanos = 0L
        windowCount = 0
        suppressed = 0
    }

    private val lastState = HashMap<String, String>(16)
}
