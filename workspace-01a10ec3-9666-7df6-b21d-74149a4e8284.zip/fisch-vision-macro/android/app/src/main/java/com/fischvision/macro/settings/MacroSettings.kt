package com.fischvision.macro.settings

import com.fischvision.macro.vision.RoiConfig

/**
 * Configuração do macro — estrutura + defaults.
 *
 * ATENÇÃO (regra 19): estes são DEFAULTS CONSERVADORES de ponto de partida.
 * NÃO são valores validados em aparelho e NÃO devem ser tratados como ideais;
 * a validação acontece com frames reais e a edição será feita na tela de
 * configurações (DataStore).
 *
 * FASE 7 — o que mudou nesta estrutura:
 *  - a ROI do minigame passou a ser explicitamente configurável em percentuais
 *    ([roiLeftPercent] … [roiHeightPercent]), conforme §7;
 *  - [calibrationMode] liga captura+visão+tracking+overlay com INPUT travado (§25);
 *  - [inputEnabled] é a trava da fase: permanece `false` — o input NÃO é
 *    habilitado nesta fase (§0, §26);
 *  - [zoneEdgeMarginPercent] substitui qualquer "número mágico" do critério
 *    PEIXE ∈ ZONA (§14);
 *  - [maxLostFrames] é a janela de tolerância de perda de tracking (§18);
 *  - gravação de frames de debug é explícita e desligada por padrão (§24).
 *
 * @status IMPLEMENTED + UNIT TEST (defaults cobertos em ContractsTest e fase 7)
 */
data class MacroSettings(
    /** Largura do buffer de captura (paisagem). Reduz carga de CPU/memória. */
    val captureWidth: Int = 960,
    /** Altura do buffer de captura (paisagem). */
    val captureHeight: Int = 540,
    /** Alvo de frames por segundo da captura. Conservador para médio/baixo. */
    val targetFps: Int = 10,
    /** HUD de debug (legado da Fase 6: painel de status curto). */
    val debugEnabled: Boolean = false,
    /** Controller desligado por padrão: nenhum comando sai sem opt-in. */
    val controllerEnabled: Boolean = false,

    // ------------------------------------------------- Fase 7 — ROI do minigame
    /** Borda esquerda da ROI, fração da largura do frame. */
    val roiLeftPercent: Float = 0.140f,
    /** Borda superior da ROI, fração da altura do frame. */
    val roiTopPercent: Float = 0.580f,
    /** Largura da ROI, fração da largura do frame. */
    val roiWidthPercent: Float = 0.660f,
    /** Altura da ROI, fração da altura do frame. */
    val roiHeightPercent: Float = 0.300f,

    // ------------------------------------------------ Fase 7 — decisão/segurança
    /** Margem (normalizada) do critério `zoneLeft <= fishX <= zoneRight` (§14). */
    val zoneEdgeMarginPercent: Float = 0.015f,
    /** Janela de frames sem detecção antes de declarar TRACK_LOST (§18). */
    val maxLostFrames: Int = 8,
    /** Confidence mínima agregada usada pela camada de decisão e pela guarda. */
    val minConfidence: Float = 0.40f,
    /** Modo de calibração: CAPTURE + VISION + TRACKING + OVERLAY ON, INPUT OFF (§25). */
    val calibrationMode: Boolean = true,
    /** Trava explícita de input da fase — permanece false até a fase de controle. */
    val inputEnabled: Boolean = false,
    /** Pacote esperado em foreground antes de qualquer input (§28). */
    val targetAppPackage: String = "com.roblox.client",

    // ------------------------------------------------- Fase 7 — debug/captura
    /** Overlay de debug da visão (retângulos + texto). Ligado no modo calibração. */
    val visionOverlayEnabled: Boolean = true,
    /** Gravação de frames de debug: DESLIGADA por padrão (§24). */
    val debugFrameCaptureEnabled: Boolean = false,
    /** Quando ligada, grava 1 frame a cada N (além dos frames de evento). */
    val debugFrameCaptureEveryNFrames: Int = 30,
    /** Teto de frames salvos por sessão. */
    val debugFrameCaptureMax: Int = 20,
) {
    init {
        require(captureWidth > 0 && captureHeight > 0) { "resolução de captura inválida" }
        require(targetFps in 1..60) { "targetFps fora de [1,60]" }
        require(maxLostFrames >= 0) { "maxLostFrames negativo" }
        require(minConfidence in 0f..1f) { "minConfidence fora de [0,1]" }
        require(zoneEdgeMarginPercent in 0f..0.5f) { "margem de zona fora de [0,0.5]" }
        require(targetAppPackage.isNotBlank()) { "pacote alvo vazio" }
        // Valida a ROI aqui: configuração incoerente falha ao construir, não em runtime.
        roiConfig()
    }

    /** ROI do minigame derivada desta configuração (§7). */
    fun roiConfig(): RoiConfig = RoiConfig(
        leftPercent = roiLeftPercent,
        topPercent = roiTopPercent,
        widthPercent = roiWidthPercent,
        heightPercent = roiHeightPercent,
    )

    companion object {
        val DEFAULT: MacroSettings = MacroSettings()
    }
}
