package com.fischvision.macro.vision.detect

import com.fischvision.macro.vision.IntRect
import com.fischvision.macro.vision.RoiSample
import kotlin.math.abs
import kotlin.math.max

/**
 * Detector do MARCADOR DO PEIXE (Fase 7, §12/§13).
 *
 * O marcador é tratado como ENTIDADE PRÓPRIA: nunca é a zona preenchida. Duas
 * características o definem:
 *
 *  1. LINHA VERTICAL — desvio estreito e persistente ao longo da altura
 *     (`lineEvidence`). É a característica PRINCIPAL, conforme §13: a posição
 *     do marcador vertical vale mais que reconhecer o desenho do peixe;
 *  2. ÍCONE DE PEIXE — blob ACIMA da barra, usado só como EVIDÊNCIA ADICIONAL
 *     (`iconEvidence`). O detector funciona sem ele (ícone oculto, desfocado ou
 *     coberto por partículas), porque o ícone apenas soma peso — nunca é portão.
 *
 * COMO O MARCADOR NÃO É CONFUNDIDO COM A ZONA (ambos são verticais):
 *  - a zona é um PATAMAR largo de colunas com desvio alto; o marcador é um
 *    ESPIGÃO estreito. O `spike` (coluna menos vizinhança) é ~0 no patamar;
 *  - portão de largura: candidato mais largo que 3% da barra é rejeitado;
 *  - penalidade de borda de zona: candidato colado a patamar largo perde
 *    [VisionConfig.fishZoneEdgePenalty], salvo se o ícone acima o confirmar.
 */
class FishMarkerDetector(private val config: VisionConfig = VisionConfig.DEFAULT) {

    // Buffers reutilizados entre frames (nenhuma alocação por frame).
    private var columnDeviation = FloatArray(0)
    private var columnWarmthDeviation = FloatArray(0)
    private var spikeScore = FloatArray(0)
    private var narrowBandSaliency = FloatArray(0)
    private var aboveEvidenceByColumn = FloatArray(0)
    private var rowBaselineLuma = FloatArray(0)
    private var rowBaselineWarmth = FloatArray(0)
    private var aboveBaselineLuma = FloatArray(0)
    private val scratch = ArrayList<Int>(256)

    fun detect(sample: RoiSample, bar: MainBarDetection?): FishMarkerDetection {
        if (bar == null || !bar.valid || bar.width <= 0f || bar.height <= 0f) return FishMarkerDetection.ABSENT
        if (sample.cellCount <= 0 || sample.framePixelsSampled <= 0) return FishMarkerDetection.ABSENT

        val step = sample.step
        val leftCell = cellOf(bar.left, sample.roiLeft, step)
        val rightCell = cellOf(bar.right, sample.roiLeft, step)
        val topCell = cellOf(bar.top, sample.roiTop, step)
        val bottomCell = cellOf(bar.bottom, sample.roiTop, step)
        if (rightCell - leftCell < 5 || bottomCell - topCell < 4) return FishMarkerDetection.ABSENT

        // Interior da barra (as bordas são do contorno, não do marcador).
        val subInset = max(1, ((bottomCell - topCell) * 0.10f).toInt())
        val y0 = (topCell + subInset).coerceAtMost(bottomCell - 2)
        val y1 = (bottomCell - subInset).coerceAtLeast(y0 + 1)
        val columns = rightCell - leftCell
        val rows = y1 - y0
        if (columns < 5 || rows < 3) return FishMarkerDetection.ABSENT

        val contrastUnit = maxOf(config.minAbsoluteContrast, config.contrastSpreadFactor * sample.backgroundSpread)
        val threshold = contrastUnit

        ensureCapacity(columns, sample.height)

        // 1) linha base por linha (mediana dentro da barra) — remove a largura
        //    do "trilho" e mantém a zona como desvio relativo.
        for (y in y0 until y1) {
            rowBaselineLuma[y] = sample.median(scratch, RoiSample.CHANNEL_LUMA, leftCell, rightCell, y, y + 1)
            rowBaselineWarmth[y] = sample.median(scratch, RoiSample.CHANNEL_WARMTH, leftCell, rightCell, y, y + 1)
        }

        // 2) desvio médio por coluna (luminância e calor) dentro da barra.
        java.util.Arrays.fill(columnDeviation, 0, columns, 0f)
        java.util.Arrays.fill(columnWarmthDeviation, 0, columns, 0f)
        for (i in 0 until columns) {
            val x = leftCell + i
            var lumaSum = 0f
            var warmSum = 0f
            var n = 0
            for (y in y0 until y1) {
                val l = sample.lumaAt(x, y)
                if (l == RoiSample.INVALID) continue
                lumaSum += abs(l - rowBaselineLuma[y])
                warmSum += max(0f, sample.warmthAt(x, y) - rowBaselineWarmth[y])
                n++
            }
            if (n > 0) {
                columnDeviation[i] = lumaSum / n
                columnWarmthDeviation[i] = (warmSum / n) * config.zoneWarmthWeight
            }
        }
        // O desvio "efetivo" é o máximo dos dois canais (zona branca OU alaranjada).
        for (i in 0 until columns) {
            if (columnWarmthDeviation[i] > columnDeviation[i]) columnDeviation[i] = columnWarmthDeviation[i]
        }

        // 3) spike: coluna menos vizinhança → elimina patamares largos (zona).
        computeSpikes(columns)

        // 4) evidência acima da barra (ícone) — AUXILIAR (§13).
        val aboveCells = max(1, ((bottomCell - topCell) * config.fishAboveBarSearchPercent).toInt())
        val aboveY0 = (topCell - aboveCells).coerceAtLeast(0)
        val aboveY1 = topCell
        var aboveRows = 0
        java.util.Arrays.fill(aboveEvidenceByColumn, 0, columns, 0f)
        if (aboveY1 > aboveY0) {
            for (y in aboveY0 until aboveY1) {
                aboveBaselineLuma[y] = sample.median(scratch, RoiSample.CHANNEL_LUMA, leftCell, rightCell, y, y + 1)
            }
            for (i in 0 until columns) {
                val x = leftCell + i
                var sum = 0f
                for (y in aboveY0 until aboveY1) {
                    val l = sample.lumaAt(x, y)
                    if (l == RoiSample.INVALID) continue
                    sum += abs(l - aboveBaselineLuma[y])
                }
                aboveEvidenceByColumn[i] = (sum / (aboveY1 - aboveY0) / contrastUnit).coerceIn(0f, 1f)
            }
            aboveRows = aboveY1 - aboveY0
        }

        // 5) candidatos por SALIÊNCIA DE FAIXA ESTREITA.
        //
        //    Por que não basta "run de colunas com desvio alto": quando o peixe
        //    está DENTRO da zona clara, as colunas do peixe se fundem ao patamar
        //    da zona e deixam de ser um run estreito (medido no diagnóstico).
        //    A saliência compara cada coluna com a linha de base dos DOIS lados,
        //    então funciona nos dois casos:
        //      · linha sobre o trilho escuro  → a própria linha é a faixa estreita;
        //      · linha sobre a zona clara     → o contorno escuro da linha é a
        //        faixa estreita (e os dois contornos são unificados adiante).
        val maxMarkerCells = max(1, (bar.width * config.fishMaxWidthPercentOfBar / step).toInt())
        val exclusionCells = max(1, (columns * config.fishEndExclusionPercentOfBar).toInt())
        val searchFrom = exclusionCells.coerceAtLeast(0)
        val searchTo = (columns - exclusionCells).coerceAtMost(columns)
        computeNarrowBandSaliency(columns, maxMarkerCells)
        var best: FishMarkerDetection? = null

        // 5a) sementes → grupos → unificação de grupos próximos
        val seeds = ArrayList<Int>(8)
        for (x in searchFrom until searchTo) {
            if (narrowBandSaliency[x] >= config.fishNarrowBandThreshold &&
                columnDeviation[x] >= threshold * 0.6f
            ) {
                seeds.add(x)
            }
        }
        val groups = ArrayList<IntArray>(4) // [start, endInclusive]
        var current = -1
        var index = 0
        while (index < seeds.size) {
            val seed = seeds[index]
            if (current < 0 || seed - current > 1) {
                groups.add(intArrayOf(seed, seed))
            } else {
                groups.last()[1] = seed
            }
            current = seed
            index++
        }

        var g = 0
        while (g < groups.size) {
            var start = groups[g][0]
            var end = groups[g][1]
            // unifica com o próximo grupo quando o vão é pequeno (contornos da
            // mesma linha vertical separados pelo corpo da linha)
            var next = g + 1
            while (next < groups.size && groups[next][0] - end <= 2) {
                end = groups[next][1]
                next++
            }
            var len = end - start + 1
            if (len > maxMarkerCells) {
                // grupo largo: recorta em torno do pico de desvio
                var peak = start
                for (x in start..end) if (columnDeviation[x] > columnDeviation[peak]) peak = x
                start = (peak - maxMarkerCells / 2).coerceAtLeast(searchFrom)
                end = (start + maxMarkerCells - 1).coerceAtMost(searchTo - 1)
                len = end - start + 1
            }
            if (len >= 1) {
                val candidate = buildCandidate(
                    sample = sample,
                    bar = bar,
                    leftCell = leftCell,
                    y0 = y0,
                    y1 = y1,
                    columns = columns,
                    start = start,
                    len = len,
                    threshold = threshold,
                    contrastUnit = contrastUnit,
                    iconRows = aboveRows,
                )
                if (candidate != null && (best == null || candidate.confidence > best.confidence)) best = candidate
            }
            g = next
        }

        val detection = best ?: FishMarkerDetection.ABSENT
        return if (detection.valid && detection.confidence >= config.fishMinConfidence) detection
        else FishMarkerDetection.ABSENT
    }

    private fun buildCandidate(
        sample: RoiSample,
        bar: MainBarDetection,
        leftCell: Int,
        y0: Int,
        y1: Int,
        columns: Int,
        start: Int,
        len: Int,
        threshold: Float,
        contrastUnit: Float,
        iconRows: Int,
    ): FishMarkerDetection? {
        // Continuidade vertical: linhas do interior com desvio acima de 50% do limiar.
        var coveredRows = 0
        var topRow = -1
        var bottomRow = -1
        for (y in y0 until y1) {
            var sum = 0f
            var n = 0
            for (k in start until start + len) {
                val l = sample.lumaAt(leftCell + k, y)
                if (l == RoiSample.INVALID) continue
                sum += abs(l - rowBaselineLuma[y])
                n++
            }
            if (n == 0) continue
            if (sum / n >= threshold * 0.5f) {
                coveredRows++
                if (topRow < 0) topRow = y
                bottomRow = y
            }
        }
        val rowsTotal = (y1 - y0).coerceAtLeast(1)
        val verticalContinuity = coveredRows.toFloat() / rowsTotal
        if (verticalContinuity < config.fishMinVerticalContinuity) return null

        var spikeSum = 0f
        var devSum = 0f
        var iconSum = 0f
        for (k in start until start + len) {
            spikeSum += spikeScore[k]
            devSum += columnDeviation[k]
            iconSum += aboveEvidenceByColumn[k]
        }
        val spike = (spikeSum / len).coerceIn(0f, 1f)
        val contrastNorm = ((devSum / len) / (contrastUnit * 1.5f)).coerceIn(0f, 1f)
        val icon = if (iconRows == 0) 0f else (iconSum / len).coerceIn(0f, 1f)
        val narrowness = (1f - (len.toFloat() / maxMarkerCellsFor(bar, sample.step)).coerceAtLeast(1f)).coerceIn(0f, 1f)

        val zoneEdge = isAdjacentToWidePlateau(start, len, columns, threshold)
        var confidence = verticalContinuity * 0.34f +
            spike * 0.26f +
            icon * 0.20f +
            narrowness * 0.12f +
            contrastNorm * 0.08f
        if (zoneEdge && icon < 0.5f) confidence -= config.fishZoneEdgePenalty
        confidence = confidence.coerceIn(0f, 1f)

        val xLeftPx = sample.pixelX(leftCell + start)
        val xRightPx = sample.pixelX(leftCell + start + len).coerceAtLeast(xLeftPx + 1)
        val markerTopPx = sample.pixelY(topRow.coerceAtLeast(y0))
        val markerBottomPx = sample.pixelY((bottomRow + 1).coerceAtLeast(y0 + 1)).coerceAtLeast(markerTopPx + 1)
        val box = IntRect(xLeftPx, markerTopPx, xRightPx, markerBottomPx)

        return FishMarkerDetection(
            boundingBox = box,
            markerTop = markerTopPx.toFloat(),
            markerBottom = markerBottomPx.toFloat(),
            confidence = confidence,
            valid = true,
            iconEvidence = icon,
            lineEvidence = verticalContinuity,
            criteria = FishMarkerDetection.Criteria(
                verticalContinuity = verticalContinuity,
                narrownessScore = narrowness,
                spikeScore = spike,
                isolationScore = (spike * 0.6f + narrowness * 0.4f).coerceIn(0f, 1f),
            ),
        )
    }

    private fun maxMarkerCellsFor(bar: MainBarDetection, step: Int): Float =
        max(1f, bar.width * config.fishMaxWidthPercentOfBar / step)

    /**
     * Saliência de faixa estreita: compara o desvio de cada coluna com a linha
     * de base local calculada dos DOIS lados (excluindo o próprio miolo da
     * faixa). Resultado alto = a coluna é um detalhe estreito; ~0 = faz parte de
     * um patamar largo (zona) ou de uma borda única.
     */
    private fun computeNarrowBandSaliency(columns: Int, maxMarkerCells: Int) {
        val half = max(1, maxMarkerCells / 2)
        val window = max(3, columns / 20)
        for (i in 0 until columns) {
            var sum = 0f
            var n = 0
            var k = i - window
            while (k <= i + window) {
                if (k in 0 until columns && (k < i - half || k > i + half)) {
                    sum += columnDeviation[k]
                    n++
                }
                k++
            }
            if (n == 0) {
                narrowBandSaliency[i] = 0f
                continue
            }
            val baseline = sum / n
            val peak = columnDeviation[i]
            val scale = max(peak, baseline).coerceAtLeast(1f)
            narrowBandSaliency[i] = (kotlin.math.abs(peak - baseline) / scale).coerceIn(0f, 1f)
        }
    }

    /**
     * Spike por coluna = desvio da coluna menos a média da vizinhança (±w).
     * Pacotes de colunas largas (zona preenchida) tendem a zero; uma linha
     * vertical isolada (marcador do peixe) permanece alta.
     */
    private fun computeSpikes(columns: Int) {
        val w = max(3, columns / 12)
        for (i in 0 until columns) {
            var sum = 0f
            var n = 0
            var k = i - w
            while (k <= i + w) {
                if (k != i && k in 0 until columns) {
                    sum += columnDeviation[k]
                    n++
                }
                k++
            }
            val neighborhood = if (n == 0) 0f else sum / n
            val peak = columnDeviation[i]
            spikeScore[i] = if (peak <= 0f) 0f else ((peak - neighborhood) / peak).coerceIn(0f, 1f)
        }
    }

    /**
     * Candidato é BORDA de um patamar largo (borda da zona)?
     *
     * Critério correto — medido no diagnóstico da fase: uma borda de zona tem o
     * patamar de UM LADO só. A linha do peixe dentro da zona tem patamar dos DOIS
     * lados (é um detalhe interno da zona, não seu contorno) e por isso NÃO deve
     * ser penalizada; caso contrário o detector de peixe ficaria dependente do
     * ícone justamente quando o peixe está na zona — o que contraria §13.
     */
    private fun isAdjacentToWidePlateau(start: Int, len: Int, columns: Int, threshold: Float): Boolean {
        val minPlateau = max(2, (columns * 0.05f).toInt())
        val leftPlateau = plateauExtent(start - 1, columns, threshold, -1) >= minPlateau
        val rightPlateau = plateauExtent(start + len, columns, threshold, +1) >= minPlateau
        return leftPlateau != rightPlateau
    }

    /** Extensão contígua de colunas acima do limiar a partir de [from], na direção [step]. */
    private fun plateauExtent(from: Int, columns: Int, threshold: Float, step: Int): Int {
        var extent = 0
        var k = from
        while (k in 0 until columns && columnDeviation[k] >= threshold) {
            extent++
            k += step
        }
        return extent
    }

    private fun ensureCapacity(columns: Int, rows: Int) {
        if (columnDeviation.size < columns) {
            columnDeviation = FloatArray(columns)
            columnWarmthDeviation = FloatArray(columns)
            spikeScore = FloatArray(columns)
            narrowBandSaliency = FloatArray(columns)
            aboveEvidenceByColumn = FloatArray(columns)
        }
        if (rowBaselineLuma.size < rows) {
            rowBaselineLuma = FloatArray(rows)
            rowBaselineWarmth = FloatArray(rows)
            aboveBaselineLuma = FloatArray(rows)
        }
    }

    private fun cellOf(px: Float, origin: Int, step: Int): Int = ((px - origin) / step).toInt()
}
