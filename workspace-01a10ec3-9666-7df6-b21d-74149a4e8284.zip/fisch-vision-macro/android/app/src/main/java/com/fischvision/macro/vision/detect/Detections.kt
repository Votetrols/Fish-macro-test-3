package com.fischvision.macro.vision.detect

import com.fischvision.macro.vision.IntRect
import com.fischvision.macro.vision.Normalization

/**
 * Objetos de detecção da Fase 7 (§8/§10/§12/§16).
 *
 * Todos carregam `confidence` calculada a partir dos critérios REAIS do
 * detector (nunca um número inventado, §19) e uma flag `valid`, de modo que
 * "ausente" é um resultado explícito e não uma exceção ou um valor fictício.
 *
 * Interfaces puramente matemáticas (Kotlin puro) — o overlay Android consome
 * estes tipos, nunca o contrário.
 */

/** Resultado do detector da BARRA PRINCIPAL. */
data class MainBarDetection(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val confidence: Float,
    val valid: Boolean = true,
    /** Evidência auxiliar dos marcadores triangulares nas extremidades (§9). */
    val endMarkers: Boolean = false,
    /** Detalhes auditáveis do score (mostrados no log de debug). */
    val criteria: Criteria = Criteria(),
) {
    data class Criteria(
        val continuity: Float = 0f,
        val aspectScore: Float = 0f,
        val verticalScore: Float = 0f,
        val borderEdgeScore: Float = 0f,
        val fillScore: Float = 0f,
    )

    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val aspect: Float get() = if (height <= 0f) 0f else width / height

    companion object {
        val INVALID = MainBarDetection(0f, 0f, 0f, 0f, 0f, valid = false)
    }
}

/** Resultado do detector da ZONA/ÁREA DE INTERAÇÃO dentro da barra. */
data class InteractionZoneDetection(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val confidence: Float,
    val valid: Boolean = true,
    /** 0 = branca/clara, 1 = alaranjada — característica AUXILIAR, não critério único. */
    val warmthDominance: Float = 0f,
    val criteria: Criteria = Criteria(),
) {
    data class Criteria(
        val columnConsistency: Float = 0f,
        val verticalConsistency: Float = 0f,
        val sizeScore: Float = 0f,
        val isolationScore: Float = 0f,
        val contrastMargin: Float = 0f,
    )

    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f
    val width: Float get() = right - left
    val height: Float get() = bottom - top

    /** Normalização contra a MAIN BAR (§10). Null quando não há barra válida. */
    fun normalizedLeft(bar: MainBarDetection?): Float? =
        bar?.let { Normalization.xOrNull(left, it.left, it.right) }

    fun normalizedRight(bar: MainBarDetection?): Float? =
        bar?.let { Normalization.xOrNull(right, it.left, it.right) }

    fun normalizedCenter(bar: MainBarDetection?): Float? =
        bar?.let { Normalization.xOrNull(centerX, it.left, it.right) }

    companion object {
        val ABSENT = InteractionZoneDetection(0f, 0f, 0f, 0f, 0f, valid = false)
    }
}

/** Resultado do detector do MARCADOR DO PEIXE (linha vertical + ícone). */
data class FishMarkerDetection(
    val boundingBox: IntRect,
    val markerTop: Float,
    val markerBottom: Float,
    val confidence: Float,
    val valid: Boolean = true,
    /** Evidência do ícone de peixe — auxiliar, nunca obrigatória (§13). */
    val iconEvidence: Float = 0f,
    val lineEvidence: Float = 0f,
    val criteria: Criteria = Criteria(),
) {
    data class Criteria(
        val verticalContinuity: Float = 0f,
        val narrownessScore: Float = 0f,
        val spikeScore: Float = 0f,
        val isolationScore: Float = 0f,
    )

    val centerX: Float get() = (boundingBox.left + boundingBox.right) / 2f
    val centerY: Float get() = (boundingBox.top + boundingBox.bottom) / 2f
    val width: Float get() = boundingBox.width.toFloat()

    /** Posição normalizada contra a MAIN BAR (§12). */
    fun normalizedX(bar: MainBarDetection?): Float? =
        bar?.let { Normalization.xOrNull(centerX, it.left, it.right) }

    companion object {
        val ABSENT = FishMarkerDetection(IntRect(0, 0, 1, 1), 0f, 0f, 0f, valid = false)
    }
}

/**
 * Resultado do detector da BARRA DE PROGRESSO (§16).
 * `UNKNOWN` é resposta legítima e preferível a um falso positivo.
 */
data class ProgressBarDetection(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val confidence: Float,
    val valid: Boolean = true,
    /** Fração preenchida da barra (0..1) medida por contraste interno. */
    val fillFraction: Float? = null,
) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val centerX: Float get() = (left + right) / 2f

    companion object {
        val UNKNOWN = ProgressBarDetection(0f, 0f, 0f, 0f, 0f, valid = false, fillFraction = null)
    }
}

/**
 * Leitura completa de um frame pelo pipeline de visão da Fase 7.
 * É este objeto que alimenta tracker → normalização → debug overlay (§6).
 */
data class FishingVisionFrame(
    val frameIndex: Long,
    val timestampNanos: Long,
    val frameWidth: Int,
    val frameHeight: Int,
    val roi: IntRect?,
    val mainBar: MainBarDetection?,
    val zone: InteractionZoneDetection?,
    val fish: FishMarkerDetection?,
    val progress: ProgressBarDetection,
    val fishInsideZone: Boolean,
    val zoneMarginNormalized: Float,
    val processingNanos: Long,
) {
    /** Confiança agregada do frame (mínima entre entidades presentes). */
    val overallConfidence: Float
        get() {
            val values = listOfNotNull(mainBar?.confidence, zone?.confidence, fish?.confidence)
            return if (values.isEmpty()) 0f else values.min()
        }
}
