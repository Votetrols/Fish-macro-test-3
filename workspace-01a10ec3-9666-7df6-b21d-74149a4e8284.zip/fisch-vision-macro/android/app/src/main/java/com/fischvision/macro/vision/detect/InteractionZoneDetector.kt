package com.fischvision.macro.vision.detect

import com.fischvision.macro.vision.RoiSample
import kotlin.math.abs
import kotlin.math.max

/**
 * Detector da ZONA/ÁREA DE INTERAÇÃO dentro da barra principal (Fase 7, §10/§39).
 *
 * MÉTODO — explicitamente multi-característica. A zona do vídeo aparece branca
 * em alguns frames e alaranjada em outros, portanto "tudo que for branco" e
 * "tudo que for laranja" são proibidos como critério único. O detector combina:
 *
 *  1. ASSINATURA POR COLUNA: para cada coluna do interior da barra mede-se a
 *     diferença da coluna contra a MEDIANA das colunas (robusta: a zona ocupa
 *     menos da metade da barra). A diferença é tomada em dois canais:
 *       - luminância  → pega a zona BRANCA/clara;
 *       - R−B (calor) → pega a zona ALARANJADA.
 *     O score da coluna é o máximo dos dois — nenhum dos dois é obrigatório;
 *  2. CONTINUIDADE HORIZONTAL: a zona é um trecho contíguo de colunas; runs com
 *     buracos de 1 coluna são unificados (ruído de compressão);
 *  3. COBERTURA VERTICAL: a zona é preenchida em ≥55% do interior da barra;
 *  4. ISOLAMENTO: o trecho escolhido tem de ser mais forte que a vizinhança —
 *     é o que evita eleger "quase toda a barra";
 *  5. PORTÕES: largura ∈ [5%, 75%] da barra (rejeita ruído e rejeita a barra
 *     inteira) e confidence ≥ [VisionConfig.zoneMinConfidence].
 *
 * A zona se MOVE — nada aqui assume posição central (§10). O acompanhamento
 * temporal é papel do tracker (Fase 7, §11), não do detector.
 */
class InteractionZoneDetector(private val config: VisionConfig = VisionConfig.DEFAULT) {

    private var colLumaMean = FloatArray(0)
    private var colWarmthMean = FloatArray(0)
    private var columnScore = FloatArray(0)
    private var rowDeviation = FloatArray(0)
    private val scratch = ArrayList<Int>(256)

    /**
     * @param bar barra principal já detectada (a busca ocorre DENTRO dela)
     */
    fun detect(sample: RoiSample, bar: MainBarDetection?): InteractionZoneDetection {
        if (bar == null || !bar.valid || bar.width <= 0f || bar.height <= 0f) return InteractionZoneDetection.ABSENT
        if (sample.cellCount <= 0) return InteractionZoneDetection.ABSENT

        val step = sample.step
        val leftCell = cellOf(bar.left, sample.roiLeft, step)
        val rightCell = cellOf(bar.right, sample.roiLeft, step)
        val topCell = cellOf(bar.top, sample.roiTop, step)
        val bottomCell = cellOf(bar.bottom, sample.roiTop, step)
        if (rightCell - leftCell < 3 || bottomCell - topCell < 3) return InteractionZoneDetection.ABSENT

        // 1) interior: ignora as bordas da barra (onde ficam contorno/marcadores)
        val inset = max(1, ((bottomCell - topCell) * config.zoneInteriorInsetPercent).toInt())
        val y0 = (topCell + inset).coerceAtMost(bottomCell - 2)
        val y1 = (bottomCell - inset).coerceAtLeast(y0 + 1)
        val x0 = leftCell
        val x1 = rightCell
        val columns = x1 - x0
        val rows = y1 - y0
        if (columns < 3 || rows < 2) return InteractionZoneDetection.ABSENT

        ensureCapacity(sample.width)

        // 2) assinatura por coluna nos dois canais
        for (i in 0 until columns) {
            val x = x0 + i
            var lumaSum = 0f
            var warmSum = 0f
            var n = 0
            for (y in y0 until y1) {
                val l = sample.lumaAt(x, y)
                if (l == RoiSample.INVALID) continue
                lumaSum += l
                warmSum += sample.warmthAt(x, y)
                n++
            }
            colLumaMean[i] = if (n == 0) 0f else lumaSum / n
            colWarmthMean[i] = if (n == 0) 0f else warmSum / n
        }

        val trackLuma = medianOf(colLumaMean, columns)
        val trackWarmth = medianOf(colWarmthMean, columns)
        val contrastUnit = maxOf(config.minAbsoluteContrast, config.contrastSpreadFactor * sample.backgroundSpread)

        var bestScore = 0f
        for (i in 0 until columns) {
            val lumaDelta = abs(colLumaMean[i] - trackLuma)
            val warmDelta = max(0f, colWarmthMean[i] - trackWarmth) * config.zoneWarmthWeight
            columnScore[i] = (max(lumaDelta, warmDelta) / contrastUnit).coerceIn(0f, 1f)
            if (columnScore[i] > bestScore) bestScore = columnScore[i]
        }
        if (bestScore < config.zoneColumnThreshold) return InteractionZoneDetection.ABSENT

        // 3) runs contíguos (unifica buracos de 1 coluna)
        var runStart = -1
        var runEnd = -1
        var bestStart = -1
        var bestLen = 0
        var gap = 0
        var i = 0
        while (i <= columns) {
            val above = i < columns && columnScore[i] >= config.zoneColumnThreshold
            if (above) {
                if (runStart < 0) runStart = i
                runEnd = i
                gap = 0
            } else if (runStart >= 0) {
                gap++
                if (gap > 1) {
                    val len = runEnd - runStart + 1
                    if (len > bestLen) {
                        bestLen = len
                        bestStart = runStart
                    }
                    runStart = -1
                    gap = 0
                }
            }
            i++
        }
        if (bestStart < 0) return InteractionZoneDetection.ABSENT

        val zoneWidthCells = bestLen
        val zoneWidthPx = zoneWidthCells * step
        val zoneMinPx = config.zoneMinWidthPercentOfBar * bar.width
        val zoneMaxPx = config.zoneMaxWidthPercentOfBar * bar.width
        if (zoneWidthPx < zoneMinPx || zoneWidthPx > zoneMaxPx) return InteractionZoneDetection.ABSENT

        // 4) cobertura vertical + média da assinatura
        var scoreSum = 0f
        for (k in bestStart until bestStart + bestLen) scoreSum += columnScore[k]
        val columnConsistency = scoreSum / bestLen

        var rowsCovered = 0
        var rowDevSum = 0f
        for (y in y0 until y1) {
            var inSum = 0f
            var outSum = 0f
            var inN = 0
            var outN = 0
            for (x in x0 until x1) {
                val l = sample.lumaAt(x, y)
                if (l == RoiSample.INVALID) continue
                if (x >= x0 + bestStart && x < x0 + bestStart + bestLen) {
                    inSum += l
                    inN++
                } else {
                    outSum += l
                    outN++
                }
            }
            if (inN == 0 || outN == 0) continue
            val dev = abs(inSum / inN - outSum / outN)
            rowDeviation[y - y0] = dev
            rowDevSum += dev
            if (dev >= contrastUnit * 0.5f) rowsCovered++
        }
        val coverage = rowsCovered.toFloat() / rows
        if (coverage < config.zoneMinVerticalCoverage) return InteractionZoneDetection.ABSENT

        // 5) isolamento + tamanho + margem de contraste
        val outsideMean = meanOutside(sample, x0, x1, y0, y1, bestStart, bestLen)
        val isolation = ((columnConsistency - outsideMean) / columnConsistency.coerceAtLeast(1e-3f)).coerceIn(0f, 1f)
        val widthFraction = zoneWidthPx / bar.width
        val sizeScore = (1f - abs(widthFraction - config.zonePreferredWidthPercentOfBar) /
            config.zonePreferredWidthPercentOfBar).coerceIn(0f, 1f)
        val peak = peakColumnScore(bestStart, bestLen)
        val contrastMargin = ((peak / config.zoneColumnThreshold) - 1f).coerceIn(0f, 1f)

        // 6) extensão vertical real (onde a assinatura se sustenta)
        var firstRow = -1
        var lastRow = -1
        for (y in 0 until rows) {
            if (rowDeviation[y] >= contrastUnit * 0.5f) {
                if (firstRow < 0) firstRow = y
                lastRow = y
            }
        }
        if (firstRow < 0) return InteractionZoneDetection.ABSENT

        val confidence = (columnConsistency * 0.30f +
            coverage * 0.25f +
            sizeScore * 0.20f +
            isolation * 0.15f +
            contrastMargin * 0.10f).coerceIn(0f, 1f)
        if (confidence < config.zoneMinConfidence) return InteractionZoneDetection.ABSENT

        val zoneLeftPx = sample.pixelX(x0 + bestStart).toFloat()
        val zoneRightPx = sample.pixelX(x0 + bestStart + bestLen).toFloat()
        val zoneTopPx = sample.pixelY(y0 + firstRow).toFloat()
        val zoneBottomPx = sample.pixelY(y0 + lastRow + 1).toFloat()

        // Característica auxiliar de cor (0 = clara/branca, 1 = alaranjada)
        var warmthIn = 0f
        var lumaDevIn = 0f
        for (k in bestStart until bestStart + bestLen) {
            warmthIn += max(0f, colWarmthMean[k] - trackWarmth) * config.zoneWarmthWeight
            lumaDevIn += abs(colLumaMean[k] - trackLuma)
        }
        val warmthDominance = if (warmthIn + lumaDevIn <= 0f) 0f else (warmthIn / (warmthIn + lumaDevIn)).coerceIn(0f, 1f)

        return InteractionZoneDetection(
            left = zoneLeftPx,
            top = zoneTopPx,
            right = zoneRightPx,
            bottom = zoneBottomPx,
            confidence = confidence,
            valid = true,
            warmthDominance = warmthDominance,
            criteria = InteractionZoneDetection.Criteria(
                columnConsistency = columnConsistency,
                verticalConsistency = coverage,
                sizeScore = sizeScore,
                isolationScore = isolation,
                contrastMargin = contrastMargin,
            ),
        )
    }

    private fun peakColumnScore(start: Int, len: Int): Float {
        var peak = 0f
        for (k in start until start + len) if (columnScore[k] > peak) peak = columnScore[k]
        return peak
    }

    private fun meanOutside(
        sample: RoiSample,
        x0: Int,
        x1: Int,
        y0: Int,
        y1: Int,
        runStart: Int,
        runLen: Int,
    ): Float {
        var sum = 0f
        var n = 0
        for (x in x0 until x1) {
            val rel = x - x0
            if (rel in runStart until runStart + runLen) continue
            var col = 0f
            var colN = 0
            for (y in y0 until y1) {
                val l = sample.lumaAt(x, y)
                if (l == RoiSample.INVALID) continue
                col += l
                colN++
            }
            if (colN == 0) continue
            sum += columnScore[x - x0]
            n++
        }
        return if (n == 0) 0f else sum / n
    }

    private fun medianOf(values: FloatArray, count: Int): Float {
        if (count <= 0) return 0f
        scratch.clear()
        for (i in 0 until count) scratch.add(values[i].toInt())
        scratch.sort()
        return scratch[scratch.size / 2].toFloat()
    }

    private fun ensureCapacity(cells: Int) {
        if (colLumaMean.size < cells) {
            colLumaMean = FloatArray(cells)
            colWarmthMean = FloatArray(cells)
            columnScore = FloatArray(cells)
            rowDeviation = FloatArray(cells)
        }
    }

    private fun cellOf(px: Float, origin: Int, step: Int): Int = ((px - origin) / step).toInt()
}
