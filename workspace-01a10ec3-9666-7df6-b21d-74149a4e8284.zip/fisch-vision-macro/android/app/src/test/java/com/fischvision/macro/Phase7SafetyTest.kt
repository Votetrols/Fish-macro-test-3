package com.fischvision.macro

import com.fischvision.macro.core.MacroState
import com.fischvision.macro.debug.EventLogger
import com.fischvision.macro.debug.MacroEventKind
import com.fischvision.macro.input.AccessibilityInputController
import com.fischvision.macro.input.GestureDispatcher
import com.fischvision.macro.input.InputCommand
import com.fischvision.macro.input.InputGateContext
import com.fischvision.macro.input.InputLimits
import com.fischvision.macro.input.InputSafetyContext
import com.fischvision.macro.input.InputSafetyGuard
import com.fischvision.macro.input.InputWiring
import com.fischvision.macro.input.SafetyBlockReason
import com.fischvision.macro.input.SafetyDecision
import com.fischvision.macro.settings.MacroSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * §26/§27/§28/§35 — SEGURANÇA DE INPUT.
 *
 * Matriz exigida: calibration mode · controller disabled · wrong app ·
 * tracking lost · low confidence · projection stopped.
 *
 * O ponto central: mesmo que um módulo chame `execute` por engano, o comando é
 * recusado — e o teste prova isso com um dispatcher que CONTA os eventos.
 */
class Phase7SafetyTest {

    private class CountingDispatcher : GestureDispatcher {
        val events = mutableListOf<String>()
        override fun tap(x: Float, y: Float): Boolean = true.also { events += "tap" }
        override fun holdStart(x: Float, y: Float, maxDurationMillis: Long): Boolean = true.also { events += "holdStart" }
        override fun holdEnd(): Boolean = true.also { events += "holdEnd" }

        val gestures: Int get() = events.count { it != "holdEnd" }
    }

    private class ManualClock(var now: Long = 0L)

    private val expectedPackage = "com.roblox.client"

    private fun context(
        calibrationMode: Boolean = false,
        controllerEnabled: Boolean = true,
        inputEnabled: Boolean = true,
        foregroundPackage: String? = expectedPackage,
        trackingValid: Boolean = true,
        confidence: Float = 0.9f,
        minConfidence: Float = 0.35f,
        fsmAllowsInput: Boolean = true,
        fsmStateName: String = "CONTROLLING",
        projectionActive: Boolean = true,
    ) = InputSafetyContext(
        calibrationMode = calibrationMode,
        controllerEnabled = controllerEnabled,
        inputEnabled = inputEnabled,
        targetAppMatches = foregroundPackage != null && foregroundPackage == expectedPackage,
        foregroundPackage = foregroundPackage,
        expectedPackage = expectedPackage,
        trackingValid = trackingValid,
        confidence = confidence,
        minConfidence = minConfidence,
        fsmAllowsInput = fsmAllowsInput,
        fsmStateName = fsmStateName,
        projectionActive = projectionActive,
    )

    // ------------------------------------------------------------ a guarda

    @Test
    fun `contexto ideal autoriza`() {
        assertEquals(SafetyDecision.Allow, InputSafetyGuard(expectedPackage).evaluate(context()))
    }

    @Test
    fun `calibration mode bloqueia mesmo com tudo o mais habilitado`() {
        val decision = InputSafetyGuard(expectedPackage).evaluate(context(calibrationMode = true))
        assertEquals(SafetyBlockReason.CALIBRATION_MODE, (decision as SafetyDecision.Block).reason)
    }

    @Test
    fun `controller disabled bloqueia`() {
        val decision = InputSafetyGuard(expectedPackage).evaluate(context(controllerEnabled = false))
        assertEquals(SafetyBlockReason.CONTROLLER_DISABLED, (decision as SafetyDecision.Block).reason)
    }

    @Test
    fun `input disabled bloqueia`() {
        val decision = InputSafetyGuard(expectedPackage).evaluate(context(inputEnabled = false))
        assertEquals(SafetyBlockReason.INPUT_DISABLED, (decision as SafetyDecision.Block).reason)
    }

    @Test
    fun `app errado em foreground bloqueia e app desconhecido tambem`() {
        val wrong = InputSafetyGuard(expectedPackage).evaluate(context(foregroundPackage = "com.outro.app"))
        assertEquals(SafetyBlockReason.WRONG_APP, (wrong as SafetyDecision.Block).reason)

        val unknown = InputSafetyGuard(expectedPackage).evaluate(context(foregroundPackage = null))
        assertEquals(
            "foreground desconhecido NUNCA é tratado como app correto",
            SafetyBlockReason.WRONG_APP,
            (unknown as SafetyDecision.Block).reason,
        )
    }

    @Test
    fun `tracking invalido bloqueia`() {
        val decision = InputSafetyGuard(expectedPackage).evaluate(context(trackingValid = false))
        assertEquals(SafetyBlockReason.TRACKING_INVALID, (decision as SafetyDecision.Block).reason)
    }

    @Test
    fun `confidence abaixo do limite bloqueia`() {
        val decision = InputSafetyGuard(expectedPackage).evaluate(context(confidence = 0.2f))
        assertEquals(SafetyBlockReason.LOW_CONFIDENCE, (decision as SafetyDecision.Block).reason)
    }

    @Test
    fun `fsm fora do estado de controle bloqueia`() {
        val decision = InputSafetyGuard(expectedPackage).evaluate(
            context(fsmAllowsInput = false, fsmStateName = "TRACKING"),
        )
        assertEquals(SafetyBlockReason.FSM_STATE, (decision as SafetyDecision.Block).reason)
    }

    @Test
    fun `projecao encerrada bloqueia`() {
        val decision = InputSafetyGuard(expectedPackage).evaluate(context(projectionActive = false))
        assertEquals(SafetyBlockReason.PROJECTION_STOPPED, (decision as SafetyDecision.Block).reason)
    }

    // ------------------------------------- integração guarda + controller

    @Test
    fun `controller fisicamente nao despacha com calibration mode ativo`() {
        val dispatcher = CountingDispatcher()
        val clock = ManualClock()
        val safety = InputSafetyGuard(expectedPackage)
        val controller = AccessibilityInputController(
            dispatcher = dispatcher,
            gate = { InputGateContext(MacroState.CONTROLLING, true, 0.9f, 960, 540) },
            limits = InputLimits(),
            clock = { clock.now },
            safety = safety,
            safetyContext = { context(calibrationMode = true) },
        )

        assertFalse(controller.execute(InputCommand(InputCommand.Action.HOLD_START)))
        assertFalse(controller.execute(InputCommand(InputCommand.Action.TAP)))
        assertEquals("nenhum gesto pode ter saído", 0, dispatcher.gestures)
        assertEquals(SafetyBlockReason.CALIBRATION_MODE, (controller.lastSafetyDecision as SafetyDecision.Block).reason)
    }

    @Test
    fun `controllerEnabled false na configuracao impede o gesto`() {
        val settings = MacroSettings.DEFAULT.copy(
            calibrationMode = false,
            inputEnabled = true,
            controllerEnabled = false,
        )
        val dispatcher = CountingDispatcher()
        val clock = ManualClock()
        val safety = InputSafetyGuard(settings.targetAppPackage)
        val controller = AccessibilityInputController(
            dispatcher = dispatcher,
            gate = { InputGateContext(MacroState.CONTROLLING, true, 0.9f, 960, 540) },
            limits = InputLimits(),
            clock = { clock.now },
            safety = safety,
            safetyContext = {
                InputWiring.safetyContext(
                    settings = settings,
                    foregroundPackage = settings.targetAppPackage,
                    trackingValid = true,
                    confidence = 0.9f,
                    fsmState = MacroState.CONTROLLING,
                    projectionActive = true,
                )
            },
        )
        assertFalse(controller.execute(InputCommand(InputCommand.Action.TAP)))
        assertEquals(0, dispatcher.gestures)
    }

    @Test
    fun `controller habilita o gesto apenas quando todas as condicoes valem`() {
        val settings = MacroSettings.DEFAULT.copy(
            calibrationMode = false,
            inputEnabled = true,
            controllerEnabled = true,
        )
        val dispatcher = CountingDispatcher()
        val clock = ManualClock()
        val controller = AccessibilityInputController(
            dispatcher = dispatcher,
            gate = { InputGateContext(MacroState.CONTROLLING, true, 0.9f, 960, 540) },
            limits = InputLimits(),
            clock = { clock.now },
            safety = InputSafetyGuard(settings.targetAppPackage),
            safetyContext = {
                InputWiring.safetyContext(
                    settings = settings,
                    foregroundPackage = settings.targetAppPackage,
                    trackingValid = true,
                    confidence = 0.9f,
                    fsmState = MacroState.CONTROLLING,
                    projectionActive = true,
                )
            },
        )
        assertTrue(controller.execute(InputCommand(InputCommand.Action.TAP)))
        assertEquals(1, dispatcher.gestures)
    }

    @Test
    fun `releaseAll sempre passa mesmo com a guarda bloqueando`() {
        val dispatcher = CountingDispatcher()
        val controller = AccessibilityInputController(
            dispatcher = dispatcher,
            gate = { InputGateContext(MacroState.ERROR, false, 0f, 960, 540) },
            safety = InputSafetyGuard(expectedPackage),
            safetyContext = { context(calibrationMode = true, projectionActive = false) },
        )
        controller.releaseAll()
        assertTrue("soltar o dedo virtual é fail-safe e não depende da guarda", dispatcher.events.contains("holdEnd"))
    }

    // ------------------------------------------------------- wiring do HUD

    @Test
    fun `modo de calibracao publica INPUT DISABLED`() {
        val settings = MacroSettings.DEFAULT // calibrationMode = true, inputEnabled = false
        val decision = InputSafetyGuard(settings.targetAppPackage).evaluate(
            InputWiring.safetyContext(
                settings = settings,
                foregroundPackage = settings.targetAppPackage,
                trackingValid = true,
                confidence = 0.9f,
                fsmState = MacroState.TRACKING,
                projectionActive = true,
            ),
        )
        assertEquals("DISABLED", InputWiring.hudInputState(settings, decision))
    }

    @Test
    fun `fora da calibracao o HUD mostra o motivo do bloqueio`() {
        val settings = MacroSettings.DEFAULT.copy(
            calibrationMode = false,
            inputEnabled = true,
            controllerEnabled = true,
        )
        val decision = InputSafetyGuard(settings.targetAppPackage).evaluate(
            InputWiring.safetyContext(
                settings = settings,
                foregroundPackage = "com.outro.app",
                trackingValid = true,
                confidence = 0.9f,
                fsmState = MacroState.TRACKING,
                projectionActive = true,
            ),
        )
        assertEquals("BLOCKED (WRONG APP)", InputWiring.hudInputState(settings, decision))
    }

    @Test
    fun `fsm so autoriza input em CONTROLLING`() {
        assertTrue(InputWiring.fsmAllowsInput(MacroState.CONTROLLING))
        listOf(
            MacroState.IDLE,
            MacroState.WAITING_FOR_FISHING_UI,
            MacroState.DETECTING,
            MacroState.TRACKING,
            MacroState.LOST_DETECTION,
            MacroState.PAUSED,
            MacroState.STOPPED,
            MacroState.ERROR,
        ).forEach { state ->
            assertFalse("$state não pode autorizar gesto", InputWiring.fsmAllowsInput(state))
        }
    }

    @Test
    fun `target app gate usa o pacote configurado`() {
        val settings = MacroSettings.DEFAULT.copy(targetAppPackage = "com.exemplo.jogo")
        val context = InputWiring.safetyContext(
            settings = settings,
            foregroundPackage = "com.roblox.client",
            trackingValid = true,
            confidence = 0.9f,
            fsmState = MacroState.CONTROLLING,
            projectionActive = true,
        )
        assertFalse("pacote diferente do configurado bloqueia", context.targetAppMatches)
    }

    @Test
    fun `event logger suprime spam respeitando o teto por segundo`() {
        val clock = ManualClock()
        val published = mutableListOf<String>()
        val logger = EventLogger(
            sink = { kind, _ -> published += kind },
            minIntervalMillisPerEvent = 1_000L,
            maxEventsPerSecond = 3,
            clock = { clock.now },
        )
        repeat(50) { logger.emit(MacroEventKind.FISH_ACQUIRED, "frame $it") }
        assertTrue("eventos repetidos no mesmo milissegundo não podem poluir o log", published.size <= 3)
        assertTrue(logger.suppressed > 0)

        clock.now += 1_000_000_000L
        logger.emit(MacroEventKind.TRACK_LOST, "perda confirmada")
        assertTrue(published.contains(MacroEventKind.TRACK_LOST))
    }

    @Test
    fun `event logger publica por mudanca de estado`() {
        val published = mutableListOf<String>()
        val logger = EventLogger(sink = { _, message -> published += message }, minIntervalMillisPerEvent = 0L)
        logger.emitOnChange(MacroEventKind.BAR_ACQUIRED, "ACQUIRING", "primeira")
        logger.emitOnChange(MacroEventKind.BAR_ACQUIRED, "ACQUIRING", "repetida")
        logger.emitOnChange(MacroEventKind.BAR_ACQUIRED, "TRACKING", "agora firme")
        assertEquals(listOf("primeira", "agora firme"), published)
    }
}
