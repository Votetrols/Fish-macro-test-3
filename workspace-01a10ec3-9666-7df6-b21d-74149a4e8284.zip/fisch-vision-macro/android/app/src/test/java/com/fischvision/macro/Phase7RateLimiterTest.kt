package com.fischvision.macro

import com.fischvision.macro.controller.ControlCommand
import com.fischvision.macro.controller.ControlConfig
import com.fischvision.macro.controller.FishingControllerImpl
import com.fischvision.macro.core.MacroState
import com.fischvision.macro.input.AccessibilityInputController
import com.fischvision.macro.input.GestureDispatcher
import com.fischvision.macro.input.InputCommand
import com.fischvision.macro.input.InputGateContext
import com.fischvision.macro.input.InputLimits
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * §31 — RATE LIMITER. A correção do defeito de `Long.MIN_VALUE` exige cinco
 * testes: primeiro comando · segundo imediato · comando após o intervalo ·
 * reset · release.
 *
 * O defeito (encontrado por leitura de código e reproduzido aqui):
 *  - `lastCommandAtNanos` começava em `Long.MIN_VALUE`, então
 *    `now - lastCommandAtNanos` estoura e devolve NEGATIVO; a comparação
 *    `now - last < minInterval` era verdadeira e o PRIMEIRO comando do processo
 *    era recusado;
 *  - o mesmo padrão existia em `FishingControllerImpl.lastTransitionAtNanos`,
 *    atrasando o primeiro PRESS do controlador.
 */
class Phase7RateLimiterTest {

    private class ManualClock(var now: Long = 1_000_000L)

    private class CountingDispatcher : GestureDispatcher {
        val events = mutableListOf<String>()
        override fun tap(x: Float, y: Float): Boolean = true.also { events += "tap" }
        override fun holdStart(x: Float, y: Float, maxDurationMillis: Long): Boolean = true.also { events += "holdStart" }
        override fun holdEnd(): Boolean = true.also { events += "holdEnd" }
    }

    private fun controller(clock: ManualClock, dispatcher: CountingDispatcher, limits: InputLimits = InputLimits()) =
        AccessibilityInputController(
            dispatcher = dispatcher,
            gate = { InputGateContext(MacroState.CONTROLLING, trackingOk = true, confidence = 0.9f, frameWidth = 960, frameHeight = 540) },
            limits = limits,
            clock = { clock.now },
        )

    @Test
    fun `primeiro comando e aceito sem depender de sentinela aritmetica`() {
        val clock = ManualClock()
        val dispatcher = CountingDispatcher()
        val controller = controller(clock, dispatcher)

        assertTrue(
            "primeiro comando do processo NÃO pode ser recusado (defeito corrigido em §31)",
            controller.execute(InputCommand(InputCommand.Action.TAP)),
        )
        assertEquals(listOf("tap"), dispatcher.events)
    }

    @Test
    fun `segundo comando imediato e suprimido pelo intervalo minimo`() {
        val clock = ManualClock()
        val dispatcher = CountingDispatcher()
        val controller = controller(clock, dispatcher, InputLimits(minIntervalMillis = 50))

        assertTrue(controller.execute(InputCommand(InputCommand.Action.TAP)))
        clock.now += 10_000_000L // 10 ms < 50 ms
        assertFalse("comando dentro do intervalo mínimo deve ser bloqueado", controller.execute(InputCommand(InputCommand.Action.TAP)))
        assertEquals(1, dispatcher.events.size)
    }

    @Test
    fun `comando apos o intervalo e aceito`() {
        val clock = ManualClock()
        val dispatcher = CountingDispatcher()
        val controller = controller(clock, dispatcher, InputLimits(minIntervalMillis = 50))

        assertTrue(controller.execute(InputCommand(InputCommand.Action.TAP)))
        clock.now += 60_000_000L // 60 ms > 50 ms
        assertTrue(controller.execute(InputCommand(InputCommand.Action.TAP)))
        assertEquals(2, dispatcher.events.size)
    }

    @Test
    fun `reset do limitador permite novo comando imediato`() {
        val clock = ManualClock()
        val dispatcher = CountingDispatcher()
        val controller = controller(clock, dispatcher, InputLimits(minIntervalMillis = 500))

        assertTrue(controller.execute(InputCommand(InputCommand.Action.TAP)))
        assertFalse(controller.execute(InputCommand(InputCommand.Action.TAP)))

        controller.resetRateLimiter()
        assertTrue("após reset, o próximo comando é tratado como primeiro", controller.execute(InputCommand(InputCommand.Action.TAP)))
    }

    @Test
    fun `release nao consome cota e nao altera o intervalo do proximo comando`() {
        val clock = ManualClock()
        val dispatcher = CountingDispatcher()
        val controller = controller(clock, dispatcher, InputLimits(minIntervalMillis = 50))

        assertTrue(controller.execute(InputCommand(InputCommand.Action.HOLD_START)))
        controller.releaseAll()
        assertTrue(dispatcher.events.contains("holdEnd"))

        clock.now += 10_000_000L
        assertFalse("release é fail-safe e não reinicia a janela de taxa", controller.execute(InputCommand(InputCommand.Action.TAP)))
        clock.now += 60_000_000L
        assertTrue(controller.execute(InputCommand(InputCommand.Action.TAP)))
    }

    @Test
    fun `janela de um minuto limita o total de comandos`() {
        val clock = ManualClock()
        val dispatcher = CountingDispatcher()
        val controller = controller(
            clock,
            dispatcher,
            InputLimits(minIntervalMillis = 10, maxCommandsPerMinute = 3),
        )
        repeat(3) {
            assertTrue(controller.execute(InputCommand(InputCommand.Action.TAP)))
            clock.now += 20_000_000L
        }
        assertFalse("quarto comando na mesma janela de 1 min deve ser bloqueado", controller.execute(InputCommand(InputCommand.Action.TAP)))

        clock.now += 61_000_000_000L
        assertTrue("passada a janela, o comando volta a ser permitido", controller.execute(InputCommand(InputCommand.Action.TAP)))
    }

    // --------------------------------- controlador lógico (mesmo defeito)

    @Test
    fun `controlador emite PRESS no primeiro ciclo sem sentinela Long MIN`() {
        val clock = ManualClock()
        val controller = FishingControllerImpl(ControlConfig(), clock = { clock.now })
        val command = controller.update(
            targetPositionX = 200f,
            indicatorPositionX = 100f,
            confidence = 0.9f,
            deltaTimeNanos = 33_000_000L,
        )
        assertEquals(
            "o primeiro erro acima da zona morta deve engajar imediatamente",
            ControlCommand.Type.PRESS,
            command.type,
        )
        assertTrue(controller.isHolding)
    }

    @Test
    fun `reset do controlador reabilita novo engajamento`() {
        val clock = ManualClock()
        val controller = FishingControllerImpl(ControlConfig(), clock = { clock.now })
        assertEquals(ControlCommand.Type.PRESS, controller.update(200f, 100f, 0.9f, 33_000_000L).type)
        controller.reset()

        clock.now += 1_000_000L
        assertEquals(ControlCommand.Type.PRESS, controller.update(200f, 100f, 0.9f, 33_000_000L).type)
    }

    @Test
    fun `zona morta continua valendo depois da correcao`() {
        val clock = ManualClock()
        val controller = FishingControllerImpl(ControlConfig(deadZonePx = 6f), clock = { clock.now })
        assertEquals(ControlCommand.Type.NONE, controller.update(103f, 100f, 0.9f, 33_000_000L).type)
        assertFalse(controller.isHolding)
    }
}
