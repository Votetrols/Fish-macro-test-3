package com.fischvision.macro

import com.fischvision.macro.capture.Frame
import com.fischvision.macro.capture.PixelFormat
import com.fischvision.macro.capture.RgbaFramePayload
import com.fischvision.macro.detector.Detection
import com.fischvision.macro.vision.ColorProfile
import com.fischvision.macro.vision.FishingUiDetectors
import com.fischvision.macro.vision.RealVisionProcessor
import com.fischvision.macro.vision.RoiManager
import com.fischvision.macro.vision.RoiMode
import com.fischvision.macro.vision.rgbToHsv
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Test implementation only — frame RGBA sintético em memória (sem Image). */
class SyntheticPayload(
    override val pixelWidth: Int,
    override val pixelHeight: Int,
) : RgbaFramePayload {

    private val pixels = IntArray(pixelWidth * pixelHeight)

    fun fill(argb: Int) = pixels.fill(argb)

    fun rect(left: Int, top: Int, right: Int, bottom: Int, argb: Int) {
        for (y in top until bottom) for (x in left until right) set(x, y, argb)
    }

    fun set(x: Int, y: Int, argb: Int) {
        if (x in 0 until pixelWidth && y in 0 until pixelHeight) pixels[y * pixelWidth + x] = argb
    }

    override fun argbAt(x: Int, y: Int): Int? =
        if (x in 0 until pixelWidth && y in 0 until pixelHeight) pixels[y * pixelWidth + x] else null

    override fun sizeBytes(): Long = pixelWidth.toLong() * pixelHeight * 4L
    override fun release() = Unit
}

private fun argb(r: Int, g: Int, b: Int): Int =
    (0xFF shl 24) or (r shl 16) or (g shl 8) or b

private fun frameOf(payload: SyntheticPayload, ts: Long = 1_000L): Frame =
    Frame(ts, payload.pixelWidth, payload.pixelHeight, 0, PixelFormat.RGBA_8888, payload)

class VisionPipelineTest {

    // Perfis explícitos de teste = simulacro de calibração (defaults NÃO são calibrados).
    private val trackProfile = ColorProfile("track", hueCenter = 0f, hueTolerance = 180f, minSaturation = 0f, minValue = 0.15f, maxValue = 0.45f)
    private val fishProfile = ColorProfile("fish", hueCenter = 200f, hueTolerance = 40f, minSaturation = 0.4f, minValue = 0.4f)
    private val indProfile = ColorProfile("ind", hueCenter = 0f, hueTolerance = 180f, minSaturation = 0f, minValue = 0.8f)

    private fun detectors(roi: RoiManager = RoiManager(mode = RoiMode.FULL_SCREEN)) =
        FishingUiDetectors(roi, trackProfile, fishProfile, indProfile)

    /**
     * Cena sintética do minigame: trilho escuro + blob ciano + bloco branco.
     *
     * NOTA (Fase 7): a barra era desenhada em y 60..76 de 160 px (≈ 37% da
     * altura) — FORA da faixa inferior/central da ROI automática (52%..94%), de
     * modo que o teste "detecção funciona dentro de ROI automática" falhava por
     * construção da cena, não por defeito do detector. A cena foi movida para a
     * região correta (y 108..124 ≈ 68%..78%), coerente com a ROI calibrada.
     */
    private fun fishingScene(): SyntheticPayload {
        val p = SyntheticPayload(320, 160)
        p.fill(argb(8, 8, 10))                      // fundo quase preto (v ≈ 0.04)
        p.rect(20, 108, 300, 124, argb(70, 70, 72)) // trilho da barra
        p.rect(140, 110, 156, 122, argb(30, 180, 220))// "peixe" ciano
        p.rect(60, 108, 72, 124, argb(240, 240, 240)) // "indicador" branco
        return p
    }

    // ------------------------------------------------------------ HSV / ROI

    @Test
    fun `hsv converte cores ancora corretamente`() {
        val hsv = FloatArray(3)
        rgbToHsv(255, 0, 0, hsv)
        assertTrue(Math.abs(hsv[0] - 0f) < 1f && hsv[1] > 0.99f && hsv[2] > 0.99f)
        rgbToHsv(0, 255, 0, hsv)
        assertTrue(Math.abs(hsv[0] - 120f) < 1f)
        rgbToHsv(0, 0, 255, hsv)
        assertTrue(Math.abs(hsv[0] - 240f) < 1f)
        rgbToHsv(255, 255, 255, hsv)
        assertTrue(hsv[1] < 0.01f && hsv[2] > 0.99f)
    }

    @Test
    fun `roi ancorada em fracao acompanha resolucao e rotacao`() {
        val roi = RoiManager(mode = RoiMode.AUTO_REGION)
        val a = roi.resolve(960, 540, rotationDegrees = 0)
        val b = roi.resolve(540, 960, rotationDegrees = 90)
        val fracAW = a.width / 960f
        val fracBW = b.width / 540f
        assertTrue(Math.abs(fracAW - fracBW) < 0.01f)
        assertTrue(a.top in 0 until a.bottom && b.top in 0 until b.bottom)
    }

    @Test
    fun `roi invalida e rejeitada na construcao`() {
        try {
            RoiManager(mode = RoiMode.CUSTOM_REGION, customLeftPct = 0.9f, customRightPct = 0.1f)
            error("ROI invertida deveria falhar")
        } catch (_: IllegalArgumentException) {
            // esperado
        }
    }

    // ------------------------------------------------------------ detecção

    @Test
    fun `deteccao valida produz barra peixe e indicador`() {
        val result = detectors().analyze(frameOf(fishingScene()))
        val types = result.map { it.type }.toSet()
        assertTrue(types.contains(Detection.Type.FISHING_BAR))
        assertTrue(types.contains(Detection.Type.FISH))
        assertTrue(types.contains(Detection.Type.PLAYER_INDICATOR))
        result.forEach { d ->
            assertTrue(d.confidence in 0f..1f)
            assertTrue(d.right > d.left && d.bottom > d.top)
        }
    }

    @Test
    fun `peixe e detectado dentro da barra (escopo de 2 estagios)`() {
        val result = detectors().analyze(frameOf(fishingScene()))
        val bar = result.first { it.type == Detection.Type.FISHING_BAR }
        val fish = result.first { it.type == Detection.Type.FISH }
        assertTrue(fish.centerX >= bar.left - 1f && fish.centerX <= bar.right + 1f)
    }

    @Test
    fun `ausencia de deteccao em frame vazio nao e erro`() {
        val p = SyntheticPayload(320, 160)
        p.fill(argb(5, 5, 5))
        val result = detectors().analyze(frameOf(p))
        assertTrue(result.isEmpty())
    }

    @Test
    fun `blob menor que o minimo de celulas e descartado`() {
        val p = SyntheticPayload(320, 160)
        p.fill(argb(8, 8, 10))
        p.rect(20, 60, 300, 76, argb(70, 70, 72))
        p.set(150, 68, argb(30, 180, 220)) // 1×1 px
        val result = detectors().analyze(frameOf(p))
        assertTrue(result.none { it.type == Detection.Type.FISH })
    }

    @Test
    fun `multiplas deteccoes do mesmo tipo sao reportadas`() {
        val p = SyntheticPayload(320, 160)
        p.fill(argb(8, 8, 10))
        p.rect(20, 60, 300, 76, argb(70, 70, 72))
        p.rect(140, 62, 156, 74, argb(30, 180, 220))
        p.rect(220, 62, 236, 74, argb(30, 180, 220))
        val fishes = detectors().analyze(frameOf(p)).filter { it.type == Detection.Type.FISH }
        assertTrue(fishes.size >= 2)
    }

    @Test
    fun `frame sem payload rgba retorna vazio sem crash (frame invalido)`() {
        val frame = Frame(0L, 10, 10, 0, PixelFormat.RGBA_8888, NoopPayload)
        assertTrue(detectors().analyze(frame).isEmpty())
    }

    @Test
    fun `deteccao funciona dentro de roi automatica`() {
        val scene = fishingScene()
        val result = detectors(RoiManager()).analyze(frameOf(scene))
        assertTrue(result.any { it.type == Detection.Type.FISHING_BAR })
    }

    // ------------------------------------------------------------ processor

    @Test
    fun `processor mede tempo e registra metricas`() = runTest {
        val processor = RealVisionProcessor(detectors())
        val result = processor.process(frameOf(fishingScene(), ts = 777L))
        assertEquals(777L, result.frameTimestampNanos)
        assertTrue(result.processingTimeNanos >= 0L)
        val snap = processor.metrics.snapshot()
        assertEquals(1L, snap.framesProcessed)
        assertNotNull(result.detections)
    }
}
