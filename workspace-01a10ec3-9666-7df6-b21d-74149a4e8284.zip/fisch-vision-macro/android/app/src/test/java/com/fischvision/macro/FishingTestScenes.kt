package com.fischvision.macro

import com.fischvision.macro.capture.Frame
import com.fischvision.macro.capture.PixelFormat
import com.fischvision.macro.vision.detect.FishingVisionFrame
import java.io.File
import kotlin.random.Random

/**
 * GERADOR DE CENAS SINTÉTICAS — Test implementation only.
 *
 * Por que existe: o vídeo de referência não está disponível no repositório nem
 * neste ambiente. Sem ele, a alternativa honesta é gerar cenas que reproduzem a
 * ESTRUTURA descrita (barra longa com bordas e marcadores nas extremidades, zona
 * preenchida que muda de cor e de posição, marcador vertical com ícone de peixe,
 * barra de progresso abaixo, fundo com partículas) e validar os detectores sobre
 * elas — em VÁRIOS estados diferentes do mesmo minigame (§37).
 *
 * O gerador não "ensina" o detector: ele produz pixels como os do jogo. Os
 * detectores não conhecem esta classe (ela vive apenas no source set de teste).
 *
 * Todos os parâmetros são frações, de modo que a cena pode ser renderizada em
 * 1920×1080 (escala do vídeo) ou 960×540 (escala da captura real do app).
 */
object FishingTestScenes {

    data class SceneSpec(
        val width: Int = 960,
        val height: Int = 540,
        val barLeftFraction: Float = 0.20f,
        val barRightFraction: Float = 0.64f,
        val barTopFraction: Float = 0.678f,
        val barBottomFraction: Float = 0.748f,
        /** Posição da zona como fração da BARRA (0..1). */
        val zoneStartOfBar: Float = 0.35f,
        val zoneWidthOfBar: Float = 0.30f,
        /** true = zona clara/branca; false = zona alaranjada (§39). */
        val zoneWhite: Boolean = true,
        val zoneVisible: Boolean = true,
        /** Posição do marcador do peixe como fração da BARRA (0..1). */
        val fishPositionOfBar: Float = 0.48f,
        val fishMarkerVisible: Boolean = true,
        val fishIconVisible: Boolean = true,
        val barVisible: Boolean = true,
        val progressVisible: Boolean = true,
        val progressFill: Float = 0.5f,
        val endMarkers: Boolean = true,
        /** Partículas/turbulência: ruído do cenário (não deve derrubar a detecção). */
        val particles: Boolean = true,
        val seed: Long = 7L,
    )

    /** Renderiza a cena como payload RGBA sintético (mesmo contrato da captura). */
    fun render(spec: SceneSpec = SceneSpec()): SyntheticPayload {
        val w = spec.width
        val h = spec.height
        val p = SyntheticPayload(w, h)
        val random = Random(spec.seed)

        // fundo da cena + faixa de "horizonte" (variação de cena, §5)
        p.fill(rgb(14, 16, 22))
        val horizonTop = (h * 0.30f).toInt()
        val horizonBottom = (h * 0.36f).toInt()
        p.rect(0, horizonTop, w, horizonBottom, rgb(38, 56, 78))
        repeat(14) { index ->
            val x = (w * 0.05f + index * w * 0.07f).toInt()
            p.rect(x, horizonTop - 26, x + 10, horizonBottom - 10, rgb(28, 40, 58))
        }

        if (spec.particles) {
            repeat(180) {
                val x = random.nextInt(0, w)
                val y = random.nextInt(0, h)
                val shade = 120 + random.nextInt(0, 90)
                p.rect(x, y, x + 2, y + 2, rgb(shade, shade, shade))
            }
        }

        if (spec.barVisible) {
            val barLeft = (w * spec.barLeftFraction).toInt()
            val barRight = (w * spec.barRightFraction).toInt()
            val barTop = (h * spec.barTopFraction).toInt()
            val barBottom = (h * spec.barBottomFraction).toInt()
            val barWidth = barRight - barLeft

            // trilho + contorno (a barra é um objeto DELIMITADO: §8)
            p.rect(barLeft, barTop, barRight, barBottom, rgb(62, 64, 70))
            p.rect(barLeft, barTop, barRight, barTop + 2, rgb(158, 158, 165))
            p.rect(barLeft, barBottom - 2, barRight, barBottom, rgb(158, 158, 165))

            // marcadores triangulares das extremidades (evidência AUXILIAR §9)
            if (spec.endMarkers) {
                p.rect(barLeft, barTop, barLeft + 5, barBottom, rgb(205, 205, 210))
                p.rect(barRight - 5, barTop, barRight, barBottom, rgb(205, 205, 210))
            }

            // zona preenchida (branca ou alaranjada — a MESMA estrutura, §39)
            if (spec.zoneVisible) {
                val zoneLeft = barLeft + (barWidth * spec.zoneStartOfBar).toInt()
                val zoneRight = zoneLeft + (barWidth * spec.zoneWidthOfBar).toInt()
                val zoneTop = barTop + 3
                val zoneBottom = barBottom - 3
                val zoneColor = if (spec.zoneWhite) rgb(238, 238, 240) else rgb(232, 152, 64)
                p.rect(zoneLeft, zoneTop, zoneRight, zoneBottom, zoneColor)
            }

            // marcador do peixe: linha vertical (clara, com CONTORNO ESCURO) + ícone
            // acima da barra. O contorno é o que mantém a linha visível quando ela
            // passa por dentro da zona clara — como numa UI real.
            if (spec.fishMarkerVisible) {
                val fishX = barLeft + (barWidth * spec.fishPositionOfBar).toInt()
                p.rect(fishX - 5, barTop - 8, fishX + 5, barBottom + 6, rgb(26, 26, 32))
                p.rect(fishX - 2, barTop - 6, fishX + 2, barBottom + 4, rgb(246, 246, 250))
                if (spec.fishIconVisible) {
                    p.rect(fishX - 8, barTop - 18, fishX + 8, barTop - 7, rgb(250, 216, 120))
                }
            }
        }

        if (spec.progressVisible) {
            val barTop = (h * spec.barTopFraction).toInt()
            val barBottom = (h * spec.barBottomFraction).toInt()
            val barLeft = (w * spec.barLeftFraction).toInt()
            val barRight = (w * spec.barRightFraction).toInt()
            val progressTop = barBottom + 18
            val progressBottom = progressTop + 12
            p.rect(barLeft + 30, progressTop, barRight - 30, progressBottom, rgb(52, 54, 58))
            val fillWidth = ((barRight - 30) - (barLeft + 30)) * spec.progressFill
            p.rect(barLeft + 30, progressTop + 1, (barLeft + 30 + fillWidth).toInt(), progressBottom - 1, rgb(96, 176, 240))
            // a barra principal NÃO deve ser eleita a partir disto (§16): ela é fina
            // (12 px) e está abaixo, com folga de 18 px.
        }
        return p
    }

    fun frameOf(payload: SyntheticPayload, timestampNanos: Long = 1_000L): Frame =
        Frame(
            timestampNanos = timestampNanos,
            width = payload.pixelWidth,
            height = payload.pixelHeight,
            rotationDegrees = 0,
            pixelFormat = PixelFormat.RGBA_8888,
            payload = payload,
        )

    fun rgb(r: Int, g: Int, b: Int): Int = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

    // ----------------------------------------------------------- evidência PNG

    /** Diretório de evidência das validações (fora de `build`, para persistir). */
    fun evidenceDir(): File {
        val configured = System.getProperty("fvm.evidenceDir")
        val dir = if (configured != null) File(configured) else File("../artifacts/phase7-validation")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /**
     * Salva o frame REAL (pixels sintéticos) com as caixas detectadas desenhadas
     * por cima — a mesma informação geométrica que o overlay Android desenha
     * sobre o jogo (§20/§47).
     *
     * As LINHAS de texto vão para um arquivo `.txt` ao lado da imagem, porque o
     * source set de teste Android não tem AWT para renderizar texto (ver
     * TinyPng). O overlay real do app mostra exatamente essas linhas na tela.
     */
    fun writeAnnotatedPng(
        payload: SyntheticPayload,
        vision: FishingVisionFrame,
        debugLines: List<String>,
        fileName: String,
    ) {
        val width = payload.pixelWidth
        val height = payload.pixelHeight
        val pixels = IntArray(width * height)
        for (y in 0 until height) {
            for (x in 0 until width) {
                pixels[y * width + x] = payload.argbAt(x, y) ?: 0
            }
        }
        val directory = evidenceDir()
        vision.roi?.let {
            TinyPng.outline(pixels, width, height, it.left, it.top, it.right - 1, it.bottom - 1, RGB_GRAY)
        }
        vision.mainBar?.takeIf { it.valid }?.let {
            TinyPng.outline(pixels, width, height, it.left.toInt(), it.top.toInt(), it.right.toInt(), it.bottom.toInt(), RGB_CYAN)
        }
        vision.zone?.takeIf { it.valid }?.let {
            TinyPng.outline(pixels, width, height, it.left.toInt(), it.top.toInt(), it.right.toInt(), it.bottom.toInt(), RGB_AMBER)
        }
        vision.fish?.takeIf { it.valid }?.let {
            TinyPng.outline(
                pixels,
                width,
                height,
                it.boundingBox.left,
                it.boundingBox.top,
                it.boundingBox.right,
                it.boundingBox.bottom,
                RGB_GREEN,
            )
            TinyPng.verticalLine(
                pixels,
                width,
                height,
                it.centerX.toInt(),
                (it.boundingBox.top - 40).coerceAtLeast(0),
                (it.boundingBox.bottom + 10).coerceAtMost(height - 1),
                RGB_GREEN,
            )
        }
        vision.progress.takeIf { it.valid }?.let {
            TinyPng.outline(pixels, width, height, it.left.toInt(), it.top.toInt(), it.right.toInt(), it.bottom.toInt(), RGB_MAGENTA)
        }

        val imageFile = File(directory, fileName)
        imageFile.parentFile?.mkdirs()
        TinyPng.write(imageFile, width, height) { x, y -> pixels[y * width + x] }
        File(directory, fileName.replace(".png", ".txt")).writeText(debugLines.joinToString("\n"))
    }

    private const val RGB_CYAN = 0xFF22D3EE.toInt()
    private const val RGB_AMBER = 0xFFFBBF24.toInt()
    private const val RGB_GREEN = 0xFF34D399.toInt()
    private const val RGB_MAGENTA = 0xFFE879F9.toInt()
    private const val RGB_GRAY = 0xFF94A3B8.toInt()
}
