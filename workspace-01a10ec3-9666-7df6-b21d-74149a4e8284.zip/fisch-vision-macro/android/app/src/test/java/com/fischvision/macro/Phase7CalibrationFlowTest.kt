package com.fischvision.macro

import com.fischvision.macro.capture.CaptureEvent
import com.fischvision.macro.capture.CaptureEventSource
import com.fischvision.macro.capture.Frame
import com.fischvision.macro.capture.FrameBus
import com.fischvision.macro.capture.FrameSource
import com.fischvision.macro.core.MacroState
import com.fischvision.macro.core.MacroStateMachine
import com.fischvision.macro.debug.DebugTextFormatter
import com.fischvision.macro.debug.VisionDebugSnapshot
import com.fischvision.macro.service.CalibrationEngine
import com.fischvision.macro.settings.MacroSettings
import com.fischvision.macro.tracker.TrackState
import com.fischvision.macro.vision.detect.FishingVisionAnalyzer
import com.fischvision.macro.vision.detect.VisionConfig
import com.fischvision.macro.vision.outcome.MinigameOutcomeDetector
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * §6/§17/§21/§25/§29/§37 — fluxo de CALIBRAÇÃO ponta a ponta:
 *
 *   frames → detectores → tracker → FSM → snapshot → texto do HUD
 *
 * Prova que: a FSM percorre WAITING → DETECTING → TRACKING; o texto do overlay
 * traz os valores REAIS; a parada da projeção desarma para o estado seguro; e a
 * fase NUNCA abre caminho de input.
 *
 * As cenas são renderizadas em 480×270 (¼ dos pixels de 960×540) para manter a
 * suíte rápida: a geometria da ROI é proporcional, portanto nada do que se
 * verifica aqui depende da resolução.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class Phase7CalibrationFlowTest {

    private val settings = MacroSettings.DEFAULT

    private fun analyzer() = FishingVisionAnalyzer(
        config = VisionConfig.DEFAULT,
        roiConfig = settings.roiConfig(),
        zoneMarginNormalized = settings.zoneEdgeMarginPercent,
    )

    /**
     * Fonte sintética que se comporta como a captura real: entrega os frames e
     * PERMANECE ABERTA (gate) até o teste liberar — assim o pipeline não termina
     * sozinho e o ciclo de parada pode ser exercitado.
     */
    private class SceneSource(
        private val frames: List<Frame>,
        private val holdOpen: Boolean = false,
    ) : FrameSource, CaptureEventSource {

        val events = MutableSharedFlow<CaptureEvent>(extraBufferCapacity = 8)
        private val gate = CompletableDeferred<Unit>()

        override suspend fun start() = Unit

        override fun frames(): Flow<Frame> = flow {
            frames.forEach { emit(it) }
            if (holdOpen) gate.await()
        }

        override suspend fun stop() {
            gate.complete(Unit)
        }

        fun releaseGate() {
            gate.complete(Unit)
        }

        override fun captureEvents(): Flow<CaptureEvent> = events
    }

    private fun framesOf(
        count: Int,
        fishPositions: List<Float> = listOf(0.20f, 0.35f, 0.45f, 0.55f, 0.60f),
        size: Pair<Int, Int> = 480 to 270,
        barVisible: Boolean = true,
        zoneVisible: Boolean = true,
        fishVisible: Boolean = true,
        startIndex: Int = 0,
    ): List<Frame> = (0 until count).map { index ->
        val spec = FishingTestScenes.SceneSpec(
            width = size.first,
            height = size.second,
            zoneStartOfBar = 0.35f,
            zoneWidthOfBar = 0.30f,
            zoneVisible = zoneVisible,
            fishMarkerVisible = fishVisible,
            fishPositionOfBar = fishPositions[index % fishPositions.size],
            barVisible = barVisible,
            progressVisible = barVisible,
        )
        FishingTestScenes.frameOf(
            FishingTestScenes.render(spec),
            timestampNanos = (startIndex + index) * 33_000_000L,
        )
    }

    @Test
    fun `calibracao percorre a FSM existente ate TRACKING sem abrir caminho de input`() = runTest {
        val fsm = MacroStateMachine()
        val snapshots = mutableListOf<VisionDebugSnapshot>()
        val engine = CalibrationEngine(
            scope = this,
            fsm = fsm,
            bus = FrameBus(),
            settings = settings,
            analyzer = analyzer(),
            onSnapshot = { snapshots.add(it) },
            foregroundPackage = { settings.targetAppPackage },
        )
        assertTrue(engine.start(SceneSource(framesOf(count = 8))))
        advanceUntilIdle()

        assertEquals(MacroState.TRACKING, fsm.state)
        assertTrue("os snapshots alimentam o overlay", snapshots.size >= 6)

        val last = engine.latestSnapshot()!!
        assertEquals(TrackState.TRACKING, last.trackState)
        assertNotNull(last.mainBar)
        assertNotNull(last.zone)
        assertNotNull(last.fish)
        assertEquals("INPUT permanece DISABLED durante toda a fase", "DISABLED", last.inputState)
        assertTrue(last.fishInsideZone)

        assertTrue(
            "a fase de calibração não pode solicitar controle",
            fsm.history.none { it.event is com.fischvision.macro.core.MacroEvent.ControlRequested },
        )
        assertEquals("a FSM nunca alcança CONTROLLING nesta fase", 0, fsm.history.count { it.to == MacroState.CONTROLLING })
        engine.stop()
    }

    @Test
    fun `texto do overlay traz os valores reais de pixel e normalizados`() = runTest {
        val fsm = MacroStateMachine()
        val snapshots = mutableListOf<VisionDebugSnapshot>()
        val engine = CalibrationEngine(
            scope = this,
            fsm = fsm,
            bus = FrameBus(),
            settings = settings,
            analyzer = analyzer(),
            onSnapshot = { snapshots.add(it) },
            foregroundPackage = { settings.targetAppPackage },
        )
        engine.start(SceneSource(framesOf(count = 6, fishPositions = listOf(0.45f))))
        advanceUntilIdle()

        val text = DebugTextFormatter.lines(snapshots.last()).joinToString("\n")
        assertTrue(text.contains("FISCH DEBUG"))
        assertTrue(text.contains("MAIN BAR: X"))
        assertTrue(text.contains("ZONE: X"))
        assertTrue(text.contains("FISH: X"))
        assertTrue(text.contains("Pixel X:"))
        assertTrue(text.contains("Normalized X:"))
        assertTrue(text.contains("FISH IN ZONE: YES"))
        assertTrue(text.contains("TRACK: TRACKING"))
        assertTrue(text.contains("FSM: TRACKING"))
        assertTrue(text.contains("INPUT: DISABLED"))
        assertTrue(text.contains("FRAME"))
        assertTrue("PROGRESS deve aparecer (UNKNOWN é resposta legítima)", text.contains("PROGRESS"))
        engine.stop()
    }

    @Test
    fun `sequencia com movimentacao mantem tracking e estima velocidade`() = runTest {
        val fsm = MacroStateMachine()
        val snapshots = mutableListOf<VisionDebugSnapshot>()
        val engine = CalibrationEngine(
            scope = this,
            fsm = fsm,
            bus = FrameBus(),
            settings = settings,
            analyzer = analyzer(),
            onSnapshot = { snapshots.add(it) },
            foregroundPackage = { null },
        )
        engine.start(
            SceneSource(
                framesOf(count = 14, fishPositions = listOf(0.10f, 0.20f, 0.30f, 0.45f, 0.60f, 0.75f, 0.85f)),
            ),
        )
        advanceUntilIdle()

        val fishTrack = snapshots.last().fishTrack
        assertNotNull(fishTrack)
        assertEquals("sequência contínua não pode perder o rastreamento", TrackState.TRACKING, fishTrack!!.state)
        val positions = snapshots.mapNotNull { it.fishTrack?.centerX }.distinct()
        assertTrue("o marcador se moveu e foi acompanhado", positions.size >= 3)
        engine.stop()
    }

    @Test
    fun `parada da projecao desarma para o estado seguro`() = runTest {
        val fsm = MacroStateMachine()
        val engine = CalibrationEngine(
            scope = this,
            fsm = fsm,
            bus = FrameBus(),
            settings = settings,
            analyzer = analyzer(),
            foregroundPackage = { null },
        )
        val source = SceneSource(framesOf(count = 6), holdOpen = true)
        engine.start(source)
        advanceUntilIdle()
        assertEquals(MacroState.TRACKING, fsm.state)

        // Ciclo do §29: onStop da projeção → evento → FSM → estado seguro.
        source.events.emit(CaptureEvent.ProjectionStopped)
        advanceUntilIdle()
        assertEquals("ProjectionStopped leva ao estado seguro", MacroState.IDLE, fsm.state)

        source.releaseGate()
        advanceUntilIdle()
        engine.stop()
    }

    @Test
    fun `perda temporaria de alvos leva a LOST_DETECTION e recupera ao voltar`() = runTest {
        val fsm = MacroStateMachine()
        val engine = CalibrationEngine(
            scope = this,
            fsm = fsm,
            bus = FrameBus(),
            settings = settings,
            analyzer = analyzer(),
            foregroundPackage = { null },
        )
        // A BARRA permanece visível e apenas a zona e o marcador somem: assim o
        // teste exercita a perda de tracking (§18) sem acionar a detecção de
        // resultado, que depende do desaparecimento da barra (§33).
        // 6 frames completos + 12 sem zona/marcador (acima de maxLostFrames=8) + 6 completos.
        val frames = framesOf(count = 6) +
            framesOf(count = 12, zoneVisible = false, fishVisible = false, startIndex = 6) +
            framesOf(count = 6, startIndex = 18)
        engine.start(SceneSource(frames))
        advanceUntilIdle()

        assertTrue(
            "a perda deve ter sido registrada como LOST_DETECTION (e não como sucesso)",
            fsm.history.any { it.to == MacroState.LOST_DETECTION },
        )
        assertEquals("com os alvos de volta, a FSM volta a rastrear", MacroState.TRACKING, fsm.state)
        assertEquals(TrackState.TRACKING, engine.latestSnapshot()!!.trackState)
        engine.stop()
    }

    @Test
    fun `engine bloqueia segunda instancia simultanea`() = runTest {
        val fsm = MacroStateMachine()
        val engine = CalibrationEngine(
            scope = this,
            fsm = fsm,
            bus = FrameBus(),
            settings = settings,
            analyzer = analyzer(),
        )
        assertTrue(engine.start(SceneSource(framesOf(count = 2), holdOpen = true)))
        assertTrue("instância única preservada", !engine.start(SceneSource(framesOf(count = 2))))
        engine.stop()
    }
}

/** §33/§34 — infraestrutura de SUCCESS/FAILED, sem OCR. */
class Phase7OutcomeTest {

    private fun sampleOf(payload: SyntheticPayload): com.fischvision.macro.vision.RoiSample {
        val roi = MacroSettings.DEFAULT.roiConfig().resolve(payload.pixelWidth, payload.pixelHeight)
        return com.fischvision.macro.vision.RoiSample().apply { sample(payload, roi, step = 2) }
    }

    @Test
    fun `ausencia curta da barra nao declara fim de minigame`() {
        val detector = MinigameOutcomeDetector(minAbsentFrames = 10)
        val payload = FishingTestScenes.render(FishingTestScenes.SceneSpec(width = 480, height = 270))
        val sample = sampleOf(payload)

        repeat(3) {
            val outcome = detector.observe(barPresent = true, zonePresent = true, progressFill = 0.9f, sample = sample)
            assertEquals(MinigameOutcomeDetector.Signal.NONE, outcome.signal)
        }
        repeat(5) {
            val outcome = detector.observe(barPresent = false, zonePresent = false, progressFill = 0.9f, sample = sample)
            assertEquals("perda de tracking não é fim de minigame", MinigameOutcomeDetector.Signal.NONE, outcome.signal)
        }
    }

    @Test
    fun `barra ausente por muitos frames com progresso alto sugere sucesso`() {
        val detector = MinigameOutcomeDetector(minAbsentFrames = 5, minConfidence = 0.3f)
        val payload = FishingTestScenes.render(FishingTestScenes.SceneSpec(width = 480, height = 270))
        val sample = sampleOf(payload)

        detector.observe(barPresent = true, zonePresent = true, progressFill = 0.95f, sample = sample)
        var outcome = detector.observe(barPresent = false, zonePresent = false, progressFill = 0.95f, sample = sample)
        repeat(6) {
            outcome = detector.observe(barPresent = false, zonePresent = false, progressFill = 0.95f, sample = sample)
        }
        assertEquals(MinigameOutcomeDetector.Signal.SUCCESS_CANDIDATE, outcome.signal)
        assertTrue(outcome.confidence > 0f)
    }

    @Test
    fun `progresso vazio com barra ausente nao e classificado como sucesso`() {
        val detector = MinigameOutcomeDetector(minAbsentFrames = 5, minConfidence = 0.3f)
        val payload = FishingTestScenes.render(FishingTestScenes.SceneSpec(width = 480, height = 270))
        val sample = sampleOf(payload)

        detector.observe(barPresent = true, zonePresent = true, progressFill = 0.02f, sample = sample)
        var outcome = detector.observe(barPresent = false, zonePresent = false, progressFill = 0.02f, sample = sample)
        repeat(6) {
            outcome = detector.observe(barPresent = false, zonePresent = false, progressFill = 0.02f, sample = sample)
        }
        assertTrue(
            "sem evidência de conclusão o resultado não pode ser SUCCESS",
            outcome.signal != MinigameOutcomeDetector.Signal.SUCCESS_CANDIDATE,
        )
    }

    @Test
    fun `reset limpa o estado do detector de resultado`() {
        val detector = MinigameOutcomeDetector(minAbsentFrames = 2)
        detector.observe(barPresent = true, zonePresent = true, progressFill = 0.9f, sample = null)
        detector.reset()
        val outcome = detector.observe(barPresent = false, zonePresent = false, progressFill = 0.9f, sample = null)
        assertEquals(MinigameOutcomeDetector.Signal.NONE, outcome.signal)
    }

    @Test
    fun `evento de resultado usa a FSM existente sem abrir caminho de input`() {
        val fsm = MacroStateMachine()
        fsm.dispatch(com.fischvision.macro.core.MacroEvent.Start)
        fsm.dispatch(com.fischvision.macro.core.MacroEvent.DetectionFound) // WAITING -> DETECTING
        fsm.dispatch(com.fischvision.macro.core.MacroEvent.DetectionFound) // DETECTING -> TRACKING

        val transition = fsm.dispatch(
            com.fischvision.macro.core.MacroEvent.OutcomeObserved(success = true, confidence = 0.8f),
        )
        assertTrue(transition.accepted)
        assertEquals(MacroState.FISHING_SUCCESS, fsm.state)
        assertTrue(fsm.history.none { it.to == MacroState.CONTROLLING })

        fsm.dispatch(com.fischvision.macro.core.MacroEvent.DetectionLost)
        assertEquals(MacroState.WAITING_FOR_FISHING_UI, fsm.state)
    }

    @Test
    fun `falha observada tambem nao autoriza input`() {
        val fsm = MacroStateMachine()
        fsm.dispatch(com.fischvision.macro.core.MacroEvent.Start)
        fsm.dispatch(com.fischvision.macro.core.MacroEvent.DetectionFound)
        fsm.dispatch(com.fischvision.macro.core.MacroEvent.DetectionFound)
        fsm.dispatch(com.fischvision.macro.core.MacroEvent.OutcomeObserved(success = false, confidence = 0.7f))
        assertEquals(MacroState.FISHING_FAILED, fsm.state)
        assertTrue(fsm.history.none { it.to == MacroState.CONTROLLING })
    }

    @Test
    fun `resultado em IDLE e rejeitado`() {
        val fsm = MacroStateMachine()
        val transition = fsm.dispatch(
            com.fischvision.macro.core.MacroEvent.OutcomeObserved(success = true, confidence = 0.9f),
        )
        assertTrue("sem sessão ativa não há resultado a registrar", !transition.accepted)
        assertEquals(MacroState.IDLE, fsm.state)
        assertNull(fsm.lastError)
    }
}
