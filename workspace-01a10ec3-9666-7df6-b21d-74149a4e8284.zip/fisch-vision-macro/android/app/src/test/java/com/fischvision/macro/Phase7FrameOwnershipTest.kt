package com.fischvision.macro

import com.fischvision.macro.capture.Frame
import com.fischvision.macro.capture.FrameBus
import com.fischvision.macro.capture.IntArrayRgbaPayload
import com.fischvision.macro.capture.PixelFormat
import com.fischvision.macro.capture.RecordedFrameSource
import com.fischvision.macro.capture.RefCountedFramePayload
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * §30 — PROPRIEDADE DO PAYLOAD e §36 — fonte de frames gravados.
 *
 * O objetivo é provar as três garantias documentadas em [RefCountedFramePayload]:
 *  1. depois da última referência, ler pixels devolve `null` (nunca lança);
 *  2. `retain()` em payload liberado devolve `false` (não ressuscita recurso);
 *  3. o delegate é fechado UMA única vez.
 */
class Phase7FrameOwnershipTest {

    private class CountingPayload(width: Int = 8, height: Int = 8) : com.fischvision.macro.capture.RgbaFramePayload {
        var releases = 0
            private set

        override val pixelWidth: Int = width
        override val pixelHeight: Int = height
        override fun argbAt(x: Int, y: Int): Int? = if (x in 0 until pixelWidth && y in 0 until pixelHeight) 0xFF102030.toInt() else null
        override fun sizeBytes(): Long = pixelWidth.toLong() * pixelHeight * 4L
        override fun release() {
            releases++
        }
    }

    private fun frameOf(payload: RefCountedFramePayload, ts: Long = 0L) = Frame(
        timestampNanos = ts,
        width = payload.pixelWidth,
        height = payload.pixelHeight,
        rotationDegrees = 0,
        pixelFormat = PixelFormat.RGBA_8888,
        payload = payload,
    )

    @Test
    fun `leitura apos a ultima referencia devolve null em vez de lancar`() {
        val delegate = CountingPayload()
        val payload = RefCountedFramePayload.of(delegate, initialReferences = 1)

        assertNotNull(payload.argbAt(1, 1))
        payload.release()

        assertTrue(payload.isReleased)
        assertNull("payload liberado não entrega pixels — nunca use-after-release", payload.argbAt(1, 1))
        assertEquals(1, delegate.releases)
    }

    @Test
    fun `retain devolve false para payload ja liberado`() {
        val payload = RefCountedFramePayload.of(CountingPayload(), 1)
        payload.release()
        assertFalse("recurso já liberado não pode ser ressuscitado", payload.retain())
        assertEquals(0, payload.refCount)
    }

    @Test
    fun `release e idempotente e fecha o recurso uma unica vez`() {
        val delegate = CountingPayload()
        val payload = RefCountedFramePayload.of(delegate, 1)
        payload.release()
        payload.release()
        payload.release()
        assertEquals("fechar duas vezes dispararia IllegalArgumentException no ImageReader", 1, delegate.releases)
    }

    @Test
    fun `multiplas referencias mantem o recurso vivo ate a ultima`() {
        val delegate = CountingPayload()
        val payload = RefCountedFramePayload.of(delegate, 2)
        payload.release()
        assertFalse(payload.isReleased)
        assertNotNull("ainda existe consumidor legítimo", payload.argbAt(2, 2))
        assertEquals(0, delegate.releases)

        payload.release()
        assertTrue(payload.isReleased)
        assertEquals(1, delegate.releases)
    }

    @Test
    fun `barramento de frames entrega pixels vivos e nao retem apos a janela`() = runTest {
        val bus = FrameBus()
        val delegate = CountingPayload()
        val payload = RefCountedFramePayload.of(delegate, 1)

        assertTrue(bus.publishShared(frameOf(payload)))
        assertEquals(
            "o barramento adiciona UMA referência à do pipeline durante a janela do frame",
            2,
            bus.inFlightReferences(),
        )

        var readInsideWindow = false
        val ran = bus.withLatestFrame { frame ->
            val p = frame.payload as RefCountedFramePayload
            readInsideWindow = p.argbAt(3, 3) != null
        }
        assertTrue(ran)
        assertTrue("dentro da janela os pixels existem", readInsideWindow)
        assertEquals("referência temporária do consumidor devolvida", 2, bus.inFlightReferences())

        // O dono (pipeline) devolve a referência dele e uma nova publicação
        // encerra a janela: aí o recurso fecha, UMA única vez.
        payload.release()
        assertEquals(1, bus.inFlightReferences())
        val second = RefCountedFramePayload.of(CountingPayload(), 1)
        bus.publishShared(frameOf(second, ts = 1L))
        assertEquals("referência da janela anterior liberada", 1, delegate.releases)
    }

    @Test
    fun `consumidor do barramento nao recebe payload morto`() = runTest {
        val bus = FrameBus()
        val payload = RefCountedFramePayload.of(CountingPayload(), 1)
        payload.release() // recurso já liberado pelo produtor (cenário de uso após release)

        assertTrue("o frame continua publicável como metadado", bus.publishShared(frameOf(payload)))
        var executed = false
        val ran = bus.withLatestFrame { executed = true }
        assertFalse("o bloco não deve rodar sobre um payload liberado", ran)
        assertFalse(executed)
    }

    @Test
    fun `fonte de frames gravados alimenta o pipeline sem Android`() = runTest {
        val directory = java.io.File(System.getProperty("java.io.tmpdir"), "fvm-recorded-${System.nanoTime()}")
        directory.mkdirs()
        try {
            val pixels = IntArray(64 * 32) { 0xFF202020.toInt() }
            val decoder = object : com.fischvision.macro.capture.RecordedFrameDecoder {
                override fun decode(file: java.io.File) = com.fischvision.macro.capture.DecodedFrame(pixels, 64, 32)
            }
            java.io.File(directory, "frame_000001.png").writeText("stub")
            java.io.File(directory, "frame_000002.png").writeText("stub")

            val source = RecordedFrameSource(directory, decoder, playbackFps = 1_000, loop = false)
            source.start()
            assertEquals(2, source.frameFiles.size)

            val frames = mutableListOf<Frame>()
            source.frames().collect { frames.add(it) }
            assertEquals(2, frames.size)
            assertTrue(frames.all { it.width == 64 && it.height == 32 })
            assertNotNull((frames[0].payload as IntArrayRgbaPayload).argbAt(1, 1))
        } finally {
            directory.deleteRecursively()
        }
    }
}
