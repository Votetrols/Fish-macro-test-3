package com.fischvision.macro

import com.fischvision.macro.debug.DebugTextFormatter
import com.fischvision.macro.debug.VisionDebugSnapshot
import com.fischvision.macro.settings.MacroSettings
import com.fischvision.macro.tracker.EntityTracker
import com.fischvision.macro.tracker.TrackObservation
import com.fischvision.macro.tracker.TrackState
import com.fischvision.macro.vision.Normalization
import com.fischvision.macro.vision.detect.FishingVisionAnalyzer
import com.fischvision.macro.vision.detect.FishingVisionFrame
import com.fischvision.macro.vision.detect.VisionConfig
import java.io.File
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * §37/§38 — CRITÉRIO VISUAL DE SUCESSO.
 *
 * O critério da fase é: o overlay deve identificar de forma CONSISTENTE
 * MAIN BAR + ZONE + FISH MARKER em MUITOS estados diferentes do minigame — não
 * basta um único frame. A especificação cita os instantes 5,5 s · 8 s · 10 s ·
 * 12 s · 14 s · 15 s do vídeo de referência.
 *
 * SITUAÇÃO REAL DESTE AMBIENTE: o arquivo `1000032864.mp4` NÃO foi fornecido no
 * repositório nem neste ambiente. Este teste reproduz, portanto, SEIS ESTADOS
 * DISTINTOS do mesmo minigame (zona em posições diferentes, branca/laranja,
 * peixe dentro/fora da zona, marcador sem ícone, barra ausente), exatamente como
 * o §38 exige (o detector tem de reconhecer a ESTRUTURA, não memorizar frames),
 * e deixa a evidência em `artifacts/phase7-validation/final/`.
 *
 * Quando os frames reais forem extraídos do vídeo, o MESMO pipeline é exercitado
 * pelo harness de replay (`RecordedFrameSource` + `FishingVisionAnalyzer`): basta
 * apontar o diretório e rodar `./gradlew test`. Nenhuma linha de detector muda.
 */
class Phase7ValidationReportTest {

    private val settings = MacroSettings.DEFAULT

    private data class State(
        val id: String,
        val description: String,
        val spec: FishingTestScenes.SceneSpec,
    )

    private fun states(): List<State> = listOf(
        State(
            "01_zona_esquerda_peixe_dentro",
            "zona deslocada à esquerda (branca), marcador dentro dela",
            FishingTestScenes.SceneSpec(zoneStartOfBar = 0.05f, zoneWidthOfBar = 0.25f, zoneWhite = true, fishPositionOfBar = 0.17f),
        ),
        State(
            "02_zona_centro_branca",
            "zona no centro (branca), marcador dentro",
            FishingTestScenes.SceneSpec(zoneStartOfBar = 0.33f, zoneWidthOfBar = 0.30f, zoneWhite = true, fishPositionOfBar = 0.48f),
        ),
        State(
            "03_zona_centro_laranja",
            "mesma zona, agora ALARANJADA (mudança visual do §39)",
            FishingTestScenes.SceneSpec(zoneStartOfBar = 0.33f, zoneWidthOfBar = 0.30f, zoneWhite = false, fishPositionOfBar = 0.48f),
        ),
        State(
            "04_zona_direita_peixe_fora",
            "zona à direita, marcador FORA da zona",
            FishingTestScenes.SceneSpec(zoneStartOfBar = 0.66f, zoneWidthOfBar = 0.26f, fishPositionOfBar = 0.30f),
        ),
        State(
            "05_marcador_sem_icone",
            "marcador parcialmente visível (sem ícone de peixe)",
            FishingTestScenes.SceneSpec(fishIconVisible = false),
        ),
        State(
            "06_barra_ausente_fim_de_rodada",
            "barra principal ausente (fim de rodada) com barra de progresso cheia",
            FishingTestScenes.SceneSpec(barVisible = false, progressVisible = false, progressFill = 1f),
        ),
    )

    @Test
    fun `valida seis estados do minigame e registra a evidencia`() {
        val analyzer = FishingVisionAnalyzer(
            config = VisionConfig.DEFAULT,
            roiConfig = settings.roiConfig(),
            zoneMarginNormalized = settings.zoneEdgeMarginPercent,
        )
        val barTracker = EntityTracker(name = "MAIN_BAR", maxLostFrames = settings.maxLostFrames)
        val zoneTracker = EntityTracker(name = "ZONE", maxLostFrames = settings.maxLostFrames)
        val fishTracker = EntityTracker(name = "FISH", maxLostFrames = settings.maxLostFrames)

        val output = StringBuilder()
        output.appendLine("# Fase 7 — evidência de validação do pipeline de visão")
        output.appendLine()
        output.appendLine("> Gerado automaticamente por `Phase7ValidationReportTest` (JVM, sem device).")
        output.appendLine("> Os frames são CENAS SINTÉTICAS que reproduzem os estados descritos do")
        output.appendLine("> minigame — o vídeo `1000032864.mp4` não foi disponibilizado. Ver PHASE_7_STATUS.md.")
        output.appendLine()
        output.appendLine("| estado | MAIN BAR (norm) | ZONE (norm) | FISH (norm) | FISH IN ZONE | TRACK |")
        output.appendLine("|---|---|---|---|---|---|")

        var frameIndex = 0L
        states().forEach { state ->
            val payload = FishingTestScenes.render(state.spec)
            val vision: FishingVisionFrame = analyzer.analyze(FishingTestScenes.frameOf(payload), frameIndex)
            frameIndex++

            val bar = vision.mainBar
            val zone = vision.zone
            val fish = vision.fish

            // O tracker consome as MESMAS detecções que o app consome.
            barTracker.update(bar?.let { TrackObservation(it.centerX, it.centerY, it.confidence, vision.timestampNanos) } ?: return@forEach, frameIndex, vision.timestampNanos)
            if (bar == null) barTracker.miss(frameIndex)
            zone?.let { zoneTracker.update(TrackObservation(it.centerX, it.centerY, it.confidence, vision.timestampNanos), frameIndex, vision.timestampNanos) }
                ?: zoneTracker.miss(frameIndex)
            fish?.let { fishTracker.update(TrackObservation(it.centerX, it.centerY, it.confidence, vision.timestampNanos), frameIndex, vision.timestampNanos) }
                ?: fishTracker.miss(frameIndex)

            // Critério de sucesso da fase: nos estados COM minigame visível, as
            // três entidades precisam ser identificadas.
            if (state.spec.barVisible) {
                assertNotNull("${state.id}: MAIN BAR deve ser identificada", bar)
                assertNotNull("${state.id}: ZONE deve ser identificada", zone)
                assertNotNull("${state.id}: FISH MARKER deve ser identificado", fish)
                assertTrue("${state.id}: barra com aspecto horizontal", bar!!.aspect > 5f)
                assertTrue("${state.id}: zona dentro da barra", zone!!.left >= bar.left - 2f && zone.right <= bar.right + 2f)
            } else {
                assertTrue("${state.id}: sem barra visível não pode haver detecção", bar == null && zone == null && fish == null)
            }

            val barText = bar?.let { "${Normalization.format(Normalization.xOrNull(it.left, it.left, it.right))}→${Normalization.format(Normalization.xOrNull(it.right, it.left, it.right))}" } ?: "--"
            val zoneText = zone?.let { "${Normalization.format(zone.normalizedLeft(bar))}→${Normalization.format(zone.normalizedRight(bar))}" } ?: "--"
            val fishText = fish?.let { Normalization.format(fish.normalizedX(bar), 3) } ?: "--"

            val snapshot = VisionDebugSnapshot(
                frameIndex = frameIndex,
                timestampMillis = vision.timestampNanos / 1_000_000L,
                fps = 29.97,
                frameWidth = vision.frameWidth,
                frameHeight = vision.frameHeight,
                roi = vision.roi,
                mainBar = bar,
                zone = zone,
                fish = fish,
                progress = vision.progress,
                fishInsideZone = vision.fishInsideZone,
                zoneMarginNormalized = vision.zoneMarginNormalized,
                tracks = listOf(barTracker.snapshot(), zoneTracker.snapshot(), fishTracker.snapshot()),
                fsmState = "TRACKING",
                inputState = "DISABLED",
                outcome = null,
                processingMillis = vision.processingNanos / 1_000_000.0,
                lostFrames = 0,
            )
            val lines = DebugTextFormatter.lines(snapshot)
            FishingTestScenes.writeAnnotatedPng(payload, vision, lines, "final/${state.id}.png")

            output.appendLine(
                "| ${state.id} | $barText | $zoneText | $fishText | " +
                    "${if (vision.fishInsideZone) "YES" else "NO"} | ${if (bar != null) "VALID" else "LOST"} |",
            )
            output.appendLine()
            output.appendLine("**${state.id}** — ${state.description}")
            output.appendLine()
            output.appendLine("```")
            lines.forEach { output.appendLine(it) }
            output.appendLine("```")
            output.appendLine()
        }

        // Consistência temporal: o tracker tem de manter a barra através dos
        // estados (mesma entidade, movimento compatível — §11).
        assertTrue("a barra deve permanecer rastreada entre os estados", barTracker.valid)
        assertTrue("a zona deve ter sido rastreada", zoneTracker.valid || zoneTracker.state == TrackState.LOST)

        val reportFile = File(FishingTestScenes.evidenceDir(), "final/RELATORIO_VALIDACAO.md")
        reportFile.parentFile?.mkdirs()
        reportFile.writeText(output.toString())

        println("Evidência da Fase 7 gravada em: ${FishingTestScenes.evidenceDir().absolutePath}")
    }
}
