package com.fischvision.macro

import java.io.File
import java.util.zip.CRC32
import java.util.zip.Deflater

/**
 * Escritor PNG mínimo — Test implementation only.
 *
 * Por que não `javax.imageio`/`java.awt`: o source set de teste unitário do
 * Android compila contra o `android.jar`, que NÃO traz AWT/ImageIO. Escrever o
 * PNG à mão (assinatura + IHDR + IDAT com `java.util.zip` + IEND) mantém a
 * geração de evidência visual funcionando sem adicionar nenhuma dependência.
 */
object TinyPng {

    /** Escreve um PNG RGB (color type 2). [pixel] devolve ARGB. */
    fun write(file: File, width: Int, height: Int, pixel: (x: Int, y: Int) -> Int) {
        val raw = java.io.ByteArrayOutputStream((width * 3 + 1) * height)
        for (y in 0 until height) {
            raw.write(0) // filtro "none" por scanline
            for (x in 0 until width) {
                val argb = pixel(x, y)
                raw.write((argb shr 16) and 0xFF)
                raw.write((argb shr 8) and 0xFF)
                raw.write(argb and 0xFF)
            }
        }
        val compressed = deflate(raw.toByteArray())

        val out = java.io.ByteArrayOutputStream()
        out.write(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A))
        val ihdr = java.io.ByteArrayOutputStream()
        writeIntBigEndian(ihdr, width)
        writeIntBigEndian(ihdr, height)
        ihdr.write(8) // bit depth
        ihdr.write(2) // color type RGB
        ihdr.write(0)
        ihdr.write(0)
        ihdr.write(0)
        writeChunk(out, "IHDR", ihdr.toByteArray())
        writeChunk(out, "IDAT", compressed)
        writeChunk(out, "IEND", ByteArray(0))
        file.writeBytes(out.toByteArray())
    }

    /** Desenha um retângulo (contorno) diretamente no buffer ARGB. */
    fun outline(pixels: IntArray, width: Int, height: Int, left: Int, top: Int, right: Int, bottom: Int, color: Int) {
        fun set(x: Int, y: Int) {
            if (x in 0 until width && y in 0 until height) pixels[y * width + x] = color
        }
        for (x in left..right) {
            set(x, top)
            set(x, bottom)
        }
        for (y in top..bottom) {
            set(left, y)
            set(right, y)
        }
    }

    /** Desenha uma linha vertical (marcador do peixe). */
    fun verticalLine(pixels: IntArray, width: Int, height: Int, x: Int, top: Int, bottom: Int, color: Int, thickness: Int = 2) {
        for (offset in -(thickness / 2)..(thickness / 2)) {
            for (y in top..bottom) {
                val px = x + offset
                if (px in 0 until width && y in 0 until height) pixels[y * width + px] = color
            }
        }
    }

    private fun deflate(data: ByteArray): ByteArray {
        val deflater = Deflater(Deflater.BEST_SPEED)
        deflater.setInput(data)
        deflater.finish()
        val buffer = java.io.ByteArrayOutputStream(data.size / 2 + 64)
        val chunk = ByteArray(16 * 1024)
        while (!deflater.finished()) {
            val n = deflater.deflate(chunk)
            buffer.write(chunk, 0, n)
        }
        deflater.end()
        return buffer.toByteArray()
    }

    private fun writeIntBigEndian(out: java.io.ByteArrayOutputStream, value: Int) {
        out.write((value ushr 24) and 0xFF)
        out.write((value ushr 16) and 0xFF)
        out.write((value ushr 8) and 0xFF)
        out.write(value and 0xFF)
    }

    private fun writeChunk(out: java.io.ByteArrayOutputStream, type: String, data: ByteArray) {
        writeIntBigEndian(out, data.size)
        val typeBytes = type.toByteArray(Charsets.US_ASCII)
        out.write(typeBytes)
        out.write(data)
        val crc = CRC32()
        crc.update(typeBytes)
        crc.update(data)
        writeIntBigEndian(out, crc.value.toInt())
    }
}
