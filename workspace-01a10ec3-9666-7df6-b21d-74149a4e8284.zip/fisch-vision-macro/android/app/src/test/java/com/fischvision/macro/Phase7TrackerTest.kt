package com.fischvision.macro

import com.fischvision.macro.tracker.EntityTrackSnapshot
import com.fischvision.macro.tracker.EntityTracker
import com.fischvision.macro.tracker.TrackObservation
import com.fischvision.macro.tracker.TrackState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * §17/§18/§35 — tracker: aquisição, tracking, perda, recuperação e a janela
 * configurável `maxLostFrames`.
 */
class Phase7TrackerTest {

    private fun observation(x: Float, ts: Long, confidence: Float = 0.9f) =
        TrackObservation(centerX = x, centerY = 100f, confidence = confidence, timestampNanos = ts)

    private fun frameTime(index: Int): Long = index * 33_000_000L

    @Test
    fun `aquisicao exige frames coerentes antes de VALID`() {
        val tracker = EntityTracker(name = "FISH", maxLostFrames = 5, acquireFrames = 2)
        assertEquals(TrackState.IDLE, tracker.state)

        tracker.update(observation(100f, frameTime(0)), frameIndex = 0L, timestampNanos = frameTime(0))
        assertEquals("um único frame não basta para confiar no alvo", TrackState.ACQUIRING, tracker.state)
        assertFalse(tracker.valid)

        tracker.update(observation(102f, frameTime(1)), frameIndex = 1L, timestampNanos = frameTime(1))
        assertEquals(TrackState.VALID, tracker.state)
        assertTrue(tracker.valid)
    }

    @Test
    fun `tracking mantem estado e acumula idade`() {
        val tracker = EntityTracker(name = "ZONE", maxLostFrames = 5)
        for (i in 0 until 6) {
            tracker.update(observation(200f + i, frameTime(i)), i.toLong(), frameTime(i))
        }
        assertEquals(TrackState.TRACKING, tracker.state)
        assertEquals(5L, tracker.lastSeenFrame)
        assertTrue(tracker.age >= 5)
        assertTrue(tracker.snapshot().valid)
    }

    @Test
    fun `perda curta nao declara LOST`() {
        val tracker = EntityTracker(name = "BAR", maxLostFrames = 4)
        tracker.update(observation(300f, frameTime(0)), 0L, frameTime(0))
        tracker.update(observation(300f, frameTime(1)), 1L, frameTime(1))
        tracker.update(observation(300f, frameTime(2)), 2L, frameTime(2))
        assertEquals(TrackState.TRACKING, tracker.state)

        repeat(4) { tracker.miss(frameIndex = 3L + it) }
        assertEquals("4 frames perdidos com janela 4 ainda não é LOST", TrackState.TRACKING, tracker.state)
        assertFalse(tracker.lost)
        assertEquals(4, tracker.missedFrames)
    }

    @Test
    fun `perda acima da janela vira LOST`() {
        val tracker = EntityTracker(name = "BAR", maxLostFrames = 3)
        tracker.update(observation(300f, frameTime(0)), 0L, frameTime(0))
        tracker.update(observation(300f, frameTime(1)), 1L, frameTime(1))

        repeat(4) { tracker.miss(frameIndex = 2L + it) }
        assertEquals(TrackState.LOST, tracker.state)
        assertTrue(tracker.lost)
        assertFalse("LOST não é utilizável para decisão", tracker.valid)
    }

    @Test
    fun `recuperacao apos LOST reinicia a aquisicao`() {
        val tracker = EntityTracker(name = "ZONE", maxLostFrames = 2, acquireFrames = 2)
        tracker.update(observation(150f, frameTime(0)), 0L, frameTime(0))
        tracker.update(observation(150f, frameTime(1)), 1L, frameTime(1))
        tracker.update(observation(150f, frameTime(2)), 2L, frameTime(2))
        repeat(3) { tracker.miss(frameIndex = 3L + it) }
        assertEquals(TrackState.LOST, tracker.state)

        // Alvo reaparece perto da última posição: reaquisição, não salto.
        tracker.update(observation(155f, frameTime(6)), 6L, frameTime(6))
        assertEquals(TrackState.ACQUIRING, tracker.state)
        tracker.update(observation(158f, frameTime(7)), 7L, frameTime(7))
        assertEquals(TrackState.VALID, tracker.state)
        tracker.update(observation(160f, frameTime(8)), 8L, frameTime(8))
        assertEquals(TrackState.TRACKING, tracker.state)
        assertEquals("contadores de perda zerados após recuperação", 0, tracker.missedFrames)
    }

    @Test
    fun `salto maior que o permitido e tratado como ausencia e nao como alvo`() {
        val tracker = EntityTracker(name = "FISH", maxAssociationDistancePx = 30f, maxLostFrames = 5)
        tracker.update(observation(100f, frameTime(0)), 0L, frameTime(0))
        tracker.update(observation(102f, frameTime(1)), 1L, frameTime(1))

        val accepted = tracker.update(observation(400f, frameTime(2)), 2L, frameTime(2))
        assertFalse("teleporte deve ser rejeitado", accepted)
        assertEquals("rejeição conta como perda, não como nova posição", 1, tracker.missedFrames)
        assertTrue(tracker.centerX < 110f)
    }

    @Test
    fun `snapshot expoe tudo que o debug overlay precisa`() {
        val tracker = EntityTracker(name = "MAIN_BAR", maxLostFrames = 5)
        tracker.update(observation(400f, frameTime(0)), 0L, frameTime(0))
        val snapshot: EntityTrackSnapshot = tracker.snapshot()
        assertEquals("MAIN_BAR", snapshot.name)
        assertEquals(400f, snapshot.centerX, 0.5f)
        assertEquals(0L, snapshot.lastSeenFrame)
        assertTrue(snapshot.confidence in 0f..1f)
    }

    @Test
    fun `reset limpa estado para IDLE`() {
        val tracker = EntityTracker(name = "FISH")
        tracker.update(observation(100f, frameTime(0)), 0L, frameTime(0))
        tracker.reset()
        assertEquals(TrackState.IDLE, tracker.state)
        assertEquals(0, tracker.missedFrames)
        assertEquals(-1L, tracker.lastSeenFrame)
    }

    @Test
    fun `configuracao invalida e rejeitada na construcao`() {
        try {
            EntityTracker(name = "X", maxLostFrames = -1)
            error("maxLostFrames negativo deveria falhar")
        } catch (_: IllegalArgumentException) {
        }
        try {
            EntityTracker(name = "X", acquireFrames = 0)
            error("acquireFrames 0 deveria falhar")
        } catch (_: IllegalArgumentException) {
        }
    }

    @Test
    fun `observe com deteccao nula conta perda e devolve false`() {
        val tracker = EntityTracker(name = "FISH", maxLostFrames = 3)
        tracker.update(observation(100f, frameTime(0)), 0L, frameTime(0))
        val accepted = tracker.observe(frameIndex = 1L, timestampNanos = frameTime(1), observation = null)
        assertFalse(accepted)
        assertEquals(1, tracker.missedFrames)
    }
}
