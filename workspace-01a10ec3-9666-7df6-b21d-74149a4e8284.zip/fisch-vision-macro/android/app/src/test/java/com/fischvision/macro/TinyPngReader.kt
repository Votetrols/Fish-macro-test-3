package com.fischvision.macro

import java.io.File
import java.util.zip.Inflater

/**
 * Leitor PNG mínimo — Test implementation only.
 *
 * Necessário porque o source set de teste unitário do Android não tem
 * `javax.imageio`. Suporta o que o `ffmpeg` gera por padrão:
 * 8 bits por canal, sem entrelaçamento, color type 0 (cinza), 2 (RGB) ou 6 (RGBA).
 *
 * É este leitor que permite ao harness de replay (§36) consumir frames REAIS
 * extraídos do vídeo, sem adicionar nenhuma dependência ao projeto.
 */
object TinyPngReader {

    data class Decoded(val pixels: IntArray, val width: Int, val height: Int)

    fun read(file: File): Decoded? {
        val bytes = try {
            file.readBytes()
        } catch (e: Exception) {
            return null
        }
        if (bytes.size < 8) return null

        var offset = 8 // assinatura PNG
        var width = 0
        var height = 0
        var bitDepth = 0
        var colorType = 0
        var interlace = 0
        val idat = java.io.ByteArrayOutputStream()

        while (offset + 8 <= bytes.size) {
            val length = readInt(bytes, offset)
            val type = String(bytes, offset + 4, 4, Charsets.US_ASCII)
            val dataStart = offset + 8
            if (length < 0 || dataStart + length > bytes.size) break
            when (type) {
                "IHDR" -> {
                    width = readInt(bytes, dataStart)
                    height = readInt(bytes, dataStart + 4)
                    bitDepth = bytes[dataStart + 8].toInt() and 0xFF
                    colorType = bytes[dataStart + 9].toInt() and 0xFF
                    interlace = bytes[dataStart + 12].toInt() and 0xFF
                }
                "IDAT" -> idat.write(bytes, dataStart, length)
                "IEND" -> break
            }
            offset = dataStart + length + 4 // pula CRC
        }
        if (width <= 0 || height <= 0 || bitDepth != 8 || interlace != 0) return null

        val channels = when (colorType) {
            0 -> 1
            2 -> 3
            6 -> 4
            else -> return null
        }
        val stride = width * channels
        val raw = inflate(idat.toByteArray()) ?: return null
        if (raw.size < (stride + 1) * height) return null

        val pixels = IntArray(width * height)
        val previous = ByteArray(stride)
        val current = ByteArray(stride)
        var position = 0
        for (y in 0 until height) {
            val filter = raw[position++].toInt() and 0xFF
            System.arraycopy(raw, position, current, 0, stride)
            position += stride
            unfilter(filter, current, previous, channels, stride)
            for (x in 0 until width) {
                val base = x * channels
                val r: Int
                val g: Int
                val b: Int
                when (channels) {
                    1 -> {
                        r = current[base].toInt() and 0xFF
                        g = r
                        b = r
                    }
                    3 -> {
                        r = current[base].toInt() and 0xFF
                        g = current[base + 1].toInt() and 0xFF
                        b = current[base + 2].toInt() and 0xFF
                    }
                    else -> {
                        r = current[base].toInt() and 0xFF
                        g = current[base + 1].toInt() and 0xFF
                        b = current[base + 2].toInt() and 0xFF
                    }
                }
                pixels[y * width + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            System.arraycopy(current, 0, previous, 0, stride)
        }
        return Decoded(pixels, width, height)
    }

    /** Filtros PNG: 0 none · 1 sub · 2 up · 3 average · 4 paeth. */
    private fun unfilter(filter: Int, current: ByteArray, previous: ByteArray, bpp: Int, stride: Int) {
        when (filter) {
            0 -> Unit
            1 -> for (i in bpp until stride) {
                current[i] = (current[i] + current[i - bpp]).toByte()
            }
            2 -> for (i in 0 until stride) {
                current[i] = (current[i] + previous[i]).toByte()
            }
            3 -> for (i in 0 until stride) {
                val left = if (i >= bpp) current[i - bpp].toInt() and 0xFF else 0
                val up = previous[i].toInt() and 0xFF
                current[i] = (current[i] + ((left + up) / 2)).toByte()
            }
            4 -> for (i in 0 until stride) {
                val a = if (i >= bpp) current[i - bpp].toInt() and 0xFF else 0
                val b = previous[i].toInt() and 0xFF
                val c = if (i >= bpp) previous[i - bpp].toInt() and 0xFF else 0
                val p = a + b - c
                val pa = kotlin.math.abs(p - a)
                val pb = kotlin.math.abs(p - b)
                val pc = kotlin.math.abs(p - c)
                val predictor = when {
                    pa <= pb && pa <= pc -> a
                    pb <= pc -> b
                    else -> c
                }
                current[i] = (current[i] + predictor).toByte()
            }
        }
    }

    private fun inflate(data: ByteArray): ByteArray? {
        val inflater = Inflater()
        inflater.setInput(data)
        val out = java.io.ByteArrayOutputStream(data.size * 4)
        val buffer = ByteArray(64 * 1024)
        return try {
            while (!inflater.finished()) {
                val n = inflater.inflate(buffer)
                if (n == 0) {
                    if (inflater.needsInput() || inflater.needsDictionary()) break
                } else {
                    out.write(buffer, 0, n)
                }
            }
            out.toByteArray()
        } catch (e: Exception) {
            null
        } finally {
            inflater.end()
        }
    }

    private fun readInt(bytes: ByteArray, offset: Int): Int =
        ((bytes[offset].toInt() and 0xFF) shl 24) or
            ((bytes[offset + 1].toInt() and 0xFF) shl 16) or
            ((bytes[offset + 2].toInt() and 0xFF) shl 8) or
            (bytes[offset + 3].toInt() and 0xFF)
}
