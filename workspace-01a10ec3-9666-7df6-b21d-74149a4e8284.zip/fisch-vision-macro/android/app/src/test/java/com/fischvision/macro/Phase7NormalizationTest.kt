package com.fischvision.macro

import com.fischvision.macro.vision.Normalization
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * §15 + §14 — normalização de coordenadas e relação PEIXE ↔ ZONA.
 * Matriz exigida: X = left, X = center, X = right, X < left, X > right, width = 0.
 */
class Phase7NormalizationTest {

    private val left = 400f
    private val right = 1200f

    @Test
    fun `x na borda esquerda normaliza para 0`() {
        val result = Normalization.x(400f, left, right)
        assertTrue(result.valid)
        assertEquals(0f, result.value!!, 1e-6f)
        assertFalse(result.clamped)
    }

    @Test
    fun `x no centro normaliza para 0 ponto 5`() {
        val result = Normalization.x(800f, left, right)
        assertEquals(0.5f, result.value!!, 1e-6f)
        assertFalse(result.clamped)
    }

    @Test
    fun `x na borda direita normaliza para 1`() {
        val result = Normalization.x(1200f, left, right)
        assertEquals(1f, result.value!!, 1e-6f)
        assertFalse(result.clamped)
    }

    @Test
    fun `x antes da barra e clampado em 0 mas o valor cru e preservado`() {
        val result = Normalization.x(320f, left, right)
        assertTrue(result.valid)
        assertEquals(0f, result.value!!, 1e-6f)
        assertTrue(result.clamped)
        assertEquals(-0.1f, result.raw!!, 1e-5f)
    }

    @Test
    fun `x depois da barra e clampado em 1 mas o valor cru e preservado`() {
        val result = Normalization.x(1400f, left, right)
        assertEquals(1f, result.value!!, 1e-6f)
        assertTrue(result.clamped)
        assertEquals(1.25f, result.raw!!, 1e-5f)
    }

    @Test
    fun `largura zero invalida a normalizacao em vez de dividir por zero`() {
        val result = Normalization.x(500f, 500f, 500f)
        assertFalse(result.valid)
        assertNull(result.value)
        assertNull(result.raw)
        assertTrue(result.reason.contains("largura"))
    }

    @Test
    fun `barra invertida e tratada como invalida`() {
        val result = Normalization.x(500f, 1200f, 400f)
        assertFalse(result.valid)
        assertNull(Normalization.xOrNull(500f, 1200f, 400f))
    }

    @Test
    fun `nan e infinito invalidam a normalizacao`() {
        assertFalse(Normalization.x(Float.NaN, left, right).valid)
        assertFalse(Normalization.x(Float.POSITIVE_INFINITY, left, right).valid)
        assertFalse(Normalization.x(800f, Float.NaN, right).valid)
        assertFalse(Normalization.x(800f, left, Float.NEGATIVE_INFINITY).valid)
    }

    @Test
    fun `peixe dentro da zona satisfaz a condicao da especificacao`() {
        val relation = Normalization.zoneRelation(0.50f, 0.30f, 0.70f, marginNormalized = 0.01f)
        assertTrue(relation.valid)
        assertTrue(relation.insideRaw)
        assertTrue(relation.insideWithMargin)
        assertTrue(relation.inside)
        assertEquals(0.5f, relation.zoneNormalizedCenter!!, 1e-6f)
    }

    @Test
    fun `peixe na borda exata da zona conta como dentro`() {
        assertTrue(Normalization.zoneRelation(0.30f, 0.30f, 0.70f, 0f).insideRaw)
        assertTrue(Normalization.zoneRelation(0.70f, 0.30f, 0.70f, 0f).insideRaw)
    }

    @Test
    fun `peixe fora da zona respeita a margem configurada`() {
        // 0.71 está 0.01 fora da zona: sem margem é fora, com margem 0.02 é dentro.
        val strict = Normalization.zoneRelation(0.71f, 0.30f, 0.70f, marginNormalized = 0f)
        assertFalse(strict.insideRaw)
        assertFalse(strict.insideWithMargin)

        val tolerant = Normalization.zoneRelation(0.71f, 0.30f, 0.70f, marginNormalized = 0.02f)
        assertFalse(tolerant.insideRaw)
        assertTrue(tolerant.insideWithMargin)
        assertTrue(tolerant.inside)
    }

    @Test
    fun `margem nao esconde ausencia real de alvo`() {
        val relation = Normalization.zoneRelation(null, 0.30f, 0.70f, marginNormalized = 0.05f)
        assertFalse(relation.valid)
        assertFalse(relation.inside)
    }

    @Test
    fun `zona invertida e normalizada para o intervalo correto`() {
        val relation = Normalization.zoneRelation(0.5f, 0.70f, 0.30f, marginNormalized = 0f)
        assertEquals(0.30f, relation.zoneNormalizedLeft!!, 1e-6f)
        assertEquals(0.70f, relation.zoneNormalizedRight!!, 1e-6f)
        assertTrue(relation.insideRaw)
    }

    @Test
    fun `erro target menos indicator e calculado em unidades normalizadas`() {
        assertEquals(0.25f, Normalization.error(0.60f, 0.35f)!!, 1e-6f)
        assertEquals(-0.25f, Normalization.error(0.35f, 0.60f)!!, 1e-6f)
        assertNull(Normalization.error(null, 0.6f))
        assertNull(Normalization.error(Float.NaN, 0.6f))
    }

    @Test
    fun `formatacao nunca exibe nan e usa duas casas`() {
        assertEquals("--", Normalization.format(null))
        assertEquals("--", Normalization.format(Float.NaN))
        assertEquals("0.42", Normalization.format(0.4239f))
        assertEquals("0.472", Normalization.format(0.4719f, 3))
    }
}
