package com.fischvision.macro

import com.fischvision.macro.settings.MacroSettings
import com.fischvision.macro.vision.IntRect
import com.fischvision.macro.vision.RoiSample
import com.fischvision.macro.vision.detect.FishMarkerDetector
import com.fischvision.macro.vision.detect.FishingVisionAnalyzer
import com.fischvision.macro.vision.detect.InteractionZoneDetector
import com.fischvision.macro.vision.detect.MainBarDetector
import com.fischvision.macro.vision.detect.ProgressBarDetector
import com.fischvision.macro.vision.detect.VisionConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * §35 — testes de detector:
 *  - MainBarDetector: barra válida · objeto vertical · objeto pequeno · barra fora da ROI
 *  - InteractionZoneDetector: esquerda · central · direita · mudança de cor · ausente
 *  - FishMarkerDetector: válido · parcialmente visível · ausente · falso positivo
 */
class Phase7DetectorsTest {

    private val settings = MacroSettings.DEFAULT
    private val roiConfig = settings.roiConfig()

    private fun sampleOf(payload: SyntheticPayload, roi: IntRect): RoiSample =
        RoiSample().apply { sample(payload, roi, step = 2) }

    // ------------------------------------------------------------ MAIN BAR

    @Test
    fun `barra valida e detectada com geometria correta`() {
        val spec = FishingTestScenes.SceneSpec()
        val payload = FishingTestScenes.render(spec)
        val roi = roiConfig.resolve(payload.pixelWidth, payload.pixelHeight)
        val bar = MainBarDetector().detect(sampleOf(payload, roi), roi)

        assertNotNull(bar)
        assertEquals(0.20f, bar!!.left / payload.pixelWidth, 0.01f)
        assertEquals(0.64f, bar.right / payload.pixelWidth, 0.01f)
        assertEquals(0.678f, bar.top / payload.pixelHeight, 0.02f)
        assertEquals(0.748f, bar.bottom / payload.pixelHeight, 0.02f)
        assertTrue("aspecto deve ser horizontal: ${bar.aspect}", bar.aspect > 5f)
        assertTrue(bar.confidence >= VisionConfig.DEFAULT.barMinConfidence)
    }

    @Test
    fun `objeto vertical nao e aceito como barra (aspecto)`() {
        val payload = SyntheticPayload(960, 540)
        payload.fill(FishingTestScenes.rgb(12, 12, 16))
        // torre vertical clara, alta e estreita, dentro da ROI
        payload.rect(460, 330, 490, 500, FishingTestScenes.rgb(230, 230, 235))
        val roi = roiConfig.resolve(960, 540)
        val bar = MainBarDetector().detect(sampleOf(payload, roi), roi)
        assertNull("objeto vertical não pode passar no portão de aspecto", bar)
    }

    @Test
    fun `objeto pequeno nao e aceito como barra`() {
        val payload = SyntheticPayload(960, 540)
        payload.fill(FishingTestScenes.rgb(12, 12, 16))
        payload.rect(400, 370, 470, 385, FishingTestScenes.rgb(230, 230, 235)) // 70x15 px
        val roi = roiConfig.resolve(960, 540)
        val bar = MainBarDetector().detect(sampleOf(payload, roi), roi)
        assertNull("objeto de 70x15 px é pequeno demais para ser a barra", bar)
    }

    @Test
    fun `barra fora da ROI e rejeitada`() {
        // A barra é desenhada ACIMA da ROI do minigame (região do topo da tela).
        val payload = SyntheticPayload(960, 540)
        payload.fill(FishingTestScenes.rgb(12, 12, 16))
        payload.rect(200, 60, 760, 96, FishingTestScenes.rgb(232, 232, 238))
        val roi = roiConfig.resolve(960, 540)
        val bar = MainBarDetector().detect(sampleOf(payload, roi), roi)
        assertNull("estrutura fora da ROI nunca é válida", bar)
    }

    @Test
    fun `marcadores de extremidade sao evidencia auxiliar e nao portao`() {
        val withMarkers = FishingTestScenes.render(FishingTestScenes.SceneSpec(endMarkers = true))
        val withoutMarkers = FishingTestScenes.render(FishingTestScenes.SceneSpec(endMarkers = false))
        val roi = roiConfig.resolve(960, 540)
        val detector = MainBarDetector()
        val a = detector.detect(sampleOf(withMarkers, roi), roi)
        val b = detector.detect(sampleOf(withoutMarkers, roi), roi)

        assertNotNull("barra sem marcadores continua válida", b)
        assertNotNull(a)
        assertTrue("marcadores presentes devem dar bônus", a!!.confidence >= b!!.confidence)
    }

    // ---------------------------------------------------------------- ZONE

    @Test
    fun `zona e encontrada a esquerda centro e direita`() {
        val analyzer = FishingVisionAnalyzer(
            roiConfig = roiConfig,
            zoneMarginNormalized = settings.zoneEdgeMarginPercent,
        )
        listOf(0.05f, 0.33f, 0.62f).forEach { start ->
            val vision = analyzer.analyze(
                FishingTestScenes.frameOf(
                    FishingTestScenes.render(
                        FishingTestScenes.SceneSpec(
                            zoneStartOfBar = start,
                            zoneWidthOfBar = 0.28f,
                            fishPositionOfBar = start + 0.13f,
                        ),
                    ),
                ),
                1L,
            )
            val zone = vision.zone
            assertNotNull("zona deveria existir em start=$start", zone)
            val center = zone!!.normalizedCenter(vision.mainBar)!!
            assertEquals("centro da zona em start=$start", start + 0.14f, center, 0.05f)
        }
    }

    @Test
    fun `zona e detectada mesmo quando muda de cor (branca e alaranjada)`() {
        val white = FishingTestScenes.render(FishingTestScenes.SceneSpec(zoneWhite = true))
        val orange = FishingTestScenes.render(FishingTestScenes.SceneSpec(zoneWhite = false))
        val roi = roiConfig.resolve(960, 540)
        val barDetector = MainBarDetector()

        val barWhite = barDetector.detect(sampleOf(white, roi), roi)
        val barOrange = barDetector.detect(sampleOf(orange, roi), roi)
        assertNotNull(barWhite)
        assertNotNull(barOrange)

        val zoneWhite = InteractionZoneDetector().detect(sampleOf(white, roi), barWhite)
        val zoneOrange = InteractionZoneDetector().detect(sampleOf(orange, roi), barOrange)

        assertTrue("zona branca deve ser encontrada", zoneWhite.valid)
        assertTrue("zona alaranjada deve ser encontrada", zoneOrange.valid)
        assertEquals("mesma posição nos dois casos", zoneWhite.centerX, zoneOrange.centerX, 6f)
        assertTrue("matiz informada como característica auxiliar", zoneOrange.warmthDominance > zoneWhite.warmthDominance)
    }

    @Test
    fun `zona ausente e reportada como ausente`() {
        val payload = FishingTestScenes.render(FishingTestScenes.SceneSpec(zoneVisible = false))
        val roi = roiConfig.resolve(960, 540)
        val sample = sampleOf(payload, roi)
        val bar = MainBarDetector().detect(sample, roi)
        assertNotNull(bar)
        val zone = InteractionZoneDetector().detect(sample, bar)
        assertFalse("sem zona desenhada não pode haver zona válida", zone.valid)
    }

    @Test
    fun `zona nao existe sem barra`() {
        val payload = FishingTestScenes.render(FishingTestScenes.SceneSpec(barVisible = false, progressVisible = false))
        val roi = roiConfig.resolve(960, 540)
        val sample = sampleOf(payload, roi)
        assertNull(MainBarDetector().detect(sample, roi))
        assertFalse(InteractionZoneDetector().detect(sample, null).valid)
    }

    // ---------------------------------------------------------------- FISH

    @Test
    fun `marcador do peixe e encontrado no trecho util da barra`() {
        val analyzer = FishingVisionAnalyzer(roiConfig = roiConfig)
        val vision = analyzer.analyze(
            FishingTestScenes.frameOf(
                FishingTestScenes.render(FishingTestScenes.SceneSpec(fishPositionOfBar = 0.45f)),
            ),
            1L,
        )
        val fish = vision.fish
        assertNotNull("marcador deve ser detectado", fish)
        assertEquals(0.45f, fish!!.normalizedX(vision.mainBar)!!, 0.03f)
        assertTrue(fish.lineEvidence > 0.5f)
        assertTrue(fish.confidence >= VisionConfig.DEFAULT.fishMinConfidence)
    }

    @Test
    fun `marcador parcialmente visivel continua detectado (sem icone)`() {
        val analyzer = FishingVisionAnalyzer(roiConfig = roiConfig)
        val vision = analyzer.analyze(
            FishingTestScenes.frameOf(
                FishingTestScenes.render(FishingTestScenes.SceneSpec(fishIconVisible = false)),
            ),
            1L,
        )
        val fish = vision.fish
        assertNotNull("a linha vertical basta: o ícone é evidência auxiliar", fish)
        assertTrue("sem ícone a evidência de ícone é baixa", fish!!.iconEvidence < 0.5f)
        assertTrue("a linha continua forte", fish.lineEvidence > 0.5f)
    }

    @Test
    fun `marcador ausente nao gera falso positivo`() {
        val analyzer = FishingVisionAnalyzer(roiConfig = roiConfig)
        val vision = analyzer.analyze(
            FishingTestScenes.frameOf(FishingTestScenes.render(FishingTestScenes.SceneSpec(fishMarkerVisible = false))),
            1L,
        )
        assertNull("sem marcador não pode existir detecção de peixe", vision.fish)
    }

    @Test
    fun `extremidades da barra nao sao confundidas com o marcador do peixe`() {
        val analyzer = FishingVisionAnalyzer(roiConfig = roiConfig)
        val vision = analyzer.analyze(
            FishingTestScenes.frameOf(
                FishingTestScenes.render(FishingTestScenes.SceneSpec(fishPositionOfBar = 0.5f)),
            ),
            1L,
        )
        val fish = vision.fish!!
        val normalized = fish.normalizedX(vision.mainBar)!!
        assertTrue(
            "marcador detectado em $normalized: as tampas das extremidades (perto de 0 e 1) não podem ser eleitas",
            normalized > 0.08f && normalized < 0.92f,
        )
    }

    @Test
    fun `marcador dentro da zona e distinto da zona`() {
        val analyzer = FishingVisionAnalyzer(roiConfig = roiConfig)
        val vision = analyzer.analyze(
            FishingTestScenes.frameOf(FishingTestScenes.render(FishingTestScenes.SceneSpec())),
            1L,
        )
        val fish = vision.fish!!
        val zone = vision.zone!!
        val fishX = fish.normalizedX(vision.mainBar)!!
        val zoneLeft = zone.normalizedLeft(vision.mainBar)!!
        val zoneRight = zone.normalizedRight(vision.mainBar)!!

        assertTrue("peixe dentro da zona", insideZone(fishX, zoneLeft, zoneRight))
        assertTrue("zona tem largura de região, não de linha", (zoneRight - zoneLeft) > 0.15f)
        assertTrue("marcador continua sendo uma linha estreita", fish.width <= vision.mainBar!!.width * 0.10f)
    }

    private fun insideZone(x: Float, left: Float, right: Float) = x >= left - 0.02f && x <= right + 0.02f

    // ------------------------------------------------------------ PROGRESS

    @Test
    fun `barra de progresso e detectada separada da barra principal`() {
        val payload = FishingTestScenes.render(FishingTestScenes.SceneSpec(progressFill = 0.5f))
        val roi = roiConfig.resolve(960, 540)
        val sample = sampleOf(payload, roi)
        val bar = MainBarDetector().detect(sample, roi)!!
        val progress = ProgressBarDetector().detect(sample, bar, roi)

        assertTrue("barra de progresso deve ser encontrada", progress.valid)
        assertTrue("progresso fica ABAIXO da barra principal", progress.top > bar.bottom)
        assertTrue("progresso é mais fino que a barra principal", progress.height < bar.height)
    }

    @Test
    fun `barra de progresso nunca e eleita barra principal`() {
        val payload = FishingTestScenes.render(FishingTestScenes.SceneSpec())
        val roi = roiConfig.resolve(960, 540)
        val sample = sampleOf(payload, roi)
        val candidates = MainBarDetector().detectCandidates(sample, roi)

        // Mesmo quando a barra de progresso aparece como candidata (cena sem barra
        // principal), ela é rejeitada pelo portão de porte.
        assertTrue(candidates.isNotEmpty())
        val chosen = FishingVisionAnalyzer(roiConfig = roiConfig)
            .analyze(FishingTestScenes.frameOf(payload), 1L)
            .mainBar!!
        assertEquals(0.678f, chosen.top / 540f, 0.02f)
    }

    @Test
    fun `progresso e reportado como UNKNOWN quando nao ha sinal confiavel`() {
        val payload = FishingTestScenes.render(FishingTestScenes.SceneSpec(progressVisible = false))
        val roi = roiConfig.resolve(960, 540)
        val sample = sampleOf(payload, roi)
        val bar = MainBarDetector().detect(sample, roi)!!
        val progress = ProgressBarDetector().detect(sample, bar, roi)
        assertFalse("sem barra de progresso o resultado é UNKNOWN, nunca falso positivo", progress.valid)
        assertNull(progress.fillFraction)
    }

    @Test
    fun `sucesso da rodada nao e declarado por mera ausencia de deteccao`() {
        val analyzer = FishingVisionAnalyzer(roiConfig = roiConfig)
        val vision = analyzer.analyze(
            FishingTestScenes.frameOf(FishingTestScenes.render(FishingTestScenes.SceneSpec(barVisible = false))),
            1L,
        )
        assertNull(vision.mainBar)
        assertFalse("um frame sem barra não declara fim de minigame por si só", vision.fishInsideZone)
    }

    @Test
    fun `frame sem payload rgba retorna visao vazia sem excecao`() {
        val frame = com.fischvision.macro.capture.Frame(
            timestampNanos = 0L,
            width = 960,
            height = 540,
            rotationDegrees = 0,
            pixelFormat = com.fischvision.macro.capture.PixelFormat.RGBA_8888,
            payload = NoopPayload,
        )
        val vision = FishingVisionAnalyzer(roiConfig = roiConfig).analyze(frame, 7L)
        assertNull(vision.mainBar)
        assertNull(vision.zone)
        assertNull(vision.fish)
        assertFalse(vision.progress.valid)
    }
}
