package com.fischvision.macro

import com.fischvision.macro.capture.DecodedFrame
import com.fischvision.macro.capture.IntArrayRgbaPayload
import com.fischvision.macro.capture.RecordedFrameDecoder
import com.fischvision.macro.capture.RecordedFrameSource
import com.fischvision.macro.debug.DebugTextFormatter
import com.fischvision.macro.debug.VisionDebugSnapshot
import com.fischvision.macro.settings.MacroSettings
import com.fischvision.macro.tracker.EntityTracker
import com.fischvision.macro.tracker.TrackObservation
import com.fischvision.macro.vision.detect.FishingVisionAnalyzer
import com.fischvision.macro.vision.detect.VisionConfig
import java.io.File
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * §36 — HARNESS DE REPLAY: alimenta frames GRAVADOS no MESMO pipeline de visão.
 *
 * `FRAME → DETECTOR → TRACKER` sem Roblox e sem device. Serve para:
 *  1. calibrar os limiares com os frames do vídeo de referência;
 *  2. reproduzir qualquer problema relatado com os pixels exatos que o causaram;
 *  3. gerar a evidência do §37 (imagens anotadas + relatório).
 *
 * COMO USAR quando os frames existirem:
 *
 * ```bash
 * mkdir -p app/src/test/resources/frames
 * ffmpeg -i 1000032864.mp4 -ss 5.5 -frames:v 1 app/src/test/resources/frames/055.png
 * ffmpeg -i 1000032864.mp4 -ss 8   -frames:v 1 app/src/test/resources/frames/080.png
 * ffmpeg -i 1000032864.mp4 -ss 10  -frames:v 1 app/src/test/resources/frames/100.png
 * ffmpeg -i 1000032864.mp4 -ss 12  -frames:v 1 app/src/test/resources/frames/120.png
 * ffmpeg -i 1000032864.mp4 -ss 14  -frames:v 1 app/src/test/resources/frames/140.png
 * ffmpeg -i 1000032864.mp4 -ss 15  -frames:v 1 app/src/test/resources/frames/150.png
 * ./gradlew :app:testDebugUnitTest --tests '*Phase7ReplayHarnessTest*'
 * ```
 *
 * Também aceita um diretório arbitrário via `-Dfvm.framesDir=/caminho`.
 *
 * SEM FRAMES, o harness não inventa resultado: ele registra que não há insumo e
 * passa. Com frames, ele processa TODOS, escreve a evidência e publica a taxa de
 * detecção de cada entidade — o número que diz se a calibração está boa.
 */
class Phase7ReplayHarnessTest {

    /** Decodificador sem AWT: PNG (TinyPngReader) ou binário RGBA cru (ffmpeg). */
    private object TestFrameDecoder : RecordedFrameDecoder {
        override fun decode(file: File): DecodedFrame? {
            val extension = file.extension.lowercase()
            if (extension == "png") {
                val decoded = TinyPngReader.read(file)
                return decoded?.let { DecodedFrame(it.pixels, it.width, it.height) }
            }
            if (extension == "rgba") {
                // Nome esperado: <algo>_<largura>x<altura>.rgba
                val match = Regex("(\\d+)x(\\d+)").find(file.nameWithoutExtension) ?: return null
                val width = match.groupValues[1].toInt()
                val height = match.groupValues[2].toInt()
                val bytes = file.readBytes()
                if (bytes.size < width * height * 4) return null
                val pixels = IntArray(width * height)
                for (i in pixels.indices) {
                    val base = i * 4
                    val r = bytes[base].toInt() and 0xFF
                    val g = bytes[base + 1].toInt() and 0xFF
                    val b = bytes[base + 2].toInt() and 0xFF
                    val a = bytes[base + 3].toInt() and 0xFF
                    pixels[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
                }
                return DecodedFrame(pixels, width, height)
            }
            return null
        }
    }

    private fun framesDirectory(): File {
        System.getProperty("fvm.framesDir")?.let { return File(it) }
        return File("src/test/resources/frames")
    }

    @Test
    fun `replay dos frames gravados alimenta o pipeline e mede a deteccao`() {
        val directory = framesDirectory()
        val files = directory.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() in setOf("png", "rgba") }
            ?.sortedBy { it.name }
            ?: emptyList()

        if (files.isEmpty()) {
            println(
                """
                [REPLAY] Nenhum frame gravado em ${directory.absolutePath}.
                [REPLAY] Este harness está pronto, mas não há insumo: o vídeo 1000032864.mp4
                [REPLAY] não foi disponibilizado no repositório nem neste ambiente.
                [REPLAY] Extraia os frames do vídeo (instruções no KDoc desta classe) e rode de novo.
                """.trimIndent(),
            )
            return
        }

        val settings = MacroSettings.DEFAULT
        val analyzer = FishingVisionAnalyzer(
            config = VisionConfig.DEFAULT,
            roiConfig = settings.roiConfig(),
            zoneMarginNormalized = settings.zoneEdgeMarginPercent,
        )
        val barTracker = EntityTracker(name = "MAIN_BAR", maxLostFrames = settings.maxLostFrames)
        val zoneTracker = EntityTracker(name = "ZONE", maxLostFrames = settings.maxLostFrames)
        val fishTracker = EntityTracker(name = "FISH", maxLostFrames = settings.maxLostFrames)

        val source = RecordedFrameSource(directory, TestFrameDecoder, playbackFps = 1_000, loop = false)
        val frames = mutableListOf<com.fischvision.macro.capture.Frame>()
        runBlocking {
            source.start()
            source.frames().collect { frames.add(it) }
        }
        assertTrue("os frames deveriam ter sido lidos", frames.isNotEmpty())

        var barFound = 0
        var zoneFound = 0
        var fishFound = 0
        var progressFound = 0
        val report = StringBuilder()
        report.appendLine("# Fase 7 — replay de frames gravados")
        report.appendLine()
        report.appendLine("Arquivos processados: ${frames.size} (${directory.absolutePath})")
        report.appendLine()
        report.appendLine("| arquivo | MAIN BAR | ZONE | FISH | PROGRESS | FISH IN ZONE |")
        report.appendLine("|---|---|---|---|---|---|")

        frames.forEachIndexed { index, frame ->
            val vision = analyzer.analyze(frame, index.toLong())
            val bar = vision.mainBar
            val zone = vision.zone
            val fish = vision.fish
            if (bar != null) barFound++
            if (zone != null) zoneFound++
            if (fish != null) fishFound++
            if (vision.progress.valid) progressFound++

            bar?.let {
                barTracker.update(TrackObservation(it.centerX, it.centerY, it.confidence, frame.timestampNanos), index.toLong(), frame.timestampNanos)
            } ?: barTracker.miss(index.toLong())
            zone?.let {
                zoneTracker.update(TrackObservation(it.centerX, it.centerY, it.confidence, frame.timestampNanos), index.toLong(), frame.timestampNanos)
            } ?: zoneTracker.miss(index.toLong())
            fish?.let {
                fishTracker.update(TrackObservation(it.centerX, it.centerY, it.confidence, frame.timestampNanos), index.toLong(), frame.timestampNanos)
            } ?: fishTracker.miss(index.toLong())

            report.appendLine(
                "| ${files.getOrNull(index)?.name ?: index} | " +
                    "${if (bar != null) "%.2f".format(bar.confidence) else "--"} | " +
                    "${if (zone != null) "%.2f".format(zone.confidence) else "--"} | " +
                    "${if (fish != null) "%.2f".format(fish.confidence) else "--"} | " +
                    "${if (vision.progress.valid) "%.2f".format(vision.progress.confidence) else "UNKNOWN"} | " +
                    "${if (vision.fishInsideZone) "YES" else "NO"} |",
            )

            val payload = frame.payload as? IntArrayRgbaPayload
            if (payload != null) {
                val snapshot = VisionDebugSnapshot(
                    frameIndex = index.toLong(),
                    timestampMillis = frame.timestampNanos / 1_000_000L,
                    fps = 0.0,
                    frameWidth = vision.frameWidth,
                    frameHeight = vision.frameHeight,
                    roi = vision.roi,
                    mainBar = bar,
                    zone = zone,
                    fish = fish,
                    progress = vision.progress,
                    fishInsideZone = vision.fishInsideZone,
                    zoneMarginNormalized = vision.zoneMarginNormalized,
                    tracks = listOf(barTracker.snapshot(), zoneTracker.snapshot(), fishTracker.snapshot()),
                    fsmState = "TRACKING",
                    inputState = "DISABLED",
                    outcome = null,
                    processingMillis = vision.processingNanos / 1_000_000.0,
                    lostFrames = 0,
                )
                FishingTestScenes.writeAnnotatedPng(
                    SyntheticPayload(payload.pixelWidth, payload.pixelHeight).also { synthetic ->
                        for (y in 0 until payload.pixelHeight) {
                            for (x in 0 until payload.pixelWidth) {
                                payload.argbAt(x, y)?.let { synthetic.set(x, y, it) }
                            }
                        }
                    },
                    vision,
                    DebugTextFormatter.lines(snapshot),
                    "replay/${files.getOrNull(index)?.nameWithoutExtension ?: index}.png",
                )
            }
        }

        val total = frames.size
        report.appendLine()
        report.appendLine("## Taxa de detecção")
        report.appendLine()
        report.appendLine("- MAIN BAR: $barFound/$total")
        report.appendLine("- ZONE: $zoneFound/$total")
        report.appendLine("- FISH: $fishFound/$total")
        report.appendLine("- PROGRESS: $progressFound/$total")
        val reportFile = File(FishingTestScenes.evidenceDir(), "replay/RELATORIO_REPLAY.md")
        reportFile.parentFile?.mkdirs()
        reportFile.writeText(report.toString())
        println("[REPLAY] $total frames processados · bar=$barFound zone=$zoneFound fish=$fishFound progress=$progressFound")
        println("[REPLAY] evidência: ${reportFile.absolutePath}")
    }
}
