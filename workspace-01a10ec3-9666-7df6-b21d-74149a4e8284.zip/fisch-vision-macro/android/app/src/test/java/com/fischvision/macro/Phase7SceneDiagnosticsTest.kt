package com.fischvision.macro

import com.fischvision.macro.settings.MacroSettings
import com.fischvision.macro.vision.Normalization
import com.fischvision.macro.vision.detect.FishingVisionAnalyzer
import com.fischvision.macro.vision.detect.VisionConfig
import org.junit.Test

/**
 * DIAGNÓSTICO da Fase 7 — imprime o que os detectores realmente encontraram em
 * cada cena sintética e grava um PNG anotado em `artifacts/phase7-validation`.
 *
 * Este teste é o instrumento de calibração: ele NÃO esconde falha de detecção,
 * mostra os números crus (posição, normalizados, confidence e critérios) para
 * que os limiares sejam ajustados com evidência, e não por tentativa cega.
 */
class Phase7SceneDiagnosticsTest {

    private fun analyzer() = FishingVisionAnalyzer(
        config = VisionConfig.DEFAULT,
        roiConfig = MacroSettings.DEFAULT.roiConfig(),
        zoneMarginNormalized = MacroSettings.DEFAULT.zoneEdgeMarginPercent,
    )

    @Test
    fun `imprime diagnostico das cenas sinteticas`() {
        val cases = listOf(
            "zona_esquerda_branca" to FishingTestScenes.SceneSpec(zoneStartOfBar = 0.05f, zoneWidthOfBar = 0.25f, zoneWhite = true, fishPositionOfBar = 0.20f),
            "zona_centro_branca" to FishingTestScenes.SceneSpec(zoneStartOfBar = 0.33f, zoneWidthOfBar = 0.30f, zoneWhite = true, fishPositionOfBar = 0.48f),
            "zona_direita_branca" to FishingTestScenes.SceneSpec(zoneStartOfBar = 0.62f, zoneWidthOfBar = 0.28f, zoneWhite = true, fishPositionOfBar = 0.76f),
            "zona_centro_laranja" to FishingTestScenes.SceneSpec(zoneStartOfBar = 0.33f, zoneWidthOfBar = 0.30f, zoneWhite = false, fishPositionOfBar = 0.48f),
            "zona_ausente" to FishingTestScenes.SceneSpec(zoneVisible = false, fishPositionOfBar = 0.48f),
            "peixe_fora_da_zona" to FishingTestScenes.SceneSpec(zoneStartOfBar = 0.05f, zoneWidthOfBar = 0.20f, fishPositionOfBar = 0.72f),
            "marcador_sem_icone" to FishingTestScenes.SceneSpec(fishIconVisible = false),
            "barra_ausente" to FishingTestScenes.SceneSpec(barVisible = false, progressVisible = false),
            "progresso_ausente" to FishingTestScenes.SceneSpec(progressVisible = false),
            "barra_escura" to FishingTestScenes.SceneSpec(),
        )
        for ((name, spec) in cases) {
            val payload = FishingTestScenes.render(spec)
            val analyzer = analyzer()
            val vision = analyzer.analyze(FishingTestScenes.frameOf(payload), 1L)
            val bar = vision.mainBar
            val zone = vision.zone
            val fish = vision.fish
            println(
                """
                [DIAG] $name
                  bar  = ${if (bar == null) "NOT FOUND" else "px[${bar.left.toInt()}..${bar.right.toInt()}] y[${bar.top.toInt()}..${bar.bottom.toInt()}] conf=${"%.3f".format(bar.confidence)} markers=${bar.endMarkers}"}
                  zone = ${if (zone == null) "NOT FOUND" else "norm[${Normalization.format(zone.normalizedLeft(bar))}..${Normalization.format(zone.normalizedRight(bar))}] center=${Normalization.format(zone.normalizedCenter(bar))} conf=${"%.3f".format(zone.confidence)} warmth=${"%.2f".format(zone.warmthDominance)}"}
                  fish = ${if (fish == null) "NOT FOUND" else "norm=${Normalization.format(fish.normalizedX(bar), 3)} px=${fish.centerX.toInt()} conf=${"%.3f".format(fish.confidence)} line=${"%.2f".format(fish.lineEvidence)} icon=${"%.2f".format(fish.iconEvidence)}"}
                  prog = ${if (!vision.progress.valid) "UNKNOWN" else "px[${vision.progress.left.toInt()}..${vision.progress.right.toInt()}] fill=${vision.progress.fillFraction?.let { "%.2f".format(it) }} conf=${"%.3f".format(vision.progress.confidence)}"}
                  inZone=${vision.fishInsideZone}
                """.trimIndent(),
            )
            FishingTestScenes.writeAnnotatedPng(payload, vision, listOf("DIAG $name"), "$name.png")
        }
    }
}
