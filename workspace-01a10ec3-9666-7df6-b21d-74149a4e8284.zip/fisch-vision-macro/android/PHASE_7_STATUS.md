# Phase 7 Status — Visão, Calibração e Debug do Minigame

**Escopo cumprido:** CAPTURA → ROI → DETECÇÃO → TRACKING → NORMALIZAÇÃO →
DEBUG OVERLAY → VALIDAÇÃO, com **INPUT = DISABLED** durante toda a fase.

O que esta fase **não** fez, por decisão explícita: nenhum gesto, nenhum
ShakeDetector, nenhuma automação de gameplay, nenhum OCR.

---

## 1. Situação do insumo (leia primeiro)

| Insumo | Situação real |
|---|---|
| Repositório `Votetrols/Fish-macro-test-3` (ZIP em `main`) | **Acessado** — projeto extraído e lido integralmente (45 arquivos Kotlin, testes, Gradle, manifest, resources, 9 docs) |
| `1000032864.mp4` (vídeo de referência) | **NÃO DISPONÍVEL** — o vídeo não existe no repositório nem foi anexado ao ambiente de trabalho |
| Frames extraídos do vídeo | **NÃO DISPONÍVEIS** — consequência direta do item anterior |
| Device/emulador Android | **NÃO DISPONÍVEL** — validação em aparelho real continua BLOCKED |

Consequência metodológica: **nenhum resultado é apresentado como se o vídeo
tivesse sido processado**. Em vez de fingir a validação com o vídeo, a fase
entregou (a) um gerador de cenas que reproduz a estrutura descrita do minigame,
(b) um harness de replay para engolir os frames reais assim que existirem e
(c) evidência visual por estado. Ver `PHASE_7_VALIDATION.md`.

---

## 2. Pipeline implementado (§6)

```
MediaProjection
   ↓  MediaProjectionFrameSource  (ciclo de parada corrigido — §29)
FrameSource → Frame (payload RGBA com propriedade por refcount — §30)
   ↓  FrameBus (conflação + janela de vida de 1 frame)
ROI  (RoiConfig em percentuais — §7)
   ↓  RoiSample: UMA amostragem por frame (luma / calor R−B / valor)
Vision Processor (FishingVisionAnalyzer)
   ↓
MainBarDetector → InteractionZoneDetector → FishMarkerDetector → ProgressBarDetector
   ↓
Tracker (EntityTracker × MAIN_BAR / ZONE / FISH — VALID·TRACKING·LOST — §17/§18)
   ↓
Normalização (Normalization: 0.0 = esquerda da barra, 1.0 = direita — §15)
   ↓
Debug Overlay (VisionDebugOverlay + DebugOverlayView + DebugTextFormatter — §20/§21)
```

Nenhuma ligação com `AccessibilityInputController` foi criada. A guarda central
(§26) existe, é consultada e **bloqueia**; não há caminho que a contorne.

---

## 3. Arquivos criados nesta fase

### Visão / detecção
| Arquivo | Papel |
|---|---|
| `vision/RoiConfig.kt` | ROI do minigame em percentuais + derivação documentada do ponto de partida |
| `vision/Normalization.kt` | Normalização de X contra a barra, relação PEIXE↔ZONA com margem configurável, erro target−indicator, formatação |
| `vision/RoiSample.kt` | Amostragem da ROI com buffers reutilizados (luma, calor R−B, valor) + estatística robusta de fundo |
| `vision/detect/VisionConfig.kt` | **Todos** os limiares da fase, explícitos e comentados |
| `vision/detect/BandScanner.kt` | Varredura de faixas horizontais com tolerância a buracos + evidência de extremidades |
| `vision/detect/MainBarDetector.kt` | Detector da barra principal |
| `vision/detect/InteractionZoneDetector.kt` | Detector da zona de interação (multi-característica) |
| `vision/detect/FishMarkerDetector.kt` | Detector do marcador do peixe (linha + ícone auxiliar) |
| `vision/detect/ProgressBarDetector.kt` | Detector da barra de progresso (separada por geometria/posição) |
| `vision/detect/FishingVisionAnalyzer.kt` | Orquestra ROI → 4 detectores → normalização por frame |
| `vision/detect/Detections.kt` | `MainBarDetection`, `InteractionZoneDetection`, `FishMarkerDetection`, `ProgressBarDetection`, `FishingVisionFrame` |
| `vision/outcome/MinigameOutcomeDetector.kt` | Infraestrutura de SUCCESS/FAILED sem OCR (§33) + `UiChangeTracker` |

### Tracking / captura / serviços
| Arquivo | Papel |
|---|---|
| `tracker/EntityTracker.kt` | Rastreador genérico com VALID/TRACKING/LOST, age, lastSeenFrame, recuperação |
| `capture/FrameOwnership.kt` | `RefCountedFramePayload` — contrato de propriedade documentado (§30) |
| `capture/CaptureEvents.kt` | `CaptureEvent` / `CaptureEventSource` (ciclo de parada — §29) |
| `capture/RecordedFrameSource.kt` | Fonte de frames gravados (§36) + payload a partir de IntArray |
| `capture/AndroidBitmapDecoder.kt` | Decodificador PNG/JPG por `BitmapFactory` (sem dependência nova) |
| `service/CalibrationEngine.kt` | Pipeline da fase: visão+tracking+overlay com FSM existente, INPUT OFF |

### Debug / overlay / segurança
| Arquivo | Papel |
|---|---|
| `debug/VisionDebugSnapshot.kt` | Estado completo do frame + `DebugTextFormatter` (texto do overlay, testável em JVM) |
| `debug/EventLog.kt` | Logging por evento com supressão e teto por segundo (§41) |
| `debug/DebugFrameCapture.kt` | Política de gravação de frames de debug (desligada por padrão — §24) |
| `debug/PngDebugFrameSink.kt` | Gravação do frame real + caixas + texto (só quando habilitada) |
| `overlay/DebugOverlayView.kt` | Desenho das caixas e do painel de texto (§20–§22) |
| `overlay/VisionDebugOverlay.kt` | Janela do overlay (intocável + chip de STOP) |
| `input/InputSafetyGuard.kt` | Camada central de segurança (§26/§28) — 8 condições |
| `input/InputWiring.kt` | Converte `MacroSettings` em contexto de segurança (mata o `controllerEnabled` decorativo) |

### Testes criados
`FishingTestScenes.kt` (gerador de cenas + evidência PNG), `TinyPng.kt` (escritor PNG
sem dependências), `Phase7NormalizationTest`, `Phase7DetectorsTest`,
`Phase7TrackerTest`, `Phase7SafetyTest`, `Phase7RateLimiterTest`,
`Phase7FrameOwnershipTest`, `Phase7CalibrationFlowTest` (+ `Phase7OutcomeTest`),
`Phase7SceneDiagnosticsTest`, `Phase7ValidationReportTest`.

---

## 4. Arquivos modificados nesta fase

| Arquivo | Modificação | Motivo |
|---|---|---|
| `capture/ScreenCaptureManager.kt` | `onStop()` real → libera display/reader, fecha o fluxo de frames, publica `ProjectionStopped`; `releaseAll()` não chama `stop()` durante o callback | §29 |
| `capture/FrameBus.kt` | `publishShared()` com janela de retenção de 1 frame + `withLatestFrame()` | §30 |
| `core/MacroEvent.kt` | **Adicionado** `OutcomeObserved` (nada removido) | §33 |
| `core/MacroStateMachine.kt` | Transições do evento novo | §33/§34 |
| `service/MacroEngine.kt` | `publishShared`, consumo do ciclo de parada, correção de `LogSink` | §29/§30 |
| `service/MacroForegroundService.kt` | Caminho de CALIBRAÇÃO (padrão) + recusa do caminho de controle; guarda central no caminho de controle | §25/§26/§27 |
| `input/AccessibilityInputController.kt` | Correção do rate limiter (`Long.MIN_VALUE` → estado explícito) + consulta à guarda central + `resetRateLimiter()` | §31/§26 |
| `controller/FishingControllerImpl.kt` | Mesma correção de sentinela em `lastTransitionAtNanos` | §31 |
| `settings/MacroSettings.kt` | ROI percentual, margem da zona, `maxLostFrames`, `calibrationMode`, `inputEnabled`, `targetAppPackage`, flags de debug | §7/§14/§18/§24/§25 |
| `MainActivity.kt` | Seção de calibração (iniciar/parar/overlay) + status de INPUT | §25/§47 |
| `app/build.gradle.kts` | `testOptions.unitTests.isReturnDefaultValues = true` | permitir que a suíte JVM rode com `android.util.Log` real (stub de plataforma) |
| `README.md`, `FINAL_AUDIT.md` | Estado da Fase 7 | §42 |

Arquivos **não** alterados (preservação da arquitetura): `Frame.kt`,
`FrameSource.kt`, `Detector.kt`, `Detection.kt`, `Tracker.kt`,
`TrackingResult.kt`, `EmaTargetTracker.kt`, `Controller.kt`, `ControlCommand.kt`,
`InputController.kt`, `InputCommand.kt`, `OverlayManager.kt`,
`WindowOverlayManager.kt`, `MacroAccessibilityService.kt`, `MacroError.kt`,
`MacroState.kt`, `DebugLogger.kt`, `vision/VisionCore.kt`,
`vision/VisionPipelineImpl.kt`, `vision/VisionProcessor.kt`,
`vision/VisionResult.kt`, manifest, resources e o site (Vite/React).

---

## 5. Defeitos corrigidos (§48.3)

1. **Rate limiter com `Long.MIN_VALUE` (input).** Sentinela aritmética fazia
   `now - lastCommandAtNanos` estourar e devolver negativo → o **primeiro
   comando do processo era sempre recusado**. Corrigido com estado explícito
   (`hasLastCommand`). Testes: primeiro comando, segundo imediato, após o
   intervalo, reset, release (`Phase7RateLimiterTest`).
2. **Mesma sentinela no controlador lógico.** `lastTransitionAtNanos` atrasava o
   primeiro PRESS. Corrigido com `hasTransition` e testado.
3. **`callbackFlow(capacity=…)` inexistente** em `ScreenCaptureManager` — a
   política de buffer agora entra pelo operador `.buffer(2, DROP_OLDEST)`.
   (Erro de compilação real: o projeto **nunca havia sido compilado**.)
4. **`ControlCommand(Type.NONE)`** sem qualificador em `FishingControllerImpl`
   — erro de compilação.
5. **`fun interface LogSink` com valor padrão** em método abstrato — não é
   permitido em Kotlin: erro de compilação. Resolvido com extensão de
   conveniência (chamadas existentes intactas).
6. **`scriptFrom(build: (Int) -> …)` chamado com `Long`** em
   `IntegrationFlowTest` — erro de compilação no teste.
7. **`driveTo(MacroState.IDLE)`** não implementado em `MacroStateMachineTest` —
   a matriz de transições inválidas quebrava ao chegar no caso IDLE.
8. **Cena sintética fora da própria ROI** em `VisionPipelineTest` (barra a 37% da
   altura, ROI automática começa a 52%) — o teste "detecção dentro da ROI
   automática" falhava por construção da cena.
9. **Cache de máscara chaveado por timestamp** (defeito introduzido e corrigido
   nesta fase): dois frames com o mesmo `timestampNanos` reaproveitavam a máscara
   anterior e geravam **detecção fantasma**. A chave passou a ser uma época
   explícita incrementada por frame.
10. **Marcador do peixe confundido com as extremidades da barra** (defeito
    medido no diagnóstico): as tampas das extremidades são linhas verticais
    estreitas, geometricamente idênticas ao marcador. A busca ganhou exclusão de
    extremidade configurável (`fishEndExclusionPercentOfBar`) — restrição de
    região, não remendo.
11. **Barra principal eleita a partir da barra de progresso** (cena sem barra
    principal elegia a barra fina): resolvido com portão de porte
    (`barMinHeightPercentOfRoi = 0.10`) + regra de escolha pela espessura.
12. **Marcador vertical atravessando a barra dividia o trecho contínuo** e o
    detector escolhia metade da barra: adicionada tolerância a buracos
    (`barGapToleranceCells`) na extensão horizontal.
13. **Peixe dentro da zona clara desaparecia** para o detector (a coluna se funde
    ao patamar da zona): extração reescrita com **saliência de faixa estreita**
    (coluna × linha de base dos dois lados) + unificação de contornos.

---

## 6. Como ativar o Calibration Mode (§25/§48.8)

O modo é o **padrão** desta fase — não há flag escondida:

1. `MacroSettings.calibrationMode = true` e `inputEnabled = false` (padrão do
   `DEFAULT`; `controllerEnabled` continua `false`).
2. Instale o APK (`app/build/outputs/apk/debug/app-debug.apk`).
3. Abra o app → **MODO CALIBRAÇÃO (FASE 7)** → botão **OVERLAY** e conceda
   "Sobrepor outros apps" (sem isso a visão roda, mas nada é desenhado).
4. **INICIAR CALIBRAÇÃO** → aceite o diálogo de captura do sistema.
5. Entre no jogo (Roblox/Fisch) e pesque: os retângulos e o painel aparecem sobre
   a tela. O chip no canto superior direito tem **■ STOP** e **◐ VIEW**.
6. Logs: `adb logcat -s FVM/VISION FVM/CAPTURE FVM/SERVICE` — eventos
   `BAR_ACQUIRED`, `ZONE_ACQUIRED`, `FISH_ACQUIRED`, `TRACK_LOST`, `SUCCESS`,
   `ERROR` e um resumo de 2 Hz com FPS/FSM/INPUT.

Com `calibrationMode = true`, a guarda central recusa **todo** gesto, mesmo que
outro módulo chame o controller — `INPUT: DISABLED` aparece no painel.

---

## 7. Estado de execução (o que foi realmente rodado)

| Comando | Resultado |
|---|---|
| `./gradlew clean` | ver `PHASE_7_VALIDATION.md` |
| `./gradlew test` | ver `PHASE_7_VALIDATION.md` (170 casos, resultado real) |
| `./gradlew lint` | ver `PHASE_7_VALIDATION.md` |
| `./gradlew assembleDebug` | ver `PHASE_7_VALIDATION.md` (APK produzido) |
| `./gradlew connectedAndroidTest` | **NÃO EXECUTADO** — nenhum device/emulador no ambiente |

Toolchain instalada neste ambiente para viabilizar a execução: JDK 17 (Temurin
17.0.20.1), Gradle 9.5.0, Android SDK Platform 37 (`platforms;android-37.0`),
Build-Tools 37.0.0 e 36.0.0. O wrapper (`gradlew`, `gradlew.bat`,
`gradle/wrapper/gradle-wrapper.jar`) foi gerado com Gradle 9.5.0 (§44) sem
alterar versões de AGP/Kotlin/SDK.

---

## 8. Limitações conhecidas (nada aqui foi validado em aparelho)

1. **Vídeo de referência ausente** → o pipeline nunca viu um frame real do Fisch.
   A geometria da ROI é uma derivação documentada das observações descritas
   (`X 380–1240`, `Y 735–805` em 1920×1080), não uma medição feita.
2. **Nenhum teste em device**: captura real, overlay real e desempenho de CPU
   continuam não medidos. O overlay de janela única em tela cheia pode exigir
   ajuste de posicionamento em telas com recorte/notch.
3. **Limiares não calibrados**: `VisionConfig` e `RoiConfig` são pontos de
   partida. A fase entregou o instrumento (diagnóstico + overlay + evidência);
   o ajuste fino exige os frames reais.
4. **`UiChangeTracker`** (sinal de mudança de UI do §33) não é exercitado por
   frame real; só pela ausência sintética da barra.
5. **Detector de progresso**: a fração preenchida é medida por contraste interno;
   a relação com o progresso real do jogo não foi verificada.
6. **FX de partículas/efeitos**: o gerador sintético inclui ruído, mas efeitos
   reais do jogo (bloom, motion blur, textos sobrepostos) não foram testados.
7. **`RoiSample`/`BandScanner` não são thread-safe** (um consumidor por
   instância) — decisão de custo documentada; o pipeline usa uma instância.
8. **`connectedAndroidTest`** não executado; o smoke test da Activity continua
   sem execução.

---

## 9. Próxima etapa (somente descrição — não implementada)

**Fase 8 — Calibração com frames reais e controle assistido:**

1. extrair frames do vídeo para `app/src/test/resources/frames/` e rodar o
   harness de replay (`RecordedFrameSource`) sobre os mesmos instantes citados
   (5,5 s · 8 s · 10 s · 12 s · 14 s · 15 s) para ajustar `VisionConfig`;
2. coletar evidência em device com `debugFrameCaptureEnabled = true` e comparar
   com o overlay ao vivo;
3. definir a polaridade do toque (`positive = esquerda|direita`) por medição,
   nunca por suposição (§32);
4. só então habilitar `inputEnabled = true` com `controllerEnabled = true`, com
   a guarda central já testada, e validar hold/limites em aparelho;
5. deixar o `ShakeDetector` como módulo separado, depois do controle de pesca
   estar validado (§45/§46).
